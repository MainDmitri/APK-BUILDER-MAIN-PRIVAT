package com.dahua.checker

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

data class UserInfo(
    val nickname: String,
    val code: String,
    val activatedAt: Long,
    val deviceId: String = ""
)

object AuthManager {

    private const val BOT_TOKEN    = "9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY"
    private const val BOT_API      = "https://api.telegram.org/bot$BOT_TOKEN"
    private const val ADMIN_CHAT   = "6365916323"

    // tgcloud endpoint для записи активаций в БД
    private const val TGCLOUD_URL  = "https://cloud.telegram.org/app9052071852/api/check"
    private const val ENDPOINT_SECRET = "msx9k_MainDmitri_2024_lock"

    private const val SECRET_KEY   = "MainDmitri_secret_2024_xK9m"

    // AES ключ для шифрования SharedPreferences (32 байта = AES-256)
    // Производится из SECRET_KEY + ANDROID_ID → уникален для каждого устройства
    private fun aesKey(deviceId: String): ByteArray =
        sha256bytes(SECRET_KEY + deviceId)

    private const val PREFS_NAME    = "ms_auth_x7k"
    private const val KEY_ACTIVATED = "ax_st"
    private const val KEY_NICKNAME  = "ax_nk"
    private const val KEY_DEVICE_ID = "ax_did"   // зашифрованный deviceId
    private const val KEY_USERS     = "ax_users"
    private const val KEY_LOCK_HASH = "ax_lh"    // sha256(deviceId + code + nickname)

    private val adminPasswordHash: String by lazy {
        sha256hex("MainC4yt552" + "slt_x9k")
    }

    private fun getPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getDeviceId(context: Context): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: "unknown"

    fun isActivated(context: Context): Boolean =
        getPrefs(context).getBoolean(KEY_ACTIVATED, false)

    // Главная защита — вызывать при каждом запуске приложения
    fun verifyDeviceLock(context: Context): Boolean {
        val prefs      = getPrefs(context)
        val nickname   = prefs.getString(KEY_NICKNAME, null) ?: return false
        val lockHash   = prefs.getString(KEY_LOCK_HASH, null) ?: return false
        val deviceId   = getDeviceId(context)
        val code       = generateCodeForNickname(nickname).replace("-", "")

        // lockHash должен совпадать с sha256(deviceId + code + nickname)
        val expected = sha256hex(deviceId + code + nickname)
        if (lockHash != expected) {
            // Телефон изменился или данные подделаны — деактивируем
            deactivate(context)
            return false
        }
        return true
    }

    fun getActiveNickname(context: Context): String =
        getPrefs(context).getString(KEY_NICKNAME, "") ?: ""

    private fun saveActivation(context: Context, nickname: String, deviceId: String) {
        val code     = generateCodeForNickname(nickname).replace("-", "")
        val lockHash = sha256hex(deviceId + code + nickname)

        // Шифруем deviceId через AES-256
        val encDeviceId = aesEncrypt(deviceId, aesKey(deviceId))

        getPrefs(context).edit()
            .putBoolean(KEY_ACTIVATED, true)
            .putString(KEY_NICKNAME, nickname)
            .putString(KEY_DEVICE_ID, encDeviceId)
            .putString(KEY_LOCK_HASH, lockHash)
            .apply()
    }

    fun deactivate(context: Context) {
        getPrefs(context).edit()
            .remove(KEY_ACTIVATED)
            .remove(KEY_NICKNAME)
            .remove(KEY_DEVICE_ID)
            .remove(KEY_LOCK_HASH)
            .apply()
    }

    fun verifyAdminPassword(password: String): Boolean =
        sha256hex(password + "slt_x9k") == adminPasswordHash

    // ── Генерация кода (HMAC-SHA256) ─────────────────────────────────────────

    private fun generateCodeForNickname(nickname: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(SECRET_KEY.toByteArray(), "HmacSHA256"))
        val hash  = mac.doFinal(nickname.trim().lowercase().toByteArray())
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb    = StringBuilder()
        for (i in 0 until 12) {
            if (i > 0 && i % 4 == 0) sb.append('-')
            sb.append(chars[(hash[i].toInt() and 0xFF) % chars.length])
        }
        return sb.toString()
    }

    // ── АКТИВАЦИЯ ─────────────────────────────────────────────────────────────

    fun activate(context: Context, nickname: String, code: String): Result<Boolean> {
        return try {
            val trimmedNick   = nickname.trim()
            val inputClean    = code.trim().uppercase().replace("-", "").replace(" ", "")
            val expectedClean = generateCodeForNickname(trimmedNick).replace("-", "")

            // 1. Локальная HMAC проверка
            if (inputClean != expectedClean) return Result.success(false)

            val deviceId = getDeviceId(context)

            // 2. Сохраняем с device lock
            saveActivation(context, trimmedNick, deviceId)

            // 3. Уведомляем тебя в Telegram (fire and forget)
            notifyActivation(trimmedNick, deviceId)

            Result.success(true)

        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Уведомление + запись в БД через tgcloud endpoint
    // POST /api/check с секретом — не требует initData
    private fun notifyActivation(nickname: String, deviceId: String) {
        Thread {
            try {
                val code = generateCodeForNickname(nickname).replace("-", "")
                val body = JSONObject().apply {
                    put("secret",   ENDPOINT_SECRET)
                    put("nickname", nickname)
                    put("deviceId", deviceId)
                    put("code",     code)
                }.toString()

                val conn = URL(TGCLOUD_URL).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.connectTimeout = 8000
                conn.readTimeout    = 8000
                conn.doOutput       = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                // Читаем ответ чтобы коннекшн закрылся нормально
                val resp = try {
                    conn.inputStream.bufferedReader().readText()
                } catch (_: Exception) {
                    conn.errorStream?.bufferedReader()?.readText() ?: ""
                }

                // Если заблокировано — деактивируемся (опционально, можно убрать)
                // val json = JSONObject(resp)
                // if (json.optString("result") == "blocked") { ... }

            } catch (_: Exception) {
                // fire and forget — локальная активация уже сохранена
                // попробуем нотификацию через бота как fallback
                try {
                    val code = generateCodeForNickname(nickname).replace("-", "")
                    val fallbackBody = JSONObject().apply {
                        put("chat_id", ADMIN_CHAT)
                        put("text", "🔑 Активация (без DB): $nickname | ${deviceId.take(12)}")
                    }.toString()
                    val conn2 = URL("$BOT_API/sendMessage").openConnection() as HttpURLConnection
                    conn2.requestMethod = "POST"
                    conn2.setRequestProperty("Content-Type", "application/json")
                    conn2.connectTimeout = 5000
                    conn2.readTimeout    = 5000
                    conn2.doOutput       = true
                    conn2.outputStream.use { it.write(fallbackBody.toByteArray()) }
                    try { conn2.inputStream.close() } catch (_: Exception) {}
                } catch (_: Exception) {}
            }
        }.start()
    }

    // ── Админ функции ─────────────────────────────────────────────────────────

    fun generateCode(context: Context, nickname: String): Result<String> {
        return try {
            val trimmed  = nickname.trim()
            if (trimmed.isEmpty()) return Result.failure(Exception("Пустой никнейм"))
            val code     = generateCodeForNickname(trimmed)
            val users    = loadUsers(context).toMutableList()
            val existing = users.indexOfFirst { it.nickname.lowercase() == trimmed.lowercase() }
            if (existing >= 0) return Result.success(users[existing].code)
            users.add(UserInfo(trimmed, code, System.currentTimeMillis()))
            saveUsers(context, users)
            Result.success(code)
        } catch (e: Exception) { Result.failure(e) }
    }

    fun getUsers(context: Context): Result<List<UserInfo>> =
        try { Result.success(loadUsers(context)) } catch (e: Exception) { Result.failure(e) }

    fun deleteUser(context: Context, nickname: String): Result<Boolean> {
        return try {
            val users   = loadUsers(context).toMutableList()
            val removed = users.removeAll { it.nickname.lowercase() == nickname.trim().lowercase() }
            if (removed) saveUsers(context, users)
            Result.success(removed)
        } catch (e: Exception) { Result.failure(e) }
    }

    private fun loadUsers(context: Context): List<UserInfo> {
        val json = getPrefs(context).getString(KEY_USERS, "[]") ?: "[]"
        val arr  = org.json.JSONArray(json)
        return (0 until arr.length()).map {
            val obj = arr.getJSONObject(it)
            UserInfo(
                nickname    = obj.getString("nickname"),
                code        = obj.getString("code"),
                activatedAt = obj.optLong("createdAt", 0L),
                deviceId    = obj.optString("deviceId", "")
            )
        }
    }

    private fun saveUsers(context: Context, users: List<UserInfo>) {
        val arr = org.json.JSONArray()
        users.forEach { u ->
            arr.put(JSONObject().apply {
                put("nickname",  u.nickname)
                put("code",      u.code)
                put("createdAt", u.activatedAt)
                put("deviceId",  u.deviceId)
            })
        }
        getPrefs(context).edit().putString(KEY_USERS, arr.toString()).apply()
    }

    // ── Крипто ────────────────────────────────────────────────────────────────

    private fun aesEncrypt(plaintext: String, key: ByteArray): String {
        val iv     = ByteArray(16).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
        val encrypted = cipher.doFinal(plaintext.toByteArray())
        // IV + encrypted, base64
        return Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
    }

    private fun sha256hex(text: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(text.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun sha256bytes(text: String): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(text.toByteArray())
}
