package com.dahua.checker

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import java.net.Inet4Address
import java.net.NetworkInterface

data class LocalNetwork(
    val ip: String,
    val subnet: String,
    val prefix: Int,
    val gateway: String = "",
    val interfaceName: String = "",
    val networkType: String = ""   // "WiFi", "Ethernet", "Mobile", "VPN", "USB", "Unknown"
)

object NetworkUtils {

    /**
     * Определяет ВСЕ доступные локальные сети — WiFi, Ethernet, USB tethering, VPN и т.д.
     * Возвращает первую подходящую (приоритет: wlan > eth > rndis/usb > rmnet > tun/ppp)
     */
    fun getLocalNetwork(context: Context): LocalNetwork? {
        // Способ 1: ConnectivityManager — надёжный на API 23+
        val cmResult = tryConnectivityManager(context)
        if (cmResult != null) return cmResult

        // Способ 2: Перебор всех NetworkInterface
        return tryAllInterfaces()
    }

    /**
     * Возвращает ВСЕ найденные сети — полезно для UI "выбери сеть"
     */
    fun getAllNetworks(context: Context): List<LocalNetwork> {
        val results = mutableListOf<LocalNetwork>()

        // ConnectivityManager — активная сеть
        tryConnectivityManager(context)?.let { results.add(it) }

        // Все интерфейсы
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return results
            for (iface in interfaces.asSequence()) {
                if (iface.isLoopback || !iface.isUp) continue

                for (ifAddr in iface.interfaceAddresses) {
                    val addr = ifAddr.address
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        val prefix = ifAddr.networkPrefixLength.toInt()
                        if (prefix < 8 || prefix > 30) continue  // skip weird masks

                        // Пропускаем если уже есть от ConnectivityManager
                        if (results.any { it.ip == ip }) continue

                        val subnet = calculateSubnet(ip, prefix)
                        val type = classifyInterface(iface.name)
                        val gw = guessGateway(ip, prefix)

                        results.add(
                            LocalNetwork(
                                ip = ip,
                                subnet = subnet,
                                prefix = prefix,
                                gateway = gw,
                                interfaceName = iface.name,
                                networkType = type
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {}

        // Сортировка по приоритету: WiFi → Ethernet → USB → VPN → Mobile → Unknown
        val priority = mapOf("WiFi" to 0, "Ethernet" to 1, "USB" to 2, "VPN" to 3, "Mobile" to 4, "Unknown" to 5)
        return results.sortedBy { priority[it.networkType] ?: 5 }
    }

    private fun tryConnectivityManager(context: Context): LocalNetwork? {
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return null
            val linkProps: LinkProperties = cm.getLinkProperties(network) ?: return null

            // Ищем gateway
            var gatewayIp = ""
            for (route in linkProps.routes) {
                if (route.isDefaultRoute) {
                    gatewayIp = route.gateway?.hostAddress ?: ""
                    break
                }
            }

            // Имя интерфейса
            val ifaceName = linkProps.interfaceName ?: ""

            for (addr in linkProps.linkAddresses) {
                val inetAddr = addr.address
                if (inetAddr is Inet4Address && !inetAddr.isLoopbackAddress) {
                    val ip = inetAddr.hostAddress ?: continue
                    val prefix = addr.prefixLength
                    val subnet = calculateSubnet(ip, prefix)
                    val type = classifyInterface(ifaceName)

                    return LocalNetwork(
                        ip = ip,
                        subnet = subnet,
                        prefix = prefix,
                        gateway = gatewayIp,
                        interfaceName = ifaceName,
                        networkType = type
                    )
                }
            }
        } catch (_: Exception) {}
        return null
    }

    private fun tryAllInterfaces(): LocalNetwork? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null

            // Приоритет интерфейсов
            data class Candidate(val net: LocalNetwork, val priority: Int)
            val candidates = mutableListOf<Candidate>()

            for (iface in interfaces.asSequence()) {
                if (iface.isLoopback || !iface.isUp) continue
                val name = iface.name.lowercase()
                val pri = when {
                    name.startsWith("wlan") -> 0
                    name.startsWith("eth") -> 1
                    name.startsWith("rndis") || name.startsWith("usb") -> 2
                    name.startsWith("tun") || name.startsWith("ppp") || name.startsWith("tap") -> 3
                    name.startsWith("rmnet") -> 4
                    name.startsWith("ccmni") || name.startsWith("pdp") -> 4
                    else -> 5
                }

                for (ifAddr in iface.interfaceAddresses) {
                    val addr = ifAddr.address
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        val prefix = ifAddr.networkPrefixLength.toInt()
                        if (prefix < 8 || prefix > 30) continue

                        val subnet = calculateSubnet(ip, prefix)
                        val type = classifyInterface(iface.name)
                        val gw = guessGateway(ip, prefix)

                        candidates.add(
                            Candidate(
                                LocalNetwork(ip, subnet, prefix, gw, iface.name, type),
                                pri
                            )
                        )
                    }
                }
            }

            return candidates.minByOrNull { it.priority }?.net
        } catch (_: Exception) {}
        return null
    }

    /**
     * Классифицирует интерфейс по имени
     */
    private fun classifyInterface(name: String): String {
        val n = name.lowercase()
        return when {
            n.startsWith("wlan") || n.startsWith("wifi") -> "WiFi"
            n.startsWith("eth") || n.startsWith("en") -> "Ethernet"
            n.startsWith("rndis") || n.startsWith("usb") -> "USB"
            n.startsWith("tun") || n.startsWith("ppp") || n.startsWith("tap") || n.startsWith("wg") -> "VPN"
            n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("pdp") -> "Mobile"
            else -> "Unknown"
        }
    }

    /**
     * Угадывает gateway — .1 для /24, .1 для /16 (первый хост)
     */
    private fun guessGateway(ip: String, prefix: Int): String {
        val parts = ip.split(".")
        if (parts.size != 4) return ""
        return when {
            prefix >= 24 -> "${parts[0]}.${parts[1]}.${parts[2]}.1"
            prefix >= 16 -> "${parts[0]}.${parts[1]}.0.1"
            prefix >= 8  -> "${parts[0]}.0.0.1"
            else -> ""
        }
    }

    fun calculateSubnet(ip: String, prefix: Int): String {
        val parts = ip.split(".")
        if (parts.size != 4) return "$ip/$prefix"

        val ipLong = parts.fold(0L) { acc, s ->
            (acc shl 8) or (s.toIntOrNull()?.toLong() ?: 0L)
        }

        val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        val network = ipLong and mask

        val a = (network shr 24) and 0xFF
        val b = (network shr 16) and 0xFF
        val c = (network shr 8) and 0xFF
        val d = network and 0xFF

        return "$a.$b.$c.$d/$prefix"
    }

    /**
     * Считает кол-во хостов в подсети
     */
    fun hostCount(prefix: Int): Long {
        if (prefix >= 31) return (1L shl (32 - prefix))
        return (1L shl (32 - prefix)) - 2  // минус network и broadcast
    }

    /**
     * Проверяет, является ли IP приватным (RFC 1918 / RFC 6598 / link-local)
     */
    fun isPrivateIp(ip: String): Boolean {
        val parts = ip.split(".")
        if (parts.size != 4) return false
        val a = parts[0].toIntOrNull() ?: return false
        val b = parts[1].toIntOrNull() ?: return false
        return when {
            a == 10 -> true                                 // 10.0.0.0/8
            a == 172 && b in 16..31 -> true                 // 172.16.0.0/12
            a == 192 && b == 168 -> true                    // 192.168.0.0/16
            a == 100 && b in 64..127 -> true                // 100.64.0.0/10 (CGNAT)
            a == 169 && b == 254 -> true                    // 169.254.0.0/16 (link-local)
            a == 127 -> true                                // loopback
            else -> false
        }
    }
}
