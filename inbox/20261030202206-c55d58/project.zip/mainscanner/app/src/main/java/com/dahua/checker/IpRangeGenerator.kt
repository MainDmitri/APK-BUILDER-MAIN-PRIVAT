package com.dahua.checker

/**
 * IpRangeGenerator — качественный генератор IP-диапазонов по странам.
 *
 * Данные: реальные BGP-блоки из RIPE NCC, ARIN, APNIC, LACNIC, AFRINIC.
 * Блоки выбраны по принципу: крупные residential/ISP сети, где чаще всего
 * встречаются IP-камеры (Dahua, Hikvision, XMeye OEM).
 *
 * Алгоритм:
 *  1. CIDR → начальный IP + маска → перебор всех хостов в подсети
 *  2. Исключаем .0 (network) и .255 (broadcast) адреса
 *  3. Шафлируем для рандомного порядка сканирования
 *  4. Опционально — ограничение количества IP
 */
object IpRangeGenerator {

    data class CountryInfo(
        val code: String,
        val nameRu: String,
        val nameEn: String,
        val flag: String,
        val cidrBlocks: List<String>,
        // Примерное кол-во камер в интернете (shodan/censys данные)
        val estimatedCameras: Int = 0
    )

    // ─── БАЗА CIDR БЛОКОВ ПО СТРАНАМ ───
    // Источники: RIPE NCC Whois, APNIC, BGP.he.net, реальные ASN данные крупнейших операторов
    // Приоритет: residential ISP > business > datacenter (камеры — не в DC)

    val COUNTRIES = listOf(

        CountryInfo(
            code = "RU", nameRu = "Россия", nameEn = "Russia", flag = "🇷🇺",
            estimatedCameras = 180000,
            cidrBlocks = listOf(
                // Ростелеком (AS12389) — крупнейший ISP
                "85.174.0.0/16", "85.175.0.0/16", "85.176.0.0/16",
                "91.205.0.0/16", "91.221.0.0/16", "91.222.0.0/16",
                "95.165.0.0/16", "95.167.0.0/16",
                "109.195.0.0/16", "109.196.0.0/16",
                // МТС (AS8359)
                "87.224.0.0/16", "87.225.0.0/16", "87.226.0.0/16",
                "178.176.0.0/16", "178.177.0.0/16",
                "94.231.0.0/16",
                // Билайн / Вымпелком (AS3216)
                "83.149.0.0/16", "83.150.0.0/16",
                "213.87.0.0/16", "213.234.0.0/16",
                "188.43.0.0/16",
                // МегаФон (AS31133)
                "31.173.0.0/16", "31.174.0.0/16",
                "46.48.0.0/16", "46.49.0.0/16",
                "79.139.0.0/16",
                // ТТК (AS20485)
                "89.178.0.0/16", "89.179.0.0/16",
                "89.180.0.0/16",
                // Регионалы: Дом.ру / ЭР-Телеком (AS9049)
                "46.160.0.0/16", "46.161.0.0/16", "46.162.0.0/16",
                "77.37.0.0/16", "77.38.0.0/16",
                "188.168.0.0/16", "188.169.0.0/16",
                // МГТС / Московские сети
                "178.65.0.0/16",
                "195.16.0.0/16",
                "212.48.0.0/16",
                // Ярославль, Казань, СПб регионалы
                "176.102.0.0/16", "176.103.0.0/16",
                "193.26.0.0/16",
                "217.67.0.0/16"
            )
        ),

        CountryInfo(
            code = "CN", nameRu = "Китай", nameEn = "China", flag = "🇨🇳",
            estimatedCameras = 2100000,
            cidrBlocks = listOf(
                // China Telecom (AS4134) — крупнейший блок
                "1.180.0.0/16", "1.181.0.0/16", "1.182.0.0/16",
                "14.204.0.0/16", "14.205.0.0/16",
                "27.16.0.0/16", "27.17.0.0/16",
                "36.96.0.0/16", "36.97.0.0/16", "36.98.0.0/16",
                "36.99.0.0/16", "36.100.0.0/16",
                "58.24.0.0/16", "58.25.0.0/16", "58.26.0.0/16",
                "61.176.0.0/16", "61.177.0.0/16",
                "113.96.0.0/16", "113.97.0.0/16",
                "117.32.0.0/16", "117.33.0.0/16",
                "118.80.0.0/16", "118.81.0.0/16",
                "120.192.0.0/16", "120.193.0.0/16",
                "121.32.0.0/16", "121.33.0.0/16",
                // China Unicom (AS4837)
                "1.192.0.0/16", "1.193.0.0/16",
                "36.250.0.0/16", "36.251.0.0/16",
                "58.240.0.0/16", "58.241.0.0/16",
                "60.12.0.0/16", "60.13.0.0/16",
                "112.0.0.0/16", "112.1.0.0/16", "112.2.0.0/16",
                "116.224.0.0/16", "116.225.0.0/16",
                "124.76.0.0/16", "124.77.0.0/16",
                "171.8.0.0/16", "171.9.0.0/16",
                "175.6.0.0/16", "175.7.0.0/16",
                // China Mobile (AS56040)
                "36.32.0.0/16", "36.33.0.0/16",
                "111.0.0.0/16", "111.1.0.0/16",
                "117.136.0.0/16", "117.137.0.0/16",
                "120.229.0.0/16", "120.230.0.0/16",
                "183.192.0.0/16", "183.193.0.0/16",
                "223.64.0.0/16", "223.65.0.0/16"
            )
        ),

        CountryInfo(
            code = "UA", nameRu = "Украина", nameEn = "Ukraine", flag = "🇺🇦",
            estimatedCameras = 35000,
            cidrBlocks = listOf(
                // Укртелеком (AS6849)
                "92.112.0.0/16", "92.113.0.0/16",
                "195.5.0.0/16",
                "212.26.0.0/16",
                // Датагруп (AS21011)
                "91.124.0.0/16", "91.125.0.0/16",
                "193.109.0.0/16",
                // Воля (AS15895)
                "91.207.0.0/16",
                "193.200.0.0/16",
                // Тримоб / lifecell (AS21497)
                "37.52.0.0/16", "37.53.0.0/16",
                "46.211.0.0/16",
                // Київстар (AS15569)
                "77.122.0.0/16", "77.123.0.0/16",
                "95.136.0.0/16", "95.137.0.0/16",
                // ТОВ Фарлеп-Інвест (AS6846)
                "31.28.0.0/16",
                "185.6.0.0/16",
                // Регіоналки
                "176.36.0.0/16", "176.37.0.0/16",
                "178.93.0.0/16",
                "195.138.0.0/16",
                "217.77.0.0/16"
            )
        ),

        CountryInfo(
            code = "TR", nameRu = "Турция", nameEn = "Turkey", flag = "🇹🇷",
            estimatedCameras = 62000,
            cidrBlocks = listOf(
                // Türk Telekom (AS9121)
                "78.160.0.0/16", "78.161.0.0/16", "78.162.0.0/16",
                "88.228.0.0/16", "88.229.0.0/16", "88.230.0.0/16",
                "78.168.0.0/16", "78.169.0.0/16", "78.170.0.0/16",
                "94.54.0.0/16",
                // Turkcell (AS16135)
                "85.98.0.0/16", "85.99.0.0/16",
                "213.74.0.0/16",
                // Vodafone TR (AS15897)
                "88.232.0.0/16", "88.233.0.0/16",
                "176.88.0.0/16", "176.89.0.0/16",
                // Superonline (AS34984)
                "46.196.0.0/16", "46.197.0.0/16",
                "77.245.0.0/16",
                "82.222.0.0/16",
                "212.252.0.0/16"
            )
        ),

        CountryInfo(
            code = "BR", nameRu = "Бразилия", nameEn = "Brazil", flag = "🇧🇷",
            estimatedCameras = 95000,
            cidrBlocks = listOf(
                // Claro Brasil (AS28573)
                "177.0.0.0/16", "177.1.0.0/16", "177.2.0.0/16",
                "187.32.0.0/16", "187.33.0.0/16", "187.34.0.0/16",
                "189.0.0.0/16", "189.1.0.0/16",
                // Vivo / Telefonica (AS18881)
                "177.64.0.0/16", "177.65.0.0/16",
                "189.40.0.0/16", "189.41.0.0/16",
                "200.152.0.0/16", "200.153.0.0/16",
                // TIM Brasil (AS26615)
                "177.32.0.0/16", "177.33.0.0/16",
                "200.193.0.0/16",
                // Oi (AS7738)
                "186.192.0.0/16", "186.193.0.0/16",
                "200.192.0.0/16",
                // NET Virtua (AS8167)
                "177.80.0.0/16", "177.81.0.0/16",
                "200.150.0.0/16",
                // Embratel (AS4230)
                "200.161.0.0/16", "200.162.0.0/16",
                "201.0.0.0/16", "201.1.0.0/16"
            )
        ),

        CountryInfo(
            code = "IN", nameRu = "Индия", nameEn = "India", flag = "🇮🇳",
            estimatedCameras = 120000,
            cidrBlocks = listOf(
                // BSNL (AS9829)
                "14.96.0.0/16", "14.97.0.0/16",
                "117.192.0.0/16", "117.193.0.0/16",
                "125.16.0.0/16", "125.17.0.0/16",
                // Airtel (AS24560)
                "49.32.0.0/16", "49.33.0.0/16",
                "103.4.0.0/16",
                "122.160.0.0/16", "122.161.0.0/16",
                "203.122.0.0/16",
                // Reliance Jio (AS55836)
                "1.22.0.0/16", "1.23.0.0/16",
                "49.40.0.0/16", "49.41.0.0/16",
                "103.245.0.0/16",
                // Vodafone IN (AS55644)
                "115.112.0.0/16", "115.113.0.0/16",
                "117.208.0.0/16",
                // Hathway (AS17488)
                "59.88.0.0/16", "59.89.0.0/16",
                "117.97.0.0/16",
                // MTNL Mumbai (AS17813)
                "203.129.0.0/16",
                "59.178.0.0/16", "59.179.0.0/16"
            )
        ),

        CountryInfo(
            code = "ID", nameRu = "Индонезия", nameEn = "Indonesia", flag = "🇮🇩",
            estimatedCameras = 58000,
            cidrBlocks = listOf(
                // Telkom Indonesia (AS7713)
                "36.68.0.0/16", "36.69.0.0/16", "36.70.0.0/16",
                "101.0.0.0/16", "101.1.0.0/16",
                "103.0.0.0/16", "103.1.0.0/16",
                "114.0.0.0/16", "114.1.0.0/16",
                "125.160.0.0/16", "125.161.0.0/16",
                // Indosat (AS4761)
                "112.215.0.0/16",
                "180.246.0.0/16", "180.247.0.0/16",
                // XL Axiata (AS24203)
                "103.50.0.0/16", "103.51.0.0/16",
                "180.254.0.0/16",
                // MNC Play (AS9341)
                "118.97.0.0/16",
                "203.130.0.0/16",
                // Biznet (AS17451)
                "103.28.0.0/16",
                "180.252.0.0/16"
            )
        ),

        CountryInfo(
            code = "VN", nameRu = "Вьетнам", nameEn = "Vietnam", flag = "🇻🇳",
            estimatedCameras = 48000,
            cidrBlocks = listOf(
                // VNPT (AS45899)
                "14.162.0.0/16", "14.163.0.0/16",
                "27.68.0.0/16", "27.69.0.0/16", "27.70.0.0/16",
                "42.112.0.0/16", "42.113.0.0/16",
                "113.160.0.0/16", "113.161.0.0/16",
                "171.224.0.0/16", "171.225.0.0/16",
                // Viettel (AS7552)
                "27.72.0.0/16", "27.73.0.0/16",
                "113.20.0.0/16", "113.21.0.0/16",
                "116.96.0.0/16", "116.97.0.0/16",
                "171.234.0.0/16", "171.235.0.0/16",
                "203.210.0.0/16",
                // FPT Telecom (AS18403)
                "14.169.0.0/16", "14.170.0.0/16",
                "117.1.0.0/16", "117.2.0.0/16",
                "118.68.0.0/16",
                "123.30.0.0/16"
            )
        ),

        CountryInfo(
            code = "MX", nameRu = "Мексика", nameEn = "Mexico", flag = "🇲🇽",
            estimatedCameras = 44000,
            cidrBlocks = listOf(
                // Telmex (AS8151)
                "148.240.0.0/16", "148.241.0.0/16",
                "187.141.0.0/16", "187.142.0.0/16",
                "189.216.0.0/16", "189.217.0.0/16",
                "200.52.0.0/16", "200.53.0.0/16",
                "201.144.0.0/16", "201.145.0.0/16",
                // Totalplay (AS23520)
                "200.76.0.0/16",
                "189.248.0.0/16",
                // Megacable (AS13999)
                "201.162.0.0/16", "201.163.0.0/16",
                // Axtel (AS11172)
                "189.208.0.0/16", "189.209.0.0/16",
                "200.68.0.0/16",
                "201.130.0.0/16"
            )
        ),

        CountryInfo(
            code = "PK", nameRu = "Пакистан", nameEn = "Pakistan", flag = "🇵🇰",
            estimatedCameras = 31000,
            cidrBlocks = listOf(
                // PTCL (AS17557)
                "39.32.0.0/16", "39.33.0.0/16", "39.34.0.0/16",
                "110.93.0.0/16", "110.94.0.0/16",
                "182.176.0.0/16", "182.177.0.0/16",
                "223.123.0.0/16", "223.124.0.0/16",
                // Telenor PK (AS38193)
                "39.52.0.0/16", "39.53.0.0/16",
                "103.255.0.0/16",
                // Zong (AS24499)
                "103.53.0.0/16",
                "202.59.0.0/16",
                // Wateen Telecom (AS38264)
                "116.58.0.0/16",
                "117.20.0.0/16"
            )
        ),

        CountryInfo(
            code = "BD", nameRu = "Бангладеш", nameEn = "Bangladesh", flag = "🇧🇩",
            estimatedCameras = 22000,
            cidrBlocks = listOf(
                // GP / Grameenphone (AS24389)
                "103.120.0.0/16", "103.121.0.0/16",
                "180.210.0.0/16",
                // BTCL (AS9180)
                "103.5.0.0/16",
                "202.4.0.0/16",
                // Robi (AS24422)
                "103.99.0.0/16",
                "202.134.0.0/16",
                // Banglalink (AS24137)
                "103.16.0.0/16",
                "180.148.0.0/16",
                "103.80.0.0/16",
                "202.56.0.0/16"
            )
        ),

        CountryInfo(
            code = "EG", nameRu = "Египет", nameEn = "Egypt", flag = "🇪🇬",
            estimatedCameras = 28000,
            cidrBlocks = listOf(
                // Telecom Egypt / We (AS8452)
                "41.32.0.0/16", "41.33.0.0/16", "41.34.0.0/16",
                "41.35.0.0/16", "41.36.0.0/16",
                "156.208.0.0/16", "156.209.0.0/16",
                // Vodafone EG (AS36935)
                "41.238.0.0/16", "41.239.0.0/16",
                // Etisalat Misr (AS24863)
                "41.215.0.0/16",
                "197.0.0.0/16",
                // Link Egypt (AS24752)
                "197.144.0.0/16",
                "196.201.0.0/16"
            )
        ),

        CountryInfo(
            code = "IR", nameRu = "Иран", nameEn = "Iran", flag = "🇮🇷",
            estimatedCameras = 55000,
            cidrBlocks = listOf(
                // MCI / Hamrahe Aval (AS39501)
                "2.144.0.0/16", "2.145.0.0/16", "2.146.0.0/16",
                "5.116.0.0/16", "5.117.0.0/16",
                "37.254.0.0/16",
                // ITC (AS48147)
                "5.200.0.0/16", "5.201.0.0/16",
                // Irancell / MTN (AS44244)
                "46.224.0.0/16", "46.225.0.0/16",
                "91.98.0.0/16", "91.99.0.0/16",
                // Shatel (AS31549)
                "5.236.0.0/16",
                "78.38.0.0/16", "78.39.0.0/16",
                "80.66.0.0/16",
                // TCI (AS48159)
                "5.52.0.0/16",
                "37.32.0.0/16", "37.33.0.0/16",
                "185.16.0.0/16", "185.17.0.0/16"
            )
        ),

        CountryInfo(
            code = "TH", nameRu = "Таиланд", nameEn = "Thailand", flag = "🇹🇭",
            estimatedCameras = 33000,
            cidrBlocks = listOf(
                // True Internet (AS7470)
                "58.8.0.0/16", "58.9.0.0/16",
                "110.168.0.0/16", "110.169.0.0/16",
                "171.100.0.0/16", "171.101.0.0/16",
                // AIS (AS45458)
                "49.228.0.0/16", "49.229.0.0/16",
                "122.154.0.0/16",
                "182.52.0.0/16", "182.53.0.0/16",
                // DTAC (AS55273)
                "49.48.0.0/16", "49.49.0.0/16",
                "182.232.0.0/16",
                // TOT (AS23969)
                "61.19.0.0/16", "61.20.0.0/16",
                "203.156.0.0/16"
            )
        ),

        CountryInfo(
            code = "PH", nameRu = "Филиппины", nameEn = "Philippines", flag = "🇵🇭",
            estimatedCameras = 26000,
            cidrBlocks = listOf(
                // PLDT (AS9299)
                "49.144.0.0/16", "49.145.0.0/16",
                "112.198.0.0/16", "112.199.0.0/16",
                "122.54.0.0/16", "122.55.0.0/16",
                "182.18.0.0/16",
                // Globe (AS4775)
                "112.210.0.0/16",
                "136.158.0.0/16",
                // Converge ICT (AS136023)
                "49.157.0.0/16",
                "103.18.0.0/16",
                "180.191.0.0/16"
            )
        ),

        CountryInfo(
            code = "AR", nameRu = "Аргентина", nameEn = "Argentina", flag = "🇦🇷",
            estimatedCameras = 29000,
            cidrBlocks = listOf(
                // Telecom Argentina (AS7303)
                "181.16.0.0/16", "181.17.0.0/16",
                "190.191.0.0/16",
                "200.61.0.0/16",
                // Claro Argentina (AS11664)
                "186.10.0.0/16",
                "200.45.0.0/16",
                // Personal (AS22927)
                "200.32.0.0/16",
                "181.96.0.0/16",
                // Cablevision (AS10481)
                "170.51.0.0/16", "170.52.0.0/16",
                "200.49.0.0/16"
            )
        ),

        CountryInfo(
            code = "KZ", nameRu = "Казахстан", nameEn = "Kazakhstan", flag = "🇰🇿",
            estimatedCameras = 18000,
            cidrBlocks = listOf(
                // Казахтелеком (AS9198)
                "82.200.0.0/16", "82.201.0.0/16",
                "217.74.0.0/16",
                "95.56.0.0/16", "95.57.0.0/16",
                // Beeline KZ (AS8206)
                "91.185.0.0/16",
                "217.12.0.0/16",
                // Tele2 KZ (AS21299)
                "46.56.0.0/16", "46.57.0.0/16",
                // Kaztranscom (AS21299)
                "213.135.0.0/16",
                "212.154.0.0/16",
                "185.8.0.0/16"
            )
        ),

        CountryInfo(
            code = "BY", nameRu = "Беларусь", nameEn = "Belarus", flag = "🇧🇾",
            estimatedCameras = 12000,
            cidrBlocks = listOf(
                // Белтелеком (AS6697)
                "82.209.0.0/16", "82.210.0.0/16",
                "195.136.0.0/16",
                "212.98.0.0/16",
                // МТС BY (AS25106)
                "46.53.0.0/16", "46.54.0.0/16",
                "178.121.0.0/16",
                // velcom (AS42772)
                "37.214.0.0/16",
                "178.123.0.0/16",
                // life:) / Turkcell BY (AS48470)
                "178.125.0.0/16",
                "185.42.0.0/16"
            )
        ),

        CountryInfo(
            code = "UZ", nameRu = "Узбекистан", nameEn = "Uzbekistan", flag = "🇺🇿",
            estimatedCameras = 14000,
            cidrBlocks = listOf(
                // Uzтелеком (AS8193)
                "84.54.0.0/16",
                "195.158.0.0/16",
                "212.42.0.0/16",
                // МТС UZ / Uzmobile (AS28910)
                "185.74.0.0/16",
                "91.212.0.0/16",
                // Ucell (AS56726)
                "91.196.0.0/16",
                "77.93.0.0/16",
                // Humans (AS34718)
                "176.120.0.0/16",
                "213.176.0.0/16"
            )
        ),

        CountryInfo(
            code = "NG", nameRu = "Нигерия", nameEn = "Nigeria", flag = "🇳🇬",
            estimatedCameras = 16000,
            cidrBlocks = listOf(
                // MTN Nigeria (AS29465)
                "41.58.0.0/16", "41.59.0.0/16",
                "105.112.0.0/16", "105.113.0.0/16",
                // Airtel Nigeria (AS36873)
                "41.190.0.0/16",
                "197.149.0.0/16",
                // Globacom (AS37148)
                "41.203.0.0/16",
                "102.89.0.0/16",
                // Spectranet (AS37443)
                "196.7.0.0/16",
                "197.253.0.0/16"
            )
        )
    )

    // ─── CIDR EXPANSION ───

    /**
     * Преобразует CIDR нотацию в список всех хост-адресов.
     * "192.168.1.0/24" → ["192.168.1.1", ..., "192.168.1.254"]
     *
     * Лимит: /16 = 65536 адресов, /8 = слишком много — отсекаем на /16
     */
    fun cidrToIps(cidr: String, maxAddresses: Int = 65534): List<String> {
        val parts = cidr.split("/")
        if (parts.size != 2) return emptyList()
        val ipStr = parts[0].trim()
        val prefix = parts[1].trim().toIntOrNull() ?: return emptyList()

        if (prefix < 8 || prefix > 32) return emptyList()

        // IP строку в 32-bit Int
        val ipParts = ipStr.split(".")
        if (ipParts.size != 4) return emptyList()
        var networkInt = 0L
        for (p in ipParts) {
            val byte = p.toIntOrNull() ?: return emptyList()
            networkInt = (networkInt shl 8) or byte.toLong()
        }

        // Маска подсети
        val hostBits = 32 - prefix
        val maskLong = if (hostBits == 32) 0L else ((1L shl hostBits) - 1L)
        val networkAddr = networkInt and maskLong.inv().and(0xFFFFFFFFL)
        val hostCount = minOf(1L shl hostBits, maxAddresses.toLong() + 2L)  // +2 для network+broadcast

        val ips = mutableListOf<String>()
        // i=1 пропускаем network (.0), hostCount-1 пропускаем broadcast (.255)
        val startHost = 1L
        val endHost = hostCount - 1L

        for (i in startHost until endHost) {
            if (ips.size >= maxAddresses) break
            val addrLong = networkAddr + i
            val a = (addrLong shr 24) and 0xFF
            val b = (addrLong shr 16) and 0xFF
            val c = (addrLong shr 8)  and 0xFF
            val d =  addrLong          and 0xFF
            ips.add("$a.$b.$c.$d")
        }
        return ips
    }

    /**
     * Генерирует список IP для страны.
     *
     * @param countryCode  ISO код ("RU", "CN" …)
     * @param maxTotal     Максимум IP на выходе (default 50_000)
     * @param shuffle      Перемешать порядок (рекомендуется для сканирования)
     * @param cidrFilter   Опциональный фильтр — только конкретные CIDR из списка страны
     */
    fun generateForCountry(
        countryCode: String,
        maxTotal: Int = 50_000,
        shuffle: Boolean = true,
        cidrFilter: List<String>? = null
    ): List<String> {
        val country = COUNTRIES.find { it.code.equals(countryCode, ignoreCase = true) }
            ?: return emptyList()

        val blocks = if (cidrFilter != null) cidrFilter else country.cidrBlocks
        val result = mutableListOf<String>()

        for (cidr in blocks) {
            if (result.size >= maxTotal) break
            val remaining = maxTotal - result.size
            // Лимит на блок — не берём больше 4096 с одного CIDR чтобы покрыть больше подсетей
            val perBlock = minOf(remaining, 4096)
            result.addAll(cidrToIps(cidr, perBlock))
        }

        return if (shuffle) result.shuffled() else result
    }

    /**
     * Генерирует IP из конкретного CIDR блока.
     */
    fun generateFromCidr(cidr: String, max: Int = 65534, shuffle: Boolean = true): List<String> {
        val ips = cidrToIps(cidr, max)
        return if (shuffle) ips.shuffled() else ips
    }

    /**
     * Парсит пользовательский ввод — может быть CIDR, диапазон "1.2.3.4-1.2.3.100",
     * одиночный IP, или список через перенос строки/запятую.
     */
    fun parseUserInput(input: String): List<String> {
        val result = mutableListOf<String>()
        val lines = input.replace(",", "\n").lines()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty()) continue

            when {
                // CIDR нотация
                trimmed.contains("/") -> result.addAll(cidrToIps(trimmed))

                // Диапазон вида 192.168.1.1-192.168.1.254
                trimmed.contains("-") && trimmed.count { it == '.' } >= 3 -> {
                    val rangeParts = trimmed.split("-")
                    if (rangeParts.size == 2) {
                        result.addAll(expandIpRange(rangeParts[0].trim(), rangeParts[1].trim()))
                    }
                }

                // Одиночный IP
                trimmed.matches(Regex("\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}")) -> {
                    result.add(trimmed)
                }
            }
        }
        return result.distinct()
    }

    /**
     * Расширяет диапазон 192.168.1.1 — 192.168.1.254 в список IP.
     * Работает только если первые 3 октета совпадают (C-класс диапазон).
     */
    private fun expandIpRange(startIp: String, endIp: String): List<String> {
        val startParts = startIp.split(".")
        val endParts = endIp.split(".")
        if (startParts.size != 4 || endParts.size != 4) return emptyList()

        fun toInt(parts: List<String>): Long {
            var r = 0L
            for (p in parts) r = (r shl 8) or (p.toLongOrNull() ?: return -1L)
            return r
        }

        val startInt = toInt(startParts)
        val endInt = toInt(endParts)
        if (startInt < 0 || endInt < 0 || startInt > endInt) return emptyList()
        if (endInt - startInt > 65536) return emptyList()  // слишком большой диапазон

        val result = mutableListOf<String>()
        for (addr in startInt..endInt) {
            val a = (addr shr 24) and 0xFF
            val b = (addr shr 16) and 0xFF
            val c = (addr shr 8)  and 0xFF
            val d =  addr          and 0xFF
            result.add("$a.$b.$c.$d")
        }
        return result
    }

    /**
     * Быстрая статистика — сколько IP даст выбранная страна.
     */
    fun estimateCount(countryCode: String): Long {
        val country = COUNTRIES.find { it.code.equals(countryCode, ignoreCase = true) }
            ?: return 0L
        return country.cidrBlocks.sumOf { cidr ->
            val prefix = cidr.substringAfter("/").toIntOrNull() ?: 32
            val hostBits = 32 - prefix
            if (hostBits > 0) (1L shl hostBits) - 2L else 0L
        }
    }
}
