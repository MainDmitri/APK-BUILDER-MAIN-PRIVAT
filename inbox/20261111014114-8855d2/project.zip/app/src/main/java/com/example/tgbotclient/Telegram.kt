package com.example.tgbotclient

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/** Telegram limit for one text message. */
const val TG_TEXT_LIMIT = 4096

private val TOKEN_REGEX = Regex("""^\d{5,}:[A-Za-z0-9_-]{30,}$""")

fun isTokenFormatValid(token: String): Boolean = TOKEN_REGEX.matches(token.trim())

/** Parses Telegram Serverless CLI access token (e.g. app12345:secret or app_12345_secret) */
fun parseServerlessCliToken(input: String): Pair<String, String> {
    val clean = input.trim()
    if (clean.isBlank()) return "" to ""
    if (clean.startsWith("https://", ignoreCase = true) || clean.startsWith("http://", ignoreCase = true)) {
        return clean.trimEnd('/') to ""
    }
    val colonMatch = Regex("""^(app_?\w+):(.+)$""", RegexOption.IGNORE_CASE).find(clean)
    if (colonMatch != null) {
        val appId = colonMatch.groupValues[1].replace("_", "")
        return "https://$appId.tgcloud.ai" to clean
    }
    val underMatch = Regex("""^(app_\w+)_(.+)$""", RegexOption.IGNORE_CASE).find(clean)
    if (underMatch != null) {
        val appId = underMatch.groupValues[1].replace("_", "")
        return "https://$appId.tgcloud.ai" to clean
    }
    if (clean.startsWith("app", ignoreCase = true)) {
        val appId = clean.substringBefore(':').substringBefore('_')
        return "https://$appId.tgcloud.ai" to clean
    }
    return "" to clean
}

fun isServerlessTokenValid(token: String): Boolean {
    val t = token.trim()
    return t.startsWith("app", ignoreCase = true) || t.startsWith("https://") || t.length >= 8
}

data class BotInfo(val id: Long, val firstName: String, val username: String)

class TelegramException(message: String, val code: Int, val retryAfter: Int? = null) : IOException(message)

object Prefs {
    const val NAME = "bot"
    const val KEY_TOKEN = "token"
    const val KEY_SERVERLESS_TOKEN = "serverless_token"
    const val KEY_BRIDGE_URL = "bridge_url"
    const val KEY_BRIDGE_KEY = "bridge_key"
    const val KEY_AUTO_REPLY_ENABLED = "auto_reply_enabled"
    const val KEY_AUTO_REPLY_TEXT = "auto_reply_text"
    const val DEFAULT_AUTO_REPLY = "Ожидайте, администратор скоро ответит"

    fun of(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    fun draftKey(chatId: Long) = "draft_$chatId"
}

/** Notification ids: 1 is reserved for the foreground service. */
fun chatNotificationId(chatId: Long): Int = 2 + (abs(chatId) % 1_000_000L).toInt()

object TelegramApi {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json".toMediaType()

    /** Executes a Bot API method and returns the "result" object/value wrapper. */
    private fun call(token: String, method: String, body: JSONObject? = null): JSONObject {
        val builder = Request.Builder().url("https://api.telegram.org/bot$token/$method")
        if (body != null) builder.post(body.toString().toRequestBody(JSON))
        client.newCall(builder.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            val json = try {
                JSONObject(raw.ifBlank { "{}" })
            } catch (_: Exception) {
                throw TelegramException("Некорректный ответ сервера (HTTP ${resp.code})", resp.code)
            }
            if (!json.optBoolean("ok")) {
                val retry = json.optJSONObject("parameters")?.optInt("retry_after", 0)?.takeIf { it > 0 }
                throw TelegramException(
                    json.optString("description", "HTTP ${resp.code}"),
                    json.optInt("error_code", resp.code),
                    retry
                )
            }
            return json
        }
    }

    suspend fun getMe(token: String): BotInfo = withContext(Dispatchers.IO) {
        val r = call(token, "getMe").getJSONObject("result")
        BotInfo(r.getLong("id"), r.optString("first_name"), r.optString("username"))
    }

    suspend fun sendText(token: String, chatId: Long, text: String, replyTo: Long?): Long =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("chat_id", chatId)
                put("text", text)
                if (replyTo != null) {
                    put(
                        "reply_parameters",
                        JSONObject().put("message_id", replyTo).put("allow_sending_without_reply", true)
                    )
                }
            }
            call(token, "sendMessage", body).getJSONObject("result").getLong("message_id")
        }
}

/** Turns network / Bot API failures into a short Russian explanation. */
fun humanError(e: Throwable): String = when (e) {
    is UnknownHostException -> "Нет подключения к интернету"
    is SocketTimeoutException -> "Сервер Telegram не ответил вовремя"
    is TelegramException -> {
        val d = e.message.orEmpty()
        when {
            e.code == 401 || e.code == 404 -> "Неверный токен бота"
            e.code == 409 && d.contains("webhook", true) -> "У бота включён webhook — getUpdates недоступен"
            e.code == 409 -> "Бот уже запущен в другом месте (конфликт 409)"
            e.code == 429 -> "Слишком много запросов, повтор через ${e.retryAfter ?: 5} с"
            d.contains("chat not found", true) -> "Чат не найден"
            d.contains("blocked by the user", true) -> "Пользователь заблокировал бота"
            d.contains("not enough rights", true) -> "У бота нет прав писать в этот чат"
            d.contains("message is too long", true) -> "Сообщение слишком длинное"
            else -> d.ifBlank { "Ошибка Telegram ${e.code}" }
        }
    }
    else -> e.message?.takeIf { it.isNotBlank() } ?: "Неизвестная ошибка"
}

enum class BotState { STOPPED, STARTING, RUNNING, RETRYING, ERROR }

data class BotStatus(val state: BotState, val message: String = "")

/** In-process event bus between the polling service and the UI. */
object MessageBus {
    private val _changes = MutableStateFlow(0L)
    /** Increments whenever stored chats/messages change. */
    val changes: StateFlow<Long> = _changes.asStateFlow()

    private val _status = MutableStateFlow(BotStatus(BotState.STOPPED))
    val status: StateFlow<BotStatus> = _status.asStateFlow()

    /** Chat that is currently visible on screen (no unread counter / notification for it). */
    @Volatile var openChatId: Long? = null

    fun notifyChanged() = _changes.update { it + 1 }
    fun setStatus(s: BotStatus) { _status.value = s }
}
