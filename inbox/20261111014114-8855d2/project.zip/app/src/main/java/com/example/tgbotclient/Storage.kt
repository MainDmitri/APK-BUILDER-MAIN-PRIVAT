package com.example.tgbotclient

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Chat(
    val id: Long,
    val title: String,
    val type: String,
    val lastMessage: String,
    val lastTime: Long,
    val unread: Int = 0
)

data class TgMessage(
    val id: Long,
    val chatId: Long,
    val fromName: String,
    val text: String,
    val time: Long,
    val isBot: Boolean,
    val replyTo: Long? = null,
    val mediaType: String? = null
)

data class StorageStats(val chats: Int, val messages: Int)

class Storage private constructor(context: Context) : SQLiteOpenHelper(context, "tgbot.db", null, 3) {

    companion object {
        @Volatile private var inst: Storage? = null
        fun get(context: Context): Storage = inst ?: synchronized(this) {
            inst ?: Storage(context.applicationContext).also { inst = it }
        }

        private val CHAT_COLUMNS = arrayOf("id", "title", "type", "last_message", "last_time", "unread")
        private val MESSAGE_COLUMNS = arrayOf("id", "chat_id", "from_name", "text", "time", "is_bot", "reply_to", "media_type")
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE chats (
                id INTEGER PRIMARY KEY,
                title TEXT,
                type TEXT,
                last_message TEXT,
                last_time INTEGER,
                unread INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        createMessages(db)
    }

    // message_id is unique only within a chat, so the key must include chat_id
    private fun createMessages(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE messages (
                id INTEGER,
                chat_id INTEGER,
                from_name TEXT,
                text TEXT,
                time INTEGER,
                is_bot INTEGER,
                reply_to INTEGER,
                media_type TEXT,
                PRIMARY KEY (chat_id, id)
            )
            """
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        if (old < 2) {
            db.execSQL("ALTER TABLE messages RENAME TO messages_old")
            createMessages(db)
            db.execSQL(
                """
                INSERT OR IGNORE INTO messages (id, chat_id, from_name, text, time, is_bot, reply_to, media_type)
                SELECT id, chat_id, from_name, text, time, is_bot, reply_to, media_type FROM messages_old
                """
            )
            db.execSQL("DROP TABLE messages_old")
        }
        if (old < 3) {
            db.execSQL("ALTER TABLE chats ADD COLUMN unread INTEGER NOT NULL DEFAULT 0")
        }
    }

    /**
     * Saves a message and updates the chat preview.
     * [countUnread] is true for incoming messages of a chat that is not open on screen.
     */
    fun saveMessage(
        msg: TgMessage,
        chatTitle: String? = null,
        chatType: String? = null,
        countUnread: Boolean = false
    ) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("id", msg.id)
                put("chat_id", msg.chatId)
                put("from_name", msg.fromName)
                put("text", msg.text)
                put("time", msg.time)
                put("is_bot", if (msg.isBot) 1 else 0)
                put("reply_to", msg.replyTo)
                put("media_type", msg.mediaType)
            }
            db.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

            val exists = db.rawQuery("SELECT last_time FROM chats WHERE id = ?", arrayOf(msg.chatId.toString()))
                .use { if (it.moveToFirst()) it.getLong(0) else null }
            if (exists == null) {
                val chatCv = ContentValues().apply {
                    put("id", msg.chatId)
                    put("title", chatTitle ?: "Чат ${msg.chatId}")
                    put("type", chatType ?: "private")
                    put("last_message", msg.text.take(100))
                    put("last_time", msg.time)
                    put("unread", 0)
                }
                db.insert("chats", null, chatCv)
            } else {
                val chatCv = ContentValues().apply {
                    if (chatTitle != null) put("title", chatTitle)
                    if (chatType != null) put("type", chatType)
                    // an edit of an old message (or a late sync) must not replace the newest preview
                    if (msg.time >= exists) {
                        put("last_message", msg.text.take(100))
                        put("last_time", msg.time)
                    }
                }
                if (chatCv.size() > 0) db.update("chats", chatCv, "id=?", arrayOf(msg.chatId.toString()))
            }
            if (countUnread) {
                db.execSQL("UPDATE chats SET unread = unread + 1 WHERE id = ?", arrayOf<Any>(msg.chatId))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun messageExists(chatId: Long, id: Long): Boolean =
        readableDatabase.rawQuery(
            "SELECT 1 FROM messages WHERE chat_id = ? AND id = ? LIMIT 1",
            arrayOf(chatId.toString(), id.toString())
        ).use { it.moveToFirst() }

    private fun readChat(c: android.database.Cursor) = Chat(
        id = c.getLong(0),
        title = c.getString(1) ?: "",
        type = c.getString(2) ?: "",
        lastMessage = c.getString(3) ?: "",
        lastTime = c.getLong(4),
        unread = c.getInt(5)
    )

    fun getChats(): List<Chat> {
        val list = mutableListOf<Chat>()
        readableDatabase.query("chats", CHAT_COLUMNS, null, null, null, null, "last_time DESC").use {
            while (it.moveToNext()) list.add(readChat(it))
        }
        return list
    }

    fun getChat(chatId: Long): Chat? =
        readableDatabase.query("chats", CHAT_COLUMNS, "id=?", arrayOf(chatId.toString()), null, null, null)
            .use { if (it.moveToFirst()) readChat(it) else null }

    fun getChatTitle(chatId: Long): String? = getChat(chatId)?.title

    fun getMessages(chatId: Long): List<TgMessage> {
        val list = mutableListOf<TgMessage>()
        readableDatabase.query(
            "messages", MESSAGE_COLUMNS, "chat_id=?", arrayOf(chatId.toString()),
            null, null, "time DESC, id DESC", "200"
        ).use {
            while (it.moveToNext()) {
                list.add(
                    TgMessage(
                        it.getLong(0),
                        it.getLong(1),
                        it.getString(2) ?: "",
                        it.getString(3) ?: "",
                        it.getLong(4),
                        it.getInt(5) == 1,
                        if (it.isNull(6)) null else it.getLong(6),
                        it.getString(7)
                    )
                )
            }
        }
        return list.reversed()
    }

    fun markRead(chatId: Long) {
        val cv = ContentValues().apply { put("unread", 0) }
        writableDatabase.update("chats", cv, "id=? AND unread<>0", arrayOf(chatId.toString()))
    }

    fun stats(): StorageStats {
        val db = readableDatabase
        val chats = db.rawQuery("SELECT COUNT(*) FROM chats", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        val messages = db.rawQuery("SELECT COUNT(*) FROM messages", null).use { if (it.moveToFirst()) it.getInt(0) else 0 }
        return StorageStats(chats, messages)
    }

    fun clearAll() {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("messages", null, null)
            db.delete("chats", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun deleteMessage(chatId: Long, id: Long) {
        writableDatabase.delete("messages", "chat_id=? AND id=?", arrayOf(chatId.toString(), id.toString()))
    }

    fun deleteChat(chatId: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("messages", "chat_id=?", arrayOf(chatId.toString()))
            db.delete("chats", "id=?", arrayOf(chatId.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }
}
