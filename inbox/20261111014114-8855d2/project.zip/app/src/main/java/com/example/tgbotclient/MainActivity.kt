package com.example.tgbotclient

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle

class MainActivity : ComponentActivity() {

    private val requestNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    /** Chat requested by a notification tap; consumed by the UI. */
    private val openChatRequest = mutableStateOf<Long?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // re-enqueue the background sync after an app update / reinstall (idempotent)
        if (Mode.isCloud(this) && CloudSync.isConfigured(this)) CloudSync.schedule(applicationContext)
        enableEdgeToEdge()

        val prefs = Prefs.of(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !prefs.getBoolean("notif_asked", false) &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            prefs.edit().putBoolean("notif_asked", true).apply()
            requestNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        // on recreation (rotation, process restore) the saved navigation state wins over the old intent
        if (savedInstanceState == null) openChatRequest.value = chatFrom(intent)

        setContent {
            AppRoot(
                openChatRequest = openChatRequest.value,
                onOpenChatConsumed = { openChatRequest.value = null },
                onDarkTheme = { dark -> applySystemBars(dark) }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        chatFrom(intent)?.let { openChatRequest.value = it }
    }

    // group chat ids are negative, so don't test for > 0
    private fun chatFrom(intent: Intent?): Long? =
        if (intent?.hasExtra("open_chat") == true) intent.getLongExtra("open_chat", 0L) else null

    private fun applySystemBars(dark: Boolean) {
        // headers are always a dark-blue gradient → light status bar icons
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = if (dark) SystemBarStyle.dark(AndroidColor.TRANSPARENT)
            else SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
    }
}

val TgBlue = Color(0xFF2AABEE)

@Composable
fun AppTheme(mode: String, onDarkTheme: (Boolean) -> Unit = {}, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    LaunchedEffect(dark) { onDarkTheme(dark) }
    val scheme = if (dark) darkColorScheme(
        primary = TgBlue, onPrimary = Color.White,
        primaryContainer = Color(0xFF1E5F8A), onPrimaryContainer = Color.White,
        secondaryContainer = Color(0xFF2B5278), onSecondaryContainer = Color.White,
        background = Color(0xFF0E1621), onBackground = Color(0xFFE9EEF3),
        surface = Color(0xFF17212B), onSurface = Color(0xFFE9EEF3),
        surfaceVariant = Color(0xFF223140), onSurfaceVariant = Color(0xFFAEBBC8),
        outline = Color(0xFF3A4B5C), outlineVariant = Color(0xFF2A3947),
        error = Color(0xFFFF6B6B), errorContainer = Color(0xFF4A2026), onErrorContainer = Color(0xFFFFDADA)
    ) else lightColorScheme(
        primary = Color(0xFF1C93E3), onPrimary = Color.White,
        primaryContainer = Color(0xFFD2ECFB), onPrimaryContainer = Color(0xFF07324D),
        secondaryContainer = Color(0xFFE1F1FC), onSecondaryContainer = Color(0xFF0B3A57),
        background = Color(0xFFF1F5F9), onBackground = Color(0xFF15202B),
        surface = Color.White, onSurface = Color(0xFF15202B),
        surfaceVariant = Color(0xFFE8EEF3), onSurfaceVariant = Color(0xFF52606D),
        outline = Color(0xFFC4CED8), outlineVariant = Color(0xFFDDE4EA),
        error = Color(0xFFD93B3B), errorContainer = Color(0xFFFDE2E2), onErrorContainer = Color(0xFF5C1111)
    )
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}

private const val SCREEN_CHATS = "chats"
private const val SCREEN_CHAT = "chat"
private const val SCREEN_SETTINGS = "settings"

private fun depth(screen: String) = if (screen == SCREEN_CHATS) 0 else 1

@Composable
fun AppRoot(
    openChatRequest: Long? = null,
    onOpenChatConsumed: () -> Unit = {},
    onDarkTheme: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current
    val prefs = remember { Prefs.of(context) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    var screen by rememberSaveable { mutableStateOf(SCREEN_CHATS) }
    var selectedChat by rememberSaveable { mutableStateOf<Long?>(null) }
    val refresh by MessageBus.changes.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(openChatRequest) {
        if (openChatRequest != null) {
            selectedChat = openChatRequest
            screen = SCREEN_CHAT
            onOpenChatConsumed()
        }
    }
    BackHandler(enabled = screen != SCREEN_CHATS) { screen = SCREEN_CHATS }

    // cloud mode: refresh from Telegram Serverless while the app is on screen (WorkManager covers the closed app)
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            while (true) {
                if (Mode.isCloud(context) && CloudSync.isConfigured(context)) {
                    CloudSync.sync(context.applicationContext)
                }
                delay(12_000)
            }
        }
    }

    val showMessage: (String) -> Unit = remember {
        { text ->
            scope.launch {
                snackbar.currentSnackbarData?.dismiss()
                snackbar.showSnackbar(text, withDismissAction = true, duration = SnackbarDuration.Short)
            }
        }
    }

    AppTheme(theme, onDarkTheme) {
        CompositionLocalProvider(LocalShowMessage provides showMessage) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Box(Modifier.fillMaxSize()) {
                    AnimatedContent(
                        targetState = screen,
                        transitionSpec = {
                            val forward = depth(targetState) >= depth(initialState)
                            val enterDur = Motion.MEDIUM
                            if (forward) {
                                (slideInHorizontally(tween(enterDur, easing = Motion.EmphasizedDecelerate)) { it / 3 } +
                                    fadeIn(tween(enterDur / 2, delayMillis = 60))) togetherWith
                                    (slideOutHorizontally(tween(enterDur, easing = Motion.EmphasizedAccelerate)) { -it / 8 } +
                                        fadeOut(tween(enterDur / 2)) + scaleOut(tween(enterDur), targetScale = 0.97f))
                            } else {
                                (slideInHorizontally(tween(enterDur, easing = Motion.EmphasizedDecelerate)) { -it / 8 } +
                                    fadeIn(tween(enterDur / 2)) + scaleIn(tween(enterDur), initialScale = 0.97f)) togetherWith
                                    (slideOutHorizontally(tween(enterDur, easing = Motion.EmphasizedAccelerate)) { it / 3 } +
                                        fadeOut(tween(enterDur / 2)))
                            }
                        },
                        label = "screen"
                    ) { s ->
                        val chatId = selectedChat
                        when {
                            s == SCREEN_SETTINGS -> SettingsScreen(
                                onBack = { screen = SCREEN_CHATS },
                                onStart = { screen = SCREEN_CHATS },
                                theme = theme,
                                onTheme = { theme = it; prefs.edit().putString("theme", it).apply() }
                            )
                            s == SCREEN_CHAT && chatId != null ->
                                ChatScreen(chatId = chatId, onBack = { screen = SCREEN_CHATS }, refresh = refresh)
                            else -> ChatsScreen(
                                refresh = refresh,
                                onOpenChat = { id -> selectedChat = id; screen = SCREEN_CHAT },
                                onSettings = { screen = SCREEN_SETTINGS }
                            )
                        }
                    }

                    SnackbarHost(
                        hostState = snackbar,
                        modifier = Modifier.align(Alignment.BottomCenter)
                            .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                            .padding(start = 12.dp, end = 12.dp, bottom = if (screen == SCREEN_CHAT) 72.dp else 12.dp)
                    ) { data ->
                        Snackbar(
                            data,
                            shape = RoundedCornerShape(14.dp),
                            containerColor = MaterialTheme.colorScheme.inverseSurface,
                            contentColor = MaterialTheme.colorScheme.inverseOnSurface
                        )
                    }
                }
            }
        }
    }
}
