package com.example.tgbotclient

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- motion tokens (Material 3 emphasized easing) ----------

object Motion {
    val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)
    val EmphasizedAccelerate = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)
    val Standard = CubicBezierEasing(0.2f, 0f, 0f, 1f)
    const val SHORT = 180
    const val MEDIUM = 340
    const val LONG = 500
}

/** Shows a snackbar from any screen. */
val LocalShowMessage = staticCompositionLocalOf<(String) -> Unit> { {} }

// ---------- time helpers ----------

fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

fun listTime(t: Long): String {
    val now = System.currentTimeMillis()
    val pattern = when {
        sameDay(t, now) -> "HH:mm"
        Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.YEAR) ==
            Calendar.getInstance().get(Calendar.YEAR) -> "d MMM"
        else -> "dd.MM.yy"
    }
    return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(t))
}

fun clockTime(t: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(t))

fun chatTypeLabel(type: String): String = when (type) {
    "group", "supergroup" -> "группа"
    "channel" -> "канал"
    "private" -> "личный чат"
    else -> type
}

// ---------- status ----------

@Composable
fun rememberBotStatus(): State<BotStatus> = MessageBus.status.collectAsStateWithLifecycle()

fun statusText(s: BotStatus): String = when (s.state) {
    BotState.RUNNING -> "на связи"
    BotState.STARTING -> "подключение…"
    BotState.RETRYING -> "переподключение…"
    BotState.ERROR -> "ошибка"
    BotState.STOPPED -> "остановлен"
}

@Composable
fun statusColor(state: BotState): Color = when (state) {
    BotState.RUNNING -> Color(0xFF4CD964)
    BotState.STARTING, BotState.RETRYING -> Color(0xFFFFC94D)
    BotState.ERROR -> Color(0xFFFF6B6B)
    BotState.STOPPED -> Color(0xFFB0B7BD)
}

@Composable
fun StatusDot(state: BotState, size: Dp = 10.dp) {
    val color by animateColorAsState(statusColor(state), tween(Motion.MEDIUM), label = "dotColor")
    val active = state == BotState.RUNNING || state == BotState.STARTING || state == BotState.RETRYING
    Box(Modifier.size(size * 2), contentAlignment = Alignment.Center) {
        if (active) {
            // the infinite transition exists only while the bot is active: no idle animation cost
            val t = rememberInfiniteTransition(label = "pulse")
            val p by t.animateFloat(
                initialValue = 0f, targetValue = 1f,
                animationSpec = infiniteRepeatable(tween(1400, easing = Motion.Standard), RepeatMode.Restart),
                label = "pulseProgress"
            )
            Box(
                Modifier.size(size * 2).drawBehind {
                    drawCircle(color.copy(alpha = 0.45f * (1f - p)), radius = this.size.minDimension / 2 * (0.5f + 0.5f * p))
                }
            )
        }
        Box(Modifier.size(size).clip(CircleShape).background(color))
    }
}

/** Status line with vertical "ticker" animation when the text changes. */
@Composable
fun AnimatedStatusText(text: String, color: Color, style: androidx.compose.ui.text.TextStyle) {
    AnimatedContent(
        targetState = text,
        transitionSpec = {
            (slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 2 } + fadeIn(tween(Motion.SHORT))) togetherWith
                (slideOutVertically(tween(Motion.SHORT)) { -it / 2 } + fadeOut(tween(Motion.SHORT)))
        },
        label = "statusText"
    ) { Text(it, style = style, color = color, maxLines = 1) }
}

// ---------- small components ----------

private val avatarPalette = listOf(
    0xFFE17076 to 0xFFF09A9F, 0xFF7BC862 to 0xFFA0DE7E, 0xFFE5CA77 to 0xFFF2DD95, 0xFF65AADD to 0xFF8CC8F2,
    0xFFA695E7 to 0xFFC2B5F5, 0xFFEE7AAE to 0xFFF5A2C7, 0xFF6EC9CB to 0xFF94DEDF, 0xFFFAA774 to 0xFFFCC39C
)

@Composable
fun Avatar(name: String, size: Dp = 48.dp, key: Long? = null) {
    val seed = key?.hashCode() ?: name.hashCode()
    val (a, b) = avatarPalette[(seed and 0x7fffffff) % avatarPalette.size]
    val brush = remember(a, b) { Brush.linearGradient(listOf(Color(b), Color(a))) }
    val letters = remember(name) {
        name.trim().split(' ', '_').filter { it.isNotBlank() }.take(2)
            .joinToString("") { it.take(1) }.uppercase().ifEmpty { "?" }
    }
    Box(
        Modifier.size(size).clip(CircleShape).background(brush).clearAndSetSemantics { },
        contentAlignment = Alignment.Center
    ) {
        Text(letters, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.38f).sp)
    }
}

@Composable
fun GradientHeader(content: @Composable RowScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val start by animateColorAsState(if (dark) Color(0xFF1F4466) else Color(0xFF2AABEE), tween(Motion.LONG), label = "hdrStart")
    val end by animateColorAsState(if (dark) Color(0xFF17212B) else Color(0xFF1782C4), tween(Motion.LONG), label = "hdrEnd")
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Row(
            Modifier.fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(start, end)))
                .statusBarsPadding()
                .displayCutoutPadding()
                .heightIn(min = 64.dp)
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
fun HeaderIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Icon(icon, contentDescription = description, tint = Color.White)
    }
}

@Composable
fun SectionCard(
    title: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            Modifier.padding(16.dp).animateContentSize(spring(stiffness = Spring.StiffnessMediumLow)),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    title, style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
                )
            }
            content()
        }
    }
}

/** Unread counter that pops in/out and bumps when the number changes. */
@Composable
fun UnreadBadge(count: Int) {
    androidx.compose.animation.AnimatedVisibility(
        visible = count > 0,
        enter = scaleIn(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)) + fadeIn(),
        exit = scaleOut(tween(Motion.SHORT)) + fadeOut(tween(Motion.SHORT))
    ) {
        var last by remember { mutableIntStateOf(count) }
        if (count > 0) last = count
        Box(
            Modifier.heightIn(min = 22.dp).widthIn(min = 22.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary).padding(horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            AnimatedContent(
                targetState = last,
                transitionSpec = {
                    (slideInVertically { it } + fadeIn()) togetherWith (slideOutVertically { -it } + fadeOut())
                },
                label = "unread"
            ) { n ->
                Text(
                    if (n > 999) "999+" else n.toString(),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun InfoBanner(text: String, isError: Boolean, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (isError) cs.errorContainer else cs.secondaryContainer, label = "bannerBg")
    val fg by animateColorAsState(if (isError) cs.onErrorContainer else cs.onSecondaryContainer, label = "bannerFg")
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(16.dp)).background(bg)
            .padding(start = 14.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
            .heightIn(min = 44.dp)
            .semantics(mergeDescendants = true) { },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = fg, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(vertical = 6.dp))
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) { Text(actionLabel, color = fg, fontWeight = FontWeight.Bold) }
        }
    }
}
