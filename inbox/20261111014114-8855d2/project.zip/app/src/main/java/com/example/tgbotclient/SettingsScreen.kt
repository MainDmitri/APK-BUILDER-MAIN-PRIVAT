package com.example.tgbotclient

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed interface CheckState {
    data object Idle : CheckState
    data object Checking : CheckState
    data class Ok(val info: BotInfo) : CheckState
    data class Failed(val message: String) : CheckState
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onStart: () -> Unit, theme: String, onTheme: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val status by rememberBotStatus()
    val cs = MaterialTheme.colorScheme
    var token by remember { mutableStateOf(prefs.getString(Prefs.KEY_TOKEN, "").orEmpty()) }
    var showToken by remember { mutableStateOf(false) }
    var notify by remember { mutableStateOf(prefs.getBoolean("notify", true)) }
    var confirmClear by remember { mutableStateOf(false) }
    var check by remember { mutableStateOf<CheckState>(CheckState.Idle) }
    var stats by remember { mutableStateOf<StorageStats?>(null) }
    val refresh by MessageBus.changes.collectAsStateWithLifecycle()

    var mode by remember { mutableStateOf(Mode.get(context)) }
    val cloudMode = mode == Mode.CLOUD
    var confirmMode by remember { mutableStateOf<String?>(null) }

    fun applyMode(target: String) {
        prefs.edit().putString("mode", target).apply()
        mode = target
        if (target == Mode.CLOUD) {
            context.stopService(Intent(context, BotPollingService::class.java))
            MessageBus.setStatus(BotStatus(BotState.STOPPED, "Режим Serverless: опрос getUpdates отключён"))
            if (CloudSync.isConfigured(context)) CloudSync.schedule(context.applicationContext)
        } else {
            CloudSync.cancel(context.applicationContext)
            MessageBus.setStatus(BotStatus(BotState.STOPPED))
        }
        MessageBus.notifyChanged()
    }

    val trimmed = token.trim()
    val formatOk = trimmed.isEmpty() || isTokenFormatValid(trimmed)
    val active = status.state == BotState.RUNNING || status.state == BotState.STARTING || status.state == BotState.RETRYING

    LaunchedEffect(refresh) { stats = withContext(Dispatchers.IO) { Storage.get(context).stats() } }

    var notifGranted by remember { mutableStateOf(true) }
    LifecycleResumeEffect(Unit) {
        notifGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        onPauseOrDispose { }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notifGranted = granted
        if (!granted) {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            }
            try {
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                showMessage("Откройте настройки уведомлений приложения вручную")
            }
        }
    }

    fun checkToken() {
        if (trimmed.isEmpty() || !isTokenFormatValid(trimmed)) return
        check = CheckState.Checking
        scope.launch {
            check = try {
                CheckState.Ok(TelegramApi.getMe(trimmed))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CheckState.Failed(humanError(e))
            }
        }
    }

    fun start() {
        when {
            trimmed.isEmpty() -> showMessage("Укажите токен бота")
            !isTokenFormatValid(trimmed) -> showMessage("Токен выглядит неверно: формат 123456:ABC…")
            else -> {
                if (trimmed != prefs.getString(Prefs.KEY_TOKEN, "")) {
                    prefs.edit().putLong("offset", 0L).remove("bot_name").remove("bot_username").apply()
                }
                prefs.edit().putString(Prefs.KEY_TOKEN, trimmed).apply()
                MessageBus.setStatus(BotStatus(BotState.STARTING))
                try {
                    ContextCompat.startForegroundService(context, Intent(context, BotPollingService::class.java))
                    onStart()
                } catch (e: Exception) {
                    MessageBus.setStatus(BotStatus(BotState.ERROR, "Не удалось запустить сервис: ${humanError(e)}"))
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            HeaderIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Назад", onBack)
            Spacer(Modifier.width(4.dp))
            Text("Настройки", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StaggeredSection(0) {
                SectionCard("Получение сообщений", Icons.Filled.Share) {
                    val options = listOf(Mode.CLOUD to "Serverless (Облако)", Mode.LOCAL to "Локально (getUpdates)")
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        options.forEachIndexed { i, (key, label) ->
                            SegmentedButton(
                                selected = mode == key,
                                onClick = { if (mode != key) confirmMode = key },
                                shape = SegmentedButtonDefaults.itemShape(i, options.size)
                            ) { Text(label) }
                        }
                    }
                    AnimatedContent(
                        targetState = cloudMode,
                        transitionSpec = { fadeIn(tween(Motion.MEDIUM)) togetherWith fadeOut(tween(Motion.SHORT)) },
                        label = "modeInfo"
                    ) { cloud ->
                        Text(
                            if (cloud) "Telegram Serverless принимает сообщения 24/7 даже при выключенном приложении, сохраняет пользователей во встроенную базу данных и сразу отвечает им «Ожидайте, администратор скоро ответит». При входе в приложение всё подгружается автоматически."
                            else "Сообщения принимает само приложение (getUpdates), пока бот запущен на телефоне. При закрытом приложении сообщения не поступают.",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    }
                    AnimatedVisibility(
                        visible = cloudMode,
                        enter = expandVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) + fadeIn(),
                        exit = shrinkVertically(tween(Motion.SHORT)) + fadeOut()
                    ) {
                        CloudPanel()
                    }
                }
            }

            StaggeredSection(1) {
                SectionCard("Бот", Icons.Filled.Lock) {
                    if (!cloudMode) StatusPanel(status)

                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it.replace("\n", ""); check = CheckState.Idle },
                        label = { Text("Токен бота") },
                        placeholder = { Text("123456789:AA…") },
                        singleLine = true,
                        isError = !formatOk,
                        supportingText = {
                            Text(
                                if (!formatOk) "Формат: цифры, двоеточие и ключ из @BotFather"
                                else "Токен нужен для отправки ответов в чаты"
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                        visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        trailingIcon = {
                            TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Скрыть" else "Показать") }
                        },
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                    )

                    AnimatedContent(
                        targetState = check,
                        transitionSpec = {
                            (fadeIn(tween(Motion.MEDIUM)) + slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 3 }) togetherWith
                                fadeOut(tween(Motion.SHORT))
                        },
                        label = "check"
                    ) { c ->
                        when (c) {
                            CheckState.Idle -> Spacer(Modifier.height(0.dp))
                            CheckState.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Проверяю токен…", style = MaterialTheme.typography.bodyMedium)
                            }
                            is CheckState.Ok -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, null, tint = statusColor(BotState.RUNNING))
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "${c.info.firstName}" + if (c.info.username.isNotBlank()) " · @${c.info.username}" else "",
                                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                                )
                            }
                            is CheckState.Failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warning, null, tint = cs.error)
                                Spacer(Modifier.width(10.dp))
                                Text(c.message, color = cs.error, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (cloudMode) {
                        FilledTonalButton(
                            onClick = {
                                prefs.edit().putString(Prefs.KEY_TOKEN, trimmed).apply()
                                checkToken()
                            },
                            shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk && check != CheckState.Checking
                        ) { Text("Сохранить и проверить токен") }
                    } else Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { start() }, shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(if (active) Icons.Filled.Refresh else Icons.Filled.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (active) "Перезапустить" else "Старт")
                        }
                        OutlinedButton(
                            enabled = active, shape = RoundedCornerShape(14.dp),
                            onClick = { context.stopService(Intent(context, BotPollingService::class.java)) }
                        ) { Text("Стоп") }
                        FilledTonalButton(
                            onClick = { checkToken() }, shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk && check != CheckState.Checking
                        ) { Text("Проверить") }
                    }
                }
            }

            StaggeredSection(2) {
                SectionCard("Автоответ пользователям", Icons.Filled.Star) {
                    var autoReplyEnabled by remember {
                        mutableStateOf(prefs.getBoolean(Prefs.KEY_AUTO_REPLY_ENABLED, true))
                    }
                    var autoReplyText by remember {
                        mutableStateOf(prefs.getString(Prefs.KEY_AUTO_REPLY_TEXT, Prefs.DEFAULT_AUTO_REPLY) ?: Prefs.DEFAULT_AUTO_REPLY)
                    }

                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Автоматический ответ", fontWeight = FontWeight.Medium)
                            Text(
                                "Отправляется каждому, кто пишет в бота",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = autoReplyEnabled,
                            onCheckedChange = {
                                autoReplyEnabled = it
                                prefs.edit().putBoolean(Prefs.KEY_AUTO_REPLY_ENABLED, it).apply()
                            }
                        )
                    }

                    if (autoReplyEnabled) {
                        OutlinedTextField(
                            value = autoReplyText,
                            onValueChange = {
                                autoReplyText = it
                                prefs.edit().putString(Prefs.KEY_AUTO_REPLY_TEXT, it).apply()
                            },
                            label = { Text("Текст автоответа") },
                            placeholder = { Text("Ожидайте, администратор скоро ответит") },
                            supportingText = { Text("По умолчанию: «Ожидайте, администратор скоро ответит»") },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            StaggeredSection(3) {
                SectionCard("Оформление", Icons.Filled.Star) {
                    val options = listOf("system" to "Авто", "light" to "Светлая", "dark" to "Тёмная")
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        options.forEachIndexed { i, (key, label) ->
                            SegmentedButton(
                                selected = theme == key,
                                onClick = { onTheme(key) },
                                shape = SegmentedButtonDefaults.itemShape(i, options.size)
                            ) { Text(label) }
                        }
                    }
                }
            }

            StaggeredSection(4) {
                SectionCard("Уведомления", Icons.Filled.Notifications) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Уведомления о сообщениях")
                            Text(
                                "Не показываются для открытого чата",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = notify, onCheckedChange = { notify = it; prefs.edit().putBoolean("notify", it).apply() })
                    }
                    AnimatedVisibility(
                        visible = notify && !notifGranted,
                        enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
                    ) {
                        InfoBanner(
                            "Android запрещает приложению показывать уведомления",
                            isError = true, actionLabel = "Разрешить",
                            onAction = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        )
                    }
                }
            }

            StaggeredSection(5) {
                SectionCard("Данные", Icons.Filled.Delete) {
                    Text(
                        stats?.let { "На устройстве: чатов ${it.chats}, сообщений ${it.messages}" } ?: "Подсчёт…",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(
                        onClick = { confirmClear = true }, shape = RoundedCornerShape(14.dp),
                        enabled = (stats?.chats ?: 0) > 0,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)
                    ) { Text("Очистить историю") }
                }
            }

            StaggeredSection(6) {
                SectionCard("О приложении", Icons.Filled.Info) {
                    val version = remember {
                        try {
                            context.packageManager.getPackageInfo(context.packageName, 0).versionName
                        } catch (_: Exception) { null }
                    }
                    Text("TG Bot Client Pro ${version.orEmpty()}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Поддержка Telegram Serverless и встроенного локального опроса.",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                    )
                    TextButton(
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/BotFather")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (_: Exception) {
                                showMessage("Нет приложения для открытия ссылки")
                            }
                        },
                        contentPadding = PaddingValues(0.dp)
                    ) { Text("Открыть @BotFather") }
                }
            }
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }
    }

    confirmMode?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmMode = null },
            icon = { Icon(Icons.Filled.Share, null) },
            title = { Text(if (target == Mode.CLOUD) "Перейти в режим Serverless?" else "Вернуться к локальному режиму?") },
            text = {
                Text(
                    if (target == Mode.CLOUD)
                        "Telegram Serverless принимает сообщения в облаке 24/7 без необходимости держать приложение запущенным. Приложение будет загружать историю сообщений из облачной базы данных."
                    else
                        "Фоновая синхронизация с облаком будет отключена. Приложение будет опрашивать Telegram напрямую через getUpdates, пока открыто."
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmMode = null; applyMode(target) }) { Text("Переключить") }
            },
            dismissButton = { TextButton(onClick = { confirmMode = null }) { Text("Отмена") } }
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            icon = { Icon(Icons.Filled.Delete, null) },
            title = { Text("Очистить историю?") },
            text = { Text("Все чаты, сообщения и черновики будут удалены с этого устройства. В Telegram ничего не изменится.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        withContext(Dispatchers.IO) { Storage.get(context).clearAll() }
                        CloudSync.resetCursor(context)
                        val editor = prefs.edit()
                        prefs.all.keys.filter { it.startsWith("draft_") }.forEach { editor.remove(it) }
                        editor.apply()
                        MessageBus.notifyChanged()
                        showMessage("История очищена")
                    }
                }) { Text("Очистить", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun StatusPanel(status: BotStatus) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        when (status.state) {
            BotState.ERROR -> cs.errorContainer
            BotState.RUNNING -> statusColor(BotState.RUNNING).copy(alpha = 0.14f)
            else -> cs.surfaceVariant
        },
        tween(Motion.MEDIUM), label = "statusBg"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusDot(status.state)
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            AnimatedStatusText(
                "Бот " + statusText(status),
                cs.onSurface, MaterialTheme.typography.titleSmall
            )
            AnimatedVisibility(
                visible = status.message.isNotBlank() && status.state != BotState.RUNNING,
                enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
            ) {
                Text(status.message, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun StaggeredSection(index: Int, content: @Composable () -> Unit) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    androidx.compose.animation.AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(Motion.MEDIUM, delayMillis = 60 + index * 50)) +
            slideInVertically(tween(Motion.LONG, delayMillis = 60 + index * 50, easing = Motion.EmphasizedDecelerate)) { it / 4 }
    ) { content() }
}

private sealed interface BridgeCheck {
    data object Idle : BridgeCheck
    data object Checking : BridgeCheck
    data class Ok(val status: BridgeStatus) : BridgeCheck
    data class Failed(val message: String) : BridgeCheck
}

/** Telegram Serverless CLI token and connection panel. */
@Composable
private fun CloudPanel() {
    val context = LocalContext.current
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val cs = MaterialTheme.colorScheme
    val cloud by CloudSync.state.collectAsStateWithLifecycle()

    var serverlessToken by remember { mutableStateOf(prefs.getString(Prefs.KEY_SERVERLESS_TOKEN, "").orEmpty()) }
    var customUrl by remember { mutableStateOf(prefs.getString(Prefs.KEY_BRIDGE_URL, "").orEmpty()) }
    var showToken by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var check by remember { mutableStateOf<BridgeCheck>(BridgeCheck.Idle) }

    val tokenTrim = serverlessToken.trim()
    val (autoUrl, _) = remember(tokenTrim) { parseServerlessCliToken(tokenTrim) }
    val effectiveUrl = if (customUrl.trim().isNotEmpty()) customUrl.trim().trimEnd('/') else autoUrl

    val tokenOk = tokenTrim.isNotEmpty() && isServerlessTokenValid(tokenTrim)
    val ready = tokenOk && effectiveUrl.isNotEmpty()

    fun save() {
        val oldUrl = prefs.getString(Prefs.KEY_BRIDGE_URL, "").orEmpty()
        val edit = prefs.edit()
            .putString(Prefs.KEY_SERVERLESS_TOKEN, tokenTrim)
            .putString(Prefs.KEY_BRIDGE_URL, customUrl.trim())
            .putString(Prefs.KEY_BRIDGE_KEY, tokenTrim)

        if (oldUrl.trimEnd('/') != effectiveUrl) edit.putLong("sync_cursor", 0L)
        edit.apply()
        CloudSync.schedule(context.applicationContext)
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = serverlessToken,
            onValueChange = {
                serverlessToken = it.replace("\n", "").trim()
                check = BridgeCheck.Idle
            },
            label = { Text("Serverless CLI токен") },
            placeholder = { Text("app12345:abc123def456…") },
            singleLine = true,
            isError = serverlessToken.isNotEmpty() && !tokenOk,
            supportingText = {
                Text(
                    if (serverlessToken.isNotEmpty() && !tokenOk) "Токен должен начинаться с app (например app12345:secret)"
                    else "Скопируйте в @BotFather: выберите бота → Serverless → CLI Access"
                )
            },
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
            visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            trailingIcon = {
                TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Скрыть" else "Показать") }
            },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )

        if (effectiveUrl.isNotEmpty()) {
            Surface(
                color = cs.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Share, null, tint = cs.primary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Сервер: $effectiveUrl",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = { showHelp = !showHelp },
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (showHelp) "Скрыть инструкцию" else "Инструкция по настройке Serverless")
            }
            TextButton(
                onClick = { showAdvanced = !showAdvanced },
                contentPadding = PaddingValues(0.dp)
            ) {
                Text(if (showAdvanced) "Скрыть адрес" else "Свой URL")
            }
        }

        AnimatedVisibility(visible = showHelp) {
            Surface(
                color = cs.secondaryContainer.copy(alpha = 0.6f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Как настроить Telegram Serverless:", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text("1. Откройте @BotFather → выберите бота → Serverless → включите Serverless.", style = MaterialTheme.typography.bodySmall)
                    Text("2. Нажмите CLI Access, скопируйте токен (вида app12345:secret) и вставьте его в поле выше.", style = MaterialTheme.typography.bodySmall)
                    Text("3. В папке serverless проекта запустите ./deploy.sh (или npx tgcloud push && npx tgcloud migrate).", style = MaterialTheme.typography.bodySmall)
                    Text("4. Нажмите «Сохранить и подключиться». Бот будет автоматически сохранять сообщения в облачную базу данных и отвечать «Ожидайте, администратор скоро ответит»!", style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        AnimatedVisibility(visible = showAdvanced) {
            OutlinedTextField(
                value = customUrl,
                onValueChange = { customUrl = it.replace("\n", ""); check = BridgeCheck.Idle },
                label = { Text("Пользовательский адрес (URL)") },
                placeholder = { Text("https://app12345.tgcloud.ai") },
                singleLine = true,
                supportingText = { Text("Необязательно. По умолчанию генерируется автоматически из токена.") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        AnimatedContent(
            targetState = check,
            transitionSpec = {
                (fadeIn(tween(Motion.MEDIUM)) + slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 3 }) togetherWith
                    fadeOut(tween(Motion.SHORT))
            },
            label = "bridgeCheck"
        ) { c ->
            when (c) {
                BridgeCheck.Idle -> Spacer(Modifier.height(0.dp))
                BridgeCheck.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Подключаюсь к Telegram Serverless…", style = MaterialTheme.typography.bodyMedium)
                }
                is BridgeCheck.Ok -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Filled.CheckCircle, null,
                        tint = statusColor(BotState.RUNNING)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Serverless на связи · чатов ${c.status.chats}, сообщений ${c.status.messages}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is BridgeCheck.Failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null, tint = cs.error)
                    Spacer(Modifier.width(10.dp))
                    Text(c.message, color = cs.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = ready && check != BridgeCheck.Checking && !cloud.syncing,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f),
                onClick = {
                    save()
                    check = BridgeCheck.Checking
                    scope.launch {
                        check = try {
                            BridgeCheck.Ok(CloudSync.status(context.applicationContext))
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            BridgeCheck.Failed(CloudSync.humanBridgeError(e))
                        }
                        if (check is BridgeCheck.Ok) {
                            val n = CloudSync.sync(context.applicationContext)
                            CloudSync.state.value.error?.let { showMessage(it) }
                                ?: showMessage("Синхронизировано с Serverless, новых: $n")
                        }
                    }
                }
            ) {
                if (cloud.syncing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                else Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Сохранить и подключиться")
            }
        }

        AnimatedVisibility(
            visible = cloud.error != null && check !is BridgeCheck.Failed,
            enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
        ) {
            InfoBanner("Последняя синхронизация: ${cloud.error.orEmpty()}", isError = true)
        }
    }
}
