package com.example.tgbotclient

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/** Message notifications shared by the local polling service and the cloud sync worker. */
object Notifier {
    const val CHANNEL_MESSAGES = "bot_channel"   // same id as in 1.2: user settings survive the update

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_MESSAGES, "Сообщения бота", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }

    fun showMessage(context: Context, from: String, text: String, chatId: Long) {
        if (!Prefs.of(context).getBoolean("notify", true)) return
        if (MessageBus.openChatId == chatId) return
        ensureChannel(context)
        val notifId = chatNotificationId(chatId)
        val openIntent = PendingIntent.getActivity(
            context, notifId,
            Intent(context, MainActivity::class.java)
                .putExtra("open_chat", chatId)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(context, CHANNEL_MESSAGES)
            .setContentTitle(from)
            .setContentText(text.take(120))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text.take(600)))
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentIntent(openIntent)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .build()
        try {
            context.getSystemService(NotificationManager::class.java).notify(notifId, n)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted
        }
    }
}
