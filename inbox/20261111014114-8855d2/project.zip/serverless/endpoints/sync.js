import { getSyncData, verifyAuth } from '../lib/database.js';

export default async function (ctx) {
  if (!verifyAuth(ctx)) {
    return { ok: false, error: 'Unauthorized: invalid serverless CLI token' };
  }

  const query = ctx.query || {};
  const body = ctx.body || {};
  const since = Number(query.since || body.since || 0);
  const limit = Math.min(Number(query.limit || body.limit || 200), 500);

  const result = await getSyncData(since, limit);

  return {
    ok: true,
    chats: result.chats,
    messages: result.messages,
    next: result.nextCursor,
    has_more: result.hasMore
  };
}
