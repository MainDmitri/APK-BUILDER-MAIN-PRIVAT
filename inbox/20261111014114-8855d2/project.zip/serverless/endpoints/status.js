import { getStats, verifyAuth } from '../lib/database.js';

export default async function (ctx) {
  if (!verifyAuth(ctx)) {
    return { ok: false, error: 'Unauthorized: invalid serverless CLI token' };
  }

  const stats = await getStats();
  return {
    ok: true,
    paired: true,
    serverless: true,
    chats: stats.chats,
    messages: stats.messages
  };
}
