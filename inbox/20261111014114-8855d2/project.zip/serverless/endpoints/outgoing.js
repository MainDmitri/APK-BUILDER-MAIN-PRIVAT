import { recordOutgoing, verifyAuth } from '../lib/database.js';

export default async function (ctx) {
  if (!verifyAuth(ctx)) {
    return { ok: false, error: 'Unauthorized: invalid serverless CLI token' };
  }

  const payload = ctx.body || ctx;
  await recordOutgoing(payload);

  return { ok: true };
}
