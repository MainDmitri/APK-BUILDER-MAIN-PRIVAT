#!/usr/bin/env bash
# Deploy script for Telegram Serverless
# Usage: ./deploy.sh [CLI_TOKEN]

set -e

TOKEN="$1"
if [ -z "$TOKEN" ]; then
  echo "Укажите CLI токен от @BotFather (Serverless -> CLI Access)"
  echo "Пример: ./deploy.sh app12345:abc123def456..."
  read -p "Введите CLI Access Token: " TOKEN
fi

if [ -z "$TOKEN" ]; then
  echo "Ошибка: токен не указан."
  exit 1
fi

echo "==> Авторизация в tgcloud..."
npx --yes @tgcloud/cli login "$TOKEN" || npx --yes tgcloud login

echo "==> Загрузка обработчиков и эндпоинтов на серверы Telegram..."
npx --yes @tgcloud/cli push || npx --yes tgcloud push

echo "==> Применение структуры базы данных SQLite..."
npx --yes @tgcloud/cli migrate || npx --yes tgcloud migrate

echo "==> Проверка статуса..."
npx --yes @tgcloud/cli status || npx --yes tgcloud status

echo "✅ Бот успешно развёрнут в Telegram Serverless!"
echo "Теперь вставьте этот же CLI токен в приложении TG Bot Client Pro в разделе Настройки -> Telegram Serverless."
