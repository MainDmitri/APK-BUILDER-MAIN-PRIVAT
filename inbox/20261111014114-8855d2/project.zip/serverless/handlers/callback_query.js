import { saveMessage } from '../lib/database.js';

let tgApi;
try {
  const sdk = await import('sdk');
  tgApi = sdk.api;
} catch (_) {
  tgApi = { answerCallbackQuery: async () => ({}) };
}

export default async function (event) {
  const cb = event.callback_query || event;
  if (!cb) return;

  const data = cb.data || '';
  const from = cb.from || {};
  const fromName = [from.first_name, from.last_name].filter(Boolean).join(' ') || from.username || 'Пользователь';
  const msg = cb.message;

  if (msg && msg.chat) {
    const chatId = Number(msg.chat.id);
    const now = Date.now();
    const chatTitle = msg.chat.title || fromName || `Чат ${chatId}`;
    const text = `[Кнопка] ${fromName} нажал: ${data}`;

    await saveMessage({
      id: now,
      chat_id: chatId,
      from_name: fromName,
      text: text,
      time: now,
      is_bot: 0,
      reply_to: null,
      media_type: null,
      chat_title: chatTitle,
      chat_type: msg.chat.type || 'private'
    });
  }

  // Answer callback query so button stops spinning
  if (cb.id) {
    try {
      await tgApi.answerCallbackQuery({ callback_query_id: cb.id });
    } catch (_) {}
  }
}
