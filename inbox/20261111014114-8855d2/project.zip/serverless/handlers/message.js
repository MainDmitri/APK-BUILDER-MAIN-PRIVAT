import { saveMessage, getAutoReplyText } from '../lib/database.js';

let tgApi;
try {
  const sdk = await import('sdk');
  tgApi = sdk.api;
} catch (_) {
  // Fallback for standalone / outside tgcloud
  tgApi = {
    sendMessage: async ({ chat_id, text, reply_parameters }) => {
      console.log(`[AutoReply to ${chat_id}]: ${text}`);
      return { message_id: Date.now() };
    }
  };
}

export default async function (event) {
  const message = event.message || event.edited_message || event;
  if (!message || !message.chat) return;

  const chatId = Number(message.chat.id);
  const msgId = Number(message.message_id);
  const time = (Number(message.date) || Math.floor(Date.now() / 1000)) * 1000;
  const isEdited = Boolean(event.edited_message);

  const from = message.from || {};
  const fromName = [from.first_name, from.last_name].filter(Boolean).join(' ') ||
    from.username || `User ${from.id || chatId}`;
  const chatTitle = message.chat.title || fromName || `Чат ${chatId}`;
  const chatType = message.chat.type || 'private';

  // Format text/media label
  let text = message.text || message.caption || '';
  let mediaType = null;
  if (!text) {
    if (message.photo) { text = '[Фото]'; mediaType = 'photo'; }
    else if (message.voice) { text = '[Голосовое]'; mediaType = 'voice'; }
    else if (message.video) { text = '[Видео]'; mediaType = 'video'; }
    else if (message.document) { text = `[Документ: ${message.document.file_name || 'файл'}]`; mediaType = 'document'; }
    else if (message.sticker) { text = `[Стикер ${message.sticker.emoji || ''}]`.trim(); mediaType = 'sticker'; }
    else if (message.location) { text = '[Геолокация]'; mediaType = 'location'; }
    else if (message.contact) { text = '[Контакт]'; mediaType = 'contact'; }
    else { text = '[Сообщение]'; }
  }

  const replyTo = message.reply_to_message ? Number(message.reply_to_message.message_id) : null;

  // 1. Save user's incoming message to the database
  await saveMessage({
    id: msgId,
    chat_id: chatId,
    from_name: fromName,
    text: text,
    time: time,
    is_bot: from.is_bot ? 1 : 0,
    reply_to: replyTo,
    media_type: mediaType,
    chat_title: chatTitle,
    chat_type: chatType
  });

  // 2. Automated response: "Ожидайте, администратор скоро ответит"
  // Reply to non-bot users on new incoming messages
  if (!from.is_bot && !isEdited) {
    const replyText = await getAutoReplyText();
    try {
      const sent = await tgApi.sendMessage({
        chat_id: chatId,
        text: replyText,
        reply_parameters: {
          message_id: msgId,
          allow_sending_without_reply: true
        }
      });

      // Save bot's reply message into the database
      const sentId = sent?.message_id || Date.now();
      await saveMessage({
        id: sentId,
        chat_id: chatId,
        from_name: 'Бот',
        text: replyText,
        time: Date.now(),
        is_bot: 1,
        reply_to: msgId,
        media_type: null,
        chat_title: chatTitle,
        chat_type: chatType
      });
    } catch (err) {
      console.error('Error sending auto-reply:', err?.message || err);
    }
  }
}
