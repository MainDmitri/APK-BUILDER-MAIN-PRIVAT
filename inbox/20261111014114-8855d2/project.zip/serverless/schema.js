/**
 * Schema definition for Telegram Serverless SQLite database.
 */
let table, integer, text;
try {
  const sdkDb = await import('sdk/db');
  table = sdkDb.table;
  integer = sdkDb.integer;
  text = sdkDb.text;
} catch (_) {
  // Mock schema DSL when running outside Telegram Serverless runtime
  table = (name, def) => ({ name, def });
  integer = (col) => ({ col, type: 'INTEGER', primaryKey: () => ({ col, type: 'INTEGER', pk: true }), default: (v) => ({ col, default: v }) });
  text = (col) => ({ col, type: 'TEXT', primaryKey: () => ({ col, type: 'TEXT', pk: true }), default: (v) => ({ col, default: v }) });
}

export const chats = table('chats', {
  id: integer('id').primaryKey(),
  title: text('title'),
  type: text('type'),
  last_message: text('last_message'),
  last_time: integer('last_time'),
  unread: integer('unread').default(0)
});

export const messages = table('messages', {
  id: integer('id'),
  chat_id: integer('chat_id'),
  from_name: text('from_name'),
  text: text('text'),
  time: integer('time'),
  is_bot: integer('is_bot').default(0),
  reply_to: integer('reply_to'),
  media_type: text('media_type')
});

export const config = table('config', {
  key: text('key').primaryKey(),
  value: text('value')
});
