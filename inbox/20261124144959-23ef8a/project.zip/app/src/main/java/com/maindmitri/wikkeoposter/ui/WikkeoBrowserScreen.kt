package com.maindmitri.wikkeoposter.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.ProductStatus
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.ImageDownloader
import com.maindmitri.wikkeoposter.network.TelegramClient
import com.maindmitri.wikkeoposter.scraper.WikkeoJsScripts
import com.maindmitri.wikkeoposter.service.AutoScrapeService
import com.maindmitri.wikkeoposter.service.AutoScrapeStateHolder
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

private data class QuickSection(val label: String, val url: String)

private val QUICK_SECTIONS = listOf(
    QuickSection("Новинки", "https://wikkeo.com/new_products"),
    QuickSection("Дропшиппинг", "https://wikkeo.com/dropshipping"),
    QuickSection("Ликвидация", "https://wikkeo.com/liquidation"),
    QuickSection("Главная", "https://wikkeo.com/")
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WikkeoBrowserScreen(
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val batchState by AutoScrapeStateHolder.state.collectAsState()

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf("https://wikkeo.com/new_products") }
    var pageProgress by remember { mutableIntStateOf(0) }
    var canGoBack by remember { mutableStateOf(false) }

    var singleBusy by remember { mutableStateOf(false) }
    var singleStatus by remember { mutableStateOf("") }

    val isProductPage = currentUrl.contains("/item/")
    val isAnyBusy = singleBusy || batchState.running

    BackHandler(enabled = canGoBack) {
        webViewRef?.goBack()
    }

    suspend fun evaluateJs(script: String): String? {
        val wv = webViewRef ?: return null
        val deferred = CompletableDeferred<String?>()
        withContext(Dispatchers.Main) {
            wv.evaluateJavascript(script) { res ->
                deferred.complete(res)
            }
        }
        return withTimeoutOrNull(12_000) { deferred.await() }
    }

    fun startSingleScrape(publishNow: Boolean) {
        if (singleBusy) return
        scope.launch {
            singleBusy = true
            try {
                singleStatus = "Читаю карточку, скачиваю фото и генерирую пост..."
                val rawJson = evaluateJs(WikkeoJsScripts.EXTRACT_PRODUCT_JS)
                val parsed = WikkeoJsScripts.parseExtractedProduct(rawJson)
                if (parsed == null) {
                    onNotify("Не удалось прочитать карточку товара. Дождись полной загрузки страницы.")
                    return@launch
                }

                val finalPrice = settings.calculateFinalPrice(parsed.wholesalePrice)
                val photoLimit = if (settings.singlePhotoWithButton) 1 else settings.maxPhotosPerPost
                val localImgs = ImageDownloader.downloadProductImages(
                    imageUrls = parsed.imageUrls,
                    refererUrl = parsed.url,
                    targetDir = dbHelper.productFolder(parsed.id),
                    maxPhotos = photoLimit
                )

                var product = parsed.copy(
                    finalPrice = finalPrice,
                    localImages = localImgs
                )

                val geminiRes = AiClient.generateTelegramPost(product, settings)
                product = product.copy(
                    generatedPost = geminiRes.postHtml,
                    lastError = if (geminiRes.success) "" else geminiRes.error
                )

                withContext(Dispatchers.IO) { dbHelper.upsert(product) }
                onProductsChanged()

                if (publishNow) {
                    singleStatus = "Публикую в Telegram-канал..."
                    val tgRes = TelegramClient.publishProduct(product, settings)
                    product = if (tgRes.success) {
                        product.copy(
                            status = ProductStatus.PUBLISHED,
                            telegramMessageId = tgRes.messageId,
                            publishedAt = System.currentTimeMillis(),
                            lastError = ""
                        )
                    } else {
                        product.copy(
                            status = ProductStatus.ERROR,
                            lastError = tgRes.error
                        )
                    }
                    withContext(Dispatchers.IO) { dbHelper.upsert(product) }
                    onProductsChanged()
                }

                if (publishNow) {
                    if (product.status == ProductStatus.PUBLISHED) {
                        onNotify("Опубликовано в канал: ${product.title} (${product.localImages.size} фото)")
                    } else {
                        onNotify("Товар сохранён, но ошибка Telegram: ${product.lastError}")
                    }
                } else {
                    onNotify("Сохранено: ${product.title} (${product.localImages.size} фото)")
                }
            } catch (e: Exception) {
                onNotify("Ошибка: ${e.message ?: "неизвестно"}")
            } finally {
                singleBusy = false
                singleStatus = ""
            }
        }
    }

    fun startBackgroundBatchScrape() {
        if (isAnyBusy) return
        scope.launch {
            singleBusy = true
            singleStatus = "Собираю ссылки со страницы для фонового автосбора..."
            try {
                withContext(Dispatchers.Main) {
                    webViewRef?.evaluateJavascript("window.scrollBy(0, 1200);", null)
                }
                delay(450)
                val linksRaw = evaluateJs(WikkeoJsScripts.EXTRACT_CATALOG_LINKS_JS)
                val allLinks = WikkeoJsScripts.parseCatalogLinks(linksRaw)
                val newLinks = withContext(Dispatchers.IO) {
                    allLinks.filter { !dbHelper.existsByUrl(it) }
                }.take(settings.maxProductsPerBatch)

                if (newLinks.isEmpty()) {
                    onNotify(
                        if (allLinks.isEmpty()) "На этой странице не найдено карточек /item/."
                        else "Все товары на странице (${allLinks.size}) уже есть в базе."
                    )
                    return@launch
                }

                AutoScrapeService.start(context, newLinks)
                onNotify("Фоновый автосбор запущен (${newLinks.size} шт.) — можно сворачивать приложение!")
            } catch (e: Exception) {
                onNotify("Ошибка запуска автосбора: ${e.message ?: "неизвестно"}")
            } finally {
                singleBusy = false
                singleStatus = ""
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Navigation & Quick Sections
        Surface(tonalElevation = 2.dp) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { webViewRef?.goBack() },
                        enabled = canGoBack
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                    Text(
                        text = currentUrl.removePrefix("https://"),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { webViewRef?.reload() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Обновить")
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QUICK_SECTIONS.forEach { sec ->
                        val selected = currentUrl.startsWith(sec.url) &&
                            (sec.url != "https://wikkeo.com/" || currentUrl == "https://wikkeo.com/")
                        FilterChip(
                            selected = selected,
                            onClick = { webViewRef?.loadUrl(sec.url) },
                            label = { Text(sec.label) }
                        )
                    }
                }
            }
        }

        if (pageProgress in 1..99) {
            LinearProgressIndicator(
                progress = { pageProgress / 100f },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Active status banner (works across tab switches and app minimize)
        if (batchState.running || singleBusy) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (batchState.running) {
                            batchState.statusText.ifBlank { "Фоновый автосбор..." }
                        } else {
                            singleStatus.ifBlank { "Обработка..." }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (batchState.running) {
                        TextButton(onClick = { AutoScrapeService.stop(context) }) {
                            Icon(Icons.Default.Close, contentDescription = "Стоп", modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Стоп")
                        }
                    }
                }
            }
        }

        // Embedded Wikkeo WebView
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        this.settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            loadsImagesAutomatically = true
                            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            useWideViewPort = true
                            loadWithOverviewMode = true
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                pageProgress = newProgress
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean = false

                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                if (!url.isNullOrBlank()) currentUrl = url
                                canGoBack = view?.canGoBack() == true
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                if (!url.isNullOrBlank()) currentUrl = url
                                canGoBack = view?.canGoBack() == true
                            }
                        }
                        loadUrl(currentUrl)
                        webViewRef = this
                    }
                }
            )
        }

        // Bottom Action Bar
        Surface(tonalElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isProductPage) {
                    FilledTonalButton(
                        onClick = { startSingleScrape(publishNow = false) },
                        enabled = !singleBusy,
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Сохранить")
                    }
                    Button(
                        onClick = { startSingleScrape(publishNow = true) },
                        enabled = !singleBusy,
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("В Telegram")
                    }
                } else {
                    Button(
                        onClick = { startBackgroundBatchScrape() },
                        enabled = !isAnyBusy,
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        val modeText = if (settings.autoPublish) "и выложить" else "в черновики"
                        Text("Автосбор в фоне (до ${settings.maxProductsPerBatch} шт. $modeText)")
                    }
                }
            }
        }
    }
}
