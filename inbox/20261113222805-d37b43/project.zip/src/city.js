import * as THREE from 'three';

export const GRID_COUNT = 7;
export const BLOCK_SIZE = 34;
export const ROAD_WIDTH = 14;
export const CELL_STEP = BLOCK_SIZE + ROAD_WIDTH; // 48
export const CITY_HALF = (GRID_COUNT * CELL_STEP) / 2;

function createWindowTexture(baseHex, litRatio = 0.45) {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, 128, 256);

  const cols = 4;
  const rows = 10;
  const padX = 8;
  const padY = 8;
  const winW = (128 - padX * (cols + 1)) / cols;
  const winH = (256 - padY * (rows + 1)) / rows;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const lit = Math.random() < litRatio;
      ctx.fillStyle = lit ? '#FEF08A' : '#1E293B';
      ctx.fillRect(padX + c * (winW + padX), padY + r * (winH + padY), winW, winH);
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function createRoadTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#334155';
  ctx.fillRect(0, 0, 256, 256);

  // Лёгкий шум асфальта
  for (let i = 0; i < 1600; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = Math.random() > 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)';
    ctx.fillRect(x, y, 2, 2);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(24, 24);
  return tex;
}

export function buildCity(scene) {
  const colliders = [];
  const buildingMaterials = [];
  const lampBulbs = [];
  const roadLines = [];

  const totalSize = GRID_COUNT * CELL_STEP + ROAD_WIDTH * 2;

  // Асфальтовая основа города
  const groundGeo = new THREE.PlaneGeometry(totalSize + 80, totalSize + 80);
  const groundMat = new THREE.MeshStandardMaterial({
    map: createRoadTexture(),
    roughness: 0.92
  });
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  scene.add(ground);

  // Координаты центров дорог для трафика и разметки
  const roadCoords = [];
  const startCoord = -((GRID_COUNT - 1) * CELL_STEP) / 2;

  for (let i = 0; i <= GRID_COUNT; i++) {
    roadCoords.push(startCoord - CELL_STEP / 2 + i * CELL_STEP);
  }

  // Пунктирная разметка на дорогах
  const dashMat = new THREE.MeshBasicMaterial({ color: 0xe2e8f0 });
  const dashGeo = new THREE.PlaneGeometry(0.4, 3.5);
  const span = GRID_COUNT * CELL_STEP;

  roadCoords.forEach((coord) => {
    for (let d = -span / 2 + 4; d < span / 2; d += 10) {
      // Вертикальная дорога
      const dashV = new THREE.Mesh(dashGeo, dashMat);
      dashV.rotation.x = -Math.PI / 2;
      dashV.position.set(coord, 0.02, d);
      scene.add(dashV);

      // Горизонтальная дорога
      const dashH = new THREE.Mesh(dashGeo, dashMat);
      dashH.rotation.x = -Math.PI / 2;
      dashH.rotation.z = Math.PI / 2;
      dashH.position.set(d, 0.02, coord);
      scene.add(dashH);
    }
    roadLines.push(coord);
  });

  // Материалы зданий
  const palette = ['#475569', '#64748B', '#3B4252', '#52525B', '#4B5563', '#334155'];
  palette.forEach((hex) => {
    const tex = createWindowTexture(hex, 0.42);
    const mat = new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.75,
      emissive: new THREE.Color(0x000000),
      emissiveMap: tex,
      emissiveIntensity: 0.08
    });
    buildingMaterials.push(mat);
  });

  const sidewalkMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.9 });
  const parkMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.95 });
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
  const crownMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.85 });
  const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.6, roughness: 0.4 });
  const bulbMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xfef08a,
    emissiveIntensity: 0.25
  });

  const blockGeo = new THREE.BoxGeometry(BLOCK_SIZE, 0.36, BLOCK_SIZE);

  // Кварталы
  for (let gx = 0; gx < GRID_COUNT; gx++) {
    for (let gz = 0; gz < GRID_COUNT; gz++) {
      const cx = startCoord + gx * CELL_STEP;
      const cz = startCoord + gz * CELL_STEP;

      const isCenter = gx === Math.floor(GRID_COUNT / 2) && gz === Math.floor(GRID_COUNT / 2);
      const isPark = !isCenter && (gx + gz) % 4 === 0;

      // Тротуар квартала
      const sidewalk = new THREE.Mesh(blockGeo, isPark ? parkMat : sidewalkMat);
      sidewalk.position.set(cx, 0.18, cz);
      sidewalk.receiveShadow = true;
      scene.add(sidewalk);

      if (isCenter) {
        // Центральная площадь с монументом и свободным проездом вокруг
        const monument = new THREE.Mesh(
          new THREE.CylinderGeometry(2.2, 3.0, 12, 8),
          new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.5, roughness: 0.3 })
        );
        monument.position.set(cx, 6.2, cz);
        monument.castShadow = true;
        scene.add(monument);
        colliders.push({ minX: cx - 3.2, maxX: cx + 3.2, minZ: cz - 3.2, maxZ: cz + 3.2, isPark: false });
      } else if (isPark) {
        // Деревья в парке
        for (let t = 0; t < 6; t++) {
          const tx = cx + (Math.random() - 0.5) * (BLOCK_SIZE - 8);
          const tz = cz + (Math.random() - 0.5) * (BLOCK_SIZE - 8);
          const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 2.4, 6), trunkMat);
          trunk.position.set(tx, 1.4, tz);
          trunk.castShadow = true;
          const crown = new THREE.Mesh(new THREE.ConeGeometry(2.2, 4.5, 7), crownMat);
          crown.position.set(tx, 4.4, tz);
          crown.castShadow = true;
          scene.add(trunk, crown);
          colliders.push({ minX: tx - 0.8, maxX: tx + 0.8, minZ: tz - 0.8, maxZ: tz + 0.8, isPark: true });
        }
      } else {
        // Застройка квартала (2x2 здания)
        const subOffsets = [
          [-BLOCK_SIZE * 0.24, -BLOCK_SIZE * 0.24],
          [BLOCK_SIZE * 0.24, -BLOCK_SIZE * 0.24],
          [-BLOCK_SIZE * 0.24, BLOCK_SIZE * 0.24],
          [BLOCK_SIZE * 0.24, BLOCK_SIZE * 0.24]
        ];
        subOffsets.forEach(([ox, oz]) => {
          const w = 11 + Math.random() * 3.2;
          const d = 11 + Math.random() * 3.2;
          const h = 14 + Math.random() * 38;
          const mat = buildingMaterials[Math.floor(Math.random() * buildingMaterials.length)];
          const bMesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
          const bx = cx + ox;
          const bz = cz + oz;
          bMesh.position.set(bx, h / 2 + 0.36, bz);
          bMesh.castShadow = true;
          bMesh.receiveShadow = true;
          scene.add(bMesh);

          colliders.push({
            minX: bx - w / 2,
            maxX: bx + w / 2,
            minZ: bz - d / 2,
            maxZ: bz + d / 2,
            w,
            d,
            x: bx,
            z: bz,
            isPark: false
          });
        });
      }

      // Уличные фонари по углам квартала
      const corners = [
        [cx - BLOCK_SIZE / 2 + 1.2, cz - BLOCK_SIZE / 2 + 1.2],
        [cx + BLOCK_SIZE / 2 - 1.2, cz + BLOCK_SIZE / 2 - 1.2]
      ];
      corners.forEach(([lx, lz]) => {
        const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 6, 6), poleMat);
        pole.position.set(lx, 3.2, lz);
        const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.35, 8, 8), bulbMat);
        bulb.position.set(lx, 6.3, lz);
        scene.add(pole, bulb);
        lampBulbs.push(bulb);
      });
    }
  }

  // Внешние ограждения по периметру города
  const boundLimit = CITY_HALF + ROAD_WIDTH / 2 + 6;
  const wallMat = new THREE.MeshStandardMaterial({ color: 0xef4444, roughness: 0.7 });
  const wallThick = 2;
  const wallHeight = 2.5;
  const wallLen = boundLimit * 2 + wallThick;

  const walls = [
    { x: 0, z: -boundLimit, w: wallLen, d: wallThick },
    { x: 0, z: boundLimit, w: wallLen, d: wallThick },
    { x: -boundLimit, z: 0, w: wallThick, d: wallLen },
    { x: boundLimit, z: 0, w: wallThick, d: wallLen }
  ];
  walls.forEach((wl) => {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(wl.w, wallHeight, wl.d), wallMat);
    mesh.position.set(wl.x, wallHeight / 2, wl.z);
    scene.add(mesh);
  });

  return {
    colliders,
    buildingMaterials,
    bulbMat,
    roadCoords,
    boundLimit: boundLimit - 2
  };
}
