import * as THREE from 'three';

export const CAR_PRESETS = {
  sport: {
    name: 'Спорткар',
    color: 0x38bdf8,
    maxSpeed: 58,
    accel: 34,
    turnSpeed: 2.5,
    driftGrip: 0.91,
    bodyHeight: 0.55,
    cabinHeight: 0.44,
    length: 4.2,
    width: 1.9,
    hasSpoiler: true
  },
  muscle: {
    name: 'Маслкар',
    color: 0xf97316,
    maxSpeed: 53,
    accel: 38,
    turnSpeed: 2.7,
    driftGrip: 0.85,
    bodyHeight: 0.62,
    cabinHeight: 0.46,
    length: 4.35,
    width: 2.0,
    hasSpoiler: true
  },
  suv: {
    name: 'Внедорожник',
    color: 0x22c55e,
    maxSpeed: 47,
    accel: 30,
    turnSpeed: 2.25,
    driftGrip: 0.95,
    bodyHeight: 0.78,
    cabinHeight: 0.58,
    length: 4.4,
    width: 2.1,
    hasSpoiler: false
  }
};

export function createCarMesh(presetKey = 'sport', customColor = null) {
  const specs = CAR_PRESETS[presetKey] || CAR_PRESETS.sport;
  const color = customColor ?? specs.color;

  const group = new THREE.Group();

  const bodyMat = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.3,
    metalness: 0.45
  });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.15,
    metalness: 0.85
  });
  const darkMat = new THREE.MeshStandardMaterial({
    color: 0x1e293b,
    roughness: 0.75,
    metalness: 0.2
  });
  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    roughness: 0.85
  });
  const rimMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.25,
    metalness: 0.8
  });

  // Нижний кузов
  const bodyGeo = new THREE.BoxGeometry(specs.width, specs.bodyHeight, specs.length);
  const bodyMesh = new THREE.Mesh(bodyGeo, bodyMat);
  bodyMesh.position.y = 0.42 + specs.bodyHeight / 2;
  bodyMesh.castShadow = true;
  bodyMesh.receiveShadow = true;
  group.add(bodyMesh);

  // Кабина
  const cabinLen = specs.length * (presetKey === 'suv' ? 0.64 : 0.5);
  const cabinGeo = new THREE.BoxGeometry(specs.width * 0.84, specs.cabinHeight, cabinLen);
  const cabinMesh = new THREE.Mesh(cabinGeo, bodyMat);
  cabinMesh.position.set(
    0,
    0.42 + specs.bodyHeight + specs.cabinHeight / 2 - 0.03,
    presetKey === 'suv' ? -0.15 : -0.1
  );
  cabinMesh.castShadow = true;
  group.add(cabinMesh);

  // Стёкла
  const windGeo = new THREE.BoxGeometry(specs.width * 0.86, specs.cabinHeight * 0.72, cabinLen * 0.92);
  const windMesh = new THREE.Mesh(windGeo, glassMat);
  windMesh.position.copy(cabinMesh.position);
  windMesh.position.y -= 0.02;
  group.add(windMesh);

  // Бамперы
  const bumperGeo = new THREE.BoxGeometry(specs.width * 0.96, 0.22, 0.22);
  const frontBumper = new THREE.Mesh(bumperGeo, darkMat);
  frontBumper.position.set(0, 0.44, specs.length / 2 + 0.04);
  group.add(frontBumper);

  const rearBumper = new THREE.Mesh(bumperGeo, darkMat);
  rearBumper.position.set(0, 0.44, -specs.length / 2 - 0.04);
  group.add(rearBumper);

  // Спойлер
  if (specs.hasSpoiler) {
    const wingGeo = new THREE.BoxGeometry(specs.width * 0.88, 0.08, 0.34);
    const wing = new THREE.Mesh(wingGeo, darkMat);
    wing.position.set(0, 0.42 + specs.bodyHeight + 0.22, -specs.length / 2 + 0.28);
    group.add(wing);

    const strutGeo = new THREE.BoxGeometry(0.08, 0.22, 0.16);
    [-0.5, 0.5].forEach((xSide) => {
      const strut = new THREE.Mesh(strutGeo, darkMat);
      strut.position.set(xSide * (specs.width * 0.32), 0.42 + specs.bodyHeight + 0.1, -specs.length / 2 + 0.28);
      group.add(strut);
    });
  }

  // Фары (передние)
  const headMat = new THREE.MeshStandardMaterial({
    color: 0xfef08a,
    emissive: 0xfef08a,
    emissiveIntensity: 0.4
  });
  const headlights = [];
  [-0.6, 0.6].forEach((side) => {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.16, 0.08), headMat);
    hl.position.set(side * (specs.width * 0.34), 0.62, specs.length / 2 + 0.01);
    group.add(hl);
    headlights.push(hl);
  });

  // Задние стоп-сигналы
  const brakeMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xef4444,
    emissiveIntensity: 0.3
  });
  const brakeLights = [];
  [-0.6, 0.6].forEach((side) => {
    const bl = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.16, 0.08), brakeMat);
    bl.position.set(side * (specs.width * 0.34), 0.64, -specs.length / 2 - 0.01);
    group.add(bl);
    brakeLights.push(bl);
  });

  // Пламя нитро
  const flameMat = new THREE.MeshBasicMaterial({
    color: 0x38bdf8,
    transparent: true,
    opacity: 0.85
  });
  const nitroFlame = new THREE.Mesh(new THREE.ConeGeometry(0.22, 1.1, 8), flameMat);
  nitroFlame.rotation.x = -Math.PI / 2;
  nitroFlame.position.set(0, 0.46, -specs.length / 2 - 0.55);
  nitroFlame.visible = false;
  group.add(nitroFlame);

  // Колёса
  const wheelRadius = presetKey === 'suv' ? 0.44 : 0.38;
  const wheelWidth = 0.28;
  const wheelGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, wheelWidth, 16);
  wheelGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.58, wheelRadius * 0.58, wheelWidth + 0.02, 10);
  rimGeo.rotateZ(Math.PI / 2);

  const wheels = [];
  const frontWheelPivots = [];
  const wheelZ = specs.length * 0.31;
  const wheelX = specs.width / 2 + 0.04;

  const positions = [
    { x: -wheelX, z: wheelZ, front: true },
    { x: wheelX, z: wheelZ, front: true },
    { x: -wheelX, z: -wheelZ, front: false },
    { x: wheelX, z: -wheelZ, front: false }
  ];

  positions.forEach((pos) => {
    const pivot = new THREE.Group();
    pivot.position.set(pos.x, wheelRadius, pos.z);

    const wheelGroup = new THREE.Group();
    const tire = new THREE.Mesh(wheelGeo, tireMat);
    tire.castShadow = true;
    const rim = new THREE.Mesh(rimGeo, rimMat);
    wheelGroup.add(tire);
    wheelGroup.add(rim);

    pivot.add(wheelGroup);
    group.add(pivot);

    wheels.push(wheelGroup);
    if (pos.front) {
      frontWheelPivots.push(pivot);
    }
  });

  return {
    group,
    wheels,
    frontWheelPivots,
    headlights,
    brakeLights,
    headMat,
    brakeMat,
    nitroFlame,
    specs
  };
}
