import * as THREE from 'three';
import './style.css';
import { createCarMesh, CAR_PRESETS } from './car.js';
import { buildCity, CITY_HALF } from './city.js';
import { SoundEngine } from './audio.js';

const STORAGE_BEST_KEY = 'citydrive_best_coins';
const STORAGE_DIST_KEY = 'citydrive_total_km';

const sound = new SoundEngine();

// DOM элементы
const canvas = document.getElementById('game-canvas');
const startOverlay = document.getElementById('start-overlay');
const hud = document.getElementById('hud');
const btnStart = document.getElementById('btn-start');
const btnMenu = document.getElementById('btn-menu');
const btnCamera = document.getElementById('btn-camera');
const btnTime = document.getElementById('btn-time');
const btnSound = document.getElementById('btn-sound');

const hudCoins = document.getElementById('hud-coins');
const hudBest = document.getElementById('hud-best');
const hudDist = document.getElementById('hud-dist');
const hudSpeed = document.getElementById('hud-speed');
const hudNitro = document.getElementById('hud-nitro');
const menuBestCoins = document.getElementById('menu-best-coins');
const menuTotalKm = document.getElementById('menu-total-km');
const minimapCanvas = document.getElementById('minimap');
const minimapCtx = minimapCanvas.getContext('2d');

// Состояние сохранения
let bestCoins = parseInt(localStorage.getItem(STORAGE_BEST_KEY) || '0', 10) || 0;
let totalKm = parseFloat(localStorage.getItem(STORAGE_DIST_KEY) || '0') || 0;
menuBestCoins.textContent = String(bestCoins);
menuTotalKm.textContent = `${totalKm.toFixed(1)} км`;
hudBest.textContent = String(bestCoins);

// Three.js сцена
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const daySky = new THREE.Color(0x7dd3fc);
const nightSky = new THREE.Color(0x0b1120);
scene.background = daySky.clone();
scene.fog = new THREE.Fog(0x7dd3fc, 70, 230);

const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.3, 350);

// Освещение
const hemiLight = new THREE.HemisphereLight(0xe0f2fe, 0x334155, 0.85);
scene.add(hemiLight);

const sunLight = new THREE.DirectionalLight(0xfffbeb, 1.25);
sunLight.position.set(60, 95, 45);
sunLight.castShadow = true;
sunLight.shadow.mapSize.width = 1024;
sunLight.shadow.mapSize.height = 1024;
sunLight.shadow.camera.near = 10;
sunLight.shadow.camera.far = 220;
const dShadow = 85;
sunLight.shadow.camera.left = -dShadow;
sunLight.shadow.camera.right = dShadow;
sunLight.shadow.camera.top = dShadow;
sunLight.shadow.camera.bottom = -dShadow;
scene.add(sunLight);
scene.add(sunLight.target);

// Город
const city = buildCity(scene);

// Игровая машина
let selectedCarType = 'sport';
let playerCar = createCarMesh(selectedCarType);
scene.add(playerCar.group);

// Фары (SpotLight) для ночного режима
const headSpot = new THREE.SpotLight(0xfef9c3, 0, 48, Math.PI / 5, 0.45, 1.2);
headSpot.position.set(0, 0.85, 1.8);
const headTarget = new THREE.Object3D();
headTarget.position.set(0, 0.2, 18);
playerCar.group.add(headSpot);
playerCar.group.add(headTarget);
headSpot.target = headTarget;

function rebuildPlayerCar(type) {
  const pos = playerCar.group.position.clone();
  const rot = playerCar.group.rotation.y;
  playerCar.group.remove(headSpot);
  playerCar.group.remove(headTarget);
  scene.remove(playerCar.group);

  playerCar = createCarMesh(type);
  playerCar.group.position.copy(pos);
  playerCar.group.rotation.y = rot;
  playerCar.group.add(headSpot);
  playerCar.group.add(headTarget);
  scene.add(playerCar.group);
}

// Трафик
const trafficCars = [];
const trafficColors = [0xef4444, 0xeab308, 0xa855f7, 0xec4899, 0x14b8a6, 0xf8fafc];
const trafficTypes = ['sport', 'muscle', 'suv'];

function spawnTraffic() {
  for (let i = 0; i < 12; i++) {
    const tType = trafficTypes[i % trafficTypes.length];
    const tColor = trafficColors[i % trafficColors.length];
    const meshObj = createCarMesh(tType, tColor);
    const axis = i % 2 === 0 ? 'z' : 'x';
    const roadIdx = Math.floor(Math.random() * city.roadCoords.length);
    const laneCoord = city.roadCoords[roadIdx];
    const dir = Math.random() > 0.5 ? 1 : -1;
    const laneOffset = dir * 3.1;
    const travelPos = (Math.random() - 0.5) * (CITY_HALF * 1.7);

    if (axis === 'z') {
      meshObj.group.position.set(laneCoord - laneOffset, 0, travelPos);
      meshObj.group.rotation.y = dir > 0 ? 0 : Math.PI;
    } else {
      meshObj.group.position.set(travelPos, 0, laneCoord + laneOffset);
      meshObj.group.rotation.y = dir > 0 ? Math.PI / 2 : -Math.PI / 2;
    }

    scene.add(meshObj.group);
    trafficCars.push({
      meshObj,
      axis,
      dir,
      speed: 12 + Math.random() * 10
    });
  }
}
spawnTraffic();

// Монеты / чекпоинты
const coins = [];
const coinGeo = new THREE.TorusGeometry(0.95, 0.25, 10, 20);
const coinMat = new THREE.MeshStandardMaterial({
  color: 0xfacc15,
  emissive: 0xca8a04,
  emissiveIntensity: 0.55,
  metalness: 0.7,
  roughness: 0.25
});

function placeCoinOnRoad(mesh) {
  const axis = Math.random() > 0.5 ? 'z' : 'x';
  const rc = city.roadCoords[Math.floor(Math.random() * city.roadCoords.length)];
  const along = (Math.random() - 0.5) * (CITY_HALF * 1.75);
  const side = (Math.random() - 0.5) * 6;
  if (axis === 'z') {
    mesh.position.set(rc + side, 1.3, along);
  } else {
    mesh.position.set(along, 1.3, rc + side);
  }
}

for (let i = 0; i < 16; i++) {
  const cMesh = new THREE.Mesh(coinGeo, coinMat);
  placeCoinOnRoad(cMesh);
  scene.add(cMesh);
  coins.push(cMesh);
}

// Состояние игры
let isPlaying = false;
let isNight = false;
let cameraMode = 0; // 0: близко сзади, 1: далеко сзади, 2: капот
let currentCoins = 0;
let sessionDistMeters = 0;

// Физика игрока
const state = {
  x: city.roadCoords[Math.floor(city.roadCoords.length / 2)],
  z: 24,
  heading: 0,
  vx: 0,
  vz: 0,
  steerAngle: 0,
  nitro: 100
};
playerCar.group.position.set(state.x, 0, state.z);

// Ввод (тач + клавиатура)
const input = {
  left: false,
  right: false,
  gas: false,
  brake: false,
  nitro: false,
  drift: false
};

function bindTouchBtn(el, key) {
  const down = (e) => {
    e.preventDefault();
    input[key] = true;
    el.classList.add('pressed');
    sound.init();
  };
  const up = (e) => {
    e.preventDefault();
    input[key] = false;
    el.classList.remove('pressed');
  };
  el.addEventListener('pointerdown', down);
  el.addEventListener('pointerup', up);
  el.addEventListener('pointercancel', up);
  el.addEventListener('pointerleave', up);
}

bindTouchBtn(document.getElementById('ctrl-left'), 'left');
bindTouchBtn(document.getElementById('ctrl-right'), 'right');
bindTouchBtn(document.getElementById('ctrl-gas'), 'gas');
bindTouchBtn(document.getElementById('ctrl-brake'), 'brake');
bindTouchBtn(document.getElementById('ctrl-nitro'), 'nitro');
bindTouchBtn(document.getElementById('ctrl-drift'), 'drift');

window.addEventListener('keydown', (e) => {
  if (e.code === 'ArrowLeft' || e.code === 'KeyA') input.left = true;
  if (e.code === 'ArrowRight' || e.code === 'KeyD') input.right = true;
  if (e.code === 'ArrowUp' || e.code === 'KeyW') input.gas = true;
  if (e.code === 'ArrowDown' || e.code === 'KeyS') input.brake = true;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') input.nitro = true;
  if (e.code === 'Space') input.drift = true;
  if (e.code === 'KeyC') cameraMode = (cameraMode + 1) % 3;
  if (e.code === 'KeyN') toggleDayNight();
});

window.addEventListener('keyup', (e) => {
  if (e.code === 'ArrowLeft' || e.code === 'KeyA') input.left = false;
  if (e.code === 'ArrowRight' || e.code === 'KeyD') input.right = false;
  if (e.code === 'ArrowUp' || e.code === 'KeyW') input.gas = false;
  if (e.code === 'ArrowDown' || e.code === 'KeyS') input.brake = false;
  if (e.code === 'ShiftLeft' || e.code === 'ShiftRight') input.nitro = false;
  if (e.code === 'Space') input.drift = false;
});

// Выбор машины
document.querySelectorAll('.car-option').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.car-option').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    selectedCarType = btn.dataset.car;
    rebuildPlayerCar(selectedCarType);
  });
});

function toggleDayNight() {
  isNight = !isNight;
  if (isNight) {
    scene.background = nightSky.clone();
    scene.fog.color.copy(nightSky);
    hemiLight.intensity = 0.28;
    sunLight.intensity = 0.25;
    city.buildingMaterials.forEach((m) => (m.emissiveIntensity = 0.55));
    city.bulbMat.emissiveIntensity = 1.4;
    headSpot.intensity = 3.6;
    btnTime.textContent = '☀️';
  } else {
    scene.background = daySky.clone();
    scene.fog.color.copy(daySky);
    hemiLight.intensity = 0.85;
    sunLight.intensity = 1.25;
    city.buildingMaterials.forEach((m) => (m.emissiveIntensity = 0.08));
    city.bulbMat.emissiveIntensity = 0.25;
    headSpot.intensity = 0;
    btnTime.textContent = '🌙';
  }
}

btnTime.addEventListener('click', toggleDayNight);
btnCamera.addEventListener('click', () => {
  cameraMode = (cameraMode + 1) % 3;
});

let soundOn = true;
btnSound.addEventListener('click', () => {
  soundOn = !soundOn;
  sound.setEnabled(soundOn);
  btnSound.textContent = soundOn ? '🔊' : '🔇';
});

btnStart.addEventListener('click', () => {
  sound.init();
  isPlaying = true;
  startOverlay.classList.add('hidden');
  hud.classList.remove('hidden');
});

btnMenu.addEventListener('click', () => {
  isPlaying = false;
  sound.updateEngine(0, false, false);
  menuBestCoins.textContent = String(bestCoins);
  menuTotalKm.textContent = `${totalKm.toFixed(1)} км`;
  hud.classList.add('hidden');
  startOverlay.classList.remove('hidden');
});

// Обработка ресайза
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// Проверка столкновения с прямоугольными коллайдерами зданий
function resolveBuildingCollisions(radius) {
  let hit = false;
  for (let i = 0; i < city.colliders.length; i++) {
    const b = city.colliders[i];
    const closestX = Math.max(b.minX, Math.min(state.x, b.maxX));
    const closestZ = Math.max(b.minZ, Math.min(state.z, b.maxZ));
    const dx = state.x - closestX;
    const dz = state.z - closestZ;
    const distSq = dx * dx + dz * dz;

    if (distSq < radius * radius) {
      const dist = Math.sqrt(distSq) || 0.001;
      const overlap = radius - dist;
      const nx = dx / dist;
      const nz = dz / dist;
      state.x += nx * overlap;
      state.z += nz * overlap;

      const dot = state.vx * nx + state.vz * nz;
      if (dot < 0) {
        state.vx -= 1.45 * dot * nx;
        state.vz -= 1.45 * dot * nz;
        state.vx *= 0.6;
        state.vz *= 0.6;
        if (Math.abs(dot) > 8) hit = true;
      }
    }
  }

  // Границы города
  const lim = city.boundLimit;
  if (state.x < -lim) { state.x = -lim; state.vx *= -0.4; hit = true; }
  if (state.x > lim) { state.x = lim; state.vx *= -0.4; hit = true; }
  if (state.z < -lim) { state.z = -lim; state.vz *= -0.4; hit = true; }
  if (state.z > lim) { state.z = lim; state.vz *= -0.4; hit = true; }

  if (hit) {
    sound.playCrash();
    navigator.vibrate?.(45);
  }
}

// Рисование миникарты
function drawMinimap() {
  const w = minimapCanvas.width;
  const h = minimapCanvas.height;
  minimapCtx.clearRect(0, 0, w, h);

  const scale = w / (city.boundLimit * 2.1);
  const cx = w / 2;
  const cy = h / 2;

  // Дороги
  minimapCtx.strokeStyle = 'rgba(148, 163, 184, 0.35)';
  minimapCtx.lineWidth = 3;
  city.roadCoords.forEach((rc) => {
    const p = cx + rc * scale;
    minimapCtx.beginPath();
    minimapCtx.moveTo(p, 4);
    minimapCtx.lineTo(p, h - 4);
    minimapCtx.stroke();

    minimapCtx.beginPath();
    minimapCtx.moveTo(4, p);
    minimapCtx.lineTo(w - 4, p);
    minimapCtx.stroke();
  });

  // Монеты
  minimapCtx.fillStyle = '#FACC15';
  coins.forEach((c) => {
    minimapCtx.beginPath();
    minimapCtx.arc(cx + c.position.x * scale, cy + c.position.z * scale, 2.2, 0, Math.PI * 2);
    minimapCtx.fill();
  });

  // Трафик
  minimapCtx.fillStyle = '#94A3B8';
  trafficCars.forEach((tc) => {
    minimapCtx.fillRect(cx + tc.meshObj.group.position.x * scale - 1.5, cy + tc.meshObj.group.position.z * scale - 1.5, 3, 3);
  });

  // Игрок
  const px = cx + state.x * scale;
  const pz = cy + state.z * scale;
  minimapCtx.save();
  minimapCtx.translate(px, pz);
  minimapCtx.rotate(-state.heading);
  minimapCtx.fillStyle = '#38BDF8';
  minimapCtx.beginPath();
  minimapCtx.moveTo(0, 5);
  minimapCtx.lineTo(-3.5, -4);
  minimapCtx.lineTo(3.5, -4);
  minimapCtx.closePath();
  minimapCtx.fill();
  minimapCtx.restore();
}

// Главный цикл
let lastTime = performance.now();
let saveTimer = 0;

function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - lastTime) / 1000, 0.05);
  lastTime = now;

  const specs = CAR_PRESETS[selectedCarType];

  if (isPlaying) {
    // Направление вперёд (в Three.js +Z для машины)
    const fwdX = Math.sin(state.heading);
    const fwdZ = Math.cos(state.heading);

    const nitroUsing = input.nitro && state.nitro > 1 && input.gas;
    if (nitroUsing) {
      state.nitro = Math.max(0, state.nitro - 28 * dt);
    } else {
      state.nitro = Math.min(100, state.nitro + 11 * dt);
    }

    const maxSpd = nitroUsing ? specs.maxSpeed * 1.38 : specs.maxSpeed;
    const accel = nitroUsing ? specs.accel * 1.65 : specs.accel;

    if (input.gas) {
      state.vx += fwdX * accel * dt;
      state.vz += fwdZ * accel * dt;
    } else if (input.brake) {
      state.vx -= fwdX * accel * 0.85 * dt;
      state.vz -= fwdZ * accel * 0.85 * dt;
    }

    // Проекция скорости на вперёд и вбок (для дрифта)
    const forwardSpeed = state.vx * fwdX + state.vz * fwdZ;
    const rightX = Math.cos(state.heading);
    const rightZ = -Math.sin(state.heading);
    const lateralSpeed = state.vx * rightX + state.vz * rightZ;

    // Поворот зависит от скорости
    const steerInput = (input.left ? 1 : 0) - (input.right ? 1 : 0);
    state.steerAngle += (steerInput * 0.45 - state.steerAngle) * Math.min(1, 10 * dt);

    const speedFactor = Math.min(1, Math.abs(forwardSpeed) / 8);
    const turnDir = forwardSpeed >= -0.5 ? 1 : -1;
    const driftBoost = input.drift ? 1.35 : 1.0;
    state.heading += steerInput * specs.turnSpeed * driftBoost * speedFactor * turnDir * dt;

    // Гашение бокового скольжения (сцепление шин)
    const grip = input.drift ? 0.96 : specs.driftGrip;
    const dampedLateral = lateralSpeed * Math.pow(grip, dt * 60);
    const drag = input.gas || input.brake ? 0.992 : 0.975;
    let clampedFwd = forwardSpeed * Math.pow(drag, dt * 60);

    if (clampedFwd > maxSpd) clampedFwd = maxSpd;
    if (clampedFwd < -maxSpd * 0.4) clampedFwd = -maxSpd * 0.4;

    const newFwdX = Math.sin(state.heading);
    const newFwdZ = Math.cos(state.heading);
    const newRightX = Math.cos(state.heading);
    const newRightZ = -Math.sin(state.heading);

    state.vx = newFwdX * clampedFwd + newRightX * dampedLateral;
    state.vz = newFwdZ * clampedFwd + newRightZ * dampedLateral;

    state.x += state.vx * dt;
    state.z += state.vz * dt;

    resolveBuildingCollisions(1.45);

    const totalSpeed = Math.hypot(state.vx, state.vz);
    sessionDistMeters += totalSpeed * dt;

    // Визуал машины игрока
    playerCar.group.position.set(state.x, 0, state.z);
    playerCar.group.rotation.y = state.heading;
    playerCar.frontWheelPivots.forEach((p) => (p.rotation.y = state.steerAngle));
    playerCar.wheels.forEach((w) => (w.rotation.x += clampedFwd * dt * 2.2));
    playerCar.brakeMat.emissiveIntensity = input.brake || input.drift ? 1.6 : 0.3;
    playerCar.nitroFlame.visible = nitroUsing;
    if (nitroUsing) {
      playerCar.nitroFlame.scale.y = 0.8 + Math.random() * 0.5;
    }

    // Столкновение с трафиком
    trafficCars.forEach((tc) => {
      const tx = tc.meshObj.group.position.x;
      const tz = tc.meshObj.group.position.z;
      const dx = state.x - tx;
      const dz = state.z - tz;
      const d2 = dx * dx + dz * dz;
      if (d2 < 3.1 * 3.1) {
        const d = Math.sqrt(d2) || 0.1;
        const nx = dx / d;
        const nz = dz / d;
        state.x += nx * (3.1 - d);
        state.z += nz * (3.1 - d);
        state.vx = state.vx * 0.4 + nx * 8;
        state.vz = state.vz * 0.4 + nz * 8;
        sound.playCrash();
        navigator.vibrate?.(55);
      }
    });

    // Сбор монет
    coins.forEach((c) => {
      const dx = state.x - c.position.x;
      const dz = state.z - c.position.z;
      if (dx * dx + dz * dz < 2.6 * 2.6) {
        currentCoins += 10;
        if (currentCoins > bestCoins) {
          bestCoins = currentCoins;
          localStorage.setItem(STORAGE_BEST_KEY, String(bestCoins));
        }
        sound.playCoin();
        navigator.vibrate?.(30);
        placeCoinOnRoad(c);
      }
    });

    // Обновление HUD
    const kmh = Math.round(totalSpeed * 3.2);
    hudSpeed.textContent = String(kmh);
    hudCoins.textContent = String(currentCoins);
    hudBest.textContent = String(bestCoins);
    hudNitro.style.width = `${Math.round(state.nitro)}%`;

    saveTimer += dt;
    if (saveTimer > 1.0) {
      totalKm += sessionDistMeters / 1000;
      sessionDistMeters = 0;
      localStorage.setItem(STORAGE_DIST_KEY, totalKm.toFixed(2));
      hudDist.textContent = `${totalKm.toFixed(1)} км`;
      saveTimer = 0;
    }

    sound.updateEngine(totalSpeed / specs.maxSpeed, nitroUsing, true);
  } else {
    // Медленное вращение камеры вокруг машины в меню
    sound.updateEngine(0, false, false);
  }

  // Движение трафика и вращение монет
  trafficCars.forEach((tc) => {
    const pos = tc.meshObj.group.position;
    if (tc.axis === 'z') {
      pos.z += tc.dir * tc.speed * dt;
      if (pos.z > city.boundLimit) pos.z = -city.boundLimit;
      if (pos.z < -city.boundLimit) pos.z = city.boundLimit;
    } else {
      pos.x += tc.dir * tc.speed * dt;
      if (pos.x > city.boundLimit) pos.x = -city.boundLimit;
      if (pos.x < -city.boundLimit) pos.x = city.boundLimit;
    }
    tc.meshObj.wheels.forEach((w) => (w.rotation.x += tc.speed * dt * 1.8));
  });

  coins.forEach((c) => {
    c.rotation.y += 2.4 * dt;
  });

  // Камера
  if (!isPlaying) {
    const t = now * 0.0004;
    camera.position.set(
      state.x + Math.sin(t) * 10,
      4.5,
      state.z + Math.cos(t) * 10
    );
    camera.lookAt(state.x, 1.2, state.z);
  } else if (cameraMode === 2) {
    // Вид с капота
    const fx = Math.sin(state.heading);
    const fz = Math.cos(state.heading);
    camera.position.set(state.x + fx * 0.5, 1.55, state.z + fz * 0.5);
    camera.lookAt(state.x + fx * 20, 1.2, state.z + fz * 20);
  } else {
    const dist = cameraMode === 0 ? 9.5 : 15.5;
    const height = cameraMode === 0 ? 4.3 : 7.5;
    const targetX = state.x - Math.sin(state.heading) * dist;
    const targetZ = state.z - Math.cos(state.heading) * dist;
    camera.position.lerp(new THREE.Vector3(targetX, height, targetZ), Math.min(1, 8 * dt));
    camera.lookAt(state.x + Math.sin(state.heading) * 4, 1.3, state.z + Math.cos(state.heading) * 4);
  }

  // Тень следует за игроком
  sunLight.position.set(state.x + 55, 90, state.z + 40);
  sunLight.target.position.set(state.x, 0, state.z);
  sunLight.target.updateMatrixWorld();

  if (isPlaying) {
    drawMinimap();
  }

  renderer.render(scene, camera);
}

requestAnimationFrame(animate);
