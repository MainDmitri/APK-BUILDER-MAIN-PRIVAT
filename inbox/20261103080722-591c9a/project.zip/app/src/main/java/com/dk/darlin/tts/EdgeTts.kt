package com.dk.darlin.tts

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Клиент нейронных голосов Microsoft Edge «Read Aloud» (бесплатно, без ключа).
 * Протокол повторяет edge-tts: WebSocket, speech.config + SSML, MP3 24 кГц 48 кбит/с.
 */
object EdgeTts {
    private const val WSS_URL =
        "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=" +
            EdgeDrm.TRUSTED_CLIENT_TOKEN

    data class Voice(val id: String, val title: String)

    val VOICES = listOf(
        Voice("ru-RU-SvetlanaNeural", "Светлана — русский, женский (по умолчанию)"),
        Voice("en-US-AvaMultilingualNeural", "Ava — многоязычный, женский"),
        Voice("en-US-EmmaMultilingualNeural", "Emma — многоязычный, женский"),
        Voice("de-DE-SeraphinaMultilingualNeural", "Seraphina — многоязычный, женский"),
        Voice("fr-FR-VivienneMultilingualNeural", "Vivienne — многоязычный, женский"),
        Voice("pt-BR-ThalitaMultilingualNeural", "Thalita — многоязычный, женский"),
        Voice("ru-RU-DmitryNeural", "Дмитрий — русский, мужской"),
        Voice("en-US-AndrewMultilingualNeural", "Andrew — многоязычный, мужской"),
        Voice("en-US-BrianMultilingualNeural", "Brian — многоязычный, мужской")
    )
    const val DEFAULT_VOICE = "ru-RU-SvetlanaNeural"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }

    private fun connectId() = UUID.randomUUID().toString().replace("-", "")

    private fun dateString(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date())
    }

    fun escapeXml(s: String): String = buildString {
        for (ch in s) when (ch) {
            '&' -> append("&amp;"); '<' -> append("&lt;"); '>' -> append("&gt;")
            '"' -> append("&quot;"); '\'' -> append("&apos;")
            else -> if (ch.code < 32 && ch != '\n' && ch != '\t') append(' ') else append(ch)
        }
    }

    private fun signed(v: Int, unit: String) = (if (v >= 0) "+$v" else "$v") + unit

    /**
     * Синтезирует текст и возвращает MP3. Блокирующий вызов — запускать в фоне.
     * @param ratePercent скорость −50..+100 (%), @param pitchHz высота −50..+50 (Гц)
     */
    @Throws(IOException::class)
    fun synthesize(text: String, voice: String, ratePercent: Int = 0, pitchHz: Int = 0, retry: Boolean = true): ByteArray {
        val url = WSS_URL + "&ConnectionId=" + connectId() +
            "&Sec-MS-GEC=" + EdgeDrm.generate() +
            "&Sec-MS-GEC-Version=" + EdgeDrm.SEC_MS_GEC_VERSION
        val major = EdgeDrm.CHROMIUM_MAJOR
        val request = Request.Builder().url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/$major.0.0.0 Safari/537.36 Edg/$major.0.0.0"
            )
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "muid=${EdgeDrm.muid()};")
            .build()

        val audio = ByteArrayOutputStream()
        val latch = CountDownLatch(1)
        var error: String? = null
        var skewFix = false

        val ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>" +
            "<voice name='$voice'><prosody pitch='${signed(pitchHz, "Hz")}' rate='${signed(ratePercent, "%")}' volume='+0%'>" +
            escapeXml(text) + "</prosody></voice></speak>"

        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(
                    "X-Timestamp:${dateString()}\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{" +
                        "\"sentenceBoundaryEnabled\":\"true\",\"wordBoundaryEnabled\":\"false\"}," +
                        "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                )
                webSocket.send(
                    "X-RequestId:${connectId()}\r\n" +
                        "Content-Type:application/ssml+xml\r\n" +
                        "X-Timestamp:${dateString()}Z\r\n" +
                        "Path:ssml\r\n\r\n" + ssml
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val headerEnd = text.indexOf("\r\n\r\n").let { if (it < 0) text.length else it }
                val headers = text.substring(0, headerEnd)
                if (headers.contains("Path:turn.end")) {
                    webSocket.close(1000, null)
                    latch.countDown()
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                if (data.size < 2) return
                val headerLen = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
                if (headerLen + 2 > data.size) return
                val headers = String(data, 2, headerLen, Charsets.UTF_8)
                if (!headers.contains("Path:audio")) return
                val start = 2 + headerLen
                if (data.size > start) synchronized(audio) { audio.write(data, start, data.size - start) }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                error = (response?.code?.let { "HTTP $it: " } ?: "") + (t.message ?: t.javaClass.simpleName)
                // Как в edge-tts: при 403 подстраиваем часы по заголовку Date сервера.
                val date = response?.header("Date")
                if (response?.code == 403 && date != null) {
                    try {
                        val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
                        val server = f.parse(date)!!.time / 1000.0
                        EdgeDrm.clockSkewSeconds += server - System.currentTimeMillis() / 1000.0
                        skewFix = true
                    } catch (_: Exception) {
                    }
                }
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                latch.countDown()
            }
        })

        val ok = latch.await(25, TimeUnit.SECONDS)
        if (!ok) {
            ws.cancel()
            throw IOException("Edge TTS: таймаут")
        }
        if (error != null) {
            // 403 — после подстройки часов; обрыв соединения (EOF/сброс) — просто ещё одна попытка
            if (retry && (skewFix || synchronized(audio) { audio.size() } == 0)) return synthesize(text, voice, ratePercent, pitchHz, retry = false)
            throw IOException("Edge TTS: $error")
        }
        val bytes = synchronized(audio) { audio.toByteArray() }
        if (bytes.isEmpty()) throw IOException("Edge TTS: аудио не получено")
        return bytes
    }

    // ───────────── Быстрый потоковый режим ─────────────
    // Бесплатный endpoint Edge принимает только MP3 (raw-PCM отвечает 1007 «Unsupported Edge output format»),
    // поэтому MP3 декодируется на лету (Mp3StreamPlayer).
    const val FORMAT_MP3 = "audio-24khz-48kbitrate-mono-mp3"

    fun ssml(text: String, voice: String, ratePercent: Int, pitchHz: Int) =
        "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>" +
            "<voice name='$voice'><prosody pitch='${signed(pitchHz, "Hz")}' rate='${signed(ratePercent, "%")}' volume='+0%'>" +
            escapeXml(text) + "</prosody></voice></speak>"

    internal fun newRequest(): Request {
        val url = WSS_URL + "&ConnectionId=" + connectId() +
            "&Sec-MS-GEC=" + EdgeDrm.generate() +
            "&Sec-MS-GEC-Version=" + EdgeDrm.SEC_MS_GEC_VERSION
        val major = EdgeDrm.CHROMIUM_MAJOR
        return Request.Builder().url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/$major.0.0.0 Safari/537.36 Edg/$major.0.0.0")
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "muid=${EdgeDrm.muid()};")
            .build()
    }

    /**
     * Одно WebSocket-соединение с Edge. Открывается заранее («прогрев»), пока думает ИИ,
     * и отдаёт звук кусками по мере синтеза.
     */
    class Connection internal constructor(val format: String) {
        private val opened = CountDownLatch(1)
        @Volatile var failed: String? = null; private set
        @Volatile var closed = false; private set
        @Volatile var turns = 0; private set
        val createdAt = System.currentTimeMillis()
        private val lock = Object()
        private var reqId: String? = null
        private var onAudio: ((ByteArray, Int, Int) -> Unit)? = null
        private var turnDone: CountDownLatch? = null
        private var turnStarted: CountDownLatch? = null
        private var gotAudio = false

        private val ws: WebSocket = client.newWebSocket(newRequest(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(
                    "X-Timestamp:${dateString()}\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{" +
                        "\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"}," +
                        "\"outputFormat\":\"$format\"}}}}\r\n"
                )
                opened.countDown()
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                val headers = text.substring(0, text.indexOf("\r\n\r\n").let { if (it < 0) text.length else it })
                trace?.invoke("TEXT " + text.take(300).replace("\r\n", " | "))
                synchronized(lock) { if (reqId != null && headers.contains(reqId!!)) turnStarted?.countDown() }
                if (headers.contains("Path:turn.end")) synchronized(lock) { turnDone?.countDown() }
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                if (data.size < 2) return
                val headerLen = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
                if (headerLen + 2 > data.size) return
                val headers = String(data, 2, headerLen, Charsets.UTF_8)
                if (!headers.contains("Path:audio")) return
                val start = 2 + headerLen
                trace?.invoke("BIN ${data.size - start} " + headers.replace("\r\n", " | ").take(200))
                if (data.size <= start) return
                val cb = synchronized(lock) { if (reqId != null && headers.contains(reqId!!)) onAudio else null } ?: return
                gotAudio = true
                cb(data, start, data.size - start)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                failed = (response?.code?.let { "HTTP $it: " } ?: "") + (t.message ?: t.javaClass.simpleName)
                trace?.invoke("FAIL $failed")
                val date = response?.header("Date")
                if (response?.code == 403 && date != null) try {
                    val f = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US)
                    EdgeDrm.clockSkewSeconds += f.parse(date)!!.time / 1000.0 - System.currentTimeMillis() / 1000.0
                } catch (_: Exception) {}
                closed = true
                opened.countDown(); synchronized(lock) { turnStarted?.countDown(); turnDone?.countDown() }
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                trace?.invoke("CLOSED $code $reason")
                closed = true; synchronized(lock) { turnStarted?.countDown(); turnDone?.countDown() }
            }
            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { closed = true; webSocket.close(1000, null) }
        })

        @Volatile var lastUsed = System.currentTimeMillis()
        /** Токен Sec-MS-GEC живёт ~5 минут; простаивающие соединения сервер со временем закрывает. */
        val usable get() = !closed && failed == null && System.currentTimeMillis() - createdAt < 240_000 &&
            System.currentTimeMillis() - lastUsed < 60_000

        /**
         * Синтезирует одну фразу; звук приходит в [audio] по мере готовности (в потоке OkHttp).
         * Блокирует до конца фразы. Возвращает false, если соединение оборвалось до первого звука.
         */
        @Synchronized
        @Throws(IOException::class)
        fun speak(ssml: String, audio: (ByteArray, Int, Int) -> Unit): Boolean {
            if (!opened.await(10, TimeUnit.SECONDS)) throw IOException("Edge TTS: таймаут соединения")
            failed?.let { return false }
            val id = connectId()
            val done = CountDownLatch(1)
            val started = CountDownLatch(1)
            synchronized(lock) { reqId = id; onAudio = audio; turnDone = done; turnStarted = started; gotAudio = false }
            val reused = turns > 0
            turns++
            lastUsed = System.currentTimeMillis()
            val sent = ws.send(
                "X-RequestId:$id\r\nContent-Type:application/ssml+xml\r\n" +
                    "X-Timestamp:${dateString()}Z\r\nPath:ssml\r\n\r\n" + ssml
            )
            if (!sent) return false
            // Сервер молча «уснувшее» соединение не отвечает — быстро переключаемся на свежее
            if (!started.await(if (reused) 3L else 8L, TimeUnit.SECONDS) || failed != null) { close(); return false }
            if (!done.await(25, TimeUnit.SECONDS)) { close(); throw IOException("Edge TTS: таймаут") }
            synchronized(lock) { reqId = null; onAudio = null; turnDone = null; turnStarted = null }
            lastUsed = System.currentTimeMillis()
            if (!gotAudio) return false
            return true
        }

        fun close() { closed = true; try { ws.close(1000, null) } catch (_: Exception) {} }
    }

    @Volatile private var warm: Connection? = null
    /** Отладочный журнал протокола (только для тестов). */
    @Volatile var trace: ((String) -> Unit)? = null

    /** Открыть соединение заранее (пока пользователь говорит / ИИ думает), чтобы первая фраза зазвучала сразу. */
    fun prewarm(format: String = FORMAT_MP3) {
        synchronized(this) {
            val w = warm
            if (w != null && w.usable && w.format == format) return
            w?.close()
            warm = try { Connection(format) } catch (_: Exception) { null }
        }
    }

    /** Прогретое соединение; одно WebSocket-соединение обслуживает много фраз подряд. */
    private fun connection(format: String, fresh: Boolean): Connection = synchronized(this) {
        val w = warm
        if (!fresh && w != null && w.usable && w.format == format) return w
        w?.close()
        Connection(format).also { warm = it }
    }

    /**
     * Потоковый синтез одной фразы: звук отдаётся кусками сразу, как приходит.
     * Одна повторная попытка на свежем соединении, если первое оборвалось до звука.
     */
    @Throws(IOException::class)
    fun stream(text: String, voice: String, ratePercent: Int, pitchHz: Int, format: String = FORMAT_MP3, audio: (ByteArray, Int, Int) -> Unit) {
        val s = ssml(text, voice, ratePercent, pitchHz)
        if (connection(format, false).speak(s, audio)) return
        val c = connection(format, true)
        if (!c.speak(s, audio)) throw IOException("Edge TTS: " + (c.failed ?: "аудио не получено"))
    }

    /** Закрыть прогретое соединение (при выходе из приложения). */
    fun release() = synchronized(this) { warm?.close(); warm = null }

}
