package com.dk.darlin.ui

import com.dk.darlin.core.safeClick
import com.dk.darlin.core.safeLongClick
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dk.darlin.R
import com.dk.darlin.ai.Agent
import com.dk.darlin.ai.Conversation
import com.dk.darlin.ai.ToolExecutor
import com.dk.darlin.core.Db
import com.dk.darlin.core.Prefs
import com.dk.darlin.core.ScreenContext
import com.dk.darlin.tts.Speaker
import com.dk.darlin.voice.VoiceInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** ScrollView с ограничением высоты (для нижней панели). */
class MaxHeightScrollView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : ScrollView(c, a) {
    var maxHeight = 0
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = if (maxHeight > 0) MeasureSpec.makeMeasureSpec(maxHeight, MeasureSpec.AT_MOST) else heightMeasureSpec
        super.onMeasure(widthMeasureSpec, h)
    }
}

/**
 * Интерфейс ассистента: шар, диалог, голосовой и текстовый ввод.
 * OVERLAY — нижняя «стеклянная» панель поверх любого приложения; FULL — экран чата в приложении.
 */
class AssistantPanel(private val ctx: Context, private val mode: Mode, private val host: Host) : VoiceInput.Listener {
    enum class Mode { OVERLAY, FULL }

    interface Host {
        fun close()
        fun launch(intent: Intent): Boolean
        fun openApp()
        /** Свернуть панель, не прерывая задачу (Дарлин работает в другом приложении). */
        fun minimize() { close() }
        /** Скрыть панель сразу после открытия другого экрана (речь и задача продолжаются). */
        fun hideAfterLaunch() { close() }
    }

    val root = FrameLayout(ctx)
    private val sheet = LinearLayout(ctx)
    private val scroll = MaxHeightScrollView(ctx)
    private val list = LinearLayout(ctx)
    private val title = Ui.text(ctx, "Дарлин", 18f, Ui.TEXT, true)
    private val status = Ui.text(ctx, "", 13f, Ui.TEXT2)
    private val partial = Ui.text(ctx, "", 17f, Ui.TEXT)
    private val orb = OrbView(ctx)
    private val input = EditText(ctx)
    private val actionBtn: ImageButton
    private val chipsScroll = HorizontalScrollView(ctx)
    private val chips = LinearLayout(ctx)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + com.dk.darlin.core.CrashLog.globalHandler)
    /** Общий голос: продолжает говорить, когда панель уже закрылась после открытия приложения. */
    private val speaker: Speaker get() = com.dk.darlin.core.Background.speaker(ctx)
    private val voice = VoiceInput(ctx, this)
    private val tools = ToolExecutor(ctx, object : com.dk.darlin.ai.ActionHost {
        override fun launch(intent: Intent): Boolean = host.launch(intent)
        override fun minimize() { host.minimize() }
        override fun hideAfterLaunch() { if (mode == Mode.OVERLAY) host.hideAfterLaunch() }
    })
    private val agent = Agent(ctx, tools)
    private var screen: ScreenContext? = null
    private var job: Job? = null
    private var lastWasVoice = false
    private var shown = false

    init {
        val d = { v: Int -> Ui.dp(ctx, v) }
        sheet.orientation = LinearLayout.VERTICAL
        sheet.isClickable = true

        if (mode == Mode.OVERLAY) {
            root.setBackgroundColor(0x66000000)
            root.safeClick { host.close() }
            sheet.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xF21A1F36.toInt(), 0xFA0B0D17.toInt())).apply {
                val r = d(28).toFloat()
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(d(1), 0x26FFFFFF)
            }
            sheet.setPadding(d(16), d(10), d(16), d(12))
            root.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
            // «ручка»
            sheet.addView(View(ctx).apply { background = Ui.round(ctx, 0x40FFFFFF, 3f) },
                LinearLayout.LayoutParams(d(40), d(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = d(8) })
            scroll.maxHeight = (ctx.resources.displayMetrics.heightPixels * 0.48f).toInt()
            ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
                val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
                sheet.setPadding(d(16), d(10), d(16), d(12) + b.bottom)
                insets
            }
        } else {
            root.setBackgroundColor(Ui.BG)
            sheet.setPadding(d(16), d(8), d(16), d(10))
            root.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // Заголовок
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(title); titles.addView(status)
        header.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Ui.iconButton(ctx, R.drawable.ic_add).apply {
            contentDescription = "Новый диалог"; safeClick { newChat() }
        })
        if (mode == Mode.OVERLAY) {
            header.addView(Ui.iconButton(ctx, R.drawable.ic_open).apply {
                contentDescription = "Открыть приложение"; safeClick { host.openApp() }
            })
            header.addView(Ui.iconButton(ctx, R.drawable.ic_close).apply {
                contentDescription = "Закрыть"; safeClick { host.close() }
            })
        }
        sheet.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Сообщения
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(0, d(6), 0, d(6))
        scroll.isFillViewport = false
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        if (mode == Mode.FULL) sheet.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        else sheet.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Живой текст распознавания
        partial.gravity = Gravity.CENTER
        partial.setTypeface(partial.typeface, Typeface.ITALIC)
        partial.visibility = View.GONE
        sheet.addView(partial, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(4) })

        // Шар
        orb.safeClick { onActionButton() }
        orb.contentDescription = "Говорить"
        val orbSize = if (mode == Mode.OVERLAY) 132 else 96
        sheet.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(orbSize)))

        // Подсказки
        chips.orientation = LinearLayout.HORIZONTAL
        chipsScroll.isHorizontalScrollBarEnabled = false
        chipsScroll.addView(chips)
        for (s in listOf("Что на экране?", "Создай в Download файл main.py с игрой «динозаврик»", "Напиши Максу в WhatsApp привет", "Поставь будильник на 7:30", "Найди мои PDF", "Напомни через 10 минут позвонить маме", "Какая погода?")) {
            chips.addView(Ui.chip(ctx, s) { submit(s, false) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = d(8) })
        }
        sheet.addView(chipsScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = d(10) })

        // Ввод
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input.hint = "Спросите что-нибудь…"
        input.setHintTextColor(Ui.TEXT2)
        input.setTextColor(Ui.TEXT)
        input.textSize = 16f
        input.background = Ui.round(ctx, Ui.SURFACE2, 24f, 0x22FFFFFF)
        input.setPadding(d(18), d(12), d(18), d(12))
        input.maxLines = 4
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.inputType = EditorInfo.TYPE_CLASS_TEXT or EditorInfo.TYPE_TEXT_FLAG_CAP_SENTENCES or EditorInfo.TYPE_TEXT_FLAG_MULTI_LINE
        input.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_SEND || (ev?.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)) { sendTyped(); true } else false
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updateButton() }
        })
        input.setOnFocusChangeListener { _, has -> if (has) { voice.stop(); speaker.stop(); setState(OrbView.State.IDLE, "") } }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        actionBtn = Ui.iconButton(ctx, R.drawable.ic_mic, 52, Ui.gradient(ctx, intArrayOf(Ui.ACCENT, 0xFF448AFF.toInt()), 26f), Color.WHITE)
        actionBtn.safeClick { if (input.text.isNotBlank()) sendTyped() else onActionButton() }
        row.addView(actionBtn, LinearLayout.LayoutParams(d(52), d(52)).apply { leftMargin = d(10) })
        sheet.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        loadRecent()
        setState(OrbView.State.IDLE, if (Prefs.hasBrain(ctx)) "Нажмите на шар или скажите" else "Базовый режим — добавьте ключ ИИ в «Параметрах»")
    }

    // ---------- Жизненный цикл ----------
    fun onShown(sc: ScreenContext?) {
        shown = true
        if (sc != null) screen = sc
        if (mode == Mode.OVERLAY) {
            sheet.translationY = Ui.dp(ctx, 400).toFloat()
            sheet.alpha = 0f
            sheet.animate().translationY(0f).alpha(1f).setDuration(320).setInterpolator(DecelerateInterpolator(2f)).start()
            reloadRecentIfStale()
        }
        orb.invalidate()
        val pendingReply = com.dk.darlin.core.Background.pendingReply
        if (pendingReply != null && mode == Mode.OVERLAY) {
            // Вернулись после работы в другом приложении с вопросом к пользователю
            com.dk.darlin.core.Background.pendingReply = null
            if (list.childCount == 0) addBubble("assistant", pendingReply)
            lastWasVoice = true
            if (com.dk.darlin.core.Background.pendingSpoken) {
                // Вопрос уже прозвучал, пока панель была скрыта — сразу слушаем ответ
                com.dk.darlin.core.Background.pendingSpoken = false
                afterReply(pendingReply, false, false)
                return
            }
            setState(OrbView.State.SPEAKING, "Говорю…")
            speaker.speak(pendingReply) { afterReply(pendingReply, false, false) }
            return
        }
        if (Prefs.bool(ctx, Prefs.AUTO_LISTEN, true) && mode == Mode.OVERLAY) listen()
    }

    fun setScreenContext(sc: ScreenContext) { screen = sc }

    fun onHidden() {
        shown = false
        voice.stop()
        // Если панель закрылась сама после открытия приложения — Дарлин договаривает и доделывает задачу
        if (!tools.keepAlive) { speaker.stop(); job?.cancel() }
        setState(OrbView.State.IDLE, "")
        hideKeyboard()
    }

    fun destroy() {
        voice.stop(); scope.cancel()
        if (!tools.keepAlive) job?.cancel()
    }

    // ---------- Ввод ----------
    private fun hasMic() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun onActionButton() {
        when {
            voice.isListening -> { voice.finish(); setState(OrbView.State.THINKING, "Распознаю…") }
            speaker.isSpeaking -> { speaker.stop(); setState(OrbView.State.IDLE, "") }
            job?.isActive == true -> { job?.cancel(); setState(OrbView.State.IDLE, "Отменено") }
            else -> listen()
        }
    }

    fun listen() {
        if (!hasMic()) {
            addBubble("error", "Нужен доступ к микрофону. Откройте приложение Дарлин → «Настройка» и разрешите микрофон.")
            return
        }
        speaker.stop()
        speaker.prewarm() // пока пользователь говорит, заранее открываем соединение с голосом
        hideKeyboard()
        input.clearFocus()
        vibrate()
        setState(OrbView.State.LISTENING, "Слушаю…")
        partial.text = ""; partial.visibility = View.VISIBLE
        voice.start()
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        hideKeyboard()
        submit(t, false)
    }

    override fun onReady() { setState(OrbView.State.LISTENING, "Говорите…") }
    override fun onLevel(level: Float) { orb.setLevel(level) }
    override fun onPartial(text: String) { partial.visibility = View.VISIBLE; partial.text = text }
    override fun onFinal(text: String) {
        partial.visibility = View.GONE
        submit(text, true)
    }
    override fun onError(message: String, silent: Boolean) {
        partial.visibility = View.GONE
        setState(OrbView.State.IDLE, message)
        if (!silent) addBubble("error", message)
    }

    // ---------- Диалог ----------
    private fun submit(text: String, byVoice: Boolean) {
        lastWasVoice = byVoice
        chipsScroll.visibility = View.GONE
        addBubble("user", text)
        Db.get(ctx).addHistory("user", text)
        setState(OrbView.State.THINKING, "Думаю…")
        job?.cancel()
        com.dk.darlin.core.Background.current?.cancel()
        val wantSpeak = Prefs.bool(ctx, Prefs.SPEAK, true) && (byVoice || Prefs.bool(ctx, "speak_typed", false))
        if (wantSpeak) speaker.prewarm() else speaker.stop()
        val t0 = System.nanoTime()
        job = com.dk.darlin.core.Background.scope.launch {
            var live: TextView? = null          // пузырь, в который печатается ответ по мере генерации
            val round = StringBuilder()          // текст текущего раунда модели
            var streamed = false                 // озвучка уже идёт потоком
            val onDelta: (String) -> Unit = { d ->
                round.append(d)
                val tv = live ?: addBubble("assistant", "").also { live = it }
                tv.text = round.toString().trimStart()
                if (shown) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                if (wantSpeak) {
                    if (!streamed) {
                        streamed = true
                        firstTextMs = (System.nanoTime() - t0) / 1_000_000
                        speaker.begin()
                        if (shown) setState(OrbView.State.SPEAKING, "Говорю…")
                    }
                    speaker.feed(d)
                }
            }
            val reply = try {
                agent.respond(text, screen, { label ->
                    // Перед действием модель могла что-то написать — это отдельный пузырь
                    live = null; round.setLength(0)
                    if (shown) addBubble("action", label)
                }, onDelta)
            } catch (e: kotlinx.coroutines.CancellationException) {
                if (streamed) speaker.stop()
                com.dk.darlin.core.Background.hideWorking()
                throw e
            }
            // Итоговый текст совпал с напечатанным потоком? Иначе (ошибка сети, «Готово.») — добавляем
            val sameAsStream = round.toString().trim() == reply.trim()
            if (!sameAsStream) addBubble("assistant", reply) else live?.text = reply
            Db.get(ctx).addHistory("assistant", reply)
            if (streamed) { if (!sameAsStream) speaker.feed("\n" + reply); speaker.end() }
            val launched = tools.launchedSomething
            val did = tools.didAction
            if (!shown && tools.keepAlive) {
                // Панель закрыта: Дарлин открыла приложение или работала в нём
                tools.keepAlive = false
                com.dk.darlin.core.Background.deliver(ctx, reply, wantSpeak, alreadySpoken = streamed, byVoice = byVoice)
                return@launch
            }
            com.dk.darlin.core.Background.hideWorking()
            tools.keepAlive = false
            if (wantSpeak && shown) {
                setState(OrbView.State.SPEAKING, "Говорю…")
                if (!streamed) speaker.speak(reply)
                speaker.whenDone { afterReply(reply, launched, did) }
            } else {
                if (streamed) speaker.stop()
                setState(OrbView.State.IDLE, "")
                if (shouldClose(reply, launched, did)) { delay(900); if (shown) host.close() }
            }
        }
        com.dk.darlin.core.Background.current = job
    }

    /** Время от отправки до первого текста модели (мс), для отладки задержек. */
    var firstTextMs = -1L
        private set

    /** Закрыть панель после ответа: открыли приложение или выполнили разовое действие и не ждём ответа. */
    private fun shouldClose(reply: String, launched: Boolean, did: Boolean): Boolean {
        if (mode != Mode.OVERLAY || tools.keepOpen) return false
        if (reply.trim().endsWith("?")) return false
        if (launched) return true
        return did && Prefs.bool(ctx, Prefs.AUTO_CLOSE, true)
    }

    private fun afterReply(reply: String, launched: Boolean, did: Boolean) {
        if (!shown) return
        setState(OrbView.State.IDLE, "")
        if (shouldClose(reply, launched, did)) { host.close(); return }
        if (lastWasVoice && Prefs.bool(ctx, Prefs.CONTINUOUS, true) && reply.trim().endsWith("?")) listen()
    }

    private fun newChat() {
        job?.cancel(); speaker.stop(); voice.stop()
        Conversation.reset()
        list.removeAllViews()
        chipsScroll.visibility = View.VISIBLE
        setState(OrbView.State.IDLE, "Новый диалог")
    }

    private fun loadRecent() {
        list.removeAllViews()
        val items = if (mode == Mode.FULL) Db.get(ctx).history(60)
        else Db.get(ctx).history(6).filter { System.currentTimeMillis() - it.created < 10 * 60_000 && Conversation.messages.isNotEmpty() }
        for (h in items) addBubble(h.role, h.text, animate = false)
        chipsScroll.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun reloadRecentIfStale() {
        if (Conversation.messages.isEmpty() || System.currentTimeMillis() - Conversation.lastTime > 10 * 60_000) {
            list.removeAllViews(); chipsScroll.visibility = View.VISIBLE
        }
    }

    fun refresh() { loadRecent() }

    private fun setState(s: OrbView.State, msg: String) {
        orb.state = s
        status.text = msg.ifEmpty { if (Prefs.hasBrain(ctx)) "Нажмите на шар или скажите" else "Базовый режим" }
        updateButton()
    }

    private fun updateButton() {
        val icon = when {
            input.text.isNotBlank() -> R.drawable.ic_send
            voice.isListening || speaker.isSpeaking || job?.isActive == true -> R.drawable.ic_stop
            else -> R.drawable.ic_mic
        }
        actionBtn.setImageResource(icon)
    }

    private fun addBubble(role: String, text: String, animate: Boolean = true): TextView {
        val d = { v: Int -> Ui.dp(ctx, v) }
        val tv = Ui.text(ctx, text, if (role == "action") 13f else 15.5f, if (role == "action") Ui.TEXT2 else Ui.TEXT)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(6) }
        when (role) {
            "user" -> {
                tv.background = Ui.gradient(ctx, intArrayOf(Ui.ACCENT, 0xFF448AFF.toInt()), 20f)
                tv.setTextColor(Color.WHITE)
                lp.gravity = Gravity.END; lp.leftMargin = d(48)
            }
            "assistant" -> {
                tv.background = Ui.round(ctx, 0x17FFFFFF, 20f, 0x1AFFFFFF)
                lp.gravity = Gravity.START; lp.rightMargin = d(32)
                tv.setTextIsSelectable(true)
            }
            "error" -> {
                tv.background = Ui.round(ctx, 0x22FF4081, 16f, 0x44FF4081)
                lp.gravity = Gravity.START
                tv.safeClick { host.openApp() }
            }
            else -> {
                tv.text = "⚡ $text"
                lp.gravity = Gravity.START
            }
        }
        if (role != "action") tv.setPadding(d(14), d(10), d(14), d(10)) else tv.setPadding(d(6), d(2), d(6), d(2))
        tv.safeLongClick {
            (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Дарлин", tv.text.toString().removePrefix("⚡ ")))
            Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show(); true
        }
        list.addView(tv, lp)
        if (animate) Ui.fadeIn(tv)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun hideKeyboard() {
        (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
    }

    private fun vibrate() {
        if (!Prefs.bool(ctx, Prefs.HAPTICS, true)) return
        try {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(18, 120))
        } catch (_: Exception) {}
    }

    @Suppress("unused")
    private fun TextView.bold() { typeface = Typeface.DEFAULT_BOLD }
}
