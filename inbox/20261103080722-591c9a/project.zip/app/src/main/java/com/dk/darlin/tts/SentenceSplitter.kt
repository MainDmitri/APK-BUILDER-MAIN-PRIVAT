package com.dk.darlin.tts

/**
 * Режет поток текста от ИИ на готовые к озвучке фразы: фраза отдаётся, как только
 * в потоке появилась её точка/вопрос/перевод строки. Блоки кода не зачитываются.
 */
class SentenceSplitter(private val maxLen: Int = 220) {
    private val sb = StringBuilder()
    private val boundary = Regex("[.!?…]+[\"»)\\]]*\\s+|\\n+")

    fun push(delta: String): List<String> {
        sb.append(delta)
        return drain(false)
    }

    fun flush(): List<String> = drain(true)

    private fun drain(final: Boolean): List<String> {
        val out = ArrayList<String>()
        while (true) {
            val f = sb.indexOf("```")
            if (f >= 0) {
                emitAll(sb.substring(0, f), out)
                val close = sb.indexOf("```", f + 3)
                if (close < 0) {
                    sb.delete(0, f)
                    if (final) { out += "Код — на экране."; sb.clear() }
                    return out.clean()
                }
                out += "Код — на экране."
                sb.delete(0, close + 3)
                continue
            }
            break
        }
        // целые фразы
        var last = 0
        for (m in boundary.findAll(sb)) {
            out += sb.substring(last, m.range.last + 1)
            last = m.range.last + 1
        }
        sb.delete(0, last)
        // слишком длинная фраза без точки — режем по запятой/пробелу, чтобы не ждать
        while (sb.length > maxLen) {
            var cut = sb.lastIndexOf(", ", maxLen).let { if (it > maxLen / 3) it + 1 else -1 }
            if (cut < 0) cut = sb.lastIndexOf(" ", maxLen).let { if (it > maxLen / 3) it else maxLen }
            out += sb.substring(0, cut); sb.delete(0, cut)
        }
        if (final && sb.isNotBlank()) { out += sb.toString(); sb.clear() }
        return out.clean()
    }

    private fun emitAll(s: String, out: MutableList<String>) {
        if (s.isBlank()) return
        var last = 0
        for (m in boundary.findAll(s)) { out += s.substring(last, m.range.last + 1); last = m.range.last + 1 }
        if (last < s.length) out += s.substring(last)
    }

    private fun List<String>.clean() = map { Speaker.cleanForSpeech(it) }.filter { it.any(Char::isLetterOrDigit) }
}
