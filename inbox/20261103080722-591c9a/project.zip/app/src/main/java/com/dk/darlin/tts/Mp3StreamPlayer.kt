package com.dk.darlin.tts

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Проигрывает MP3-поток по мере поступления байтов: MediaCodec (audio/mpeg) → AudioTrack.
 * Звук начинается с первого же куска от Edge, не дожидаясь конца синтеза фразы.
 */
class Mp3StreamPlayer(private val sampleRate: Int = 24000) {
    private val queue = LinkedBlockingQueue<ByteArray>()
    private val pending = ByteArrayOutputStream()
    @Volatile private var ended = false
    @Volatile private var stopped = false
    @Volatile var error: Throwable? = null; private set
    private var codec: MediaCodec? = null
    private var track: AudioTrack? = null
    private var framesWritten = 0L
    private val worker = Thread({ run() }, "darlin-mp3")
    private val finished = java.util.concurrent.CountDownLatch(1)
    /** Время (nanoTime), когда в динамик ушёл первый звук — для замеров задержки. */
    @Volatile var firstAudioAt = 0L; private set

    fun start(): Mp3StreamPlayer { worker.start(); return this }

    /** Новые байты MP3 (можно рвать на любой границе — кадры собираются здесь). */
    fun write(b: ByteArray, off: Int = 0, len: Int = b.size) {
        if (stopped || len <= 0) return
        queue.put(b.copyOfRange(off, off + len))
    }

    /** Больше данных не будет: доиграть и завершиться. */
    fun end() { ended = true; queue.put(ByteArray(0)) }

    fun stop() {
        stopped = true; ended = true; queue.put(ByteArray(0))
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
    }

    /** Ждёт, пока весь звук будет проигран (или остановлен). */
    fun awaitDone(timeoutMs: Long = 120_000) { finished.await(timeoutMs, TimeUnit.MILLISECONDS) }

    private fun run() {
        try {
            val minBuf = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(if (android.os.Build.VERSION.SDK_INT >= 26) AudioAttributes.USAGE_ASSISTANT else AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(minBuf, sampleRate / 5 * 2)) // ~200 мс
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_AUDIO_MPEG)
            c.configure(MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_MPEG, sampleRate, 1), null, null, 0)
            c.start()
            codec = c
            val info = MediaCodec.BufferInfo()
            var inputEos = false
            var outputEos = false
            var pts = 0L
            while (!stopped && !outputEos) {
                if (!inputEos) {
                    val frame = nextFrame()
                    if (frame != null || ended) {
                        val idx = c.dequeueInputBuffer(10_000)
                        if (idx >= 0) {
                            if (frame == null) {
                                c.queueInputBuffer(idx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputEos = true
                            } else {
                                c.getInputBuffer(idx)!!.apply { clear(); put(frame) }
                                c.queueInputBuffer(idx, 0, frame.size, pts, 0)
                                pts += 1_000_000L * 576 / sampleRate
                            }
                        } else if (frame != null) pushBack(frame)
                    }
                }
                val o = c.dequeueOutputBuffer(info, if (inputEos) 10_000 else 0)
                if (o >= 0) {
                    if (info.size > 0) {
                        val buf = c.getOutputBuffer(o)!!
                        val pcm = ByteArray(info.size); buf.position(info.offset); buf.get(pcm)
                        if (t.playState != AudioTrack.PLAYSTATE_PLAYING) t.play()
                        if (firstAudioAt == 0L) firstAudioAt = System.nanoTime()
                        var w = 0
                        while (w < pcm.size && !stopped) { val r = t.write(pcm, w, pcm.size - w); if (r <= 0) break; w += r }
                        framesWritten += pcm.size / 2
                    }
                    c.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputEos = true
                }
            }
            // Дожидаемся, пока AudioTrack доиграет буфер
            if (!stopped && framesWritten > 0) {
                if (t.playState != AudioTrack.PLAYSTATE_PLAYING) t.play()
                val deadline = System.currentTimeMillis() + 5000 + framesWritten * 1000 / sampleRate
                while (!stopped && (t.playbackHeadPosition.toLong() and 0xFFFFFFFFL) < framesWritten && System.currentTimeMillis() < deadline) Thread.sleep(20)
            }
        } catch (e: Throwable) {
            error = e
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { track?.stop() } catch (_: Exception) {}
            try { track?.release() } catch (_: Exception) {}
            finished.countDown()
        }
    }

    // ---------- Разбор MP3 на кадры ----------
    private var buf = ByteArray(0)
    private var back: ByteArray? = null

    private fun pushBack(f: ByteArray) { back = f }

    /** Следующий целый MP3-кадр, или null, если данных пока нет (и ждать нечего — при ended). */
    private fun nextFrame(): ByteArray? {
        back?.let { back = null; return it }
        while (true) {
            parseFrame()?.let { return it }
            if (ended && queue.isEmpty()) return null
            val chunk = queue.poll(20, TimeUnit.MILLISECONDS) ?: return null
            if (chunk.isEmpty()) { if (ended && queue.isEmpty()) return parseFrame(); continue }
            buf = if (buf.isEmpty()) chunk else buf + chunk
        }
    }

    private fun parseFrame(): ByteArray? {
        var i = 0
        while (i + 4 <= buf.size) {
            val len = frameLength(buf, i)
            if (len > 0) {
                if (i + len > buf.size) { if (i > 0) buf = buf.copyOfRange(i, buf.size); return null }
                val f = buf.copyOfRange(i, i + len)
                buf = buf.copyOfRange(i + len, buf.size)
                return f
            }
            i++
        }
        if (i > 0 && i < buf.size) buf = buf.copyOfRange(i, buf.size)
        return null
    }

    companion object {
        private val BITRATES_V1_L3 = intArrayOf(0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320)
        private val BITRATES_V2_L3 = intArrayOf(0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160)
        private val RATES_V1 = intArrayOf(44100, 48000, 32000)

        /** Длина MP3-кадра Layer III по заголовку, 0 — если тут не заголовок. */
        fun frameLength(b: ByteArray, i: Int): Int {
            val h0 = b[i].toInt() and 0xFF; val h1 = b[i + 1].toInt() and 0xFF; val h2 = b[i + 2].toInt() and 0xFF
            if (h0 != 0xFF || (h1 and 0xE0) != 0xE0) return 0
            val version = (h1 shr 3) and 3        // 3 = MPEG1, 2 = MPEG2, 0 = MPEG2.5
            val layer = (h1 shr 1) and 3          // 1 = Layer III
            if (version == 1 || layer != 1) return 0
            val brIdx = (h2 shr 4) and 0xF; val srIdx = (h2 shr 2) and 3; val pad = (h2 shr 1) and 1
            if (brIdx == 0 || brIdx == 15 || srIdx == 3) return 0
            val v1 = version == 3
            val br = (if (v1) BITRATES_V1_L3 else BITRATES_V2_L3)[brIdx] * 1000
            val sr = RATES_V1[srIdx] / (if (version == 3) 1 else if (version == 2) 2 else 4)
            return (if (v1) 144 else 72) * br / sr + pad
        }
    }
}
