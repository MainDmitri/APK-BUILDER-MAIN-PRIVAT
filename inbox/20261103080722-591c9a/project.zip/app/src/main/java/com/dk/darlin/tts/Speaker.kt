package com.dk.darlin.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.dk.darlin.core.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Озвучка ответов: по умолчанию нейроголоса Microsoft Edge,
 * при любой ошибке/без интернета — системный TextToSpeech.
 */
class Speaker(context: Context) {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + com.dk.darlin.core.CrashLog.globalHandler)
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingTts = ArrayList<Pair<String, () -> Unit>>()
    @Volatile private var systemDone: (() -> Unit)? = null
    private var session: Session? = null
    private val afterDone = ArrayList<() -> Unit>()

    var isSpeaking = false
        private set

    var lastError: String? = null
        private set

    /** Задержка последней озвучки: от начала (первого текста) до первого звука, мс. */
    @Volatile var lastFirstAudioMs = -1L
        private set

    /**
     * Потоковая озвучка: begin() → feed(кусочки текста по мере генерации) → end().
     * Каждая фраза синтезируется, как только закончилась, следующая — пока звучит текущая.
     */
    private inner class Session(val voice: String, val system: Boolean, val onDone: () -> Unit) {
        val splitter = SentenceSplitter()
        val sentences = Channel<String>(Channel.UNLIMITED)
        var player: Mp3StreamPlayer? = null
        val startedAt = System.nanoTime()
        var any = false
        val job: Job = scope.launch(Dispatchers.IO) { run() }

        fun feed(t: String) { for (x in splitter.push(t)) { any = true; sentences.trySend(x) } }
        fun end() { for (x in splitter.flush()) { any = true; sentences.trySend(x) }; sentences.close() }

        private suspend fun run() {
            val rate = Prefs.rate(ctx); val pitch = Prefs.pitch(ctx)
            var useSystem = system
            var useFiles = false
            for (s in sentences) {
                currentCoroutineContext().ensureActive()
                if (!useSystem && !useFiles) {
                    try {
                        val p = player ?: Mp3StreamPlayer().start().also { player = it }
                        EdgeTts.stream(s, voice, rate, pitch) { b, o, n -> p.write(b, o, n) }
                        if (p.error != null && p.firstAudioAt == 0L) { useFiles = true; player = null } // нет декодера — запасной путь
                        if (!useFiles) continue
                    } catch (e: Exception) {
                        lastError = e.message
                        useSystem = true
                    }
                }
                if (useFiles && !useSystem) {
                    try {
                        val bytes = java.io.ByteArrayOutputStream()
                        EdgeTts.stream(s, voice, rate, pitch) { b, o, n -> bytes.write(b, o, n) }
                        val f = File(ctx.cacheDir, "tts_${System.nanoTime()}.mp3"); f.writeBytes(bytes.toByteArray())
                        markFirstAudio()
                        withContext(Dispatchers.Main) { playFile(f) }
                        f.delete()
                        continue
                    } catch (e: Exception) { lastError = e.message; useSystem = true }
                }
                // Системный голос: сначала доигрываем то, что уже синтезировал Edge
                player?.let { it.end(); it.awaitDone(); player = null }
                markFirstAudio()
                speakSystemAwait(s)
            }
            player?.let { p ->
                p.end()
                p.awaitDone()
                if (p.firstAudioAt > 0 && lastFirstAudioMs < 0) lastFirstAudioMs = (p.firstAudioAt - startedAt) / 1_000_000
            }
            withContext(Dispatchers.Main) { if (session === this@Session) finishSession() }
        }

        private fun markFirstAudio() { if (lastFirstAudioMs < 0) lastFirstAudioMs = (System.nanoTime() - startedAt) / 1_000_000 }

        fun cancel() { job.cancel(); sentences.close(); player?.stop() }
    }

    private fun finishSession() {
        val s = session ?: return
        session = null
        isSpeaking = false
        s.onDone()
        val cbs = ArrayList(afterDone); afterDone.clear()
        cbs.forEach { try { it() } catch (_: Exception) {} }
    }

    /** Начать потоковую озвучку (останавливает текущую). */
    fun begin(voiceOverride: String? = null, onDone: () -> Unit = {}) {
        stop()
        lastFirstAudioMs = -1
        isSpeaking = true
        val system = Prefs.voiceEngine(ctx) == "system" && voiceOverride == null
        if (!system) prewarm()
        session = Session(voiceOverride ?: Prefs.edgeVoice(ctx), system, onDone)
    }

    /** Заранее открыть соединение с Edge (пока пользователь говорит или модель думает). */
    fun prewarm() {
        if (Prefs.voiceEngine(ctx) == "system") return
        Thread { try { EdgeTts.prewarm() } catch (_: Exception) {} }.apply { isDaemon = true }.start()
    }

    /** Добавить текст (любой длины, хоть по одному токену). */
    fun feed(text: String) { session?.feed(text) }

    /** Текст закончился — дозвучать и вызвать onDone. */
    fun end() { session?.end() }

    /** Сказать готовый текст целиком. onDone вызывается в главном потоке после окончания (не при stop()). */
    fun speak(text: String, voiceOverride: String? = null, onDone: () -> Unit = {}) {
        if (cleanForSpeech(text).isBlank()) { stop(); onDone(); return }
        begin(voiceOverride, onDone)
        feed(text); end()
    }

    /** Выполнить действие, когда текущая речь закончится (сразу, если ничего не звучит). */
    fun whenDone(cb: () -> Unit) { if (!isSpeaking) cb() else afterDone.add(cb) }

    private suspend fun speakSystemAwait(text: String) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { cont ->
            speakSystem(text) { if (cont.isActive) cont.resume(Unit) }
            cont.invokeOnCancellation { main.post { tts?.stop() } }
        }
    }

    private var mediaPlayer: MediaPlayer? = null

    private suspend fun playFile(f: File) = suspendCancellableCoroutine<Unit> { cont ->
        try {
            val mp = MediaPlayer()
            mediaPlayer = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                it.release(); if (mediaPlayer === it) mediaPlayer = null
                if (cont.isActive) cont.resume(Unit)
            }
            mp.setOnErrorListener { p, _, _ ->
                p.release(); if (mediaPlayer === p) mediaPlayer = null
                if (cont.isActive) cont.resume(Unit)
                true
            }
            mp.prepare()
            mp.start()
            cont.invokeOnCancellation {
                main.post { try { mp.stop(); mp.release() } catch (_: Exception) {} }
            }
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(Unit)
        }
    }

    private fun speakSystem(text: String, onDone: () -> Unit) {
        val t = tts
        if (t == null) {
            pendingTts.add(text to onDone)
            tts = TextToSpeech(ctx) { status ->
                main.post {
                    ttsReady = status == TextToSpeech.SUCCESS
                    if (ttsReady) {
                        tts?.language = Locale("ru", "RU")
                        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                if (utteranceId == "last") main.post { systemDone?.invoke(); systemDone = null }
                            }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                main.post { systemDone?.invoke(); systemDone = null }
                            }
                        })
                    }
                    val list = ArrayList(pendingTts); pendingTts.clear()
                    for ((tx, cb) in list) if (ttsReady) speakSystemNow(tx, cb) else cb()
                }
            }
            return
        }
        if (!ttsReady) { pendingTts.add(text to onDone); return }
        speakSystemNow(text, onDone)
    }

    private fun speakSystemNow(text: String, onDone: () -> Unit) {
        val t = tts ?: return onDone()
        systemDone = onDone
        t.setSpeechRate(1f + Prefs.rate(ctx) / 100f)
        t.setPitch(1f + Prefs.pitch(ctx) / 100f)
        val parts = splitChunks(text, 3500)
        parts.forEachIndexed { i, p ->
            t.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(),
                if (i == parts.lastIndex) "last" else "p$i")
        }
    }

    fun stop() {
        session?.cancel(); session = null
        afterDone.clear()
        try { mediaPlayer?.stop() } catch (_: Exception) {}
        try { mediaPlayer?.release() } catch (_: Exception) {}
        mediaPlayer = null
        tts?.stop()
        pendingTts.clear()
        systemDone = null
        isSpeaking = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown(); tts = null
        scope.cancel()
    }

    companion object {
        fun cleanForSpeech(s: String): String = s
            .replace(Regex("```[\\s\\S]*?```"), " (код на экране) ")
            .replace(Regex("\\[([^\\]]+)]\\([^)]+\\)"), "$1")
            .replace(Regex("https?://\\S+"), " ссылка ")
            .replace(Regex("[*_#`>|]+"), "")
            .replace(Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        fun splitChunks(s: String, max: Int = 400): List<String> {
            val out = ArrayList<String>()
            val sentences = s.split(Regex("(?<=[.!?…])\\s+"))
            val sb = StringBuilder()
            for (sent in sentences) {
                var x = sent
                while (x.length > max) {
                    if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                    val cut = x.lastIndexOf(' ', max).let { if (it < max / 2) max else it }
                    out.add(x.substring(0, cut)); x = x.substring(cut).trim()
                }
                // Первый кусок короткий — чтобы звук начинался быстрее.
                val limit = if (out.isEmpty()) 160 else max
                if (sb.length + x.length + 1 > limit && sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(x)
            }
            if (sb.isNotBlank()) out.add(sb.toString())
            return out.filter { it.isNotBlank() }
        }
    }
}
