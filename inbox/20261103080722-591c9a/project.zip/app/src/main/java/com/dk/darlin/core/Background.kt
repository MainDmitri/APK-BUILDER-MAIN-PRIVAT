package com.dk.darlin.core

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.tts.Speaker
import com.dk.darlin.voice.DarlinInteractionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob

/**
 * Задачи, которые переживают закрытие панели: когда Дарлин управляет другим приложением,
 * панель сворачивается, а работа продолжается здесь.
 */
object Background {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + CrashLog.globalHandler)
    @Volatile var current: Job? = null
    /** Ответ, который нужно озвучить при следующем показе панели (если задача закончилась вопросом). */
    @Volatile var pendingReply: String? = null

    private var speaker: Speaker? = null
    fun speaker(ctx: Context): Speaker = speaker ?: Speaker(ctx.applicationContext).also { speaker = it }

    /** Показ индикатора «Дарлин работает…» с кнопкой «Стоп» поверх других приложений. */
    fun showWorking(ctx: Context, text: String = "Дарлин выполняет задачу…") {
        DarlinAccessibilityService.instance?.showCard(text, null, null, "Стоп") { current?.cancel() }
    }

    fun hideWorking() { DarlinAccessibilityService.instance?.hideCard() }

    /** Вопрос уже озвучен — при повторном показе панели сразу слушать. */
    @Volatile var pendingSpoken = false

    /**
     * Доставляет ответ, когда панель уже скрыта (Дарлин открыла приложение или работала в нём).
     * [alreadySpoken] — ответ уже звучит потоком общим голосом, второй раз не говорим.
     */
    fun deliver(ctx: Context, reply: String, speak: Boolean, alreadySpoken: Boolean = false, byVoice: Boolean = true) {
        hideWorking()
        val app = ctx.applicationContext
        val sp = speaker(app)
        val svc = DarlinInteractionService.instance
        if (reply.trim().endsWith("?") && byVoice && svc != null) {
            // Нужен ответ пользователя — снова открываем панель; она начнёт слушать
            val reopen = {
                pendingReply = reply
                pendingSpoken = alreadySpoken
                try { svc.showSession(Bundle(), 0) } catch (_: Exception) { pendingReply = null; pendingSpoken = false }
            }
            if (alreadySpoken) sp.whenDone(reopen) else reopen()
            return
        }
        if (speak) { if (!alreadySpoken) sp.speak(reply, null) {} }
        else Toast.makeText(app, reply.take(300), Toast.LENGTH_LONG).show()
    }
}
