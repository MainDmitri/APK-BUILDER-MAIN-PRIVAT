package com.maindmitri.wikkeoposter

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.zIndex
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.SettingsRepository
import com.maindmitri.wikkeoposter.service.AutoScrapeStateHolder
import com.maindmitri.wikkeoposter.ui.ProductsScreen
import com.maindmitri.wikkeoposter.ui.SettingsScreen
import com.maindmitri.wikkeoposter.ui.WikkeoBrowserScreen
import com.maindmitri.wikkeoposter.ui.WikkeoPosterTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* Foreground service works regardless; permission enables visible progress notification */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestNotificationPermissionIfNeeded()
        setContent {
            WikkeoPosterTheme {
                WikkeoPosterApp()
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@Composable
private fun WikkeoPosterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settingsRepo = remember { SettingsRepository(context) }
    val dbHelper = remember { ProductDbHelper(context) }
    val batchState by AutoScrapeStateHolder.state.collectAsState()

    var settings by remember { mutableStateOf(settingsRepo.load()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var currentTab by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    fun reloadProducts() {
        scope.launch {
            products = withContext(Dispatchers.IO) { dbHelper.getAll() }
        }
    }

    fun notify(message: String) {
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
        }
    }

    LaunchedEffect(batchState.dbVersion) {
        reloadProducts()
    }

    LaunchedEffect(batchState.lastFinishedMessage) {
        if (batchState.lastFinishedMessage.isNotBlank()) {
            notify(batchState.lastFinishedMessage)
            AutoScrapeStateHolder.clearLastFinishedMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Wikkeo") },
                    label = { Text("Wikkeo") }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = {
                        currentTab = 1
                        reloadProducts()
                    },
                    icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Товары") },
                    label = { Text("Товары (${products.size})") }
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Настройки") },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Keep Wikkeo WebView mounted so switching tabs never loses page/scroll position
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .zIndex(if (currentTab == 0) 1f else 0f)
                    .alpha(if (currentTab == 0) 1f else 0f)
            ) {
                WikkeoBrowserScreen(
                    settings = settings,
                    dbHelper = dbHelper,
                    onProductsChanged = ::reloadProducts,
                    onNotify = ::notify
                )
            }
            if (currentTab == 1) {
                Box(modifier = Modifier.fillMaxSize().zIndex(2f).background(MaterialTheme.colorScheme.background)) {
                    ProductsScreen(
                        products = products,
                        settings = settings,
                        dbHelper = dbHelper,
                        onProductsChanged = ::reloadProducts,
                        onNotify = ::notify
                    )
                }
            } else if (currentTab == 2) {
                Box(modifier = Modifier.fillMaxSize().zIndex(2f).background(MaterialTheme.colorScheme.background)) {
                    SettingsScreen(
                        settings = settings,
                        onSave = { updated ->
                            settings = updated
                            settingsRepo.save(updated)
                        },
                        onNotify = ::notify
                    )
                }
            }
        }
    }
}
