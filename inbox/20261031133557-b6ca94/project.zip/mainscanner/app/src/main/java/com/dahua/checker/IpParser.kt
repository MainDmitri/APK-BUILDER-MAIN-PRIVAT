package com.dahua.checker

object IpParser {

    fun parse(input: String): List<String> {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return emptyList()

        return when {
            // CIDR takes priority — no ambiguity
            '/' in trimmed -> parseCidr(trimmed)
            // Range: X.X.X.X-Y.Y.Y.Y (full IPs) or X.X.X.A-B (last-octet shorthand)
            '-' in trimmed -> parseRange(trimmed)
            else -> parseSingle(trimmed)
        }
    }

    fun parseMultiline(text: String): List<String> {
        val result = mutableListOf<String>()
        text.lines().forEach { line ->
            val l = line.trim()
            if (l.isNotEmpty() && !l.startsWith("#")) {
                result.addAll(parse(l))
            }
        }
        return result
    }

    private fun parseSingle(ip: String): List<String> {
        return try {
            val parts = ip.split(".")
            if (parts.size != 4) return emptyList()
            parts.forEach {
                val v = it.toIntOrNull() ?: return emptyList()
                if (v < 0 || v > 255) return emptyList()
            }
            listOf(ip)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseRange(range: String): List<String> {
        return try {
            // Поддерживаем два формата:
            //   1) X.X.X.X-Y.Y.Y.Y  — полные IP с обеих сторон
            //   2) X.X.X.A-B        — последний октет: 192.168.1.1-255
            //
            // Стратегия: ищем последний дефис. Всё до него — начало, всё после — конец.
            // Если конец не содержит точек — это краткий формат последнего октета.
            val dashIdx = range.lastIndexOf('-')
            if (dashIdx < 0) return emptyList()

            val startStr = range.substring(0, dashIdx).trim()
            val endStr   = range.substring(dashIdx + 1).trim()

            val startLong = ipToLong(startStr)
            if (startLong < 0) return emptyList()

            val endLong: Long = if ('.' in endStr) {
                // Полный IP на конце
                ipToLong(endStr).also { if (it < 0) return emptyList() }
            } else {
                // Краткий формат: заменяем последний октет стартового IP
                val lastOctetEnd = endStr.toIntOrNull() ?: return emptyList()
                if (lastOctetEnd < 0 || lastOctetEnd > 255) return emptyList()
                val prefix = startStr.substringBeforeLast('.')
                ipToLong("$prefix.$lastOctetEnd").also { if (it < 0) return emptyList() }
            }

            if (startLong > endLong) return emptyList()
            val count = endLong - startLong + 1
            if (count > 65536) return emptyList()
            (startLong..endLong).map { longToIp(it) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseCidr(cidr: String): List<String> {
        return try {
            val (ipStr, prefixStr) = cidr.split("/", limit = 2).map { it.trim() }
            val prefix = prefixStr.toIntOrNull() ?: return emptyList()
            if (prefix < 0 || prefix > 32) return emptyList()
            val baseIp = ipToLong(ipStr)
            if (baseIp < 0) return emptyList()
            val mask = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
            val network = baseIp and mask
            val hostCount = 1L shl (32 - prefix)
            // Лимит 100 000 IP — совпадает с ограничением в MainActivity
            // УБРАНО ограничение prefix < 16: большие CIDR (/8, /9 ...) теперь разрешены
            if (hostCount > 100_000L) return emptyList()
            if (prefix >= 31) {
                (0 until hostCount).map { longToIp(network + it) }
            } else {
                (1 until hostCount - 1).map { longToIp(network + it) }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun ipToLong(ip: String): Long {
        val parts = ip.split(".")
        if (parts.size != 4) return -1
        var result = 0L
        for (p in parts) {
            val v = p.toIntOrNull() ?: return -1
            if (v < 0 || v > 255) return -1
            result = (result shl 8) or v.toLong()
        }
        return result
    }

    private fun longToIp(value: Long): String {
        return "${(value shr 24) and 0xFF}.${(value shr 16) and 0xFF}.${(value shr 8) and 0xFF}.${value and 0xFF}"
    }
}
