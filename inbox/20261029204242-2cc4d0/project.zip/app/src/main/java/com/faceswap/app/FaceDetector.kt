package com.faceswap.app

import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import ai.onnxruntime.*
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Детектор лиц на базе RetinaFace (det_10g.onnx от InsightFace buffalo_l).
 * Возвращает список прямоугольников лиц и 5 ключевых точек (landmark) для каждого.
 */
class FaceDetector(modelPath: String) : AutoCloseable {

    private val TAG = "FaceDetector"
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    // Входной размер модели RetinaFace det_10g
    private val INPUT_SIZE = 640

    data class Face(
        val bbox: RectF,           // координаты в пикселях оригинального изображения
        val landmarks: FloatArray, // 10 чисел: 5 точек x,y (глаза, нос, углы рта)
        val score: Float
    )

    init {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            addNnapi()   // GPU/NPU через Android NNAPI если доступен
        }
        session = env.createSession(modelPath, opts)
        Log.d(TAG, "Модель загружена: $modelPath")
    }

    fun detect(bitmap: Bitmap): List<Face> {
        val (resized, scale) = resizeWithPad(bitmap, INPUT_SIZE)
        val inputTensor = bitmapToTensor(resized)

        val inputs = mapOf(session.inputNames.first() to inputTensor)
        val results = session.run(inputs)

        val faces = parseOutput(results, scale, bitmap.width, bitmap.height)

        inputTensor.close()
        results.close()

        return faces.sortedByDescending { it.score }
    }

    /** Масштабирует bitmap с сохранением пропорций, добавляя серые поля. */
    private fun resizeWithPad(src: Bitmap, targetSize: Int): Pair<Bitmap, Float> {
        val scale = min(targetSize.toFloat() / src.width, targetSize.toFloat() / src.height)
        val newW = (src.width * scale).toInt()
        val newH = (src.height * scale).toInt()

        val padded = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(padded)
        canvas.drawColor(android.graphics.Color.rgb(114, 114, 114)) // серый фон
        val scaled = Bitmap.createScaledBitmap(src, newW, newH, true)
        canvas.drawBitmap(scaled, ((targetSize - newW) / 2).toFloat(), ((targetSize - newH) / 2).toFloat(), null)
        scaled.recycle()

        return Pair(padded, scale)
    }

    private fun bitmapToTensor(bitmap: Bitmap): OnnxTensor {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        // NCHW, BGR, нормализация: [0,255] без деления
        val floatBuf = FloatBuffer.allocate(1 * 3 * h * w)
        val r = FloatArray(h * w)
        val g = FloatArray(h * w)
        val b = FloatArray(h * w)
        for (i in pixels.indices) {
            val px = pixels[i]
            b[i] = (px and 0xFF).toFloat()
            g[i] = ((px shr 8) and 0xFF).toFloat()
            r[i] = ((px shr 16) and 0xFF).toFloat()
        }
        floatBuf.put(b)
        floatBuf.put(g)
        floatBuf.put(r)
        floatBuf.rewind()

        return OnnxTensor.createTensor(
            env,
            floatBuf,
            longArrayOf(1, 3, h.toLong(), w.toLong())
        )
    }

    /**
     * Разбирает выход RetinaFace det_10g.
     * Выходы: scores (N,1), bboxes (N,4), kps (N,10)
     */
    private fun parseOutput(
        results: OrtSession.Result,
        scale: Float,
        origW: Int,
        origH: Int
    ): List<Face> {
        val INPUT_SIZE_F = INPUT_SIZE.toFloat()
        val padX = (INPUT_SIZE - origW * scale) / 2f
        val padY = (INPUT_SIZE - origH * scale) / 2f

        // имена выходов det_10g: "score_8","score_16","score_32","bbox_8","bbox_16","bbox_32","kps_8","kps_16","kps_32"
        // Собираем все bbox/score/kps со страйдами 8,16,32
        val faces = mutableListOf<Face>()
        val strides = listOf(8, 16, 32)

        for (stride in strides) {
            val scores = results.get("score_$stride").orElse(null)
                ?: results.get("score${stride}").orElse(null)
                ?: continue
            val bboxes = results.get("bbox_$stride").orElse(null)
                ?: results.get("bbox${stride}").orElse(null)
                ?: continue
            val kps = results.get("kps_$stride").orElse(null)
                ?: results.get("kps${stride}").orElse(null)

            val scoreArr = (scores.value as Array<*>).flatMap { row ->
                (row as FloatArray).toList()
            }
            val bboxArr = bboxes.value as Array<FloatArray>
            val kpsArr = kps?.let { (it.value as Array<FloatArray>) }

            val fW = INPUT_SIZE / stride
            val fH = INPUT_SIZE / stride

            for (i in scoreArr.indices) {
                val sc = scoreArr[i]
                if (sc < 0.5f) continue

                val anchorX = (i % fW) * stride + stride / 2f
                val anchorY = (i / fW) * stride + stride / 2f

                val row = bboxArr[i]
                val x1 = (anchorX - row[0] * stride - padX) / scale
                val y1 = (anchorY - row[1] * stride - padY) / scale
                val x2 = (anchorX + row[2] * stride - padX) / scale
                val y2 = (anchorY + row[3] * stride - padY) / scale

                val bbox = RectF(
                    x1.coerceIn(0f, origW.toFloat()),
                    y1.coerceIn(0f, origH.toFloat()),
                    x2.coerceIn(0f, origW.toFloat()),
                    y2.coerceIn(0f, origH.toFloat())
                )

                val landmarks = if (kpsArr != null) {
                    val kRow = kpsArr[i]
                    FloatArray(10) { j ->
                        val v = kRow[j]
                        if (j % 2 == 0) {
                            ((anchorX + v * stride - padX) / scale).coerceIn(0f, origW.toFloat())
                        } else {
                            ((anchorY + v * stride - padY) / scale).coerceIn(0f, origH.toFloat())
                        }
                    }
                } else FloatArray(10)

                faces.add(Face(bbox, landmarks, sc))
            }
        }

        return nms(faces, 0.4f)
    }

    private fun nms(faces: List<Face>, iouThreshold: Float): List<Face> {
        val sorted = faces.sortedByDescending { it.score }.toMutableList()
        val keep = mutableListOf<Face>()
        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            keep.add(best)
            sorted.removeAll { iou(it.bbox, best.bbox) > iouThreshold }
        }
        return keep
    }

    private fun iou(a: RectF, b: RectF): Float {
        val ix1 = max(a.left, b.left)
        val iy1 = max(a.top, b.top)
        val ix2 = min(a.right, b.right)
        val iy2 = min(a.bottom, b.bottom)
        val inter = max(0f, ix2 - ix1) * max(0f, iy2 - iy1)
        val union = (a.width() * a.height()) + (b.width() * b.height()) - inter
        return if (union <= 0f) 0f else inter / union
    }

    override fun close() {
        session.close()
        env.close()
    }
}
