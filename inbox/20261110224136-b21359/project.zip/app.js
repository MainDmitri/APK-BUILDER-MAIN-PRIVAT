let count = parseInt(localStorage.getItem('count') || '0', 10);
const counterEl = document.getElementById('counter');
function updateCount(val) {
  count = val;
  counterEl.textContent = count;
  localStorage.setItem('count', count.toString());
}
updateCount(count);
document.getElementById('btn-inc').onclick = () => updateCount(count + 1);
document.getElementById('btn-dec').onclick = () => updateCount(count - 1);
document.getElementById('btn-reset').onclick = () => updateCount(0);

const notesKey = 'appbuilder_demo_notes';
let notes = JSON.parse(localStorage.getItem(notesKey) || '["Привет от AppBuilder!", "Всё работает быстро и оффлайн"]');
const listEl = document.getElementById('notes-list');
const inputEl = document.getElementById('note-input');
function renderNotes() {
  listEl.innerHTML = '';
  notes.forEach((text, i) => {
    const li = document.createElement('li');
    li.innerHTML = `<span>${text}</span><button class="del-btn" onclick="delNote(${i})">✕</button>`;
    listEl.appendChild(li);
  });
  localStorage.setItem(notesKey, JSON.stringify(notes));
}
window.delNote = (i) => { notes.splice(i, 1); renderNotes(); };
document.getElementById('btn-add').onclick = () => {
  const v = inputEl.value.trim();
  if (!v) return;
  notes.push(v);
  inputEl.value = '';
  renderNotes();
};
renderNotes();