package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class VkResult(
    val success: Boolean,
    val postId: Long? = null,
    val warning: String = "",
    val error: String = ""
)

object VkClient {

    private const val API_VERSION = "5.199"

    /**
     * Accepts "243648198", "-243648198", "club243648198", "public243648198", or "https://vk.ru/club243648198".
     * Returns positive numeric group ID or null.
     */
    fun normalizeGroupId(raw: String): Long? {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return null
        val digits = Regex("(?:club|public|event)?-?(\\d{4,15})", RegexOption.IGNORE_CASE)
            .find(trimmed)
            ?.groupValues
            ?.get(1)
        return digits?.toLongOrNull()?.takeIf { it > 0 }
    }

    fun stripHtmlForVk(html: String): String = html
        .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
        .replace(Regex("<[^>]+>"), "")
        .replace("&amp;", "&")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&nbsp;", " ")
        .lines()
        .filterNot { it.contains("wikkeo.com", ignoreCase = true) }
        .joinToString("\n")
        .trim()

    fun adaptTextForVk(rawHtmlOrPlain: String, settings: AppSettings): String {
        val plain = stripHtmlForVk(rawHtmlOrPlain)
        val lines = plain.lines().toMutableList()
        val vkContact = settings.vkOrderContact.trim()
        val vkBuyUrl = settings.resolveVkBuyUrl()
        val vkBtnText = settings.vkBuyButtonText.trim().ifEmpty { "🛒 Купить" }

        // Replace existing Telegram "📩 Для заказа: ..." line with VK contact if configured
        val contactIdx = lines.indexOfFirst {
            it.contains("Для заказа", ignoreCase = true) || it.startsWith("📩")
        }
        if (vkContact.isNotBlank()) {
            val newContactLine = "📩 Для заказа: $vkContact"
            if (contactIdx >= 0) lines[contactIdx] = newContactLine
            else lines.add(newContactLine)
        } else if (contactIdx >= 0 && settings.orderContact.isNotBlank() &&
            lines[contactIdx].contains(settings.orderContact, ignoreCase = true)
        ) {
            // Remove Telegram-only username when posting to VK if VK contact isn't set
            lines.removeAt(contactIdx)
        }

        // Insert clickable VK buy link before hashtags (if not already present)
        if (vkBuyUrl != null && vkBuyUrl.isNotBlank() && lines.none { it.contains(vkBuyUrl, ignoreCase = true) }) {
            val buyLine = "$vkBtnText: $vkBuyUrl"
            val hashIdx = lines.indexOfFirst { it.trim().startsWith("#") }
            if (hashIdx >= 0) {
                lines.add(hashIdx, buyLine)
            } else {
                lines.add(buyLine)
            }
        }
        val joined = lines.joinToString("\n").trim()
        return AiClient.injectAbkhaziaLineIfOrderPresent(joined, settings.abkhaziaOrderLine, asHtml = false) ?: joined
    }

    suspend fun fetchRecentWallTexts(settings: AppSettings): List<String> =
        withContext(Dispatchers.IO) {
            val token = settings.vkAccessToken.trim()
            val groupId = normalizeGroupId(settings.vkGroupId) ?: return@withContext emptyList()
            if (token.isBlank()) return@withContext emptyList()
            val (ok, body) = callVkMethod(
                method = "wall.get",
                token = token,
                params = mapOf("owner_id" to "-$groupId", "count" to "60")
            )
            if (!ok) return@withContext emptyList()
            runCatching {
                val items = JSONObject(body).getJSONObject("response").optJSONArray("items")
                    ?: return@runCatching emptyList<String>()
                val out = mutableListOf<String>()
                for (i in 0 until items.length()) {
                    val t = items.getJSONObject(i).optString("text", "").trim()
                    if (t.isNotBlank()) out.add(t)
                }
                out
            }.getOrDefault(emptyList())
        }

    suspend fun testConnection(tokenRaw: String, groupRaw: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val token = tokenRaw.trim()
            val groupId = normalizeGroupId(groupRaw)
            if (token.isBlank()) return@withContext false to "Укажи VK Access Token"
            if (groupId == null) return@withContext false to "Укажи ID сообщества (например, 243648198)"

            val res = callVkMethod(
                method = "groups.getById",
                token = token,
                params = mapOf("group_id" to groupId.toString())
            )
            if (!res.first) return@withContext false to "Ошибка ВК: ${res.second}"

            val name = runCatching {
                val root = JSONObject(res.second).getJSONObject("response")
                val groups = root.optJSONArray("groups")
                if (groups != null && groups.length() > 0) {
                    groups.getJSONObject(0).optString("name", "club$groupId")
                } else {
                    "club$groupId"
                }
            }.getOrDefault("club$groupId")

            // Check if photo upload is allowed by this token (error 27 = community token)
            val uploadCheck = callVkMethod(
                method = "photos.getWallUploadServer",
                token = token,
                params = mapOf("group_id" to groupId.toString())
            )
            if (uploadCheck.first) {
                true to "Готово! Сообщество «$name» подключено (постинг с фото доступен)."
            } else if (uploadCheck.second.contains("27") || uploadCheck.second.contains("group auth", ignoreCase = true)) {
                true to "Сообщество «$name» подключено (ключ сообщества: доступен только текст; для фото нужен пользовательский токен админа)."
            } else {
                true to "Сообщество «$name» найдено. Примечание по фото: ${uploadCheck.second}"
            }
        }

    suspend fun publishProduct(product: Product, settings: AppSettings): VkResult =
        withContext(Dispatchers.IO) {
            val token = settings.vkAccessToken.trim()
            val groupId = normalizeGroupId(settings.vkGroupId)
            if (token.isBlank() || groupId == null) {
                return@withContext VkResult(
                    success = false,
                    error = "Заполни VK Token и ID сообщества в Настройках"
                )
            }

            val rawText = product.generatedPost.ifBlank {
                AiClient.assembleTelegramPost(
                    AiClient.buildFallbackBody(product),
                    product,
                    settings
                )
            }
            val vkMessage = adaptTextForVk(rawText, settings)
            val photoFiles = product.localImages
                .map { File(it) }
                .filter { it.exists() && it.length() > 0 }
                .take(settings.maxPhotosPerPost.coerceIn(1, 10))

            publishWithFiles(token, groupId, vkMessage, photoFiles)
        }

    suspend fun publishMigratedTelegramPost(
        plainText: String,
        remoteImageUrls: List<String>,
        cacheDir: File,
        settings: AppSettings
    ): VkResult = withContext(Dispatchers.IO) {
        val token = settings.vkAccessToken.trim()
        val groupId = normalizeGroupId(settings.vkGroupId)
        if (token.isBlank() || groupId == null) {
            return@withContext VkResult(
                success = false,
                error = "Заполни VK Token и ID сообщества в Настройках"
            )
        }

        val tempDir = File(cacheDir, "vk_migrate_${UUID.randomUUID().toString().take(8)}")
        val files = try {
            if (remoteImageUrls.isNotEmpty()) {
                ImageDownloader.downloadProductImages(
                    imageUrls = remoteImageUrls,
                    refererUrl = "https://t.me/",
                    targetDir = tempDir,
                    maxPhotos = settings.maxPhotosPerPost.coerceIn(1, 10),
                    removeWatermarks = settings.removeWatermarks
                ).map { File(it) }
            } else {
                emptyList()
            }
        } catch (_: Exception) {
            emptyList()
        }

        try {
            publishWithFiles(token, groupId, adaptTextForVk(plainText, settings), files)
        } finally {
            runCatching { tempDir.deleteRecursively() }
        }
    }

    private fun publishWithFiles(
        token: String,
        groupId: Long,
        message: String,
        photoFiles: List<File>
    ): VkResult {
        val attachments = mutableListOf<String>()
        var photoWarning = ""

        if (photoFiles.isNotEmpty()) {
            val uploadServerRes = callVkMethod(
                method = "photos.getWallUploadServer",
                token = token,
                params = mapOf("group_id" to groupId.toString())
            )
            if (uploadServerRes.first) {
                val uploadUrl = runCatching {
                    JSONObject(uploadServerRes.second)
                        .getJSONObject("response")
                        .getString("upload_url")
                }.getOrNull()

                if (!uploadUrl.isNullOrBlank()) {
                    for (file in photoFiles) {
                        val attach = uploadSingleWallPhoto(token, groupId, uploadUrl, file)
                        if (attach != null) attachments.add(attach)
                    }
                }
            } else {
                photoWarning = if (uploadServerRes.second.contains("27") ||
                    uploadServerRes.second.contains("group auth", ignoreCase = true)
                ) {
                    "Опубликовано без фото: ключ сообщества ВК не поддерживает загрузку фото на стену (нужен user token админа)."
                } else {
                    "Фото не загружены: ${uploadServerRes.second}"
                }
            }
        }

        val postParams = linkedMapOf(
            "owner_id" to "-$groupId",
            "from_group" to "1",
            "message" to message
        )
        if (attachments.isNotEmpty()) {
            postParams["attachments"] = attachments.joinToString(",")
        }

        val postRes = callVkMethod("wall.post", token, postParams)
        if (!postRes.first) {
            return VkResult(success = false, error = postRes.second)
        }
        val postId = runCatching {
            JSONObject(postRes.second).getJSONObject("response").optLong("post_id").takeIf { it > 0 }
        }.getOrNull()

        return VkResult(success = true, postId = postId, warning = photoWarning)
    }

    private fun uploadSingleWallPhoto(
        token: String,
        groupId: Long,
        uploadUrl: String,
        file: File
    ): String? {
        val uploadJson = uploadFileMultipart(uploadUrl, "photo", file) ?: return null
        val server = uploadJson.optString("server", "")
        val photo = uploadJson.optString("photo", "")
        val hash = uploadJson.optString("hash", "")
        if (server.isBlank() || photo.isBlank() || photo == "[]" || hash.isBlank()) return null

        val saveRes = callVkMethod(
            method = "photos.saveWallPhoto",
            token = token,
            params = mapOf(
                "group_id" to groupId.toString(),
                "server" to server,
                "photo" to photo,
                "hash" to hash
            )
        )
        if (!saveRes.first) return null
        return runCatching {
            val arr = JSONObject(saveRes.second).getJSONArray("response")
            if (arr.length() == 0) return null
            val item = arr.getJSONObject(0)
            "photo${item.getLong("owner_id")}_${item.getLong("id")}"
        }.getOrNull()
    }

    private fun callVkMethod(
        method: String,
        token: String,
        params: Map<String, String>
    ): Pair<Boolean, String> {
        var last = false to "Ошибка VK"
        for (attempt in 0 until 3) {
            last = callVkMethodOnce(method, token, params)
            if (last.first) return last
            val isTransient = last.second.contains("VK #6:") ||
                last.second.contains("VK #10:") ||
                last.second.contains("VK HTTP 5") ||
                last.second.contains("Сетевая ошибка", ignoreCase = true)
            if (!isTransient || attempt == 2) return last
            runCatching { Thread.sleep(1500L * (attempt + 1)) }
        }
        return last
    }

    private fun callVkMethodOnce(
        method: String,
        token: String,
        params: Map<String, String>
    ): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            val allParams = LinkedHashMap<String, String>(params)
            allParams["access_token"] = token
            allParams["v"] = API_VERSION

            val formBody = allParams.entries.joinToString("&") { (k, v) ->
                "${URLEncoder.encode(k, "UTF-8")}=${URLEncoder.encode(v, "UTF-8")}"
            }

            conn = (URL("https://api.vk.com/method/$method").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15_000
                readTimeout = 30_000
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            }
            conn.outputStream.use { it.write(formBody.toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
            if (code !in 200..299) return false to "VK HTTP $code"

            val json = JSONObject(body)
            if (json.has("error")) {
                val err = json.getJSONObject("error")
                val errCode = err.optInt("error_code", 0)
                val errMsg = err.optString("error_msg", "Неизвестная ошибка VK")
                return false to "VK #$errCode: $errMsg"
            }
            true to body
        } catch (e: Exception) {
            false to "Сетевая ошибка VK: ${e.message ?: "неизвестно"}"
        } finally {
            conn?.disconnect()
        }
    }

    private fun uploadFileMultipart(urlStr: String, fieldName: String, file: File): JSONObject? {
        val boundary = "----VkUpload${UUID.randomUUID().toString().replace("-", "")}"
        val crlf = "\r\n"
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }
            DataOutputStream(conn.outputStream).use { out ->
                out.writeBytes("--$boundary$crlf")
                out.writeBytes("Content-Disposition: form-data; name=\"$fieldName\"; filename=\"${file.name}\"$crlf")
                out.writeBytes("Content-Type: image/jpeg$crlf$crlf")
                file.inputStream().use { it.copyTo(out) }
                out.writeBytes(crlf)
                out.writeBytes("--$boundary--$crlf")
                out.flush()
            }
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
