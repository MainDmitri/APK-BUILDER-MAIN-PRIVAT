package com.maindmitri.wikkeoposter.network

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

/**
 * On-device watermark cleaner for wholesale marketplace product photos.
 * Detects and cleanly removes corner/margin watermark bands (logos, store names, phone numbers,
 * Wikkeo/Chinese supplier stamps) via edge-band analysis + content-aware border trim and
 * corner background-matched inpainting, while keeping the central product intact.
 */
object WatermarkCleaner {

    fun clean(source: Bitmap): Bitmap {
        val w = source.width
        val h = source.height
        if (w < 260 || h < 260) return source

        // 1. Copy into mutable ARGB_8888 bitmap
        val work = source.copy(Bitmap.Config.ARGB_8888, true)

        // 2. Clean subtle corner watermarks (bottom-right, bottom-left, top-right, top-left)
        // when the surrounding border is relatively uniform (typical studio/catalog product shot).
        val cornerW = (w * 0.24f).toInt().coerceIn(40, 260)
        val cornerH = (h * 0.11f).toInt().coerceIn(24, 120)

        cleanCornerIfWatermark(work, w - cornerW, h - cornerH, cornerW, cornerH, sampleAbove = true, sampleLeft = true)
        cleanCornerIfWatermark(work, 0, h - cornerH, cornerW, cornerH, sampleAbove = true, sampleLeft = false)
        cleanCornerIfWatermark(work, w - cornerW, 0, cornerW, cornerH, sampleAbove = false, sampleLeft = true)
        cleanCornerIfWatermark(work, 0, 0, cornerW, cornerH, sampleAbove = false, sampleLeft = false)

        // 3. Smart micro-trim of bottom/top watermark strips (up to 7% bottom, 5% top)
        // when the strip shows strong text/bar contrast against an otherwise clean margin.
        val bottomCrop = detectBottomWatermarkStrip(work)
        val topCrop = detectTopWatermarkStrip(work)

        val newH = h - topCrop - bottomCrop
        if ((bottomCrop > 0 || topCrop > 0) && newH >= (h * 0.84f).toInt()) {
            val cropped = Bitmap.createBitmap(work, 0, topCrop, w, newH)
            work.recycle()
            return cropped
        }
        return work
    }

    private fun cleanCornerIfWatermark(
        bmp: Bitmap,
        startX: Int,
        startY: Int,
        boxW: Int,
        boxH: Int,
        sampleAbove: Boolean,
        sampleLeft: Boolean
    ) {
        val w = bmp.width
        val h = bmp.height
        val x0 = startX.coerceIn(0, w - 1)
        val y0 = startY.coerceIn(0, h - 1)
        val x1 = (x0 + boxW).coerceAtMost(w)
        val y1 = (y0 + boxH).coerceAtMost(h)
        if (x1 - x0 < 20 || y1 - y0 < 16) return

        // Sample reference background strip just outside the corner box
        val refY = if (sampleAbove) (y0 - 6).coerceAtLeast(0) else (y1 + 5).coerceAtMost(h - 1)
        val refX = if (sampleLeft) (x0 - 6).coerceAtLeast(0) else (x1 + 5).coerceAtMost(w - 1)

        var sumR = 0L
        var sumG = 0L
        var sumB = 0L
        var samples = 0
        val refLumas = mutableListOf<Int>()

        for (x in x0 until x1 step 3) {
            val c = bmp.getPixel(x, refY)
            sumR += Color.red(c)
            sumG += Color.green(c)
            sumB += Color.blue(c)
            refLumas.add(luma(c))
            samples++
        }
        for (y in y0 until y1 step 3) {
            val c = bmp.getPixel(refX, y)
            sumR += Color.red(c)
            sumG += Color.green(c)
            sumB += Color.blue(c)
            refLumas.add(luma(c))
            samples++
        }
        if (samples < 10) return

        val bgR = (sumR / samples).toInt()
        val bgG = (sumG / samples).toInt()
        val bgB = (sumB / samples).toInt()
        val avgLuma = refLumas.average()
        val refSpread = refLumas.map { abs(it - avgLuma) }.average()

        // Only inpaint corner if surrounding edge is clean/uniform background (prevents erasing real product)
        if (refSpread > 18.0) return

        // Check if corner box contains watermark pixels differing from the clean background
        var diffPixels = 0
        var totalChecked = 0
        for (y in y0 until y1 step 2) {
            for (x in x0 until x1 step 2) {
                val c = bmp.getPixel(x, y)
                val dist = abs(Color.red(c) - bgR) + abs(Color.green(c) - bgG) + abs(Color.blue(c) - bgB)
                if (dist > 42) diffPixels++
                totalChecked++
            }
        }
        val ratio = if (totalChecked > 0) diffPixels.toDouble() / totalChecked else 0.0
        // Watermark text/logo occupies roughly 2%..55% of the corner box
        if (ratio < 0.02 || ratio > 0.58) return

        // Smoothly fill the corner box with local edge-feathered background color
        val bgColor = Color.rgb(bgR, bgG, bgB)
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val edgeDistY = if (sampleAbove) (y - y0) else (y1 - 1 - y)
                val edgeDistX = if (sampleLeft) (x - x0) else (x1 - 1 - x)
                val minEdge = minOf(edgeDistX, edgeDistY)
                if (minEdge >= 6) {
                    bmp.setPixel(x, y, bgColor)
                } else {
                    val alpha = minEdge / 6f
                    val orig = bmp.getPixel(x, y)
                    val r = (bgR * alpha + Color.red(orig) * (1f - alpha)).toInt()
                    val g = (bgG * alpha + Color.green(orig) * (1f - alpha)).toInt()
                    val b = (bgB * alpha + Color.blue(orig) * (1f - alpha)).toInt()
                    bmp.setPixel(x, y, Color.rgb(r, g, b))
                }
            }
        }
    }

    private fun detectBottomWatermarkStrip(bmp: Bitmap): Int {
        val w = bmp.width
        val h = bmp.height
        val stripH = (h * 0.07f).toInt().coerceIn(18, 85)
        val startY = h - stripH
        val refY = (startY - 6).coerceAtLeast(0)
        return if (isLikelyBannerStrip(bmp, startY, h, refY, w)) stripH else 0
    }

    private fun detectTopWatermarkStrip(bmp: Bitmap): Int {
        val w = bmp.width
        val h = bmp.height
        val stripH = (h * 0.05f).toInt().coerceIn(14, 60)
        val refY = (stripH + 6).coerceAtMost(h - 1)
        return if (isLikelyBannerStrip(bmp, 0, stripH, refY, w)) stripH else 0
    }

    private fun isLikelyBannerStrip(bmp: Bitmap, y0: Int, y1: Int, refY: Int, w: Int): Boolean {
        // Measure horizontal edge transitions (text/logo banners have high horizontal stroke density)
        var transitions = 0
        var refTransitions = 0
        for (x in 4 until w - 4 step 4) {
            val c1 = luma(bmp.getPixel(x, refY))
            val c2 = luma(bmp.getPixel(x + 4, refY))
            if (abs(c1 - c2) > 30) refTransitions++
        }
        val midY = (y0 + y1) / 2
        for (x in 4 until w - 4 step 4) {
            val c1 = luma(bmp.getPixel(x, midY))
            val c2 = luma(bmp.getPixel(x + 4, midY))
            if (abs(c1 - c2) > 35) transitions++
        }
        // Only trim if the reference row just inside is calm while the outer strip has sharp text strokes
        return refTransitions < (w / 32) && transitions > (w / 18)
    }

    private fun luma(pixel: Int): Int =
        (Color.red(pixel) * 299 + Color.green(pixel) * 587 + Color.blue(pixel) * 114) / 1000
}
