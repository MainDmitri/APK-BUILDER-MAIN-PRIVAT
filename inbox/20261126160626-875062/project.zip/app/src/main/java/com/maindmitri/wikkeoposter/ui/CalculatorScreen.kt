package com.maindmitri.wikkeoposter.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.network.AiClient
import kotlin.math.ceil
import kotlin.math.roundToInt

private val QTY_PRESETS = listOf(1, 5, 10, 20, 50, 100)
private val MARKUP_PRESETS = listOf(20, 35, 50, 75, 100)
private val ROUND_OPTIONS = listOf(10 to "до 10₽", 50 to "до 50₽", 90 to "…90₽")

@Composable
fun CalculatorScreen(
    products: List<Product>,
    settings: AppSettings,
    onApplyMarkupToSettings: (markupPercent: Double, roundTo: Int) -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current

    // Mode: 0 = По наценке %, 1 = По своей цене продажи
    var calcMode by remember { mutableIntStateOf(0) }
    var selectedProductName by remember { mutableStateOf("") }

    var wholesaleText by remember { mutableStateOf("1000") }
    var quantityText by remember { mutableStateOf("10") }
    var deliveryTotalText by remember { mutableStateOf("1500") }
    var packPerUnitText by remember { mutableStateOf("30") }
    var defectPercentText by remember { mutableStateOf("3") }
    var extraFeePercentText by remember { mutableStateOf("0") }

    var markupPercentText by remember(settings.markupPercent) {
        mutableStateOf(settings.markupPercent.roundToInt().coerceAtLeast(1).toString())
    }
    var customSellPriceText by remember { mutableStateOf("1890") }
    var roundRule by remember { mutableIntStateOf(10) } // 10, 50, or 90 (psychological ...90₽)

    val wholesale = wholesaleText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val qty = (quantityText.toIntOrNull() ?: 1).coerceAtLeast(1)
    val deliveryTotal = deliveryTotalText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val packPerUnit = packPerUnitText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val defectPct = (defectPercentText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 50.0)
    val feePct = (extraFeePercentText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 50.0)
    val markupPct = (markupPercentText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0)

    val deliveryPerUnit = deliveryTotal / qty.toDouble()
    val defectReservePerUnit = wholesale * (defectPct / 100.0)
    val unitCost = wholesale + deliveryPerUnit + packPerUnit + defectReservePerUnit

    fun applyRounding(rawPrice: Double): Int {
        if (rawPrice <= 0.0) return 0
        return when (roundRule) {
            90 -> {
                val baseHundred = ((rawPrice / 100.0).roundToInt() * 100).coerceAtLeast(100)
                (baseHundred - 10).coerceAtLeast(10)
            }
            50 -> ((rawPrice / 50.0).roundToInt() * 50).coerceAtLeast(50)
            else -> ((rawPrice / 10.0).roundToInt() * 10).coerceAtLeast(10)
        }
    }

    val sellPricePerUnit: Int = if (calcMode == 0) {
        applyRounding(unitCost * (1.0 + markupPct / 100.0))
    } else {
        customSellPriceText.toIntOrNull()?.coerceAtLeast(0) ?: 0
    }

    val feePerUnit = sellPricePerUnit * (feePct / 100.0)
    val netProfitPerUnit = sellPricePerUnit - unitCost - feePerUnit
    val marginPct = if (sellPricePerUnit > 0) (netProfitPerUnit / sellPricePerUnit) * 100.0 else 0.0
    val roiPct = if (unitCost > 0) (netProfitPerUnit / unitCost) * 100.0 else 0.0

    val totalInvestment = unitCost * qty
    val totalRevenue = sellPricePerUnit.toDouble() * qty
    val totalNetProfit = netProfitPerUnit * qty
    val breakEvenUnits = if (sellPricePerUnit - feePerUnit > 0.0) {
        ceil(totalInvestment / (sellPricePerUnit - feePerUnit)).toInt()
    } else {
        0
    }

    val recentPricedProducts = remember(products) {
        products.filter { (it.wholesalePrice ?: 0.0) > 0.0 }.take(10)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Умный калькулятор Wikkeo",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        // Quick-pick from saved Wikkeo products
        if (recentPricedProducts.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Подставить опт из сохранённых товаров:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    recentPricedProducts.forEach { prod ->
                        val wPrice = prod.wholesalePrice?.roundToInt() ?: 0
                        FilterChip(
                            selected = selectedProductName == prod.title,
                            onClick = {
                                selectedProductName = prod.title
                                wholesaleText = wPrice.toString()
                            },
                            label = {
                                Text(
                                    text = "${prod.title.take(18)} • $wPrice₽",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }
            }
        }

        // Card 1: Purchase & Logistics Inputs
        Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("1. Закупка и расходы", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wholesaleText,
                        onValueChange = { wholesaleText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Опт за 1 шт (₽)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1.2f)
                    )
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Кол-во (шт)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(0.9f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    QTY_PRESETS.forEach { q ->
                        FilterChip(
                            selected = qty == q,
                            onClick = { quantityText = q.toString() },
                            label = { Text("$q шт") }
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = deliveryTotalText,
                        onValueChange = { deliveryTotalText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Доставка партии ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = packPerUnitText,
                        onValueChange = { packPerUnitText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Упаковка / шт ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = defectPercentText,
                        onValueChange = { defectPercentText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Резерв брак %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = extraFeePercentText,
                        onValueChange = { extraFeePercentText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Комиссия/налог %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Card 2: Pricing Mode & Target Price
        Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("2. Цена продажи", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = calcMode == 0,
                        onClick = { calcMode = 0 },
                        label = { Text("По наценке %") }
                    )
                    FilterChip(
                        selected = calcMode == 1,
                        onClick = {
                            calcMode = 1
                            if (sellPricePerUnit > 0) customSellPriceText = sellPricePerUnit.toString()
                        },
                        label = { Text("Своя цена ₽") }
                    )
                }

                if (calcMode == 0) {
                    OutlinedTextField(
                        value = markupPercentText,
                        onValueChange = { markupPercentText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Желаемая наценка (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MARKUP_PRESETS.forEach { m ->
                            FilterChip(
                                selected = markupPct.roundToInt() == m,
                                onClick = { markupPercentText = m.toString() },
                                label = { Text("+$m%") }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ROUND_OPTIONS.forEach { (rule, label) ->
                            FilterChip(
                                selected = roundRule == rule,
                                onClick = { roundRule = rule },
                                label = { Text(label) }
                            )
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = customSellPriceText,
                        onValueChange = { customSellPriceText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Цена продажи в канале (₽)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Card 3: Results & Profit KPI Dashboard
        val profitColor = if (netProfitPerUnit >= 0) BrandEmerald else Color(0xFFDC2626)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("3. Итог и прибыль", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CalcKpiTile(
                        title = "Цена в посте",
                        value = AiClient.formatRub(sellPricePerUnit),
                        accent = BrandBlue,
                        modifier = Modifier.weight(1f)
                    )
                    CalcKpiTile(
                        title = "Прибыль / 1 шт",
                        value = "${if (netProfitPerUnit >= 0) "+" else ""}${AiClient.formatRub(netProfitPerUnit)}",
                        accent = profitColor,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CalcKpiTile(
                        title = "Вложения ($qty шт)",
                        value = AiClient.formatRub(totalInvestment),
                        accent = BrandAmber,
                        modifier = Modifier.weight(1f)
                    )
                    CalcKpiTile(
                        title = "Прибыль партии",
                        value = "${if (totalNetProfit >= 0) "+" else ""}${AiClient.formatRub(totalNetProfit)}",
                        accent = profitColor,
                        modifier = Modifier.weight(1f)
                    )
                }

                HorizontalDivider()

                CalcDetailRow("Себестоимость 1 шт (с доставкой и браком)", AiClient.formatRub(unitCost))
                CalcDetailRow("Доставка на 1 шт", AiClient.formatRub(deliveryPerUnit))
                CalcDetailRow("Выручка со всей партии", AiClient.formatRub(totalRevenue))
                CalcDetailRow(
                    "Маржа / ROI",
                    "${marginPct.roundToInt()}%  •  ROI ${roiPct.roundToInt()}%"
                )
                if (breakEvenUnits > 0) {
                    val statusHint = if (breakEvenUnits <= qty) {
                        "$breakEvenUnits шт из $qty (остальные ${qty - breakEvenUnits} шт — чистый плюс)"
                    } else {
                        "Не окупается при текущей цене"
                    }
                    CalcDetailRow("Точка безубыточности", statusHint)
                }
            }
        }

        // Card 4: 3 Price Strategy Comparison
        if (unitCost > 0) {
            Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Сравнение стратегий цены",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    listOf(
                        Triple("Быстрый оборот (+30%)", 30.0, BrandAmber),
                        Triple("Оптимальная (+50%)", 50.0, BrandBlue),
                        Triple("Высокая маржа (+80%)", 80.0, BrandEmerald)
                    ).forEach { (label, pct, accent) ->
                        val p = applyRounding(unitCost * (1.0 + pct / 100.0))
                        val batchProfit = (p - unitCost - p * (feePct / 100.0)) * qty
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(label, style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "${AiClient.formatRub(p)}  (→ +${AiClient.formatRub(batchProfit)})",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = accent
                            )
                        }
                    }
                }
            }
        }

        // Actions: Apply markup to AppSettings + Copy Calculation
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val effectiveMarkup = if (calcMode == 0) {
                        markupPct
                    } else if (wholesale > 0) {
                        ((sellPricePerUnit - wholesale) / wholesale * 100.0).coerceAtLeast(0.0)
                    } else {
                        20.0
                    }
                    val targetRound = if (roundRule == 90) 10 else roundRule
                    onApplyMarkupToSettings(effectiveMarkup, targetRound)
                    onNotify("Наценка ${effectiveMarkup.roundToInt()}% применена для автосбора и постов!")
                },
                modifier = Modifier.weight(1.2f)
            ) {
                Text("Применить в автосбор", maxLines = 1)
            }
            OutlinedButton(
                onClick = {
                    val report = buildString {
                        if (selectedProductName.isNotBlank()) appendLine("Товар: $selectedProductName")
                        appendLine("Опт Wikkeo: ${AiClient.formatRub(wholesale)} × $qty шт")
                        appendLine("Себестоимость 1 шт: ${AiClient.formatRub(unitCost)}")
                        appendLine("Цена продажи: ${AiClient.formatRub(sellPricePerUnit)}")
                        appendLine("Вложения: ${AiClient.formatRub(totalInvestment)}")
                        appendLine("Чистая прибыль с партии: ${AiClient.formatRub(totalNetProfit)} (ROI ${roiPct.roundToInt()}%)")
                    }.trim()
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Wikkeo Calc", report))
                    onNotify("Расчёт скопирован в буфер обмена")
                },
                modifier = Modifier.weight(0.9f)
            ) {
                Text("📋 Скопировать", maxLines = 1)
            }
        }

        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun CalcKpiTile(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = accent.copy(alpha = 0.12f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = accent)
            Spacer(Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CalcDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold
        )
    }
}
