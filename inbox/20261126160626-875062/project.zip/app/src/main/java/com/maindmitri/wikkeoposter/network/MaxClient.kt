package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class MaxResult(
    val success: Boolean,
    val messageId: String? = null,
    val error: String = ""
)

data class MaxChatInfo(
    val chatId: Long,
    val title: String,
    val type: String
)

data class MaxChannelMessage(
    val mid: String,
    val text: String,
    val timestamp: Long
)

object MaxClient {

    private const val BASE_URL = "https://platform-api2.max.ru"

    private val maxSslSocketFactory by lazy {
        val trustManager = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
        ctx.socketFactory
    }

    private fun openMaxConnection(urlStr: String): HttpURLConnection {
        val conn = URL(urlStr).openConnection() as HttpURLConnection
        if (conn is HttpsURLConnection) {
            conn.sslSocketFactory = maxSslSocketFactory
        }
        return conn
    }


    fun adaptHtmlForMax(rawHtml: String, settings: AppSettings): String {
        val lines = rawHtml
            .lines()
            .filterNot { it.contains("wikkeo.com", ignoreCase = true) }
            .toMutableList()
        val maxContact = settings.maxOrderContact.trim()
        val contactIdx = lines.indexOfFirst {
            it.contains("Для заказа", ignoreCase = true) || it.startsWith("📩")
        }
        if (maxContact.isNotBlank()) {
            val newLine = "📩 <b>Для заказа:</b> ${AiClient.escapeHtml(maxContact)}"
            if (contactIdx >= 0) lines[contactIdx] = newLine
            else {
                val hashIdx = lines.indexOfFirst { it.trim().startsWith("#") }
                if (hashIdx >= 0) lines.add(hashIdx, newLine) else lines.add(newLine)
            }
        } else if (contactIdx >= 0 && settings.orderContact.isNotBlank() &&
            lines[contactIdx].contains(settings.orderContact, ignoreCase = true)
        ) {
            lines.removeAt(contactIdx)
        }
        val joined = lines.joinToString("\n").trim()
        val withAbh = AiClient.injectAbkhaziaLineIfOrderPresent(joined, settings.abkhaziaOrderLine, asHtml = true) ?: joined
        return withAbh.take(4000)
    }

    /**
     * Fetches up to [maxMessages] recent messages (with mid + text) from the MAX channel
     * using GET /messages?chat_id=...&count=100 (with timestamp pagination).
     */
    suspend fun fetchRecentChannelMessages(
        settings: AppSettings,
        maxMessages: Int = 200
    ): List<MaxChannelMessage> = withContext(Dispatchers.IO) {
        val token = settings.maxBotToken.trim()
        val chatId = settings.maxChatId.trim().toLongOrNull() ?: return@withContext emptyList()
        if (token.isBlank()) return@withContext emptyList()

        val result = mutableListOf<MaxChannelMessage>()
        val seenMids = linkedSetOf<String>()
        var toTimestamp: Long? = null

        for (page in 0 until 3) {
            if (result.size >= maxMessages) break
            val url = buildString {
                append("$BASE_URL/messages?chat_id=$chatId&count=100")
                if (toTimestamp != null) append("&to=$toTimestamp")
            }
            val (ok, body) = requestJson("GET", url, token)
            if (!ok) break
            val batch = runCatching {
                val arr = JSONObject(body).optJSONArray("messages") ?: return@runCatching emptyList<MaxChannelMessage>()
                val out = mutableListOf<MaxChannelMessage>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val bodyObj = m.optJSONObject("body")
                    val mid = bodyObj?.optString("mid", "").orEmpty().ifBlank { m.optString("mid", "") }
                    val txt = bodyObj?.optString("text", "").orEmpty().ifBlank { m.optString("text", "") }
                    val ts = m.optLong("timestamp", 0L)
                    if (mid.isNotBlank() && txt.isNotBlank()) {
                        out.add(MaxChannelMessage(mid = mid, text = txt.trim(), timestamp = ts))
                    }
                }
                out
            }.getOrDefault(emptyList())

            if (batch.isEmpty()) break
            var addedThisPage = 0
            for (msg in batch) {
                if (seenMids.add(msg.mid)) {
                    result.add(msg)
                    addedThisPage++
                }
            }
            val oldestTs = batch.map { it.timestamp }.filter { it > 0L }.minOrNull()
            if (addedThisPage == 0 || oldestTs == null || oldestTs == toTimestamp) break
            toTimestamp = oldestTs - 1L
        }
        result
    }

    /**
     * Edits an existing MAX channel post's text via PUT /messages?message_id={mid}.
     * Omits `attachments` so existing photos and inline Buy buttons remain untouched!
     */
    suspend fun editPublishedPost(
        messageId: String,
        newText: String,
        settings: AppSettings,
        useHtml: Boolean = false
    ): MaxResult = withContext(Dispatchers.IO) {
        val token = settings.maxBotToken.trim()
        if (token.isBlank() || messageId.isBlank()) {
            return@withContext MaxResult(success = false, error = "Не указан токен MAX или message_id")
        }
        val clean = newText
            .lines()
            .filterNot { it.contains("wikkeo.com", ignoreCase = true) }
            .joinToString("\n")
            .trim()
            .take(4000)

        val payload = JSONObject().apply {
            put("text", clean)
            if (useHtml) put("format", "html")
        }.toString()

        val encodedMid = URLEncoder.encode(messageId, "UTF-8")
        val endpoint = "$BASE_URL/messages?message_id=$encodedMid"

        var lastErr = "Ошибка редактирования поста в MAX"
        for (attempt in 0 until 3) {
            val (ok, resp) = requestJson("PUT", endpoint, token, payload)
            if (ok) return@withContext MaxResult(success = true, messageId = messageId)
            lastErr = resp
            if (resp.contains("429") || resp.contains("HTTP 5") || resp.contains("Сетевая ошибка", ignoreCase = true)) {
                runCatching { Thread.sleep(1200L * (attempt + 1)) }
                continue
            }
            break
        }
        MaxResult(success = false, error = lastErr)
    }

    suspend fun fetchRecentChannelTexts(settings: AppSettings): List<String> =
        withContext(Dispatchers.IO) {
            val token = settings.maxBotToken.trim()
            val chatId = settings.maxChatId.trim().toLongOrNull() ?: return@withContext emptyList()
            if (token.isBlank()) return@withContext emptyList()
            val (ok, body) = requestJson("GET", "$BASE_URL/messages?chat_id=$chatId&count=60", token)
            if (!ok) return@withContext emptyList()
            runCatching {
                val arr = JSONObject(body).optJSONArray("messages") ?: return@runCatching emptyList<String>()
                val out = mutableListOf<String>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val txt = m.optJSONObject("body")?.optString("text", "")
                        ?: m.optString("text", "")
                    if (txt.isNotBlank()) out.add(txt.trim())
                }
                out
            }.getOrDefault(emptyList())
        }

    suspend fun fetchBotChannels(tokenRaw: String): Pair<List<MaxChatInfo>, String> =
        withContext(Dispatchers.IO) {
            val token = tokenRaw.trim()
            if (token.isBlank()) return@withContext emptyList<MaxChatInfo>() to "Сначала укажи токен бота MAX"
            val (ok, bodyOrErr) = requestJson("GET", "$BASE_URL/chats?count=50", token)
            if (!ok) return@withContext emptyList<MaxChatInfo>() to "Ошибка MAX: $bodyOrErr"

            val list = runCatching {
                val arr = JSONObject(bodyOrErr).optJSONArray("chats") ?: JSONArray()
                val out = mutableListOf<MaxChatInfo>()
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    val id = c.optLong("chat_id", 0L)
                    if (id != 0L) {
                        out.add(
                            MaxChatInfo(
                                chatId = id,
                                title = c.optString("title", "Чат $id").ifBlank { "Чат $id" },
                                type = c.optString("type", "chat")
                            )
                        )
                    }
                }
                out
            }.getOrDefault(emptyList())

            if (list.isEmpty()) {
                emptyList<MaxChatInfo>() to "Бот не состоит ни в одном канале. Добавь бота админом в канал MAX."
            } else {
                list to "Найдено чатов/каналов MAX: ${list.size}"
            }
        }

    suspend fun testConnection(tokenRaw: String, chatIdRaw: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val token = tokenRaw.trim()
            if (token.isBlank()) return@withContext false to "Укажи токен бота MAX"

            val (meOk, meBody) = requestJson("GET", "$BASE_URL/me", token)
            if (!meOk) return@withContext false to "Неверный токен MAX: $meBody"
            val botName = runCatching {
                val j = JSONObject(meBody)
                j.optString("username").ifBlank { j.optString("first_name", "MAX Bot") }
            }.getOrDefault("MAX Bot")

            val chatId = chatIdRaw.trim().toLongOrNull()
            if (chatId == null) {
                return@withContext true to "Бот @$botName работает! Теперь нажми «Найти каналы» или введи числовой chat_id."
            }

            val (chatOk, chatBody) = requestJson("GET", "$BASE_URL/chats/$chatId", token)
            if (!chatOk) {
                return@withContext false to "Бот @$botName найден, но канал $chatId недоступен: $chatBody"
            }
            val title = runCatching {
                JSONObject(chatBody).optString("title", chatId.toString())
            }.getOrDefault(chatId.toString())

            true to "Готово! Бот @$botName подключён к каналу MAX «$title»."
        }

    suspend fun publishProduct(product: Product, settings: AppSettings): MaxResult =
        withContext(Dispatchers.IO) {
            val token = settings.maxBotToken.trim()
            val chatId = settings.maxChatId.trim().toLongOrNull()
            if (token.isBlank() || chatId == null) {
                return@withContext MaxResult(
                    success = false,
                    error = "Заполни токен бота MAX и числовой ID канала в Настройках"
                )
            }

            val rawHtml = product.generatedPost.ifBlank {
                AiClient.assembleTelegramPost(
                    AiClient.buildFallbackBody(product),
                    product,
                    settings
                )
            }
            val cleanHtml = adaptHtmlForMax(rawHtml, settings)

            val photoFiles = product.localImages
                .map { File(it) }
                .filter { it.exists() && it.length() > 0 }
                .take(settings.maxPhotosPerPost.coerceIn(1, 10))

            publishWithFiles(token, chatId, cleanHtml, photoFiles, settings)
        }

    suspend fun publishMigratedTelegramPost(
        plainText: String,
        remoteImageUrls: List<String>,
        cacheDir: File,
        settings: AppSettings
    ): MaxResult = withContext(Dispatchers.IO) {
        val token = settings.maxBotToken.trim()
        val chatId = settings.maxChatId.trim().toLongOrNull()
        if (token.isBlank() || chatId == null) {
            return@withContext MaxResult(
                success = false,
                error = "Заполни токен бота MAX и ID канала в Настройках"
            )
        }

        val tempDir = File(cacheDir, "max_migrate_${UUID.randomUUID().toString().take(8)}")
        val files = try {
            if (remoteImageUrls.isNotEmpty()) {
                ImageDownloader.downloadProductImages(
                    imageUrls = remoteImageUrls,
                    refererUrl = "https://t.me/",
                    targetDir = tempDir,
                    maxPhotos = settings.maxPhotosPerPost.coerceIn(1, 10),
                    removeWatermarks = settings.removeWatermarks
                ).map { File(it) }
            } else {
                emptyList()
            }
        } catch (_: Exception) {
            emptyList()
        }

        try {
            val adapted = adaptHtmlForMax(AiClient.escapeHtml(plainText), settings)
            publishWithFiles(token, chatId, adapted, files, settings)
        } finally {
            runCatching { tempDir.deleteRecursively() }
        }
    }

    private fun publishWithFiles(
        token: String,
        chatId: Long,
        htmlText: String,
        photoFiles: List<File>,
        settings: AppSettings
    ): MaxResult {
        val attachments = JSONArray()

        // 1) Upload images via POST /uploads?type=image
        for (file in photoFiles) {
            val imageAttachment = uploadImageAttachment(token, file)
            if (imageAttachment != null) {
                attachments.put(imageAttachment)
            }
        }

        // 2) Attach inline link button "🛒 Купить" directly to the same post (supported natively by MAX!)
        val buyUrl = settings.resolveMaxBuyUrl()
        if (!buyUrl.isNullOrBlank()) {
            val btnText = settings.maxBuyButtonText.trim().ifEmpty { "🛒 Купить" }
            val btn = JSONObject()
                .put("type", "link")
                .put("text", btnText.take(64))
                .put("url", buyUrl)
            val buttons = JSONArray().put(JSONArray().put(btn))
            val keyboardAttachment = JSONObject()
                .put("type", "inline_keyboard")
                .put("payload", JSONObject().put("buttons", buttons))
            attachments.put(keyboardAttachment)
        }

        if (photoFiles.isNotEmpty()) {
            // Official MAX docs recommend a brief pause after media upload before POST /messages
            runCatching { Thread.sleep(800) }
        }

        val bodyJson = JSONObject().apply {
            put("text", htmlText)
            put("format", "html")
            put("notify", true)
            if (attachments.length() > 0) {
                put("attachments", attachments)
            }
        }.toString()

        val encodedChat = URLEncoder.encode(chatId.toString(), "UTF-8")
        val endpoint = "$BASE_URL/messages?chat_id=$encodedChat&disable_link_preview=true"

        // Retry on attachment.not.ready / 429 / 5xx as recommended by MAX Bot API docs
        var lastError = "Ошибка отправки в MAX"
        for (attempt in 0 until 4) {
            val (ok, respBody) = requestJson("POST", endpoint, token, bodyJson)
            if (ok) {
                val mid = runCatching {
                    val root = JSONObject(respBody)
                    val msgObj = root.optJSONObject("message")
                    msgObj?.optJSONObject("body")?.optString("mid")
                        ?: msgObj?.optString("mid")
                }.getOrNull()?.takeIf { it.isNotBlank() }
                return MaxResult(success = true, messageId = mid ?: "sent")
            }
            lastError = respBody
            val shouldRetry = respBody.contains("attachment.not.ready", ignoreCase = true) ||
                respBody.contains("429") ||
                respBody.contains("HTTP 5") ||
                respBody.contains("Сетевая ошибка", ignoreCase = true)
            if (!shouldRetry || attempt == 3) break
            runCatching { Thread.sleep(1500L * (attempt + 1)) }
        }
        return MaxResult(success = false, error = lastError)
    }

    private fun uploadImageAttachment(token: String, file: File): JSONObject? {
        val (ok, uploadInfo) = requestJson("POST", "$BASE_URL/uploads?type=image", token)
        if (!ok) return null
        val uploadUrl = runCatching { JSONObject(uploadInfo).optString("url", "") }.getOrNull()
        if (uploadUrl.isNullOrBlank()) return null

        val uploadedJson = uploadMultipartFile(uploadUrl, token, file) ?: return null
        return JSONObject()
            .put("type", "image")
            .put("payload", uploadedJson)
    }

    private fun requestJson(
        method: String,
        urlStr: String,
        token: String,
        jsonBody: String? = null
    ): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            conn = openMaxConnection(urlStr).apply {
                requestMethod = method
                connectTimeout = 15_000
                readTimeout = 30_000
                setRequestProperty("Authorization", token)
                setRequestProperty("Accept", "application/json")
                if (jsonBody != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                }
            }
            if (jsonBody != null) {
                conn.outputStream.use { it.write(jsonBody.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()

            if (code !in 200..299) {
                val msg = runCatching {
                    val j = JSONObject(body)
                    val c = j.optString("code", "")
                    val m = j.optString("message", "")
                    listOf(c, m).filter { it.isNotBlank() }.joinToString(": ")
                }.getOrNull().orEmpty().ifBlank { "HTTP $code" }
                return false to msg
            }

            // MAX API can return HTTP 200 with {"success": false, "code": "...", "message": "..."}
            val isExplicitFailure = runCatching {
                val j = JSONObject(body)
                j.has("success") && !j.optBoolean("success", true)
            }.getOrDefault(false)

            if (isExplicitFailure) {
                val msg = runCatching {
                    val j = JSONObject(body)
                    "${j.optString("code", "")}: ${j.optString("message", "Ошибка MAX")}".trim(':', ' ')
                }.getOrDefault("Ошибка MAX")
                return false to msg
            }
            true to body
        } catch (e: Exception) {
            false to "Сетевая ошибка MAX: ${e.message ?: "неизвестно"}"
        } finally {
            conn?.disconnect()
        }
    }

    private fun uploadMultipartFile(urlStr: String, token: String, file: File): JSONObject? {
        val boundary = "----MaxUpload${UUID.randomUUID().toString().replace("-", "")}"
        val crlf = "\r\n"
        var conn: HttpURLConnection? = null
        return try {
            conn = openMaxConnection(urlStr).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Authorization", token)
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }
            DataOutputStream(conn.outputStream).use { out ->
                out.writeBytes("--$boundary$crlf")
                out.writeBytes("Content-Disposition: form-data; name=\"data\"; filename=\"${file.name}\"$crlf")
                out.writeBytes("Content-Type: image/jpeg$crlf$crlf")
                file.inputStream().use { it.copyTo(out) }
                out.writeBytes(crlf)
                out.writeBytes("--$boundary--$crlf")
                out.flush()
            }
            if (conn.responseCode !in 200..299) return null
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
            JSONObject(body)
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
