package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Analyzes existing products already published across Telegram, VK, MAX, and local SQLite
 * so auto-scrape skips duplicates and only collects genuinely new products.
 */
object ChannelAnalyzer {

    private val STOP_WORDS = setOf(
        "для", "или", "под", "без", "при", "про", "это", "все", "как", "над", "при",
        "цена", "заказ", "заказа", "купить", "новинка", "модное", "тренд", "мужское",
        "женское", "детское", "унисекс", "товар", "товара", "опт", "оптом", "руб", "шт"
    )

    data class ExistingInventory(
        val existingUrls: Set<String>,
        val normalizedTitles: List<Set<String>>,
        val scannedTelegram: Int,
        val scannedVk: Int,
        val scannedMax: Int
    ) {
        fun isAlreadyInChannels(url: String, title: String): Boolean {
            val clean = ProductDbHelper.cleanUrl(url)
            if (clean in existingUrls) return true
            val candidateTokens = tokenize(title)
            if (candidateTokens.size < 2) return false
            for (existingTokens in normalizedTitles) {
                if (existingTokens.size < 2) continue
                val overlap = candidateTokens.count { it in existingTokens }
                val minSize = minOf(candidateTokens.size, existingTokens.size)
                val ratio = overlap.toDouble() / minSize.toDouble()
                if (overlap >= 2 && ratio >= 0.65) return true
            }
            return false
        }
    }

    suspend fun analyzeChannels(
        dbHelper: ProductDbHelper,
        settings: AppSettings
    ): ExistingInventory = withContext(Dispatchers.IO) {
        val urls = linkedSetOf<String>()
        val titleTokenSets = mutableListOf<Set<String>>()

        // 1. Local SQLite products
        val local = dbHelper.getAll()
        for (p in local) {
            urls.add(ProductDbHelper.cleanUrl(p.url))
            val t = tokenize(p.title)
            if (t.size >= 2) titleTokenSets.add(t)
        }

        // 2. Live Telegram channel posts
        var tgCount = 0
        if (settings.telegramChannelId.isNotBlank()) {
            val (tgPosts, _) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
            tgCount = tgPosts.size
            for (post in tgPosts) {
                val firstLine = post.text.lines().firstOrNull().orEmpty()
                val t = tokenize(firstLine)
                if (t.size >= 2) titleTokenSets.add(t)
            }
        }

        // 3. Live VK wall posts
        var vkCount = 0
        if (settings.vkAccessToken.isNotBlank() && settings.vkGroupId.isNotBlank()) {
            val vkPosts = VkClient.fetchRecentWallTexts(settings)
            vkCount = vkPosts.size
            for (text in vkPosts) {
                val firstLine = text.lines().firstOrNull().orEmpty()
                val t = tokenize(firstLine)
                if (t.size >= 2) titleTokenSets.add(t)
            }
        }

        // 4. Live MAX channel posts
        var maxCount = 0
        if (settings.maxBotToken.isNotBlank() && settings.maxChatId.isNotBlank()) {
            val maxPosts = MaxClient.fetchRecentChannelTexts(settings)
            maxCount = maxPosts.size
            for (text in maxPosts) {
                val firstLine = text.lines().firstOrNull().orEmpty()
                val t = tokenize(firstLine)
                if (t.size >= 2) titleTokenSets.add(t)
            }
        }

        ExistingInventory(
            existingUrls = urls,
            normalizedTitles = titleTokenSets,
            scannedTelegram = tgCount,
            scannedVk = vkCount,
            scannedMax = maxCount
        )
    }

    fun tokenize(raw: String): Set<String> = raw
        .lowercase()
        .replace(Regex("[^a-zа-яё0-9]+"), " ")
        .split(" ")
        .map { it.trim() }
        .filter { it.length >= 3 && it !in STOP_WORDS }
        .toSet()
}
