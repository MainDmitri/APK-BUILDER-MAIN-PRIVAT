package com.maindmitri.wikkeoposter.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.ProductStatus
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.ChannelPostPreview
import com.maindmitri.wikkeoposter.network.MaxClient
import com.maindmitri.wikkeoposter.network.TelegramClient
import com.maindmitri.wikkeoposter.network.VkClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProductsScreen(
    products: List<Product>,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedFilter by remember { mutableStateOf<ProductStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var editingProductId by remember { mutableStateOf<String?>(null) }

    var showToolsDialog by remember { mutableStateOf(false) }
    var showConfirmClearDrafts by remember { mutableStateOf(false) }
    var sortMode by remember { mutableStateOf("new") }
    var channelDialogPosts by remember { mutableStateOf<List<ChannelPostPreview>?>(null) }

    var taskRunning by remember { mutableStateOf(false) }
    var taskProgressText by remember { mutableStateOf("") }
    var activeJob by remember { mutableStateOf<Job?>(null) }

    val editingProduct = products.firstOrNull { it.id == editingProductId }

    if (editingProduct != null) {
        ProductDetailEditor(
            product = editingProduct,
            settings = settings,
            dbHelper = dbHelper,
            onBack = { editingProductId = null },
            onProductsChanged = onProductsChanged,
            onNotify = onNotify
        )
        return
    }

    val publishedCount = remember(products) { products.count { it.status == ProductStatus.PUBLISHED } }
    val draftCount = remember(products) { products.count { it.status == ProductStatus.DRAFT } }
    val vkCount = remember(products) { products.count { it.vkPostId != null } }
    val maxCount = remember(products) { products.count { !it.maxMessageId.isNullOrBlank() } }
    val errorCount = remember(products) { products.count { it.status == ProductStatus.ERROR } }

    val filtered = remember(products, selectedFilter, searchQuery, sortMode) {
        val byStatus = if (selectedFilter == null) products else products.filter { it.status == selectedFilter }
        val q = searchQuery.trim()
        val searched = if (q.isBlank()) byStatus
        else byStatus.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.url.contains(q, ignoreCase = true) ||
                it.seller.contains(q, ignoreCase = true) ||
                it.generatedPost.contains(q, ignoreCase = true)
        }
        when (sortMode) {
            "cheap" -> searched.sortedBy { it.finalPrice ?: Int.MAX_VALUE }
            "expensive" -> searched.sortedByDescending { it.finalPrice ?: -1 }
            else -> searched
        }
    }

    fun launchBulkTask(initialText: String, block: suspend () -> Unit) {
        if (taskRunning) return
        showToolsDialog = false
        activeJob = scope.launch {
            taskRunning = true
            taskProgressText = initialText
            try {
                block()
            } catch (e: Exception) {
                onNotify("Задача остановлена: ${e.message ?: "отменено"}")
            } finally {
                taskRunning = false
                taskProgressText = ""
            }
        }
    }

    if (showConfirmClearDrafts) {
        AlertDialog(
            onDismissRequest = { showConfirmClearDrafts = false },
            title = { Text("Удалить все черновики?") },
            text = { Text("Будут удалены все черновики ($draftCount шт.) вместе с их локальными фото.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showConfirmClearDrafts = false
                        scope.launch {
                            val removed = withContext(Dispatchers.IO) {
                                val drafts = dbHelper.getAll().filter { it.status == ProductStatus.DRAFT }
                                drafts.forEach { dbHelper.delete(it.id) }
                                drafts.size
                            }
                            onProductsChanged()
                            onNotify("Удалено черновиков: $removed")
                        }
                    }
                ) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClearDrafts = false }) { Text("Отмена") }
            }
        )
    }

    // Channel Tools Dialog (clean, spacious, zero truncated labels!)
    if (showToolsDialog) {
        AlertDialog(
            onDismissRequest = { showToolsDialog = false },
            title = { Text("Инструменты каналов", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (draftCount > 0) {
                        Button(
                            onClick = {
                                launchBulkTask("Публикую черновики...") {
                                    val drafts = withContext(Dispatchers.IO) {
                                        dbHelper.getAll().filter { it.status == ProductStatus.DRAFT }
                                    }
                                    var okTg = 0
                                    var okVk = 0
                                    var okMax = 0
                                    for ((i, draft) in drafts.withIndex()) {
                                        if (settings.requirePhotos && draft.localImages.isEmpty()) continue
                                        taskProgressText = "Черновик ${i + 1}/${drafts.size}: ${draft.title.take(22)}..."
                                        val tgRes = TelegramClient.publishProduct(draft, settings)
                                        var updated = if (tgRes.success) {
                                            okTg++
                                            draft.copy(
                                                status = ProductStatus.PUBLISHED,
                                                telegramMessageId = tgRes.messageId,
                                                publishedAt = System.currentTimeMillis(),
                                                lastError = ""
                                            )
                                        } else {
                                            draft.copy(status = ProductStatus.ERROR, lastError = tgRes.error)
                                        }
                                        if (settings.autoPublishVk && settings.vkAccessToken.isNotBlank() && settings.vkGroupId.isNotBlank()) {
                                            val vkRes = VkClient.publishProduct(updated, settings)
                                            if (vkRes.success) {
                                                okVk++
                                                updated = updated.copy(vkPostId = vkRes.postId ?: 1L)
                                            }
                                        }
                                        if (settings.autoPublishMax && settings.maxBotToken.isNotBlank() && settings.maxChatId.isNotBlank()) {
                                            val maxRes = MaxClient.publishProduct(updated, settings)
                                            if (maxRes.success) {
                                                okMax++
                                                updated = updated.copy(maxMessageId = maxRes.messageId ?: "sent")
                                            }
                                        }
                                        withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                                        onProductsChanged()
                                        delay(1100)
                                    }
                                    onNotify("Готово! ТГ: $okTg, ВК: $okVk, MAX: $okMax")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("📤 Выложить все черновики ($draftCount)")
                        }
                    }

                    FilledTonalButton(
                        onClick = {
                            val abhLine = settings.abkhaziaOrderLine.trim()
                                .ifEmpty { "Для покупки по Абхазии писать @MainStoreabh" }
                            launchBulkTask("Анализирую посты в ТГ и MAX...") {
                                var tgUpdated = 0
                                var maxUpdated = 0
                                var skippedAlready = 0

                                if (settings.telegramBotToken.isNotBlank() && settings.telegramChannelId.isNotBlank()) {
                                    val (liveTgPosts, _) = TelegramClient.fetchRecentPublicChannelPosts(
                                        settings.telegramChannelId,
                                        maxPages = 6
                                    )
                                    val localByMsgId = withContext(Dispatchers.IO) {
                                        dbHelper.getAll()
                                            .filter { it.telegramMessageId != null && it.telegramMessageId > 0 }
                                            .associateBy { it.telegramMessageId!! }
                                    }
                                    val tgTargets = linkedMapOf<Long, Pair<String, Boolean>>()
                                    for ((mid, prod) in localByMsgId) {
                                        if (prod.generatedPost.isNotBlank()) tgTargets[mid] = prod.generatedPost to true
                                    }
                                    for (lp in liveTgPosts) {
                                        if (!tgTargets.containsKey(lp.messageId)) {
                                            tgTargets[lp.messageId] = AiClient.escapeHtml(lp.text) to true
                                        }
                                    }
                                    var idxTg = 0
                                    for ((mid, pair) in tgTargets) {
                                        idxTg++
                                        val (rawText, isHtml) = pair
                                        if (!rawText.contains("для заказа", ignoreCase = true)) continue
                                        val updatedText = AiClient.injectAbkhaziaLineIfOrderPresent(rawText, abhLine, asHtml = isHtml)
                                        if (updatedText == null) {
                                            skippedAlready++
                                            continue
                                        }
                                        taskProgressText = "Абхазия • ТГ ($idxTg/${tgTargets.size})"
                                        val editRes = TelegramClient.editPublishedPost(mid, updatedText, settings)
                                        if (editRes.success) {
                                            tgUpdated++
                                            localByMsgId[mid]?.let { prod ->
                                                withContext(Dispatchers.IO) {
                                                    dbHelper.upsert(prod.copy(generatedPost = updatedText))
                                                }
                                            }
                                        }
                                        delay(900)
                                    }
                                }

                                if (settings.maxBotToken.isNotBlank() && settings.maxChatId.isNotBlank()) {
                                    taskProgressText = "Абхазия • читаю канал MAX..."
                                    val maxPosts = MaxClient.fetchRecentChannelMessages(settings, maxMessages = 250)
                                    for ((idxMax, mp) in maxPosts.withIndex()) {
                                        if (!mp.text.contains("для заказа", ignoreCase = true)) continue
                                        val updatedText = AiClient.injectAbkhaziaLineIfOrderPresent(mp.text, abhLine, asHtml = false)
                                        if (updatedText == null) {
                                            skippedAlready++
                                            continue
                                        }
                                        taskProgressText = "Абхазия • MAX (${idxMax + 1}/${maxPosts.size})"
                                        val editRes = MaxClient.editPublishedPost(mp.mid, updatedText, settings, useHtml = false)
                                        if (editRes.success) maxUpdated++
                                        delay(700)
                                    }
                                }

                                onProductsChanged()
                                onNotify("Абхазия добавлена! ТГ: $tgUpdated, MAX: $maxUpdated (уже было: $skippedAlready)")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📍 Добавить Абхазию в посты ТГ + MAX")
                    }

                    FilledTonalButton(
                        onClick = {
                            launchBulkTask("Проверяю посты в Telegram...") {
                                val (livePosts, _) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
                                val localAll = withContext(Dispatchers.IO) { dbHelper.getAll() }
                                val matchedByMsgId = linkedMapOf<Long, Product>()
                                for (p in localAll) {
                                    val mid = p.telegramMessageId
                                    if (p.status == ProductStatus.PUBLISHED && mid != null && mid > 0) matchedByMsgId[mid] = p
                                }
                                for (lp in livePosts) {
                                    if (lp.text.contains("НАВИГАЦИЯ ПО КАНАЛУ", ignoreCase = true)) continue
                                    if (lp.text.startsWith("🛍") && lp.text.lines().size <= 2) continue
                                    if (!matchedByMsgId.containsKey(lp.messageId)) {
                                        val found = localAll.firstOrNull {
                                            it.title.length >= 4 && lp.text.contains(it.title, ignoreCase = true)
                                        }
                                        if (found != null) {
                                            val linked = found.copy(status = ProductStatus.PUBLISHED, telegramMessageId = lp.messageId)
                                            withContext(Dispatchers.IO) { dbHelper.upsert(linked) }
                                            matchedByMsgId[lp.messageId] = linked
                                        }
                                    }
                                }
                                val unmatchedLive = livePosts.filter { lp ->
                                    !matchedByMsgId.containsKey(lp.messageId) &&
                                        !lp.text.contains("НАВИГАЦИЯ ПО КАНАЛУ", ignoreCase = true) &&
                                        !(lp.text.startsWith("🛍") && lp.text.lines().size <= 2)
                                }
                                val total = matchedByMsgId.size + unmatchedLive.size
                                if (total == 0) {
                                    onNotify("Не найдено постов для обновления.")
                                    return@launchBulkTask
                                }
                                var done = 0
                                var editedOk = 0
                                for ((msgId, prod) in matchedByMsgId) {
                                    done++
                                    taskProgressText = "Обновляю $done/$total: ${prod.title.take(22)}..."
                                    val aiRes = AiClient.generateTelegramPost(prod, settings)
                                    val editRes = TelegramClient.editPublishedPost(msgId, aiRes.postHtml, settings)
                                    if (editRes.success) {
                                        editedOk++
                                        withContext(Dispatchers.IO) { dbHelper.upsert(prod.copy(generatedPost = aiRes.postHtml, lastError = "")) }
                                    }
                                    delay(900)
                                }
                                for (lp in unmatchedLive) {
                                    done++
                                    taskProgressText = "Обновляю пост #$done/$total..."
                                    val aiRes = AiClient.rewriteExistingChannelPost(lp.text, settings)
                                    if (TelegramClient.editPublishedPost(lp.messageId, aiRes.postHtml, settings).success) editedOk++
                                    delay(900)
                                }
                                onProductsChanged()
                                onNotify("Обновлено описаний в ТГ: $editedOk из $total")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🔄 Переписать описания постов в ТГ")
                    }

                    HorizontalDivider()

                    OutlinedButton(
                        onClick = {
                            if (settings.vkAccessToken.isBlank() || settings.vkGroupId.isBlank()) {
                                onNotify("Сначала укажи VK Token и ID сообщества в Настройках")
                                return@OutlinedButton
                            }
                            launchBulkTask("Готовлю перенос из ТГ в ВК...") {
                                val localPublished = withContext(Dispatchers.IO) {
                                    dbHelper.getAll().filter { it.status == ProductStatus.PUBLISHED && it.vkPostId == null }
                                }
                                val (liveTgPosts, _) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
                                val localMsgIds = localPublished.mapNotNull { it.telegramMessageId }.toSet()
                                val allVkTitles = withContext(Dispatchers.IO) {
                                    dbHelper.getAll().filter { it.vkPostId != null }.map { it.title }
                                }
                                val extraTgPosts = liveTgPosts.filter { lp ->
                                    lp.messageId !in localMsgIds &&
                                        !lp.text.contains("НАВИГАЦИЯ ПО КАНАЛУ", ignoreCase = true) &&
                                        !(lp.text.startsWith("🛍") && lp.text.lines().size <= 2) &&
                                        allVkTitles.none { t -> t.length >= 4 && lp.text.contains(t, ignoreCase = true) }
                                }
                                val total = localPublished.size + extraTgPosts.size
                                if (total == 0) {
                                    onNotify("Все товары из ТГ уже перенесены в ВК!")
                                    return@launchBulkTask
                                }
                                var done = 0
                                var okCount = 0
                                for (prod in localPublished) {
                                    done++
                                    taskProgressText = "ТГ → ВК $done/$total: ${prod.title.take(20)}..."
                                    val vkRes = VkClient.publishProduct(prod, settings)
                                    if (vkRes.success) {
                                        okCount++
                                        withContext(Dispatchers.IO) { dbHelper.upsert(prod.copy(vkPostId = vkRes.postId ?: 1L)) }
                                    }
                                    delay(1300)
                                }
                                for (lp in extraTgPosts.reversed()) {
                                    done++
                                    taskProgressText = "ТГ → ВК пост $done/$total..."
                                    val vkRes = VkClient.publishMigratedTelegramPost(lp.text, lp.imageUrls, context.cacheDir, settings)
                                    if (vkRes.success) okCount++
                                    delay(1300)
                                }
                                onProductsChanged()
                                onNotify("Перенесено в ВК: $okCount из $total")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📲 Перенести всё из Telegram в ВК")
                    }

                    OutlinedButton(
                        onClick = {
                            if (settings.maxBotToken.isBlank() || settings.maxChatId.isBlank()) {
                                onNotify("Сначала укажи MAX Token и ID канала в Настройках")
                                return@OutlinedButton
                            }
                            launchBulkTask("Готовлю перенос из ТГ в MAX...") {
                                val localPublished = withContext(Dispatchers.IO) {
                                    dbHelper.getAll().filter { it.status == ProductStatus.PUBLISHED && it.maxMessageId.isNullOrBlank() }
                                }
                                val (liveTgPosts, _) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
                                val localMsgIds = localPublished.mapNotNull { it.telegramMessageId }.toSet()
                                val allMaxTitles = withContext(Dispatchers.IO) {
                                    dbHelper.getAll().filter { !it.maxMessageId.isNullOrBlank() }.map { it.title }
                                }
                                val extraTgPosts = liveTgPosts.filter { lp ->
                                    lp.messageId !in localMsgIds &&
                                        !lp.text.contains("НАВИГАЦИЯ ПО КАНАЛУ", ignoreCase = true) &&
                                        !(lp.text.startsWith("🛍") && lp.text.lines().size <= 2) &&
                                        allMaxTitles.none { t -> t.length >= 4 && lp.text.contains(t, ignoreCase = true) }
                                }
                                val total = localPublished.size + extraTgPosts.size
                                if (total == 0) {
                                    onNotify("Все товары из ТГ уже перенесены в MAX!")
                                    return@launchBulkTask
                                }
                                var done = 0
                                var okCount = 0
                                for (prod in localPublished) {
                                    done++
                                    taskProgressText = "ТГ → MAX $done/$total: ${prod.title.take(20)}..."
                                    val maxRes = MaxClient.publishProduct(prod, settings)
                                    if (maxRes.success) {
                                        okCount++
                                        withContext(Dispatchers.IO) { dbHelper.upsert(prod.copy(maxMessageId = maxRes.messageId ?: "sent")) }
                                    }
                                    delay(900)
                                }
                                for (lp in extraTgPosts.reversed()) {
                                    done++
                                    taskProgressText = "ТГ → MAX пост $done/$total..."
                                    val maxRes = MaxClient.publishMigratedTelegramPost(lp.text, lp.imageUrls, context.cacheDir, settings)
                                    if (maxRes.success) okCount++
                                    delay(900)
                                }
                                onProductsChanged()
                                onNotify("Перенесено в MAX: $okCount из $total")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📲 Перенести всё из Telegram в MAX")
                    }

                    HorizontalDivider()

                    OutlinedButton(
                        onClick = {
                            launchBulkTask("Публикую навигацию...") {
                                val (_, msg) = TelegramClient.publishAndPinNavigation(settings)
                                onNotify(msg)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📌 Закрепить навигацию по хештегам в ТГ")
                    }

                    if (draftCount > 0) {
                        OutlinedButton(
                            onClick = {
                                launchBulkTask("Пересчитываю цены черновиков...") {
                                    val updatedCount = withContext(Dispatchers.IO) {
                                        val drafts = dbHelper.getAll().filter { it.status == ProductStatus.DRAFT }
                                        var count = 0
                                        for (d in drafts) {
                                            val newPrice = settings.calculateFinalPrice(d.wholesalePrice) ?: continue
                                            if (newPrice != d.finalPrice) {
                                                val formatted = AiClient.formatRub(newPrice)
                                                val newPost = d.generatedPost.replace(
                                                    Regex("💰\\s*<b>Цена:</b>\\s*[^\\n]+"),
                                                    "💰 <b>Цена:</b> $formatted"
                                                )
                                                dbHelper.upsert(d.copy(finalPrice = newPrice, generatedPost = newPost))
                                                count++
                                            }
                                        }
                                        count
                                    }
                                    onProductsChanged()
                                    onNotify("Пересчитано цен в черновиках: $updatedCount")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("💰 Пересчитать цены в черновиках")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            launchBulkTask("Проверяю живые посты в ТГ...") {
                                val (posts, msg) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
                                onNotify(msg)
                                if (posts.isNotEmpty()) channelDialogPosts = posts
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🔍 Посмотреть живые посты ТГ-канала")
                    }

                    if (draftCount > 0) {
                        OutlinedButton(
                            onClick = {
                                launchBulkTask("Перегенерирую тексты черновиков через ИИ...") {
                                    val drafts = withContext(Dispatchers.IO) {
                                        dbHelper.getAll().filter { it.status == ProductStatus.DRAFT }
                                    }
                                    var ok = 0
                                    for ((i, d) in drafts.withIndex()) {
                                        taskProgressText = "ИИ-текст ${i + 1}/${drafts.size}: ${d.title.take(20)}..."
                                        val res = AiClient.generateTelegramPost(d, settings)
                                        if (res.success) ok++
                                        withContext(Dispatchers.IO) {
                                            dbHelper.upsert(
                                                d.copy(
                                                    generatedPost = res.postHtml,
                                                    lastError = if (res.success) "" else res.error
                                                )
                                            )
                                        }
                                        delay(400)
                                    }
                                    onProductsChanged()
                                    onNotify("Обновлено текстов черновиков: $ok из ${drafts.size}")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✨ Переписать тексты всех черновиков")
                        }

                        OutlinedButton(
                            onClick = {
                                showToolsDialog = false
                                showConfirmClearDrafts = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🗑 Удалить все черновики ($draftCount)", color = MaterialTheme.colorScheme.error)
                        }
                    }

                    if (errorCount > 0) {
                        OutlinedButton(
                            onClick = {
                                showToolsDialog = false
                                scope.launch {
                                    val removed = withContext(Dispatchers.IO) {
                                        val errs = dbHelper.getAll().filter { it.status == ProductStatus.ERROR }
                                        errs.forEach { dbHelper.delete(it.id) }
                                        errs.size
                                    }
                                    onProductsChanged()
                                    onNotify("Удалено товаров с ошибками: $removed")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("🧹 Удалить товары с ошибками ($errorCount)", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showToolsDialog = false }) { Text("Закрыть") }
            }
        )
    }

    if (channelDialogPosts != null) {
        val posts = channelDialogPosts!!
        AlertDialog(
            onDismissRequest = { channelDialogPosts = null },
            title = { Text("Посты в канале (${posts.size})") },
            text = {
                LazyColumn(
                    modifier = Modifier.height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(posts, key = { it.messageId }) { post ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { openExternalUrl(context, post.postUrl) }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = post.text.lines().firstOrNull().orEmpty().take(90),
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "Пост #${post.messageId} • Открыть ↗",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { channelDialogPosts = null }) { Text("Закрыть") }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Row 1: Modern Clickable 4-Card KPI Dashboard
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KpiStatCard("ТГ", publishedCount, BrandEmerald, Modifier.weight(1f)) {
                selectedFilter = ProductStatus.PUBLISHED
            }
            KpiStatCard("ВК", vkCount, BrandBlue, Modifier.weight(1f)) {
                selectedFilter = null
            }
            KpiStatCard("MAX", maxCount, BrandViolet, Modifier.weight(1f)) {
                selectedFilter = null
            }
            KpiStatCard("Черн.", draftCount, BrandAmber, Modifier.weight(1f)) {
                selectedFilter = ProductStatus.DRAFT
            }
        }

        // Row 2: Search + Compact Tools Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Поиск или #хештег...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f)
            )
            FilledTonalButton(
                onClick = { showToolsDialog = true },
                enabled = !taskRunning,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.height(52.dp)
            ) {
                Icon(Icons.Default.Menu, contentDescription = "Действия", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Меню")
            }
        }

        // Row 3: Horizontally scrollable Filter Chips (never clips on narrow screens)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == null,
                onClick = { selectedFilter = null },
                label = { Text("Все (${products.size})") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.PUBLISHED,
                onClick = { selectedFilter = ProductStatus.PUBLISHED },
                label = { Text("В канале ($publishedCount)") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.DRAFT,
                onClick = { selectedFilter = ProductStatus.DRAFT },
                label = { Text("Черновики ($draftCount)") }
            )
            if (errorCount > 0) {
                FilterChip(
                    selected = selectedFilter == ProductStatus.ERROR,
                    onClick = { selectedFilter = ProductStatus.ERROR },
                    label = { Text("Ошибки ($errorCount)") }
                )
            }
            val sortLabel = when (sortMode) {
                "cheap" -> "↕ Дешевле"
                "expensive" -> "↕ Дороже"
                else -> "↕ Новые"
            }
            FilterChip(
                selected = sortMode != "new",
                onClick = {
                    sortMode = when (sortMode) {
                        "new" -> "cheap"
                        "cheap" -> "expensive"
                        else -> "new"
                    }
                },
                label = { Text(sortLabel) }
            )
        }

        // Active Background Task Banner (only visible when running)
        if (taskRunning) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = taskProgressText.ifBlank { "Выполняю..." },
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    TextButton(onClick = { activeJob?.cancel() }) {
                        Text("Стоп")
                    }
                }
            }
        }

        // Spacious Product List (takes ~75% of screen!)
        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "Ничего не найдено" else "Пока нет сохранённых товаров",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Открой вкладку Wikkeo, выбери товар или нажми «Автосбор в фоне».",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    ProductListCard(
                        product = item,
                        onClick = { editingProductId = item.id },
                        onOpenWikkeo = { openExternalUrl(context, item.url) },
                        onQuickDelete = {
                            scope.launch {
                                withContext(Dispatchers.IO) { dbHelper.delete(item.id) }
                                onProductsChanged()
                                onNotify("Удалено: ${item.title.take(28)}")
                            }
                        },
                        onQuickPublish = {
                            launchBulkTask("Публикую ${item.title.take(22)}...") {
                                if (settings.requirePhotos && item.localImages.isEmpty()) {
                                    onNotify("У товара нет фото")
                                    return@launchBulkTask
                                }
                                var updated = item
                                val summary = mutableListOf<String>()
                                if (settings.telegramBotToken.isNotBlank() && settings.telegramChannelId.isNotBlank()) {
                                    val tgRes = TelegramClient.publishProduct(updated, settings)
                                    if (tgRes.success) {
                                        updated = updated.copy(
                                            status = ProductStatus.PUBLISHED,
                                            telegramMessageId = tgRes.messageId,
                                            publishedAt = System.currentTimeMillis(),
                                            lastError = ""
                                        )
                                        summary.add("ТГ ✓")
                                    } else {
                                        updated = updated.copy(status = ProductStatus.ERROR, lastError = tgRes.error)
                                        summary.add("ТГ ✗")
                                    }
                                }
                                if (settings.autoPublishVk && settings.vkAccessToken.isNotBlank() && settings.vkGroupId.isNotBlank()) {
                                    val vkRes = VkClient.publishProduct(updated, settings)
                                    if (vkRes.success) {
                                        updated = updated.copy(vkPostId = vkRes.postId ?: 1L)
                                        summary.add("ВК ✓")
                                    }
                                }
                                if (settings.autoPublishMax && settings.maxBotToken.isNotBlank() && settings.maxChatId.isNotBlank()) {
                                    val maxRes = MaxClient.publishProduct(updated, settings)
                                    if (maxRes.success) {
                                        updated = updated.copy(maxMessageId = maxRes.messageId ?: "sent")
                                        summary.add("MAX ✓")
                                    }
                                }
                                withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                                onProductsChanged()
                                onNotify(if (summary.isEmpty()) "Настрой каналы" else summary.joinToString(" • "))
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun KpiStatCard(
    label: String,
    count: Int,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = accent.copy(alpha = 0.12f),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = accent
            )
        }
    }
}

@Composable
private fun ProductListCard(
    product: Product,
    onClick: () -> Unit,
    onOpenWikkeo: () -> Unit,
    onQuickDelete: () -> Unit,
    onQuickPublish: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LocalThumbImage(
                path = product.localImages.firstOrNull(),
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(12.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                val wholesaleStr = AiClient.formatRub(product.wholesalePrice)
                val finalStr = AiClient.formatRub(product.finalPrice ?: product.wholesalePrice)
                Text(
                    text = "Опт: $wholesaleStr → Пост: $finalStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                if (product.minOrder.isNotBlank()) {
                    Text(
                        text = "Мин. заказ: ${product.minOrder}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatusBadge(product.status)
                    if (product.vkPostId != null) {
                        MiniPlatformBadge("✓ ВК", BrandBlue)
                    }
                    if (!product.maxMessageId.isNullOrBlank()) {
                        MiniPlatformBadge("✓ MAX", BrandViolet)
                    }
                    Text(
                        text = "📷 ${product.localImages.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Wikkeo ↗",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = onOpenWikkeo)
                    )
                }
            }
            if (product.status == ProductStatus.DRAFT || product.status == ProductStatus.ERROR) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = onQuickPublish,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Быстро выложить",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(
                        onClick = onQuickDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "Удалить черновик",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniPlatformBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun StatusBadge(status: ProductStatus) {
    val bg = when (status) {
        ProductStatus.PUBLISHED -> BrandEmerald
        ProductStatus.DRAFT -> BrandAmber
        ProductStatus.ERROR -> Color(0xFFDC2626)
    }
    Surface(
        color = bg.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = if (status == ProductStatus.PUBLISHED) "✓ ТГ" else status.labelRu,
            color = bg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun LocalThumbImage(path: String?, modifier: Modifier = Modifier) {
    var bitmap by remember(path) { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(path) {
        bitmap = withContext(Dispatchers.IO) {
            if (path.isNullOrBlank()) return@withContext null
            val f = File(path)
            if (!f.exists()) return@withContext null
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(f.absolutePath, opts)?.asImageBitmap()
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.ShoppingCart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductDetailEditor(
    product: Product,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onBack: () -> Unit,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var postText by remember(product.id, product.generatedPost) { mutableStateOf(product.generatedPost) }
    var priceText by remember(product.id, product.finalPrice) {
        mutableStateOf((product.finalPrice ?: product.wholesalePrice?.toInt())?.toString() ?: "")
    }
    var localImages by remember(product.id, product.localImages) { mutableStateOf(product.localImages) }
    var busy by remember { mutableStateOf(false) }
    var previewMode by remember { mutableStateOf(false) }

    BackHandler(enabled = !busy) { onBack() }

    fun currentEditedProduct(): Product = product.copy(
        finalPrice = priceText.toIntOrNull(),
        generatedPost = postText,
        localImages = localImages
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Text(
                    text = product.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack, enabled = !busy) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                }
            },
            actions = {
                IconButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.delete(product.id) }
                            onProductsChanged()
                            onNotify("Товар удалён")
                            onBack()
                        }
                    },
                    enabled = !busy
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить")
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Owner-only Wikkeo source card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Источник Wikkeo (только для владельца)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = product.url,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    val ownerDetails = buildList {
                        add("Опт: ${AiClient.formatRub(product.wholesalePrice)}")
                        if (product.minOrder.isNotBlank()) add("Мин. заказ: ${product.minOrder}")
                        if (product.seller.isNotBlank()) add("Поставщик: ${product.seller}")
                    }.joinToString("  •  ")
                    Text(
                        text = ownerDetails,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { openExternalUrl(context, product.url) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("На Wikkeo")
                        }
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Wikkeo URL", product.url))
                                onNotify("Ссылка на Wikkeo скопирована")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Копировать")
                        }
                    }
                    if (localImages.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val savedCount = savePhotosToGallery(context, product.id, localImages)
                                    onNotify("Сохранено в Галерею (Pictures/WikkeoPoster): $savedCount фото")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Скачать фото в Галерею (${localImages.size} шт.)")
                        }
                    }
                    val postUrl = TelegramClient.buildPostUrl(settings.telegramChannelId, product.telegramMessageId)
                    if (product.status == ProductStatus.PUBLISHED && postUrl != null) {
                        HorizontalDivider()
                        val dateStr = product.publishedAt?.let {
                            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(it))
                        }.orEmpty()
                        TextButton(
                            onClick = { openExternalUrl(context, postUrl) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✓ Опубликовано $dateStr — открыть пост в Telegram ↗")
                        }
                    }
                }
            }

            // Photos gallery
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Сохранённые фото (${localImages.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                StatusBadge(product.status)
            }

            if (localImages.isEmpty()) {
                Text(
                    text = "Фотографии не скачаны.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(localImages, key = { it }) { imgPath ->
                        Box(modifier = Modifier.size(110.dp)) {
                            LocalThumbImage(
                                path = imgPath,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            IconButton(
                                onClick = {
                                    localImages = localImages.filterNot { it == imgPath }
                                    scope.launch(Dispatchers.IO) {
                                        runCatching { File(imgPath).delete() }
                                        dbHelper.upsert(currentEditedProduct())
                                        withContext(Dispatchers.Main) { onProductsChanged() }
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(26.dp)
                                    .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Убрать фото",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (product.lastError.isNotBlank()) {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text(
                        text = product.lastError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Price & Post editor
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Цена в посте (₽)") },
                supportingText = {
                    Text("Опт на Wikkeo: ${AiClient.formatRub(product.wholesalePrice)}")
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            // Editor / Live Post Preview switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = !previewMode,
                    onClick = { previewMode = false },
                    label = { Text("✏️ Редактор") }
                )
                FilterChip(
                    selected = previewMode,
                    onClick = { previewMode = true },
                    label = { Text("👁 Превью поста") }
                )
            }

            if (previewMode) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        if (localImages.isNotEmpty()) {
                            LocalThumbImage(
                                path = localImages.firstOrNull(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(210.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(Modifier.height(10.dp))
                        }
                        Text(
                            text = VkClient.stripHtmlForVk(postText),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        val buyUrlPreview = settings.resolveBuyUrl()
                        if (!buyUrlPreview.isNullOrBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Surface(
                                color = BrandBlue.copy(alpha = 0.14f),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = settings.buyButtonText.ifBlank { "🛒 Купить" },
                                    color = BrandBlue,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 14.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                OutlinedTextField(
                    value = postText,
                    onValueChange = { postText = it },
                    label = { Text("Текст поста (без ссылки Wikkeo)") },
                    supportingText = {
                        val color = if (postText.length > 1024) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant
                        Text("${postText.length} / 1024 символов", color = color)
                    },
                    minLines = 7,
                    maxLines = 14,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // AI + Save + Copy row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            val res = AiClient.generateTelegramPost(edited, settings)
                            postText = res.postHtml
                            val updated = edited.copy(
                                generatedPost = res.postHtml,
                                lastError = if (res.success) "" else res.error
                            )
                            withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                            onProductsChanged()
                            onNotify(if (res.success) "Описание обновлено через ИИ" else res.error)
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("ИИ-текст", maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.upsert(currentEditedProduct()) }
                            onProductsChanged()
                            onNotify("Сохранено")
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Сохранить", maxLines = 1)
                }
            }

            // Primary Publish Everywhere button
            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        var edited = currentEditedProduct()
                        if (settings.requirePhotos && edited.localImages.isEmpty()) {
                            onNotify("Нет фото для публикации (выключи «Только товары с фото» в Настройках).")
                            busy = false
                            return@launch
                        }
                        withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                        val summary = mutableListOf<String>()

                        if (settings.telegramBotToken.isNotBlank() && settings.telegramChannelId.isNotBlank()) {
                            val tgRes = TelegramClient.publishProduct(edited, settings)
                            if (tgRes.success) {
                                edited = edited.copy(
                                    status = ProductStatus.PUBLISHED,
                                    telegramMessageId = tgRes.messageId,
                                    publishedAt = System.currentTimeMillis(),
                                    lastError = ""
                                )
                                summary.add("ТГ ✓")
                            } else {
                                edited = edited.copy(status = ProductStatus.ERROR, lastError = tgRes.error)
                                summary.add("ТГ ✗")
                            }
                        }

                        if (settings.vkAccessToken.isNotBlank() && settings.vkGroupId.isNotBlank()) {
                            val vkRes = VkClient.publishProduct(edited, settings)
                            if (vkRes.success) {
                                edited = edited.copy(vkPostId = vkRes.postId ?: 1L)
                                summary.add("ВК ✓")
                            } else {
                                summary.add("ВК ✗")
                            }
                        }

                        if (settings.maxBotToken.isNotBlank() && settings.maxChatId.isNotBlank()) {
                            val maxRes = MaxClient.publishProduct(edited, settings)
                            if (maxRes.success) {
                                edited = edited.copy(maxMessageId = maxRes.messageId ?: "sent")
                                summary.add("MAX ✓")
                            } else {
                                summary.add("MAX ✗")
                            }
                        }

                        withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                        onProductsChanged()
                        onNotify(
                            if (summary.isEmpty()) "Сначала настрой хотя бы один канал (ТГ / ВК / MAX)"
                            else "Результат: ${summary.joinToString(" • ")}"
                        )
                        busy = false
                    }
                },
                enabled = !busy,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("🚀 Выложить везде (ТГ + ВК + MAX)")
                }
            }

            if (product.status == ProductStatus.PUBLISHED && product.telegramMessageId != null) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                            val editRes = TelegramClient.editPublishedPost(
                                messageId = product.telegramMessageId,
                                newHtmlRaw = edited.generatedPost,
                                settings = settings
                            )
                            if (editRes.success) {
                                withContext(Dispatchers.IO) { dbHelper.upsert(edited.copy(lastError = "")) }
                                onProductsChanged()
                                onNotify("Описание обновлено прямо в опубликованном посте ТГ!")
                            } else {
                                onNotify("Ошибка обновления поста: ${editRes.error}")
                            }
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("🔄 Обновить описание в этом посте ТГ")
                }
            }

            // Individual platform buttons in a clean compact row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                            val tgRes = TelegramClient.publishProduct(edited, settings)
                            val updated = if (tgRes.success) {
                                edited.copy(
                                    status = ProductStatus.PUBLISHED,
                                    telegramMessageId = tgRes.messageId,
                                    publishedAt = System.currentTimeMillis(),
                                    lastError = ""
                                )
                            } else {
                                edited.copy(status = ProductStatus.ERROR, lastError = tgRes.error)
                            }
                            withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                            onProductsChanged()
                            onNotify(if (tgRes.success) "Опубликовано в ТГ!" else "Ошибка ТГ: ${tgRes.error}")
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("В ТГ", maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                            val vkRes = VkClient.publishProduct(edited, settings)
                            if (vkRes.success) {
                                withContext(Dispatchers.IO) { dbHelper.upsert(edited.copy(vkPostId = vkRes.postId ?: 1L)) }
                                onProductsChanged()
                                onNotify("Опубликовано в ВК!")
                            } else {
                                onNotify("Ошибка ВК: ${vkRes.error}")
                            }
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("В ВК", maxLines = 1)
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                            val maxRes = MaxClient.publishProduct(edited, settings)
                            if (maxRes.success) {
                                withContext(Dispatchers.IO) { dbHelper.upsert(edited.copy(maxMessageId = maxRes.messageId ?: "sent")) }
                                onProductsChanged()
                                onNotify("Опубликовано в MAX!")
                            } else {
                                onNotify("Ошибка MAX: ${maxRes.error}")
                            }
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("В MAX", maxLines = 1)
                }
            }

            OutlinedButton(
                onClick = {
                    val plain = VkClient.stripHtmlForVk(postText)
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Post Text", plain))
                    onNotify("Текст поста скопирован")
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("📋 Скопировать текст поста")
            }

            Spacer(Modifier.height(12.dp))
        }
    }
}

private fun openExternalUrl(context: Context, url: String) {
    runCatching {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}

private suspend fun savePhotosToGallery(
    context: Context,
    productId: String,
    paths: List<String>
): Int = withContext(Dispatchers.IO) {
    var count = 0
    val resolver = context.contentResolver
    paths.forEachIndexed { idx, p ->
        val src = File(p)
        if (!src.exists()) return@forEachIndexed
        val fileName = "${productId}_${idx + 1}.jpg"
        runCatching {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/WikkeoPoster"
                    )
                }
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                }
                count++
            }
        }
    }
    count
}
