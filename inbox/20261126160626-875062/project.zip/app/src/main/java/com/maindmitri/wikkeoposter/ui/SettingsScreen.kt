package com.maindmitri.wikkeoposter.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AiProvider
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.MaxChatInfo
import com.maindmitri.wikkeoposter.network.MaxClient
import com.maindmitri.wikkeoposter.network.TelegramClient
import com.maindmitri.wikkeoposter.network.VkClient
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onNotify: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var activeSection by remember { mutableIntStateOf(0) } // 0=ИИ, 1=ТГ, 2=ВК, 3=MAX, 4=Цены/Фото

    var aiProvider by remember(settings) { mutableStateOf(settings.aiProvider) }
    var rusapixKey by remember(settings) { mutableStateOf(settings.rusapixApiKey) }
    var rusapixBaseUrl by remember(settings) { mutableStateOf(settings.rusapixBaseUrl) }
    var rusapixModel by remember(settings) { mutableStateOf(settings.rusapixModel) }
    var openRouterKey by remember(settings) { mutableStateOf(settings.openRouterApiKey) }
    var openRouterModel by remember(settings) { mutableStateOf(settings.openRouterModel) }
    var loadedModels by remember(aiProvider) { mutableStateOf<List<String>>(emptyList()) }
    var styleHint by remember(settings) { mutableStateOf(settings.customStyleHint) }

    var tgToken by remember(settings) { mutableStateOf(settings.telegramBotToken) }
    var tgChannel by remember(settings) { mutableStateOf(settings.telegramChannelId) }
    var orderContact by remember(settings) { mutableStateOf(settings.orderContact) }
    var abkhaziaOrderLine by remember(settings) { mutableStateOf(settings.abkhaziaOrderLine) }
    var buyButtonText by remember(settings) { mutableStateOf(settings.buyButtonText) }
    var buyButtonUrl by remember(settings) { mutableStateOf(settings.buyButtonUrl) }
    var extraHashtags by remember(settings) { mutableStateOf(settings.extraHashtags) }
    var singlePhotoWithButton by remember(settings) { mutableStateOf(settings.singlePhotoWithButton) }
    var autoPublish by remember(settings) { mutableStateOf(settings.autoPublish) }

    var vkToken by remember(settings) { mutableStateOf(settings.vkAccessToken) }
    var vkGroupId by remember(settings) { mutableStateOf(settings.vkGroupId) }
    var autoPublishVk by remember(settings) { mutableStateOf(settings.autoPublishVk) }
    var vkOrderContact by remember(settings) { mutableStateOf(settings.vkOrderContact) }
    var vkBuyButtonText by remember(settings) { mutableStateOf(settings.vkBuyButtonText) }
    var vkBuyButtonUrl by remember(settings) { mutableStateOf(settings.vkBuyButtonUrl) }

    var maxToken by remember(settings) { mutableStateOf(settings.maxBotToken) }
    var maxChatId by remember(settings) { mutableStateOf(settings.maxChatId) }
    var autoPublishMax by remember(settings) { mutableStateOf(settings.autoPublishMax) }
    var maxOrderContact by remember(settings) { mutableStateOf(settings.maxOrderContact) }
    var maxBuyButtonText by remember(settings) { mutableStateOf(settings.maxBuyButtonText) }
    var maxBuyButtonUrl by remember(settings) { mutableStateOf(settings.maxBuyButtonUrl) }
    var discoveredMaxChats by remember { mutableStateOf<List<MaxChatInfo>>(emptyList()) }

    var markupPercent by remember(settings) { mutableStateOf(settings.markupPercent.toInt().toString()) }
    var markupFixed by remember(settings) { mutableStateOf(settings.markupFixed.toString()) }
    var roundTo by remember(settings) { mutableStateOf(settings.roundTo.toString()) }
    var batchLimit by remember(settings) { mutableStateOf(settings.maxProductsPerBatch.toString()) }
    var maxPhotos by remember(settings) { mutableStateOf(settings.maxPhotosPerPost.toString()) }
    var removeWatermarks by remember(settings) { mutableStateOf(settings.removeWatermarks) }
    var requirePhotos by remember(settings) { mutableStateOf(settings.requirePhotos) }

    var testingAi by remember { mutableStateOf(false) }
    var loadingModels by remember { mutableStateOf(false) }
    var testingTelegram by remember { mutableStateOf(false) }
    var testingVk by remember { mutableStateOf(false) }
    var testingMax by remember { mutableStateOf(false) }
    var loadingMaxChats by remember { mutableStateOf(false) }
    var showSecrets by remember { mutableStateOf(false) }

    val secretTransform = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation()

    fun collectSettings(): AppSettings = AppSettings(
        aiProvider = aiProvider,
        rusapixApiKey = AppSettings.normalizeApiKey(rusapixKey),
        rusapixBaseUrl = rusapixBaseUrl.trim().ifEmpty { AiProvider.RUSAPIX.defaultBaseUrl },
        rusapixModel = rusapixModel.trim().ifEmpty { AiProvider.RUSAPIX.defaultModel },
        openRouterApiKey = AppSettings.normalizeApiKey(openRouterKey),
        openRouterModel = openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultModel },
        customStyleHint = styleHint.trim(),
        telegramBotToken = tgToken.trim(),
        telegramChannelId = tgChannel.trim(),
        orderContact = orderContact.trim(),
        buyButtonText = buyButtonText.trim().ifEmpty { "🛒 Купить" },
        buyButtonUrl = buyButtonUrl.trim(),
        extraHashtags = extraHashtags.trim(),
        singlePhotoWithButton = singlePhotoWithButton,
        includeSourceLink = false,
        autoPublish = autoPublish,
        vkAccessToken = vkToken.trim(),
        vkGroupId = vkGroupId.trim(),
        autoPublishVk = autoPublishVk,
        vkOrderContact = vkOrderContact.trim(),
        vkBuyButtonText = vkBuyButtonText.trim().ifEmpty { "🛒 Купить" },
        vkBuyButtonUrl = vkBuyButtonUrl.trim(),
        maxBotToken = maxToken.trim(),
        maxChatId = maxChatId.trim(),
        autoPublishMax = autoPublishMax,
        maxOrderContact = maxOrderContact.trim(),
        maxBuyButtonText = maxBuyButtonText.trim().ifEmpty { "🛒 Купить" },
        maxBuyButtonUrl = maxBuyButtonUrl.trim(),
        markupPercent = markupPercent.toDoubleOrNull() ?: 0.0,
        markupFixed = markupFixed.toIntOrNull() ?: 0,
        roundTo = (roundTo.toIntOrNull() ?: 10).coerceAtLeast(1),
        maxProductsPerBatch = (batchLimit.toIntOrNull() ?: 5).coerceIn(1, 30),
        maxPhotosPerPost = (maxPhotos.toIntOrNull() ?: 8).coerceIn(1, 10),
        removeWatermarks = removeWatermarks,
        requirePhotos = requirePhotos,
        abkhaziaOrderLine = abkhaziaOrderLine.trim()
    )

    val aiReady = if (aiProvider == AiProvider.RUSAPIX) rusapixKey.isNotBlank() else openRouterKey.isNotBlank()
    val tgReady = tgToken.isNotBlank() && tgChannel.isNotBlank()
    val vkReady = vkToken.isNotBlank() && vkGroupId.isNotBlank()
    val maxReady = maxToken.isNotBlank() && maxChatId.isNotBlank()

    Column(modifier = Modifier.fillMaxSize()) {
        // Clean Section Tabs with live connection indicators
        Surface(tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Настройки",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Ключи",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.width(6.dp))
                        Switch(checked = showSecrets, onCheckedChange = { showSecrets = it })
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = activeSection == 0,
                        onClick = { activeSection = 0 },
                        label = { Text(if (aiReady) "🟢 ИИ" else "⚪️ ИИ") }
                    )
                    FilterChip(
                        selected = activeSection == 1,
                        onClick = { activeSection = 1 },
                        label = { Text(if (tgReady) "🟢 Telegram" else "⚪️ Telegram") }
                    )
                    FilterChip(
                        selected = activeSection == 2,
                        onClick = { activeSection = 2 },
                        label = { Text(if (vkReady) "🟢 ВК" else "⚪️ ВК") }
                    )
                    FilterChip(
                        selected = activeSection == 3,
                        onClick = { activeSection = 3 },
                        label = { Text(if (maxReady) "🟢 MAX" else "⚪️ MAX") }
                    )
                    FilterChip(
                        selected = activeSection == 4,
                        onClick = { activeSection = 4 },
                        label = { Text("⚙️ Цены и фото") }
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (activeSection) {
                0 -> {
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Нейросеть для описаний", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AiProvider.entries.forEach { p ->
                                    FilterChip(
                                        selected = aiProvider == p,
                                        onClick = { aiProvider = p },
                                        label = { Text(p.title) }
                                    )
                                }
                            }
                            if (aiProvider == AiProvider.RUSAPIX) {
                                OutlinedTextField(
                                    value = rusapixKey,
                                    onValueChange = { rusapixKey = AppSettings.normalizeApiKey(it) },
                                    label = { Text("RusAPIX API Key (sk-... или ссылка)") },
                                    supportingText = { Text("Можно вставить целиком ссылку rusapix.ru/login#k=...") },
                                    visualTransformation = secretTransform,
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = rusapixBaseUrl,
                                    onValueChange = { rusapixBaseUrl = it },
                                    label = { Text("Base URL RusAPIX") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                val chips = if (loadedModels.isNotEmpty()) loadedModels.take(12) else AiProvider.RUSAPIX.suggestedModels
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    chips.forEach { m ->
                                        FilterChip(
                                            selected = rusapixModel == m,
                                            onClick = { rusapixModel = m },
                                            label = { Text(m) }
                                        )
                                    }
                                }
                                OutlinedTextField(
                                    value = rusapixModel,
                                    onValueChange = { rusapixModel = it },
                                    label = { Text("Модель RusAPIX") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            } else {
                                OutlinedTextField(
                                    value = openRouterKey,
                                    onValueChange = { openRouterKey = it.trim() },
                                    label = { Text("OpenRouter API Key (sk-or-...)") },
                                    visualTransformation = secretTransform,
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                val chips = if (loadedModels.isNotEmpty()) loadedModels.take(12) else AiProvider.OPENROUTER.suggestedModels
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    chips.forEach { m ->
                                        FilterChip(
                                            selected = openRouterModel == m,
                                            onClick = { openRouterModel = m },
                                            label = { Text(m.substringAfter('/')) }
                                        )
                                    }
                                }
                                OutlinedTextField(
                                    value = openRouterModel,
                                    onValueChange = { openRouterModel = it },
                                    label = { Text("Модель OpenRouter") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            OutlinedTextField(
                                value = styleHint,
                                onValueChange = { styleHint = it },
                                label = { Text("Стиль описаний") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            loadingModels = true
                                            val cur = collectSettings()
                                            val (models, msg) = AiClient.fetchAvailableModels(
                                                cur.aiProvider,
                                                cur.activeApiKey(),
                                                cur.activeBaseUrl()
                                            )
                                            if (models.isNotEmpty()) loadedModels = models
                                            onNotify(msg)
                                            loadingModels = false
                                        }
                                    },
                                    enabled = !loadingModels && !testingAi,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (loadingModels) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("Модели")
                                }
                                FilledTonalButton(
                                    onClick = {
                                        scope.launch {
                                            testingAi = true
                                            val cur = collectSettings()
                                            val (_, msg) = AiClient.testConnection(
                                                cur.aiProvider,
                                                cur.activeApiKey(),
                                                cur.activeBaseUrl(),
                                                cur.activeModel()
                                            )
                                            onNotify(msg)
                                            testingAi = false
                                        }
                                    },
                                    enabled = !testingAi && !loadingModels,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (testingAi) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("Проверить ИИ")
                                }
                            }
                        }
                    }
                }

                1 -> {
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Telegram-канал", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = tgToken,
                                onValueChange = { tgToken = it },
                                label = { Text("Bot Token (от @BotFather)") },
                                visualTransformation = secretTransform,
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = tgChannel,
                                onValueChange = { tgChannel = it },
                                label = { Text("Канал (@username или -100...)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = orderContact,
                                onValueChange = { orderContact = it },
                                label = { Text("Контакт для заказа в ТГ (напр. @MainDmitri)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = abkhaziaOrderLine,
                                onValueChange = { abkhaziaOrderLine = it },
                                label = { Text("Строка для Абхазии (после «Для заказа»)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = buyButtonText,
                                onValueChange = { buyButtonText = it },
                                label = { Text("Текст кнопки в ТГ") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = buyButtonUrl,
                                onValueChange = { buyButtonUrl = it },
                                label = { Text("Ссылка кнопки «Купить» в ТГ (необязательно)") },
                                supportingText = { Text("Если пусто — подставится t.me/<твой контакт>") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = extraHashtags,
                                onValueChange = { extraHashtags = it },
                                label = { Text("Доп. хештеги в каждый пост") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            SettingsSwitchRow(
                                title = "1 фото + кнопка «Купить» в одном посте",
                                subtitle = "Выкл. = альбом всех фото + кнопка под ним",
                                checked = singlePhotoWithButton,
                                onCheckedChange = { singlePhotoWithButton = it }
                            )
                            SettingsSwitchRow(
                                title = "Автопубликация в ТГ при автосборе",
                                subtitle = "Выкл. = сохранять в «Черновики»",
                                checked = autoPublish,
                                onCheckedChange = { autoPublish = it }
                            )
                            FilledTonalButton(
                                onClick = {
                                    scope.launch {
                                        testingTelegram = true
                                        val (_, msg) = TelegramClient.testConnection(tgToken, tgChannel)
                                        onNotify(msg)
                                        testingTelegram = false
                                    }
                                },
                                enabled = !testingTelegram,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (testingTelegram) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                else Text("Проверить Telegram")
                            }
                        }
                    }
                }

                2 -> {
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("ВКонтакте (сообщество)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = vkToken,
                                onValueChange = { vkToken = it },
                                label = { Text("VK Access Token") },
                                supportingText = { Text("Для фото нужен токен админа (wall, photos, groups, offline)") },
                                visualTransformation = secretTransform,
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = vkGroupId,
                                onValueChange = { vkGroupId = it },
                                label = { Text("ID сообщества (напр. 243648198)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = vkOrderContact,
                                onValueChange = { vkOrderContact = it },
                                label = { Text("Username / контакт для ВК") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = vkBuyButtonText,
                                onValueChange = { vkBuyButtonText = it },
                                label = { Text("Текст кнопки «Купить» в ВК") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = vkBuyButtonUrl,
                                onValueChange = { vkBuyButtonUrl = it },
                                label = { Text("Ссылка «Купить» в ВК (необязательно)") },
                                supportingText = { Text("Если пусто — подставится vk.me/club<ID>") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            SettingsSwitchRow(
                                title = "Автодублировать посты в ВК",
                                subtitle = "Публиковать в ВК сразу при автосборе",
                                checked = autoPublishVk,
                                onCheckedChange = { autoPublishVk = it }
                            )
                            FilledTonalButton(
                                onClick = {
                                    scope.launch {
                                        testingVk = true
                                        val (_, msg) = VkClient.testConnection(vkToken, vkGroupId)
                                        onNotify(msg)
                                        testingVk = false
                                    }
                                },
                                enabled = !testingVk,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (testingVk) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                else Text("Проверить ВК")
                            }
                        }
                    }
                }

                3 -> {
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Мессенджер MAX (канал)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = maxToken,
                                onValueChange = { maxToken = it },
                                label = { Text("MAX Bot Token") },
                                supportingText = { Text("Добавь бота админом в канал MAX") },
                                visualTransformation = secretTransform,
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = maxChatId,
                                onValueChange = { maxChatId = it.filter { ch -> ch.isDigit() || ch == '-' } },
                                label = { Text("ID канала MAX (chat_id)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (discoveredMaxChats.isNotEmpty()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    discoveredMaxChats.forEach { chat ->
                                        FilterChip(
                                            selected = maxChatId == chat.chatId.toString(),
                                            onClick = { maxChatId = chat.chatId.toString() },
                                            label = { Text("${chat.title.take(20)} (${chat.chatId})") }
                                        )
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = maxOrderContact,
                                onValueChange = { maxOrderContact = it },
                                label = { Text("Username / контакт для MAX") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = maxBuyButtonText,
                                onValueChange = { maxBuyButtonText = it },
                                label = { Text("Текст кнопки «Купить» в MAX") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = maxBuyButtonUrl,
                                onValueChange = { maxBuyButtonUrl = it },
                                label = { Text("Ссылка кнопки «Купить» в MAX") },
                                supportingText = { Text("Напр. https://max.ru/...") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            SettingsSwitchRow(
                                title = "Автодублировать посты в MAX",
                                subtitle = "Публиковать с фото и кнопкой «Купить»",
                                checked = autoPublishMax,
                                onCheckedChange = { autoPublishMax = it }
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            loadingMaxChats = true
                                            val (chats, msg) = MaxClient.fetchBotChannels(maxToken)
                                            if (chats.isNotEmpty()) {
                                                discoveredMaxChats = chats
                                                if (maxChatId.isBlank()) maxChatId = chats.first().chatId.toString()
                                            }
                                            onNotify(msg)
                                            loadingMaxChats = false
                                        }
                                    },
                                    enabled = !loadingMaxChats && !testingMax,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (loadingMaxChats) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("Найти каналы")
                                }
                                FilledTonalButton(
                                    onClick = {
                                        scope.launch {
                                            testingMax = true
                                            val (_, msg) = MaxClient.testConnection(maxToken, maxChatId)
                                            onNotify(msg)
                                            testingMax = false
                                        }
                                    },
                                    enabled = !testingMax && !loadingMaxChats,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    if (testingMax) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                                    else Text("Проверить MAX")
                                }
                            }
                        }
                    }
                }

                else -> {
                    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Цены, фото и автосбор", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = markupPercent,
                                    onValueChange = { markupPercent = it.filter { ch -> ch.isDigit() || ch == '-' } },
                                    label = { Text("Наценка %") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = markupFixed,
                                    onValueChange = { markupFixed = it.filter { ch -> ch.isDigit() || ch == '-' } },
                                    label = { Text("+ фикс ₽") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = roundTo,
                                    onValueChange = { roundTo = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Округл. ₽") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // Live price preview calculator
                            val previewSettings = collectSettings()
                            val sampleOut = previewSettings.calculateFinalPrice(1000.0) ?: 1000
                            val profit = sampleOut - 1000
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Пример расчёта: 1 000 ₽ опт → ${AiClient.formatRub(sampleOut)} в посте (прибыль ${if (profit >= 0) "+" else ""}$profit ₽)",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }

                            HorizontalDivider()
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = batchLimit,
                                    onValueChange = { batchLimit = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Товаров за сбор") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = maxPhotos,
                                    onValueChange = { maxPhotos = it.filter { ch -> ch.isDigit() } },
                                    label = { Text("Макс. фото (до 10)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            SettingsSwitchRow(
                                title = "Удалять водяные знаки с фото",
                                subtitle = "Очищает углы и нижние полосы с логотипами",
                                checked = removeWatermarks,
                                onCheckedChange = { removeWatermarks = it }
                            )
                            SettingsSwitchRow(
                                title = "Только товары с фото",
                                subtitle = "Пропускать позиции без фотографий",
                                checked = requirePhotos,
                                onCheckedChange = { requirePhotos = it }
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        // Pinned Save bar at bottom
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = {
                    val updated = collectSettings()
                    onSave(updated)
                    onNotify("Настройки сохранены!")
                },
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Сохранить настройки")
            }
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
