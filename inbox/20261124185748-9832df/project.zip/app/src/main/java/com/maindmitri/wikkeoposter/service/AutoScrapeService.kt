package com.maindmitri.wikkeoposter.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.maindmitri.wikkeoposter.MainActivity
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.ProductStatus
import com.maindmitri.wikkeoposter.data.SettingsRepository
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.ImageDownloader
import com.maindmitri.wikkeoposter.network.TelegramClient
import com.maindmitri.wikkeoposter.network.VkClient
import com.maindmitri.wikkeoposter.scraper.WikkeoJsScripts
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

data class BatchScrapeState(
    val running: Boolean = false,
    val total: Int = 0,
    val done: Int = 0,
    val published: Int = 0,
    val statusText: String = "",
    val lastFinishedMessage: String = "",
    val dbVersion: Long = 0L
)

object AutoScrapeStateHolder {
    private val _state = MutableStateFlow(BatchScrapeState())
    val state: StateFlow<BatchScrapeState> = _state.asStateFlow()

    fun update(transform: (BatchScrapeState) -> BatchScrapeState) {
        _state.value = transform(_state.value)
    }

    fun bumpDbVersion() {
        _state.value = _state.value.copy(dbVersion = _state.value.dbVersion + 1L)
    }

    fun clearLastFinishedMessage() {
        _state.value = _state.value.copy(lastFinishedMessage = "")
    }
}

class AutoScrapeService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var batchJob: Job? = null
    private var headlessWebView: WebView? = null
    private var pageLoadedSignal: CompletableDeferred<Unit>? = null
    private var expectedPathFragment: String = ""
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopBatchAndSelf("Автосбор остановлен")
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val urls = intent.getStringArrayListExtra(EXTRA_URLS).orEmpty()
                if (urls.isEmpty()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForegroundSafe(
                    buildNotification(
                        title = "Wikkeo Poster • Автосбор",
                        text = "Запуск обработки (${urls.size} шт.)...",
                        progress = 0,
                        max = urls.size,
                        ongoing = true
                    )
                )
                startBatch(urls)
                return START_NOT_STICKY
            }
            else -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        stopBatchAndSelf("Автосбор завершён по лимиту фонового времени Android")
    }

    override fun onDestroy() {
        batchJob?.cancel()
        releaseWakeLock()
        destroyWebView()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startForegroundSafe(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun acquireWakeLock() {
        runCatching {
            if (wakeLock == null) {
                val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK,
                    "WikkeoPoster::AutoScrapeWakeLock"
                ).apply {
                    setReferenceCounted(false)
                }
            }
            wakeLock?.acquire(20 * 60 * 1000L)
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView(): WebView {
        headlessWebView?.let { return it }
        val wv = WebView(applicationContext).apply {
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            this.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadsImagesAutomatically = true
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                useWideViewPort = true
                loadWithOverviewMode = true
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean = false

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    // Keep running in background
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    val frag = expectedPathFragment
                    if (frag.isBlank() || (url != null && url.contains(frag, ignoreCase = true))) {
                        pageLoadedSignal?.complete(Unit)
                    }
                }
            }
            layout(0, 0, 1080, 1920)
        }
        headlessWebView = wv
        return wv
    }

    private fun destroyWebView() {
        runCatching {
            headlessWebView?.stopLoading()
            headlessWebView?.destroy()
        }
        headlessWebView = null
    }

    private suspend fun evaluateJs(script: String): String? {
        val wv = headlessWebView ?: return null
        val deferred = CompletableDeferred<String?>()
        withContext(Dispatchers.Main) {
            wv.evaluateJavascript(script) { res -> deferred.complete(res) }
        }
        return withTimeoutOrNull(12_000) { deferred.await() }
    }

    /**
     * Clears previous DOM cleanly via about:blank and waits specifically for the target product URL
     * so item #2..N never accidentally re-read item #1's stale DOM.
     */
    private suspend fun loadProductPageClean(url: String): Boolean {
        val wv = withContext(Dispatchers.Main) { ensureWebView() }
        val targetSlug = url.trimEnd('/').substringAfterLast('/')
        expectedPathFragment = targetSlug

        // Reset previous page DOM so stale <h1>/<img> from item #1 can never trigger early ready
        withContext(Dispatchers.Main) {
            wv.stopLoading()
            wv.loadUrl("about:blank")
        }
        delay(120)

        val signal = CompletableDeferred<Unit>()
        pageLoadedSignal = signal
        withContext(Dispatchers.Main) {
            wv.loadUrl(url)
        }
        withTimeoutOrNull(14_000) { signal.await() }

        val checkScript = buildDomReadyCheckJs(targetSlug)
        var titleSeenTicks = 0
        for (attempt in 0 until 25) {
            val state = WikkeoJsScripts.decodeJsStringResult(evaluateJs(checkScript))
            if (state == "ready") return true
            if (state == "title") {
                titleSeenTicks++
                if (titleSeenTicks == 1) {
                    withContext(Dispatchers.Main) {
                        wv.evaluateJavascript("window.scrollBy(0, 450);", null)
                    }
                }
                if (titleSeenTicks >= 6) return true
            }
            delay(200)
        }
        return titleSeenTicks > 0
    }

    private fun startBatch(urls: List<String>) {
        batchJob?.cancel()
        acquireWakeLock()

        batchJob = serviceScope.launch {
            val settings = SettingsRepository(applicationContext).load()
            val dbHelper = ProductDbHelper(applicationContext)
            val uniqueUrls = urls.map { ProductDbHelper.cleanUrl(it) }.distinct()
            val total = uniqueUrls.size
            val doneCount = AtomicInteger(0)
            val pubCount = AtomicInteger(0)
            val ioSemaphore = Semaphore(3)
            val telegramMutex = Mutex()
            val workers = mutableListOf<Deferred<Unit>>()

            AutoScrapeStateHolder.update {
                it.copy(
                    running = true,
                    total = total,
                    done = 0,
                    published = 0,
                    statusText = "Сканирую 1/$total...",
                    lastFinishedMessage = ""
                )
            }

            try {
                for ((idx, itemUrl) in uniqueUrls.withIndex()) {
                    val scanText = "Сканирую ${idx + 1}/$total • готово: ${doneCount.get()}"
                    AutoScrapeStateHolder.update { it.copy(statusText = scanText) }
                    updateNotification(
                        title = "Wikkeo Poster • Автосбор (${doneCount.get()}/$total)",
                        text = scanText,
                        progress = doneCount.get(),
                        max = total
                    )

                    val loaded = runCatching { loadProductPageClean(itemUrl) }.getOrDefault(false)
                    if (!loaded) continue

                    val rawJson = runCatching { evaluateJs(WikkeoJsScripts.EXTRACT_PRODUCT_JS) }.getOrNull()
                    val parsedRaw = WikkeoJsScripts.parseExtractedProduct(rawJson) ?: continue
                    // Always bind strictly to the target itemUrl & its unique ID
                    val parsed = parsedRaw.copy(
                        id = WikkeoJsScripts.extractProductId(itemUrl),
                        url = itemUrl
                    )

                    val worker = async(Dispatchers.IO) {
                        ioSemaphore.withPermit {
                            runCatching {
                                val saved = finalizeProduct(
                                    parsed = parsed,
                                    settings = settings,
                                    dbHelper = dbHelper,
                                    telegramMutex = telegramMutex
                                )
                                val finished = doneCount.incrementAndGet()
                                if (saved.status == ProductStatus.PUBLISHED) {
                                    pubCount.incrementAndGet()
                                }
                                val text = "Готово $finished/$total (в канале: ${pubCount.get()})"
                                AutoScrapeStateHolder.update {
                                    it.copy(
                                        done = finished,
                                        published = pubCount.get(),
                                        statusText = text,
                                        dbVersion = it.dbVersion + 1L
                                    )
                                }
                                updateNotification(
                                    title = "Wikkeo Poster • Автосбор ($finished/$total)",
                                    text = text,
                                    progress = finished,
                                    max = total
                                )
                            }
                            Unit
                        }
                    }
                    workers.add(worker)
                }

                AutoScrapeStateHolder.update {
                    it.copy(statusText = "Завершаю фото, ИИ и Telegram (${doneCount.get()}/$total)...")
                }
                workers.awaitAll()

                val pubNote = if (settings.autoPublish) ", опубликовано: ${pubCount.get()}" else ""
                val summary = "Автосбор завершён! Сохранено: ${doneCount.get()}$pubNote"
                showCompletionNotification(summary)
                stopBatchAndSelf(summary)
            } catch (e: Exception) {
                val msg = "Автосбор остановлен: ${e.message ?: "отменено"}"
                stopBatchAndSelf(msg)
            }
        }
    }

    private suspend fun finalizeProduct(
        parsed: Product,
        settings: AppSettings,
        dbHelper: ProductDbHelper,
        telegramMutex: Mutex
    ): Product {
        val finalPrice = settings.calculateFinalPrice(parsed.wholesalePrice)
        val photoCountLimit = if (settings.singlePhotoWithButton) 1 else settings.maxPhotosPerPost
        val localImgs = ImageDownloader.downloadProductImages(
            imageUrls = parsed.imageUrls,
            refererUrl = parsed.url,
            targetDir = dbHelper.productFolder(parsed.id),
            maxPhotos = photoCountLimit
        )

        var product = parsed.copy(
            finalPrice = finalPrice,
            localImages = localImgs
        )

        val aiRes = AiClient.generateTelegramPost(product, settings)
        product = product.copy(
            generatedPost = aiRes.postHtml,
            lastError = if (aiRes.success) "" else aiRes.error
        )

        dbHelper.upsert(product)
        AutoScrapeStateHolder.bumpDbVersion()

        if (settings.autoPublish) {
            val tgRes = telegramMutex.withLock {
                val res = TelegramClient.publishProduct(product, settings)
                delay(1000)
                res
            }
            product = if (tgRes.success) {
                product.copy(
                    status = ProductStatus.PUBLISHED,
                    telegramMessageId = tgRes.messageId,
                    publishedAt = System.currentTimeMillis(),
                    lastError = ""
                )
            } else {
                product.copy(
                    status = ProductStatus.ERROR,
                    lastError = tgRes.error
                )
            }
            dbHelper.upsert(product)
            AutoScrapeStateHolder.bumpDbVersion()
        }

        if (settings.autoPublishVk && settings.vkAccessToken.isNotBlank() && settings.vkGroupId.isNotBlank()) {
            val vkRes = telegramMutex.withLock {
                val res = VkClient.publishProduct(product, settings)
                delay(1000)
                res
            }
            if (vkRes.success) {
                product = product.copy(vkPostId = vkRes.postId ?: 1L)
                dbHelper.upsert(product)
                AutoScrapeStateHolder.bumpDbVersion()
            }
        }

        return product
    }

    private fun stopBatchAndSelf(message: String) {
        batchJob?.cancel()
        batchJob = null
        releaseWakeLock()
        destroyWebView()
        AutoScrapeStateHolder.update {
            it.copy(
                running = false,
                statusText = "",
                lastFinishedMessage = message,
                dbVersion = it.dbVersion + 1L
            )
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Автосбор Wikkeo",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Прогресс фонового сбора товаров с Wikkeo и публикации в Telegram"
            }
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(
        title: String,
        text: String,
        progress: Int,
        max: Int,
        ongoing: Boolean
    ): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPending = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AutoScrapeService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openPending)
            .setOngoing(ongoing)
            .setOnlyAlertOnce(true)

        if (ongoing && max > 0) {
            builder.setProgress(max, progress.coerceIn(0, max), progress == 0)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Стоп", stopPending)
        }
        return builder.build()
    }

    private fun updateNotification(title: String, text: String, progress: Int, max: Int) {
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(
                NOTIFICATION_ID,
                buildNotification(title, text, progress, max, ongoing = true)
            )
        }
    }

    private fun showCompletionNotification(summary: String) {
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val openIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openPending = PendingIntent.getActivity(
                this,
                2,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val doneNotif = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Wikkeo Poster")
                .setContentText(summary)
                .setContentIntent(openPending)
                .setAutoCancel(true)
                .build()
            nm.notify(COMPLETION_NOTIFICATION_ID, doneNotif)
        }
    }

    companion object {
        private const val CHANNEL_ID = "wikkeo_autoscrape_channel"
        private const val NOTIFICATION_ID = 1001
        private const val COMPLETION_NOTIFICATION_ID = 1002
        private const val ACTION_START = "com.maindmitri.wikkeoposter.ACTION_START_AUTOSCRAPE"
        private const val ACTION_STOP = "com.maindmitri.wikkeoposter.ACTION_STOP_AUTOSCRAPE"
        private const val EXTRA_URLS = "extra_urls"

        private fun buildDomReadyCheckJs(targetSlug: String): String {
            val quotedSlug = JSONObject.quote(targetSlug)
            return """
                (function() {
                    var href = window.location.href || '';
                    if (href === 'about:blank' || href.indexOf($quotedSlug) === -1) return 'wait';
                    var h1 = document.querySelector('h1');
                    var hasTitle = !!(h1 && h1.innerText && h1.innerText.trim().length > 2);
                    var hasImg = Array.from(document.images || []).some(function(i) {
                        return i.complete && i.naturalWidth >= 200 && i.naturalHeight >= 200;
                    });
                    return (hasTitle && hasImg) ? 'ready' : (hasTitle ? 'title' : 'wait');
                })();
            """.trimIndent()
        }

        fun start(context: Context, urls: List<String>) {
            val intent = Intent(context, AutoScrapeService::class.java).apply {
                action = ACTION_START
                putStringArrayListExtra(EXTRA_URLS, ArrayList(urls))
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, AutoScrapeService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
