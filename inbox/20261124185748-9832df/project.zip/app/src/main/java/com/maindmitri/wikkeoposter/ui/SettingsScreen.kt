package com.maindmitri.wikkeoposter.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AiProvider
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.TelegramClient
import com.maindmitri.wikkeoposter.network.VkClient
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onNotify: (String) -> Unit
) {
    val scope = rememberCoroutineScope()

    var aiProvider by remember(settings) { mutableStateOf(settings.aiProvider) }
    var rusapixKey by remember(settings) { mutableStateOf(settings.rusapixApiKey) }
    var rusapixBaseUrl by remember(settings) { mutableStateOf(settings.rusapixBaseUrl) }
    var rusapixModel by remember(settings) { mutableStateOf(settings.rusapixModel) }
    var openRouterKey by remember(settings) { mutableStateOf(settings.openRouterApiKey) }
    var openRouterModel by remember(settings) { mutableStateOf(settings.openRouterModel) }
    var loadedModels by remember(aiProvider) { mutableStateOf<List<String>>(emptyList()) }
    var styleHint by remember(settings) { mutableStateOf(settings.customStyleHint) }

    var tgToken by remember(settings) { mutableStateOf(settings.telegramBotToken) }
    var tgChannel by remember(settings) { mutableStateOf(settings.telegramChannelId) }
    var orderContact by remember(settings) { mutableStateOf(settings.orderContact) }
    var buyButtonText by remember(settings) { mutableStateOf(settings.buyButtonText) }
    var buyButtonUrl by remember(settings) { mutableStateOf(settings.buyButtonUrl) }
    var extraHashtags by remember(settings) { mutableStateOf(settings.extraHashtags) }
    var singlePhotoWithButton by remember(settings) { mutableStateOf(settings.singlePhotoWithButton) }
    var includeLink by remember(settings) { mutableStateOf(settings.includeSourceLink) }
    var autoPublish by remember(settings) { mutableStateOf(settings.autoPublish) }
    var vkToken by remember(settings) { mutableStateOf(settings.vkAccessToken) }
    var vkGroupId by remember(settings) { mutableStateOf(settings.vkGroupId) }
    var autoPublishVk by remember(settings) { mutableStateOf(settings.autoPublishVk) }

    var markupPercent by remember(settings) { mutableStateOf(settings.markupPercent.toInt().toString()) }
    var markupFixed by remember(settings) { mutableStateOf(settings.markupFixed.toString()) }
    var roundTo by remember(settings) { mutableStateOf(settings.roundTo.toString()) }
    var batchLimit by remember(settings) { mutableStateOf(settings.maxProductsPerBatch.toString()) }
    var maxPhotos by remember(settings) { mutableStateOf(settings.maxPhotosPerPost.toString()) }

    var testingAi by remember { mutableStateOf(false) }
    var loadingModels by remember { mutableStateOf(false) }
    var testingTelegram by remember { mutableStateOf(false) }
    var testingVk by remember { mutableStateOf(false) }
    var showSecrets by remember { mutableStateOf(false) }

    fun collectSettings(): AppSettings = AppSettings(
        aiProvider = aiProvider,
        rusapixApiKey = AppSettings.normalizeApiKey(rusapixKey),
        rusapixBaseUrl = rusapixBaseUrl.trim().ifEmpty { AiProvider.RUSAPIX.defaultBaseUrl },
        rusapixModel = rusapixModel.trim().ifEmpty { AiProvider.RUSAPIX.defaultModel },
        openRouterApiKey = AppSettings.normalizeApiKey(openRouterKey),
        openRouterModel = openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultModel },
        customStyleHint = styleHint.trim(),
        telegramBotToken = tgToken.trim(),
        telegramChannelId = tgChannel.trim(),
        orderContact = orderContact.trim(),
        buyButtonText = buyButtonText.trim().ifEmpty { "🛒 Купить" },
        buyButtonUrl = buyButtonUrl.trim(),
        extraHashtags = extraHashtags.trim(),
        singlePhotoWithButton = singlePhotoWithButton,
        includeSourceLink = includeLink,
        autoPublish = autoPublish,
        vkAccessToken = vkToken.trim(),
        vkGroupId = vkGroupId.trim(),
        autoPublishVk = autoPublishVk,
        markupPercent = markupPercent.toDoubleOrNull() ?: 0.0,
        markupFixed = markupFixed.toIntOrNull() ?: 0,
        roundTo = (roundTo.toIntOrNull() ?: 10).coerceAtLeast(1),
        maxProductsPerBatch = (batchLimit.toIntOrNull() ?: 5).coerceIn(1, 30),
        maxPhotosPerPost = (maxPhotos.toIntOrNull() ?: 8).coerceIn(1, 10)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Показывать ключи и токены",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Switch(checked = showSecrets, onCheckedChange = { showSecrets = it })
        }

        // AI Provider section (RusAPIX + OpenRouter)
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Нейросеть для описаний",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiProvider.entries.forEach { p ->
                        FilterChip(
                            selected = aiProvider == p,
                            onClick = { aiProvider = p },
                            label = { Text(p.title) }
                        )
                    }
                }

                if (aiProvider == AiProvider.RUSAPIX) {
                    OutlinedTextField(
                        value = rusapixKey,
                        onValueChange = { rusapixKey = AppSettings.normalizeApiKey(it) },
                        label = { Text("RusAPIX API Key (sk-... или ссылка)") },
                        supportingText = {
                            Text("Можно вставить целиком ссылку rusapix.ru/login#k=... — ключ извлечётся сам")
                        },
                        visualTransformation = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = rusapixBaseUrl,
                        onValueChange = { rusapixBaseUrl = it },
                        label = { Text("Base URL RusAPIX") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    val chips = if (loadedModels.isNotEmpty()) loadedModels.take(12) else AiProvider.RUSAPIX.suggestedModels
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        chips.forEach { m ->
                            FilterChip(
                                selected = rusapixModel == m,
                                onClick = { rusapixModel = m },
                                label = { Text(m) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = rusapixModel,
                        onValueChange = { rusapixModel = it },
                        label = { Text("Модель RusAPIX") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    OutlinedTextField(
                        value = openRouterKey,
                        onValueChange = { openRouterKey = it.trim() },
                        label = { Text("OpenRouter API Key (sk-or-...)") },
                        visualTransformation = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    val chips = if (loadedModels.isNotEmpty()) loadedModels.take(12) else AiProvider.OPENROUTER.suggestedModels
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        chips.forEach { m ->
                            FilterChip(
                                selected = openRouterModel == m,
                                onClick = { openRouterModel = m },
                                label = { Text(m.substringAfter('/')) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = openRouterModel,
                        onValueChange = { openRouterModel = it },
                        label = { Text("Модель OpenRouter") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                OutlinedTextField(
                    value = styleHint,
                    onValueChange = { styleHint = it },
                    label = { Text("Стиль описаний для постов") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                loadingModels = true
                                val current = collectSettings()
                                val (models, msg) = AiClient.fetchAvailableModels(
                                    provider = current.aiProvider,
                                    apiKeyRaw = current.activeApiKey(),
                                    baseUrl = current.activeBaseUrl()
                                )
                                if (models.isNotEmpty()) loadedModels = models
                                onNotify(msg)
                                loadingModels = false
                            }
                        },
                        enabled = !loadingModels && !testingAi,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (loadingModels) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        } else {
                            Text("Модели")
                        }
                    }

                    FilledTonalButton(
                        onClick = {
                            scope.launch {
                                testingAi = true
                                val current = collectSettings()
                                val (_, msg) = AiClient.testConnection(
                                    provider = current.aiProvider,
                                    apiKeyRaw = current.activeApiKey(),
                                    baseUrl = current.activeBaseUrl(),
                                    model = current.activeModel()
                                )
                                onNotify(msg)
                                testingAi = false
                            }
                        },
                        enabled = !testingAi && !loadingModels,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (testingAi) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        } else {
                            Text("Проверить ИИ")
                        }
                    }
                }
            }
        }

        // Telegram section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Telegram-канал и кнопка «Купить»",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = tgToken,
                    onValueChange = { tgToken = it },
                    label = { Text("Bot Token (от @BotFather)") },
                    visualTransformation = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tgChannel,
                    onValueChange = { tgChannel = it },
                    label = { Text("Канал (@username или -100...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = orderContact,
                    onValueChange = { orderContact = it },
                    label = { Text("Контакт для заказа (напр. @MainDmitri)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = buyButtonText,
                    onValueChange = { buyButtonText = it },
                    label = { Text("Текст кнопки в посте") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = buyButtonUrl,
                    onValueChange = { buyButtonUrl = it },
                    label = { Text("Ссылка кнопки «Купить» (необязательно)") },
                    supportingText = {
                        Text("Если пусто — автоматически откроет твой контакт (t.me/username)")
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = extraHashtags,
                    onValueChange = { extraHashtags = it },
                    label = { Text("Доп. хештеги в каждый пост") },
                    supportingText = {
                        Text("Основные (#мужское, #женское, #детское, #модное, категории) ставятся автоматически")
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("1 фото + кнопка «Купить» в одном посте", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Если выкл. — альбом из всех фото + кнопка под ним",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = singlePhotoWithButton,
                        onCheckedChange = { singlePhotoWithButton = it }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Автопубликация при автосборе", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Если выкл. — товары сохраняются в «Черновики»",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = autoPublish, onCheckedChange = { autoPublish = it })
                }

                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            testingTelegram = true
                            val (_, msg) = TelegramClient.testConnection(tgToken, tgChannel)
                            onNotify(msg)
                            testingTelegram = false
                        }
                    },
                    enabled = !testingTelegram,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (testingTelegram) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Проверить бота и канал")
                    }
                }
            }
        }


        // VK Community section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "ВКонтакте (сообщество)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = vkToken,
                    onValueChange = { vkToken = it },
                    label = { Text("VK Access Token") },
                    supportingText = {
                        Text("Для постов с фото нужен токен админа (wall, photos, groups, offline); ключ сообщества публикует только текст")
                    },
                    visualTransformation = if (showSecrets) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = vkGroupId,
                    onValueChange = { vkGroupId = it },
                    label = { Text("ID сообщества (напр. 243648198 или club243648198)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Автодублировать посты в ВК", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Публиковать в ВК сразу при автосборе",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = autoPublishVk, onCheckedChange = { autoPublishVk = it })
                }
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            testingVk = true
                            val (_, msg) = VkClient.testConnection(vkToken, vkGroupId)
                            onNotify(msg)
                            testingVk = false
                        }
                    },
                    enabled = !testingVk,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (testingVk) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Проверить ВК сообщество")
                    }
                }
            }
        }

        // Pricing & Limits section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Цены и лимиты сбора",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = markupPercent,
                        onValueChange = { markupPercent = it.filter { ch -> ch.isDigit() || ch == '-' } },
                        label = { Text("Наценка %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = markupFixed,
                        onValueChange = { markupFixed = it.filter { ch -> ch.isDigit() || ch == '-' } },
                        label = { Text("+ фикс ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = roundTo,
                        onValueChange = { roundTo = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Округл. ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = batchLimit,
                        onValueChange = { batchLimit = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Товаров за автосбор") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = maxPhotos,
                        onValueChange = { maxPhotos = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Макс. фото (до 10)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Button(
            onClick = {
                val updated = collectSettings()
                onSave(updated)
                onNotify("Настройки сохранены!")
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Сохранить настройки")
        }

        Spacer(Modifier.height(16.dp))
    }
}
