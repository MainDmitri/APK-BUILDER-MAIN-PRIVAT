package com.example.tgbotclient

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// ---------- helpers ----------

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

private fun listTime(t: Long): String =
    SimpleDateFormat(if (sameDay(t, System.currentTimeMillis())) "HH:mm" else "dd.MM", Locale.getDefault()).format(Date(t))

@Composable
fun rememberServiceRunning(): State<Boolean> = produceState(BotPollingService.running) {
    while (true) {
        value = BotPollingService.running
        delay(700)
    }
}

// ---------- small components ----------

@Composable
fun Avatar(name: String, size: androidx.compose.ui.unit.Dp = 46.dp) {
    val palette = listOf(0xFFE17076, 0xFF7BC862, 0xFFE5CA77, 0xFF65AADD, 0xFFA695E7, 0xFFEE7AAE, 0xFF6EC9CB, 0xFFFAA774)
    val color = Color(palette[(name.hashCode() and 0x7fffffff) % palette.size])
    Box(Modifier.size(size).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
fun StatusDot(running: Boolean) {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulseAlpha"
    )
    val c by animateColorAsState(if (running) Color(0xFF4CD964) else Color(0xFFB0B7BD), label = "dotColor")
    Box(Modifier.size(10.dp).alpha(if (running) a else 1f).clip(CircleShape).background(c))
}

@Composable
fun GradientHeader(content: @Composable RowScope.() -> Unit) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val brush = Brush.horizontalGradient(
        if (dark) listOf(Color(0xFF1F4466), Color(0xFF17212B)) else listOf(Color(0xFF2AABEE), Color(0xFF1B8FD0))
    )
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Row(
            Modifier.fillMaxWidth().background(brush).statusBarsPadding().padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
fun HeaderButton(glyph: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(glyph, fontSize = 22.sp, color = Color.White)
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp).animateContentSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

// ---------- chats list ----------

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatsScreen(refresh: Int, onOpenChat: (Long) -> Unit, onSettings: () -> Unit) {
    val context = LocalContext.current
    val storage = remember { Storage.get(context) }
    val scope = rememberCoroutineScope()
    val botName = remember { context.getSharedPreferences("bot", Context.MODE_PRIVATE).getString("bot_name", "").orEmpty() }
    val running by rememberServiceRunning()
    var chats by remember { mutableStateOf(emptyList<Chat>()) }
    var query by remember { mutableStateOf("") }
    var toDelete by remember { mutableStateOf<Chat?>(null) }

    LaunchedEffect(refresh) { chats = withContext(Dispatchers.IO) { storage.getChats() } }
    val shown = remember(chats, query) {
        if (query.isBlank()) chats
        else chats.filter { it.title.contains(query, true) || it.lastMessage.contains(query, true) }
    }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            Column(Modifier.weight(1f)) {
                Text("TG Bot Client Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(running)
                    Spacer(Modifier.width(6.dp))
                    Crossfade(running, label = "status") {
                        Text(
                            (if (botName.isNotBlank()) "$botName · " else "") + if (it) "работает" else "остановлен",
                            style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            }
            HeaderButton("⚙", onSettings)
        }

        AnimatedVisibility(visible = chats.isNotEmpty()) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Поиск по чатам") },
                singleLine = true, shape = RoundedCornerShape(28.dp),
                trailingIcon = { if (query.isNotEmpty()) Text("✕", Modifier.clip(CircleShape).clickable { query = "" }.padding(12.dp)) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }

        if (chats.isEmpty()) {
            EmptyState(onSettings)
        } else if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Text("Ничего не найдено", Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
        } else {
            LazyColumn(contentPadding = WindowInsets.navigationBars.asPaddingValues()) {
                itemsIndexed(shown, key = { _, c -> c.id }) { index, chat ->
                    val state = remember { MutableTransitionState(index > 12).apply { targetState = true } }
                    val delayMs = if (index < 12) index * 35 else 0
                    AnimatedVisibility(
                        visibleState = state,
                        enter = fadeIn(tween(300, delayMillis = delayMs)) + slideInVertically(tween(300, delayMillis = delayMs)) { it / 3 }
                    ) {
                        ChatRow(chat, onClick = { onOpenChat(chat.id) }, onLongClick = { toDelete = chat })
                    }
                }
            }
        }
    }

    toDelete?.let { chat ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить чат?") },
            text = { Text("«${chat.title}» и вся переписка будут удалены с этого устройства.") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch {
                        chats = withContext(Dispatchers.IO) { storage.deleteChat(chat.id); storage.getChats() }
                    }
                }) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(chat: Chat, onClick: () -> Unit, onLongClick: () -> Unit) {
    val haptics = LocalHapticFeedback.current
    Row(
        Modifier.fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = {
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                onLongClick()
            })
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(chat.title)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(chat.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                chat.lastMessage, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), style = MaterialTheme.typography.bodyMedium
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(listTime(chat.lastTime), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
    }
}

@Composable
private fun EmptyState(onSettings: () -> Unit) {
    val t = rememberInfiniteTransition(label = "bob")
    val dy by t.animateFloat(
        initialValue = 0f, targetValue = -18f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bobY"
    )
    Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("💬", fontSize = 64.sp, modifier = Modifier.graphicsLayer { translationY = dy })
        Spacer(Modifier.height(16.dp))
        Text("Пока нет чатов", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
            "Запустите бота в настройках и напишите ему в Telegram",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = onSettings, shape = RoundedCornerShape(24.dp)) { Text("Открыть настройки") }
    }
}

// ---------- chat ----------

@Composable
private fun DateChip(t: Long) {
    val now = System.currentTimeMillis()
    val label = when {
        sameDay(t, now) -> "Сегодня"
        sameDay(t, now - 86_400_000L) -> "Вчера"
        else -> SimpleDateFormat("d MMMM", Locale.getDefault()).format(Date(t))
    }
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
        Text(
            label, style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                .padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    msg: TgMessage, quoted: TgMessage?,
    onReply: () -> Unit, onCopy: () -> Unit, onSaveTemplate: () -> Unit, onDelete: () -> Unit, onQuoteClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val haptics = LocalHapticFeedback.current
    var menu by remember { mutableStateOf(false) }
    // only messages that just arrived animate in; old ones are shown instantly when scrolled into view
    val state = remember(msg.id) {
        MutableTransitionState(System.currentTimeMillis() - msg.time > 8000).apply { targetState = true }
    }
    val bg = if (msg.isBot) cs.primary else cs.surfaceVariant
    val fg = if (msg.isBot) Color.White else cs.onSurface
    val shape = RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (msg.isBot) 18.dp else 4.dp, bottomEnd = if (msg.isBot) 4.dp else 18.dp
    )

    AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(220)) +
            scaleIn(animationSpec = tween(220), initialScale = 0.85f, transformOrigin = TransformOrigin(if (msg.isBot) 1f else 0f, 1f)) +
            slideInVertically(tween(220)) { it / 3 }
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 2.dp),
            horizontalAlignment = if (msg.isBot) Alignment.End else Alignment.Start
        ) {
            Box {
                Column(
                    Modifier.widthIn(max = 300.dp).clip(shape).background(bg)
                        .combinedClickable(onClick = onReply, onLongClick = {
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            menu = true
                        })
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    if (msg.replyTo != null) {
                        Row(Modifier.height(IntrinsicSize.Min).padding(bottom = 6.dp).clip(RoundedCornerShape(6.dp)).clickable(onClick = onQuoteClick)) {
                            Box(Modifier.width(3.dp).fillMaxHeight().background(if (msg.isBot) Color.White else cs.primary))
                            Spacer(Modifier.width(6.dp))
                            Column {
                                Text(quoted?.fromName ?: "Сообщение", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = fg)
                                Text(quoted?.text ?: "…", maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = 0.8f))
                            }
                        }
                    }
                    if (!msg.isBot) {
                        Text(msg.fromName, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = cs.primary)
                    }
                    Text(msg.text, color = fg)
                    Text(
                        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.time)),
                        style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.65f),
                        modifier = Modifier.align(Alignment.End)
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Ответить") }, onClick = { menu = false; onReply() })
                    DropdownMenuItem(text = { Text("Копировать") }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(text = { Text("В шаблоны") }, onClick = { menu = false; onSaveTemplate() })
                    DropdownMenuItem(text = { Text("Удалить у себя") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun SendButton(enabled: Boolean, sending: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "sendBg")
    val scale by animateFloatAsState(
        if (enabled) 1f else 0.88f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy), label = "sendScale"
    )
    Box(
        Modifier.size(52.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape).background(bg)
            .clickable(enabled = enabled && !sending, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (sending) CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
        else Text("➤", fontSize = 20.sp, color = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ChatScreen(chatId: Long, onBack: () -> Unit, refresh: Int) {
    val context = LocalContext.current
    val storage = remember { Storage.get(context) }
    val scope = rememberCoroutineScope()
    val token = remember { context.getSharedPreferences("bot", Context.MODE_PRIVATE).getString("token", "").orEmpty() }
    var title by remember { mutableStateOf("Чат $chatId") }
    var messages by remember { mutableStateOf(emptyList<TgMessage>()) }
    var text by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<TgMessage?>(null) }
    var replyPreview by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var firstLoad by remember { mutableStateOf(true) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var templates by remember { mutableStateOf(Templates.load(context)) }
    var showTemplates by remember { mutableStateOf(false) }
    var editIndex by remember { mutableStateOf<Int?>(null) }
    var draft by remember { mutableStateOf("") }
    var attachMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(refresh) {
        val (t, m) = withContext(Dispatchers.IO) { storage.getChatTitle(chatId) to storage.getMessages(chatId) }
        t?.let { title = it }
        messages = m
    }
    val nearBottom by remember {
        derivedStateOf {
            // not laid out yet -> treat as bottom, so the "↓" button doesn't flash on open
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index
            last == null || last >= messages.lastIndex - 1
        }
    }
    LaunchedEffect(messages.size) {
        if (messages.isEmpty()) return@LaunchedEffect
        if (firstLoad) {
            listState.scrollToItem(messages.lastIndex)
            firstLoad = false
        } else if (nearBottom || messages.last().isBot) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    fun setReply(m: TgMessage) {
        replyTo = m
        replyPreview = m.text.take(60)
    }

    fun send() {
        val msgText = text.trim()
        if (msgText.isEmpty() || sending) return
        if (token.isBlank()) {
            Toast.makeText(context, "Укажите токен в настройках", Toast.LENGTH_SHORT).show()
            return
        }
        val reply = replyTo
        sending = true
        scope.launch {
            try {
                // real message_id from Telegram, so replying to our own messages works
                val sentId = sendText(token, chatId, msgText, reply?.id)
                val now = System.currentTimeMillis()
                messages = withContext(Dispatchers.IO) {
                    storage.saveMessage(TgMessage(sentId, chatId, "Бот", msgText, now, true, reply?.id))
                    storage.getMessages(chatId)
                }
                text = ""
                replyTo = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(context, "Не отправлено: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                sending = false
            }
        }
    }

    fun sendPicked(uri: Uri, asPhoto: Boolean) {
        if (sending) return
        if (token.isBlank()) {
            Toast.makeText(context, "Укажите токен в настройках", Toast.LENGTH_SHORT).show()
            return
        }
        val caption = text.trim()
        val reply = replyTo
        sending = true
        progress = 0f
        scope.launch {
            try {
                val (sentId, fileName) = sendFile(context, token, chatId, uri, asPhoto, caption, reply?.id) { progress = it }
                val label = if (asPhoto) "[Фото]" else "[Документ: $fileName]"
                val now = System.currentTimeMillis()
                messages = withContext(Dispatchers.IO) {
                    storage.saveMessage(
                        TgMessage(sentId, chatId, "Бот", if (caption.isEmpty()) label else "$label $caption", now, true, reply?.id, if (asPhoto) "photo" else "document")
                    )
                    storage.getMessages(chatId)
                }
                text = ""
                replyTo = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Toast.makeText(context, "Не отправлено: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                sending = false
                progress = null
            }
        }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendPicked(uri, true) }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) sendPicked(uri, false) }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            HeaderButton("←", onBack)
            Spacer(Modifier.width(8.dp))
            Avatar(title, 40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("сообщений: ${messages.size}", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f))
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (messages.isEmpty()) {
                Text("Сообщений пока нет", Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
            }
            LazyColumn(
                state = listState, modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
            ) {
                itemsIndexed(messages, key = { _, m -> m.id }) { index, msg ->
                    val prev = messages.getOrNull(index - 1)
                    Column {
                        if (prev == null || !sameDay(prev.time, msg.time)) DateChip(msg.time)
                        MessageBubble(
                            msg = msg,
                            quoted = msg.replyTo?.let { rid -> messages.firstOrNull { it.id == rid } },
                            onReply = { setReply(msg) },
                            onSaveTemplate = {
                                templates = templates + msg.text
                                Templates.save(context, templates)
                                Toast.makeText(context, "Добавлено в шаблоны", Toast.LENGTH_SHORT).show()
                            },
                            onCopy = {
                                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                    .setPrimaryClip(ClipData.newPlainText("message", msg.text))
                                Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                            },
                            onDelete = {
                                scope.launch {
                                    messages = withContext(Dispatchers.IO) { storage.deleteMessage(chatId, msg.id); storage.getMessages(chatId) }
                                }
                            },
                            onQuoteClick = {
                                val i = messages.indexOfFirst { it.id == msg.replyTo }
                                if (i >= 0) scope.launch { listState.animateScrollToItem(i) }
                            }
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = !nearBottom && messages.isNotEmpty(),
                modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp),
                enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()
            ) {
                Box(
                    Modifier.size(44.dp).shadow(6.dp, CircleShape).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                        .clickable { scope.launch { listState.animateScrollToItem(messages.lastIndex) } },
                    contentAlignment = Alignment.Center
                ) { Text("↓", fontSize = 20.sp) }
            }
        }

        AnimatedVisibility(
            visible = replyTo != null,
            enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
        ) {
            Row(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(32.dp).background(MaterialTheme.colorScheme.primary))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Ответ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(replyPreview, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                TextButton(onClick = { replyTo = null }) { Text("✕") }
            }
        }

        AnimatedVisibility(visible = showTemplates, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            LazyRow(
                Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(top = 6.dp),
                contentPadding = PaddingValues(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { TemplateChip("＋ Новый", accent = true, onClick = { draft = ""; editIndex = -1 }) }
                itemsIndexed(templates) { i, t ->
                    TemplateChip(
                        t.take(28), onClick = {
                            val add = Templates.expand(t, title.substringBefore(' '))
                            text = if (text.isBlank()) add else text.trimEnd() + " " + add
                        },
                        onLongClick = { draft = t; editIndex = i }
                    )
                }
            }
        }

        AnimatedVisibility(visible = progress != null) {
            LinearProgressIndicator(progress = { progress ?: 0f }, modifier = Modifier.fillMaxWidth())
        }

        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                .navigationBarsPadding().imePadding().padding(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Box(Modifier.padding(bottom = 4.dp)) {
                ToolButton("📎", false) { attachMenu = true }
                DropdownMenu(expanded = attachMenu, onDismissRequest = { attachMenu = false }) {
                    DropdownMenuItem(text = { Text("Фото") }, onClick = { attachMenu = false; pickPhoto.launch("image/*") })
                    DropdownMenuItem(text = { Text("Файл") }, onClick = { attachMenu = false; pickFile.launch("*/*") })
                }
            }
            Box(Modifier.padding(bottom = 4.dp)) { ToolButton("⚡", showTemplates) { showTemplates = !showTemplates } }
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                modifier = Modifier.weight(1f), maxLines = 5,
                shape = RoundedCornerShape(26.dp),
                placeholder = { Text("Сообщение") }
            )
            Spacer(Modifier.width(8.dp))
            SendButton(enabled = text.isNotBlank(), sending = sending, onClick = { send() })
        }
    }

    editIndex?.let { idx ->
        AlertDialog(
            onDismissRequest = { editIndex = null },
            title = { Text(if (idx < 0) "Новый шаблон" else "Шаблон") },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth(),
                        minLines = 2, maxLines = 6, placeholder = { Text("Текст шаблона") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Переменные: {имя}, {дата}, {время}", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = draft.isNotBlank(), onClick = {
                    val list = templates.toMutableList()
                    if (idx < 0) list.add(draft.trim()) else list[idx] = draft.trim()
                    templates = list
                    Templates.save(context, list)
                    editIndex = null
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    if (idx >= 0) TextButton(onClick = {
                        val list = templates.toMutableList().also { it.removeAt(idx) }
                        templates = list
                        Templates.save(context, list)
                        editIndex = null
                    }) { Text("Удалить") }
                    TextButton(onClick = { editIndex = null }) { Text("Отмена") }
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TemplateChip(label: String, accent: Boolean = false, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    val cs = MaterialTheme.colorScheme
    Text(
        label, maxLines = 1, overflow = TextOverflow.Ellipsis,
        color = if (accent) Color.White else cs.onSurface,
        modifier = Modifier.clip(RoundedCornerShape(18.dp))
            .background(if (accent) cs.primary else cs.surfaceVariant)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun ToolButton(glyph: String, active: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent, label = "toolBg")
    Box(Modifier.size(44.dp).clip(CircleShape).background(bg).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(glyph, fontSize = 22.sp)
    }
}

// ---------- settings ----------

@Composable
private fun ThemeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant, label = "chipBg")
    val fg by animateColorAsState(if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, label = "chipFg")
    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(label, color = fg)
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onStart: () -> Unit, theme: String, onTheme: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("bot", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val running by rememberServiceRunning()
    var token by remember { mutableStateOf(prefs.getString("token", "").orEmpty()) }
    var showToken by remember { mutableStateOf(false) }
    var notify by remember { mutableStateOf(prefs.getBoolean("notify", true)) }
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            HeaderButton("←", onBack)
            Spacer(Modifier.width(8.dp))
            Text("Настройки", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard("Бот") {
                OutlinedTextField(
                    value = token, onValueChange = { token = it },
                    label = { Text("Bot Token") }, singleLine = true,
                    visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = { Text(if (showToken) "🙈" else "👁", Modifier.clip(CircleShape).clickable { showToken = !showToken }.padding(10.dp)) },
                    shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(running)
                    Spacer(Modifier.width(8.dp))
                    Crossfade(running, label = "settingsStatus") { Text(if (it) "Бот работает" else "Бот остановлен") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(shape = RoundedCornerShape(14.dp), onClick = {
                        val newToken = token.trim()
                        if (newToken.isEmpty()) {
                            Toast.makeText(context, "Укажите токен бота", Toast.LENGTH_SHORT).show()
                        } else {
                            // update ids belong to a specific bot: a stale offset would hide a new bot's updates
                            if (newToken != prefs.getString("token", "")) prefs.edit().putLong("offset", 0L).apply()
                            prefs.edit().putString("token", newToken).apply()
                            androidx.core.content.ContextCompat.startForegroundService(
                                context, Intent(context, BotPollingService::class.java)
                            )
                            onStart()
                        }
                    }) { Text(if (running) "Перезапустить" else "Старт") }
                    OutlinedButton(
                        enabled = running, shape = RoundedCornerShape(14.dp),
                        onClick = { context.stopService(Intent(context, BotPollingService::class.java)) }
                    ) { Text("Стоп") }
                }
            }

            SectionCard("Оформление") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system" to "Авто", "dark" to "Тёмная", "light" to "Светлая").forEach { (key, label) ->
                        ThemeChip(label, theme == key) { onTheme(key) }
                    }
                }
            }

            SectionCard("Уведомления и данные") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Уведомления о сообщениях")
                    Switch(checked = notify, onCheckedChange = { notify = it; prefs.edit().putBoolean("notify", it).apply() })
                }
                OutlinedButton(onClick = { confirmClear = true }, shape = RoundedCornerShape(14.dp)) { Text("Очистить историю") }
            }
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Очистить историю?") },
            text = { Text("Все чаты и сообщения будут удалены с этого устройства.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        withContext(Dispatchers.IO) { Storage.get(context).clearAll() }
                        Toast.makeText(context, "История очищена", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Очистить") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } }
        )
    }
}
