package com.example.tgbotclient

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

private const val MAX_FILE = 50L * 1024 * 1024  // Bot API limit for uploads
private const val MAX_PHOTO = 10L * 1024 * 1024 // Bot API limit for sendPhoto

private val http = OkHttpClient.Builder()
    .connectTimeout(30, TimeUnit.SECONDS)
    .writeTimeout(120, TimeUnit.SECONDS)
    .readTimeout(120, TimeUnit.SECONDS)
    .build()

/** Calls a send* method and returns the new message_id; throws with Telegram's description on failure. */
private fun call(token: String, method: String, body: RequestBody): Long {
    val req = Request.Builder().url("https://api.telegram.org/bot$token/$method").post(body).build()
    return http.newCall(req).execute().use { resp ->
        val json = JSONObject(resp.body?.string().orEmpty().ifBlank { "{}" })
        if (!json.optBoolean("ok")) throw IOException(json.optString("description", "HTTP ${resp.code}"))
        json.getJSONObject("result").getLong("message_id")
    }
}

private fun replyParams(id: Long): String =
    JSONObject().put("message_id", id).put("allow_sending_without_reply", true).toString()

suspend fun sendText(token: String, chatId: Long, text: String, replyTo: Long?): Long =
    withContext(Dispatchers.IO) {
        val body = JSONObject().apply {
            put("chat_id", chatId)
            put("text", text)
            if (replyTo != null) put("reply_parameters", JSONObject(replyParams(replyTo)))
        }
        call(token, "sendMessage", body.toString().toRequestBody("application/json".toMediaType()))
    }

/** Streams the file from the content Uri (never loaded fully into memory) and reports progress 0..1. */
private class UriBody(
    private val resolver: ContentResolver, private val uri: Uri,
    private val type: MediaType?, private val size: Long, private val onProgress: (Float) -> Unit
) : RequestBody() {
    override fun contentType() = type
    override fun contentLength() = if (size > 0) size else -1L
    override fun writeTo(sink: BufferedSink) {
        val input = resolver.openInputStream(uri) ?: throw IOException("не удалось открыть файл")
        input.use {
            val buf = ByteArray(16 * 1024)
            var done = 0L
            var lastPct = -1
            while (true) {
                val n = it.read(buf)
                if (n < 0) break
                sink.write(buf, 0, n)
                done += n
                if (size > 0) {
                    val pct = (done * 100 / size).toInt()
                    if (pct != lastPct) { lastPct = pct; onProgress(pct / 100f) }
                }
            }
        }
    }
}

/** Sends a picked file as photo or document. Returns (message_id, file name). */
suspend fun sendFile(
    context: Context, token: String, chatId: Long, uri: Uri,
    asPhoto: Boolean, caption: String, replyTo: Long?, onProgress: (Float) -> Unit
): Pair<Long, String> = withContext(Dispatchers.IO) {
    val resolver = context.contentResolver
    var name = "file"
    var size = -1L
    resolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val si = c.getColumnIndex(OpenableColumns.SIZE)
            if (ni >= 0) c.getString(ni)?.let { name = it }
            if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
        }
    }
    if (size > MAX_FILE) throw IOException("файл больше 50 МБ")
    if (asPhoto && size > MAX_PHOTO) throw IOException("фото больше 10 МБ — отправьте как файл")
    if (caption.length > 1024) throw IOException("подпись длиннее 1024 символов")

    val body = UriBody(resolver, uri, resolver.getType(uri)?.toMediaTypeOrNull(), size, onProgress)
    val mb = MultipartBody.Builder().setType(MultipartBody.FORM)
        .addFormDataPart("chat_id", chatId.toString())
    if (caption.isNotBlank()) mb.addFormDataPart("caption", caption)
    if (replyTo != null) mb.addFormDataPart("reply_parameters", replyParams(replyTo))
    mb.addFormDataPart(if (asPhoto) "photo" else "document", name, body)
    call(token, if (asPhoto) "sendPhoto" else "sendDocument", mb.build()) to name
}
