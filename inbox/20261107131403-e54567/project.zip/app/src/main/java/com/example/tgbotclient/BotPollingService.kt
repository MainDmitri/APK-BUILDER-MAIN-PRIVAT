package com.example.tgbotclient

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object MessageBus {
    var onNewMessage: ((TgMessage) -> Unit)? = null
}

class BotPollingService : Service() {

    companion object {
        @Volatile var running = false
    }

    private var job: Job? = null
    @Volatile private var call: Call? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
    private lateinit var storage: Storage

    override fun onCreate() {
        super.onCreate()
        storage = Storage.get(this)
        running = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra("action")) {
            "stop" -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForegroundService()
                startPolling()
            }
        }
        return START_STICKY
    }

    private fun startForegroundService() {
        val channelId = "bot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Bot Messages", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("TG Bot Client Pro")
            .setContentText("Long-polling активен")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        startForeground(1, notification)

        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tgbot:polling").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun toast(msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    private fun startPolling() {
        job?.cancel()
        call?.cancel() // otherwise the old long-poll lives up to 25s and Telegram answers 409
        job = scope.launch {
            val prefs = getSharedPreferences("bot", Context.MODE_PRIVATE)
            val token = prefs.getString("token", "").orEmpty().trim()
            if (token.isEmpty()) {
                toast("Укажите токен бота в настройках")
                stopSelf()
                return@launch
            }
            var offset = prefs.getLong("offset", 0L)

            try {
                getMe(token)?.let { prefs.edit().putString("bot_name", it.optString("first_name")).apply() }
            } catch (_: Exception) {}

            while (isActive) {
                try {
                    val url = "https://api.telegram.org/bot$token/getUpdates".toHttpUrl().newBuilder()
                        .addQueryParameter("offset", offset.toString())
                        .addQueryParameter("timeout", "25")
                        .addQueryParameter("allowed_updates", """["message","edited_message","callback_query"]""")
                        .build()
                    val c = client.newCall(Request.Builder().url(url).build())
                    call = c
                    val (code, body) = c.execute().use { it.code to it.body?.string().orEmpty() }

                    if (code == 401 || code == 404) {
                        toast("Неверный токен бота")
                        stopSelf()
                        return@launch
                    }
                    val json = JSONObject(body)
                    if (!json.optBoolean("ok")) { // 409 / 429 / 5xx: without a pause this was a tight request loop
                        delay(4000)
                        continue
                    }
                    val results = json.getJSONArray("result")
                    for (i in 0 until results.length()) {
                        val update = results.getJSONObject(i)
                        offset = update.getLong("update_id") + 1
                        try {
                            handleUpdate(update, token)
                        } catch (_: Exception) {} // one bad update must not block the queue
                    }
                    if (results.length() > 0) prefs.edit().putLong("offset", offset).apply()
                } catch (e: Exception) {
                    delay(4000)
                }
            }
        }
    }

    private fun chatTitle(chat: JSONObject): String =
        chat.optString("title").ifBlank {
            listOf(chat.optString("first_name"), chat.optString("last_name")).filter { it.isNotBlank() }.joinToString(" ")
        }.ifBlank { chat.optString("username") }.ifBlank { "Чат ${chat.optLong("id")}" }

    private fun handleUpdate(update: JSONObject, token: String) {
        // Message / edited
        val message = update.optJSONObject("message")
            ?: update.optJSONObject("edited_message")

        if (message != null) {
            val chat = message.getJSONObject("chat")
            val chatId = chat.getLong("id")
            val fromName = message.optJSONObject("from")?.optString("first_name").orEmpty().ifBlank { chatTitle(chat) }
            val text = when {
                message.has("text") -> message.getString("text")
                else -> {
                    val label = mediaLabel(message)
                    val caption = message.optString("caption")
                    if (caption.isBlank()) label else "$label $caption"
                }
            }
            val msgId = message.getLong("message_id")
            val time = message.getLong("date") * 1000
            val replyTo = message.optJSONObject("reply_to_message")?.getLong("message_id")

            val tgMsg = TgMessage(msgId, chatId, fromName, text, time, false, replyTo)
            storage.saveMessage(tgMsg, chatTitle(chat), chat.optString("type", "private"))
            MessageBus.onNewMessage?.invoke(tgMsg)
            showNotification(fromName, text, chatId)
            return
        }

        // Callback query
        val cb = update.optJSONObject("callback_query")
        if (cb != null) {
            val data = cb.optString("data")
            val from = cb.optJSONObject("from")?.optString("first_name") ?: "?"
            val msg = cb.optJSONObject("message")
            if (msg != null) {
                val chat = msg.getJSONObject("chat")
                val chatId = chat.getLong("id")
                val text = "[Кнопка] $from нажал: $data"
                val now = System.currentTimeMillis()
                val tgMsg = TgMessage(now, chatId, from, text, now, false)
                storage.saveMessage(tgMsg, chatTitle(chat), chat.optString("type", "private"))
                MessageBus.onNewMessage?.invoke(tgMsg)
                showNotification(from, text, chatId)
            }
            // Answer callback to remove loading
            try {
                val answer = "https://api.telegram.org/bot$token/answerCallbackQuery".toHttpUrl().newBuilder()
                    .addQueryParameter("callback_query_id", cb.getString("id"))
                    .build()
                client.newCall(Request.Builder().url(answer).build()).execute().close()
            } catch (_: Exception) {}
        }
    }

    private fun mediaLabel(message: JSONObject): String = when {
        message.has("photo") -> "[Фото]"
        message.has("document") -> "[Документ: ${message.getJSONObject("document").optString("file_name")}]"
        message.has("voice") -> "[Голосовое]"
        message.has("video") -> "[Видео]"
        message.has("sticker") -> "[Стикер]"
        message.has("location") -> "[Геолокация]"
        message.has("contact") -> "[Контакт]"
        else -> "[Сообщение]"
    }

    private fun showNotification(from: String, text: String, chatId: Long) {
        if (!getSharedPreferences("bot", Context.MODE_PRIVATE).getBoolean("notify", true)) return
        val channelId = "bot_channel"
        val notifId = 2 + (abs(chatId) % 1_000_000L).toInt() // 1 is the foreground-service notification
        val openIntent = PendingIntent.getActivity(
            this, notifId, Intent(this, MainActivity::class.java).apply {
                putExtra("open_chat", chatId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle(from)
            .setContentText(text.take(120))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(notifId, n)
    }

    private fun getMe(token: String): JSONObject? {
        val req = Request.Builder().url("https://api.telegram.org/bot$token/getMe").build()
        val body = client.newCall(req).execute().use { it.body?.string() } ?: return null
        val json = JSONObject(body)
        return if (json.optBoolean("ok")) json.getJSONObject("result") else null
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        call?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        scope.cancel()
        super.onDestroy()
    }
}
