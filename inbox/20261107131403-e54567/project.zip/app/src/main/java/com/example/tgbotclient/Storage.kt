package com.example.tgbotclient

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

data class Chat(
    val id: Long,
    val title: String,
    val type: String,
    val lastMessage: String,
    val lastTime: Long
)

data class TgMessage(
    val id: Long,
    val chatId: Long,
    val fromName: String,
    val text: String,
    val time: Long,
    val isBot: Boolean,
    val replyTo: Long? = null,
    val mediaType: String? = null
)

class Storage private constructor(context: Context) : SQLiteOpenHelper(context, "tgbot.db", null, 2) {

    companion object {
        @Volatile private var inst: Storage? = null
        fun get(context: Context): Storage = inst ?: synchronized(this) {
            inst ?: Storage(context.applicationContext).also { inst = it }
        }
    }


    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE chats (
                id INTEGER PRIMARY KEY,
                title TEXT,
                type TEXT,
                last_message TEXT,
                last_time INTEGER
            )
        """)
        createMessages(db)
    }

    // message_id is unique only within a chat, so the key must include chat_id
    private fun createMessages(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE messages (
                id INTEGER,
                chat_id INTEGER,
                from_name TEXT,
                text TEXT,
                time INTEGER,
                is_bot INTEGER,
                reply_to INTEGER,
                media_type TEXT,
                PRIMARY KEY (chat_id, id)
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        if (old < 2) {
            db.execSQL("ALTER TABLE messages RENAME TO messages_old")
            createMessages(db)
            db.execSQL("""
                INSERT OR IGNORE INTO messages (id, chat_id, from_name, text, time, is_bot, reply_to, media_type)
                SELECT id, chat_id, from_name, text, time, is_bot, reply_to, media_type FROM messages_old
            """)
            db.execSQL("DROP TABLE messages_old")
        }
    }

    fun saveMessage(msg: TgMessage, chatTitle: String? = null, chatType: String? = null) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("id", msg.id)
                put("chat_id", msg.chatId)
                put("from_name", msg.fromName)
                put("text", msg.text)
                put("time", msg.time)
                put("is_bot", if (msg.isBot) 1 else 0)
                put("reply_to", msg.replyTo)
                put("media_type", msg.mediaType)
            }
            db.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

            val chatCv = ContentValues().apply {
                put("last_message", msg.text.take(100))
                put("last_time", msg.time)
                if (chatTitle != null) put("title", chatTitle)
                if (chatType != null) put("type", chatType)
            }
            if (db.update("chats", chatCv, "id=?", arrayOf(msg.chatId.toString())) == 0) {
                chatCv.put("id", msg.chatId)
                if (chatTitle == null) chatCv.put("title", "Чат ${msg.chatId}")
                if (chatType == null) chatCv.put("type", "private")
                db.insert("chats", null, chatCv)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun getChats(): List<Chat> {
        val list = mutableListOf<Chat>()
        val c = readableDatabase.query("chats", null, null, null, null, null, "last_time DESC")
        c.use {
            while (it.moveToNext()) {
                list.add(Chat(
                    it.getLong(0),
                    it.getString(1) ?: "",
                    it.getString(2) ?: "",
                    it.getString(3) ?: "",
                    it.getLong(4)
                ))
            }
        }
        return list
    }

    fun getMessages(chatId: Long): List<TgMessage> {
        val list = mutableListOf<TgMessage>()
        val c = readableDatabase.query(
            "messages", null, "chat_id=?", arrayOf(chatId.toString()),
            null, null, "time DESC, id DESC", "200"
        )
        c.use {
            while (it.moveToNext()) {
                list.add(TgMessage(
                    it.getLong(0),
                    it.getLong(1),
                    it.getString(2) ?: "",
                    it.getString(3) ?: "",
                    it.getLong(4),
                    it.getInt(5) == 1,
                    if (it.isNull(6)) null else it.getLong(6),
                    it.getString(7)
                ))
            }
        }
        return list.reversed()
    }

    fun clearAll() {
        writableDatabase.delete("messages", null, null)
        writableDatabase.delete("chats", null, null)
    }

    fun getChatTitle(chatId: Long): String? =
        readableDatabase.query("chats", arrayOf("title"), "id=?", arrayOf(chatId.toString()), null, null, null)
            .use { if (it.moveToFirst()) it.getString(0) else null }

    fun deleteMessage(chatId: Long, id: Long) {
        writableDatabase.delete("messages", "chat_id=? AND id=?", arrayOf(chatId.toString(), id.toString()))
    }

    fun deleteChat(chatId: Long) {
        writableDatabase.delete("messages", "chat_id=?", arrayOf(chatId.toString()))
        writableDatabase.delete("chats", "id=?", arrayOf(chatId.toString()))
    }
}
