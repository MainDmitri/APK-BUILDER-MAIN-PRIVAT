package com.example.tgbotclient

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MainActivity : ComponentActivity() {

    private val requestNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // group chat ids are negative, so don't test for > 0
        val openChat = if (intent?.hasExtra("open_chat") == true) intent.getLongExtra("open_chat", 0L) else null
        setContent { AppRoot(initialChat = openChat) }
    }
}

@Composable
fun AppTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val blue = Color(0xFF2AABEE)
    val scheme = if (dark) darkColorScheme(
        primary = blue, onPrimary = Color.White,
        primaryContainer = Color(0xFF1E5F8A), onPrimaryContainer = Color.White,
        background = Color(0xFF0E1621), surface = Color(0xFF17212B), surfaceVariant = Color(0xFF223140)
    ) else lightColorScheme(
        primary = blue, onPrimary = Color.White,
        primaryContainer = Color(0xFFD2ECFB),
        background = Color(0xFFF1F5F9), surface = Color.White, surfaceVariant = Color(0xFFE4EAF0)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AppRoot(initialChat: Long? = null) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("bot", Context.MODE_PRIVATE) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "system") ?: "system") }
    var screen by rememberSaveable { mutableStateOf(if (initialChat != null) "chat" else "chats") }
    var selectedChat by rememberSaveable { mutableStateOf(initialChat) }
    var refresh by remember { mutableStateOf(0) }

    DisposableEffect(Unit) {
        MessageBus.onNewMessage = { refresh++ }
        onDispose { MessageBus.onNewMessage = null }
    }
    BackHandler(enabled = screen != "chats") { screen = "chats" }

    AppTheme(theme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    if (targetState == "chats") {
                        (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                            (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(200)))
                    } else {
                        (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                            (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(200)))
                    }
                },
                label = "screen"
            ) { s ->
                when (s) {
                    "settings" -> SettingsScreen(
                        onBack = { screen = "chats" },
                        onStart = { screen = "chats" },
                        theme = theme,
                        onTheme = { theme = it; prefs.edit().putString("theme", it).apply() }
                    )
                    "chat" -> selectedChat?.let { id ->
                        ChatScreen(chatId = id, onBack = { screen = "chats" }, refresh = refresh)
                    }
                    else -> ChatsScreen(
                        refresh = refresh,
                        onOpenChat = { id -> selectedChat = id; screen = "chat" },
                        onSettings = { screen = "settings" }
                    )
                }
            }
        }
    }
}
