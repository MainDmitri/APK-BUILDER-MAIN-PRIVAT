package com.example.tgbotclient

import android.content.Context
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Quick-reply templates, stored as a JSON array in the "bot" prefs. */
object Templates {
    private const val KEY = "templates"
    private val defaults = listOf(
        "Здравствуйте, {имя}!",
        "Спасибо за обращение!",
        "Одну минуту, уточню информацию.",
        "Хорошего дня!"
    )

    fun load(context: Context): List<String> {
        val raw = context.getSharedPreferences("bot", Context.MODE_PRIVATE).getString(KEY, null) ?: return defaults
        return try {
            val a = JSONArray(raw)
            List(a.length()) { a.getString(it) }
        } catch (_: Exception) {
            defaults
        }
    }

    fun save(context: Context, list: List<String>) {
        context.getSharedPreferences("bot", Context.MODE_PRIVATE).edit().putString(KEY, JSONArray(list).toString()).apply()
    }

    fun expand(template: String, name: String): String {
        val now = Date()
        return template
            .replace("{имя}", name)
            .replace("{дата}", SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(now))
            .replace("{время}", SimpleDateFormat("HH:mm", Locale.getDefault()).format(now))
    }
}
