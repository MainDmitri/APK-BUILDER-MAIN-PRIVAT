package com.pultitool.remote.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pultitool.remote.adb.AdbManager
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AdbScreen() {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val adb = remember { AdbManager(ctx) }
    val prefs = remember { ctx.getSharedPreferences("adb_tool", android.content.Context.MODE_PRIVATE) }

    var ip by remember { mutableStateOf(prefs.getString("last_ip", "") ?: "") }
    var url by remember { mutableStateOf("https://github.com/yuliskov/SmartTube/releases/latest/download/smarttube_stable.apk") }
    var log by remember { mutableStateOf("ADB готов\n") }
    var busy by remember { mutableStateOf(false) }
    var packages by remember { mutableStateOf(listOf<String>()) }
    var frozen by remember { mutableStateOf(prefs.getStringSet("frozen", emptySet()) ?: emptySet()) }

    fun append(s: String) { log += "• $s\n" }
    fun saveFrozen(set: Set<String>) {
        frozen = set
        prefs.edit().putStringSet("frozen", set).apply()
    }

    val pickApk = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                val dest = File(ctx.cacheDir, "picked.apk")
                ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
                append(adb.installApk(dest))
            } catch (e: Exception) { append("✖ ${e.message}") }
            busy = false
        }
    }

    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            try {
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
                val dest = File(ctx.cacheDir, name)
                ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { i.copyTo(it) } }
                append(adb.push(dest, "/sdcard/Download/$name"))
            } catch (e: Exception) { append("✖ ${e.message}") }
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("ADB Инструменты", style = MaterialTheme.typography.headlineSmall)
        Text("Android TV · порт 5555 · без root", style = MaterialTheme.typography.bodySmall)

        OutlinedTextField(ip, { ip = it; prefs.edit().putString("last_ip", it).apply() },
            label = { Text("IP телевизора") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(url, { url = it },
            label = { Text("URL APK") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = {
                scope.launch {
                    busy = true
                    append("Сканирование сети...")
                    try {
                        append("Поиск устройств с включённым ADB на порту 5555…")
                        val found = AdbManager.scanForAdb { host -> scope.launch { append("→ $host") } }
                        if (found.isNotEmpty()) ip = found.first()
                        append(if (found.isEmpty()) "Устройства с доступным ADB не найдены" else "Найдено устройств: ${found.size}")
                    } catch (e: Exception) {
                        append("Ошибка сканирования: ${e.message ?: "неизвестная ошибка"}")
                    } finally { busy = false }
                }
            }, enabled = !busy) { Text("Скан") }

            Button(onClick = {
                scope.launch {
                    busy = true
                    adb.connect(ip).onSuccess {
                        append("Подключено к $ip")
                        append(adb.shell("getprop ro.product.model") + " / Android " + adb.shell("getprop ro.build.version.release"))
                    }.onFailure { append("✖ ${it.message}") }
                    busy = false
                }
            }, enabled = !busy && ip.isNotBlank()) { Text("Подключить") }
        }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    val list = adb.shell("pm list packages -3").lines()
                        .map { it.removePrefix("package:").trim() }
                        .filter { it.isNotBlank() }.sorted()
                    packages = list
                    append("Приложений: ${list.size}")
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Список приложений") }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "app.apk" }
                    val f = File(ctx.getExternalFilesDir("apk"), name)
                    append("Скачиваю $name...")
                    AdbManager.download(url, f) { if (it % 25 == 0) append("  $it%") }
                    append(adb.installApk(f))
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Скачать и установить") }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { pickApk.launch(arrayOf("*/*")) }, enabled = !busy) { Text("APK с телефона") }
            Button(onClick = { pickFile.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Файл на ТВ") }
        }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    adb.shell("settings put global private_dns_specifier dns.adguard-dns.com")
                    adb.shell("settings put global private_dns_mode hostname")
                    append("AdGuard DNS включён")
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("AdGuard DNS") }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    adb.shell("settings put global private_dns_mode opportunistic")
                    append("DNS возвращён")
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Вернуть DNS") }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    adb.shell("screencap -p /sdcard/pulti.png")
                    val f = File(ctx.getExternalFilesDir("shots"), "screen_${System.currentTimeMillis()}.png")
                    append(adb.pull("/sdcard/pulti.png", f))
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Скриншот") }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    val out = adb.shell("logcat -d -t 200")
                    append("Logcat (${out.lines().size} строк):")
                    append(out.take(1200))
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Logcat") }

        Button(onClick = {
            scope.launch {
                busy = true
                try {
                    adb.shell("nohup sh -c 'sleep 1800; input keyevent 223' </dev/null >/dev/null 2>&1 &")
                    append("Таймер сна: 30 мин")
                } catch (e: Exception) { append("✖ ${e.message}") }
                busy = false
            }
        }, enabled = !busy) { Text("Сон через 30 мин") }

        Button(onClick = {
            scope.launch {
                busy = true
                val current = frozen.toList()
                current.forEach { pkg ->
                    try {
                        val r = adb.shell("pm enable $pkg")
                        append("$pkg: $r")
                        if (r.contains("enabled", true)) saveFrozen(frozen - pkg)
                    } catch (e: Exception) { append("$pkg: ${e.message}") }
                }
                append(if (frozen.isEmpty()) "✔ Всё разморожено" else "Осталось: ${frozen.size}")
                busy = false
            }
        }, enabled = !busy && frozen.isNotEmpty()) { Text("Разморозить всё (${frozen.size})") }

        Button(onClick = { adb.close(); append("Отключено") }) { Text("Отключиться") }

        if (packages.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Приложения:", style = MaterialTheme.typography.titleSmall)
            packages.take(20).forEach { pkg ->
                val isFrozen = pkg in frozen
                TextButton(onClick = {
                    scope.launch {
                        busy = true
                        try {
                            if (isFrozen) {
                                append(adb.shell("pm enable $pkg"))
                                saveFrozen(frozen - pkg)
                            } else {
                                append(adb.shell("pm disable-user --user 0 $pkg"))
                                saveFrozen(frozen + pkg)
                            }
                        } catch (e: Exception) { append("✖ ${e.message}") }
                        busy = false
                    }
                }) { Text("${if (isFrozen) "✔ " else ""}$pkg") }
            }
            if (packages.size > 20) Text("... и ещё ${packages.size - 20}")
        }

        Spacer(Modifier.height(12.dp))
        Text("Лог:", style = MaterialTheme.typography.titleSmall)
        Text(log, style = MaterialTheme.typography.bodySmall)
    }
}
