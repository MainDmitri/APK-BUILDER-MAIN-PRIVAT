package com.pultitool.remote.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Иконки, нарисованные вручную (в material-icons-core их нет). */
enum class Glyph { POWER, VOL_UP, VOL_DOWN, MUTE, PLAY, PAUSE, PLAY_PAUSE, STOP, REWIND, FORWARD, PREV, NEXT,
    HOME, BACK, MENU, KEYBOARD, INPUT, TV, WIFI, RADAR, SHIELD, TIMER, TOUCH, GRID, APPS, PLUS, MINUS, INFO, GUIDE,
    PULSE, SPEED, GLOBE, LINK, TROPHY, EYE, ROUTE, DOOR, CALC, MAP, DOWNLOAD, HAND, DASH, SEARCH, CODE }

@Composable
fun GlyphIcon(g: Glyph, modifier: Modifier = Modifier, tint: Color = Pal.text, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) { drawGlyph(g, tint) }
}

fun DrawScope.drawGlyph(g: Glyph, c: Color) {
    val w = size.width
    val h = size.height
    val sw = w * 0.09f
    val st = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * w, y * h)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(c, p(x1, y1), p(x2, y2), sw, StrokeCap.Round)
    fun tri(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
        val path = Path().apply { moveTo(x1 * w, y1 * h); lineTo(x2 * w, y2 * h); lineTo(x3 * w, y3 * h); close() }
        drawPath(path, c)
    }
    fun speaker() {
        val path = Path().apply {
            moveTo(0.12f * w, 0.38f * h); lineTo(0.3f * w, 0.38f * h); lineTo(0.52f * w, 0.18f * h)
            lineTo(0.52f * w, 0.82f * h); lineTo(0.3f * w, 0.62f * h); lineTo(0.12f * w, 0.62f * h); close()
        }
        drawPath(path, c)
    }
    when (g) {
        Glyph.POWER -> {
            drawArc(c, -60f, 300f, false, topLeft = p(0.16f, 0.2f), size = Size(w * 0.68f, h * 0.68f), style = st)
            line(0.5f, 0.1f, 0.5f, 0.48f)
        }
        Glyph.VOL_UP -> { speaker(); line(0.66f, 0.5f, 0.92f, 0.5f); line(0.79f, 0.37f, 0.79f, 0.63f) }
        Glyph.VOL_DOWN -> { speaker(); line(0.66f, 0.5f, 0.92f, 0.5f) }
        Glyph.MUTE -> { speaker(); line(0.66f, 0.38f, 0.9f, 0.62f); line(0.9f, 0.38f, 0.66f, 0.62f) }
        Glyph.PLAY -> tri(0.28f, 0.15f, 0.85f, 0.5f, 0.28f, 0.85f)
        Glyph.PAUSE -> { line(0.35f, 0.2f, 0.35f, 0.8f); line(0.65f, 0.2f, 0.65f, 0.8f) }
        Glyph.PLAY_PAUSE -> { tri(0.08f, 0.2f, 0.5f, 0.5f, 0.08f, 0.8f); line(0.68f, 0.25f, 0.68f, 0.75f); line(0.88f, 0.25f, 0.88f, 0.75f) }
        Glyph.STOP -> drawRoundRect(c, p(0.22f, 0.22f), Size(w * 0.56f, h * 0.56f), CornerRadius(w * 0.08f))
        Glyph.REWIND -> { tri(0.5f, 0.22f, 0.08f, 0.5f, 0.5f, 0.78f); tri(0.92f, 0.22f, 0.5f, 0.5f, 0.92f, 0.78f) }
        Glyph.FORWARD -> { tri(0.08f, 0.22f, 0.5f, 0.5f, 0.08f, 0.78f); tri(0.5f, 0.22f, 0.92f, 0.5f, 0.5f, 0.78f) }
        Glyph.PREV -> { line(0.2f, 0.22f, 0.2f, 0.78f); tri(0.82f, 0.2f, 0.3f, 0.5f, 0.82f, 0.8f) }
        Glyph.NEXT -> { line(0.8f, 0.22f, 0.8f, 0.78f); tri(0.18f, 0.2f, 0.7f, 0.5f, 0.18f, 0.8f) }
        Glyph.HOME -> {
            val path = Path().apply {
                moveTo(0.12f * w, 0.5f * h); lineTo(0.5f * w, 0.15f * h); lineTo(0.88f * w, 0.5f * h)
                moveTo(0.24f * w, 0.42f * h); lineTo(0.24f * w, 0.85f * h); lineTo(0.76f * w, 0.85f * h); lineTo(0.76f * w, 0.42f * h)
            }
            drawPath(path, c, style = st)
        }
        Glyph.BACK -> {
            val path = Path().apply {
                moveTo(0.38f * w, 0.18f * h); lineTo(0.14f * w, 0.4f * h); lineTo(0.38f * w, 0.62f * h)
                moveTo(0.14f * w, 0.4f * h); lineTo(0.62f * w, 0.4f * h)
                cubicTo(0.95f * w, 0.4f * h, 0.95f * w, 0.84f * h, 0.62f * w, 0.84f * h); lineTo(0.42f * w, 0.84f * h)
            }
            drawPath(path, c, style = st)
        }
        Glyph.MENU -> { line(0.18f, 0.28f, 0.82f, 0.28f); line(0.18f, 0.5f, 0.82f, 0.5f); line(0.18f, 0.72f, 0.82f, 0.72f) }
        Glyph.KEYBOARD -> {
            drawRoundRect(c, p(0.06f, 0.24f), Size(w * 0.88f, h * 0.54f), CornerRadius(w * 0.1f), style = st)
            for (r in 0..1) for (k in 0..3) drawCircle(c, w * 0.04f, p(0.24f + k * 0.17f, 0.4f + r * 0.13f))
            line(0.3f, 0.66f, 0.7f, 0.66f)
        }
        Glyph.INPUT -> {
            drawRoundRect(c, p(0.08f, 0.18f), Size(w * 0.84f, h * 0.56f), CornerRadius(w * 0.08f), style = st)
            line(0.3f, 0.46f, 0.66f, 0.46f); line(0.54f, 0.34f, 0.66f, 0.46f); line(0.54f, 0.58f, 0.66f, 0.46f)
            line(0.36f, 0.88f, 0.64f, 0.88f)
        }
        Glyph.TV -> {
            drawRoundRect(c, p(0.06f, 0.2f), Size(w * 0.88f, h * 0.56f), CornerRadius(w * 0.08f), style = st)
            line(0.34f, 0.9f, 0.66f, 0.9f); line(0.38f, 0.06f, 0.5f, 0.18f); line(0.62f, 0.06f, 0.5f, 0.18f)
        }
        Glyph.WIFI -> {
            for (i in 0..2) {
                val r = 0.16f + i * 0.17f
                drawArc(c, 225f, 90f, false, topLeft = p(0.5f - r, 0.78f - r), size = Size(w * r * 2, h * r * 2), style = st)
            }
            drawCircle(c, w * 0.06f, p(0.5f, 0.78f))
        }
        Glyph.RADAR -> {
            drawCircle(c, w * 0.4f, p(0.5f, 0.5f), style = st)
            drawCircle(c, w * 0.2f, p(0.5f, 0.5f), style = st)
            line(0.5f, 0.5f, 0.82f, 0.22f)
            drawCircle(c, w * 0.06f, p(0.5f, 0.5f))
        }
        Glyph.SHIELD -> {
            val path = Path().apply {
                moveTo(0.5f * w, 0.08f * h); lineTo(0.86f * w, 0.22f * h)
                cubicTo(0.86f * w, 0.62f * h, 0.7f * w, 0.82f * h, 0.5f * w, 0.93f * h)
                cubicTo(0.3f * w, 0.82f * h, 0.14f * w, 0.62f * h, 0.14f * w, 0.22f * h); close()
            }
            drawPath(path, c, style = st)
            line(0.34f, 0.5f, 0.46f, 0.62f); line(0.46f, 0.62f, 0.68f, 0.38f)
        }
        Glyph.TIMER -> {
            drawCircle(c, w * 0.36f, p(0.5f, 0.56f), style = st)
            line(0.5f, 0.56f, 0.5f, 0.36f); line(0.5f, 0.56f, 0.64f, 0.64f); line(0.4f, 0.08f, 0.6f, 0.08f)
        }
        Glyph.TOUCH -> {
            drawRoundRect(c, p(0.1f, 0.1f), Size(w * 0.8f, h * 0.8f), CornerRadius(w * 0.14f), style = st)
            drawCircle(c, w * 0.1f, p(0.5f, 0.5f))
        }
        Glyph.GRID -> {
            for (r in 0..2) for (k in 0..2) drawCircle(c, w * 0.07f, p(0.22f + k * 0.28f, 0.22f + r * 0.28f))
        }
        Glyph.APPS -> {
            for (r in 0..1) for (k in 0..1) drawRoundRect(c, p(0.12f + k * 0.42f, 0.12f + r * 0.42f), Size(w * 0.32f, h * 0.32f), CornerRadius(w * 0.08f))
        }
        Glyph.PLUS -> { line(0.5f, 0.2f, 0.5f, 0.8f); line(0.2f, 0.5f, 0.8f, 0.5f) }
        Glyph.MINUS -> line(0.2f, 0.5f, 0.8f, 0.5f)
        Glyph.INFO -> {
            drawCircle(c, w * 0.4f, p(0.5f, 0.5f), style = st)
            line(0.5f, 0.45f, 0.5f, 0.72f); drawCircle(c, w * 0.055f, p(0.5f, 0.3f))
        }
        Glyph.GUIDE -> {
            drawRoundRect(c, p(0.1f, 0.16f), Size(w * 0.8f, h * 0.68f), CornerRadius(w * 0.08f), style = st)
            line(0.1f, 0.4f, 0.9f, 0.4f); line(0.36f, 0.4f, 0.36f, 0.84f)
        }
        Glyph.PULSE -> {
            val path = Path().apply {
                moveTo(0.05f * w, 0.55f * h); lineTo(0.28f * w, 0.55f * h); lineTo(0.38f * w, 0.25f * h)
                lineTo(0.52f * w, 0.82f * h); lineTo(0.64f * w, 0.45f * h); lineTo(0.72f * w, 0.55f * h); lineTo(0.95f * w, 0.55f * h)
            }
            drawPath(path, c, style = st)
        }
        Glyph.SPEED -> {
            drawArc(c, 150f, 240f, false, topLeft = p(0.1f, 0.14f), size = Size(w * 0.8f, h * 0.8f), style = st)
            line(0.5f, 0.54f, 0.72f, 0.3f); drawCircle(c, w * 0.07f, p(0.5f, 0.54f))
        }
        Glyph.GLOBE -> {
            drawCircle(c, w * 0.4f, p(0.5f, 0.5f), style = st)
            drawOval(c, p(0.32f, 0.1f), Size(w * 0.36f, h * 0.8f), style = st)
            line(0.1f, 0.5f, 0.9f, 0.5f)
        }
        Glyph.LINK -> {
            drawRoundRect(c, p(0.08f, 0.36f), Size(w * 0.46f, h * 0.28f), CornerRadius(w * 0.14f), style = st)
            drawRoundRect(c, p(0.46f, 0.36f), Size(w * 0.46f, h * 0.28f), CornerRadius(w * 0.14f), style = st)
        }
        Glyph.TROPHY -> {
            val path = Path().apply {
                moveTo(0.28f * w, 0.14f * h); lineTo(0.72f * w, 0.14f * h); lineTo(0.72f * w, 0.36f * h)
                cubicTo(0.72f * w, 0.6f * h, 0.28f * w, 0.6f * h, 0.28f * w, 0.36f * h); close()
            }
            drawPath(path, c, style = st)
            drawArc(c, 90f, 180f, false, topLeft = p(0.1f, 0.18f), size = Size(w * 0.2f, h * 0.22f), style = st)
            drawArc(c, -90f, 180f, false, topLeft = p(0.7f, 0.18f), size = Size(w * 0.2f, h * 0.22f), style = st)
            line(0.5f, 0.58f, 0.5f, 0.78f); line(0.32f, 0.86f, 0.68f, 0.86f)
        }
        Glyph.EYE -> {
            val path = Path().apply {
                moveTo(0.06f * w, 0.5f * h); quadraticTo(0.5f * w, 0.05f * h, 0.94f * w, 0.5f * h)
                quadraticTo(0.5f * w, 0.95f * h, 0.06f * w, 0.5f * h); close()
            }
            drawPath(path, c, style = st)
            drawCircle(c, w * 0.12f, p(0.5f, 0.5f))
        }
        Glyph.ROUTE -> {
            drawCircle(c, w * 0.1f, p(0.2f, 0.8f), style = st); drawCircle(c, w * 0.1f, p(0.8f, 0.2f), style = st)
            val path = Path().apply {
                moveTo(0.3f * w, 0.8f * h); lineTo(0.62f * w, 0.8f * h)
                cubicTo(0.9f * w, 0.8f * h, 0.9f * w, 0.5f * h, 0.62f * w, 0.5f * h); lineTo(0.38f * w, 0.5f * h)
                cubicTo(0.1f * w, 0.5f * h, 0.1f * w, 0.2f * h, 0.38f * w, 0.2f * h); lineTo(0.7f * w, 0.2f * h)
            }
            drawPath(path, c, style = st)
        }
        Glyph.DOOR -> {
            drawRoundRect(c, p(0.22f, 0.08f), Size(w * 0.56f, h * 0.84f), CornerRadius(w * 0.05f), style = st)
            drawCircle(c, w * 0.06f, p(0.64f, 0.52f))
        }
        Glyph.CALC -> {
            drawRoundRect(c, p(0.16f, 0.06f), Size(w * 0.68f, h * 0.88f), CornerRadius(w * 0.1f), style = st)
            line(0.3f, 0.26f, 0.7f, 0.26f)
            for (r in 0..1) for (k in 0..2) drawCircle(c, w * 0.05f, p(0.32f + k * 0.18f, 0.52f + r * 0.2f))
        }
        Glyph.MAP -> {
            drawCircle(c, w * 0.1f, p(0.5f, 0.5f))
            listOf(0.15f to 0.2f, 0.85f to 0.25f, 0.2f to 0.82f, 0.82f to 0.8f).forEach { (x, y) ->
                line(0.5f, 0.5f, x, y); drawCircle(c, w * 0.08f, p(x, y))
            }
        }
        Glyph.DOWNLOAD -> {
            line(0.5f, 0.1f, 0.5f, 0.62f); line(0.28f, 0.42f, 0.5f, 0.64f); line(0.72f, 0.42f, 0.5f, 0.64f)
            line(0.14f, 0.88f, 0.86f, 0.88f)
        }
        Glyph.HAND -> {
            drawRoundRect(c, p(0.24f, 0.42f), Size(w * 0.56f, h * 0.48f), CornerRadius(w * 0.2f), style = st)
            line(0.36f, 0.42f, 0.36f, 0.18f); line(0.5f, 0.42f, 0.5f, 0.1f); line(0.64f, 0.42f, 0.64f, 0.18f)
            line(0.24f, 0.62f, 0.1f, 0.46f)
        }
        Glyph.DASH -> {
            drawRoundRect(c, p(0.1f, 0.1f), Size(w * 0.36f, h * 0.46f), CornerRadius(w * 0.08f), style = st)
            drawRoundRect(c, p(0.54f, 0.1f), Size(w * 0.36f, h * 0.26f), CornerRadius(w * 0.08f), style = st)
            drawRoundRect(c, p(0.1f, 0.64f), Size(w * 0.36f, h * 0.26f), CornerRadius(w * 0.08f), style = st)
            drawRoundRect(c, p(0.54f, 0.44f), Size(w * 0.36f, h * 0.46f), CornerRadius(w * 0.08f), style = st)
        }
        Glyph.SEARCH -> { drawCircle(c, w * 0.26f, p(0.42f, 0.42f), style = st); line(0.62f, 0.62f, 0.88f, 0.88f) }
        Glyph.CODE -> {
            line(0.32f, 0.26f, 0.1f, 0.5f); line(0.1f, 0.5f, 0.32f, 0.74f)
            line(0.68f, 0.26f, 0.9f, 0.5f); line(0.9f, 0.5f, 0.68f, 0.74f); line(0.56f, 0.18f, 0.44f, 0.82f)
        }
    }
}

fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), strong: Boolean = false): Modifier = this
    .clip(shape)
    .background(if (strong) Pal.glassStrong else Pal.glass, shape)
    .border(1.dp, Brush.verticalGradient(listOf(Color(0x52FFFFFF), Color(0x12FFFFFF))), shape)

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val accent = LocalAccent.current
    val amoled = LocalAmoled.current
    Box(
        Modifier
            .fillMaxSize()
            .background(if (amoled) Brush.verticalGradient(listOf(Color.Black, Color(0xFF05070B))) else Brush.verticalGradient(listOf(Pal.bgTop, Pal.bgBottom)))
    ) {
        if (!amoled) Canvas(Modifier.fillMaxSize()) {
            drawCircle(Brush.radialGradient(listOf(accent.a.copy(alpha = 0.20f), Color.Transparent),
                center = Offset(size.width * 0.1f, size.height * 0.08f), radius = size.width * 0.8f),
                radius = size.width * 0.8f, center = Offset(size.width * 0.1f, size.height * 0.08f))
            drawCircle(Brush.radialGradient(listOf(accent.b.copy(alpha = 0.15f), Color.Transparent),
                center = Offset(size.width * 0.95f, size.height * 0.75f), radius = size.width * 0.9f),
                radius = size.width * 0.9f, center = Offset(size.width * 0.95f, size.height * 0.75f))
        }
        content()
    }
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, padding: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.glass(RoundedCornerShape(22.dp)).padding(padding), verticalArrangement = Arrangement.spacedBy(3.dp), content = content)
}

/** Кнопка пульта с анимацией нажатия и поддержкой долгого нажатия. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PadButton(
    modifier: Modifier = Modifier,
    size: Dp = 60.dp,
    shape: Shape = CircleShape,
    background: Brush? = null,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.45f, stiffness = 600f), label = "press")
    val base = if (background != null) Modifier.clip(shape).background(background, shape) else Modifier.glass(shape, strong = pressed)
    Box(
        modifier
            .size(size)
            .scale(scale)
            .then(base)
            .combinedClickable(
                interactionSource = src,
                indication = null,
                enabled = enabled,
                onClick = onClick,
                onLongClick = onLongClick
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

@Composable
fun GlyphButton(g: Glyph, size: Dp = 60.dp, tint: Color = Pal.text, background: Brush? = null, label: String? = null,
                onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PadButton(size = size, background = background, onLongClick = onLongClick, onClick = onClick) {
            GlyphIcon(g, tint = tint, size = size * 0.42f)
        }
        if (label != null) {
            Spacer(Modifier.height(4.dp))
            Text(label, color = Pal.textDim, fontSize = 11.sp)
        }
    }
}

@Composable
fun TextKey(text: String, modifier: Modifier = Modifier, size: Dp = 64.dp, fontSize: Int = 22,
            shape: Shape = CircleShape, background: Brush? = null, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    PadButton(modifier = modifier, size = size, shape = shape, background = background, onLongClick = onLongClick, onClick = onClick) {
        Text(text, color = Pal.text, fontSize = fontSize.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, glyph: Glyph? = null, enabled: Boolean = true, onClick: () -> Unit) {
    val accent = LocalAccent.current
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, label = "gb")
    Row(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(18.dp))
            .background(if (enabled) accent.brush else Brush.linearGradient(listOf(Color(0xFF3A3556), Color(0xFF2E2A45))))
            .combinedClickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (glyph != null) { GlyphIcon(glyph, tint = Color.White, size = 20.dp); Spacer(Modifier.width(10.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    Box(
        modifier
            .glass(RoundedCornerShape(18.dp))
            .combinedClickable(interactionSource = src, indication = null, onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier = modifier.padding(start = 4.dp, top = 10.dp, bottom = 8.dp),
        color = Pal.textDim, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
}

@Composable
fun Chip(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier
        .clip(RoundedCornerShape(50))
        .background(color.copy(alpha = 0.18f))
        .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
        .padding(horizontal = 10.dp, vertical = 4.dp),
        color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
fun StatusDot(color: Color, size: Dp = 10.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(color))
}

@Composable
fun Header(title: String, subtitle: String? = null, leading: (@Composable () -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (leading != null) { leading(); Spacer(Modifier.width(10.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.text, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.4).sp, maxLines = 1)
            if (subtitle != null) Text(subtitle, color = Pal.textDim, fontSize = 13.sp, maxLines = 1)
        }
        trailing()
    }
}
