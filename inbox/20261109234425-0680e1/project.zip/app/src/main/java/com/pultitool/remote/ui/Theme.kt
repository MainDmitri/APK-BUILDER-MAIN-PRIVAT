package com.pultitool.remote.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

data class Accent(val name: String, val a: Color, val b: Color) {
    val brush: Brush get() = Brush.linearGradient(listOf(a, b))
}

val Accents = listOf(
    Accent("Неон", Color(0xFF7C4DFF), Color(0xFF00E5FF)),
    Accent("Закат", Color(0xFFFF4081), Color(0xFFFF9100)),
    Accent("Аврора", Color(0xFF00E676), Color(0xFF00B0FF)),
    Accent("Янтарь", Color(0xFFFFC400), Color(0xFFFF6E40)),
    Accent("Океан", Color(0xFF2979FF), Color(0xFF651FFF)),
    Accent("Рубин", Color(0xFFFF1744), Color(0xFFD500F9))
)

val LocalAccent = staticCompositionLocalOf { Accents[0] }

/** Чёрная AMOLED-тема: чистый чёрный фон без свечений. */
val LocalAmoled = staticCompositionLocalOf { false }

object Pal {
    val bgTop = Color(0xFF080D18)
    val bgBottom = Color(0xFF101B2B)
    val glass = Color(0x16FFFFFF)
    val glassStrong = Color(0x25FFFFFF)
    val stroke = Color(0x30FFFFFF)
    val text = Color(0xFFF4F7FF)
    val textDim = Color(0xFFAAB7CC)
    val red = Color(0xFFFF3B5C)
    val green = Color(0xFF2EE59D)
    val yellow = Color(0xFFFFC542)
}

@Composable
fun PultTheme(accent: Accent, amoled: Boolean = false, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent.a,
        secondary = accent.b,
        background = if (amoled) Color.Black else Pal.bgTop,
        surface = if (amoled) Color(0xFF0E0E0E) else Color(0xFF1A1633),
        surfaceVariant = Color(0xFF1B2A40),
        onPrimary = Color.White,
        onSurface = Pal.text,
        onBackground = Pal.text,
        onSurfaceVariant = Pal.textDim,
        error = Pal.red
    )
    androidx.compose.runtime.CompositionLocalProvider(LocalAccent provides accent, LocalAmoled provides amoled) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
