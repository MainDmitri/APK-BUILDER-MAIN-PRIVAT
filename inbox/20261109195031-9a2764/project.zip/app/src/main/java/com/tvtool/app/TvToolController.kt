package com.tvtool.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ConnectionStatus {
    Disconnected, Connecting, Connected
}

class TvToolController(private val context: Context) {
    val adb = Adb(context)
    private val prefs = context.getSharedPreferences("tvtool", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var worker: Job? = null

    val launcherComponent = "com.tvtool.app/.HomeActivity"
    private val adguardDns = "dns.adguard-dns.com"

    var ip by mutableStateOf(prefs.getString("ip", "").orEmpty())
    var url by mutableStateOf(
        "https://github.com/yuliskov/SmartTube/releases/latest/download/smarttube_stable.apk"
    )
    var repo by mutableStateOf(prefs.getString("repo", "yuliskov/SmartTube").orEmpty())
    var status by mutableStateOf(ConnectionStatus.Disconnected)
        private set
    var deviceInfo by mutableStateOf("")
        private set
    var scanProgress by mutableFloatStateOf(0f)
        private set
    var downloadProgress by mutableFloatStateOf(-1f)
        private set
    var busy by mutableStateOf(false)
        private set
    var busyLabel by mutableStateOf("")
        private set

    val logs = mutableStateListOf<String>()

    var packagePickerTitle by mutableStateOf<String?>(null)
        private set
    var packagePickerItems by mutableStateOf<List<String>>(emptyList())
        private set
    private var packagePickerAction: ((List<String>) -> Unit)? = null

    var githubApks by mutableStateOf<List<Pair<String, String>>>(emptyList())
        private set
    var showGithubPicker by mutableStateOf(false)

    var screenshotBitmap by mutableStateOf<Bitmap?>(null)
    var textInputVisible by mutableStateOf(false)
    var textInputValue by mutableStateOf("")

    fun log(msg: String) {
        logs.add(0, "• $msg")
        if (logs.size > 400) {
            logs.removeRange(400, logs.size)
        }
    }

    fun clearLogs() {
        logs.clear()
    }

    fun dismissPackagePicker() {
        packagePickerTitle = null
        packagePickerItems = emptyList()
        packagePickerAction = null
    }

    fun confirmPackagePicker(selected: List<String>) {
        val action = packagePickerAction
        dismissPackagePicker()
        action?.invoke(selected)
    }

    fun dismissGithubPicker() {
        showGithubPicker = false
        githubApks = emptyList()
    }

    fun onCleared() {
        worker?.cancel()
        scope.cancel()
        adb.close()
    }

    private fun runTask(label: String = "", block: suspend () -> Unit) {
        worker?.cancel()
        worker = scope.launch {
            busy = true
            busyLabel = label
            try {
                if (label.isNotEmpty()) log("▶ $label")
                withContext(Dispatchers.IO) { block() }
            } catch (e: Throwable) {
                if (isActive) {
                    log("✖ ${e.message ?: e.javaClass.simpleName}")
                    adb.close()
                    status = ConnectionStatus.Disconnected
                    deviceInfo = ""
                }
            } finally {
                busy = false
                busyLabel = ""
                downloadProgress = -1f
            }
        }
    }

    private suspend fun ensureConnected() {
        val host = ip.trim()
        if (host.isBlank()) throw IllegalStateException("Укажите IP телевизора")
        prefs.edit().putString("ip", host).apply()
        if (adb.host != host || status != ConnectionStatus.Connected) {
            status = ConnectionStatus.Connecting
            adb.close()
            adb.host = host
            adb.connect()
            status = ConnectionStatus.Connected
        }
    }

    fun scanNetwork() = runTask("Сканирование сети") {
        scanProgress = 0f
        log("Сканирую подсеть на порт 5555…")
        val found = Adb.scan { p ->
            scanProgress = p / 100f
            if (p % 20 == 0) {
                scope.launch { log("Прогресс: $p%") }
            }
        }
        scanProgress = 1f
        if (found.isEmpty()) {
            log("Устройства не найдены")
        } else {
            log("Найдено: ${found.joinToString()}")
            withContext(Dispatchers.Main) {
                ip = found.first()
            }
        }
    }

    fun connectAndInfo() = runTask("Подключение") {
        ensureConnected()
        val model = adb.shell("getprop ro.product.model")
        val android = adb.shell("getprop ro.build.version.release")
        val size = adb.shell("wm size")
        val disk = adb.shell("df -h /data | tail -1")
        val info = buildString {
            appendLine("Модель: $model")
            appendLine("Android: $android")
            appendLine("Экран: $size")
            append("Диск: $disk")
        }
        withContext(Dispatchers.Main) {
            deviceInfo = info
        }
        log("Модель: $model")
        log("Android: $android")
        log("Экран: $size")
        log("Диск: $disk")
        log("✔ Подключено к ${adb.host}")
    }

    fun disconnect() {
        adb.close()
        status = ConnectionStatus.Disconnected
        deviceInfo = ""
        log("Отключено")
    }

    fun downloadAndInstall(targetUrl: String = url, install: Boolean) = runTask(
        if (install) "Скачать и установить" else "Скачивание"
    ) {
        val u = targetUrl.trim()
        if (u.isBlank()) throw IllegalStateException("URL пустой")
        if (install) ensureConnected()
        val name = u.substringAfterLast('/').substringBefore('?').ifBlank { "app.apk" }
        val file = File(context.getExternalFilesDir("apk"), name)
        downloadProgress = 0f
        log("Скачиваю $name…")
        Adb.download(u, file) { p ->
            downloadProgress = p / 100f
            if (p % 20 == 0) scope.launch { log("  $p%") }
        }
        log("SHA-256: ${Adb.sha256(file)}")
        log("Сохранено: ${file.absolutePath}")
        if (install) {
            adb.install(file)
            log("✔ Установлено")
        }
    }

    fun loadGithubApks(repoName: String = repo) = runTask("GitHub $repoName") {
        val r = repoName.trim()
        if (r.isBlank() || !r.contains('/')) {
            throw IllegalStateException("Укажите owner/repo")
        }
        prefs.edit().putString("repo", r).apply()
        withContext(Dispatchers.Main) { repo = r }
        val apks = Adb.releaseApks(r)
        if (apks.isEmpty()) {
            log("APK в релизе не найдены")
        } else {
            log("Найдено APK: ${apks.size}")
            withContext(Dispatchers.Main) {
                githubApks = apks
                showGithubPicker = true
            }
        }
    }

    fun installGithubApk(pair: Pair<String, String>) {
        dismissGithubPicker()
        url = pair.second
        downloadAndInstall(pair.second, install = true)
    }

    fun installPickedApk(uri: Uri) = runTask("Установка с телефона") {
        ensureConnected()
        val dest = File(context.cacheDir, "picked.apk")
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { input.copyTo(it) }
        } ?: throw IllegalStateException("Не удалось прочитать файл")
        adb.install(dest)
        log("✔ Установлено с телефона")
    }

    fun installLauncher() = runTask("Установка лаунчера") {
        ensureConnected()
        adb.install(File(context.applicationInfo.sourceDir))
        log(adb.shell("cmd package set-home-activity $launcherComponent"))
        adb.shell("input keyevent 3")
        log("✔ Лаунчер установлен и активирован")
    }

    fun openPackagePicker(title: String, cmd: String, onSelected: (List<String>) -> Unit) =
        runTask(title) {
            ensureConnected()
            val packages = adb.shell(cmd).lines()
                .map { it.removePrefix("package:").trim() }
                .filter { it.isNotBlank() }
                .sorted()
            if (packages.isEmpty()) {
                log("Список пуст")
                return@runTask
            }
            withContext(Dispatchers.Main) {
                packagePickerTitle = title
                packagePickerItems = packages
                packagePickerAction = onSelected
            }
        }

    fun freezePackages(pkgs: List<String>) = runTask("Заморозка") {
        ensureConnected()
        val frozen = getFrozenSet()
        pkgs.forEach { pkg ->
            val res = adb.shell("pm disable-user --user 0 $pkg")
            log("$pkg: $res")
            frozen.add(pkg)
        }
        saveFrozen(frozen)
        log("✔ Заморожено: ${pkgs.size}")
    }

    fun unfreezeAll() = runTask("Разморозка") {
        ensureConnected()
        val frozen = getFrozenSet()
        frozen.toList().forEach { pkg ->
            val res = adb.shell("pm enable $pkg")
            log("$pkg: $res")
            if (res.contains("enabled", true)) frozen.remove(pkg)
        }
        saveFrozen(frozen)
        log(if (frozen.isEmpty()) "✔ Все включены" else "Осталось: ${frozen.size}")
    }

    fun launchPackages(pkgs: List<String>) = runTask("Запуск") {
        ensureConnected()
        pkgs.forEach {
            adb.shell("monkey -p $it -c android.intent.category.LAUNCHER 1")
            log("Запуск: $it")
        }
    }

    fun uninstallPackages(pkgs: List<String>) = runTask("Удаление") {
        ensureConnected()
        pkgs.forEach {
            log("$it: ${adb.shell("pm uninstall --user 0 $it")}")
        }
    }

    fun takePackageSnapshot() = runTask("Снимок пакетов") {
        ensureConnected()
        prefs.edit().putString("snapshot", takeSnapshot()).apply()
        log("✔ Снимок сохранён")
    }

    fun comparePackageSnapshot() = runTask("Сравнение") {
        ensureConnected()
        val old = prefs.getString("snapshot", null)
            ?: throw IllegalStateException("Сначала сделайте снимок")
        fun parse(s: String) = s.lines().filter { "|" in it }
            .associate { it.substringBefore('|') to it.substringAfter('|') }
        val oldMap = parse(old)
        val newMap = parse(takeSnapshot())
        (newMap.keys - oldMap.keys).forEach { log("+ появилось: $it") }
        (oldMap.keys - newMap.keys).forEach { log("- удалено: $it") }
        newMap.filter { (k, v) -> oldMap[k] != null && oldMap[k] != v }.forEach { (k, v) ->
            log("⟳ $k: ${if (v == "d") "выключено" else "включено"}")
        }
        log("Сравнение завершено")
    }

    fun runMonitor() = runTask("Монитор") {
        ensureConnected()
        repeat(3) { i ->
            val mem = adb.shell("grep -E 'MemTotal|MemAvailable' /proc/meminfo")
                .replace(Regex("\\s+"), " ")
            val temp = adb.shell("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null")
                .toIntOrNull()?.div(1000)
            val load = adb.shell("cat /proc/loadavg").substringBefore(" ")
            log("[$i] $mem | load $load | ${temp ?: "?"}°C")
            delay(1500)
        }
    }

    fun enableAdguardDns() = runTask("AdGuard DNS") {
        ensureConnected()
        if (!prefs.contains("dns_mode")) {
            prefs.edit()
                .putString("dns_mode", adb.shell("settings get global private_dns_mode"))
                .putString("dns_spec", adb.shell("settings get global private_dns_specifier"))
                .apply()
        }
        adb.shell("settings put global private_dns_specifier $adguardDns")
        adb.shell("settings put global private_dns_mode hostname")
        delay(2500)
        val ping = adb.shell("ping -c 1 -W 2 example.com")
        if (ping.contains("1 received") || ping.contains("1 packets received")) {
            log("✔ DNS $adguardDns активен")
        } else {
            log("✖ Проблема с интернетом — откат")
            restoreDnsInternal()
        }
    }

    fun disableAdguardDns() = runTask("Откат DNS") {
        ensureConnected()
        restoreDnsInternal()
    }

    private fun restoreDnsInternal() {
        val mode = prefs.getString("dns_mode", "opportunistic") ?: "opportunistic"
        val spec = prefs.getString("dns_spec", "") ?: ""
        if (spec.isNotBlank() && spec != "null") {
            adb.shell("settings put global private_dns_specifier $spec")
        }
        adb.shell("settings put global private_dns_mode $mode")
        prefs.edit().remove("dns_mode").remove("dns_spec").apply()
        log("✔ DNS восстановлен: $mode")
    }

    fun rebootTv() = runTask("Перезагрузка") {
        ensureConnected()
        adb.shell("reboot")
        log("Команда reboot отправлена")
        withContext(Dispatchers.Main) {
            status = ConnectionStatus.Disconnected
            deviceInfo = ""
        }
        adb.close()
    }

    fun shareReport() = runTask("Отчёт") {
        ensureConnected()
        val text = generateReport()
        withContext(Dispatchers.Main) {
            shareText(text)
        }
        log("Отчёт готов")
    }

    fun sendKey(keyCode: Int) = runTask("") {
        ensureConnected()
        adb.shell("input keyevent $keyCode")
    }

    fun sendText(text: String) = runTask("Ввод текста") {
        ensureConnected()
        val escaped = text.replace(" ", "%s").replace("'", "")
        adb.shell("input text '$escaped'")
        log("Текст отправлен")
    }

    fun takeScreenshot() = runTask("Скриншот") {
        ensureConnected()
        adb.shell("screencap -p /sdcard/tvtool.png")
        val file = File(context.getExternalFilesDir("shots"), "screen_${System.currentTimeMillis()}.png")
        file.parentFile?.mkdirs()
        adb.pull(file, "/sdcard/tvtool.png")
        val bmp = BitmapFactory.decodeFile(file.path)
        withContext(Dispatchers.Main) {
            screenshotBitmap = bmp
        }
        log("Скриншот: ${file.name}")
    }

    fun shareLogcat() = runTask("Logcat") {
        ensureConnected()
        val text = adb.shell("logcat -d -t 300").takeLast(50000)
        withContext(Dispatchers.Main) {
            shareText(text)
        }
        log("Logcat отправлен")
    }

    private fun takeSnapshot(): String {
        val disabled = adb.shell("pm list packages -d").lines().toSet()
        return adb.shell("pm list packages").lines()
            .filter { it.startsWith("package:") }
            .joinToString("\n") { pkg ->
                val name = pkg.removePrefix("package:")
                "$name|${if (pkg in disabled) "d" else "e"}"
            }
    }

    private fun generateReport(): String = buildString {
        appendLine("TvTool отчёт")
        appendLine(
            adb.shell("getprop ro.product.model") +
                " / Android " +
                adb.shell("getprop ro.build.version.release")
        )
        appendLine(
            "Пользовательских приложений: " +
                adb.shell("pm list packages -3").lines().count { it.isNotBlank() }
        )
        appendLine("Заморожено: " + getFrozenSet().joinToString())
        appendLine(
            "DNS: " +
                adb.shell("settings get global private_dns_mode") + " " +
                adb.shell("settings get global private_dns_specifier")
        )
        append(adb.shell("grep MemAvailable /proc/meminfo"))
    }

    private fun getFrozenSet(): MutableSet<String> =
        prefs.getStringSet("frozen", emptySet())!!.toMutableSet()

    private fun saveFrozen(set: Set<String>) {
        prefs.edit().putStringSet("frozen", set).apply()
    }

    fun shareText(text: String) {
        val intent = Intent(Intent.ACTION_SEND)
            .setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, text)
        context.startActivity(Intent.createChooser(intent, "Поделиться").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
