package com.tvtool.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.ActionButton
import com.tvtool.app.ui.components.ProgressBlock
import com.tvtool.app.ui.components.SectionCard
import com.tvtool.app.ui.components.SpacerH

@Composable
fun InstallScreen(controller: TvToolController) {
    var showRepoDialog by remember { mutableStateOf(false) }
    var repoDraft by remember { mutableStateOf(controller.repo) }

    val pickApk = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) controller.installPickedApk(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Скачать и установить") {
            OutlinedTextField(
                value = controller.url,
                onValueChange = { controller.url = it },
                label = { Text("URL APK") },
                singleLine = false,
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
            )
            SpacerH(8)
            if (controller.downloadProgress >= 0f) {
                ProgressBlock("Загрузка", controller.downloadProgress)
                SpacerH(8)
            }
            ActionButton(
                text = "Скачать и установить на ТВ",
                onClick = { controller.downloadAndInstall(install = true) },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Только скачать на телефон",
                onClick = { controller.downloadAndInstall(install = false) },
                enabled = !controller.busy,
            )
        }

        SectionCard("Источники") {
            ActionButton(
                text = "GitHub релиз (owner/repo)",
                onClick = {
                    repoDraft = controller.repo
                    showRepoDialog = true
                },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Установить APK с телефона",
                onClick = { pickApk.launch(arrayOf("application/vnd.android.package-archive", "*/*")) },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Установить этот лаунчер на ТВ",
                onClick = { controller.installLauncher() },
                enabled = !controller.busy,
            )
        }
        SpacerH(8)
    }

    if (showRepoDialog) {
        AlertDialog(
            onDismissRequest = { showRepoDialog = false },
            title = { Text("GitHub репозиторий") },
            text = {
                OutlinedTextField(
                    value = repoDraft,
                    onValueChange = { repoDraft = it },
                    label = { Text("owner/repo") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showRepoDialog = false
                    controller.repo = repoDraft.trim()
                    controller.loadGithubApks(repoDraft.trim())
                }) { Text("Загрузить") }
            },
            dismissButton = {
                TextButton(onClick = { showRepoDialog = false }) { Text("Отмена") }
            },
        )
    }

    if (controller.showGithubPicker) {
        AlertDialog(
            onDismissRequest = { controller.dismissGithubPicker() },
            title = { Text("Выберите APK") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    controller.githubApks.forEach { pair ->
                        TextButton(
                            onClick = { controller.installGithubApk(pair) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(pair.first)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { controller.dismissGithubPicker() }) { Text("Закрыть") }
            },
        )
    }
}
