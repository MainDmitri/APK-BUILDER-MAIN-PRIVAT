package com.tvtool.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.ActionButton
import com.tvtool.app.ui.components.SectionCard
import com.tvtool.app.ui.components.SpacerH

@Composable
fun RemoteScreen(controller: TvToolController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Пульт") {
            Dpad(
                enabled = !controller.busy,
                onKey = { controller.sendKey(it) },
            )
            SpacerH(12)
            ActionButton(
                text = "Ввести текст на ТВ",
                onClick = {
                    controller.textInputValue = ""
                    controller.textInputVisible = true
                },
                enabled = !controller.busy,
            )
        }

        SectionCard("Экран и логи") {
            ActionButton(
                text = "Скриншот ТВ",
                onClick = { controller.takeScreenshot() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Logcat (поделиться)",
                onClick = { controller.shareLogcat() },
                enabled = !controller.busy,
            )
        }
        SpacerH(8)
    }

    if (controller.textInputVisible) {
        AlertDialog(
            onDismissRequest = { controller.textInputVisible = false },
            title = { Text("Текст для ТВ") },
            text = {
                OutlinedTextField(
                    value = controller.textInputValue,
                    onValueChange = { controller.textInputValue = it },
                    label = { Text("Текст") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = controller.textInputValue
                    controller.textInputVisible = false
                    if (t.isNotBlank()) controller.sendText(t)
                }) { Text("Отправить") }
            },
            dismissButton = {
                TextButton(onClick = { controller.textInputVisible = false }) { Text("Отмена") }
            },
        )
    }

    controller.screenshotBitmap?.let { bmp ->
        AlertDialog(
            onDismissRequest = { controller.screenshotBitmap = null },
            title = { Text("Скриншот") },
            text = {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Скриншот ТВ",
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    contentScale = ContentScale.Fit,
                )
            },
            confirmButton = {
                TextButton(onClick = { controller.screenshotBitmap = null }) { Text("OK") }
            },
        )
    }
}

@Composable
private fun Dpad(enabled: Boolean, onKey: (Int) -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            DpadKey("▲", enabled, Modifier) { onKey(19) }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            modifier = Modifier.fillMaxWidth(),
        ) {
            DpadKey("◀", enabled, Modifier) { onKey(21) }
            DpadKey("OK", enabled, Modifier) { onKey(23) }
            DpadKey("▶", enabled, Modifier) { onKey(22) }
        }
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            DpadKey("▼", enabled, Modifier) { onKey(20) }
        }
        SpacerH(4)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilledTonalButton(
                onClick = { onKey(3) },
                enabled = enabled,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
            ) { Text("Home") }
            FilledTonalButton(
                onClick = { onKey(4) },
                enabled = enabled,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(14.dp),
            ) { Text("Back") }
        }
    }
}

@Composable
private fun DpadKey(
    label: String,
    enabled: Boolean,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.size(72.dp),
        shape = RoundedCornerShape(16.dp),
    ) {
        Text(label, style = MaterialTheme.typography.titleLarge)
    }
}
