package com.tvtool.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.ActionButton
import com.tvtool.app.ui.components.SectionCard
import com.tvtool.app.ui.components.SpacerH

@Composable
fun SystemScreen(controller: TvToolController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Пакеты") {
            ActionButton(
                text = "Сделать снимок пакетов",
                onClick = { controller.takePackageSnapshot() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Сравнить с снимком",
                onClick = { controller.comparePackageSnapshot() },
                enabled = !controller.busy,
            )
        }

        SectionCard("Мониторинг") {
            ActionButton(
                text = "Монитор (память / load / °C)",
                onClick = { controller.runMonitor() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Отчёт (поделиться)",
                onClick = { controller.shareReport() },
                enabled = !controller.busy,
            )
        }

        SectionCard("DNS и питание") {
            Text(
                "AdGuard Private DNS с автооткатом при недоступности сети.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SpacerH(8)
            ActionButton(
                text = "Включить AdGuard DNS",
                onClick = { controller.enableAdguardDns() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Вернуть DNS",
                onClick = { controller.disableAdguardDns() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Перезагрузка ТВ",
                onClick = { controller.rebootTv() },
                enabled = !controller.busy,
            )
        }
        SpacerH(8)
    }
}
