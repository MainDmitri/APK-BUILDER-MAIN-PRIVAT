package com.tvtool.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.tvtool.app.ConnectionStatus
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.LogPanel
import com.tvtool.app.ui.components.PackagePickerSheet
import com.tvtool.app.ui.screens.AppsScreen
import com.tvtool.app.ui.screens.ConnectionScreen
import com.tvtool.app.ui.screens.InstallScreen
import com.tvtool.app.ui.screens.RemoteScreen
import com.tvtool.app.ui.screens.SystemScreen

private data class Tab(val title: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(controller: TvToolController) {
    val tabs = listOf(
        Tab("Сеть", Icons.Filled.Phone),
        Tab("Устан.", Icons.Filled.PlayArrow),
        Tab("Прил.", Icons.Filled.Menu),
        Tab("Сист.", Icons.Filled.Settings),
        Tab("Пульт", Icons.Filled.Home),
    )
    var selected by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TvTool", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Управление Android TV",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    ConnectionChip(controller.status, controller.ip)
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
        bottomBar = {
            Column {
                LogPanel(
                    logs = controller.logs,
                    onClear = { controller.clearLogs() },
                )
                NavigationBar {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, maxLines = 1) },
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
        ) {
            if (controller.busy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                if (controller.busyLabel.isNotBlank()) {
                    Text(
                        controller.busyLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp, top = 4.dp),
                    )
                }
            }
            when (selected) {
                0 -> ConnectionScreen(controller)
                1 -> InstallScreen(controller)
                2 -> AppsScreen(controller)
                3 -> SystemScreen(controller)
                4 -> RemoteScreen(controller)
            }
        }
    }

    controller.packagePickerTitle?.let { title ->
        PackagePickerSheet(
            title = title,
            packages = controller.packagePickerItems,
            onDismiss = { controller.dismissPackagePicker() },
            onConfirm = { controller.confirmPackagePicker(it) },
        )
    }
}

@Composable
private fun ConnectionChip(status: ConnectionStatus, ip: String) {
    val (label, color) = when (status) {
        ConnectionStatus.Disconnected -> "Нет связи" to SoftMuted
        ConnectionStatus.Connecting -> "Подключение…" to Warn
        ConnectionStatus.Connected -> (if (ip.isBlank()) "Онлайн" else ip) to Success
    }
    AssistChip(
        onClick = {},
        label = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    modifier = Modifier.size(8.dp),
                    shape = CircleShape,
                    color = color,
                ) {}
                Text(
                    text = "  $label",
                    style = MaterialTheme.typography.labelLarge,
                    maxLines = 1,
                )
            }
        },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            labelColor = MaterialTheme.colorScheme.onSurface,
        ),
        modifier = Modifier.padding(end = 12.dp),
    )
}
