package com.tvtool.app

import android.app.ActivityManager
import android.content.Intent
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.tvtool.app.ui.Navy
import com.tvtool.app.ui.NavyCard
import com.tvtool.app.ui.SoftMuted
import com.tvtool.app.ui.SoftWhite
import com.tvtool.app.ui.Teal
import com.tvtool.app.ui.TvToolTheme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            TvToolTheme {
                BackHandler { /* HOME launcher — не выходим */ }
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = Navy,
                ) {
                    LauncherScreen(resumeTick = resumeTick.intValue)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue = resumeTick.intValue + 1
    }
}

private data class LauncherApp(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap?,
    val pinned: Boolean,
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LauncherScreen(resumeTick: Int) {
    val context = LocalContext.current
    val prefs = remember {
        context.getSharedPreferences("launcher", android.content.Context.MODE_PRIVATE)
    }
    var apps by remember { mutableStateOf<List<LauncherApp>>(emptyList()) }
    var ramText by remember { mutableStateOf("") }
    var menuPkg by remember { mutableStateOf<String?>(null) }
    var clock by remember { mutableStateOf(formatClock()) }
    var localTick by remember { mutableIntStateOf(0) }

    fun reload() {
        val pm = context.packageManager
        val pinned = prefs.getStringSet("pinned", emptySet()).orEmpty()
        val hidden = prefs.getStringSet("hidden", emptySet()).orEmpty()
        val resolved =
            (
                pm.queryIntentActivities(
                    Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),
                    0,
                ) +
                    pm.queryIntentActivities(
                        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
                        0,
                    )
                )
                .distinctBy { it.activityInfo.packageName }
                .filter {
                    it.activityInfo.packageName != context.packageName &&
                        it.activityInfo.packageName !in hidden
                }
                .sortedWith(
                    compareBy(
                        { it.activityInfo.packageName !in pinned },
                        { it.loadLabel(pm).toString().lowercase(Locale.getDefault()) },
                    ),
                )
        apps = resolved.map { info ->
            val pkg = info.activityInfo.packageName
            LauncherApp(
                packageName = pkg,
                label = info.loadLabel(pm).toString(),
                icon = drawableToBitmap(info.loadIcon(pm)),
                pinned = pkg in pinned,
            )
        }
        val memInfo = ActivityManager.MemoryInfo()
        (context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as ActivityManager)
            .getMemoryInfo(memInfo)
        ramText = "RAM ${memInfo.availMem / 1048576} МБ · ${apps.size} приложений"
    }

    LaunchedEffect(resumeTick, localTick) {
        reload()
    }

    LaunchedEffect(Unit) {
        while (true) {
            clock = formatClock()
            delay(30_000)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Navy)
            .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = clock,
                style = MaterialTheme.typography.headlineMedium,
                color = SoftWhite,
                modifier = Modifier
                    .weight(1f)
                    .combinedClickable(
                        onClick = {},
                        onLongClick = {
                            prefs.edit().remove("hidden").apply()
                            localTick++
                        },
                    ),
            )
            Text(
                text = ramText,
                style = MaterialTheme.typography.bodyMedium,
                color = SoftMuted,
            )
        }
        Spacer(Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 110.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(apps, key = { it.packageName }) { app ->
                AppTile(
                    title = (if (app.pinned) "★ " else "") + app.label,
                    icon = app.icon,
                    onClick = {
                        context.packageManager
                            .getLaunchIntentForPackage(app.packageName)
                            ?.let { context.startActivity(it) }
                    },
                    onLongClick = { menuPkg = app.packageName },
                )
            }
            item {
                AppTile(
                    title = "Настройки",
                    icon = null,
                    settings = true,
                    onClick = { context.startActivity(Intent(Settings.ACTION_SETTINGS)) },
                    onLongClick = {},
                )
            }
        }
    }

    menuPkg?.let { pkg ->
        AlertDialog(
            onDismissRequest = { menuPkg = null },
            title = { Text(pkg) },
            text = {
                Column {
                    TextButton(
                        onClick = {
                            toggleSet(prefs, "pinned", pkg)
                            menuPkg = null
                            localTick++
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Закрепить / открепить") }
                    TextButton(
                        onClick = {
                            toggleSet(prefs, "hidden", pkg)
                            menuPkg = null
                            localTick++
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Скрыть") }
                    TextButton(
                        onClick = {
                            menuPkg = null
                            context.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Удалить") }
                    TextButton(
                        onClick = {
                            menuPkg = null
                            context.startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:$pkg"),
                                ),
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("О приложении") }
                }
            },
            confirmButton = {
                TextButton(onClick = { menuPkg = null }) { Text("Закрыть") }
            },
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(
    title: String,
    icon: ImageBitmap?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    settings: Boolean = false,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .background(NavyCard, RoundedCornerShape(18.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier.size(56.dp),
            contentAlignment = Alignment.Center,
        ) {
            when {
                icon != null -> Image(
                    bitmap = icon,
                    contentDescription = title,
                    modifier = Modifier.size(56.dp),
                )
                settings -> Icon(
                    Icons.Filled.Settings,
                    contentDescription = title,
                    tint = Teal,
                    modifier = Modifier.size(40.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            color = SoftWhite,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

private fun formatClock(): String =
    SimpleDateFormat("HH:mm · EEE d MMM", Locale("ru")).format(Date())

private fun drawableToBitmap(drawable: Drawable): ImageBitmap? = try {
    drawable.toBitmap(96, 96).asImageBitmap()
} catch (_: Throwable) {
    null
}

private fun toggleSet(prefs: android.content.SharedPreferences, key: String, pkg: String) {
    val set = prefs.getStringSet(key, emptySet())!!.toMutableSet()
    if (!set.add(pkg)) set.remove(pkg)
    prefs.edit().putStringSet(key, set).apply()
}
