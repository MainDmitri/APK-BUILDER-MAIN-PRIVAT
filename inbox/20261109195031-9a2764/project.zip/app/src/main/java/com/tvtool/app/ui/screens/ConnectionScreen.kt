package com.tvtool.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.tvtool.app.ConnectionStatus
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.ActionButton
import com.tvtool.app.ui.components.ProgressBlock
import com.tvtool.app.ui.components.SectionCard
import com.tvtool.app.ui.components.SpacerH

@Composable
fun ConnectionScreen(controller: TvToolController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Подключение к ТВ") {
            OutlinedTextField(
                value = controller.ip,
                onValueChange = { controller.ip = it },
                label = { Text("IP телевизора") },
                placeholder = { Text("192.168.1.50") },
                supportingText = { Text("ADB по Wi‑Fi, порт 5555") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                modifier = Modifier.fillMaxWidth(),
            )
            SpacerH(8)
            if (controller.busy && controller.busyLabel.contains("Сканир", ignoreCase = true)) {
                ProgressBlock("Сканирование", controller.scanProgress)
                SpacerH(8)
            }
            ActionButton(
                text = "Сканировать сеть",
                onClick = { controller.scanNetwork() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Подключиться и показать инфо",
                onClick = { controller.connectAndInfo() },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Отключиться",
                onClick = { controller.disconnect() },
                enabled = controller.status != ConnectionStatus.Disconnected,
            )
        }

        if (controller.deviceInfo.isNotBlank()) {
            SectionCard("Устройство") {
                Text(
                    text = controller.deviceInfo,
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        SectionCard("Подсказка") {
            Text(
                "Включите «Отладка по сети» / ADB over Wi‑Fi на телевизоре. " +
                    "Телефон и ТВ должны быть в одной Wi‑Fi сети.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        SpacerH(8)
    }
}
