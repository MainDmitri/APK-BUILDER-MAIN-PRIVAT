package com.tvtool.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.tvtool.app.ui.MainScreen
import com.tvtool.app.ui.TvToolTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            val controller = remember { TvToolController(applicationContext) }
            DisposableEffect(controller) {
                onDispose { controller.onCleared() }
            }
            TvToolTheme {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .safeDrawingPadding(),
                    color = androidx.compose.material3.MaterialTheme.colorScheme.background,
                ) {
                    MainScreen(controller)
                }
            }
        }
    }
}
