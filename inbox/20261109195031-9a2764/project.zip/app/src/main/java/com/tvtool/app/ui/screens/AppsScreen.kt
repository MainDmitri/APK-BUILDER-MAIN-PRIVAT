package com.tvtool.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tvtool.app.TvToolController
import com.tvtool.app.ui.components.ActionButton
import com.tvtool.app.ui.components.SectionCard
import com.tvtool.app.ui.components.SpacerH

@Composable
fun AppsScreen(controller: TvToolController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Заморозка") {
            Text(
                "Отключение пользовательских и системных пакетов через pm disable-user.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SpacerH(8)
            ActionButton(
                text = "Заморозить приложения…",
                onClick = {
                    controller.openPackagePicker(
                        title = "Заморозить",
                        cmd = "pm list packages -e",
                    ) { pkgs -> controller.freezePackages(pkgs) }
                },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Вернуть все замороженные",
                onClick = { controller.unfreezeAll() },
                enabled = !controller.busy,
            )
        }

        SectionCard("Пользовательские приложения") {
            ActionButton(
                text = "Запустить приложения…",
                onClick = {
                    controller.openPackagePicker(
                        title = "Запуск",
                        cmd = "pm list packages -3",
                    ) { pkgs -> controller.launchPackages(pkgs) }
                },
                enabled = !controller.busy,
            )
            SpacerH(8)
            ActionButton(
                text = "Удалить приложения…",
                onClick = {
                    controller.openPackagePicker(
                        title = "Удалить",
                        cmd = "pm list packages -3",
                    ) { pkgs -> controller.uninstallPackages(pkgs) }
                },
                enabled = !controller.busy,
            )
        }
        SpacerH(8)
    }
}
