package com.example.tgbotclient

import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val URL_REGEX = Regex("""(https?://|www\.|t\.me/)[^\s<>"]+""", RegexOption.IGNORE_CASE)

/** Makes http(s) / t.me links tappable; the system opens them in the browser or Telegram. */
private fun linkify(text: String, linkColor: Color): AnnotatedString = buildAnnotatedString {
    var last = 0
    val styles = TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline))
    for (m in URL_REGEX.findAll(text)) {
        val raw = m.value.trimEnd('.', ',', ')', '!', '?', ';', ':')
        append(text.substring(last, m.range.first))
        val url = if (raw.startsWith("http", true)) raw else "https://$raw"
        withLink(LinkAnnotation.Url(url, styles)) { append(raw) }
        last = m.range.first + raw.length
    }
    append(text.substring(last))
}

@Composable
private fun DateChip(t: Long) {
    val now = System.currentTimeMillis()
    val label = when {
        sameDay(t, now) -> "Сегодня"
        sameDay(t, now - 86_400_000L) -> "Вчера"
        else -> SimpleDateFormat("d MMMM", Locale.getDefault()).format(Date(t))
    }
    Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(
            label, style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(
    msg: TgMessage,
    quoted: TgMessage?,
    firstInGroup: Boolean,
    lastInGroup: Boolean,
    showSender: Boolean,
    highlighted: Boolean,
    onReply: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
    onQuoteClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val haptics = LocalHapticFeedback.current
    var menu by remember { mutableStateOf(false) }
    // only messages that just arrived animate in; old ones appear instantly when scrolled into view
    val state = remember(msg.id) {
        MutableTransitionState(System.currentTimeMillis() - msg.time > 8000).apply { targetState = true }
    }
    val out = msg.isBot
    val bg = if (out) cs.primary else cs.surface
    val fg = if (out) Color.White else cs.onSurface
    val big = 18.dp
    val small = 6.dp
    val shape = RoundedCornerShape(
        topStart = if (!out && !firstInGroup) small else big,
        topEnd = if (out && !firstInGroup) small else big,
        bottomStart = if (!out) (if (lastInGroup) 4.dp else small) else big,
        bottomEnd = if (out) (if (lastInGroup) 4.dp else small) else big
    )
    val highlight by animateColorAsState(
        if (highlighted) cs.primary.copy(alpha = 0.18f) else Color.Transparent,
        tween(if (highlighted) Motion.SHORT else 900), label = "highlight"
    )
    val pressScale by animateFloatAsState(if (menu) 0.97f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "press")
    val maxWidth = (LocalConfiguration.current.screenWidthDp * 0.8f).dp
    val linkColor = if (out) Color.White else cs.primary
    val body = remember(msg.text, linkColor) { linkify(msg.text, linkColor) }

    androidx.compose.animation.AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(Motion.SHORT)) +
            scaleIn(spring(0.75f, Spring.StiffnessMediumLow), initialScale = 0.8f, transformOrigin = TransformOrigin(if (out) 1f else 0f, 1f)) +
            slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 2 }
    ) {
        Column(
            Modifier.fillMaxWidth().background(highlight)
                .padding(top = if (firstInGroup) 4.dp else 1.dp, bottom = 1.dp, start = 10.dp, end = 10.dp),
            horizontalAlignment = if (out) Alignment.End else Alignment.Start
        ) {
            Box {
                Column(
                    Modifier.widthIn(max = maxWidth)
                        .graphicsLayer { scaleX = pressScale; scaleY = pressScale }
                        .shadow(if (out) 0.dp else 0.5.dp, shape)
                        .clip(shape).background(bg)
                        .combinedClickable(
                            role = Role.Button,
                            onClickLabel = "Ответить",
                            onLongClickLabel = "Действия с сообщением",
                            onClick = onReply,
                            onLongClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                menu = true
                            }
                        )
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    if (showSender && !out) {
                        Text(msg.fromName, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = cs.primary)
                    }
                    if (msg.replyTo != null) {
                        Row(
                            Modifier.padding(vertical = 4.dp).height(IntrinsicSize.Min)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (out) Color.White.copy(alpha = 0.15f) else cs.primary.copy(alpha = 0.08f))
                                .clickable(onClickLabel = "Перейти к сообщению", onClick = onQuoteClick)
                        ) {
                            Box(Modifier.width(3.dp).fillMaxHeight().background(if (out) Color.White else cs.primary))
                            Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                Text(
                                    quoted?.fromName ?: "Сообщение", style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold, color = if (out) Color.White else cs.primary
                                )
                                Text(
                                    quoted?.text ?: "нет на устройстве", maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                    Text(body, color = fg, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        clockTime(msg.time),
                        style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.65f),
                        modifier = Modifier.align(Alignment.End)
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, shape = RoundedCornerShape(14.dp)) {
                    DropdownMenuItem(text = { Text("Ответить") }, onClick = { menu = false; onReply() })
                    DropdownMenuItem(text = { Text("Копировать") }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(
                        text = { Text("Удалить у себя", color = cs.error) },
                        onClick = { menu = false; onDelete() }
                    )
                }
            }
        }
    }
}

@Composable
private fun SendButton(enabled: Boolean, sending: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (enabled || sending) cs.primary else cs.surfaceVariant, tween(Motion.SHORT), label = "sendBg")
    val scale by animateFloatAsState(
        if (enabled || sending) 1f else 0.86f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium), label = "sendScale"
    )
    Box(
        Modifier.size(52.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape).background(bg)
            .clickable(enabled = enabled && !sending, role = Role.Button, onClickLabel = "Отправить", onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = sending,
            transitionSpec = {
                (scaleIn(spring(Spring.DampingRatioMediumBouncy), initialScale = 0.4f) + fadeIn()) togetherWith
                    (scaleOut(tween(Motion.SHORT), targetScale = 0.4f) + fadeOut(tween(Motion.SHORT)))
            },
            label = "sendIcon"
        ) { isSending ->
            if (isSending) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                val rotation by animateFloatAsState(if (enabled) 0f else -30f, spring(Spring.DampingRatioMediumBouncy), label = "sendRot")
                Icon(
                    Icons.AutoMirrored.Filled.Send, contentDescription = "Отправить",
                    tint = if (enabled) Color.White else cs.onSurfaceVariant,
                    modifier = Modifier.graphicsLayer { rotationZ = rotation }
                )
            }
        }
    }
}

@Composable
fun ChatScreen(chatId: Long, onBack: () -> Unit, refresh: Long) {
    val context = LocalContext.current
    val storage = remember { Storage.get(context) }
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val cs = MaterialTheme.colorScheme
    var chat by remember { mutableStateOf<Chat?>(null) }
    var messages by remember { mutableStateOf(emptyList<TgMessage>()) }
    var loaded by remember { mutableStateOf(false) }
    var text by rememberSaveableText(prefs.getString(Prefs.draftKey(chatId), "").orEmpty())
    var replyTo by remember { mutableStateOf<TgMessage?>(null) }
    var sending by remember { mutableStateOf(false) }
    var firstLoad by remember { mutableStateOf(true) }
    var highlightedId by remember { mutableStateOf<Long?>(null) }
    val listState = rememberLazyListState()

    // the chat is "open" only while the screen is resumed: in background, notifications and counters work again
    LifecycleResumeEffect(chatId) {
        MessageBus.openChatId = chatId
        context.getSystemService(NotificationManager::class.java)?.cancel(chatNotificationId(chatId))
        scope.launch {
            withContext(Dispatchers.IO) { storage.markRead(chatId) }
            MessageBus.notifyChanged()
        }
        onPauseOrDispose {
            if (MessageBus.openChatId == chatId) MessageBus.openChatId = null
        }
    }

    LaunchedEffect(refresh) {
        val (c, m) = withContext(Dispatchers.IO) { storage.getChat(chatId) to storage.getMessages(chatId) }
        chat = c
        messages = m
        loaded = true
    }

    // draft is persisted with a small debounce so it survives leaving the chat or killing the app
    LaunchedEffect(text) {
        delay(400)
        val key = Prefs.draftKey(chatId)
        if (text.isBlank()) prefs.edit().remove(key).apply() else prefs.edit().putString(key, text).apply()
    }

    LaunchedEffect(highlightedId) {
        if (highlightedId != null) { delay(1200); highlightedId = null }
    }

    BackHandler(enabled = replyTo != null) { replyTo = null }

    val nearBottom by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            last >= listState.layoutInfo.totalItemsCount - 2
        }
    }
    LaunchedEffect(messages.size) {
        if (messages.isEmpty()) return@LaunchedEffect
        if (firstLoad) {
            listState.scrollToItem(messages.lastIndex)
            firstLoad = false
        } else if (nearBottom || messages.last().isBot) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val title = chat?.title ?: "Чат $chatId"
    val overLimit = text.length > TG_TEXT_LIMIT

    fun send() {
        val msgText = text.trim()
        if (msgText.isEmpty() || sending || msgText.length > TG_TEXT_LIMIT) return
        val token = prefs.getString("token", "").orEmpty().trim()
        if (token.isBlank()) {
            showMessage("Укажите токен бота в настройках")
            return
        }
        val reply = replyTo
        sending = true
        scope.launch {
            try {
                // real message_id from Telegram, so replying to our own messages works
                val sentId = TelegramApi.sendText(token, chatId, msgText, reply?.id)
                val now = System.currentTimeMillis()
                messages = withContext(Dispatchers.IO) {
                    storage.saveMessage(TgMessage(sentId, chatId, "Бот", msgText, now, true, reply?.id))
                    storage.getMessages(chatId)
                }
                text = ""
                replyTo = null
                prefs.edit().remove(Prefs.draftKey(chatId)).apply()
                MessageBus.notifyChanged()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                showMessage("Не отправлено: ${humanError(e)}")
            } finally {
                sending = false
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            HeaderIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Назад", onBack)
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .clickable(onClickLabel = "Скопировать id чата") {
                        (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("chat_id", chatId.toString()))
                        showMessage("ID чата $chatId скопирован")
                    }
                    .padding(vertical = 4.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(title, 42.dp, key = chatId)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val sub = listOfNotNull(chat?.type?.let { chatTypeLabel(it) }, "сообщений: ${messages.size}").joinToString(" · ")
                    AnimatedStatusText(sub, Color.White.copy(alpha = 0.8f), MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(Modifier.width(8.dp))
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (loaded && messages.isEmpty()) {
                Column(
                    Modifier.align(Alignment.Center).padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("👋", style = MaterialTheme.typography.displaySmall)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Сообщений пока нет.\nНапишите первым — бот отправит текст в этот чат.",
                        textAlign = TextAlign.Center, color = cs.onSurfaceVariant
                    )
                }
            }
            LazyColumn(
                state = listState, modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                itemsIndexed(messages, key = { _, m -> m.id }) { index, msg ->
                    val prev = messages.getOrNull(index - 1)
                    val next = messages.getOrNull(index + 1)
                    val newDay = prev == null || !sameDay(prev.time, msg.time)
                    val firstInGroup = prev == null || !sameDay(prev.time, msg.time) || prev.isBot != msg.isBot || prev.fromName != msg.fromName ||
                        msg.time - prev.time > 5 * 60_000L
                    val lastInGroup = next == null || !sameDay(next.time, msg.time) || next.isBot != msg.isBot ||
                        next.fromName != msg.fromName || next.time - msg.time > 5 * 60_000L
                    Column(Modifier.animateItem()) {
                        if (newDay) DateChip(msg.time)
                        MessageBubble(
                            msg = msg,
                            quoted = msg.replyTo?.let { rid -> messages.firstOrNull { it.id == rid } },
                            firstInGroup = firstInGroup,
                            lastInGroup = lastInGroup,
                            showSender = firstInGroup && chat?.type != "private",
                            highlighted = highlightedId == msg.id,
                            onReply = { replyTo = msg },
                            onCopy = {
                                (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                                    .setPrimaryClip(ClipData.newPlainText("message", msg.text))
                                showMessage("Текст скопирован")
                            },
                            onDelete = {
                                scope.launch {
                                    messages = withContext(Dispatchers.IO) {
                                        storage.deleteMessage(chatId, msg.id)
                                        storage.getMessages(chatId)
                                    }
                                    if (replyTo?.id == msg.id) replyTo = null
                                    showMessage("Сообщение удалено с устройства")
                                }
                            },
                            onQuoteClick = {
                                val i = messages.indexOfFirst { it.id == msg.replyTo }
                                if (i >= 0) {
                                    scope.launch {
                                        listState.animateScrollToItem(i)
                                        highlightedId = messages[i].id
                                    }
                                } else {
                                    showMessage("Исходного сообщения нет на устройстве")
                                }
                            }
                        )
                    }
                }
            }
            // BoxScope inside a Column: the ColumnScope extension can't be used with an implicit
            // receiver here (that was the compile error), so call the top-level overload explicitly.
            androidx.compose.animation.AnimatedVisibility(
                visible = !nearBottom && messages.isNotEmpty(),
                modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp),
                enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(),
                exit = scaleOut(tween(Motion.SHORT)) + fadeOut(tween(Motion.SHORT))
            ) {
                SmallFloatingActionButton(
                    onClick = { scope.launch { listState.animateScrollToItem(messages.lastIndex) } },
                    containerColor = cs.surface, contentColor = cs.primary,
                    shape = CircleShape
                ) { Icon(Icons.Filled.KeyboardArrowDown, "К последним сообщениям") }
            }
        }

        AnimatedVisibility(
            visible = replyTo != null,
            enter = expandVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) + fadeIn(),
            exit = shrinkVertically(tween(Motion.SHORT)) + fadeOut(tween(Motion.SHORT))
        ) {
            // keep the last value during the exit animation
            var shown by remember { mutableStateOf(replyTo) }
            if (replyTo != null) shown = replyTo
            Row(
                Modifier.fillMaxWidth().background(cs.surface)
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(cs.primary))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Ответ: ${shown?.fromName.orEmpty()}", style = MaterialTheme.typography.labelMedium,
                        color = cs.primary, fontWeight = FontWeight.Bold, maxLines = 1
                    )
                    Text(shown?.text.orEmpty(), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { replyTo = null }) { Icon(Icons.Filled.Close, "Отменить ответ") }
            }
        }

        Surface(color = cs.surface, tonalElevation = 2.dp, shadowElevation = 6.dp) {
            Column(
                Modifier.fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.ime.union(WindowInsets.navigationBars))
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(
                        value = text, onValueChange = { text = it },
                        modifier = Modifier.weight(1f), maxLines = 6,
                        shape = RoundedCornerShape(26.dp),
                        isError = overLimit,
                        placeholder = { Text("Сообщение от имени бота") },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = cs.outlineVariant,
                            focusedContainerColor = cs.background.copy(alpha = 0.4f),
                            unfocusedContainerColor = cs.background.copy(alpha = 0.4f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    SendButton(enabled = text.isNotBlank() && !overLimit, sending = sending, onClick = { send() })
                }
                AnimatedVisibility(
                    visible = text.length > TG_TEXT_LIMIT - 500,
                    enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
                ) {
                    Text(
                        "${text.length} / $TG_TEXT_LIMIT" + if (overLimit) " — слишком длинно для Telegram" else "",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (overLimit) cs.error else cs.onSurfaceVariant,
                        modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                    )
                }
            }
        }
    }
}

/** Draft text that survives configuration changes; initial value comes from the persisted draft. */
@Composable
private fun rememberSaveableText(initial: String): MutableState<String> =
    androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(initial) }
