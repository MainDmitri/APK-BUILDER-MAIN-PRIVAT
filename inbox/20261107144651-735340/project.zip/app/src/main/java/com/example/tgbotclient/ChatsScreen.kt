package com.example.tgbotclient

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ChatsScreen(refresh: Long, onOpenChat: (Long) -> Unit, onSettings: () -> Unit) {
    val context = LocalContext.current
    val storage = remember { Storage.get(context) }
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val status by rememberBotStatus()
    var chats by remember { mutableStateOf<List<Chat>?>(null) }   // null = still loading
    var drafts by remember { mutableStateOf(emptyMap<Long, String>()) }
    var botName by remember { mutableStateOf("") }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var actionsFor by remember { mutableStateOf<Chat?>(null) }
    var toDelete by remember { mutableStateOf<Chat?>(null) }
    // staggered entrance only for the very first appearance of the list
    var introPlayed by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(refresh) {
        val loaded = withContext(Dispatchers.IO) { storage.getChats() }
        drafts = loaded.mapNotNull { c -> prefs.getString(Prefs.draftKey(c.id), null)?.takeIf { it.isNotBlank() }?.let { c.id to it } }.toMap()
        botName = prefs.getString("bot_name", "").orEmpty()
        chats = loaded
    }
    LaunchedEffect(chats != null) {
        if (chats != null) { delay(800); introPlayed = true }
    }

    BackHandler(enabled = searchOpen) { searchOpen = false; query = "" }

    val all = chats.orEmpty()
    val shown = remember(all, query) {
        val q = query.trim()
        if (q.isEmpty()) all else all.filter { it.title.contains(q, true) || it.lastMessage.contains(q, true) }
    }
    val totalUnread = all.sumOf { it.unread }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("TG Bot Client Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(status.state, 8.dp)
                    Spacer(Modifier.width(4.dp))
                    val prefix = if (botName.isNotBlank()) "$botName · " else ""
                    val unread = if (totalUnread > 0) " · непрочитанных: $totalUnread" else ""
                    AnimatedStatusText(
                        prefix + statusText(status) + unread,
                        Color.White.copy(alpha = 0.85f), MaterialTheme.typography.bodySmall
                    )
                }
            }
            if (all.isNotEmpty()) {
                Crossfade(searchOpen, label = "searchToggle") { open ->
                    if (open) HeaderIconButton(Icons.Filled.Close, "Закрыть поиск") { searchOpen = false; query = "" }
                    else HeaderIconButton(Icons.Filled.Search, "Поиск") { searchOpen = true }
                }
            }
            HeaderIconButton(Icons.Filled.Settings, "Настройки", onSettings)
        }

        AnimatedVisibility(
            visible = status.state == BotState.ERROR || status.state == BotState.STOPPED && all.isNotEmpty(),
            enter = expandVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) + fadeIn(),
            exit = shrinkVertically(tween(Motion.SHORT)) + fadeOut()
        ) {
            InfoBanner(
                text = if (status.state == BotState.ERROR) status.message.ifBlank { "Бот остановлен из-за ошибки" }
                else "Бот остановлен — новые сообщения не приходят",
                isError = status.state == BotState.ERROR,
                actionLabel = "Настройки", onAction = onSettings
            )
        }

        AnimatedVisibility(
            visible = searchOpen && all.isNotEmpty(),
            enter = expandVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) + fadeIn(),
            exit = shrinkVertically(tween(Motion.SHORT)) + fadeOut(tween(Motion.SHORT))
        ) {
            val focus = remember { FocusRequester() }
            LaunchedEffect(Unit) { focus.requestFocus() }
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Поиск по чатам и сообщениям") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Очистить") }
                },
                singleLine = true, shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).focusRequester(focus)
            )
        }

        when {
            chats == null -> Box(Modifier.fillMaxSize()) // DB read takes a few ms; avoid flashing the empty state
            all.isEmpty() -> EmptyState(status.state, onSettings)
            shown.isEmpty() -> Text(
                "Ничего не найдено по запросу «${query.trim()}»",
                Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            else -> {
                val listState = rememberLazyListState()
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = WindowInsets.navigationBars.asPaddingValues()
                ) {
                    itemsIndexed(shown, key = { _, c -> c.id }) { index, chat ->
                        val animate = !introPlayed && index < 12
                        val state = remember { MutableTransitionState(!animate).apply { targetState = true } }
                        val delayMs = if (animate) index * 40 else 0
                        // top-level (non-scoped) overload: we are inside LazyItemScope, not ColumnScope
                        androidx.compose.animation.AnimatedVisibility(
                            visibleState = state,
                            modifier = Modifier.animateItem(),
                            enter = fadeIn(tween(Motion.MEDIUM, delayMillis = delayMs)) +
                                slideInVertically(tween(Motion.MEDIUM, delayMillis = delayMs, easing = Motion.EmphasizedDecelerate)) { it / 2 }
                        ) {
                            ChatRow(
                                chat = chat,
                                draft = drafts[chat.id],
                                onClick = { onOpenChat(chat.id) },
                                onLongClick = { actionsFor = chat }
                            )
                        }
                    }
                }
            }
        }
    }

    actionsFor?.let { chat ->
        ChatActionsDialog(
            chat = chat,
            onDismiss = { actionsFor = null },
            onMarkRead = {
                actionsFor = null
                scope.launch {
                    withContext(Dispatchers.IO) { storage.markRead(chat.id) }
                    MessageBus.notifyChanged()
                }
            },
            onDelete = { actionsFor = null; toDelete = chat }
        )
    }

    toDelete?.let { chat ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            icon = { Icon(Icons.Filled.Delete, null) },
            title = { Text("Удалить чат?") },
            text = { Text("«${chat.title}» и вся переписка будут удалены только с этого устройства. В Telegram ничего не изменится.") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) { storage.deleteChat(chat.id) }
                        prefs.edit().remove(Prefs.draftKey(chat.id)).apply()
                        MessageBus.notifyChanged()
                        showMessage("Чат «${chat.title}» удалён")
                    }
                }) { Text("Удалить", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun ChatActionsDialog(chat: Chat, onDismiss: () -> Unit, onMarkRead: () -> Unit, onDelete: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(chat.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column {
                Text("${chatTypeLabel(chat.type)} · id ${chat.id}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                if (chat.unread > 0) {
                    ListItem(
                        headlineContent = { Text("Отметить прочитанным") },
                        leadingContent = { Icon(Icons.Filled.Done, null) },
                        modifier = Modifier.clip16().clickableRole(onMarkRead),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                }
                ListItem(
                    headlineContent = { Text("Удалить чат", color = MaterialTheme.colorScheme.error) },
                    leadingContent = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                    modifier = Modifier.clip16().clickableRole(onDelete),
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}

private fun Modifier.clip16() = this.then(Modifier.clip(RoundedCornerShape(16.dp)))

private fun Modifier.clickableRole(onClick: () -> Unit) =
    this.then(Modifier.clickable(role = Role.Button, onClick = onClick))

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(chat: Chat, draft: String?, onClick: () -> Unit, onLongClick: () -> Unit) {
    val haptics = LocalHapticFeedback.current
    val cs = MaterialTheme.colorScheme
    val description = buildString {
        append(chat.title)
        if (chat.unread > 0) append(", непрочитанных ${chat.unread}")
        append(". ")
        append(draft?.let { "Черновик: $it" } ?: chat.lastMessage)
    }
    Row(
        Modifier.fillMaxWidth()
            .combinedClickable(
                role = Role.Button,
                onClickLabel = "Открыть чат",
                onLongClickLabel = "Действия с чатом",
                onClick = onClick,
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongClick()
                }
            )
            .semantics(mergeDescendants = true) {
                contentDescription = description
            }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(chat.title, 52.dp, key = chat.id)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    chat.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    listTime(chat.lastTime), style = MaterialTheme.typography.labelSmall,
                    color = if (chat.unread > 0) cs.primary else cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val preview = if (draft != null) {
                    androidx.compose.ui.text.buildAnnotatedString {
                        pushStyle(androidx.compose.ui.text.SpanStyle(color = cs.error, fontWeight = FontWeight.Medium))
                        append("Черновик: ")
                        pop()
                        append(draft.replace('\n', ' '))
                    }
                } else androidx.compose.ui.text.AnnotatedString(chat.lastMessage.replace('\n', ' '))
                Text(
                    preview, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                UnreadBadge(chat.unread)
            }
        }
    }
}

@Composable
private fun EmptyState(state: BotState, onSettings: () -> Unit) {
    val t = rememberInfiniteTransition(label = "bob")
    val dy by t.animateFloat(
        initialValue = 0f, targetValue = -16f,
        animationSpec = infiniteRepeatable(tween(1400, easing = Motion.Standard), RepeatMode.Reverse), label = "bobY"
    )
    val visible = remember { MutableTransitionState(false).apply { targetState = true } }
    androidx.compose.animation.AnimatedVisibility(
        visibleState = visible,
        enter = fadeIn(tween(Motion.LONG)) + slideInVertically(tween(Motion.LONG, easing = Motion.EmphasizedDecelerate)) { it / 6 }
    ) {
        Column(
            Modifier.fillMaxSize().navigationBarsPadding().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text("💬", fontSize = 72.sp, modifier = Modifier.graphicsLayer { translationY = dy })
            Spacer(Modifier.height(20.dp))
            Text("Пока нет чатов", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            val running = state == BotState.RUNNING || state == BotState.STARTING || state == BotState.RETRYING
            Text(
                if (running) "Бот запущен. Напишите ему в Telegram — переписка появится здесь."
                else "1. Получите токен у @BotFather\n2. Вставьте его в настройках и нажмите «Старт»\n3. Напишите боту в Telegram",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium
            )
            if (!running) {
                Spacer(Modifier.height(24.dp))
                Button(onClick = onSettings, shape = RoundedCornerShape(24.dp), contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp)) {
                    Icon(Icons.Filled.Settings, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Открыть настройки")
                }
            }
        }
    }
}
