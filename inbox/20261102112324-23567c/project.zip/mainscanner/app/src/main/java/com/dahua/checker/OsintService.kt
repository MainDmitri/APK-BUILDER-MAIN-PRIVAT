package com.dahua.checker

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * OSINT сервис — поиск камер и серверов через IoT-поисковики:
 *   FOFA    (fofa.info)   — email + key как URL-параметры, qbase64 запрос
 *   Shodan  (shodan.io)   — api_key в URL
 *   Censys  (censys.io)   — Basic Auth: api_id:api_secret
 *   ZoomEye (zoomeye.hk)  — API-KEY заголовок
 */
object OsintService {

    data class OsintResult(
        val ip: String,
        val port: Int,
        val host: String = "",
        val country: String = "",
        val title: String = "",
        val source: String = ""   // "FOFA", "Shodan", "Censys", "ZoomEye"
    )

    private fun readBody(conn: HttpURLConnection): String = try {
        if (conn.responseCode == 200)
            conn.inputStream.bufferedReader().readText()
        else
            conn.errorStream?.bufferedReader()?.readText() ?: ""
    } catch (_: Exception) { "" }

    // ── FOFA ──────────────────────────────────────────────────────────────────
    // Аутентификация: email=&key= в URL-параметрах (не Basic Auth!)
    // https://fofa.info/api/v1/search/all?email=X&key=Y&qbase64=Z&size=N&fields=ip,port,country,host,title
    suspend fun searchFofa(
        email: String,
        apiKey: String,
        query: String,
        size: Int = 100
    ): Result<List<OsintResult>> = withContext(Dispatchers.IO) {
        try {
            val qb64 = Base64.encodeToString(query.trim().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            val encodedEmail = URLEncoder.encode(email, "UTF-8")
            val fields = "ip,port,country,host,title"
            val urlStr = "https://fofa.info/api/v1/search/all" +
                "?email=$encodedEmail&key=$apiKey&qbase64=$qb64" +
                "&size=$size&fields=$fields&full=false"

            val conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "MainScanner/1.0")
            conn.connectTimeout = 12000
            conn.readTimeout = 20000

            val code = conn.responseCode
            val body = readBody(conn)
            conn.disconnect()

            if (code != 200) {
                // Попробуем распарсить сообщение об ошибке из JSON
                val errMsg = runCatching {
                    JSONObject(body).optString("errmsg", "HTTP $code")
                }.getOrElse { "HTTP $code" }
                return@withContext Result.failure(Exception("FOFA: $errMsg"))
            }

            val json = JSONObject(body)
            if (json.optBoolean("error", false)) {
                return@withContext Result.failure(
                    Exception(json.optString("errmsg", "FOFA неизвестная ошибка"))
                )
            }

            val results = json.optJSONArray("results") ?: JSONArray()
            val list = mutableListOf<OsintResult>()
            for (i in 0 until results.length()) {
                val row = results.optJSONArray(i) ?: continue
                // fields порядок: ip, port, country, host, title
                val ip      = row.optString(0).trim()
                val port    = row.optString(1).toIntOrNull() ?: 0
                val country = row.optString(2)
                val host    = row.optString(3)
                val title   = row.optString(4)
                if (ip.isNotEmpty() && ip != "null") {
                    list.add(OsintResult(ip, port, host, country, title, "FOFA"))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Shodan ────────────────────────────────────────────────────────────────
    // https://api.shodan.io/shodan/host/search?key=<key>&query=<q>&page=1
    suspend fun searchShodan(
        apiKey: String,
        query: String,
        page: Int = 1
    ): Result<List<OsintResult>> = withContext(Dispatchers.IO) {
        try {
            val q = URLEncoder.encode(query, "UTF-8")
            val urlStr = "https://api.shodan.io/shodan/host/search?key=$apiKey&query=$q&page=$page"
            val conn = URL(urlStr).openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 12000
            conn.readTimeout = 20000

            val code = conn.responseCode
            val body = readBody(conn)
            conn.disconnect()

            if (code != 200) {
                val errMsg = runCatching { JSONObject(body).optString("error", "HTTP $code") }
                    .getOrElse { "HTTP $code" }
                return@withContext Result.failure(Exception("Shodan: $errMsg"))
            }

            val json = JSONObject(body)
            val matches = json.optJSONArray("matches") ?: JSONArray()
            val list = mutableListOf<OsintResult>()
            for (i in 0 until matches.length()) {
                val m       = matches.optJSONObject(i) ?: continue
                val ip      = m.optString("ip_str").trim()
                val port    = m.optInt("port", 0)
                // location — это объект, не строка
                val locObj  = m.optJSONObject("location")
                val country = locObj?.optString("country_name") ?: ""
                val hostArr = m.optJSONArray("hostnames")
                val host    = if (hostArr != null && hostArr.length() > 0) hostArr.optString(0) else ""
                val title   = m.optString("data", "").take(80)
                if (ip.isNotEmpty() && ip != "null") {
                    list.add(OsintResult(ip, port, host, country, title, "Shodan"))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Censys ────────────────────────────────────────────────────────────────
    // POST https://search.censys.io/api/v2/hosts/search
    // Basic Auth: api_id:api_secret
    suspend fun searchCensys(
        apiId: String,
        apiSecret: String,
        query: String,
        perPage: Int = 100
    ): Result<List<OsintResult>> = withContext(Dispatchers.IO) {
        try {
            val conn = URL("https://search.censys.io/api/v2/hosts/search")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            val auth = Base64.encodeToString("$apiId:$apiSecret".toByteArray(), Base64.NO_WRAP)
            conn.setRequestProperty("Authorization", "Basic $auth")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 12000
            conn.readTimeout = 20000
            conn.doOutput = true

            // Censys v2 fields — не передаём в теле, только q и per_page
            val reqBody = JSONObject().apply {
                put("q", query)
                put("per_page", minOf(perPage, 100))
            }
            conn.outputStream.use { it.write(reqBody.toString().toByteArray()) }

            val code = conn.responseCode
            val body = readBody(conn)
            conn.disconnect()

            if (code != 200) {
                val errMsg = runCatching {
                    JSONObject(body).optJSONObject("error")?.optString("message") ?: "HTTP $code"
                }.getOrElse { "HTTP $code" }
                return@withContext Result.failure(Exception("Censys: $errMsg"))
            }

            val json = JSONObject(body)
            val hits = json.optJSONObject("result")?.optJSONArray("hits") ?: JSONArray()
            val list = mutableListOf<OsintResult>()
            for (i in 0 until hits.length()) {
                val h       = hits.optJSONObject(i) ?: continue
                val ip      = h.optString("ip").trim()
                val svcs    = h.optJSONArray("services") ?: JSONArray()
                val firstSvc = svcs.optJSONObject(0)
                val port    = firstSvc?.optInt("port", 0) ?: 0
                val svcName = firstSvc?.optString("service_name", "") ?: ""
                val country = h.optJSONObject("location")?.optString("country", "") ?: ""
                // reverse_dns.names — массив строк
                val namesArr = h.optJSONObject("dns")?.optJSONObject("reverse_dns")
                    ?.optJSONArray("names")
                val host = if (namesArr != null && namesArr.length() > 0) namesArr.optString(0) else ""
                if (ip.isNotEmpty() && ip != "null") {
                    list.add(OsintResult(ip, port, host, country, svcName, "Censys"))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── ZoomEye ───────────────────────────────────────────────────────────────
    // https://api.zoomeye.hk/host/search?query=<q>&page=1
    // Заголовок: API-KEY: <key>
    suspend fun searchZoomEye(
        apiKey: String,
        query: String,
        page: Int = 1
    ): Result<List<OsintResult>> = withContext(Dispatchers.IO) {
        try {
            val q = URLEncoder.encode(query, "UTF-8")
            val conn = URL("https://api.zoomeye.org/host/search?query=$q&page=$page")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("API-KEY", apiKey)
            conn.connectTimeout = 12000
            conn.readTimeout = 20000

            val code = conn.responseCode
            val body = readBody(conn)
            conn.disconnect()

            if (code != 200) {
                val errMsg = runCatching { JSONObject(body).optString("message", "HTTP $code") }
                    .getOrElse { "HTTP $code" }
                return@withContext Result.failure(Exception("ZoomEye: $errMsg"))
            }

            val json = JSONObject(body)
            val matches = json.optJSONArray("matches") ?: JSONArray()
            val list = mutableListOf<OsintResult>()
            for (i in 0 until matches.length()) {
                val m    = matches.optJSONObject(i) ?: continue
                val ip   = m.optString("ip").trim()
                val port = m.optJSONObject("portinfo")?.optInt("port", 0) ?: 0
                // geoinfo.country.names — объект {"en":"Russia","zh-CN":"俄罗斯",...}
                val countryNamesObj = m.optJSONObject("geoinfo")
                    ?.optJSONObject("country")?.optJSONObject("names")
                val country = countryNamesObj?.optString("en") ?: ""
                val host  = m.optJSONObject("rdns")?.optString("rdns", "") ?: ""
                val title = m.optJSONObject("portinfo")?.optString("banner", "")?.take(80) ?: ""
                if (ip.isNotEmpty() && ip != "null") {
                    list.add(OsintResult(ip, port, host, country, title, "ZoomEye"))
                }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ── Готовые FOFA запросы для поиска камер ─────────────────────────────────
    // Синтаксис FOFA: двойные кавычки, операторы || и &&, поле="значение"
    object Queries {
        // Камеры
        const val FOFA_IPC       = """app="hikvision-camera" || app="dahua-IPC" || title="IPC" || title="IP Camera""""
        const val FOFA_HIKVISION = """app="hikvision-camera" || body="DNVRS-Webs""""
        const val FOFA_DAHUA     = """app="dahua-IPC" || body="DahuaHWP2P""""
        const val FOFA_REOLINK   = """app="Reolink-Camera""""
        const val FOFA_RTSP      = """port="554" && protocol="rtsp""""
        // Сетевое оборудование
        const val FOFA_MIKROTIK  = """app="MikroTik-RouterOS""""
        // Серверы
        const val FOFA_REDIS     = """port="6379" && protocol="redis""""
        const val FOFA_MONGO     = """port="27017" && protocol="mongodb""""
        const val FOFA_DOCKER    = """port="2375" && body="Docker""""
        const val FOFA_ELASTIC   = """port="9200" && body="cluster_name""""

        // Shodan
        const val SHODAN_IPC       = """http.title:"IPC" http.title:"IP Camera""""
        const val SHODAN_HIKVISION = """product:"Hikvision IP Camera""""
        const val SHODAN_DAHUA     = """product:"Dahua IP Camera""""
        const val SHODAN_RTSP      = """port:554 has_screenshot:true"""
        const val SHODAN_MIKROTIK  = """product:"MikroTik RouterOS""""

        // ZoomEye
        const val ZOOMEYE_IPC       = """app:"Hikvision Camera" || app:"Dahua Camera""""
        const val ZOOMEYE_HIKVISION = """app:"Hikvision Camera""""
        const val ZOOMEYE_RTSP      = """port:554"""

        // Censys
        const val CENSYS_IPC  = """services.http.response.html_title: "IPC""""
        const val CENSYS_RTSP = """services.port: 554"""
    }
}
