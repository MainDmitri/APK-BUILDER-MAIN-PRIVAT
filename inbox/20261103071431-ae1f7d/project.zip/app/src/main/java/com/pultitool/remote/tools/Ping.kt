package com.pultitool.remote.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import kotlin.math.abs

/** Один замер пинга. rttMs == null — потеря пакета. */
data class PingSample(val seq: Int, val rttMs: Double?, val ttl: Int?, val method: String, val time: Long = System.currentTimeMillis())

/** Сводная статистика по серии пингов. */
data class PingStats(
    val sent: Int,
    val received: Int,
    val min: Double,
    val avg: Double,
    val max: Double,
    val jitter: Double
) {
    val lossPercent: Double get() = if (sent == 0) 0.0 else (sent - received) * 100.0 / sent

    companion object {
        fun of(samples: List<PingSample>): PingStats {
            val ok = samples.mapNotNull { it.rttMs }
            if (ok.isEmpty()) return PingStats(samples.size, 0, 0.0, 0.0, 0.0, 0.0)
            // Джиттер — среднее абсолютное отклонение между соседними ответами (RFC 3550, упрощённо)
            val jitter = if (ok.size < 2) 0.0 else ok.zipWithNext { a, b -> abs(b - a) }.average()
            return PingStats(samples.size, ok.size, ok.min(), ok.average(), ok.max(), jitter)
        }
    }
}

data class TraceHop(val ttl: Int, val ip: String?, val host: String, val rttMs: Double?, val reached: Boolean)

object Ping {
    private val pingBin: String? by lazy {
        listOf("/system/bin/ping", "/system/xbin/ping", "/bin/ping").firstOrNull { File(it).exists() }
    }

    val icmpAvailable: Boolean get() = pingBin != null

    private val timeRe = Regex("time[=<]\\s*([0-9.]+)\\s*ms")
    private val ttlRe = Regex("ttl=(\\d+)")
    private val fromRe = Regex("[Ff]rom\\s+([0-9a-fA-F.:]+)")

    private fun run(args: List<String>, timeoutSec: Long): String? = try {
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        val out = StringBuilder()
        val reader = Thread {
            try { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } } catch (_: Exception) {}
        }
        reader.start()
        if (!p.waitFor(timeoutSec, TimeUnit.SECONDS)) p.destroy()
        reader.join(500)
        out.toString()
    } catch (_: Exception) {
        null
    }

    suspend fun resolve(host: String): InetAddress? = withContext(Dispatchers.IO) {
        try { InetAddress.getByName(host.trim()) } catch (_: Exception) { null }
    }

    /** ICMP-пинг через системную утилиту, при недоступности — TCP-«пинг» (время установки соединения). */
    suspend fun once(host: String, seq: Int, tcpPort: Int = 443, timeoutMs: Int = 2000): PingSample = withContext(Dispatchers.IO) {
        val bin = pingBin
        if (bin != null) {
            val out = run(listOf(bin, "-n", "-c", "1", "-W", ((timeoutMs + 999) / 1000).toString(), host), (timeoutMs / 1000L) + 3)
            if (out != null) {
                val t = timeRe.find(out)?.groupValues?.get(1)?.toDoubleOrNull()
                val ttl = ttlRe.find(out)?.groupValues?.get(1)?.toIntOrNull()
                if (t != null) return@withContext PingSample(seq, t, ttl, "ICMP")
                // Утилита отработала, но ответа нет — это потеря пакета
                if (out.contains("transmitted")) return@withContext PingSample(seq, null, null, "ICMP")
            }
        }
        tcp(host, seq, tcpPort, timeoutMs)
    }

    fun tcp(host: String, seq: Int, port: Int, timeoutMs: Int): PingSample {
        val start = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            PingSample(seq, (System.nanoTime() - start) / 1_000_000.0, null, "TCP:$port")
        } catch (e: java.net.ConnectException) {
            // RST от хоста — тоже ответ: хост жив, порт закрыт
            val ms = (System.nanoTime() - start) / 1_000_000.0
            if (ms < timeoutMs) PingSample(seq, ms, null, "TCP:$port") else PingSample(seq, null, null, "TCP:$port")
        } catch (_: Exception) {
            PingSample(seq, null, null, "TCP:$port")
        }
    }

    /** Трассировка: ping с растущим TTL, хост, вернувший «Time to live exceeded», — очередной узел маршрута. */
    suspend fun traceroute(host: String, maxHops: Int = 30, onHop: (TraceHop) -> Unit): Boolean = withContext(Dispatchers.IO) {
        val bin = pingBin ?: return@withContext false
        val dest = resolve(host)?.hostAddress ?: return@withContext false
        for (ttl in 1..maxHops) {
            val start = System.nanoTime()
            val out = run(listOf(bin, "-n", "-c", "1", "-W", "2", "-t", ttl.toString(), dest), 5) ?: ""
            val elapsed = (System.nanoTime() - start) / 1_000_000.0
            val reached = out.contains("bytes from") && timeRe.containsMatchIn(out)
            val ip = if (reached) dest else fromRe.find(out)?.groupValues?.get(1)?.trimEnd(':')
            var rtt: Double? = if (reached) timeRe.find(out)?.groupValues?.get(1)?.toDoubleOrNull() else null
            if (ip != null && rtt == null) {
                val again = run(listOf(bin, "-n", "-c", "1", "-W", "1", ip), 3)
                rtt = again?.let { timeRe.find(it)?.groupValues?.get(1)?.toDoubleOrNull() } ?: elapsed.takeIf { it < 2000 }
            }
            val name = if (ip != null) try {
                InetAddress.getByName(ip).canonicalHostName.takeIf { it != ip } ?: ""
            } catch (_: Exception) { "" } else ""
            onHop(TraceHop(ttl, ip, name, rtt, reached))
            if (reached) return@withContext true
        }
        true
    }
}
