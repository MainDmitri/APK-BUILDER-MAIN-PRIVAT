package com.pultitool.remote.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.data.RKey
import com.pultitool.remote.tv.ConnState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Полноэкранный жестовый пульт:
 * свайп — стрелки, касание — OK, двойное касание — Назад, долгое нажатие — Домой,
 * два пальца вверх/вниз — громкость.
 */
@Composable
fun GestureRemoteScreen(vm: AppViewModel) {
    val controller by vm.controller.collectAsState()
    val accent = LocalAccent.current
    val scope = rememberCoroutineScope()
    var feedback by remember { mutableStateOf("") }
    var ripplePos by remember { mutableStateOf(Offset.Zero) }
    val ripple = remember { Animatable(1f) }
    var pendingTap by remember { mutableStateOf<Job?>(null) }

    BackHandler { vm.back() }

    fun fire(key: RKey, label: String, at: Offset) {
        vm.press(key)
        feedback = label
        ripplePos = at
        scope.launch { ripple.snapTo(0f); ripple.animateTo(1f, tween(450)) }
    }

    val state = controller?.state?.collectAsState()
    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .pointerInput(Unit) {
                val swipe = 60.dp.toPx()
                val volStep = 48.dp.toPx()
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val start = down.position
                    val t0 = System.currentTimeMillis()
                    var maxPointers = 1
                    var last = start
                    var twoFingerAcc = 0f
                    var twoFingerPrevY: Float? = null
                    var longFired = false
                    while (true) {
                        val ev = awaitPointerEvent(PointerEventPass.Main)
                        val pressed = ev.changes.filter { it.pressed }
                        maxPointers = maxOf(maxPointers, pressed.size)
                        if (pressed.size >= 2) {
                            val y = pressed.map { it.position.y }.average().toFloat()
                            val prev = twoFingerPrevY
                            if (prev != null) {
                                twoFingerAcc += y - prev
                                while (twoFingerAcc <= -volStep) { twoFingerAcc += volStep; fire(RKey.VOL_UP, "Громкость +", pressed[0].position) }
                                while (twoFingerAcc >= volStep) { twoFingerAcc -= volStep; fire(RKey.VOL_DOWN, "Громкость −", pressed[0].position) }
                            }
                            twoFingerPrevY = y
                        } else if (pressed.size == 1) {
                            last = pressed[0].position
                        }
                        ev.changes.forEach { it.consume() }
                        if (pressed.isEmpty()) break
                    }
                    if (maxPointers >= 2) return@awaitEachGesture
                    val d = last - start
                    if (d.getDistance() < 24f && System.currentTimeMillis() - t0 > 600) longFired = true
                    if (longFired) { fire(RKey.HOME, "Домой", last); return@awaitEachGesture }
                    if (abs(d.x) > swipe || abs(d.y) > swipe) {
                        if (abs(d.x) > abs(d.y)) {
                            if (d.x > 0) fire(RKey.RIGHT, "Вправо →", last) else fire(RKey.LEFT, "← Влево", last)
                        } else {
                            if (d.y > 0) fire(RKey.DOWN, "Вниз ↓", last) else fire(RKey.UP, "↑ Вверх", last)
                        }
                    } else {
                        // Касание: ждём второе — если оно будет, это «Назад», иначе «OK»
                        val p = pendingTap
                        if (p != null && p.isActive) {
                            p.cancel(); pendingTap = null
                            fire(RKey.BACK, "Назад", last)
                        } else {
                            val at = last
                            pendingTap = scope.launch { delay(260); fire(RKey.OK, "OK", at); pendingTap = null }
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val v = ripple.value
            if (v < 1f) {
                drawCircle(accent.b.copy(alpha = (1 - v) * 0.6f), 40f + 220f * v, ripplePos, style = Stroke(6f))
                drawCircle(Brush.radialGradient(listOf(accent.a.copy(alpha = (1 - v) * 0.35f), Color.Transparent), ripplePos, 60f + 200f * v), 60f + 200f * v, ripplePos)
            }
        }
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                val st = state?.value
                StatusDot(when (st) { is ConnState.Connected -> Pal.green; is ConnState.Error -> Pal.red; null -> Pal.red; else -> Pal.yellow })
                Spacer(Modifier.padding(4.dp))
                Text(controller?.device?.name ?: "ТВ не подключён", color = Pal.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
                PadButton(size = 40.dp, onClick = { vm.back() }) { Text("✕", color = Pal.text, fontSize = 16.sp) }
            }
            Spacer(Modifier.weight(1f))
            Text(feedback, color = Pal.text, fontSize = 34.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("Свайп — стрелки", "Касание — OK · Двойное — Назад", "Удержание — Домой", "Два пальца ↑↓ — громкость").forEach {
                    Text(it, color = Pal.textDim, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}
