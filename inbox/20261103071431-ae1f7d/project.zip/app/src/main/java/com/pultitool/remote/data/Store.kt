package com.pultitool.remote.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Последний результат аудита для панели «Главная». */
data class AuditSummary(
    val score: Int,
    val time: Long,
    val hosts: Int,
    val critical: Int,
    val high: Int,
    val medium: Int,
    val low: Int
)

/** Последний результат теста скорости. */
data class SpeedSummary(val downMbps: Double, val upMbps: Double, val pingMs: Double, val time: Long)

/** Запись журнала монитора сети. */
data class MonitorEvent(val time: Long, val kind: String, val ip: String, val name: String) {
    fun toJson(): JSONObject = JSONObject().put("t", time).put("k", kind).put("ip", ip).put("n", name)

    companion object {
        const val NEW = "new"
        const val LEFT = "left"
        const val BACK = "back"
        const val INFO = "info"
        fun fromJson(o: JSONObject) = MonitorEvent(o.optLong("t"), o.optString("k"), o.optString("ip"), o.optString("n"))
    }
}

/** Хранилище устройств, настроек и статистики в SharedPreferences (JSON через org.json). */
class Store(context: Context) {
    private val prefs = context.getSharedPreferences("pulti_tool", Context.MODE_PRIVATE)

    fun loadDevices(): List<TvDevice> {
        val raw = prefs.getString("devices", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getJSONObject(it) }
                .filter { Protocol.entries.any { p -> p.name == it.optString("protocol") } }
                .map { TvDevice.fromJson(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveDevices(list: List<TvDevice>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("devices", arr.toString()).apply()
    }

    fun loadSettings(): AppSettings = AppSettings(
        vibration = prefs.getBoolean("vibration", true),
        keepScreenOn = prefs.getBoolean("keepScreenOn", false),
        volumeKeys = prefs.getBoolean("volumeKeys", true),
        accent = prefs.getInt("accent", 0),
        autoConnect = prefs.getBoolean("autoConnect", true),
        sounds = prefs.getBoolean("sounds", false),
        amoled = prefs.getBoolean("amoled", false),
        shakeMute = prefs.getBoolean("shakeMute", false),
        monitorInterval = prefs.getInt("monitorInterval", 60),
        monitorVibrate = prefs.getBoolean("monitorVibrate", true)
    )

    fun saveSettings(s: AppSettings) {
        prefs.edit()
            .putBoolean("vibration", s.vibration)
            .putBoolean("keepScreenOn", s.keepScreenOn)
            .putBoolean("volumeKeys", s.volumeKeys)
            .putInt("accent", s.accent)
            .putBoolean("autoConnect", s.autoConnect)
            .putBoolean("sounds", s.sounds)
            .putBoolean("amoled", s.amoled)
            .putBoolean("shakeMute", s.shakeMute)
            .putInt("monitorInterval", s.monitorInterval)
            .putBoolean("monitorVibrate", s.monitorVibrate)
            .apply()
    }

    var lastDeviceId: String?
        get() = prefs.getString("lastDevice", null)
        set(v) { prefs.edit().putString("lastDevice", v).apply() }

    var auditConsent: Boolean
        get() = prefs.getBoolean("auditConsent", false)
        set(v) { prefs.edit().putBoolean("auditConsent", v).apply() }

    var pressCount: Long
        get() = prefs.getLong("pressCount", 0L)
        set(v) { prefs.edit().putLong("pressCount", v).apply() }

    var pingCount: Long
        get() = prefs.getLong("pingCount", 0L)
        set(v) { prefs.edit().putLong("pingCount", v).apply() }

    var lanDevicesSeen: Int
        get() = prefs.getInt("lanSeen", 0)
        set(v) { prefs.edit().putInt("lanSeen", v).apply() }

    var auditSummary: AuditSummary?
        get() {
            val raw = prefs.getString("auditSummary", null) ?: return null
            return try {
                val o = JSONObject(raw)
                AuditSummary(o.getInt("score"), o.getLong("time"), o.optInt("hosts"), o.optInt("c"), o.optInt("h"), o.optInt("m"), o.optInt("l"))
            } catch (_: Exception) { null }
        }
        set(v) {
            if (v == null) { prefs.edit().remove("auditSummary").apply(); return }
            prefs.edit().putString("auditSummary", JSONObject().put("score", v.score).put("time", v.time).put("hosts", v.hosts)
                .put("c", v.critical).put("h", v.high).put("m", v.medium).put("l", v.low).toString()).apply()
        }

    var speedSummary: SpeedSummary?
        get() {
            val raw = prefs.getString("speedSummary", null) ?: return null
            return try {
                val o = JSONObject(raw)
                SpeedSummary(o.getDouble("d"), o.optDouble("u", 0.0), o.optDouble("p", 0.0), o.getLong("t"))
            } catch (_: Exception) { null }
        }
        set(v) {
            if (v == null) { prefs.edit().remove("speedSummary").apply(); return }
            prefs.edit().putString("speedSummary", JSONObject().put("d", v.downMbps).put("u", v.upMbps).put("p", v.pingMs).put("t", v.time).toString()).apply()
        }

    /** Известные монитору устройства: ip → имя. */
    var knownHosts: Map<String, String>
        get() {
            val raw = prefs.getString("knownHosts", null) ?: return emptyMap()
            return try {
                val o = JSONObject(raw)
                o.keys().asSequence().associateWith { o.optString(it) }
            } catch (_: Exception) { emptyMap() }
        }
        set(v) {
            val o = JSONObject()
            v.forEach { (k, n) -> o.put(k, n) }
            prefs.edit().putString("knownHosts", o.toString()).apply()
        }

    var monitorLog: List<MonitorEvent>
        get() {
            val raw = prefs.getString("monitorLog", null) ?: return emptyList()
            return try {
                val a = JSONArray(raw)
                (0 until a.length()).map { MonitorEvent.fromJson(a.getJSONObject(it)) }
            } catch (_: Exception) { emptyList() }
        }
        set(v) {
            val a = JSONArray()
            v.takeLast(300).forEach { a.put(it.toJson()) }
            prefs.edit().putString("monitorLog", a.toString()).apply()
        }

    /** Достижения: id → время получения. */
    var achievements: Map<String, Long>
        get() {
            val raw = prefs.getString("achievements", null) ?: return emptyMap()
            return try {
                val o = JSONObject(raw)
                o.keys().asSequence().associateWith { o.optLong(it) }
            } catch (_: Exception) { emptyMap() }
        }
        set(v) {
            val o = JSONObject()
            v.forEach { (k, t) -> o.put(k, t) }
            prefs.edit().putString("achievements", o.toString()).apply()
        }

    /** Счётчики для достижений. */
    fun counter(name: String): Long = prefs.getLong("cnt_$name", 0L)
    fun addCounter(name: String, delta: Long = 1): Long {
        val v = counter(name) + delta
        prefs.edit().putLong("cnt_$name", v).apply()
        return v
    }
}
