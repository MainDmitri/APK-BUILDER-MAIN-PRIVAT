package com.pultitool.remote.tv

import android.content.Context
import android.util.Base64
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

/** Samsung Tizen (2016+): WebSocket ws://ip:8001 или wss://ip:8002 (с токеном). */
class SamsungController(context: Context, d: TvDevice) : TvController(context, d) {
    private var ws: WebSocket? = null
    @Volatile private var closedByUser = false
    @Volatile private var triedSecure = false

    override val supportsTouchpad = true

    fun keyName(k: RKey): String = when (k) {
        RKey.POWER -> "KEY_POWER"; RKey.UP -> "KEY_UP"; RKey.DOWN -> "KEY_DOWN"; RKey.LEFT -> "KEY_LEFT"
        RKey.RIGHT -> "KEY_RIGHT"; RKey.OK -> "KEY_ENTER"; RKey.BACK -> "KEY_RETURN"; RKey.HOME -> "KEY_HOME"
        RKey.MENU -> "KEY_MENU"; RKey.VOL_UP -> "KEY_VOLUP"; RKey.VOL_DOWN -> "KEY_VOLDOWN"; RKey.MUTE -> "KEY_MUTE"
        RKey.CH_UP -> "KEY_CHUP"; RKey.CH_DOWN -> "KEY_CHDOWN"
        RKey.D0 -> "KEY_0"; RKey.D1 -> "KEY_1"; RKey.D2 -> "KEY_2"; RKey.D3 -> "KEY_3"; RKey.D4 -> "KEY_4"
        RKey.D5 -> "KEY_5"; RKey.D6 -> "KEY_6"; RKey.D7 -> "KEY_7"; RKey.D8 -> "KEY_8"; RKey.D9 -> "KEY_9"
        RKey.PLAY_PAUSE -> "KEY_PLAY"; RKey.PLAY -> "KEY_PLAY"; RKey.PAUSE -> "KEY_PAUSE"; RKey.STOP -> "KEY_STOP"
        RKey.REWIND -> "KEY_REWIND"; RKey.FAST_FORWARD -> "KEY_FF"; RKey.PREV -> "KEY_REWIND"; RKey.NEXT -> "KEY_FF"
        RKey.INPUT -> "KEY_SOURCE"; RKey.INFO -> "KEY_INFO"; RKey.SETTINGS -> "KEY_MENU"; RKey.EXIT -> "KEY_EXIT"
        RKey.GUIDE -> "KEY_GUIDE"; RKey.SEARCH -> "KEY_SEARCH"
        RKey.RED -> "KEY_RED"; RKey.GREEN -> "KEY_GREEN"; RKey.YELLOW -> "KEY_YELLOW"; RKey.BLUE -> "KEY_CYAN"
        RKey.DEL -> "KEY_BACKSPACE"; RKey.ENTER -> "KEY_ENTER"
    }

    override fun builtinApps() = listOf(
        AppShortcut("YouTube", "111299001912", AppColors.YOUTUBE),
        AppShortcut("Netflix", "3201907018807", AppColors.NETFLIX),
        AppShortcut("Prime Video", "3201910019365", AppColors.PRIME),
        AppShortcut("Spotify", "3201606009684", AppColors.SPOTIFY),
        AppShortcut("Disney+", "3201901017640", AppColors.DISNEY),
        AppShortcut("Twitch", "3202203026841", AppColors.TWITCH),
        AppShortcut("Plex", "3201512006963", AppColors.PLEX),
        AppShortcut("Браузер", "org.tizen.browser", AppColors.BROWSER)
    )

    private fun url(secure: Boolean): String {
        val name = Base64.encodeToString("Пульт Тул".toByteArray(), Base64.NO_WRAP)
        val base = if (secure) "wss://${device.ip}:8002" else "ws://${device.ip}:8001"
        val tok = if (secure && device.token.isNotEmpty()) "&token=${device.token}" else ""
        return "$base/api/v2/channels/samsung.remote.control?name=$name$tok"
    }

    override suspend fun connect() = withContext(Dispatchers.IO) {
        closedByUser = false
        ws?.cancel()
        // Модели 2018+ требуют wss:8002; старые — ws:8001
        val secure = NetUtil.isPortOpen(device.ip, 8002, 1200)
        triedSecure = secure
        if (!secure && !NetUtil.isPortOpen(device.ip, 8001, 1200)) {
            _state.value = ConnState.Error("Samsung недоступен (порты 8001/8002 закрыты). Включите ТВ")
            return@withContext
        }
        open(secure)
    }

    private fun open(secure: Boolean) {
        _state.value = ConnState.WaitTv("Разрешите подключение «Пульт Тул» на экране телевизора")
        val req = Request.Builder().url(url(secure)).build()
        ws = NetUtil.ws.newWebSocket(req, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    when (o.optString("event")) {
                        "ms.channel.connect" -> {
                            val token = o.optJSONObject("data")?.optString("token").orEmpty()
                            if (token.isNotEmpty() && token != device.token) updateDevice(device.copy(token = token, paired = true))
                            else if (!device.paired) updateDevice(device.copy(paired = true))
                            _state.value = ConnState.Connected(if (secure) "Защищённое соединение" else "Подключено")
                        }
                        "ms.channel.unauthorized" -> _state.value = ConnState.Error("Доступ запрещён на ТВ. Разрешите устройство в настройках «Внешние устройства»")
                        "ms.channel.timeOut" -> _state.value = ConnState.Error("Время подтверждения на ТВ истекло")
                    }
                } catch (_: Exception) {
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (closedByUser || ws !== webSocket) return
                _state.value = ConnState.Error("Samsung: ${t.message ?: "ошибка соединения"}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!closedByUser && ws === webSocket) _state.value = ConnState.Error("Соединение закрыто ТВ")
            }
        })
    }

    override fun disconnect() {
        closedByUser = true
        ws?.close(1000, null)
        ws = null
        _state.value = ConnState.Idle
    }

    private fun send(o: JSONObject) {
        val s = ws
        if (s == null || !s.send(o.toString())) _state.value = ConnState.Error("Нет соединения с Samsung")
    }

    private fun keyMsg(key: String, cmd: String) = JSONObject()
        .put("method", "ms.remote.control")
        .put("params", JSONObject().put("Cmd", cmd).put("DataOfCmd", key).put("Option", "false").put("TypeOfRemote", "SendRemoteKey"))

    override suspend fun sendKey(key: RKey, longPress: Boolean) {
        val k = keyName(key)
        if (longPress) {
            send(keyMsg(k, "Press")); delay(700); send(keyMsg(k, "Release"))
        } else send(keyMsg(k, "Click"))
    }

    override suspend fun sendText(text: String) {
        val b64 = Base64.encodeToString(text.toByteArray(), Base64.NO_WRAP)
        send(JSONObject().put("method", "ms.remote.control").put("params",
            JSONObject().put("Cmd", b64).put("DataOfCmd", "base64").put("TypeOfRemote", "SendInputString")))
        send(JSONObject().put("method", "ms.remote.control").put("params", JSONObject().put("TypeOfRemote", "SendInputEnd")))
    }

    override suspend fun launchApp(app: AppShortcut) {
        send(JSONObject().put("method", "ms.channel.emit").put("params", JSONObject()
            .put("event", "ed.apps.launch").put("to", "host")
            .put("data", JSONObject().put("appId", app.id).put("action_type", if (app.id.contains('.')) "NATIVE_LAUNCH" else "DEEP_LINK"))))
        withContext(Dispatchers.IO) {
            NetUtil.post("http://${device.ip}:8001/api/v2/applications/${app.id}", "", "application/json")
        }
    }

    override val supportsUrl = true
    override val supportsYouTube = true

    private fun runApp(appId: String, type: String, meta: String) {
        send(JSONObject().put("method", "ms.channel.emit").put("params", JSONObject()
            .put("event", "ed.apps.launch").put("to", "host")
            .put("data", JSONObject().put("appId", appId).put("action_type", type).put("metaTag", meta))))
    }

    override suspend fun openUrl(url: String): Boolean {
        runApp("org.tizen.browser", "NATIVE_LAUNCH", url); return ws != null
    }

    override suspend fun openYouTube(videoId: String): Boolean {
        runApp("111299001912", "DEEP_LINK", "v=$videoId"); return ws != null
    }

    override suspend fun moveCursor(dx: Int, dy: Int) {
        send(JSONObject().put("method", "ms.remote.control").put("params", JSONObject()
            .put("Cmd", "Move").put("Position", JSONObject().put("x", dx).put("y", dy).put("Time", System.currentTimeMillis().toString()))
            .put("TypeOfRemote", "ProcessMouseDevice")))
    }

    override suspend fun click() {
        send(JSONObject().put("method", "ms.remote.control").put("params", JSONObject()
            .put("Cmd", "LeftClick").put("TypeOfRemote", "ProcessMouseDevice")))
    }
}
