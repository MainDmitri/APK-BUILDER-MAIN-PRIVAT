package com.pultitool.remote.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.data.MonitorEvent

@Composable
fun MonitorScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.monitor.collectAsState()
    val settings by vm.settings.collectAsState()
    val accent = LocalAccent.current
    val inf = rememberInfiniteTransition(label = "radar")
    val sweep by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "sweep")

    ToolScaffold("Монитор сети", "Оповещение о новых устройствах в вашей сети", onBack = { vm.back() }) {
        Row(Modifier.fillMaxWidth().glass().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(96.dp)) {
                    val c = Offset(size.width / 2, size.height / 2)
                    listOf(0.33f, 0.66f, 1f).forEach { drawCircle(Color(0x33FFFFFF), size.width / 2 * it, c, style = Stroke(1.5f)) }
                    if (st.enabled) rotate(sweep) {
                        drawArc(Brush.sweepGradient(listOf(Color.Transparent, accent.b.copy(alpha = 0.7f)), c), -60f, 60f, true)
                    }
                    st.online.take(24).forEachIndexed { i, h ->
                        val a = Math.toRadians((h.ip.substringAfterLast('.').toIntOrNull() ?: i) * 137.5)
                        val rr = size.width / 2 * (0.35f + 0.55f * ((i * 37) % 10) / 10f)
                        drawCircle(Pal.green, 3.5f, Offset(c.x + rr * kotlin.math.cos(a).toFloat(), c.y + rr * kotlin.math.sin(a).toFloat()))
                    }
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(if (st.enabled) (if (st.scanning) "Сканирую сеть…" else "Наблюдение активно") else "Монитор выключен",
                    color = if (st.enabled) Pal.green else Pal.textDim, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (st.enabled && !st.scanning && st.nextCheckIn > 0) Text("Следующая проверка через ${st.nextCheckIn} с", color = Pal.textDim, fontSize = 12.sp)
                if (st.lastCheck > 0) Text("Онлайн: ${st.online.size} · известно: ${st.known}", color = Pal.textDim, fontSize = 12.sp)
                if (st.lastCheck > 0) Text("Проверено: ${fmtTime(st.lastCheck, "HH:mm:ss")}", color = Pal.textDim, fontSize = 12.sp)
            }
        }
        if (st.enabled) GhostButton("Остановить монитор", Modifier.fillMaxWidth()) { tools.setMonitor(false) }
        else GradientButton("Включить монитор", Modifier.fillMaxWidth(), Glyph.EYE) { tools.setMonitor(true) }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Интервал проверки: ${settings.monitorInterval} с", color = Pal.textDim, fontSize = 12.sp)
            Slider(settings.monitorInterval.toFloat(), { vm.updateSettings(settings.copy(monitorInterval = (it / 15).toInt() * 15)) }, valueRange = 15f..600f)
            ToggleRow("Вибрация при новом устройстве", settings.monitorVibrate) { vm.updateSettings(settings.copy(monitorVibrate = it)) }
            Text("Монитор работает, пока приложение открыто или свёрнуто недавно. Первый запуск запоминает текущие устройства как «свои».",
                color = Pal.textDim, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton("Забыть известные", Modifier.weight(1f)) { tools.forgetKnown() }
            GhostButton("Очистить журнал", Modifier.weight(1f)) { tools.clearMonitorLog() }
        }
        SectionTitle("Журнал (${st.log.size})")
        if (st.log.isEmpty()) Text("Событий пока нет", color = Pal.textDim, fontSize = 13.sp)
        st.log.reversed().take(100).forEach { e ->
            val (icon, color, title) = when (e.kind) {
                MonitorEvent.NEW -> Triple("🆕", Pal.yellow, "Новое устройство")
                MonitorEvent.LEFT -> Triple("⬇", Pal.textDim, "Отключилось")
                MonitorEvent.BACK -> Triple("⬆", Pal.green, "Вернулось")
                else -> Triple("ℹ", accent.b, "")
            }
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 18.sp); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (title.isNotEmpty()) "$title: ${e.name}" else e.name, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    if (e.ip.isNotEmpty()) Text(e.ip, color = Pal.textDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Text(fmtTime(e.time, "dd.MM HH:mm:ss"), color = Pal.textDim, fontSize = 10.sp)
            }
        }
    }
}
