package com.pultitool.remote

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.pultitool.remote.data.RKey
import com.pultitool.remote.ui.PultApp
import com.pultitool.remote.util.ShakeDetector
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private val tools: NetToolsViewModel by viewModels()
    private var shake: ShakeDetector? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { PultApp(vm, tools) }
        handleShare(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    vm.settings.collect { s ->
                        if (s.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                }
                launch {
                    vm.toast.collect { Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show() }
                }
                launch {
                    // Полноэкранный режим без системных панелей на жестовом пульте.
                    vm.screen.collect { applyImmersive(it == Screen.GESTURE) }
                }
            }
        }
        lifecycleScope.launch { vm.prewarmCert() }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    /** Ссылка, пришедшая из «Поделиться» (YouTube, браузер и т.д.), открывает пульт. */
    private fun handleShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND || intent.type != "text/plain") return
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
        val url = Regex("https?://\\S+").find(text)?.value ?: text
        if (url.isNotBlank()) {
            vm.setSharedUrl(url)
            vm.navigate(Screen.REMOTE)
        }
    }

    private fun applyImmersive(on: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (on) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onResume() {
        super.onResume()
        if (vm.settings.value.shakeMute) {
            if (shake == null) shake = ShakeDetector(this) { vm.shakeMute() }
            shake?.start()
        }
    }

    override fun onPause() {
        super.onPause()
        shake?.stop()
    }

    private fun volumeKeysActive(): Boolean =
        vm.settings.value.volumeKeys && vm.screen.value == Screen.REMOTE && vm.controller.value != null

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeKeysActive()) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> { vm.press(RKey.VOL_UP); return true }
                KeyEvent.KEYCODE_VOLUME_DOWN -> { vm.press(RKey.VOL_DOWN); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (volumeKeysActive() && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) return true
        return super.onKeyUp(keyCode, event)
    }
}
