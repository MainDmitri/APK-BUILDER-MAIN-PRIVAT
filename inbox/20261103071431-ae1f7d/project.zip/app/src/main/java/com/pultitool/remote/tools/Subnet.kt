package com.pultitool.remote.tools

data class SubnetInfo(
    val ip: String,
    val prefix: Int,
    val mask: String,
    val wildcard: String,
    val network: String,
    val broadcast: String,
    val firstHost: String,
    val lastHost: String,
    val hosts: Long,
    val ipClass: String,
    val scope: String,
    val binIp: String,
    val binMask: String,
    val hex: String,
    val subnets: List<String>
)

object Subnet {
    fun ipToLong(ip: String): Long {
        val p = ip.trim().split('.')
        require(p.size == 4) { "Неверный IPv4: $ip" }
        return p.fold(0L) { acc, s ->
            val v = s.toIntOrNull() ?: throw IllegalArgumentException("Неверный IPv4: $ip")
            require(v in 0..255) { "Октет вне диапазона: $v" }
            (acc shl 8) or v.toLong()
        }
    }

    fun longToIp(v: Long): String = "${(v shr 24) and 255}.${(v shr 16) and 255}.${(v shr 8) and 255}.${v and 255}"

    private fun bin(v: Long): String = (0..3).joinToString(".") { i -> ((v shr (24 - 8 * i)) and 255).toString(2).padStart(8, '0') }

    fun maskToPrefix(mask: String): Int {
        val m = ipToLong(mask)
        val prefix = java.lang.Long.bitCount(m)
        require(m == prefixMask(prefix)) { "Маска не непрерывна: $mask" }
        return prefix
    }

    fun prefixMask(prefix: Int): Long = if (prefix == 0) 0L else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL

    /** Ввод: "192.168.1.10/24", "192.168.1.10 255.255.255.0" или "192.168.1.10" + отдельный префикс. */
    fun calc(input: String, splitPrefix: Int? = null): SubnetInfo {
        val s = input.trim()
        val (ipStr, prefix) = when {
            '/' in s -> s.substringBefore('/').trim() to (s.substringAfter('/').trim().let { t -> if ('.' in t) maskToPrefix(t) else t.toIntOrNull() ?: throw IllegalArgumentException("Неверный префикс") })
            ' ' in s -> s.substringBefore(' ').trim() to maskToPrefix(s.substringAfter(' ').trim())
            else -> s to 24
        }
        require(prefix in 0..32) { "Префикс должен быть от 0 до 32" }
        val ip = ipToLong(ipStr)
        val mask = prefixMask(prefix)
        val net = ip and mask
        val bc = net or (mask.inv() and 0xFFFFFFFFL)
        val hosts = when (prefix) { 32 -> 1L; 31 -> 2L; else -> (bc - net - 1) }
        val first = if (prefix >= 31) net else net + 1
        val last = if (prefix >= 31) bc else bc - 1
        val o1 = (ip shr 24).toInt()
        val cls = when { o1 < 128 -> "A"; o1 < 192 -> "B"; o1 < 224 -> "C"; o1 < 240 -> "D (multicast)"; else -> "E (резерв)" }
        val o2 = ((ip shr 16) and 255).toInt()
        val scope = when {
            o1 == 10 || (o1 == 172 && o2 in 16..31) || (o1 == 192 && o2 == 168) -> "Частная (RFC 1918)"
            o1 == 100 && o2 in 64..127 -> "CGNAT (RFC 6598) — адрес оператора"
            o1 == 127 -> "Loopback"
            o1 == 169 && o2 == 254 -> "Link-local (APIPA)"
            o1 in 224..239 -> "Multicast"
            o1 >= 240 -> "Зарезервирована"
            else -> "Публичная"
        }
        val subs = mutableListOf<String>()
        if (splitPrefix != null && splitPrefix in (prefix + 1)..32) {
            val size = 1L shl (32 - splitPrefix)
            var n = net
            while (n <= bc && subs.size < 64) { subs += "${longToIp(n)}/$splitPrefix  (${longToIp(n)} – ${longToIp(n + size - 1)})"; n += size }
        }
        return SubnetInfo(
            longToIp(ip), prefix, longToIp(mask), longToIp(mask.inv() and 0xFFFFFFFFL), longToIp(net), longToIp(bc),
            longToIp(first), longToIp(last), hosts, cls, scope, bin(ip), bin(mask), "0x%08X".format(ip), subs
        )
    }
}
