package com.pultitool.remote.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs

enum class SpeedPhase(val title: String) { IDLE("Готов"), PING("Задержка"), DOWNLOAD("Загрузка"), UPLOAD("Отдача"), DONE("Готово"), ERROR("Ошибка") }

data class LatencyResult(val target: String, val avgMs: Double, val minMs: Double, val jitterMs: Double, val lost: Int)

data class SpeedState(
    val phase: SpeedPhase = SpeedPhase.IDLE,
    val currentMbps: Double = 0.0,
    val downMbps: Double = 0.0,
    val upMbps: Double = 0.0,
    val latency: List<LatencyResult> = emptyList(),
    val progress: Float = 0f,
    val downSeries: List<Float> = emptyList(),
    val upSeries: List<Float> = emptyList(),
    val bytesDown: Long = 0,
    val bytesUp: Long = 0,
    val server: String = "",
    val error: String? = null
) {
    val pingMs: Double get() = latency.filter { it.lost < 5 }.minOfOrNull { it.avgMs } ?: 0.0
}

/** Тест скорости по speed.cloudflare.com: несколько параллельных потоков, замер каждые 200 мс. */
object SpeedTest {
    private const val BASE = "https://speed.cloudflare.com"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    private suspend fun latency(target: String, port: Int): LatencyResult {
        val samples = mutableListOf<Double>()
        var lost = 0
        repeat(5) { i ->
            val s = Ping.tcp(target, i, port, 1500)
            if (s.rttMs != null) samples += s.rttMs else lost++
            delay(120)
        }
        if (samples.isEmpty()) return LatencyResult(target, 0.0, 0.0, 0.0, lost)
        // Первое соединение часто медленнее (ARP/NAT), поэтому min — главная метрика, avg — для справки
        val jitter = if (samples.size < 2) 0.0 else samples.zipWithNext { a, b -> abs(a - b) }.average()
        return LatencyResult(target, samples.average(), samples.min(), jitter, lost)
    }

    suspend fun run(durationSec: Int = 10, streams: Int = 4, onUpdate: (SpeedState) -> Unit): SpeedState = withContext(Dispatchers.IO) {
        var st = SpeedState(phase = SpeedPhase.PING)
        onUpdate(st)
        try {
            // 1. Задержка до 1.1.1.1 и 8.8.8.8 (TCP 443 и 53)
            val lat = listOf(latency("1.1.1.1", 443), latency("8.8.8.8", 443), latency("speed.cloudflare.com", 443))
            var colo = ""
            try {
                val trace = Internet.getText("$BASE/cdn-cgi/trace")
                colo = trace.lines().firstOrNull { it.startsWith("colo=") }?.substringAfter('=') ?: ""
            } catch (_: Exception) {
            }
            st = st.copy(latency = lat, server = if (colo.isNotEmpty()) "Cloudflare · $colo" else "Cloudflare")
            onUpdate(st)

            // 2. Загрузка
            st = st.copy(phase = SpeedPhase.DOWNLOAD, progress = 0f)
            onUpdate(st)
            val down = measure(durationSec, { counter, deadline -> downloadWorker(counter, deadline) }, streams) { mbps, prog, series, bytes ->
                st = st.copy(currentMbps = mbps, progress = prog, downSeries = series, bytesDown = bytes)
                onUpdate(st)
            }
            st = st.copy(downMbps = down, currentMbps = down)
            onUpdate(st)

            // 3. Отдача
            st = st.copy(phase = SpeedPhase.UPLOAD, progress = 0f, currentMbps = 0.0)
            onUpdate(st)
            val up = measure((durationSec * 0.8).toInt().coerceAtLeast(5), { counter, deadline -> uploadWorker(counter, deadline) }, streams.coerceAtMost(3)) { mbps, prog, series, bytes ->
                st = st.copy(currentMbps = mbps, progress = prog, upSeries = series, bytesUp = bytes)
                onUpdate(st)
            }
            st = st.copy(phase = SpeedPhase.DONE, upMbps = up, currentMbps = st.downMbps, progress = 1f)
            onUpdate(st)
            st
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            st = st.copy(phase = SpeedPhase.ERROR, error = e.message ?: e.javaClass.simpleName)
            onUpdate(st)
            st
        }
    }

    /** Запуск потоков и выборка скорости. Итог — медиана последних 70 % выборок (отбрасываем «разгон» TCP). */
    private suspend fun measure(
        durationSec: Int,
        worker: suspend (AtomicLong, Long) -> Unit,
        streams: Int,
        onSample: (Double, Float, List<Float>, Long) -> Unit
    ): Double = coroutineScope {
        val counter = AtomicLong(0)
        val start = System.nanoTime()
        val deadline = start + durationSec * 1_000_000_000L
        val jobs = (0 until streams).map { async(Dispatchers.IO) { try { worker(counter, deadline) } catch (_: Exception) {} } }
        val samples = mutableListOf<Double>()
        val sampler = launch {
            var lastBytes = 0L
            var lastT = System.nanoTime()
            while (isActive && System.nanoTime() < deadline) {
                delay(200)
                val now = System.nanoTime()
                val b = counter.get()
                val mbps = (b - lastBytes) * 8.0 / ((now - lastT) / 1e9) / 1e6
                lastBytes = b; lastT = now
                samples += mbps
                // Сглаживание для стрелки спидометра
                val shown = samples.takeLast(5).average()
                onSample(shown, ((now - start).toFloat() / (deadline - start)).coerceIn(0f, 1f), samples.map { it.toFloat() }, b)
            }
        }
        jobs.awaitAll()
        sampler.cancel()
        if (counter.get() == 0L) throw IllegalStateException("Нет данных — проверьте подключение к Интернету")
        val tail = samples.drop((samples.size * 0.3).toInt()).sorted()
        if (tail.isEmpty()) counter.get() * 8.0 / durationSec / 1e6 else tail[tail.size / 2]
    }

    private suspend fun downloadWorker(counter: AtomicLong, deadline: Long) {
        val buf = ByteArray(64 * 1024)
        while (System.nanoTime() < deadline) {
            kotlin.coroutines.coroutineContext.ensureActive()
            val req = Request.Builder().url("$BASE/__down?bytes=25000000").header("User-Agent", "PultTool/1.0").build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                val ins = r.body?.byteStream() ?: return
                while (System.nanoTime() < deadline) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    counter.addAndGet(n.toLong())
                }
            }
        }
    }

    private suspend fun uploadWorker(counter: AtomicLong, deadline: Long) {
        val chunk = ByteArray(64 * 1024) { (it * 31).toByte() }
        val total = 8L * 1024 * 1024
        while (System.nanoTime() < deadline) {
            kotlin.coroutines.coroutineContext.ensureActive()
            val body = object : RequestBody() {
                override fun contentType() = "application/octet-stream".toMediaType()
                override fun contentLength() = total
                override fun writeTo(sink: BufferedSink) {
                    var sent = 0L
                    while (sent < total) {
                        if (System.nanoTime() >= deadline) throw java.io.IOException("time")
                        val n = minOf(chunk.size.toLong(), total - sent).toInt()
                        sink.write(chunk, 0, n)
                        sink.flush()
                        sent += n
                        counter.addAndGet(n.toLong())
                    }
                }
            }
            try {
                client.newCall(Request.Builder().url("$BASE/__up").post(body).build()).execute().close()
            } catch (_: java.io.IOException) {
                if (System.nanoTime() < deadline) delay(100)
            }
        }
    }
}
