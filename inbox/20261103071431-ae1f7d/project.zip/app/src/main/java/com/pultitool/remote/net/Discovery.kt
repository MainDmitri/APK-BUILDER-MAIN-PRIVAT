package com.pultitool.remote.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.pultitool.remote.data.FoundDevice
import com.pultitool.remote.data.Protocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.MulticastSocket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicInteger

data class SsdpHit(val ip: String, val location: String?, val server: String, val st: String, val usn: String)

/** Поиск телевизоров: SSDP + mDNS (NsdManager) + проба TCP-портов по подсети /24. */
class Discovery(private val context: Context) {

    companion object {
        val TV_PORTS = intArrayOf(6466, 6467, 8001, 8002, 3000, 3001, 8060, 1925, 1926, 8008, 8009, 80)

        fun withMulticast(context: Context, block: () -> Unit) {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val lock = wm?.createMulticastLock("pultitool-discovery")
            try {
                lock?.setReferenceCounted(false)
                lock?.acquire()
            } catch (_: Exception) {
            }
            try {
                block()
            } finally {
                try { lock?.release() } catch (_: Exception) {}
            }
        }

        /** SSDP M-SEARCH: возвращает ответы устройств за timeoutMs. */
        fun ssdp(context: Context, timeoutMs: Int = 3500, sts: List<String> = listOf(
            "ssdp:all",
            "roku:ecp",
            "urn:dial-multiscreen-org:service:dial:1",
            "urn:samsung.com:device:RemoteControlReceiver:1",
            "urn:lge-com:service:webos-second-screen:1",
            "urn:schemas-sony-com:service:IRCC:1",
            "urn:schemas-upnp-org:device:MediaRenderer:1"
        )): List<SsdpHit> {
            val hits = ConcurrentHashMap<String, SsdpHit>()
            withMulticast(context) {
                try {
                    MulticastSocket(null).use { sock ->
                        sock.reuseAddress = true
                        sock.bind(java.net.InetSocketAddress(0))
                        sock.timeToLive = 4
                        sock.soTimeout = 400
                        val group = InetAddress.getByName("239.255.255.250")
                        repeat(2) {
                            for (st in sts) {
                                val msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: $st\r\nUSER-AGENT: Android/1 UPnP/1.1 PultTool/1.0\r\n\r\n"
                                val b = msg.toByteArray()
                                try { sock.send(DatagramPacket(b, b.size, group, 1900)) } catch (_: Exception) {}
                            }
                        }
                        val end = System.currentTimeMillis() + timeoutMs
                        val buf = ByteArray(4096)
                        while (System.currentTimeMillis() < end) {
                            try {
                                val p = DatagramPacket(buf, buf.size)
                                sock.receive(p)
                                val ip = p.address.hostAddress ?: continue
                                val text = String(p.data, 0, p.length)
                                val h = text.split("\r\n").mapNotNull { line ->
                                    val i = line.indexOf(':'); if (i > 0) line.substring(0, i).trim().lowercase() to line.substring(i + 1).trim() else null
                                }.toMap()
                                val key = ip + "|" + (h["st"] ?: h["nt"] ?: "")
                                hits[key] = SsdpHit(ip, h["location"], h["server"] ?: "", h["st"] ?: h["nt"] ?: "", h["usn"] ?: "")
                            } catch (_: SocketTimeoutException) {
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
            return hits.values.toList()
        }
    }

    data class Progress(val done: Int, val total: Int, val stage: String)

    /** mDNS через NsdManager: возвращает ip -> (тип сервиса, имя). */
    private suspend fun nsd(types: List<String>, durationMs: Long): Map<String, Pair<String, String>> = withContext(Dispatchers.IO) {
        val nsd = context.getSystemService(Context.NSD_SERVICE) as? NsdManager ?: return@withContext emptyMap()
        val result = ConcurrentHashMap<String, Pair<String, String>>()
        val toResolve = LinkedBlockingQueue<NsdServiceInfo>()
        val listeners = mutableListOf<NsdManager.DiscoveryListener>()
        withMulticast(context) {
            for (type in types) {
                val l = object : NsdManager.DiscoveryListener {
                    override fun onDiscoveryStarted(serviceType: String) {}
                    override fun onDiscoveryStopped(serviceType: String) {}
                    override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
                    override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
                    override fun onServiceFound(info: NsdServiceInfo) { toResolve.offer(info) }
                    override fun onServiceLost(info: NsdServiceInfo) {}
                }
                try {
                    nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l)
                    listeners.add(l)
                } catch (_: Exception) {
                }
            }
            val end = System.currentTimeMillis() + durationMs
            // Разрешаем сервисы по одному (старые версии Android не позволяют параллельный resolve)
            while (System.currentTimeMillis() < end) {
                val info = toResolve.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) ?: continue
                val lock = Object()
                var done = false
                try {
                    @Suppress("DEPRECATION")
                    nsd.resolveService(info, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(si: NsdServiceInfo, errorCode: Int) {
                            synchronized(lock) { done = true; lock.notifyAll() }
                        }

                        override fun onServiceResolved(si: NsdServiceInfo) {
                            @Suppress("DEPRECATION")
                            val ip = si.host?.hostAddress
                            if (ip != null && !ip.contains(':')) {
                                var name = si.serviceName ?: ""
                                try {
                                    val fn = si.attributes["fn"]
                                    if (fn != null) name = String(fn)
                                } catch (_: Exception) {
                                }
                                val type = si.serviceType ?: ""
                                val prev = result[ip]
                                if (prev == null || type.contains("androidtvremote")) result[ip] = type to name
                            }
                            synchronized(lock) { done = true; lock.notifyAll() }
                        }
                    })
                    synchronized(lock) { if (!done) lock.wait(2500) }
                } catch (_: Exception) {
                }
            }
            for (l in listeners) try { nsd.stopServiceDiscovery(l) } catch (_: Exception) {}
        }
        result
    }

    /** Полное сканирование. onFound вызывается при каждом обнаружении/уточнении. */
    suspend fun scan(onProgress: (Progress) -> Unit, onFound: (FoundDevice) -> Unit) = coroutineScope {
        val found = ConcurrentHashMap<String, FoundDevice>()
        fun publish(d: FoundDevice) {
            val prev = found[d.ip]
            val merged = if (prev == null) d else {
                val better = if (priority(d.protocol) > priority(prev.protocol)) d else prev
                better.copy(
                    name = listOf(d.name, prev.name).firstOrNull { it.isNotBlank() && !it.startsWith("Устройство") } ?: better.name,
                    model = better.model.ifEmpty { if (better === d) prev.model else d.model },
                    mac = better.mac.ifEmpty { if (better === d) prev.mac else d.mac },
                    ports = (prev.ports + d.ports).distinct().sorted(),
                    source = (prev.source.split(", ") + d.source.split(", ")).filter { it.isNotBlank() }.distinct().joinToString(", ")
                )
            }
            found[d.ip] = merged
            onFound(merged)
        }

        onProgress(Progress(0, 100, "Поиск по SSDP и mDNS…"))
        val ssdpJob = async(Dispatchers.IO) { ssdp(context) }
        val nsdJob = async(Dispatchers.IO) { nsd(listOf("_androidtvremote2._tcp.", "_googlecast._tcp.", "_airplay._tcp."), 5000) }

        val net = NetUtil.localNet(context)
        val portJob = launch(Dispatchers.IO) {
            if (net == null) return@launch
            val base = net.base24
            val hosts = (1..254).map { "$base$it" }.filter { it != net.ip }
            val total = hosts.size
            val counter = AtomicInteger(0)
            val sem = Semaphore(48)
            hosts.map { ip ->
                async {
                    sem.withPermit {
                        val open = TV_PORTS.filter { p -> NetUtil.isPortOpen(ip, p, 300) }
                        val n = counter.incrementAndGet()
                        if (n % 4 == 0 || n == total) onProgress(Progress(n, total, "Проверено адресов: $n из $total"))
                        val proto = protocolFromPorts(open)
                        if (proto != null) publish(identify(ip, proto, open))
                    }
                }
            }.awaitAll()
        }

        for (hit in ssdpJob.await()) {
            val proto = protocolFromSsdp(hit) ?: continue
            launch(Dispatchers.IO) {
                var name = ""
                var model = ""
                var brand = brandOf(proto)
                hit.location?.let { loc ->
                    NetUtil.get(loc)?.let { r ->
                        name = NetUtil.xmlTag(r.body, "friendlyName") ?: ""
                        model = NetUtil.xmlTag(r.body, "modelName") ?: ""
                        NetUtil.xmlTag(r.body, "manufacturer")?.let { brand = it }
                    }
                }
                publish(FoundDevice(hit.ip, name.ifEmpty { "Устройство ${hit.ip}" }, proto, brand, model, source = "SSDP"))
            }
        }
        for ((ip, v) in nsdJob.await()) {
            val proto = Protocol.ANDROID_TV
            val label = when {
                v.first.contains("androidtvremote") -> "Android TV"
                v.first.contains("googlecast") -> "Google Cast"
                else -> "AirPlay"
            }
            if (label == "AirPlay" && found[ip] == null) continue
            publish(FoundDevice(ip, v.second.ifEmpty { label }, proto, if (label == "AirPlay") "" else "Google", source = "mDNS $label"))
        }
        portJob.join()
        onProgress(Progress(100, 100, "Готово"))
    }

    private fun priority(p: Protocol) = when (p) {
        Protocol.ANDROID_TV -> 6; Protocol.SAMSUNG -> 5; Protocol.LG -> 5; Protocol.ROKU -> 5
        Protocol.PHILIPS -> 3; Protocol.SONY -> 2
    }

    private fun brandOf(p: Protocol) = when (p) {
        Protocol.ANDROID_TV -> "Android TV"; Protocol.SAMSUNG -> "Samsung"; Protocol.LG -> "LG"
        Protocol.ROKU -> "Roku"; Protocol.PHILIPS -> "Philips"; Protocol.SONY -> "Sony"
    }

    fun protocolFromPorts(open: List<Int>): Protocol? = when {
        6466 in open || 6467 in open -> Protocol.ANDROID_TV
        8001 in open || 8002 in open -> Protocol.SAMSUNG
        3000 in open || 3001 in open -> Protocol.LG
        8060 in open -> Protocol.ROKU
        1925 in open || 1926 in open -> Protocol.PHILIPS
        8008 in open && 8009 in open -> Protocol.ANDROID_TV
        else -> null
    }

    private fun protocolFromSsdp(h: SsdpHit): Protocol? {
        val s = (h.server + " " + h.st + " " + h.usn).lowercase()
        return when {
            "roku" in s -> Protocol.ROKU
            "samsung" in s || "tizen" in s -> Protocol.SAMSUNG
            "webos" in s || "lge" in s -> Protocol.LG
            "sony" in s && ("ircc" in s || "bravia" in s) -> Protocol.SONY
            "philips" in s || "jointspace" in s -> Protocol.PHILIPS
            else -> null
        }
    }

    /** Уточняем имя/модель/MAC через HTTP API конкретной платформы. */
    fun identify(ip: String, proto: Protocol, open: List<Int>): FoundDevice {
        var name = ""
        var model = ""
        var mac = ""
        var brand = brandOf(proto)
        try {
            when (proto) {
                Protocol.SAMSUNG -> NetUtil.get("http://$ip:8001/api/v2/")?.let { r ->
                    val dev = JSONObject(r.body).optJSONObject("device")
                    name = dev?.optString("name").orEmpty()
                    model = dev?.optString("modelName").orEmpty()
                    mac = dev?.optString("wifiMac").orEmpty()
                }
                Protocol.ROKU -> NetUtil.get("http://$ip:8060/query/device-info")?.let { r ->
                    name = NetUtil.xmlTag(r.body, "user-device-name") ?: NetUtil.xmlTag(r.body, "friendly-device-name") ?: ""
                    model = NetUtil.xmlTag(r.body, "model-name") ?: ""
                    mac = NetUtil.xmlTag(r.body, "wifi-mac") ?: NetUtil.xmlTag(r.body, "ethernet-mac") ?: ""
                }
                Protocol.PHILIPS -> for (v in listOf("6", "1")) {
                    val r = NetUtil.get("http://$ip:1925/$v/system") ?: continue
                    if (r.code == 200) {
                        val o = JSONObject(r.body); name = o.optString("name"); model = o.optString("model"); break
                    }
                }
                Protocol.ANDROID_TV -> if (8008 in open) NetUtil.get("http://$ip:8008/setup/eureka_info?params=name,device_info")?.let { r ->
                    val o = JSONObject(r.body)
                    name = o.optString("name")
                    val di = o.optJSONObject("device_info")
                    model = di?.optString("model_name").orEmpty()
                    di?.optString("manufacturer")?.takeIf { it.isNotBlank() }?.let { brand = it }
                    mac = o.optString("mac_address")
                }
                else -> {}
            }
        } catch (_: Exception) {
        }
        if (name.isBlank()) name = try {
            val host = InetAddress.getByName(ip).canonicalHostName
            if (host != ip) host.substringBefore('.') else "${brand.ifEmpty { "ТВ" }} $ip"
        } catch (_: Exception) {
            "${brand.ifEmpty { "ТВ" }} $ip"
        }
        return FoundDevice(ip, name, proto, brand, model, NetUtil.normalizeMac(mac) ?: "", open, "Порты")
    }

    /** Ручное добавление: определяем протокол по открытым портам. */
    suspend fun probeHost(ip: String): FoundDevice? = withContext(Dispatchers.IO) {
        val open = coroutineScope { TV_PORTS.map { p -> async { if (NetUtil.isPortOpen(ip, p, 800)) p else null } }.awaitAll().filterNotNull() }
        val proto = protocolFromPorts(open) ?: return@withContext null
        identify(ip, proto, open)
    }

}
