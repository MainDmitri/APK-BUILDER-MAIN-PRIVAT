package com.pultitool.remote.net

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

data class LocalNet(
    val ip: String,
    val prefix: Int,
    val gateway: String?,
    val dns: List<String>,
    val iface: String?,
    val isWifi: Boolean
) {
    /** Базовый адрес /24, например "192.168.1." */
    val base24: String get() = ip.substringBeforeLast('.') + "."
}

object NetUtil {

    /** Доверяем любым сертификатам: телевизоры в локальной сети используют самоподписанные сертификаты. */
    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    val trustAll: X509TrustManager = object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }

    val trustAllFactory: SSLSocketFactory by lazy {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
        ctx.socketFactory
    }

    val anyHost = HostnameVerifier { _, _ -> true }

    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(2500, TimeUnit.MILLISECONDS)
            .readTimeout(4000, TimeUnit.MILLISECONDS)
            .writeTimeout(4000, TimeUnit.MILLISECONDS)
            .sslSocketFactory(trustAllFactory, trustAll)
            .hostnameVerifier(anyHost)
            .followRedirects(false)
            .followSslRedirects(false)
            .retryOnConnectionFailure(false)
            .build()
    }

    val ws: OkHttpClient by lazy {
        http.newBuilder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }

    fun localNet(context: Context): LocalNet? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val all = buildList {
            cm.activeNetwork?.let { add(it) }
            cm.allNetworks.forEach { if (!contains(it)) add(it) }
        }
        var fallback: LocalNet? = null
        for (n in all) {
            val lp = cm.getLinkProperties(n) ?: continue
            val caps = cm.getNetworkCapabilities(n)
            val local = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true ||
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
            val la = lp.linkAddresses.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress } ?: continue
            val ip = la.address.hostAddress ?: continue
            val gw = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }?.gateway?.hostAddress
            val dns = lp.dnsServers.filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress }
            val ln = LocalNet(ip, la.prefixLength, gw, dns, lp.interfaceName, local)
            if (local) return ln
            if (fallback == null) fallback = ln
        }
        return fallback
    }

    fun isPortOpen(ip: String, port: Int, timeoutMs: Int = 350): Boolean = try {
        Socket().use { s -> s.connect(InetSocketAddress(ip, port), timeoutMs); true }
    } catch (e: Exception) {
        false
    }

    fun get(url: String, headers: Map<String, String> = emptyMap()): HttpResult? = try {
        val rb = Request.Builder().url(url)
        headers.forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            val body = r.body?.source()?.let { src ->
                src.request(65536)
                val n = minOf(src.buffer.size, 65536L)
                src.buffer.readString(n, Charsets.UTF_8)
            } ?: ""
            HttpResult(r.code, body, r.headers.toMultimap().mapValues { it.value.joinToString("; ") }.mapKeys { it.key.lowercase() })
        }
    } catch (e: Exception) {
        null
    }

    fun post(url: String, body: String, contentType: String, headers: Map<String, String> = emptyMap()): HttpResult? = try {
        val rb = Request.Builder().url(url).post(body.toRequestBody(contentType.toMediaType()))
        headers.forEach { (k, v) -> rb.header(k, v) }
        http.newCall(rb.build()).execute().use { r ->
            HttpResult(r.code, r.body?.string()?.take(65536) ?: "", r.headers.toMultimap().mapValues { it.value.joinToString("; ") }.mapKeys { it.key.lowercase() })
        }
    } catch (e: Exception) {
        null
    }

    fun xmlTag(xml: String, tag: String): String? {
        val r = Regex("<(?:[A-Za-z0-9_]+:)?$tag(?:\\s[^>]*)?>([^<]*)</(?:[A-Za-z0-9_]+:)?$tag>", RegexOption.IGNORE_CASE)
        return r.find(xml)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() }
    }

    fun normalizeMac(raw: String): String? {
        val hex = raw.filter { it.isLetterOrDigit() }.uppercase()
        if (hex.length != 12 || hex.any { it !in "0123456789ABCDEF" }) return null
        return hex.chunked(2).joinToString(":")
    }

    fun isValidIp(ip: String): Boolean {
        val p = ip.trim().split('.')
        return p.size == 4 && p.all { s -> s.toIntOrNull()?.let { it in 0..255 } == true && s.isNotEmpty() }
    }
}

data class HttpResult(val code: Int, val body: String, val headers: Map<String, String>) {
    fun header(name: String): String? = headers[name.lowercase()]
}
