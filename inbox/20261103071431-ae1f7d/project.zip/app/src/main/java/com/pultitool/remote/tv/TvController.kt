package com.pultitool.remote.tv

import android.content.Context
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.Protocol
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.TvDevice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

sealed class ConnState {
    data object Idle : ConnState()
    data class Connecting(val message: String = "Подключение…") : ConnState()
    /** Нужен ввод кода/ключа: kind = "code" (код с экрана ТВ) или "psk" (ключ Sony). */
    data class NeedCode(val message: String, val kind: String = "code", val hexLength: Int = 6) : ConnState()
    data class WaitTv(val message: String) : ConnState()
    data class Connected(val info: String = "") : ConnState()
    data class Error(val message: String) : ConnState()
}

data class VolumeInfo(val level: Int, val max: Int, val muted: Boolean)

abstract class TvController(val context: Context, initial: TvDevice) {
    @Volatile var device: TvDevice = initial
        protected set

    protected val _state = MutableStateFlow<ConnState>(ConnState.Idle)
    val state: StateFlow<ConnState> = _state

    protected val _volume = MutableStateFlow<VolumeInfo?>(null)
    val volume: StateFlow<VolumeInfo?> = _volume

    protected val _currentApp = MutableStateFlow("")
    val currentApp: StateFlow<String> = _currentApp

    /** Вызывается, когда контроллер получил новый токен/ключ, который нужно сохранить. */
    var onDeviceUpdated: ((TvDevice) -> Unit)? = null

    protected fun updateDevice(d: TvDevice) {
        device = d
        onDeviceUpdated?.invoke(d)
    }

    open val supportsText: Boolean = true
    open val supportsTouchpad: Boolean = false
    open val supportsToast: Boolean = false
    /** Может ли протокол открыть произвольную ссылку (браузер ТВ). */
    open val supportsUrl: Boolean = false
    /** Может ли протокол открыть ролик YouTube по ID. */
    open val supportsYouTube: Boolean = false

    abstract suspend fun connect()
    abstract fun disconnect()
    abstract suspend fun sendKey(key: RKey, longPress: Boolean = false)
    open suspend fun submitCode(code: String) {}
    open suspend fun sendText(text: String) {}
    open suspend fun launchApp(app: AppShortcut) {}
    open suspend fun moveCursor(dx: Int, dy: Int) {}
    open suspend fun click() { sendKey(RKey.OK) }
    open suspend fun showToast(text: String) {}
    /** Открыть ссылку на ТВ. Возвращает false, если протокол это не поддерживает. */
    open suspend fun openUrl(url: String): Boolean = false
    /** Открыть ролик YouTube по ID видео. */
    open suspend fun openYouTube(videoId: String): Boolean = false

    abstract fun builtinApps(): List<AppShortcut>

    companion object {
        fun create(context: Context, d: TvDevice): TvController = when (d.protocol) {
            Protocol.ANDROID_TV -> AndroidTvController(context, d)
            Protocol.SAMSUNG -> SamsungController(context, d)
            Protocol.LG -> LgController(context, d)
            Protocol.ROKU -> RokuController(context, d)
            Protocol.PHILIPS -> PhilipsController(context, d)
            Protocol.SONY -> SonyController(context, d)
        }
    }
}

object AppColors {
    const val YOUTUBE = 0xFFFF0033
    const val NETFLIX = 0xFFE50914
    const val PRIME = 0xFF00A8E1
    const val KINOPOISK = 0xFFFF6600
    const val IVI = 0xFFEA003D
    const val OKKO = 0xFF5F2EEA
    const val SPOTIFY = 0xFF1DB954
    const val DISNEY = 0xFF113CCF
    const val BROWSER = 0xFF4285F4
    const val TWITCH = 0xFF9146FF
    const val VK = 0xFF0077FF
    const val PLEX = 0xFFE5A00D
    const val KODI = 0xFF17B2E7
    const val RUTUBE = 0xFF100943
}
