package com.pultitool.remote.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

object WakeOnLan {
    /** Отправляет magic packet (6×FF + 16×MAC) на широковещательные адреса, порты 9 и 7. */
    suspend fun send(mac: String, ip: String?): Boolean = withContext(Dispatchers.IO) {
        val norm = NetUtil.normalizeMac(mac) ?: return@withContext false
        val macBytes = norm.split(':').map { it.toInt(16).toByte() }.toByteArray()
        val data = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) data[i] = 0xFF.toByte()
        for (i in 0 until 16) System.arraycopy(macBytes, 0, data, 6 + i * 6, 6)
        val targets = buildList {
            add("255.255.255.255")
            if (ip != null && NetUtil.isValidIp(ip)) { add(ip.substringBeforeLast('.') + ".255"); add(ip) }
        }
        var ok = false
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                for (t in targets) for (port in intArrayOf(9, 7)) {
                    try {
                        s.send(DatagramPacket(data, data.size, InetAddress.getByName(t), port)); ok = true
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
        ok
    }
}
