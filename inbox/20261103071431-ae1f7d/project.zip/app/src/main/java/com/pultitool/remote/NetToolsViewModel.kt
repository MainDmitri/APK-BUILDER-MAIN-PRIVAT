package com.pultitool.remote

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pultitool.remote.data.MonitorEvent
import com.pultitool.remote.data.SpeedSummary
import com.pultitool.remote.data.Store
import com.pultitool.remote.net.NetUtil
import com.pultitool.remote.tools.Dns
import com.pultitool.remote.tools.DnsResult
import com.pultitool.remote.tools.HttpInspector
import com.pultitool.remote.tools.HttpResponseInfo
import com.pultitool.remote.tools.LanHost
import com.pultitool.remote.tools.LanScanner
import com.pultitool.remote.tools.Ping
import com.pultitool.remote.tools.PingSample
import com.pultitool.remote.tools.PingStats
import com.pultitool.remote.tools.PortResult
import com.pultitool.remote.tools.PortScan
import com.pultitool.remote.tools.PublicIp
import com.pultitool.remote.tools.PublicIpInfo
import com.pultitool.remote.tools.SpeedPhase
import com.pultitool.remote.tools.SpeedState
import com.pultitool.remote.tools.SpeedTest
import com.pultitool.remote.tools.TraceHop
import com.pultitool.remote.util.Achievements
import com.pultitool.remote.util.BannerKind
import com.pultitool.remote.util.Events
import com.pultitool.remote.util.Haptics
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PingState(
    val host: String = "8.8.8.8",
    val running: Boolean = false,
    val continuous: Boolean = false,
    val count: Int = 20,
    val intervalMs: Long = 1000,
    val samples: List<PingSample> = emptyList(),
    val resolved: String = "",
    val error: String? = null
) {
    val stats: PingStats get() = PingStats.of(samples)
}

data class PortScanState(
    val host: String = "",
    val spec: String = "21,22,23,25,53,80,110,139,143,443,445,554,631,1883,3389,5000,5353,5900,8000,8008,8009,8080,8443,8554,9000,37777",
    val running: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val open: List<PortResult> = emptyList(),
    val elapsedMs: Long = 0,
    val finished: Boolean = false,
    val error: String? = null
)

data class TraceState(
    val host: String = "google.com",
    val running: Boolean = false,
    val hops: List<TraceHop> = emptyList(),
    val finished: Boolean = false,
    val error: String? = null
)

data class LoadState<T>(val loading: Boolean = false, val data: T? = null, val error: String? = null)

data class MapState(
    val running: Boolean = false,
    val done: Int = 0,
    val total: Int = 0,
    val hosts: List<LanHost> = emptyList(),
    val gateway: String? = null,
    val selfIp: String? = null,
    val time: Long = 0,
    val error: String? = null
)

data class MonitorState(
    val enabled: Boolean = false,
    val scanning: Boolean = false,
    val lastCheck: Long = 0,
    val online: List<LanHost> = emptyList(),
    val known: Int = 0,
    val log: List<MonitorEvent> = emptyList(),
    val nextCheckIn: Int = 0
)

class NetToolsViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication()
    private val store = Store(app)

    init { Achievements.init(app) }

    // ---------- Пинг ----------
    private val _ping = MutableStateFlow(PingState())
    val ping: StateFlow<PingState> = _ping
    private var pingJob: Job? = null

    fun setPing(transform: (PingState) -> PingState) { if (!_ping.value.running) _ping.value = transform(_ping.value) }

    fun startPing() {
        val host = _ping.value.host.trim()
        if (host.isEmpty()) return
        pingJob?.cancel()
        _ping.value = _ping.value.copy(running = true, samples = emptyList(), error = null, resolved = "")
        pingJob = viewModelScope.launch {
            val addr = Ping.resolve(host)
            if (addr == null) {
                _ping.value = _ping.value.copy(running = false, error = "Не удалось найти хост «$host»")
                return@launch
            }
            _ping.value = _ping.value.copy(resolved = addr.hostAddress ?: "")
            var seq = 1
            while (isActive) {
                val st = _ping.value
                if (!st.continuous && seq > st.count) break
                val t0 = System.currentTimeMillis()
                val s = Ping.once(addr.hostAddress ?: host, seq)
                val list = (_ping.value.samples + s).takeLast(300)
                _ping.value = _ping.value.copy(samples = list)
                Achievements.count("pings", listOf(100L to "pinger"))
                seq++
                val wait = st.intervalMs - (System.currentTimeMillis() - t0)
                if (wait > 0) delay(wait)
            }
            _ping.value = _ping.value.copy(running = false)
        }
    }

    fun stopPing() {
        pingJob?.cancel()
        _ping.value = _ping.value.copy(running = false)
    }

    // ---------- Порты ----------
    private val _ports = MutableStateFlow(PortScanState())
    val ports: StateFlow<PortScanState> = _ports
    private var portJob: Job? = null

    fun setPorts(transform: (PortScanState) -> PortScanState) { if (!_ports.value.running) _ports.value = transform(_ports.value) }

    fun startPorts(timeoutMs: Int, banner: Boolean) {
        val st = _ports.value
        val list = try { PortScan.parse(st.spec) } catch (e: Exception) {
            _ports.value = st.copy(error = e.message); return
        }
        if (st.host.isBlank()) { _ports.value = st.copy(error = "Укажите IP-адрес или имя хоста"); return }
        _ports.value = st.copy(running = true, done = 0, total = list.size, open = emptyList(), finished = false, error = null)
        portJob = viewModelScope.launch(Dispatchers.IO) {
            val start = System.currentTimeMillis()
            val ip = PortScan.resolve(st.host)
            if (ip == null) {
                _ports.value = _ports.value.copy(running = false, error = "Не удалось найти хост «${st.host}»"); return@launch
            }
            try {
                PortScan.scan(ip, list, timeoutMs, banner,
                    onProgress = { d -> _ports.value = _ports.value.copy(done = d, elapsedMs = System.currentTimeMillis() - start) },
                    onOpen = { r -> synchronized(this@NetToolsViewModel) { _ports.value = _ports.value.copy(open = (_ports.value.open + r).sortedBy { it.port }) } })
                Achievements.unlock("porter")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ports.value = _ports.value.copy(error = e.message)
            } finally {
                _ports.value = _ports.value.copy(running = false, finished = true, elapsedMs = System.currentTimeMillis() - start)
            }
        }
    }

    fun stopPorts() {
        portJob?.cancel()
        _ports.value = _ports.value.copy(running = false, finished = true)
    }

    // ---------- Трассировка ----------
    private val _trace = MutableStateFlow(TraceState())
    val trace: StateFlow<TraceState> = _trace
    private var traceJob: Job? = null

    fun setTraceHost(h: String) { if (!_trace.value.running) _trace.value = _trace.value.copy(host = h) }

    fun startTrace() {
        val host = _trace.value.host.trim()
        if (host.isEmpty()) return
        if (!Ping.icmpAvailable) { _trace.value = _trace.value.copy(error = "Системная утилита ping недоступна на этом устройстве"); return }
        _trace.value = _trace.value.copy(running = true, hops = emptyList(), finished = false, error = null)
        traceJob = viewModelScope.launch {
            try {
                val ok = Ping.traceroute(host) { hop -> _trace.value = _trace.value.copy(hops = _trace.value.hops + hop) }
                if (!ok) _trace.value = _trace.value.copy(error = "Не удалось найти хост «$host»")
                else Achievements.unlock("tracer")
            } finally {
                _trace.value = _trace.value.copy(running = false, finished = true)
            }
        }
    }

    fun stopTrace() { traceJob?.cancel() }

    // ---------- DNS ----------
    private val _dns = MutableStateFlow(LoadState<DnsResult>())
    val dns: StateFlow<LoadState<DnsResult>> = _dns

    fun lookupDns(query: String, type: String, resolver: Int) {
        _dns.value = LoadState(loading = true, data = _dns.value.data)
        viewModelScope.launch {
            _dns.value = try {
                val r = Dns.lookup(query, type, resolver)
                Achievements.unlock("dns")
                LoadState(data = r)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { LoadState(error = e.message ?: "Ошибка") }
        }
    }

    // ---------- Внешний IP ----------
    private val _ip = MutableStateFlow(LoadState<PublicIpInfo>())
    val ip: StateFlow<LoadState<PublicIpInfo>> = _ip

    fun fetchIp() {
        _ip.value = LoadState(loading = true, data = _ip.value.data)
        viewModelScope.launch {
            _ip.value = try {
                val r = PublicIp.fetch()
                Achievements.unlock("globe")
                LoadState(data = r)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { LoadState(error = e.message ?: "Ошибка") }
        }
    }

    // ---------- Тест скорости ----------
    private val _speed = MutableStateFlow(SpeedState())
    val speed: StateFlow<SpeedState> = _speed
    private val _lastSpeed = MutableStateFlow(store.speedSummary)
    val lastSpeed: StateFlow<SpeedSummary?> = _lastSpeed
    private var speedJob: Job? = null

    fun startSpeed() {
        if (speedJob?.isActive == true) return
        speedJob = viewModelScope.launch {
            val r = SpeedTest.run { s -> _speed.value = s }
            if (r.phase == SpeedPhase.DONE) {
                val sum = SpeedSummary(r.downMbps, r.upMbps, r.pingMs, System.currentTimeMillis())
                store.speedSummary = sum
                _lastSpeed.value = sum
                Achievements.unlock("speed")
                if (r.downMbps >= 100) Achievements.unlock("rocket")
            }
        }
    }

    fun stopSpeed() {
        speedJob?.cancel()
        _speed.value = _speed.value.copy(phase = SpeedPhase.IDLE, currentMbps = 0.0)
    }

    // ---------- HTTP ----------
    private val _http = MutableStateFlow(LoadState<HttpResponseInfo>())
    val http: StateFlow<LoadState<HttpResponseInfo>> = _http

    fun sendHttp(url: String, method: String, headers: String, body: String, follow: Boolean, ignoreCert: Boolean) {
        _http.value = LoadState(loading = true)
        viewModelScope.launch {
            _http.value = try {
                val r = HttpInspector.send(url, method, headers, body, follow, ignoreCert)
                Achievements.unlock("inspector")
                LoadState(data = r)
            } catch (e: CancellationException) { throw e } catch (e: Exception) {
                val msg = when (e) {
                    is javax.net.ssl.SSLHandshakeException -> "Ошибка TLS: ${e.message}. Можно включить «Игнорировать сертификат»"
                    is java.net.UnknownHostException -> "Хост не найден"
                    is java.net.SocketTimeoutException -> "Таймаут соединения"
                    else -> e.message ?: e.javaClass.simpleName
                }
                LoadState(error = msg)
            }
        }
    }

    // ---------- Карта сети ----------
    private val _map = MutableStateFlow(MapState())
    val map: StateFlow<MapState> = _map
    private var mapJob: Job? = null

    fun scanMap() {
        if (_map.value.running) return
        val net = NetUtil.localNet(ctx)
        _map.value = MapState(running = true, gateway = net?.gateway, selfIp = net?.ip, hosts = _map.value.hosts)
        mapJob = viewModelScope.launch {
            try {
                val acc = mutableListOf<LanHost>()
                val res = LanScanner.scan(ctx,
                    onProgress = { d, t -> _map.value = _map.value.copy(done = d, total = t) },
                    onHost = { h -> synchronized(acc) { acc += h; _map.value = _map.value.copy(hosts = acc.toList()) } })
                _map.value = _map.value.copy(hosts = res, running = false, time = System.currentTimeMillis())
                store.lanDevicesSeen = res.size
                if (res.size >= 5) Achievements.unlock("mapper")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _map.value = _map.value.copy(running = false, error = e.message)
            }
        }
    }

    fun stopMap() {
        mapJob?.cancel()
        _map.value = _map.value.copy(running = false)
    }

    // ---------- Монитор новых устройств ----------
    private val _monitor = MutableStateFlow(MonitorState(log = store.monitorLog, known = store.knownHosts.size))
    val monitor: StateFlow<MonitorState> = _monitor
    private var monitorJob: Job? = null

    private fun log(e: MonitorEvent) {
        val l = (_monitor.value.log + e).takeLast(200)
        _monitor.value = _monitor.value.copy(log = l)
        store.monitorLog = l
    }

    fun setMonitor(on: Boolean) {
        if (on == _monitor.value.enabled) return
        if (!on) {
            monitorJob?.cancel()
            _monitor.value = _monitor.value.copy(enabled = false, scanning = false, nextCheckIn = 0)
            log(MonitorEvent(System.currentTimeMillis(), MonitorEvent.INFO, "", "Монитор остановлен"))
            return
        }
        Achievements.unlock("guardian")
        _monitor.value = _monitor.value.copy(enabled = true)
        log(MonitorEvent(System.currentTimeMillis(), MonitorEvent.INFO, "", "Монитор запущен"))
        monitorJob = viewModelScope.launch {
            var known = store.knownHosts.toMutableMap()
            var previous: Set<String>? = null
            val firstRun = known.isEmpty()
            while (isActive) {
                _monitor.value = _monitor.value.copy(scanning = true)
                val hosts = try { LanScanner.scan(ctx, { _, _ -> }, { }) } catch (e: CancellationException) { throw e } catch (e: Exception) {
                    log(MonitorEvent(System.currentTimeMillis(), MonitorEvent.INFO, "", "Ошибка: ${e.message}")); emptyList()
                }
                val now = System.currentTimeMillis()
                val ips = hosts.map { it.ip }.toSet()
                if (hosts.isNotEmpty()) {
                    val newOnes = hosts.filter { it.ip !in known }
                    if (previous == null && firstRun) {
                        // Первый запуск — запоминаем текущие устройства как «свои»
                        log(MonitorEvent(now, MonitorEvent.INFO, "", "Базовый снимок сети: ${hosts.size} устройств"))
                    } else {
                        newOnes.forEach { h ->
                            log(MonitorEvent(now, MonitorEvent.NEW, h.ip, "${h.kind.emoji} ${h.label}"))
                            Events.banner("Новое устройство в сети!", "${h.kind.emoji} ${h.label} · ${h.ip}", BannerKind.WARNING)
                        }
                        if (newOnes.isNotEmpty() && store.loadSettings().monitorVibrate) Haptics.pattern(ctx, longArrayOf(0, 120, 80, 120, 80, 200))
                        previous?.let { prev ->
                            (prev - ips).forEach { ip -> log(MonitorEvent(now, MonitorEvent.LEFT, ip, known[ip] ?: ip)) }
                            (ips - prev).filter { it in known }.forEach { ip ->
                                log(MonitorEvent(now, MonitorEvent.BACK, ip, hosts.firstOrNull { it.ip == ip }?.label ?: ip))
                            }
                        }
                    }
                    hosts.forEach { h -> known[h.ip] = h.label }
                    store.knownHosts = known
                    previous = ips
                }
                _monitor.value = _monitor.value.copy(scanning = false, lastCheck = now, online = hosts, known = known.size)
                val interval = store.loadSettings().monitorInterval.coerceIn(15, 3600)
                for (left in interval downTo 1) {
                    _monitor.value = _monitor.value.copy(nextCheckIn = left)
                    delay(1000)
                }
                known = store.knownHosts.toMutableMap()
            }
        }
    }

    fun forgetKnown() {
        store.knownHosts = emptyMap()
        _monitor.value = _monitor.value.copy(known = 0)
        log(MonitorEvent(System.currentTimeMillis(), MonitorEvent.INFO, "", "Список известных устройств очищен"))
    }

    fun clearMonitorLog() {
        store.monitorLog = emptyList()
        _monitor.value = _monitor.value.copy(log = emptyList())
    }

    val lanSeen: Int get() = store.lanDevicesSeen
}
