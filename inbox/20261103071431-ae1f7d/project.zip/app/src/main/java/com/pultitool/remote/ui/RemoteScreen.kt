package com.pultitool.remote.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.Protocol
import com.pultitool.remote.data.RKey
import com.pultitool.remote.tv.ConnState
import com.pultitool.remote.tv.TvController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

private enum class RemoteTab(val title: String, val glyph: Glyph) {
    MAIN("Пульт", Glyph.GRID), TOUCH("Тачпад", Glyph.TOUCH), NUM("Цифры", Glyph.KEYBOARD),
    MEDIA("Медиа", Glyph.PLAY_PAUSE), APPS("Приложения", Glyph.APPS)
}

@Composable
fun RemoteScreen(vm: AppViewModel) {
    val controller by vm.controller.collectAsState()
    val c = controller
    if (c == null) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
            EmptyState(Glyph.GRID, "Телевизор не выбран", "Найдите телевизор в сети или выберите сохранённый, чтобы начать управление.") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GradientButton("Найти", glyph = Glyph.RADAR, onClick = { vm.startScan() })
                    GhostButton("Мои устройства", onClick = { vm.navigate(Screen.DEVICES) })
                }
            }
        }
        return
    }
    RemoteContent(vm, c)
}

@Composable
private fun RemoteContent(vm: AppViewModel, c: TvController) {
    val state by c.state.collectAsState()
    val volume by c.volume.collectAsState()
    val currentApp by c.currentApp.collectAsState()
    val devices by vm.devices.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val device = devices.firstOrNull { it.id == c.device.id } ?: c.device
    var tab by remember { mutableStateOf(RemoteTab.MAIN) }
    var showKeyboard by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val sharedUrl by vm.sharedUrl.collectAsState()
    var showLink by remember { mutableStateOf(false) }
    LaunchedEffect(sharedUrl) { if (sharedUrl != null) showLink = true }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(device.name, subtitle = null, leading = { DeviceAvatar(device, 42) }, trailing = {
            if (sleepLeft > 0) Chip("${sleepLeft / 60}:${"%02d".format(sleepLeft % 60)}", Pal.yellow, Modifier.clickable { showSleep = true })
            IconButton(onClick = { showSleep = true }) { GlyphIcon(Glyph.TIMER, tint = Pal.text, size = 22.dp) }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Ещё", tint = Pal.text) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Переподключить") }, onClick = { menu = false; vm.reconnect() })
                    DropdownMenuItem(text = { Text("Включить (Wake-on-LAN)") }, onClick = { menu = false; vm.wake(device) })
                    DropdownMenuItem(text = { Text("Настройки устройства") }, onClick = { menu = false; showEdit = true })
                    DropdownMenuItem(text = { Text("Сменить телевизор") }, onClick = { menu = false; vm.navigate(Screen.DEVICES) })
                    DropdownMenuItem(text = { Text("Отключиться") }, onClick = { menu = false; vm.disconnect() })
                }
            }
        })
        StatusBanner(state, volume?.let { "Громкость ${it.level}${if (it.muted) " · без звука" else ""}" }, currentApp, onRetry = { vm.reconnect() })

        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            GlyphButton(Glyph.POWER, size = 58.dp, tint = Color.White,
                background = Brush.linearGradient(listOf(Color(0xFFFF3B5C), Color(0xFFFF7A45))), onClick = { vm.press(RKey.POWER) })
            Spacer(Modifier.weight(1f))
            GlyphButton(Glyph.HAND, size = 46.dp, onClick = { vm.navigate(Screen.GESTURE) })
            Spacer(Modifier.width(10.dp))
            GlyphButton(Glyph.LINK, size = 46.dp, onClick = { showLink = true })
            Spacer(Modifier.width(10.dp))
            GlyphButton(Glyph.INPUT, size = 46.dp, onClick = { vm.press(RKey.INPUT) })
            Spacer(Modifier.width(10.dp))
            GlyphButton(Glyph.KEYBOARD, size = 46.dp, onClick = {
                if (c.supportsText) showKeyboard = true else vm.message("Ввод текста не поддерживается этим протоколом")
            })
        }

        TabSelector(tab) { tab = it; vm.haptic(10) }

        AnimatedContent(tab, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }, label = "tab") { t ->
            Box(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp), contentAlignment = Alignment.TopCenter) {
                when (t) {
                    RemoteTab.MAIN -> MainPad(vm, volume?.level)
                    RemoteTab.TOUCH -> TouchPad(vm, c.supportsTouchpad)
                    RemoteTab.NUM -> NumPad(vm)
                    RemoteTab.MEDIA -> MediaPad(vm)
                    RemoteTab.APPS -> AppsPad(vm, c.builtinApps(), device.customApps, c.supportsToast)
                }
            }
        }
    }

    if (showKeyboard) KeyboardDialog(vm) { showKeyboard = false }
    if (showSleep) SleepDialog(sleepLeft, onPick = { vm.startSleepTimer(it); showSleep = false },
        onCancel = { vm.cancelSleepTimer(); showSleep = false }, onDismiss = { showSleep = false })
    if (showEdit) DeviceEditDialog(device, onDismiss = { showEdit = false }) { vm.editDevice(it); showEdit = false }
    if (showLink) OpenLinkDialog(vm, c, sharedUrl ?: "") { showLink = false; vm.setSharedUrl(null) }
    (state as? ConnState.NeedCode)?.let { s -> PairingDialog(s, onSubmit = { vm.submitCode(it) }, onCancel = { vm.disconnect() }) }
}

@Composable
private fun StatusBanner(state: ConnState, volume: String?, app: String, onRetry: () -> Unit) {
    val (color, text) = when (state) {
        is ConnState.Idle -> Pal.textDim to "Не подключено"
        is ConnState.Connecting -> Pal.yellow to state.message
        is ConnState.NeedCode -> Pal.yellow to state.message
        is ConnState.WaitTv -> Pal.yellow to state.message
        is ConnState.Connected -> Pal.green to listOfNotNull("Подключено", state.info.takeIf { it.isNotBlank() }, volume).joinToString(" · ")
        is ConnState.Error -> Pal.red to state.message
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (state is ConnState.Connecting || state is ConnState.WaitTv) CircularProgressIndicator(Modifier.size(14.dp), color = color, strokeWidth = 2.dp)
        else StatusDot(color)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(text, color = Pal.text, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (app.isNotBlank() && state is ConnState.Connected) Text("Сейчас: $app", color = Pal.textDim, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (state is ConnState.Error || state is ConnState.Idle) TextButton(onClick = onRetry) { Text("Подключить") }
    }
}

@Composable
private fun TabSelector(tab: RemoteTab, onSelect: (RemoteTab) -> Unit) {
    val accent = LocalAccent.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(RoundedCornerShape(20.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        RemoteTab.entries.forEach { t ->
            val on = t == tab
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                    .then(if (on) Modifier.background(accent.brush) else Modifier)
                    .clickable { onSelect(t) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlyphIcon(t.glyph, tint = Pal.text, size = 18.dp)
                Text(t.title, color = Pal.text, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

// ------------------------- Основной пульт -------------------------

@Composable
private fun MainPad(vm: AppViewModel, volumeLevel: Int?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        DPad(
            onKey = { k, long -> vm.press(k, long) },
            modifier = Modifier.size(270.dp)
        )
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(26.dp)) {
            GlyphButton(Glyph.BACK, label = "Назад", onLongClick = { vm.press(RKey.BACK, true) }) { vm.press(RKey.BACK) }
            GlyphButton(Glyph.HOME, label = "Домой", onLongClick = { vm.press(RKey.HOME, true) }) { vm.press(RKey.HOME) }
            GlyphButton(Glyph.MENU, label = "Меню") { vm.press(RKey.MENU) }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            Rocker("ГРОМК", volumeLevel?.toString(), Glyph.VOL_UP, Glyph.VOL_DOWN,
                onUp = { vm.press(RKey.VOL_UP) }, onDown = { vm.press(RKey.VOL_DOWN) }, autoRepeat = true)
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                GlyphButton(Glyph.MUTE, size = 56.dp, label = "Без звука") { vm.press(RKey.MUTE) }
                GlyphButton(Glyph.GUIDE, size = 56.dp, label = "Гид") { vm.press(RKey.GUIDE) }
            }
            Rocker("КАНАЛ", null, Glyph.PLUS, Glyph.MINUS,
                onUp = { vm.press(RKey.CH_UP) }, onDown = { vm.press(RKey.CH_DOWN) }, autoRepeat = false)
        }
        Spacer(Modifier.height(18.dp))
        ColorKeys(vm)
    }
}

@Composable
private fun ColorKeys(vm: AppViewModel) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        listOf(RKey.RED to Color(0xFFFF3B3B), RKey.GREEN to Color(0xFF2EE56B), RKey.YELLOW to Color(0xFFFFD43B), RKey.BLUE to Color(0xFF3B8BFF)).forEach { (k, col) ->
            PadButton(size = 0.dp, shape = RoundedCornerShape(10.dp), modifier = Modifier.width(58.dp).height(26.dp),
                background = Brush.linearGradient(listOf(col, col.copy(alpha = 0.7f))), onClick = { vm.press(k) }) {}
        }
    }
}

private enum class PadZone { NONE, UP, DOWN, LEFT, RIGHT, OK }

@Composable
fun DPad(onKey: (RKey, Boolean) -> Unit, modifier: Modifier = Modifier) {
    val accent = LocalAccent.current
    var zone by remember { mutableStateOf(PadZone.NONE) }
    val okScale by animateFloatAsState(if (zone == PadZone.OK) 0.9f else 1f, label = "ok")
    fun zoneAt(o: Offset, w: Float, h: Float): PadZone {
        val dx = o.x - w / 2; val dy = o.y - h / 2
        val dist = hypot(dx, dy)
        val r = minOf(w, h) / 2
        if (dist < r * 0.36f) return PadZone.OK
        if (dist > r * 1.02f) return PadZone.NONE
        val ang = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble()))
        return when {
            ang >= -45 && ang < 45 -> PadZone.RIGHT
            ang >= 45 && ang < 135 -> PadZone.DOWN
            ang >= -135 && ang < -45 -> PadZone.UP
            else -> PadZone.LEFT
        }
    }
    fun keyOf(z: PadZone): RKey? = when (z) {
        PadZone.UP -> RKey.UP; PadZone.DOWN -> RKey.DOWN; PadZone.LEFT -> RKey.LEFT
        PadZone.RIGHT -> RKey.RIGHT; PadZone.OK -> RKey.OK; PadZone.NONE -> null
    }
    Box(
        modifier.pointerInput(Unit) {
            detectTapGestures(
                onPress = { o ->
                    zone = zoneAt(o, size.width.toFloat(), size.height.toFloat())
                    tryAwaitRelease()
                    zone = PadZone.NONE
                },
                onTap = { o -> keyOf(zoneAt(o, size.width.toFloat(), size.height.toFloat()))?.let { onKey(it, false) } },
                onLongPress = { o -> keyOf(zoneAt(o, size.width.toFloat(), size.height.toFloat()))?.let { onKey(it, true) } }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(Color(0x30FFFFFF), Color(0x10FFFFFF)), c, r), r, c)
            drawCircle(Brush.sweepGradient(listOf(accent.a, accent.b, accent.a), c), r - 1.5f, c, style = Stroke(3f))
            val start = when (zone) {
                PadZone.RIGHT -> -45f; PadZone.DOWN -> 45f; PadZone.LEFT -> 135f; PadZone.UP -> 225f; else -> null
            }
            if (start != null) {
                drawArc(Brush.radialGradient(listOf(accent.b.copy(alpha = 0.1f), accent.b.copy(alpha = 0.45f)), c, r),
                    start, 90f, true, topLeft = Offset(c.x - r, c.y - r), size = Size(r * 2, r * 2))
            }
            drawCircle(Color(0x14000000), r * 0.4f, c)
        }
        Icon(Icons.Filled.KeyboardArrowUp, null, tint = Pal.text, modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp).size(36.dp))
        Icon(Icons.Filled.KeyboardArrowDown, null, tint = Pal.text, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp).size(36.dp))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, tint = Pal.text, modifier = Modifier.align(Alignment.CenterStart).padding(start = 18.dp).size(36.dp))
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Pal.text, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 18.dp).size(36.dp))
        Box(
            Modifier.size(96.dp).scale(okScale).clip(CircleShape).background(accent.brush)
                .border(2.dp, Color(0x55FFFFFF), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text("OK", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp) }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Rocker(title: String, value: String?, up: Glyph, down: Glyph, onUp: () -> Unit, onDown: () -> Unit, autoRepeat: Boolean) {
    val scope = rememberCoroutineScope()
    Column(
        Modifier.width(72.dp).height(190.dp).glass(RoundedCornerShape(36.dp)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.fillMaxWidth().weight(1f).combinedClickable(onClick = onUp,
            onLongClick = { if (autoRepeat) scope.launch { repeat(6) { onUp(); delay(120) } } else onUp() }), contentAlignment = Alignment.Center) {
            GlyphIcon(up, tint = Pal.text, size = 28.dp)
        }
        Text(value ?: title, color = Pal.textDim, fontSize = if (value != null) 16.sp else 11.sp, fontWeight = FontWeight.Bold)
        Box(Modifier.fillMaxWidth().weight(1f).combinedClickable(onClick = onDown,
            onLongClick = { if (autoRepeat) scope.launch { repeat(6) { onDown(); delay(120) } } else onDown() }), contentAlignment = Alignment.Center) {
            GlyphIcon(down, tint = Pal.text, size = 28.dp)
        }
    }
}

// ------------------------- Тачпад -------------------------

@Composable
private fun TouchPad(vm: AppViewModel, mouseSupported: Boolean) {
    val accent = LocalAccent.current
    var mouse by remember { mutableStateOf(mouseSupported) }
    var trail by remember { mutableStateOf<Offset?>(null) }
    var accX by remember { mutableFloatStateOf(0f) }
    var accY by remember { mutableFloatStateOf(0f) }
    var lastSend by remember { mutableLongStateOf(0L) }
    Column(Modifier.padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (mouseSupported) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                Text(if (mouse) "Режим мыши (курсор на ТВ)" else "Режим свайпов (стрелки)", color = Pal.text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(mouse, { mouse = it })
            }
        }
        Box(
            Modifier.fillMaxWidth().height(330.dp).glass(RoundedCornerShape(28.dp))
                .pointerInput(mouse) {
                    detectTapGestures(onTap = { if (mouse) vm.click() else vm.press(RKey.OK) },
                        onDoubleTap = { vm.press(RKey.BACK) },
                        onLongPress = { vm.press(RKey.HOME) })
                }
                .pointerInput(mouse) {
                    detectDragGestures(
                        onDragStart = { o -> trail = o; accX = 0f; accY = 0f },
                        onDragEnd = { trail = null; accX = 0f; accY = 0f },
                        onDragCancel = { trail = null }
                    ) { change, drag ->
                        trail = change.position
                        accX += drag.x; accY += drag.y
                        if (mouse) {
                            val now = System.currentTimeMillis()
                            if (now - lastSend > 30) {
                                vm.moveCursor((accX * 1.4f).toInt(), (accY * 1.4f).toInt())
                                accX = 0f; accY = 0f; lastSend = now
                            }
                        } else {
                            val th = 90f
                            if (abs(accX) > th || abs(accY) > th) {
                                val k = if (abs(accX) > abs(accY)) (if (accX > 0) RKey.RIGHT else RKey.LEFT) else (if (accY > 0) RKey.DOWN else RKey.UP)
                                vm.press(k); accX = 0f; accY = 0f
                            }
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val step = 28.dp.toPx()
                var x = step
                while (x < size.width) { var y = step; while (y < size.height) { drawCircle(Color(0x18FFFFFF), 2.5f, Offset(x, y)); y += step }; x += step }
                trail?.let {
                    drawCircle(Brush.radialGradient(listOf(accent.b.copy(alpha = 0.55f), Color.Transparent), it, 120f), 120f, it)
                    drawCircle(Color.White, 12f, it)
                }
            }
            if (trail == null) Text(
                if (mouse) "Водите пальцем — курсор\nНажатие — клик · Двойное — назад · Удержание — домой"
                else "Свайп — стрелки\nНажатие — OK · Двойное — назад · Удержание — домой",
                color = Pal.textDim, fontSize = 13.sp, textAlign = TextAlign.Center
            )
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
            GlyphButton(Glyph.BACK, label = "Назад") { vm.press(RKey.BACK) }
            GlyphButton(Glyph.HOME, label = "Домой") { vm.press(RKey.HOME) }
            GlyphButton(Glyph.VOL_DOWN, label = "Тише") { vm.press(RKey.VOL_DOWN) }
            GlyphButton(Glyph.VOL_UP, label = "Громче") { vm.press(RKey.VOL_UP) }
        }
    }
}

// ------------------------- Цифры -------------------------

@Composable
private fun NumPad(vm: AppViewModel) {
    var typed by remember { mutableStateOf("") }
    LaunchedEffect(typed) {
        if (typed.isNotEmpty()) { delay(2500); typed = "" }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (typed.isEmpty()) "Канал" else typed, color = if (typed.isEmpty()) Pal.textDim else Pal.text,
            fontSize = if (typed.isEmpty()) 14.sp else 34.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "OK"))
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                row.forEach { k ->
                    val bg = if (k == "OK") LocalAccent.current.brush else null
                    TextKey(k, size = 74.dp, fontSize = 26, background = bg) {
                        when (k) {
                            "⌫" -> { vm.press(RKey.DEL); typed = typed.dropLast(1) }
                            "OK" -> { vm.press(RKey.ENTER); typed = "" }
                            else -> { vm.press(RKey.digit(k.toInt())); typed = (typed + k).takeLast(4) }
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TextKey("CH +", size = 0.dp, fontSize = 14, shape = RoundedCornerShape(16.dp), modifier = Modifier.width(80.dp).height(46.dp)) { vm.press(RKey.CH_UP) }
            TextKey("CH −", size = 0.dp, fontSize = 14, shape = RoundedCornerShape(16.dp), modifier = Modifier.width(80.dp).height(46.dp)) { vm.press(RKey.CH_DOWN) }
            TextKey("Гид", size = 0.dp, fontSize = 14, shape = RoundedCornerShape(16.dp), modifier = Modifier.width(80.dp).height(46.dp)) { vm.press(RKey.GUIDE) }
        }
    }
}

// ------------------------- Медиа -------------------------

@Composable
private fun MediaPad(vm: AppViewModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
        GlyphButton(Glyph.PLAY_PAUSE, size = 104.dp, tint = Color.White, background = LocalAccent.current.brush) { vm.press(RKey.PLAY_PAUSE) }
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            GlyphButton(Glyph.PREV, size = 56.dp, label = "Пред.") { vm.press(RKey.PREV) }
            GlyphButton(Glyph.REWIND, size = 64.dp, label = "Назад", onLongClick = { vm.press(RKey.REWIND, true) }) { vm.press(RKey.REWIND) }
            GlyphButton(Glyph.STOP, size = 56.dp, label = "Стоп") { vm.press(RKey.STOP) }
            GlyphButton(Glyph.FORWARD, size = 64.dp, label = "Вперёд", onLongClick = { vm.press(RKey.FAST_FORWARD, true) }) { vm.press(RKey.FAST_FORWARD) }
            GlyphButton(Glyph.NEXT, size = 56.dp, label = "След.") { vm.press(RKey.NEXT) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            GlyphButton(Glyph.PLAY, size = 56.dp, label = "Пуск") { vm.press(RKey.PLAY) }
            GlyphButton(Glyph.PAUSE, size = 56.dp, label = "Пауза") { vm.press(RKey.PAUSE) }
            GlyphButton(Glyph.MUTE, size = 56.dp, label = "Звук") { vm.press(RKey.MUTE) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SmallKey("Поиск", { Icon(Icons.Filled.Search, null, tint = Pal.text) }) { vm.press(RKey.SEARCH) }
            SmallKey("Опции", { Icon(Icons.Filled.Settings, null, tint = Pal.text) }) { vm.press(RKey.SETTINGS) }
            SmallKey("Инфо", { GlyphIcon(Glyph.INFO, tint = Pal.text, size = 22.dp) }) { vm.press(RKey.INFO) }
            SmallKey("Выход", { Text("✕", color = Pal.text, fontSize = 18.sp) }) { vm.press(RKey.EXIT) }
        }
        ColorKeys(vm)
    }
}

@Composable
private fun SmallKey(label: String, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        PadButton(size = 52.dp, shape = RoundedCornerShape(16.dp), onClick = onClick) { icon() }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Pal.textDim, fontSize = 11.sp)
    }
}

// ------------------------- Приложения -------------------------

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
private fun AppsPad(vm: AppViewModel, builtin: List<AppShortcut>, custom: List<AppShortcut>, toast: Boolean) {
    var adding by remember { mutableStateOf(false) }
    var removing by remember { mutableStateOf<AppShortcut?>(null) }
    var toastText by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        if (builtin.isEmpty() && custom.isEmpty()) {
            Text("Для этого типа подключения запуск приложений недоступен. Используйте кнопку «Домой».",
                color = Pal.textDim, fontSize = 14.sp, modifier = Modifier.padding(8.dp))
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), maxItemsInEachRow = 3,
            modifier = Modifier.fillMaxWidth()) {
            (builtin + custom).forEach { app ->
                val isCustom = app in custom
                AppTile(app, Modifier.weight(1f), onClick = { vm.launchApp(app) }, onLongClick = if (isCustom) ({ removing = app }) else null)
            }
            Column(
                Modifier.weight(1f).height(96.dp).glass(RoundedCornerShape(22.dp)).clickable { adding = true },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                GlyphIcon(Glyph.PLUS, tint = Pal.text, size = 28.dp)
                Text("Своё", color = Pal.textDim, fontSize = 12.sp)
            }
        }
        if (toast) {
            Spacer(Modifier.height(18.dp))
            SectionTitle("Сообщение на экран ТВ")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(toastText, { toastText = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Привет с телефона!") })
                IconButton(onClick = { if (toastText.isNotBlank()) { vm.showToast(toastText); toastText = "" } }) {
                    Icon(Icons.AutoMirrored.Filled.Send, "Отправить", tint = LocalAccent.current.b)
                }
            }
        }
    }
    if (adding) AddAppDialog(onDismiss = { adding = false }) { vm.addCustomApp(it); adding = false }
    removing?.let { app ->
        AlertDialog(onDismissRequest = { removing = null }, title = { Text("Удалить «${app.title}»?") },
            confirmButton = { TextButton(onClick = { vm.removeCustomApp(app); removing = null }) { Text("Удалить", color = Pal.red) } },
            dismissButton = { TextButton(onClick = { removing = null }) { Text("Отмена") } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppTile(app: AppShortcut, modifier: Modifier, onClick: () -> Unit, onLongClick: (() -> Unit)?) {
    val col = Color(app.color)
    Column(
        modifier.height(96.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(col, col.copy(alpha = 0.55f))))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(22.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(app.title.take(1).uppercase(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Text(app.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AddAppDialog(onDismiss: () -> Unit, onAdd: (AppShortcut) -> Unit) {
    var title by remember { mutableStateOf("") }
    var id by remember { mutableStateOf("") }
    val colors = listOf(0xFF6C5CE7, 0xFFE84393, 0xFF00B894, 0xFFFDCB6E, 0xFF0984E3, 0xFFD63031)
    var color by remember { mutableLongStateOf(colors[0]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Своё приложение") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                OutlinedTextField(id, { id = it.trim() }, label = { Text("ID / ссылка") }, singleLine = true)
                Text("Android TV: ссылка (https://… или market://launch?id=пакет). Samsung/LG/Roku: ID приложения.",
                    color = Pal.textDim, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colors.forEach { cl ->
                        Box(Modifier.size(30.dp).clip(CircleShape).background(Color(cl))
                            .then(if (cl == color) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                            .clickable { color = cl })
                    }
                }
            }
        },
        confirmButton = { TextButton(enabled = title.isNotBlank() && id.isNotBlank(), onClick = { onAdd(AppShortcut(title.trim(), id, color)) }) { Text("Добавить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

// ------------------------- Диалоги -------------------------

@Composable
private fun KeyboardDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); try { focus.requestFocus() } catch (_: Exception) {} }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ввод текста на ТВ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Откройте на телевизоре поле поиска, затем введите текст здесь.", color = Pal.textDim, fontSize = 13.sp)
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().focusRequester(focus), singleLine = true,
                    placeholder = { Text("Например: фильмы 2026") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send, capitalization = KeyboardCapitalization.Sentences),
                    keyboardActions = KeyboardActions(onSend = { if (text.isNotEmpty()) { vm.sendText(text); text = "" } }))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GhostButton("⌫ Стереть", onClick = { vm.press(RKey.DEL) })
                    GhostButton("↵ Ввод", onClick = { vm.press(RKey.ENTER) })
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotEmpty(), onClick = { vm.sendText(text); text = "" }) { Text("Отправить") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}

@Composable
private fun PairingDialog(s: ConnState.NeedCode, onSubmit: (String) -> Unit, onCancel: () -> Unit) {
    var code by remember(s) { mutableStateOf("") }
    val isHex = s.kind == "code"
    val ok = if (isHex) code.length == s.hexLength else code.isNotBlank()
    AlertDialog(
        onDismissRequest = {},
        title = { Text(if (isHex) "Код сопряжения" else "Ключ доступа") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(s.message, color = Pal.textDim, fontSize = 14.sp, textAlign = TextAlign.Center)
                OutlinedTextField(
                    code,
                    { v -> code = if (isHex) v.uppercase().filter { it in "0123456789ABCDEF" }.take(s.hexLength) else v },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(fontSize = 28.sp, fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center, letterSpacing = 6.sp, color = Pal.text),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { if (ok) onSubmit(code) }),
                    modifier = Modifier.fillMaxWidth()
                )
                if (isHex) CodeCells(code, s.hexLength)
            }
        },
        confirmButton = { TextButton(enabled = ok, onClick = { onSubmit(code) }) { Text("Подтвердить") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Отмена") } }
    )
}

@Composable
private fun CodeCells(code: String, n: Int) {
    val accent = LocalAccent.current
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 0 until n) {
            val filled = i < code.length
            Box(Modifier.size(width = 34.dp, height = 6.dp).clip(RoundedCornerShape(3.dp))
                .background(if (filled) accent.brush else Brush.linearGradient(listOf(Pal.glassStrong, Pal.glassStrong))))
        }
    }
}

@Composable
private fun SleepDialog(left: Long, onPick: (Int) -> Unit, onCancel: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Таймер сна") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (left > 0) "Телевизор выключится через ${left / 60} мин ${left % 60} с" else "Через сколько выключить телевизор?",
                    color = Pal.textDim, fontSize = 14.sp)
                Text("Приложение должно оставаться открытым или в фоне.", color = Pal.textDim, fontSize = 12.sp)
                listOf(5, 15, 30, 45, 60, 90, 120).chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { m ->
                            TextKey("$m", size = 0.dp, fontSize = 15, shape = RoundedCornerShape(14.dp),
                                modifier = Modifier.width(56.dp).height(44.dp)) { onPick(m) }
                        }
                    }
                }
            }
        },
        confirmButton = { if (left > 0) TextButton(onClick = onCancel) { Text("Отменить таймер", color = Pal.red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } }
    )
}



/** Отправка ссылки или ролика YouTube на телевизор. */
@Composable
private fun OpenLinkDialog(vm: AppViewModel, c: TvController, initial: String, onDismiss: () -> Unit) {
    var url by remember { mutableStateOf(initial) }
    val yt = com.pultitool.remote.youTubeId(url)
    val canOpen = (yt != null && c.supportsYouTube) || c.supportsUrl
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Открыть на ТВ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(url, { url = it }, label = { Text("Ссылка или ID ролика YouTube") }, singleLine = false, maxLines = 3, modifier = Modifier.fillMaxWidth())
                when {
                    yt != null && c.supportsYouTube -> Text("▶ Ролик YouTube: $yt — откроется в приложении YouTube на ТВ", color = Pal.green, fontSize = 12.sp)
                    url.isNotBlank() && c.supportsUrl -> Text("🌐 Откроется в браузере телевизора", color = Pal.textDim, fontSize = 12.sp)
                    url.isNotBlank() -> Text("Протокол ${c.device.protocol.short} не умеет открывать произвольные ссылки" +
                        if (c.supportsYouTube) " — поддерживаются ролики YouTube" else "", color = Pal.yellow, fontSize = 12.sp)
                }
                Text("Совет: в YouTube или браузере нажмите «Поделиться» → «Пульт Тул», и ссылка попадёт сюда.", color = Pal.textDim, fontSize = 11.sp)
            }
        },
        confirmButton = { TextButton(enabled = url.isNotBlank() && canOpen, onClick = { vm.openOnTv(url); onDismiss() }) { Text("Открыть") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
