package com.pultitool.remote.audit

import android.content.Context
import com.pultitool.remote.net.Discovery
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.coroutineContext

/**
 * Аудит СОБСТВЕННОЙ локальной сети. Только пассивная/неинвазивная разведка:
 * проверка открытых портов, чтение заголовков HTTP/RTSP/ONVIF и определение,
 * требуется ли аутентификация. Никаких попыток входа, подбора паролей,
 * захвата видеопотоков или эксплуатации уязвимостей.
 */
class NetworkAuditor(private val context: Context) {

    companion object {
        val PORTS = intArrayOf(
            21, 22, 23, 80, 81, 88, 139, 443, 445, 554, 631, 1883, 3000, 3389, 5000, 5001,
            6466, 8000, 8001, 8008, 8060, 8080, 8081, 8123, 8443, 8554, 8899, 9100, 34567, 37777
        )
        val WEB_PORTS = setOf(80, 81, 88, 443, 5000, 5001, 8000, 8080, 8081, 8123, 8443, 8899)
        val HTTPS_PORTS = setOf(443, 5001, 8443)
        val RTSP_PORTS = setOf(554, 8554)
        private const val UA = "PultTool-NetworkAudit/1.0 (read-only)"

        private data class Sig(val keys: List<String>, val brand: String, val type: DevType)

        private val SIGNATURES = listOf(
            Sig(listOf("hikvision", "dnvrs-webs", "dvrdvs-webs", "app-webs", "hikvision-webs", "doc/page/login.asp", "ivms"), "Hikvision", DevType.CAMERA),
            Sig(listOf("hiwatch"), "HiWatch (Hikvision)", DevType.CAMERA),
            Sig(listOf("ezviz"), "EZVIZ", DevType.CAMERA),
            Sig(listOf("dahua", "dhwebclientplugin", "/rpc2_login", "dh_webclient", "dhvideowhmode", "web service</title>"), "Dahua", DevType.CAMERA),
            Sig(listOf("imou"), "Imou (Dahua)", DevType.CAMERA),
            Sig(listOf("amcrest"), "Amcrest", DevType.CAMERA),
            Sig(listOf("netsurveillance", "xmeye", "xiongmai", "hi3520"), "Xiongmai / XMeye", DevType.DVR),
            Sig(listOf("uniview", "unv "), "Uniview", DevType.CAMERA),
            Sig(listOf("reolink"), "Reolink", DevType.CAMERA),
            Sig(listOf("axis communications", "axis-cgi"), "Axis", DevType.CAMERA),
            Sig(listOf("foscam"), "Foscam", DevType.CAMERA),
            Sig(listOf("trassir"), "TRASSIR", DevType.DVR),
            Sig(listOf("polyvision"), "Polyvision", DevType.CAMERA),
            Sig(listOf("nvms-"), "TVT", DevType.DVR),
            Sig(listOf("ip camera", "ipcam", "network camera", "netcam", "webcam", "motioneye", "go2rtc", "ip-камера", "boa/0.94"), "", DevType.CAMERA),
            Sig(listOf("nvr", "dvr", "network video recorder"), "", DevType.DVR),
            Sig(listOf("keenetic", "zyxel"), "Keenetic / Zyxel", DevType.ROUTER),
            Sig(listOf("mikrotik", "routeros", "webfig"), "MikroTik", DevType.ROUTER),
            Sig(listOf("tp-link", "tplink", "tl-wr"), "TP-Link", DevType.ROUTER),
            Sig(listOf("mercusys"), "Mercusys", DevType.ROUTER),
            Sig(listOf("asuswrt", "rt-ac", "rt-ax", "asus router"), "ASUS", DevType.ROUTER),
            Sig(listOf("miwifi", "xiaomi router"), "Xiaomi", DevType.ROUTER),
            Sig(listOf("huawei", "hg8245", "echolife"), "Huawei", DevType.ROUTER),
            Sig(listOf("zte", "zxhn", "f660", "f670"), "ZTE", DevType.ROUTER),
            Sig(listOf("d-link", "dlink"), "D-Link", DevType.ROUTER),
            Sig(listOf("netgear"), "Netgear", DevType.ROUTER),
            Sig(listOf("tenda"), "Tenda", DevType.ROUTER),
            Sig(listOf("netis"), "Netis", DevType.ROUTER),
            Sig(listOf("sagemcom", "f@st"), "Sagemcom", DevType.ROUTER),
            Sig(listOf("eltex"), "Eltex", DevType.ROUTER),
            Sig(listOf("snr-", "snr "), "SNR", DevType.ROUTER),
            Sig(listOf("luci-static", "/cgi-bin/luci", "openwrt"), "OpenWrt", DevType.ROUTER),
            Sig(listOf("dd-wrt"), "DD-WRT", DevType.ROUTER),
            Sig(listOf("ubiquiti", "unifi os", "ubnt", "airos", "edgeos"), "Ubiquiti", DevType.ROUTER),
            Sig(listOf("linksys"), "Linksys", DevType.ROUTER),
            Sig(listOf("fritz!box", "fritzbox"), "AVM FRITZ!Box", DevType.ROUTER),
            Sig(listOf("pfsense", "opnsense"), "pfSense / OPNsense", DevType.ROUTER),
            Sig(listOf("synology", "diskstation"), "Synology", DevType.NAS),
            Sig(listOf("qnap"), "QNAP", DevType.NAS),
            Sig(listOf("truenas", "freenas"), "TrueNAS", DevType.NAS),
            Sig(listOf("openmediavault"), "OpenMediaVault", DevType.NAS),
            Sig(listOf("asustor"), "ASUSTOR", DevType.NAS),
            Sig(listOf("wd my cloud", "mycloud"), "WD My Cloud", DevType.NAS),
            Sig(listOf("nextcloud", "owncloud"), "Nextcloud", DevType.NAS),
            Sig(listOf("hp laserjet", "hp officejet", "hp deskjet", "hp-chaisoe", "hp http server"), "HP", DevType.PRINTER),
            Sig(listOf("epson"), "Epson", DevType.PRINTER),
            Sig(listOf("canon inc", "imagerunner", "pixma", "i-sensys"), "Canon", DevType.PRINTER),
            Sig(listOf("brother"), "Brother", DevType.PRINTER),
            Sig(listOf("kyocera"), "Kyocera", DevType.PRINTER),
            Sig(listOf("pantum"), "Pantum", DevType.PRINTER),
            Sig(listOf("cups"), "CUPS", DevType.PRINTER),
            Sig(listOf("home assistant"), "Home Assistant", DevType.SMART_HOME),
            Sig(listOf("shelly"), "Shelly", DevType.SMART_HOME),
            Sig(listOf("tasmota"), "Tasmota", DevType.SMART_HOME),
            Sig(listOf("esphome"), "ESPHome", DevType.SMART_HOME),
            Sig(listOf("zigbee2mqtt"), "Zigbee2MQTT", DevType.SMART_HOME),
            Sig(listOf("domoticz", "openhab", "node-red"), "Smart Home", DevType.SMART_HOME),
            Sig(listOf("plex media", "jellyfin", "emby server", "kodi"), "Медиасервер", DevType.TV),
            Sig(listOf("proxmox", "portainer", "webmin", "cockpit"), "Сервер", DevType.COMPUTER)
        )

        private val TITLE = Regex("<title[^>]*>([^<]{0,200})</title>", RegexOption.IGNORE_CASE)
        private val PASSWORD_INPUT = Regex("type\\s*=\\s*[\"']?password", RegexOption.IGNORE_CASE)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private val io = Dispatchers.IO.limitedParallelism(128)

    suspend fun run(onProgress: (AuditProgress) -> Unit, onHost: (AuditHost) -> Unit): List<AuditHost> = coroutineScope {
        val net = NetUtil.localNet(context) ?: run {
            onProgress(AuditProgress(0, 0, "Нет подключения к локальной сети (Wi-Fi/Ethernet)", false))
            return@coroutineScope emptyList()
        }
        val base = net.base24
        val hosts = (1..254).map { "$base$it" }
        onProgress(AuditProgress(0, hosts.size, "WS-Discovery (ONVIF) и SSDP…", true))

        val wsdJob = async(io) { wsDiscovery() }
        val ssdpJob = async(io) { Discovery.ssdp(context, 3000, listOf("ssdp:all", "urn:schemas-upnp-org:device:InternetGatewayDevice:1")) }

        // 1. Проба портов: все хосты × все порты параллельно
        val total = hosts.size
        val done = AtomicInteger(0)
        val openMap = ConcurrentHashMap<String, MutableSet<Int>>()
        hosts.map { ip ->
            async(io) {
                val open = PORTS.map { p -> async(io) { if (NetUtil.isPortOpen(ip, p, 280)) p else null } }.awaitAll().filterNotNull()
                if (open.isNotEmpty()) openMap[ip] = open.toMutableSet()
                else if (ip == net.ip || ip == net.gateway || reachable(ip)) openMap.putIfAbsent(ip, mutableSetOf())
                val n = done.incrementAndGet()
                if (n % 6 == 0 || n == total) onProgress(AuditProgress(n, total, "Поиск устройств: $n из $total адресов", true))
            }
        }.awaitAll()

        val wsd = wsdJob.await()
        val ssdp = ssdpJob.await()
        wsd.keys.forEach { openMap.putIfAbsent(it, mutableSetOf()) }
        ssdp.forEach { openMap.putIfAbsent(it.ip, mutableSetOf()) }
        openMap.putIfAbsent(net.ip, mutableSetOf())

        // 2. Отпечатки сервисов
        val ips = openMap.keys.sortedBy { it.substringAfterLast('.').toIntOrNull() ?: 0 }
        val fp = AtomicInteger(0)
        onProgress(AuditProgress(0, ips.size, "Анализ сервисов на ${ips.size} устройствах…", true))
        val results = ips.map { ip ->
            async(io) {
                coroutineContext.ensureActive()
                val host = fingerprint(ip, openMap[ip]!!.sorted(), net.gateway == ip, net.ip == ip, wsd[ip], ssdp.filter { it.ip == ip })
                onHost(host)
                val n = fp.incrementAndGet()
                onProgress(AuditProgress(n, ips.size, "Анализ сервисов: $n из ${ips.size}", true))
                host
            }
        }.awaitAll()
        onProgress(AuditProgress(ips.size, ips.size, "Готово: найдено устройств — ${results.size}", false))
        results
    }

    private fun reachable(ip: String): Boolean = try {
        InetAddress.getByName(ip).isReachable(350)
    } catch (_: Exception) {
        false
    }

    // ---------------- WS-Discovery (ONVIF) ----------------

    data class WsdHit(val xaddrs: String, val scopes: String)

    private fun wsDiscovery(): Map<String, WsdHit> {
        val result = ConcurrentHashMap<String, WsdHit>()
        Discovery.withMulticast(context) {
            try {
                MulticastSocket(null).use { sock ->
                    sock.reuseAddress = true
                    sock.bind(InetSocketAddress(0))
                    sock.soTimeout = 400
                    val group = InetAddress.getByName("239.255.255.250")
                    for (types in listOf("dn:NetworkVideoTransmitter", "tds:Device", "")) {
                        val typesXml = if (types.isEmpty()) "" else "<d:Types>$types</d:Types>"
                        val probe = """<?xml version="1.0" encoding="UTF-8"?><e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl" xmlns:tds="http://www.onvif.org/ver10/device/wsdl"><e:Header><w:MessageID>uuid:${UUID.randomUUID()}</w:MessageID><w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To><w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header><e:Body><d:Probe>$typesXml</d:Probe></e:Body></e:Envelope>"""
                        val b = probe.toByteArray()
                        try { sock.send(DatagramPacket(b, b.size, group, 3702)) } catch (_: Exception) {}
                    }
                    val end = System.currentTimeMillis() + 3000
                    val buf = ByteArray(16384)
                    while (System.currentTimeMillis() < end) {
                        try {
                            val p = DatagramPacket(buf, buf.size)
                            sock.receive(p)
                            val ip = p.address.hostAddress ?: continue
                            val xml = String(p.data, 0, p.length)
                            val x = NetUtil.xmlTag(xml, "XAddrs") ?: ""
                            val s = NetUtil.xmlTag(xml, "Scopes") ?: ""
                            if (x.isNotEmpty() || s.isNotEmpty()) result[ip] = WsdHit(x, s)
                        } catch (_: SocketTimeoutException) {
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return result
    }

    private fun scopeValue(scopes: String, key: String): String =
        scopes.split(Regex("\\s+")).firstOrNull { it.contains("onvif.org/$key/") }
            ?.substringAfter("onvif.org/$key/")?.let { java.net.URLDecoder.decode(it, "UTF-8") } ?: ""

    // ---------------- HTTP ----------------

    private fun httpProbe(ip: String, port: Int): WebInfo? {
        val https = port in HTTPS_PORTS
        var url = "${if (https) "https" else "http"}://$ip:$port/"
        var first = NetUtil.get(url, mapOf("User-Agent" to UA))
        if (first == null && !https && port != 8000) {
            // некоторые панели слушают HTTPS на нестандартном порту
            val alt = "https://$ip:$port/"
            first = NetUtil.get(alt, mapOf("User-Agent" to UA))
            if (first != null) url = alt
        }
        var r = first ?: return null
        // Одна-две переадресации в пределах того же хоста
        var hops = 0
        while (r.code in 300..399 && hops < 2) {
            val loc = r.header("location") ?: break
            val next = when {
                loc.startsWith("http://") || loc.startsWith("https://") -> if (loc.contains(ip)) loc else break
                loc.startsWith("/") -> url.substringBefore("://") + "://$ip:$port$loc"
                else -> url.substringBeforeLast('/') + "/" + loc
            }
            url = next
            r = NetUtil.get(url, mapOf("User-Agent" to UA)) ?: break
            hops++
        }
        val wa = r.header("www-authenticate")
        val scheme = wa?.substringBefore(' ')?.trim()?.takeIf { it.isNotEmpty() }
        val realm = wa?.let { Regex("realm=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
        val title = TITLE.find(r.body)?.groupValues?.get(1)?.trim()?.replace(Regex("\\s+"), " ") ?: ""
        val login = PASSWORD_INPUT.containsMatchIn(r.body) ||
            Regex("login|signin|авториз|вход|password|passwd", RegexOption.IGNORE_CASE).containsMatchIn(url + " " + title)
        return WebInfo(port, url.startsWith("https"), r.code, title, r.header("server") ?: "", scheme, realm, login,
            r.body.take(12000).lowercase())
    }

    // ---------------- RTSP ----------------

    private fun readRtspHeaders(input: BufferedInputStream): Map<String, String> {
        val buf = ByteArrayOutputStream()
        var last4 = 0
        while (buf.size() < 8192) {
            val b = input.read()
            if (b < 0) break
            buf.write(b)
            last4 = (last4 shl 8) or b
            if (last4 == 0x0D0A0D0A) break
        }
        val lines = buf.toString("UTF-8").split("\r\n")
        val map = LinkedHashMap<String, String>()
        lines.firstOrNull()?.let { map[":status"] = it }
        for (l in lines.drop(1)) {
            val i = l.indexOf(':')
            if (i > 0) {
                val k = l.substring(0, i).trim().lowercase()
                map[k] = (map[k]?.let { "$it, " } ?: "") + l.substring(i + 1).trim()
            }
        }
        return map
    }

    private fun statusOf(h: Map<String, String>): Int =
        h[":status"]?.split(' ')?.getOrNull(1)?.toIntOrNull() ?: 0

    /** OPTIONS + DESCRIBE без учётных данных: только чтение статуса и заголовков, поток не запрашивается. */
    private fun rtspProbe(ip: String, port: Int): RtspInfo? = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, port), 1500)
            s.soTimeout = 2500
            val out = s.getOutputStream()
            val input = BufferedInputStream(s.getInputStream())
            val uri = "rtsp://$ip:$port/"
            out.write("OPTIONS $uri RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: $UA\r\n\r\n".toByteArray()); out.flush()
            val h1 = readRtspHeaders(input)
            val st1 = statusOf(h1)
            h1["content-length"]?.toIntOrNull()?.let { input.skip(it.toLong()) }
            out.write("DESCRIBE $uri RTSP/1.0\r\nCSeq: 2\r\nAccept: application/sdp\r\nUser-Agent: $UA\r\n\r\n".toByteArray()); out.flush()
            val h2 = try { readRtspHeaders(input) } catch (_: Exception) { emptyMap() }
            val st2 = statusOf(h2)
            val wa = h2["www-authenticate"] ?: h1["www-authenticate"]
            val scheme = wa?.let { w ->
                val schemes = Regex("(Digest|Basic)", RegexOption.IGNORE_CASE).findAll(w).map { it.value.lowercase().replaceFirstChar { c -> c.uppercase() } }.toSet()
                schemes.joinToString("+")
            }?.takeIf { it.isNotEmpty() }
            val realm = wa?.let { Regex("realm=\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(it)?.groupValues?.get(1) }
            if (st1 == 0 && st2 == 0) null
            else RtspInfo(port, h1["server"] ?: h2["server"] ?: "", st1, st2, scheme, realm)
        }
    } catch (_: Exception) {
        null
    }

    // ---------------- ONVIF ----------------

    private fun onvifProbe(endpoints: List<String>): OnvifInfo? {
        val body = """<?xml version="1.0" encoding="UTF-8"?><s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"><s:Body><GetDeviceInformation xmlns="http://www.onvif.org/ver10/device/wsdl"/></s:Body></s:Envelope>"""
        for (ep in endpoints.distinct()) {
            val r = NetUtil.post(ep, body, "application/soap+xml; charset=utf-8", mapOf("User-Agent" to UA)) ?: continue
            val text = r.body
            val isOnvif = text.contains("onvif", true) || text.contains("Envelope", true)
            if (!isOnvif && r.code != 401) continue
            val manufacturer = NetUtil.xmlTag(text, "Manufacturer") ?: ""
            val model = NetUtil.xmlTag(text, "Model") ?: ""
            val fw = NetUtil.xmlTag(text, "FirmwareVersion") ?: ""
            val auth = when {
                r.code == 401 || text.contains("NotAuthorized", true) || text.contains("Sender not Authorized", true) -> true
                r.code == 200 && (manufacturer.isNotEmpty() || model.isNotEmpty()) -> false
                else -> null
            }
            return OnvifInfo(ep, manufacturer, model, fw, auth)
        }
        return null
    }

    // ---------------- Классификация ----------------

    private fun fingerprint(
        ip: String,
        open: List<Int>,
        isGateway: Boolean,
        isSelf: Boolean,
        wsd: WsdHit?,
        ssdp: List<com.pultitool.remote.net.SsdpHit>
    ): AuditHost {
        if (isSelf) return AuditHost(ip, "этот телефон", DevType.PHONE, android.os.Build.MANUFACTURER ?: "", android.os.Build.MODEL ?: "",
            open, isSelf = true, findings = emptyList())

        val web = open.filter { it in WEB_PORTS }.mapNotNull { httpProbe(ip, it) }
        val rtsp = open.filter { it in RTSP_PORTS }.mapNotNull { rtspProbe(ip, it) }

        var upnpName = ""
        var upnpManufacturer = ""
        var upnpModel = ""
        var igd = false
        for (h in ssdp) {
            if (h.st.contains("InternetGatewayDevice", true) || h.usn.contains("InternetGatewayDevice", true)) igd = true
            if (upnpName.isEmpty()) h.location?.let { loc ->
                NetUtil.get(loc, mapOf("User-Agent" to UA))?.let { r ->
                    upnpName = NetUtil.xmlTag(r.body, "friendlyName") ?: ""
                    upnpManufacturer = NetUtil.xmlTag(r.body, "manufacturer") ?: ""
                    upnpModel = NetUtil.xmlTag(r.body, "modelName") ?: ""
                    if (r.body.contains("InternetGatewayDevice", true)) igd = true
                }
            }
        }

        val onvifEndpoints = buildList {
            wsd?.xaddrs?.split(Regex("\\s+"))?.filter { it.startsWith("http") && it.contains(ip) }?.let { addAll(it) }
            for (p in listOf(80, 8899, 8080, 8000)) if (p in open && (wsd != null || 554 in open || 8554 in open || 37777 in open || p == 8899)) add("http://$ip:$p/onvif/device_service")
        }
        var onvif = if (onvifEndpoints.isNotEmpty()) onvifProbe(onvifEndpoints) else null
        if (wsd != null) {
            val nm = scopeValue(wsd.scopes, "name"); val hw = scopeValue(wsd.scopes, "hardware")
            onvif = (onvif ?: OnvifInfo(wsd.xaddrs.split(' ').firstOrNull() ?: "", "", "", "", null)).copy(scopesName = nm, scopesHardware = hw)
        }

        // Определение бренда и типа
        val haystack = buildString {
            web.forEach { append(it.title).append(' ').append(it.server).append(' ').append(it.realm ?: "").append(' ').append(it.bodySample).append(' ') }
            rtsp.forEach { append(it.server).append(' ').append(it.realm ?: "").append(' ') }
            append(upnpName).append(' ').append(upnpManufacturer).append(' ').append(upnpModel).append(' ')
            onvif?.let { append(it.manufacturer).append(' ').append(it.model).append(' ').append(it.scopesName).append(' ').append(it.scopesHardware) }
            ssdp.forEach { append(it.server).append(' ') }
        }.lowercase()

        val sig = SIGNATURES.firstOrNull { s -> s.keys.any { haystack.contains(it) } }
        var brand = onvif?.manufacturer?.takeIf { it.isNotBlank() } ?: sig?.brand ?: upnpManufacturer
        var type = sig?.type ?: DevType.OTHER
        if (37777 in open) { type = if (type == DevType.DVR) DevType.DVR else DevType.CAMERA; if (brand.isBlank()) brand = "Dahua (вероятно)" }
        if (34567 in open) { type = DevType.DVR; if (brand.isBlank()) brand = "Xiongmai / XMeye (вероятно)" }
        if (onvif != null || rtsp.isNotEmpty()) {
            if (type != DevType.DVR && type != DevType.CAMERA) type = if (haystack.contains("nvr") || haystack.contains("dvr")) DevType.DVR else DevType.CAMERA
        }
        if (type == DevType.OTHER || type == DevType.ADMIN_PANEL) {
            type = when {
                isGateway -> DevType.ROUTER
                igd -> DevType.ROUTER
                6466 in open || 8001 in open || 8060 in open || 8008 in open || (3000 in open && haystack.contains("webos")) -> DevType.TV
                9100 in open || 631 in open -> DevType.PRINTER
                8123 in open -> DevType.SMART_HOME
                3389 in open || 22 in open || 445 in open -> DevType.COMPUTER
                web.isNotEmpty() -> DevType.ADMIN_PANEL
                else -> DevType.OTHER
            }
        }
        if (isGateway && type != DevType.ROUTER && type != DevType.CAMERA) type = DevType.ROUTER
        val model = onvif?.model?.takeIf { it.isNotBlank() } ?: onvif?.scopesHardware?.takeIf { it.isNotBlank() } ?: upnpModel
        if (brand.isBlank() && type == DevType.ROUTER) brand = web.firstOrNull { it.title.isNotBlank() }?.title ?: ""

        val hostname = try {
            val h = InetAddress.getByName(ip).canonicalHostName
            if (h == ip) "" else h
        } catch (_: Exception) { "" }

        val host = AuditHost(ip, hostname, type, brand, model, open, web, rtsp, onvif, upnpName, emptyList(), isGateway, false)
        return host.copy(findings = findings(host, igd))
    }

    private fun findings(h: AuditHost, igd: Boolean): List<Finding> {
        val f = mutableListOf<Finding>()
        val isCam = h.type == DevType.CAMERA || h.type == DevType.DVR
        val p = h.openPorts

        for (r in h.rtsp) {
            when {
                r.describeStatus in 200..299 -> f += Finding(Severity.CRITICAL, "RTSP-поток доступен без пароля (порт ${r.port})",
                    "Запрос DESCRIBE без учётных данных получил ответ ${r.describeStatus}. Любой в сети может смотреть видео.",
                    "Включите обязательную аутентификацию RTSP (Digest) в настройках камеры/регистратора, задайте уникальный сложный пароль, отключите RTSP, если он не используется, и не пробрасывайте порт ${r.port} в интернет.")
                r.authScheme == "Basic" -> f += Finding(Severity.MEDIUM, "RTSP использует только Basic-аутентификацию",
                    "Пароль к видеопотоку передаётся в открытом виде (Base64) по сети. Realm: ${r.realm ?: "—"}",
                    "Переключите RTSP на Digest-аутентификацию в настройках безопасности устройства и обновите прошивку.")
                r.describeStatus == 401 || r.optionsStatus == 401 -> f += Finding(Severity.INFO, "RTSP защищён паролем (порт ${r.port})",
                    "Сервер требует аутентификацию (${r.authScheme ?: "схема не указана"}).",
                    "Убедитесь, что пароль не заводской и уникален; ограничьте доступ к порту ${r.port} только локальной сетью.")
                else -> f += Finding(Severity.LOW, "Открыт RTSP-сервис (порт ${r.port})",
                    "Ответ сервера: OPTIONS ${r.optionsStatus}, DESCRIBE ${r.describeStatus}. Требуется ли пароль для конкретных путей, определить не удалось.",
                    "Проверьте в настройках устройства, что RTSP требует аутентификацию, и отключите его, если он не нужен.")
            }
        }
        h.onvif?.let { o ->
            if (o.authRequired == false) f += Finding(Severity.MEDIUM, "ONVIF выдаёт сведения без пароля",
                "GetDeviceInformation вернул данные без аутентификации: ${listOf(o.manufacturer, o.model, o.firmware).filter { it.isNotBlank() }.joinToString(" / ")}.",
                "Включите проверку подлинности ONVIF (режим Digest/WS-UsernameToken) или отключите ONVIF, если NVR его не использует. Создайте отдельного ONVIF-пользователя с ограниченными правами.")
            else if (o.authRequired == true) f += Finding(Severity.INFO, "ONVIF требует аутентификацию", "Сервис ONVIF: ${o.endpoint}", "Используйте отдельную учётную запись ONVIF с уникальным паролем.")
        }
        if (34567 in p) f += Finding(Severity.HIGH, "Служба XMeye/NETSurveillance (порт 34567)",
            "Этот сервис известен многочисленными уязвимостями и облачным P2P-доступом.",
            "Обновите прошивку, отключите облако/P2P (XMeye Cloud), смените заводской пароль, вынесите регистратор в изолированную сеть и не пробрасывайте порт 34567 на роутере.")
        if (37777 in p) f += Finding(Severity.MEDIUM, "Сервис Dahua (порт 37777)",
            "Открыт фирменный протокол Dahua для клиентских программ (SmartPSS/DMSS).",
            "Обновите прошивку, отключите P2P/Easy4ip, если не нужен, используйте сложный пароль и не публикуйте порт 37777 в интернет.")
        if (8000 in p && h.brand.contains("Hikvision", true)) f += Finding(Severity.LOW, "Сервис Hikvision SDK (порт 8000)",
            "Открыт порт для iVMS-4200/Hik-Connect.", "Отключите Hik-Connect/облако, если не используется; не пробрасывайте порт 8000 на роутере; обновите прошивку.")
        if (23 in p) f += Finding(Severity.HIGH, "Открыт Telnet (порт 23)",
            "Telnet передаёт логин и пароль без шифрования и часто имеет заводские учётные записи.",
            "Отключите Telnet в настройках устройства (или обновите прошивку). Для администрирования используйте SSH или веб-интерфейс по HTTPS.")
        if (21 in p) f += Finding(Severity.MEDIUM, "Открыт FTP (порт 21)", "FTP передаёт пароли открытым текстом.",
            "Отключите FTP или замените на SFTP/FTPS; проверьте, не включён ли анонимный доступ.")
        if (3389 in p) f += Finding(Severity.MEDIUM, "Открыт удалённый рабочий стол RDP (порт 3389)", "Доступ к компьютеру по RDP.",
            "Включите проверку подлинности на уровне сети (NLA), используйте сложный пароль, не пробрасывайте 3389 в интернет.")
        if (445 in p || 139 in p) f += Finding(Severity.LOW, "Общий доступ к файлам SMB", "Открыты порты ${listOf(139, 445).filter { it in p }.joinToString()}.",
            "Отключите SMBv1, закройте гостевой доступ к общим папкам, установите обновления ОС.")
        if (1883 in p) f += Finding(Severity.MEDIUM, "MQTT без TLS (порт 1883)", "Брокер умного дома доступен без шифрования.",
            "Включите аутентификацию на MQTT-брокере, по возможности используйте TLS (порт 8883) и ACL.")

        for (w in h.web) {
            val adminLike = isCam || h.type == DevType.ROUTER || h.type == DevType.NAS || h.type == DevType.ADMIN_PANEL || h.type == DevType.SMART_HOME
            if (w.status in 200..299 && !w.authRequired && adminLike) f += Finding(if (isCam) Severity.HIGH else Severity.MEDIUM,
                "Веб-интерфейс без явного запроса пароля (порт ${w.port})",
                "Страница «${w.title.ifBlank { "без заголовка" }}» открылась без аутентификации и формы входа (вход может выполняться скриптом — проверьте вручную).",
                "Откройте http${if (w.https) "s" else ""}://${h.ip}:${w.port}/ и убедитесь, что без пароля нельзя изменить настройки. Задайте пароль администратора и обновите прошивку.")
            if (!w.https && w.authScheme.equals("Basic", true)) f += Finding(Severity.MEDIUM, "Basic-аутентификация по HTTP (порт ${w.port})",
                "Пароль передаётся по сети без шифрования. Realm: ${w.realm ?: "—"}",
                "Включите HTTPS в настройках устройства или используйте Digest; используйте уникальный пароль.")
            else if (!w.https && w.loginForm && adminLike && h.web.none { it.https }) f += Finding(Severity.LOW, "Панель входа только по HTTP (порт ${w.port})",
                "Форма входа «${w.title.ifBlank { "—" }}» доступна без шифрования TLS.",
                "Включите HTTPS для веб-интерфейса (если поддерживается) и отключите HTTP; не открывайте панель управления из интернета.")
        }
        if (igd && (h.type == DevType.ROUTER || h.isGateway)) f += Finding(Severity.MEDIUM, "UPnP IGD включён на роутере",
            "Любое устройство в сети (включая камеры и заражённые IoT) может само открыть порты в интернет.",
            "Отключите UPnP в настройках роутера, если он не нужен (игровые приставки/торренты), и проверьте список проброшенных портов.")
        if (h.type == DevType.ROUTER && h.web.isNotEmpty()) f += Finding(Severity.INFO, "Панель управления роутером",
            "Обнаружен веб-интерфейс администрирования.",
            "Смените заводской пароль администратора, отключите удалённое управление из WAN, WPS и обновите прошивку роутера.")
        if (isCam) f += Finding(Severity.INFO, "Камера видеонаблюдения в общей сети",
            "Камеры и регистраторы — частая цель атак.",
            "Вынесите камеры в отдельную гостевую/IoT-сеть или VLAN, запретите им доступ в интернет, если облако не нужно, регулярно обновляйте прошивку.")
        if (f.isEmpty()) f += Finding(Severity.INFO, "Явных проблем не обнаружено",
            if (p.isEmpty()) "Устройство отвечает, но проверяемые порты закрыты." else "Открытые порты: ${p.joinToString { "$it (${portName(it)})" }}.",
            "Поддерживайте прошивку в актуальном состоянии.")
        return f.sortedByDescending { it.severity.weight }
    }
}

/** Текстовый отчёт для экспорта. */
fun buildAuditReport(hosts: List<AuditHost>, net: String): String = buildString {
    appendLine("Пульт Тул — отчёт аудита собственной сети")
    appendLine("Сеть: $net · Устройств: ${hosts.size} · ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.forLanguageTag("ru")).format(java.util.Date())}")
    appendLine("Режим: только чтение (без подбора паролей и захвата потоков)")
    appendLine()
    for (h in hosts.sortedByDescending { it.maxSeverity.weight }) {
        appendLine("■ ${h.ip}${if (h.hostname.isNotBlank()) " (${h.hostname})" else ""} — ${h.type.title}")
        val bm = listOf(h.brand, h.model).filter { it.isNotBlank() }.joinToString(" ")
        if (bm.isNotBlank()) appendLine("  Устройство: $bm")
        if (h.openPorts.isNotEmpty()) appendLine("  Порты: ${h.openPorts.joinToString { "$it/${portName(it)}" }}")
        if (h.authSummary.isNotBlank()) appendLine("  Доступ: ${h.authSummary}")
        for (f in h.findings) {
            appendLine("  [${f.severity.title}] ${f.title}")
            appendLine("    ${f.detail}")
            appendLine("    Что сделать: ${f.advice}")
        }
        appendLine()
    }
}
