package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.util.Achievements

@Composable
fun AchievementsScreen(vm: AppViewModel) {
    val unlocked by Achievements.unlocked.collectAsState()
    val total = Achievements.all.size
    ToolScaffold("Достижения", "Открыто ${unlocked.size} из $total", onBack = { vm.back() }) {
        Row(Modifier.fillMaxWidth().glass().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            ScoreRing((unlocked.size * 100) / total, 96.dp, "%")
            Column(Modifier.padding(start = 16.dp)) {
                Text(when {
                    unlocked.size == total -> "Легенда сети 👑"
                    unlocked.size >= total * 2 / 3 -> "Сетевой гуру"
                    unlocked.size >= total / 3 -> "Опытный пользователь"
                    else -> "Новичок"
                }, color = Pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Пользуйтесь пультом и сетевыми инструментами, чтобы открыть все награды", color = Pal.textDim, fontSize = 12.sp)
            }
        }
        Achievements.all.sortedByDescending { unlocked.containsKey(it.id) }.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { a ->
                    val got = unlocked[a.id]
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                            .background(if (got != null) Brush.linearGradient(listOf(Color(0x55FFC542), Color(0x22FF6E40))) else Brush.linearGradient(listOf(Color(0x14FFFFFF), Color(0x0AFFFFFF))))
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(54.dp).clip(RoundedCornerShape(27.dp)).background(if (got != null) Color(0x33FFFFFF) else Color(0x11FFFFFF)), contentAlignment = Alignment.Center) {
                            Text(if (got != null) a.emoji else "🔒", fontSize = 26.sp, modifier = Modifier.alpha(if (got != null) 1f else 0.6f))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(a.title, color = if (got != null) Pal.text else Pal.textDim, fontWeight = FontWeight.Bold, fontSize = 13.sp, textAlign = TextAlign.Center)
                        Text(a.description, color = Pal.textDim, fontSize = 11.sp, textAlign = TextAlign.Center)
                        if (got != null) Text(fmtTime(got, "dd.MM.yyyy"), color = Pal.yellow, fontSize = 10.sp)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
