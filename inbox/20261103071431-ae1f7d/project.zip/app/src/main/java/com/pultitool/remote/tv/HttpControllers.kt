package com.pultitool.remote.tv

import android.content.Context
import android.util.Base64
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

/** Roku External Control Protocol: HTTP POST на порт 8060. */
class RokuController(context: Context, d: TvDevice) : TvController(context, d) {
    private val base get() = "http://${device.ip}:8060"

    private fun keyName(k: RKey): String? = when (k) {
        RKey.POWER -> "Power"; RKey.UP -> "Up"; RKey.DOWN -> "Down"; RKey.LEFT -> "Left"; RKey.RIGHT -> "Right"
        RKey.OK -> "Select"; RKey.BACK -> "Back"; RKey.HOME -> "Home"; RKey.MENU -> "Info"
        RKey.VOL_UP -> "VolumeUp"; RKey.VOL_DOWN -> "VolumeDown"; RKey.MUTE -> "VolumeMute"
        RKey.CH_UP -> "ChannelUp"; RKey.CH_DOWN -> "ChannelDown"
        RKey.PLAY_PAUSE, RKey.PLAY, RKey.PAUSE -> "Play"; RKey.STOP -> "Back"
        RKey.REWIND -> "Rev"; RKey.FAST_FORWARD -> "Fwd"; RKey.PREV -> "InstantReplay"; RKey.NEXT -> "Fwd"
        RKey.INPUT -> "InputHDMI1"; RKey.INFO -> "Info"; RKey.SETTINGS -> "Info"; RKey.EXIT -> "Home"
        RKey.GUIDE -> "Info"; RKey.SEARCH -> "Search"; RKey.DEL -> "Backspace"; RKey.ENTER -> "Enter"
        RKey.D0, RKey.D1, RKey.D2, RKey.D3, RKey.D4, RKey.D5, RKey.D6, RKey.D7, RKey.D8, RKey.D9 ->
            "Lit_" + (k.ordinal - RKey.D0.ordinal)
        RKey.RED, RKey.GREEN, RKey.YELLOW, RKey.BLUE -> null
    }

    override fun builtinApps() = listOf(
        AppShortcut("YouTube", "837", AppColors.YOUTUBE),
        AppShortcut("Netflix", "12", AppColors.NETFLIX),
        AppShortcut("Prime Video", "13", AppColors.PRIME),
        AppShortcut("Disney+", "291097", AppColors.DISNEY),
        AppShortcut("Spotify", "22297", AppColors.SPOTIFY),
        AppShortcut("Plex", "13535", AppColors.PLEX),
        AppShortcut("Twitch", "50539", AppColors.TWITCH)
    )

    override suspend fun connect() = withContext(Dispatchers.IO) {
        _state.value = ConnState.Connecting("Проверка Roku…")
        val r = NetUtil.get("$base/query/device-info")
        if (r != null && r.code == 200) {
            val name = NetUtil.xmlTag(r.body, "user-device-name") ?: NetUtil.xmlTag(r.body, "friendly-device-name") ?: ""
            val mac = NetUtil.xmlTag(r.body, "wifi-mac") ?: NetUtil.xmlTag(r.body, "ethernet-mac") ?: ""
            if (mac.isNotEmpty() && device.mac.isEmpty()) updateDevice(device.copy(mac = mac.uppercase()))
            _state.value = ConnState.Connected(name)
        } else _state.value = ConnState.Error("Roku не отвечает на порту 8060")
    }

    override fun disconnect() { _state.value = ConnState.Idle }

    private fun post(path: String) {
        val r = NetUtil.post("$base$path", "", "text/plain")
        if (r == null) _state.value = ConnState.Error("Roku не отвечает")
        else if (_state.value !is ConnState.Connected) _state.value = ConnState.Connected()
    }

    override suspend fun sendKey(key: RKey, longPress: Boolean) = withContext(Dispatchers.IO) {
        val k = keyName(key) ?: return@withContext
        if (longPress) { post("/keydown/$k"); delay(700); post("/keyup/$k") } else post("/keypress/$k")
    }

    override suspend fun sendText(text: String) = withContext(Dispatchers.IO) {
        for (ch in text) post("/keypress/Lit_" + URLEncoder.encode(ch.toString(), "UTF-8"))
    }

    override suspend fun launchApp(app: AppShortcut) = withContext(Dispatchers.IO) { post("/launch/${app.id}") }

    override val supportsYouTube = true

    override suspend fun openYouTube(videoId: String): Boolean = withContext(Dispatchers.IO) {
        val r = NetUtil.post("$base/launch/837?contentId=${URLEncoder.encode(videoId, "UTF-8")}&mediaType=movie", "", "text/plain")
        r != null && r.code in 200..299
    }
}

/** Philips JointSpace (порт 1925, HTTP, API v1/v6 без авторизации на старых моделях). */
class PhilipsController(context: Context, d: TvDevice) : TvController(context, d) {
    @Volatile private var apiVersion = "1"

    private fun keyName(k: RKey): String? = when (k) {
        RKey.POWER -> "Standby"; RKey.UP -> "CursorUp"; RKey.DOWN -> "CursorDown"; RKey.LEFT -> "CursorLeft"
        RKey.RIGHT -> "CursorRight"; RKey.OK -> "Confirm"; RKey.BACK -> "Back"; RKey.HOME -> "Home"
        RKey.MENU -> "Options"; RKey.VOL_UP -> "VolumeUp"; RKey.VOL_DOWN -> "VolumeDown"; RKey.MUTE -> "Mute"
        RKey.CH_UP -> "ChannelStepUp"; RKey.CH_DOWN -> "ChannelStepDown"
        RKey.D0, RKey.D1, RKey.D2, RKey.D3, RKey.D4, RKey.D5, RKey.D6, RKey.D7, RKey.D8, RKey.D9 ->
            "Digit" + (k.ordinal - RKey.D0.ordinal)
        RKey.PLAY_PAUSE -> "PlayPause"; RKey.PLAY -> "Play"; RKey.PAUSE -> "Pause"; RKey.STOP -> "Stop"
        RKey.REWIND -> "Rewind"; RKey.FAST_FORWARD -> "FastForward"; RKey.PREV -> "Previous"; RKey.NEXT -> "Next"
        RKey.INPUT -> "Source"; RKey.INFO -> "Info"; RKey.SETTINGS -> "Adjust"; RKey.EXIT -> "Back"
        RKey.GUIDE -> "Find"; RKey.SEARCH -> "Find"
        RKey.RED -> "RedColour"; RKey.GREEN -> "GreenColour"; RKey.YELLOW -> "YellowColour"; RKey.BLUE -> "BlueColour"
        RKey.DEL -> null; RKey.ENTER -> "Confirm"
    }

    override val supportsText = false
    override fun builtinApps() = emptyList<AppShortcut>()

    override suspend fun connect() = withContext(Dispatchers.IO) {
        _state.value = ConnState.Connecting("Проверка Philips…")
        for (v in listOf("6", "5", "1")) {
            val r = NetUtil.get("http://${device.ip}:1925/$v/system")
            if (r != null && r.code == 200) {
                apiVersion = v
                val name = try { JSONObject(r.body).optString("name") } catch (_: Exception) { "" }
                _state.value = ConnState.Connected("JointSpace v$v $name".trim())
                return@withContext
            }
        }
        _state.value = ConnState.Error("Philips не отвечает на порту 1925 (для моделей 2016+ с Android TV используйте протокол Android TV)")
    }

    override fun disconnect() { _state.value = ConnState.Idle }

    override suspend fun sendKey(key: RKey, longPress: Boolean) = withContext(Dispatchers.IO) {
        val k = keyName(key) ?: return@withContext
        val r = NetUtil.post("http://${device.ip}:1925/$apiVersion/input/key", JSONObject().put("key", k).toString(), "application/json")
        if (r == null) _state.value = ConnState.Error("Philips не отвечает")
    }
}

/** Sony Bravia: IRCC по SOAP (порт 80) с предварительным общим ключом (PSK). */
class SonyController(context: Context, d: TvDevice) : TvController(context, d) {

    companion object {
        fun ircc(a: Int, b: Int, c: Int): String {
            val bytes = byteArrayOf(0, 0, 0, a.toByte(), 0, 0, 0, b.toByte(), 0, 0, 0, c.toByte(), 3)
            return Base64.encodeToString(bytes, Base64.NO_WRAP)
        }

        fun code(k: RKey): String = when (k) {
            RKey.POWER -> ircc(1, 1, 0x15); RKey.VOL_UP -> ircc(1, 1, 0x12); RKey.VOL_DOWN -> ircc(1, 1, 0x13)
            RKey.MUTE -> ircc(1, 1, 0x14); RKey.CH_UP -> ircc(1, 1, 0x10); RKey.CH_DOWN -> ircc(1, 1, 0x11)
            RKey.UP -> ircc(1, 1, 0x74); RKey.DOWN -> ircc(1, 1, 0x75); RKey.LEFT -> ircc(1, 1, 0x34)
            RKey.RIGHT -> ircc(1, 1, 0x33); RKey.OK, RKey.ENTER -> ircc(1, 1, 0x65); RKey.HOME, RKey.MENU -> ircc(1, 1, 0x60)
            RKey.BACK, RKey.EXIT -> ircc(2, 0x97, 0x23); RKey.SETTINGS -> ircc(2, 0x97, 0x36)
            RKey.D1 -> ircc(1, 1, 0); RKey.D2 -> ircc(1, 1, 1); RKey.D3 -> ircc(1, 1, 2); RKey.D4 -> ircc(1, 1, 3)
            RKey.D5 -> ircc(1, 1, 4); RKey.D6 -> ircc(1, 1, 5); RKey.D7 -> ircc(1, 1, 6); RKey.D8 -> ircc(1, 1, 7)
            RKey.D9 -> ircc(1, 1, 8); RKey.D0 -> ircc(1, 1, 9)
            RKey.PLAY, RKey.PLAY_PAUSE -> ircc(2, 0x97, 0x1A); RKey.PAUSE -> ircc(2, 0x97, 0x19)
            RKey.STOP -> ircc(2, 0x97, 0x18); RKey.REWIND -> ircc(2, 0x97, 0x1B); RKey.FAST_FORWARD -> ircc(2, 0x97, 0x1C)
            RKey.PREV -> ircc(2, 0x97, 0x3C); RKey.NEXT -> ircc(2, 0x97, 0x3D)
            RKey.INPUT -> ircc(1, 1, 0x25); RKey.INFO -> ircc(1, 1, 0x3A); RKey.GUIDE -> ircc(2, 0xA4, 0x5B)
            RKey.SEARCH -> ircc(2, 0x97, 0x36); RKey.DEL -> ircc(2, 0x97, 0x23)
            RKey.RED -> ircc(2, 0x97, 0x25); RKey.GREEN -> ircc(2, 0x97, 0x26)
            RKey.YELLOW -> ircc(2, 0x97, 0x27); RKey.BLUE -> ircc(2, 0x97, 0x24)
        }
    }

    override val supportsText = false
    override fun builtinApps() = listOf(AppShortcut("Netflix", ircc(2, 0x1A, 0x7C), AppColors.NETFLIX))

    override suspend fun connect() = withContext(Dispatchers.IO) {
        if (device.psk.isEmpty()) {
            _state.value = ConnState.NeedCode("Введите PSK: на ТВ Настройки → Сеть → Домашняя сеть → Управление IP → Pre-Shared Key", "psk")
            return@withContext
        }
        _state.value = ConnState.Connecting("Проверка Sony…")
        val r = NetUtil.post("http://${device.ip}/sony/system",
            """{"method":"getPowerStatus","id":50,"params":[],"version":"1.0"}""", "application/json",
            mapOf("X-Auth-PSK" to device.psk))
        when {
            r == null -> _state.value = ConnState.Error("Sony не отвечает по HTTP (порт 80)")
            r.code == 403 || r.body.contains("[40") ->
                _state.value = ConnState.NeedCode("PSK не подошёл. Проверьте ключ в настройках ТВ", "psk")
            else -> _state.value = ConnState.Connected(if (r.body.contains("active")) "ТВ включён" else "Подключено")
        }
    }

    override suspend fun submitCode(code: String) {
        updateDevice(device.copy(psk = code.trim(), paired = true))
        connect()
    }

    override fun disconnect() { _state.value = ConnState.Idle }

    private fun sendIrcc(c: String) {
        val body = """<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:X_SendIRCC xmlns:u="urn:schemas-sony-com:service:IRCC:1"><IRCCCode>$c</IRCCCode></u:X_SendIRCC></s:Body></s:Envelope>"""
        val r = NetUtil.post("http://${device.ip}/sony/IRCC", body, "text/xml; charset=UTF-8",
            mapOf("SOAPACTION" to "\"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC\"", "X-Auth-PSK" to device.psk))
        if (r == null) _state.value = ConnState.Error("Sony не отвечает")
        else if (r.code == 403) _state.value = ConnState.NeedCode("PSK отклонён телевизором", "psk")
    }

    override suspend fun sendKey(key: RKey, longPress: Boolean) = withContext(Dispatchers.IO) { sendIrcc(code(key)) }

    override suspend fun launchApp(app: AppShortcut) = withContext(Dispatchers.IO) { sendIrcc(app.id) }

    override val supportsUrl = true
    override val supportsYouTube = true

    /** Bravia REST API: appControl.setActiveApp открывает встроенный веб-браузер ТВ. */
    override suspend fun openUrl(url: String): Boolean = withContext(Dispatchers.IO) {
        val payload = org.json.JSONObject().put("method", "setActiveApp").put("id", 601).put("version", "1.0")
            .put("params", org.json.JSONArray().put(org.json.JSONObject().put("uri", "localapp://webappruntime?url=" + URLEncoder.encode(url, "UTF-8"))))
        val r = NetUtil.post("http://${device.ip}/sony/appControl", payload.toString(), "application/json", mapOf("X-Auth-PSK" to device.psk))
        r != null && r.code in 200..299 && !r.body.contains("\"error\"")
    }

    override suspend fun openYouTube(videoId: String): Boolean = openUrl("https://www.youtube.com/tv#/watch?v=$videoId")
}
