package com.pultitool.remote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel

@Composable
fun PingScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.ping.collectAsState()
    val stats = st.stats
    val net = vm.localNet()
    val presets = buildList {
        net?.gateway?.let { add("Роутер" to it) }
        add("Google DNS" to "8.8.8.8")
        add("Cloudflare" to "1.1.1.1")
        add("Яндекс" to "ya.ru")
        vm.controller.value?.device?.let { add("ТВ" to it.ip) }
    }

    ToolScaffold("Пинг", "Задержка, джиттер и потери в реальном времени", onBack = { tools.stopPing(); vm.back() }) {
        ToolField(st.host, { v -> tools.setPing { it.copy(host = v) } }, "Хост или IP", onGo = { tools.startPing() })
        ChipRow(presets.map { it.first }) { i -> tools.setPing { it.copy(host = presets[i].second) } }
        GlassCard(Modifier.fillMaxWidth()) {
            ToggleRow("Непрерывный режим", st.continuous, "Пинговать, пока не остановите") { v -> tools.setPing { it.copy(continuous = v) } }
            if (!st.continuous) {
                Text("Количество: ${st.count}", color = Pal.textDim, fontSize = 12.sp)
                Slider(st.count.toFloat(), { v -> tools.setPing { it.copy(count = v.toInt()) } }, valueRange = 5f..100f, enabled = !st.running)
            }
            Text("Интервал: ${st.intervalMs} мс", color = Pal.textDim, fontSize = 12.sp)
            Slider(st.intervalMs.toFloat(), { v -> tools.setPing { it.copy(intervalMs = (v / 100).toLong() * 100) } }, valueRange = 200f..3000f, enabled = !st.running)
        }
        if (st.running) GhostButton("Остановить", Modifier.fillMaxWidth()) { tools.stopPing() }
        else GradientButton("Запустить пинг", Modifier.fillMaxWidth(), Glyph.PULSE) { tools.startPing() }
        ErrorText(st.error)

        if (st.samples.isNotEmpty() || st.running) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (st.resolved.isNotEmpty() && st.resolved != st.host) "${st.host} → ${st.resolved}" else st.host,
                    color = Pal.textDim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                val last = st.samples.lastOrNull()
                if (last != null) Chip(last.method, LocalAccent.current.b)
            }
            LatencyChart(st.samples.map { it.rttMs })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("%.1f".format(stats.min), "мин, мс", Modifier.weight(1f), latencyColor(stats.min))
                MiniStat("%.1f".format(stats.avg), "сред, мс", Modifier.weight(1f), latencyColor(stats.avg))
                MiniStat("%.1f".format(stats.max), "макс, мс", Modifier.weight(1f), latencyColor(stats.max))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("%.1f".format(stats.jitter), "джиттер, мс", Modifier.weight(1f), if (stats.jitter < 10) Pal.green else Pal.yellow)
                MiniStat("%.0f%%".format(stats.lossPercent), "потери", Modifier.weight(1f), if (stats.lossPercent == 0.0) Pal.green else Pal.red)
                MiniStat("${stats.received}/${stats.sent}", "ответов", Modifier.weight(1f))
            }
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Качество связи", color = Pal.text, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                val verdict = when {
                    stats.received == 0 -> "Хост не отвечает (ICMP может быть заблокирован)"
                    stats.lossPercent > 5 -> "Заметные потери пакетов — возможны обрывы видео и лаги"
                    stats.avg < 30 && stats.jitter < 10 -> "Отлично — подходит для игр и видеозвонков"
                    stats.avg < 80 -> "Хорошо — комфортно для стриминга и звонков"
                    stats.avg < 150 -> "Средне — возможны задержки в онлайн-играх"
                    else -> "Высокая задержка — проверьте Wi-Fi или канал провайдера"
                }
                Text(verdict, color = Pal.textDim, fontSize = 13.sp)
            }
            GlassCard(Modifier.fillMaxWidth()) {
                st.samples.takeLast(8).reversed().forEach { s ->
                    Row(Modifier.fillMaxWidth()) {
                        Text("#${s.seq}", color = Pal.textDim, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.width(52.dp))
                        Text(s.rttMs?.let { "%.1f мс".format(it) } ?: "таймаут", color = latencyColor(s.rttMs), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Text(s.ttl?.let { "ttl=$it" } ?: s.method, color = Pal.textDim, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
