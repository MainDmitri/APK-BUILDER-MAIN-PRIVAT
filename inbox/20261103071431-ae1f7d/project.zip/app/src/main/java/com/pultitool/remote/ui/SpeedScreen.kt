package com.pultitool.remote.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.tools.SpeedPhase

@Composable
fun SpeedScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.speed.collectAsState()
    val last by tools.lastSpeed.collectAsState()
    val running = st.phase in listOf(SpeedPhase.PING, SpeedPhase.DOWNLOAD, SpeedPhase.UPLOAD)

    ToolScaffold("Тест скорости", st.server.ifEmpty { "speed.cloudflare.com" }, onBack = { if (running) tools.stopSpeed(); vm.back() }) {
        SpeedGauge(st.currentMbps, st.phase.title)
        if (running) ProgressLine(if (st.phase == SpeedPhase.PING) 0f else st.progress, "${st.phase.title}…")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniStat(if (st.downMbps > 0) "%.1f".format(st.downMbps) else "—", "↓ Мбит/с", Modifier.weight(1f), Pal.green)
            MiniStat(if (st.upMbps > 0) "%.1f".format(st.upMbps) else "—", "↑ Мбит/с", Modifier.weight(1f), LocalAccent.current.b)
            MiniStat(if (st.pingMs > 0) "%.0f".format(st.pingMs) else "—", "пинг, мс", Modifier.weight(1f), latencyColor(st.pingMs.takeIf { it > 0 }))
        }
        if (running) GhostButton("Остановить", Modifier.fillMaxWidth()) { tools.stopSpeed() }
        else GradientButton(if (st.phase == SpeedPhase.DONE) "Повторить тест" else "Начать тест", Modifier.fillMaxWidth(), Glyph.SPEED) { tools.startSpeed() }
        st.error?.let { ErrorText(it) }

        if (st.latency.isNotEmpty()) GlassCard(Modifier.fillMaxWidth()) {
            Text("Задержка (TCP 443)", color = Pal.text, fontWeight = FontWeight.Bold)
            st.latency.forEach { l ->
                InfoRow(l.target, if (l.lost >= 5) "недоступен" else "мин %.0f · ср %.0f · джиттер %.1f мс".format(l.minMs, l.avgMs, l.jitterMs))
            }
        }
        if (st.downSeries.size > 2) GlassCard(Modifier.fillMaxWidth()) {
            Text("Загрузка во времени", color = Pal.textDim, fontSize = 12.sp)
            Sparkline(st.downSeries, Pal.green)
            if (st.upSeries.size > 2) {
                Text("Отдача во времени", color = Pal.textDim, fontSize = 12.sp)
                Sparkline(st.upSeries, LocalAccent.current.b)
            }
            InfoRow("Получено", "%.1f МБ".format(st.bytesDown / 1e6))
            InfoRow("Отправлено", "%.1f МБ".format(st.bytesUp / 1e6))
        }
        if (st.phase == SpeedPhase.DONE) GlassCard(Modifier.fillMaxWidth()) {
            Text("Чего хватит", color = Pal.text, fontWeight = FontWeight.Bold)
            val d = st.downMbps
            listOf(
                "4K-стриминг (25 Мбит/с)" to (d >= 25),
                "Full HD видео (8 Мбит/с)" to (d >= 8),
                "Видеозвонки HD (4 Мбит/с)" to (d >= 4 && st.upMbps >= 2),
                "Онлайн-игры (пинг < 60 мс)" to (st.pingMs in 0.1..60.0),
                "Несколько 4K-потоков (100 Мбит/с)" to (d >= 100)
            ).forEach { (t, ok) -> Text((if (ok) "✓ " else "✕ ") + t, color = if (ok) Pal.green else Pal.textDim, fontSize = 13.sp) }
        }
        last?.let { l ->
            if (st.phase != SpeedPhase.DONE) Text("Прошлый тест (${fmtTime(l.time)}): ↓ %.1f · ↑ %.1f Мбит/с · %.0f мс".format(l.downMbps, l.upMbps, l.pingMs),
                color = Pal.textDim, fontSize = 12.sp)
        }
        Text("Тест расходует трафик (~50–300 МБ при быстром канале). Результат зависит от Wi-Fi и загрузки сети.", color = Pal.textDim, fontSize = 11.sp)
    }
}
