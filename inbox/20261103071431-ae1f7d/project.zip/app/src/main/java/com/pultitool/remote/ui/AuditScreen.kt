package com.pultitool.remote.ui

import android.content.Intent
import com.pultitool.remote.util.FileExport
import kotlinx.coroutines.launch
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.rememberLauncherForActivityResult
import android.Manifest
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.audit.AuditHost
import com.pultitool.remote.audit.DevType
import com.pultitool.remote.audit.Finding
import com.pultitool.remote.audit.Severity
import com.pultitool.remote.audit.buildAuditReport
import com.pultitool.remote.audit.portName

private enum class AuditFilter(val title: String) { ALL("Все"), ISSUES("С проблемами"), CAMERAS("Камеры/DVR"), PANELS("Веб-панели"), ROUTERS("Роутеры") }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AuditScreen(vm: AppViewModel) {
    val audit by vm.audit.collectAsState()
    val context = LocalContext.current
    val net = remember { vm.localNet() }
    var consent by remember { mutableStateOf(vm.auditConsent) }
    var filter by remember { mutableStateOf(AuditFilter.ALL) }
    val scope = rememberCoroutineScope()
    var saved by remember { mutableStateOf<String?>(null) }
    val doSave: () -> Unit = {
        scope.launch {
            try { saved = "Сохранено: " + vm.saveAuditReport() }
            catch (e: Exception) { saved = "Не удалось сохранить: ${e.message}" }
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) doSave() else saved = "Нет доступа к хранилищу"
    }
    val exportRun: () -> Unit = {
        if (FileExport.needsLegacyPermission)
            permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else doSave()
    }
    LaunchedEffect(saved) { saved?.let { vm.message(it); saved = null } }

    val hosts = audit.hosts.filter { h ->
        when (filter) {
            AuditFilter.ALL -> true
            AuditFilter.ISSUES -> h.findings.any { it.severity.weight >= Severity.MEDIUM.weight }
            AuditFilter.CAMERAS -> h.type == DevType.CAMERA || h.type == DevType.DVR || h.rtsp.isNotEmpty() || h.onvif != null
            AuditFilter.PANELS -> h.web.isNotEmpty()
            AuditFilter.ROUTERS -> h.type == DevType.ROUTER
        }
    }.sortedByDescending { it.maxSeverity.weight }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Header("Аудит сети", net?.let { "Ваша сеть ${it.base24}0/24" } ?: "Нет подключения к локальной сети",
                leading = { IconButton(onClick = { vm.navigate(Screen.TOOLS) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Pal.text) } },
                trailing = {
                    if (audit.hosts.isNotEmpty()) {
                        IconButton(onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Пульт Тул — отчёт аудита сети")
                                putExtra(Intent.EXTRA_TEXT, vm.auditReportText())
                            }
                            context.startActivity(Intent.createChooser(send, "Поделиться отчётом"))
                        }) { Icon(Icons.Filled.Share, "Поделиться", tint = Pal.text) }
                        IconButton(onClick = { exportRun() }) { GlyphIcon(Glyph.DOWNLOAD, tint = Pal.text, size = 22.dp) }
                    }
                })
        }
        item {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0x22FFC542))
                    .border(1.dp, Color(0x66FFC542), RoundedCornerShape(22.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null, tint = Pal.yellow)
                    Spacer(Modifier.width(8.dp))
                    Text("Только для вашей собственной сети", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Проверяйте только свою сеть или сеть, владелец которой дал вам явное разрешение. " +
                        "Сканирование чужих сетей без разрешения может нарушать закон.\n\n" +
                        "Проверка работает только в режиме чтения: находит устройства и открытые службы (веб-панели, RTSP, ONVIF, Dahua, XMeye и др.) " +
                        "и определяет, требуют ли они вход. Приложение НЕ подбирает пароли, НЕ пробует стандартные логины и НЕ открывает видеопотоки.",
                    color = Pal.textDim, fontSize = 13.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { consent = !consent; vm.auditConsent = consent }) {
                    Checkbox(consent, { consent = it; vm.auditConsent = it })
                    Text("Это моя сеть, или у меня есть разрешение владельца", color = Pal.text, fontSize = 13.sp)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                if (audit.running) {
                    val p = audit.progress
                    val frac by animateFloatAsState(if (p.total > 0) p.done.toFloat() / p.total else 0f, label = "ap")
                    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Pal.glassStrong)) {
                        Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(4.dp)).background(LocalAccent.current.brush))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(p.stage, color = Pal.textDim, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    GhostButton("Остановить", Modifier.fillMaxWidth(), onClick = { vm.stopAudit() })
                } else {
                    GradientButton(if (audit.finished) "Проверить снова" else "Начать проверку", Modifier.fillMaxWidth(), glyph = Glyph.SHIELD,
                        enabled = consent && net != null, onClick = { vm.startAudit() })
                    if (net == null) Text("Подключитесь к Wi-Fi, чтобы проверить сеть", color = Pal.red, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    if (audit.finished && audit.progress.stage.isNotBlank()) Text(audit.progress.stage, color = Pal.textDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        if (audit.hosts.isNotEmpty()) {
            item { Summary(audit.hosts) }
            item {
                FlowRow(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AuditFilter.entries.forEach { f ->
                        val on = f == filter
                        Text(f.title, Modifier.clip(RoundedCornerShape(50))
                            .background(if (on) LocalAccent.current.brush else Brush.linearGradient(listOf(Pal.glassStrong, Pal.glassStrong)))
                            .clickable { filter = f }.padding(horizontal = 12.dp, vertical = 7.dp), color = Pal.text, fontSize = 12.sp)
                    }
                }
            }
        }
        items(hosts, key = { it.ip }) { h -> HostCard(h) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Summary(hosts: List<AuditHost>) {
    val all = hosts.flatMap { it.findings }
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("${hosts.size}", color = Pal.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("устройств в сети", color = Pal.textDim, fontSize = 12.sp)
            }
            val cams = hosts.count { it.type == DevType.CAMERA || it.type == DevType.DVR }
            Column(Modifier.weight(1f)) {
                Text("$cams", color = Pal.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("камер / DVR", color = Pal.textDim, fontSize = 12.sp)
            }
            val issues = all.count { it.severity.weight >= Severity.MEDIUM.weight }
            Column(Modifier.weight(1f)) {
                Text("$issues", color = if (issues > 0) Pal.red else Pal.green, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("проблем", color = Pal.textDim, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Severity.entries.forEach { s ->
                val n = all.count { it.severity == s }
                if (n > 0) Chip("${s.title}: $n", Color(s.color))
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HostCard(h: AuditHost) {
    var open by remember { mutableStateOf(false) }
    val sev = h.maxSeverity
    val rot by animateFloatAsState(if (open) 180f else 0f, label = "rot")
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
            .glass(RoundedCornerShape(22.dp))
            .clickable { open = !open }
            .animateContentSize()
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(sev.color).copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                GlyphIcon(typeGlyph(h.type), tint = Color(sev.color), size = 24.dp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                val title = listOf(h.brand, h.model).filter { it.isNotBlank() }.joinToString(" ").ifBlank { h.upnpName.ifBlank { h.hostname.ifBlank { h.type.title } } }
                Text(title, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(h.ip + " · " + h.type.title + (if (h.isGateway) " · шлюз" else "") + (if (h.isSelf) " · этот телефон" else ""),
                    color = Pal.textDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (h.findings.any { it.severity.weight >= Severity.LOW.weight }) Chip(sev.title, Color(sev.color))
            Icon(Icons.Filled.KeyboardArrowDown, null, tint = Pal.textDim, modifier = Modifier.rotate(rot))
        }
        if (h.openPorts.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                h.openPorts.forEach { p -> Chip("$p ${portName(p)}", LocalAccent.current.b) }
            }
        }
        if (h.authSummary.isNotBlank()) {
            Spacer(Modifier.height(6.dp))
            Text(h.authSummary, color = Pal.text, fontSize = 12.sp)
        }
        AnimatedVisibility(open) {
            Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (h.hostname.isNotBlank()) Detail("Имя хоста", h.hostname)
                if (h.upnpName.isNotBlank()) Detail("UPnP", h.upnpName)
                h.onvif?.let { o ->
                    Detail("ONVIF", listOf(o.manufacturer, o.model, o.firmware.takeIf { it.isNotBlank() }?.let { "прошивка $it" })
                        .filter { !it.isNullOrBlank() }.joinToString(" · ").ifBlank { o.endpoint })
                }
                h.web.forEach { w ->
                    Detail("Веб :${w.port}${if (w.https) " (HTTPS)" else ""}",
                        listOf("HTTP ${w.status}", w.title.takeIf { it.isNotBlank() }?.let { "«$it»" }, w.server.takeIf { it.isNotBlank() },
                            w.authScheme?.let { "вход: $it" + (w.realm?.let { r -> " ($r)" } ?: "") },
                            if (w.loginForm) "форма входа" else null, if (!w.authRequired) "вход не обнаружен" else null)
                            .filterNotNull().joinToString(" · "))
                }
                h.rtsp.forEach { r ->
                    Detail("RTSP :${r.port}", listOf(
                        r.server.takeIf { it.isNotBlank() },
                        "OPTIONS ${r.optionsStatus}", "DESCRIBE ${r.describeStatus}",
                        r.authScheme?.let { "auth: $it" }, r.realm?.let { "realm «$it»" }
                    ).filterNotNull().joinToString(" · "))
                }
                if (h.findings.isEmpty()) Text("Замечаний нет", color = Pal.green, fontSize = 13.sp)
                h.findings.sortedByDescending { it.severity.weight }.forEach { FindingView(it) }
            }
        }
    }
}

@Composable
private fun Detail(k: String, v: String) {
    Row {
        Text(k, color = Pal.textDim, fontSize = 12.sp, modifier = Modifier.width(96.dp))
        Text(v, color = Pal.text, fontSize = 12.sp)
    }
}

@Composable
private fun FindingView(f: Finding) {
    val col = Color(f.severity.color)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(col.copy(alpha = 0.1f))
            .border(1.dp, col.copy(alpha = 0.35f), RoundedCornerShape(14.dp)).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Chip(f.severity.title, col)
            Spacer(Modifier.width(8.dp))
            Text(f.title, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        if (f.detail.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(f.detail, color = Pal.textDim, fontSize = 12.sp) }
        if (f.advice.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text("Рекомендация: " + f.advice, color = Pal.text, fontSize = 12.sp) }
    }
}

private fun typeGlyph(t: DevType): Glyph = when (t) {
    DevType.ROUTER -> Glyph.WIFI
    DevType.CAMERA, DevType.DVR -> Glyph.RADAR
    DevType.ADMIN_PANEL -> Glyph.GUIDE
    DevType.NAS -> Glyph.APPS
    DevType.PRINTER -> Glyph.MENU
    DevType.TV -> Glyph.TV
    DevType.SMART_HOME -> Glyph.HOME
    DevType.COMPUTER -> Glyph.KEYBOARD
    DevType.PHONE -> Glyph.TOUCH
    DevType.OTHER -> Glyph.INFO
}
