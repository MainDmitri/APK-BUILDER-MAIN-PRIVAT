package com.pultitool.remote.tv

import android.content.Context
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.ProtoIO
import com.pultitool.remote.net.ProtoMsg
import com.pultitool.remote.net.ProtoWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.interfaces.RSAPublicKey
import java.security.cert.X509Certificate
import javax.net.ssl.SSLException
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

/**
 * Android TV / Google TV Remote Service v2.
 * Сопряжение: TLS на порт 6467, протокол Polo (OuterMessage), код из 6 hex-символов на экране ТВ.
 * Управление: TLS на порт 6466, сообщения RemoteMessage (см. remotemessage.proto из androidtvremote2).
 */
class AndroidTvController(context: Context, d: TvDevice) : TvController(context, d) {

    private var socket: SSLSocket? = null
    private var out: OutputStream? = null
    private var pairSocket: SSLSocket? = null
    private var pairOut: OutputStream? = null
    @Volatile private var pairStage = 0
    @Volatile private var closedByUser = false
    private var imeCounter = 0L
    private var fieldCounter = 0L

    override val supportsTouchpad = true

    companion object {
        const val PORT_REMOTE = 6466
        const val PORT_PAIR = 6467
        // PING | KEY | IME | POWER | VOLUME | APP_LINK
        const val FEATURES = 1L or 2L or 4L or 32L or 64L or 512L

        fun keyCode(k: RKey): Int = when (k) {
            RKey.POWER -> 26; RKey.UP -> 19; RKey.DOWN -> 20; RKey.LEFT -> 21; RKey.RIGHT -> 22
            RKey.OK -> 23; RKey.BACK -> 4; RKey.HOME -> 3; RKey.MENU -> 82
            RKey.VOL_UP -> 24; RKey.VOL_DOWN -> 25; RKey.MUTE -> 164
            RKey.CH_UP -> 166; RKey.CH_DOWN -> 167
            RKey.D0 -> 7; RKey.D1 -> 8; RKey.D2 -> 9; RKey.D3 -> 10; RKey.D4 -> 11
            RKey.D5 -> 12; RKey.D6 -> 13; RKey.D7 -> 14; RKey.D8 -> 15; RKey.D9 -> 16
            RKey.PLAY_PAUSE -> 85; RKey.PLAY -> 126; RKey.PAUSE -> 127; RKey.STOP -> 86
            RKey.REWIND -> 89; RKey.FAST_FORWARD -> 90; RKey.PREV -> 88; RKey.NEXT -> 87
            RKey.INPUT -> 178; RKey.INFO -> 165; RKey.SETTINGS -> 176; RKey.EXIT -> 111
            RKey.GUIDE -> 172; RKey.SEARCH -> 84
            RKey.RED -> 183; RKey.GREEN -> 184; RKey.YELLOW -> 185; RKey.BLUE -> 186
            RKey.DEL -> 67; RKey.ENTER -> 66
        }
    }

    override fun builtinApps() = listOf(
        AppShortcut("YouTube", "https://www.youtube.com", AppColors.YOUTUBE),
        AppShortcut("Netflix", "https://www.netflix.com/title", AppColors.NETFLIX),
        AppShortcut("Prime Video", "https://app.primevideo.com", AppColors.PRIME),
        AppShortcut("Кинопоиск", "https://hd.kinopoisk.ru", AppColors.KINOPOISK),
        AppShortcut("Okko", "https://okko.tv", AppColors.OKKO),
        AppShortcut("ivi", "https://www.ivi.ru", AppColors.IVI),
        AppShortcut("Disney+", "https://www.disneyplus.com", AppColors.DISNEY),
        AppShortcut("Spotify", "spotify://spotify:home", AppColors.SPOTIFY),
        AppShortcut("Twitch", "twitch://stream", AppColors.TWITCH),
        AppShortcut("Плей Маркет", "market://launch?id=com.android.vending", AppColors.BROWSER),
        AppShortcut("Kodi", "market://launch?id=org.xbmc.kodi", AppColors.KODI),
        AppShortcut("VK Видео", "market://launch?id=com.vk.tvapp", AppColors.VK)
    )

    override suspend fun connect() = withContext(Dispatchers.IO) {
        closedByUser = false
        disconnectSockets()
        _state.value = ConnState.Connecting("Подключение к ${device.ip}:$PORT_REMOTE…")
        try {
            openRemote()
        } catch (e: java.net.ConnectException) {
            _state.value = ConnState.Error("ТВ недоступен по адресу ${device.ip}. Включите его и проверьте Wi-Fi")
        } catch (e: java.net.SocketTimeoutException) {
            _state.value = ConnState.Error("ТВ не отвечает (таймаут). Проверьте, что он в той же сети")
        } catch (e: java.net.NoRouteToHostException) {
            _state.value = ConnState.Error("Нет маршрута до ${device.ip}")
        } catch (e: Exception) {
            if (e is SSLException || e is java.net.SocketException || !device.paired) {
                // ТВ не знает наш сертификат — запускаем сопряжение
                startPairing()
            } else {
                _state.value = ConnState.Error("Не удалось подключиться: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun newSocket(port: Int): SSLSocket {
        val ctx = CertManager.sslContext(context)
        val raw = java.net.Socket()
        raw.connect(InetSocketAddress(device.ip, port), 4000)
        val s = ctx.socketFactory.createSocket(raw, device.ip, port, true) as SSLSocket
        s.useClientMode = true
        s.soTimeout = 0
        s.startHandshake()
        return s
    }

    private fun openRemote() {
        val s = newSocket(PORT_REMOTE)
        socket = s
        out = s.outputStream
        val input = s.inputStream
        // Ждём первое сообщение (remote_configure) — если ТВ закрыл соединение, сертификат не принят
        s.soTimeout = 5000
        val first = ProtoIO.readDelimited(input) ?: throw SSLException("ТВ закрыл соединение (нужно сопряжение)")
        s.soTimeout = 0
        if (!device.paired) updateDevice(device.copy(paired = true))
        handleRemote(first)
        thread(name = "atv-reader", isDaemon = true) {
            try {
                while (true) {
                    val m = ProtoIO.readDelimited(input) ?: break
                    handleRemote(m)
                }
            } catch (_: Exception) {
            }
            if (!closedByUser && socket === s) {
                _state.value = ConnState.Error("Соединение с ТВ потеряно")
            }
        }
    }

    private fun sendRemote(bytes: ByteArray) {
        val o = out ?: throw IllegalStateException("Нет подключения")
        ProtoIO.writeDelimited(o, bytes)
    }

    private fun handleRemote(raw: ByteArray) {
        val m = ProtoMsg.parse(raw)
        when {
            m.has(1) -> { // remote_configure
                val cfg = m.msg(1)
                val devInfo = cfg?.msg(2)
                val tvFeatures = cfg?.int(1) ?: FEATURES
                val vendor = devInfo?.string(2).orEmpty()
                val model = devInfo?.string(1).orEmpty()
                if (model.isNotEmpty() && device.model.isEmpty()) updateDevice(device.copy(model = model, brand = vendor.ifEmpty { device.brand }))
                val reply = ProtoWriter().msg(1) {
                    int(1, FEATURES and tvFeatures)
                    msg(2) {
                        string(1, android.os.Build.MODEL ?: "Phone")
                        string(2, android.os.Build.MANUFACTURER ?: "Android")
                        int(3, 1)
                        string(4, "1")
                        string(5, "atvremote")
                        string(6, "1.0.0")
                    }
                }.toByteArray()
                sendRemote(reply)
                _state.value = ConnState.Connected(listOf(vendor, model).filter { it.isNotBlank() }.joinToString(" "))
            }
            m.has(2) -> { // remote_set_active
                sendRemote(ProtoWriter().msg(2) { int(1, FEATURES) }.toByteArray())
            }
            m.has(8) -> { // ping
                val v = m.msg(8)?.int(1) ?: 0
                sendRemote(ProtoWriter().msg(9) { int(1, v) }.toByteArray())
            }
            m.has(20) -> { // ime key inject -> текущее приложение
                val pkg = m.msg(20)?.msg(1)?.string(12).orEmpty()
                if (pkg.isNotEmpty()) _currentApp.value = pkg
            }
            m.has(21) -> { // ime batch edit
                val b = m.msg(21)
                imeCounter = b?.int(1) ?: imeCounter
                fieldCounter = b?.int(2) ?: fieldCounter
            }
            m.has(40) -> { // remote_start
                val started = (m.msg(40)?.int(1) ?: 0L) != 0L
                _state.value = ConnState.Connected(if (started) "ТВ включён" else "ТВ в режиме ожидания")
            }
            m.has(50) -> { // volume
                val v = m.msg(50)
                if (v != null) _volume.value = VolumeInfo(v.int(7).toInt(), v.int(6).toInt(), v.int(8) != 0L)
            }
            m.has(3) -> { // remote_error
                _state.value = ConnState.Connected("ТВ сообщил об ошибке команды")
            }
        }
    }

    // ---------------- Pairing ----------------

    private fun outer(block: ProtoWriter.() -> Unit): ByteArray =
        ProtoWriter().int(1, 2).int(2, 200).apply(block).toByteArray()

    private fun startPairing() {
        _state.value = ConnState.Connecting("Запуск сопряжения…")
        try {
            val s = newSocket(PORT_PAIR)
            pairSocket = s
            pairOut = s.outputStream
            s.soTimeout = 10000
            val input = s.inputStream
            ProtoIO.writeDelimited(s.outputStream, outer {
                msg(10) { string(1, "atvremote"); string(2, "Пульт Тул") }
            })
            pairStage = 1
            while (true) {
                val raw = ProtoIO.readDelimited(input) ?: throw SSLException("ТВ закрыл соединение сопряжения")
                val m = ProtoMsg.parse(raw)
                val status = m.int(2)
                if (status != 200L) throw IllegalStateException("ТВ ответил статусом $status")
                when {
                    m.has(11) -> ProtoIO.writeDelimited(s.outputStream, outer {
                        msg(20) {
                            msg(1) { int(1, 3); int(2, 6) }
                            int(3, 1)
                        }
                    })
                    m.has(20) -> ProtoIO.writeDelimited(s.outputStream, outer {
                        msg(30) {
                            msg(1) { int(1, 3); int(2, 6) }
                            int(2, 1)
                        }
                    })
                    m.has(31) -> {
                        pairStage = 2
                        s.soTimeout = 0
                        _state.value = ConnState.NeedCode("Введите 6-значный код, показанный на экране телевизора")
                        return
                    }
                    else -> throw IllegalStateException("Неожиданный ответ ТВ при сопряжении")
                }
            }
        } catch (e: Exception) {
            closePairing()
            _state.value = ConnState.Error("Сопряжение не удалось: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun unsignedBytes(v: BigInteger): ByteArray {
        val b = v.toByteArray()
        return if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b
    }

    private fun hexBytes(hex: String): ByteArray {
        val h = if (hex.length % 2 == 1) "0$hex" else hex
        return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** Экспонента кодируется как в androidtvremote2: hex с ведущим "0". */
    private fun expBytes(e: BigInteger): ByteArray = hexBytes("0" + e.toString(16).uppercase())

    override suspend fun submitCode(code: String) = withContext(Dispatchers.IO) {
        val c = code.trim().uppercase()
        val s = pairSocket
        if (s == null || pairStage != 2) {
            _state.value = ConnState.Error("Сессия сопряжения истекла, попробуйте снова")
            return@withContext
        }
        if (c.length != 6 || c.any { it !in "0123456789ABCDEF" }) {
            _state.value = ConnState.NeedCode("Код должен состоять из 6 символов 0-9, A-F")
            return@withContext
        }
        try {
            val clientCert = CertManager.identity(context).second
            val serverCert = s.session.peerCertificates[0] as X509Certificate
            val cpk = clientCert.publicKey as RSAPublicKey
            val spk = serverCert.publicKey as RSAPublicKey
            val md = MessageDigest.getInstance("SHA-256")
            md.update(unsignedBytes(cpk.modulus))
            md.update(expBytes(cpk.publicExponent))
            md.update(unsignedBytes(spk.modulus))
            md.update(expBytes(spk.publicExponent))
            md.update(hexBytes(c.substring(2)))
            val hash = md.digest()
            if ((hash[0].toInt() and 0xFF) != c.substring(0, 2).toInt(16)) {
                _state.value = ConnState.NeedCode("Неверный код. Проверьте символы на экране ТВ")
                return@withContext
            }
            _state.value = ConnState.Connecting("Проверка кода…")
            s.soTimeout = 15000
            ProtoIO.writeDelimited(s.outputStream, outer { msg(40) { bytes(1, hash) } })
            val raw = ProtoIO.readDelimited(s.inputStream) ?: throw SSLException("ТВ закрыл соединение")
            val m = ProtoMsg.parse(raw)
            if (m.int(2) != 200L || !m.has(41)) throw IllegalStateException("ТВ отклонил код (статус ${m.int(2)})")
            closePairing()
            updateDevice(device.copy(paired = true))
            _state.value = ConnState.Connecting("Сопряжено! Подключаемся…")
            openRemote()
        } catch (e: Exception) {
            closePairing()
            _state.value = ConnState.Error("Ошибка сопряжения: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun closePairing() {
        pairStage = 0
        try { pairSocket?.close() } catch (_: Exception) {}
        pairSocket = null
        pairOut = null
    }

    private fun disconnectSockets() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        out = null
        closePairing()
    }

    override fun disconnect() {
        closedByUser = true
        disconnectSockets()
        _state.value = ConnState.Idle
    }

    override suspend fun sendKey(key: RKey, longPress: Boolean) = withContext(Dispatchers.IO) {
        try {
            val kc = keyCode(key)
            if (longPress) {
                sendRemote(ProtoWriter().msg(10) { int(1, kc); int(2, 1) }.toByteArray())
                Thread.sleep(600)
                sendRemote(ProtoWriter().msg(10) { int(1, kc); int(2, 2) }.toByteArray())
            } else {
                sendRemote(ProtoWriter().msg(10) { int(1, kc); int(2, 3) }.toByteArray())
            }
        } catch (e: Exception) {
            _state.value = ConnState.Error("Команда не отправлена: ${e.message}")
        }
    }

    override suspend fun sendText(text: String) = withContext(Dispatchers.IO) {
        if (text.isEmpty()) return@withContext
        try {
            val pos = (text.length - 1).toLong()
            sendRemote(ProtoWriter().msg(21) {
                int(1, imeCounter)
                int(2, fieldCounter)
                msg(3) {
                    int(1, 1)
                    msg(2) { int(1, pos); int(2, pos); string(3, text) }
                }
            }.toByteArray())
        } catch (e: Exception) {
            _state.value = ConnState.Error("Текст не отправлен: ${e.message}")
        }
    }

    override suspend fun launchApp(app: AppShortcut) = withContext(Dispatchers.IO) {
        try {
            sendRemote(ProtoWriter().msg(90) { string(1, app.id) }.toByteArray())
        } catch (e: Exception) {
            _state.value = ConnState.Error("Не удалось открыть ${app.title}: ${e.message}")
        }
    }

    override val supportsUrl = true
    override val supportsYouTube = true

    override suspend fun openUrl(url: String): Boolean = withContext(Dispatchers.IO) {
        try {
            sendRemote(ProtoWriter().msg(90) { string(1, url) }.toByteArray()); true
        } catch (e: Exception) {
            _state.value = ConnState.Error("Ссылка не отправлена: ${e.message}"); false
        }
    }

    override suspend fun openYouTube(videoId: String): Boolean = openUrl("https://www.youtube.com/watch?v=$videoId")

    /** Тачпад: свайпы переводятся в нажатия D-pad. */
    override suspend fun moveCursor(dx: Int, dy: Int) {
        val k = if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) (if (dx > 0) RKey.RIGHT else RKey.LEFT) else (if (dy > 0) RKey.DOWN else RKey.UP)
        sendKey(k)
    }
}
