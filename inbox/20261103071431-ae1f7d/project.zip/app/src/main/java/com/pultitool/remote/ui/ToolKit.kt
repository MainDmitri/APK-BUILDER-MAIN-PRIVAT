package com.pultitool.remote.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Каркас экрана инструмента: заголовок с кнопкой «Назад» и прокручиваемое содержимое. */
@Composable
fun ToolScaffold(
    title: String,
    subtitle: String?,
    onBack: () -> Unit,
    scroll: Boolean = true,
    trailing: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Header(title, subtitle, leading = {
            PadButton(size = 42.dp, onClick = onBack) { GlyphIcon(Glyph.BACK, tint = Pal.text, size = 20.dp) }
        }, trailing = trailing)
        val m = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 16.dp)
        Column(if (scroll) m.verticalScroll(rememberScrollState()) else m, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            content()
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun ToolField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Uri,
    singleLine: Boolean = true,
    minLines: Int = 1,
    onGo: (() -> Unit)? = null
) {
    OutlinedTextField(
        value, onChange, label = { Text(label) }, singleLine = singleLine, minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = if (onGo != null) ImeAction.Go else ImeAction.Default),
        keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = { onGo?.invoke() }),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun ToggleRow(title: String, checked: Boolean, subtitle: String? = null, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (subtitle != null) Text(subtitle, color = Pal.textDim, fontSize = 12.sp)
        }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = accent.a, checkedThumbColor = Color.White))
    }
}

@Composable
fun MiniStat(value: String, label: String, modifier: Modifier = Modifier, color: Color = Pal.text) {
    Column(modifier.glass(RoundedCornerShape(18.dp)).padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = color, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(label, color = Pal.textDim, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun ProgressLine(progress: Float, text: String) {
    val accent = LocalAccent.current
    Column {
        LinearProgressIndicator(progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = accent.b, trackColor = Pal.glassStrong)
        Spacer(Modifier.height(4.dp))
        Text(text, color = Pal.textDim, fontSize = 12.sp)
    }
}

@Composable
fun ErrorText(text: String?) {
    if (text != null) Text("⚠ $text", color = Pal.red, fontSize = 13.sp)
}

/** Моноширинный выделяемый блок результата. */
@Composable
fun MonoBox(text: String, modifier: Modifier = Modifier) {
    SelectionContainer {
        Text(text, modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x55000000)).padding(12.dp),
            color = Pal.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp)
    }
}

fun copyText(ctx: Context, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("PultTool", text))
    Toast.makeText(ctx, "Скопировано", Toast.LENGTH_SHORT).show()
}

@Composable
fun CopyChip(text: String) {
    val ctx = LocalContext.current
    Chip("Копировать", LocalAccent.current.b, Modifier.clickable { copyText(ctx, text) })
}

fun latencyColor(ms: Double?): Color = when {
    ms == null -> Pal.red
    ms < 40 -> Pal.green
    ms < 100 -> Pal.yellow
    else -> Color(0xFFFF8A3D)
}

/** Живой график задержки: линия с градиентной заливкой, точки потерь отмечены красным. */
@Composable
fun LatencyChart(values: List<Double?>, modifier: Modifier = Modifier, maxPoints: Int = 60) {
    val accent = LocalAccent.current
    val pts = values.takeLast(maxPoints)
    val maxV = max(pts.filterNotNull().maxOrNull() ?: 50.0, 20.0) * 1.15
    val anim by animateFloatAsState(maxV.toFloat(), tween(400), label = "max")
    Box(modifier.fillMaxWidth().height(180.dp).glass(RoundedCornerShape(20.dp)).padding(12.dp)) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // Сетка
            for (i in 0..4) {
                val y = h * i / 4f
                drawLine(Color(0x22FFFFFF), Offset(0f, y), Offset(w, y), 1f)
            }
            if (pts.isEmpty()) return@Canvas
            val step = if (maxPoints > 1) w / (maxPoints - 1) else w
            val x0 = w - (pts.size - 1) * step
            val line = Path()
            val fill = Path()
            var started = false
            var lastX = 0f
            pts.forEachIndexed { i, v ->
                val x = x0 + i * step
                if (v == null) {
                    drawLine(Pal.red.copy(alpha = 0.7f), Offset(x, 0f), Offset(x, h), 3f)
                    return@forEachIndexed
                }
                val y = h - (v / anim).toFloat().coerceIn(0f, 1f) * h
                if (!started) { line.moveTo(x, y); fill.moveTo(x, h); fill.lineTo(x, y); started = true } else { line.lineTo(x, y); fill.lineTo(x, y) }
                lastX = x
            }
            if (started) {
                fill.lineTo(lastX, h); fill.close()
                drawPath(fill, Brush.verticalGradient(listOf(accent.b.copy(alpha = 0.35f), Color.Transparent)))
                drawPath(line, Brush.horizontalGradient(listOf(accent.a, accent.b)), style = Stroke(width = 5f, cap = StrokeCap.Round))
                val lastVal = pts.lastOrNull()
                if (lastVal != null) drawCircle(Color.White, 7f, Offset(x0 + (pts.size - 1) * step, h - (lastVal / anim).toFloat().coerceIn(0f, 1f) * h))
            }
        }
        Text("${anim.toInt()} мс", color = Pal.textDim, fontSize = 10.sp, modifier = Modifier.align(Alignment.TopStart))
        Text("0", color = Pal.textDim, fontSize = 10.sp, modifier = Modifier.align(Alignment.BottomStart))
    }
}

/** Небольшая спарклайн-диаграмма (например, скорость по времени). */
@Composable
fun Sparkline(values: List<Float>, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(48.dp)) {
        if (values.size < 2) return@Canvas
        val mx = (values.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val step = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i * step
            val y = size.height - v / mx * size.height
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(path, color, style = Stroke(width = 4f, cap = StrokeCap.Round))
    }
}

/** Кольцо оценки безопасности 0–100 с анимированным заполнением. */
@Composable
fun ScoreRing(score: Int?, size: Dp = 140.dp, label: String = "из 100") {
    val target = (score ?: 0) / 100f
    val anim = remember { Animatable(0f) }
    LaunchedEffect(score) { anim.animateTo(target, tween(1200, easing = FastOutSlowInEasing)) }
    val color = scoreColor(score)
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.width * 0.1f
            val inset = sw / 2
            drawArc(Color(0x22FFFFFF), 135f, 270f, false, Offset(inset, inset), Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(listOf(color.copy(alpha = 0.6f), color, color.copy(alpha = 0.6f))), 135f, 270f * anim.value, false,
                Offset(inset, inset), Size(this.size.width - sw, this.size.height - sw), style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (score == null) "—" else "${(anim.value * 100).toInt()}", color = Pal.text, fontSize = (size.value * 0.26f).sp, fontWeight = FontWeight.Black)
            Text(if (score == null) "нет аудита" else label, color = Pal.textDim, fontSize = 11.sp)
        }
    }
}

fun scoreColor(score: Int?): Color = when {
    score == null -> Pal.textDim
    score >= 80 -> Pal.green
    score >= 50 -> Pal.yellow
    else -> Pal.red
}

/** Спидометр: шкала 0–1000 Мбит/с с нелинейной разметкой и пружинной стрелкой. */
@Composable
fun SpeedGauge(mbps: Double, label: String, modifier: Modifier = Modifier) {
    val accent = LocalAccent.current
    val marks = listOf(0, 5, 10, 25, 50, 100, 250, 500, 1000)
    fun frac(v: Double): Float {
        if (v <= 0) return 0f
        for (i in 0 until marks.size - 1) {
            val a = marks[i]; val b = marks[i + 1]
            if (v <= b) return (i + ((v - a) / (b - a))).toFloat() / (marks.size - 1)
        }
        return 1f
    }
    val f by animateFloatAsState(frac(mbps), spring(dampingRatio = 0.6f, stiffness = 80f), label = "needle")
    Box(modifier.fillMaxWidth().height(260.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(260.dp)) {
            val sw = size.width * 0.07f
            val r = size.width / 2 - sw
            val c = Offset(size.width / 2, size.height / 2)
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            drawArc(Color(0x22FFFFFF), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            drawArc(Brush.sweepGradient(listOf(accent.a, accent.b, accent.a), c), 135f, 270f * f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            marks.forEachIndexed { i, _ ->
                val ang = Math.toRadians(135.0 + 270.0 * i / (marks.size - 1))
                val p1 = Offset(c.x + (r - sw) * cos(ang).toFloat(), c.y + (r - sw) * sin(ang).toFloat())
                val p2 = Offset(c.x + (r - sw * 1.6f) * cos(ang).toFloat(), c.y + (r - sw * 1.6f) * sin(ang).toFloat())
                drawLine(Color(0x88FFFFFF), p1, p2, 3f)
            }
            val ang = Math.toRadians(135.0 + 270.0 * f)
            val tip = Offset(c.x + (r - sw * 2f) * cos(ang).toFloat(), c.y + (r - sw * 2f) * sin(ang).toFloat())
            drawLine(Color.White, c, tip, 6f, StrokeCap.Round)
            drawCircle(accent.b, sw * 0.5f, c)
            drawCircle(Color.White, sw * 0.22f, c)
        }
        // Подписи шкалы
        Box(Modifier.size(260.dp)) {
            marks.forEachIndexed { i, m ->
                val ang = Math.toRadians(135.0 + 270.0 * i / (marks.size - 1))
                val rr = 82f
                Text(if (m >= 1000) "1G" else "$m", color = Pal.textDim, fontSize = 10.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.align(Alignment.Center).padding(
                        start = if (cos(ang) > 0) (rr * cos(ang) * 2).toFloat().coerceAtLeast(0f).dp else 0.dp,
                        end = if (cos(ang) < 0) (-rr * cos(ang) * 2).toFloat().coerceAtLeast(0f).dp else 0.dp,
                        top = if (sin(ang) > 0) (rr * sin(ang) * 2).toFloat().coerceAtLeast(0f).dp else 0.dp,
                        bottom = if (sin(ang) < 0) (-rr * sin(ang) * 2).toFloat().coerceAtLeast(0f).dp else 0.dp
                    ))
            }
        }
        Column(Modifier.padding(top = 120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (mbps >= 100) "%.0f".format(mbps) else "%.1f".format(mbps), color = Pal.text, fontSize = 38.sp, fontWeight = FontWeight.Black)
            Text("Мбит/с · $label", color = Pal.textDim, fontSize = 12.sp)
        }
    }
}

@Composable
fun SegmentRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEachIndexed { i, o ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                    .then(if (i == selected) Modifier.background(accent.brush) else Modifier)
                    .clickable { onSelect(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = Pal.text, fontSize = 12.sp, fontWeight = if (i == selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1) }
        }
    }
}

@Composable
fun ChipRow(options: List<String>, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScrollSafe(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, o -> Chip(o, LocalAccent.current.b, Modifier.clickable { onSelect(i) }) }
    }
}

@Composable
fun Modifier.horizontalScrollSafe(): Modifier = this.then(Modifier.horizontalScroll(rememberScrollState()))

