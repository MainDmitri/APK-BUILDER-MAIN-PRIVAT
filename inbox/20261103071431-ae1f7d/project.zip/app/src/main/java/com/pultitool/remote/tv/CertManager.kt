package com.pultitool.remote.tv

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager

/**
 * Постоянный самоподписанный клиентский сертификат (RSA-2048) для протокола Android TV Remote v2.
 * Хранится в PKCS12-хранилище во внутренней памяти приложения (files/atv_client.p12).
 * Сертификат строится вручную в DER (без сторонних библиотек).
 */
object CertManager {
    private const val FILE = "atv_client.p12"
    private const val ALIAS = "pultitool"
    private val PASS = "pultitool-local".toCharArray()

    @Volatile private var cached: Pair<PrivateKey, X509Certificate>? = null

    @Synchronized
    fun identity(context: Context): Pair<PrivateKey, X509Certificate> {
        cached?.let { return it }
        val f = File(context.filesDir, FILE)
        if (f.exists()) {
            try {
                val ks = KeyStore.getInstance("PKCS12")
                f.inputStream().use { ks.load(it, PASS) }
                val key = ks.getKey(ALIAS, PASS) as PrivateKey
                val cert = ks.getCertificate(ALIAS) as X509Certificate
                return (key to cert).also { cached = it }
            } catch (_: Exception) {
                f.delete()
            }
        }
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048, SecureRandom())
        val kp = kpg.generateKeyPair()
        val cert = buildSelfSigned(kp.public.encoded, kp.private, "atvremote")
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry(ALIAS, kp.private, PASS, arrayOf(cert))
        f.outputStream().use { ks.store(it, PASS) }
        return (kp.private to cert).also { cached = it }
    }

    fun reset(context: Context) {
        cached = null
        File(context.filesDir, FILE).delete()
    }

    fun sslContext(context: Context): SSLContext {
        val (key, cert) = identity(context)
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry(ALIAS, key, PASS, arrayOf(cert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PASS)
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, arrayOf<TrustManager>(com.pultitool.remote.net.NetUtil.trustAll), SecureRandom())
        return ctx
    }

    // ---------- DER ----------
    private fun len(n: Int): ByteArray = when {
        n < 0x80 -> byteArrayOf(n.toByte())
        n < 0x100 -> byteArrayOf(0x81.toByte(), n.toByte())
        n < 0x10000 -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
        else -> byteArrayOf(0x83.toByte(), (n shr 16).toByte(), (n shr 8).toByte(), n.toByte())
    }

    private fun tlv(tag: Int, content: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(tag); o.write(len(content.size)); o.write(content)
        return o.toByteArray()
    }

    private fun seq(vararg parts: ByteArray) = tlv(0x30, parts.fold(ByteArray(0)) { a, b -> a + b })
    private fun set(vararg parts: ByteArray) = tlv(0x31, parts.fold(ByteArray(0)) { a, b -> a + b })
    private fun integer(v: BigInteger) = tlv(0x02, v.toByteArray())
    private fun nul() = byteArrayOf(0x05, 0x00)
    private fun utf8(s: String) = tlv(0x0C, s.toByteArray(Charsets.UTF_8))
    private fun bitString(b: ByteArray) = tlv(0x03, byteArrayOf(0) + b)

    private fun oid(dotted: String): ByteArray {
        val parts = dotted.split('.').map { it.toLong() }
        val o = ByteArrayOutputStream()
        o.write((parts[0] * 40 + parts[1]).toInt())
        for (p in parts.drop(2)) {
            val stack = ArrayList<Int>()
            var v = p
            stack.add((v and 0x7F).toInt())
            v = v shr 7
            while (v > 0) { stack.add(((v and 0x7F) or 0x80).toInt()); v = v shr 7 }
            stack.reversed().forEach { o.write(it) }
        }
        return tlv(0x06, o.toByteArray())
    }

    private fun utcTime(d: Date): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return tlv(0x17, f.format(d).toByteArray(Charsets.US_ASCII))
    }

    private fun buildSelfSigned(spki: ByteArray, key: PrivateKey, cn: String): X509Certificate {
        val sigAlg = seq(oid("1.2.840.113549.1.1.11"), nul())
        val name = seq(set(seq(oid("2.5.4.3"), utf8(cn))))
        val now = System.currentTimeMillis()
        val validity = seq(utcTime(Date(now - 86_400_000L)), utcTime(Date(now + 10L * 365 * 86_400_000L)))
        val serial = BigInteger(63, SecureRandom()).add(BigInteger.ONE)
        val version = tlv(0xA0, integer(BigInteger.valueOf(2)))
        val tbs = seq(version, integer(serial), sigAlg, name, validity, name, spki)
        val s = Signature.getInstance("SHA256withRSA")
        s.initSign(key)
        s.update(tbs)
        val der = seq(tbs, sigAlg, bitString(s.sign()))
        return CertificateFactory.getInstance("X.509").generateCertificate(der.inputStream()) as X509Certificate
    }
}
