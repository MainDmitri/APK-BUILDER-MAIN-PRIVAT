package com.pultitool.remote

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pultitool.remote.audit.AuditHost
import com.pultitool.remote.audit.AuditProgress
import com.pultitool.remote.audit.NetworkAuditor
import com.pultitool.remote.audit.Severity
import com.pultitool.remote.audit.buildAuditReport
import com.pultitool.remote.data.AuditSummary
import com.pultitool.remote.util.Achievements
import com.pultitool.remote.util.FileExport
import com.pultitool.remote.util.Haptics
import com.pultitool.remote.data.AppSettings
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.FoundDevice
import com.pultitool.remote.data.Protocol
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.Store
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.Discovery
import com.pultitool.remote.net.LocalNet
import com.pultitool.remote.net.NetUtil
import com.pultitool.remote.net.WakeOnLan
import com.pultitool.remote.tv.CertManager
import com.pultitool.remote.tv.ConnState
import com.pultitool.remote.tv.TvController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen(val title: String, val root: Boolean = false) {
    HOME("Главная", true),
    DEVICES("Устройства", true),
    SCAN("Поиск ТВ"),
    REMOTE("Пульт", true),
    GESTURE("Жестовый пульт"),
    TOOLS("Инструменты", true),
    AUDIT("Аудит безопасности"),
    PING("Пинг"),
    PORTS("Проверка портов"),
    TRACE("Трассировка"),
    DNS("DNS-запрос"),
    PUBLIC_IP("Внешний IP"),
    SUBNET("Калькулятор подсетей"),
    SPEED("Тест скорости"),
    HTTP("HTTP-инспектор"),
    MAP("Карта сети"),
    MONITOR("Монитор сети"),
    ACHIEVEMENTS("Достижения"),
    SETTINGS("Настройки", true)
}

/** Оценка безопасности 0–100 по находкам аудита. Каждый уровень ограничен, чтобы одна категория не обнуляла счёт. */
fun securityScore(hosts: List<AuditHost>): Int {
    val f = hosts.flatMap { it.findings }
    val crit = (f.count { it.severity == Severity.CRITICAL } * 25).coerceAtMost(60)
    val high = (f.count { it.severity == Severity.HIGH } * 15).coerceAtMost(45)
    val med = (f.count { it.severity == Severity.MEDIUM } * 7).coerceAtMost(28)
    val low = (f.count { it.severity == Severity.LOW } * 2).coerceAtMost(10)
    return (100 - crit - high - med - low).coerceIn(0, 100)
}

/** Достаёт ID ролика YouTube из ссылки: youtu.be/ID, watch?v=ID, shorts/ID, embed/ID, live/ID. */
fun youTubeId(url: String): String? {
    val u = url.trim()
    val patterns = listOf(
        Regex("youtu\\.be/([A-Za-z0-9_-]{11})"),
        Regex("[?&]v=([A-Za-z0-9_-]{11})"),
        Regex("youtube\\.com/(?:shorts|embed|live|v)/([A-Za-z0-9_-]{11})")
    )
    patterns.forEach { re -> re.find(u)?.let { return it.groupValues[1] } }
    return if (u.matches(Regex("^[A-Za-z0-9_-]{11}$"))) u else null
}

data class ScanState(
    val running: Boolean = false,
    val progress: Float = 0f,
    val stage: String = "",
    val found: List<FoundDevice> = emptyList(),
    val finished: Boolean = false
)

data class AuditState(
    val running: Boolean = false,
    val progress: AuditProgress = AuditProgress(0, 0, "", false),
    val hosts: List<AuditHost> = emptyList(),
    val finished: Boolean = false
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication()
    private val store = Store(app)

    private val _devices = MutableStateFlow(store.loadDevices())
    val devices: StateFlow<List<TvDevice>> = _devices

    private val _settings = MutableStateFlow(store.loadSettings())
    val settings: StateFlow<AppSettings> = _settings

    private val _screen = MutableStateFlow(Screen.HOME)
    val screen: StateFlow<Screen> = _screen

    private val _controller = MutableStateFlow<TvController?>(null)
    val controller: StateFlow<TvController?> = _controller

    private val _scan = MutableStateFlow(ScanState())
    val scan: StateFlow<ScanState> = _scan

    private val _audit = MutableStateFlow(AuditState())
    val audit: StateFlow<AuditState> = _audit

    private val _sleepLeft = MutableStateFlow(0L)
    val sleepLeft: StateFlow<Long> = _sleepLeft

    private val _online = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val online: StateFlow<Map<String, Boolean>> = _online

    private val _presses = MutableStateFlow(store.pressCount)
    val presses: StateFlow<Long> = _presses

    private val _auditSummary = MutableStateFlow(store.auditSummary)
    val auditSummary: StateFlow<AuditSummary?> = _auditSummary

    /** Ссылка, пришедшая через «Поделиться» из другого приложения. */
    private val _sharedUrl = MutableStateFlow<String?>(null)
    val sharedUrl: StateFlow<String?> = _sharedUrl

    private val _toast = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toast: SharedFlow<String> = _toast

    var auditConsent: Boolean
        get() = store.auditConsent
        set(v) { store.auditConsent = v }

    private var scanJob: Job? = null
    private var auditJob: Job? = null
    private var sleepJob: Job? = null
    private var stateJob: Job? = null
    private val history = ArrayDeque<Screen>()

    init {
        Achievements.init(app)
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h in 0..4) Achievements.unlock("night_owl")
        if (_settings.value.autoConnect) {
            val last = store.lastDeviceId?.let { id -> _devices.value.firstOrNull { it.id == id } }
            if (last != null) {
                selectDevice(last, navigate = false)
                _screen.value = Screen.REMOTE
            }
        }
        refreshOnline()
    }

    fun navigate(s: Screen) {
        val cur = _screen.value
        if (cur == s) return
        if (s.root) history.clear() else if (cur != Screen.GESTURE) history.addLast(cur)
        if (s == Screen.GESTURE) { history.addLast(cur); Achievements.unlock("gesture") }
        _screen.value = s
    }

    /** Назад: возвращает false, если уходить некуда (корневой экран). */
    fun back(): Boolean {
        val prev = history.removeLastOrNull()
        if (prev != null) { _screen.value = prev; return true }
        if (_screen.value != Screen.HOME) { _screen.value = Screen.HOME; return true }
        return false
    }

    fun message(text: String) { _toast.tryEmit(text) }

    // ---------------- Устройства ----------------

    private fun persist(list: List<TvDevice>) {
        _devices.value = list
        store.saveDevices(list)
    }

    fun upsert(d: TvDevice) {
        val list = _devices.value.toMutableList()
        val i = list.indexOfFirst { it.id == d.id }
        if (i >= 0) list[i] = d else list.add(d)
        persist(list)
        if (list.size >= 3) Achievements.unlock("collector")
    }

    fun deleteDevice(d: TvDevice) {
        if (_controller.value?.device?.id == d.id) {
            _controller.value?.disconnect(); _controller.value = null
        }
        persist(_devices.value.filter { it.id != d.id })
    }

    fun toggleFavorite(d: TvDevice) = upsert(d.copy(favorite = !d.favorite))

    fun rename(d: TvDevice, name: String) = upsert(d.copy(name = name.trim().ifEmpty { d.name }))

    fun editDevice(d: TvDevice) {
        val old = _devices.value.firstOrNull { it.id == d.id }
        val resetPairing = old != null && (old.ip != d.ip || old.protocol != d.protocol)
        val nd = if (resetPairing) d.copy(paired = false, token = "") else d
        upsert(nd)
        if (_controller.value?.device?.id == d.id) selectDevice(nd, navigate = false)
    }

    fun selectDevice(d: TvDevice, navigate: Boolean = true) {
        _controller.value?.disconnect()
        val fresh = d.copy(lastUsed = System.currentTimeMillis())
        upsert(fresh)
        store.lastDeviceId = fresh.id
        val c = TvController.create(ctx, fresh)
        c.onDeviceUpdated = { nd -> upsert(nd) }
        _controller.value = c
        stateJob?.cancel()
        stateJob = viewModelScope.launch {
            c.state.first { it is ConnState.Connected }
            Achievements.unlock("first_connect")
        }
        if (navigate) navigate(Screen.REMOTE)
        viewModelScope.launch { c.connect() }
    }

    fun reconnect() {
        val c = _controller.value ?: return
        viewModelScope.launch { c.connect() }
    }

    fun disconnect() {
        _controller.value?.disconnect()
    }

    fun refreshOnline() {
        viewModelScope.launch(Dispatchers.IO) {
            val map = _devices.value.filter { it.ip.isNotBlank() }.map { d ->
                async {
                    val ports = when (d.protocol) {
                        Protocol.ANDROID_TV -> listOf(6466, 6467, 8008)
                        Protocol.SAMSUNG -> listOf(8001, 8002)
                        Protocol.LG -> listOf(3000, 3001)
                        Protocol.ROKU -> listOf(8060)
                        Protocol.PHILIPS -> listOf(1925, 1926)
                        Protocol.SONY -> listOf(80)
                    }
                    d.id to ports.any { NetUtil.isPortOpen(d.ip, it, 700) }
                }
            }.awaitAll().toMap()
            _online.value = map
        }
    }

    // ---------------- Команды ----------------

    fun press(key: RKey, longPress: Boolean = false) {
        val c = _controller.value ?: run { message("Сначала выберите телевизор"); return }
        haptic(if (key == RKey.POWER) 40 else 15)
        countPress()
        viewModelScope.launch { c.sendKey(key, longPress) }
    }

    private fun countPress() {
        val n = _presses.value + 1
        _presses.value = n
        if (n % 10 == 0L) store.pressCount = n
        if (n >= 100) Achievements.unlock("presses_100")
        if (n >= 1000) Achievements.unlock("presses_1000")
    }

    fun sendText(text: String) {
        val c = _controller.value ?: return
        haptic(15)
        Achievements.unlock("typist")
        viewModelScope.launch { c.sendText(text) }
    }

    fun launchApp(app: AppShortcut) {
        val c = _controller.value ?: return
        haptic(25)
        viewModelScope.launch { c.launchApp(app) }
        message("Открываем ${app.title}…")
    }

    fun moveCursor(dx: Int, dy: Int) {
        val c = _controller.value ?: return
        viewModelScope.launch { c.moveCursor(dx, dy) }
    }

    fun click() {
        val c = _controller.value ?: return
        haptic(15)
        viewModelScope.launch { c.click() }
    }

    fun showToast(text: String) {
        val c = _controller.value ?: return
        viewModelScope.launch { c.showToast(text) }
    }

    /** Встряхивание телефона — выключить/включить звук на ТВ. */
    fun shakeMute() {
        val c = _controller.value ?: return
        if (c.state.value !is ConnState.Connected) return
        haptic(60)
        countPress()
        viewModelScope.launch { c.sendKey(RKey.MUTE) }
        Achievements.unlock("shaker")
        message("🤳 Встряхивание: звук ТВ переключён")
    }

    fun setSharedUrl(url: String?) { _sharedUrl.value = url }

    /** Открыть ссылку на ТВ: YouTube-ролики — в приложении YouTube, остальное — в браузере ТВ. */
    fun openOnTv(url: String) {
        val c = _controller.value ?: run { message("Сначала подключитесь к телевизору"); return }
        val trimmed = url.trim()
        if (trimmed.isEmpty()) return
        val yt = youTubeId(trimmed)
        val full = if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "https://$trimmed"
        haptic(25)
        viewModelScope.launch {
            val ok = when {
                yt != null && c.supportsYouTube -> c.openYouTube(yt)
                c.supportsUrl -> c.openUrl(full)
                else -> false
            }
            if (ok) {
                Achievements.unlock("streamer")
                message(if (yt != null && c.supportsYouTube) "▶ Открываем YouTube на ТВ" else "🌐 Ссылка отправлена на ТВ")
            } else if (!c.supportsUrl && !(yt != null && c.supportsYouTube)) {
                message(if (yt == null) "${c.device.protocol.short}: открытие ссылок не поддерживается протоколом. Доступны ролики YouTube" else "${c.device.protocol.short}: протокол не поддерживает открытие ссылок")
            } else message("Телевизор не принял ссылку")
        }
    }

    fun submitCode(code: String) {
        val c = _controller.value ?: return
        viewModelScope.launch { c.submitCode(code) }
    }

    fun addCustomApp(app: AppShortcut) {
        val d = _controller.value?.device ?: return
        val nd = _devices.value.firstOrNull { it.id == d.id } ?: d
        upsert(nd.copy(customApps = nd.customApps + app))
    }

    fun removeCustomApp(app: AppShortcut) {
        val d = _controller.value?.device ?: return
        val nd = _devices.value.firstOrNull { it.id == d.id } ?: d
        upsert(nd.copy(customApps = nd.customApps - app))
    }

    fun wake(d: TvDevice) {
        viewModelScope.launch {
            if (d.mac.isBlank()) { message("Укажите MAC-адрес в настройках устройства"); return@launch }
            val ok = WakeOnLan.send(d.mac, d.ip)
            message(if (ok) "Сигнал включения (Wake-on-LAN) отправлен" else "Не удалось отправить Wake-on-LAN")
            if (ok && _controller.value?.device?.id == d.id) {
                delay(8000)
                _controller.value?.let { if (it.state.value !is ConnState.Connected) it.connect() }
            }
        }
    }

    fun wakeMac(mac: String) {
        viewModelScope.launch {
            val ok = WakeOnLan.send(mac, NetUtil.localNet(ctx)?.ip)
            message(if (ok) "Magic packet отправлен на $mac" else "Неверный MAC-адрес")
        }
    }

    // ---------------- Таймер сна ----------------

    fun startSleepTimer(minutes: Int) {
        sleepJob?.cancel()
        val end = System.currentTimeMillis() + minutes * 60_000L
        sleepJob = viewModelScope.launch {
            while (true) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                _sleepLeft.value = left / 1000
                delay(1000)
            }
            _sleepLeft.value = 0
            _controller.value?.let { c ->
                c.sendKey(RKey.POWER)
                message("Таймер сна: телевизор выключен")
            }
        }
        message("Таймер сна: $minutes мин")
    }

    fun cancelSleepTimer() {
        sleepJob?.cancel(); sleepJob = null; _sleepLeft.value = 0
    }

    // ---------------- Сканирование ----------------

    fun startScan() {
        if (_scan.value.running) return
        navigate(Screen.SCAN)
        Achievements.unlock("tv_scan")
        _scan.value = ScanState(running = true, stage = "Подготовка…")
        scanJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                Discovery(ctx).scan(
                    onProgress = { p ->
                        _scan.value = _scan.value.copy(progress = if (p.total > 0) p.done.toFloat() / p.total else 0f, stage = p.stage)
                    },
                    onFound = { d ->
                        synchronized(this@AppViewModel) {
                            val list = _scan.value.found.filter { it.ip != d.ip } + d
                            _scan.value = _scan.value.copy(found = list.sortedBy { it.ip.substringAfterLast('.').toIntOrNull() ?: 0 })
                        }
                    }
                )
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) message("Ошибка сканирования: ${e.message}")
            }
            _scan.value = _scan.value.copy(running = false, finished = true, progress = 1f,
                stage = if (_scan.value.found.isEmpty()) "Телевизоры не найдены. Проверьте, что телефон и ТВ в одной Wi-Fi сети" else "Найдено: ${_scan.value.found.size}")
        }
    }

    fun stopScan() {
        scanJob?.cancel()
        _scan.value = _scan.value.copy(running = false, finished = true, stage = "Остановлено")
    }

    fun isSaved(f: FoundDevice): Boolean = _devices.value.any { it.ip == f.ip && it.protocol == f.protocol }

    fun addFound(f: FoundDevice, open: Boolean = false) {
        val existing = _devices.value.firstOrNull { it.ip == f.ip && it.protocol == f.protocol }
        val d = existing ?: TvDevice(name = f.name, ip = f.ip, protocol = f.protocol, brand = f.brand, model = f.model, mac = f.mac)
        if (existing == null) upsert(d)
        if (open) selectDevice(d) else message("«${d.name}» добавлен")
    }

    suspend fun probeManual(ip: String): FoundDevice? = Discovery(ctx).probeHost(ip.trim())

    fun addManual(name: String, ip: String, protocol: Protocol, mac: String) {
        val d = TvDevice(
            name = name.ifBlank { "ТВ $ip" },
            ip = ip.trim(), protocol = protocol, brand = protocol.short,
            mac = NetUtil.normalizeMac(mac) ?: ""
        )
        upsert(d)
        selectDevice(d)
    }

    // ---------------- Аудит сети ----------------

    fun startAudit() {
        if (_audit.value.running) return
        _audit.value = AuditState(running = true, progress = AuditProgress(0, 254, "Запуск…", true))
        auditJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                NetworkAuditor(ctx).run(
                    onProgress = { p -> _audit.value = _audit.value.copy(progress = p) },
                    onHost = { h ->
                        synchronized(this@AppViewModel) {
                            val list = _audit.value.hosts.filter { it.ip != h.ip } + h
                            _audit.value = _audit.value.copy(hosts = list.sortedBy { it.ip.substringAfterLast('.').toIntOrNull() ?: 0 })
                        }
                    }
                )
            } catch (e: Exception) {
                if (e !is kotlinx.coroutines.CancellationException) message("Ошибка аудита: ${e.message}")
            }
            _audit.value = _audit.value.copy(running = false, finished = true)
            val hosts = _audit.value.hosts
            if (hosts.isNotEmpty()) {
                val f = hosts.flatMap { it.findings }
                val sum = AuditSummary(
                    securityScore(hosts), System.currentTimeMillis(), hosts.size,
                    f.count { it.severity == Severity.CRITICAL }, f.count { it.severity == Severity.HIGH },
                    f.count { it.severity == Severity.MEDIUM }, f.count { it.severity == Severity.LOW }
                )
                store.auditSummary = sum
                _auditSummary.value = sum
                Achievements.unlock("auditor")
                if (sum.score >= 90) Achievements.unlock("fortress")
            }
        }
    }

    /** Текст отчёта аудита для «Поделиться» и сохранения. */
    fun auditReportText(): String {
        val net = localNet()?.let { "${it.ip}/${it.prefix}" } ?: "—"
        val hosts = _audit.value.hosts
        return "Оценка безопасности: ${securityScore(hosts)}/100\n\n" + buildAuditReport(hosts, net)
    }

    /** Сохраняет отчёт аудита в «Загрузки» (TXT + CSV). Возвращает путь к TXT. */
    suspend fun saveAuditReport(): String = withContext(Dispatchers.IO) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val path = FileExport.saveToDownloads(ctx, "pulttool_audit_$stamp.txt", "text/plain", auditReportText())
        val csv = buildString {
            appendLine("ip;hostname;type;brand;model;open_ports;auth;max_severity;findings")
            _audit.value.hosts.forEach { h ->
                fun q(v: String) = "\"" + v.replace("\"", "\"\"") + "\""
                appendLine(listOf(h.ip, h.hostname, h.type.title, h.brand, h.model, h.openPorts.joinToString(" "), h.authSummary,
                    h.maxSeverity.title, h.findings.joinToString(" | ") { "${it.severity.title}: ${it.title}" }).joinToString(";") { q(it) })
            }
        }
        FileExport.saveToDownloads(ctx, "pulttool_audit_$stamp.csv", "text/csv", "\uFEFF" + csv)
        Achievements.unlock("exporter")
        path
    }

    fun stopAudit() {
        auditJob?.cancel()
        _audit.value = _audit.value.copy(running = false, finished = true,
            progress = _audit.value.progress.copy(stage = "Остановлено", running = false))
    }

    fun localNet(): LocalNet? = NetUtil.localNet(ctx)

    // ---------------- Настройки ----------------

    fun updateSettings(s: AppSettings) {
        _settings.value = s
        store.saveSettings(s)
    }

    fun resetCertificate() {
        viewModelScope.launch(Dispatchers.IO) {
            CertManager.reset(ctx)
            persist(_devices.value.map { if (it.protocol == Protocol.ANDROID_TV) it.copy(paired = false) else it })
            message("Сертификат сброшен. Android TV потребуют повторного сопряжения")
        }
    }

    fun haptic(ms: Long) {
        if (_settings.value.vibration) Haptics.tick(ctx, ms)
    }

    suspend fun prewarmCert() = withContext(Dispatchers.Default) {
        try { CertManager.identity(ctx) } catch (_: Exception) {}
    }

    override fun onCleared() {
        store.pressCount = _presses.value
        _controller.value?.disconnect()
        super.onCleared()
    }
}
