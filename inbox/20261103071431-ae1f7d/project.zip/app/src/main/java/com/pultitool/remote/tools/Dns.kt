package com.pultitool.remote.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URLEncoder

data class DnsRecord(val type: String, val name: String, val data: String, val ttl: Int)

data class DnsResult(
    val query: String,
    val resolver: String,
    val records: List<DnsRecord>,
    val systemAddrs: List<String>,
    val systemMs: Long,
    val dohMs: Long,
    val status: String
)

object Dns {
    val types = listOf("A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "CAA", "PTR")
    val resolvers = listOf(
        "Cloudflare" to "https://cloudflare-dns.com/dns-query",
        "Google" to "https://dns.google/resolve"
    )

    private val typeNames = mapOf(1 to "A", 2 to "NS", 5 to "CNAME", 6 to "SOA", 12 to "PTR", 15 to "MX", 16 to "TXT", 28 to "AAAA", 257 to "CAA", 65 to "HTTPS")
    private val statusNames = mapOf(0 to "NOERROR", 1 to "FORMERR", 2 to "SERVFAIL", 3 to "NXDOMAIN", 4 to "NOTIMP", 5 to "REFUSED")

    fun isIp(s: String): Boolean = s.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")) || (s.contains(':') && s.all { it.isLetterOrDigit() || it == ':' || it == '.' })

    /** Имя для обратного запроса: 1.2.3.4 → 4.3.2.1.in-addr.arpa */
    fun reverseName(ip: String): String {
        val addr = InetAddress.getByName(ip)
        return if (addr is Inet4Address) ip.split('.').reversed().joinToString(".") + ".in-addr.arpa"
        else addr.address.joinToString("") { "%02x".format(it) }.reversed().toCharArray().joinToString(".") + ".ip6.arpa"
    }

    suspend fun lookup(input: String, type: String, resolverIdx: Int): DnsResult = withContext(Dispatchers.IO) {
        val q = input.trim().removePrefix("http://").removePrefix("https://").substringBefore('/').trimEnd('.')
        require(q.isNotEmpty()) { "Введите домен или IP" }
        val reverse = isIp(q)
        val name = if (reverse) reverseName(q) else q
        val qType = if (reverse) "PTR" else type

        // 1) Системный резолвер (DNS вашего роутера/оператора)
        val t0 = System.currentTimeMillis()
        val sys = try {
            if (reverse) {
                val h = InetAddress.getByName(q).canonicalHostName
                if (h != q) listOf(h) else emptyList()
            } else InetAddress.getAllByName(q).map {
                (if (it is Inet6Address) "AAAA " else "A ") + it.hostAddress
            }
        } catch (_: Exception) { emptyList() }
        val sysMs = System.currentTimeMillis() - t0

        // 2) DNS-over-HTTPS (JSON API)
        val (rName, rUrl) = resolvers[resolverIdx.coerceIn(0, resolvers.lastIndex)]
        val t1 = System.currentTimeMillis()
        val records = mutableListOf<DnsRecord>()
        var status = "—"
        try {
            val body = Internet.getText("$rUrl?name=${URLEncoder.encode(name, "UTF-8")}&type=$qType", mapOf("Accept" to "application/dns-json"))
            val o = JSONObject(body)
            status = statusNames[o.optInt("Status", -1)] ?: "code ${o.optInt("Status")}"
            listOf("Answer", "Authority").forEach { sect ->
                val arr = o.optJSONArray(sect) ?: return@forEach
                for (i in 0 until arr.length()) {
                    val r = arr.getJSONObject(i)
                    records += DnsRecord(typeNames[r.optInt("type")] ?: r.optInt("type").toString(), r.optString("name"), r.optString("data"), r.optInt("TTL"))
                }
            }
        } catch (e: Exception) {
            status = "Ошибка DoH: ${e.message ?: e.javaClass.simpleName}"
        }
        DnsResult(if (reverse) "$q → $name" else q, rName, records, sys, sysMs, System.currentTimeMillis() - t1, status)
    }
}
