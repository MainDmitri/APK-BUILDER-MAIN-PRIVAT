package com.pultitool.remote.audit

enum class DevType(val title: String) {
    ROUTER("Роутер / шлюз"),
    CAMERA("IP-камера"),
    DVR("Видеорегистратор DVR/NVR"),
    ADMIN_PANEL("Веб-панель управления"),
    NAS("Сетевое хранилище (NAS)"),
    PRINTER("Принтер / МФУ"),
    TV("Телевизор / медиаприставка"),
    SMART_HOME("Умный дом / IoT"),
    COMPUTER("Компьютер / сервер"),
    PHONE("Это устройство"),
    OTHER("Другое устройство")
}

enum class Severity(val title: String, val color: Long, val weight: Int) {
    CRITICAL("Критично", 0xFFFF3B5C, 4),
    HIGH("Высокий", 0xFFFF8A3D, 3),
    MEDIUM("Средний", 0xFFFFC542, 2),
    LOW("Низкий", 0xFF4FC3F7, 1),
    INFO("Инфо", 0xFF8E9AAF, 0)
}

data class Finding(val severity: Severity, val title: String, val detail: String, val advice: String)

data class WebInfo(
    val port: Int,
    val https: Boolean,
    val status: Int,
    val title: String,
    val server: String,
    val authScheme: String?,
    val realm: String?,
    val loginForm: Boolean,
    val bodySample: String
) {
    val authRequired: Boolean get() = status == 401 || authScheme != null || loginForm
}

data class RtspInfo(
    val port: Int,
    val server: String,
    val optionsStatus: Int,
    val describeStatus: Int,
    val authScheme: String?,
    val realm: String?
)

data class OnvifInfo(
    val endpoint: String,
    val manufacturer: String,
    val model: String,
    val firmware: String,
    val authRequired: Boolean?,
    val scopesName: String = "",
    val scopesHardware: String = ""
)

data class AuditHost(
    val ip: String,
    val hostname: String = "",
    val type: DevType = DevType.OTHER,
    val brand: String = "",
    val model: String = "",
    val openPorts: List<Int> = emptyList(),
    val web: List<WebInfo> = emptyList(),
    val rtsp: List<RtspInfo> = emptyList(),
    val onvif: OnvifInfo? = null,
    val upnpName: String = "",
    val findings: List<Finding> = emptyList(),
    val isGateway: Boolean = false,
    val isSelf: Boolean = false
) {
    val maxSeverity: Severity get() = findings.maxByOrNull { it.severity.weight }?.severity ?: Severity.INFO
    val authSummary: String
        get() {
            val parts = mutableListOf<String>()
            if (web.isNotEmpty()) {
                val open = web.filter { !it.authRequired && it.status in 200..299 }
                parts += if (open.isEmpty()) "веб: требуется вход" else "веб: вход не обнаружен (${open.joinToString { it.port.toString() }})"
            }
            if (rtsp.isNotEmpty()) {
                parts += if (rtsp.any { it.describeStatus in 200..299 }) "RTSP: доступ без пароля!"
                else if (rtsp.any { it.describeStatus == 401 || it.optionsStatus == 401 }) "RTSP: требуется пароль"
                else "RTSP: ответ ${rtsp.first().describeStatus.takeIf { it > 0 } ?: rtsp.first().optionsStatus}"
            }
            onvif?.authRequired?.let { parts += if (it) "ONVIF: требуется пароль" else "ONVIF: данные без пароля" }
            return parts.joinToString(" · ")
        }
}

data class AuditProgress(val done: Int, val total: Int, val stage: String, val running: Boolean)

fun portName(p: Int): String = when (p) {
    21 -> "FTP"; 22 -> "SSH"; 23 -> "Telnet"; 80 -> "HTTP"; 81 -> "HTTP-alt"; 88 -> "HTTP (Hikvision)"
    139 -> "NetBIOS"; 443 -> "HTTPS"; 445 -> "SMB"; 554 -> "RTSP"; 631 -> "IPP"; 1883 -> "MQTT"
    3000 -> "webOS/HTTP"; 3389 -> "RDP"; 5000 -> "HTTP (NAS/UPnP)"; 5001 -> "HTTPS (NAS)"
    6466 -> "Android TV"; 8000 -> "HTTP/Hik SDK"; 8001 -> "Samsung TV"; 8008 -> "Cast"
    8060 -> "Roku"; 8080 -> "HTTP-proxy"; 8081 -> "HTTP-alt"; 8123 -> "Home Assistant"
    8443 -> "HTTPS-alt"; 8554 -> "RTSP-alt"; 8899 -> "ONVIF/HTTP"; 9100 -> "JetDirect"
    34567 -> "XMeye DVR"; 37777 -> "Dahua"; else -> p.toString()
}
