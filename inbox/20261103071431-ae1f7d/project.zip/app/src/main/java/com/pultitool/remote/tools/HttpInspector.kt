package com.pultitool.remote.tools

import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

data class HeaderCheck(val name: String, val present: Boolean, val good: Boolean, val note: String)

data class HttpHop(val url: String, val code: Int, val location: String?)

data class HttpResponseInfo(
    val finalUrl: String,
    val method: String,
    val code: Int,
    val message: String,
    val protocol: String,
    val timeMs: Long,
    val headers: List<Pair<String, String>>,
    val body: String,
    val bodyBytes: Long,
    val contentType: String,
    val redirects: List<HttpHop>,
    val tls: String?,
    val cert: String?,
    val checks: List<HeaderCheck>
)

object HttpInspector {
    val methods = listOf("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")

    private fun client(ignoreCert: Boolean): OkHttpClient {
        val b = OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)
        if (ignoreCert) b.sslSocketFactory(NetUtil.trustAllFactory, NetUtil.trustAll).hostnameVerifier(NetUtil.anyHost)
        return b.build()
    }

    fun parseHeaders(text: String): Headers {
        val b = Headers.Builder()
        text.lines().map { it.trim() }.filter { it.isNotEmpty() && ':' in it }.forEach {
            b.add(it.substringBefore(':').trim(), it.substringAfter(':').trim())
        }
        return b.build()
    }

    suspend fun send(
        rawUrl: String,
        method: String,
        headersText: String,
        body: String,
        followRedirects: Boolean,
        ignoreCert: Boolean
    ): HttpResponseInfo = withContext(Dispatchers.IO) {
        var url = rawUrl.trim()
        require(url.isNotEmpty()) { "Введите адрес" }
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
        val c = client(ignoreCert)
        val headers = parseHeaders(headersText)
        val hops = mutableListOf<HttpHop>()
        var curMethod = method
        val start = System.currentTimeMillis()
        var hop = 0
        while (true) {
            val reqBody = if (curMethod in listOf("POST", "PUT", "PATCH")) body.toRequestBody((headers["Content-Type"] ?: "application/json").toMediaTypeOrNull())
            else if (curMethod == "DELETE" && body.isNotEmpty()) body.toRequestBody((headers["Content-Type"] ?: "application/json").toMediaTypeOrNull()) else null
            val rb = Request.Builder().url(url).headers(headers).method(curMethod, reqBody)
            if (headers["User-Agent"] == null) rb.header("User-Agent", "PultTool/1.0 (Android) HttpInspector")
            val resp = c.newCall(rb.build()).execute()
            resp.use { r ->
                val loc = r.header("Location")
                if (followRedirects && r.isRedirect && loc != null && hop < 10) {
                    hops += HttpHop(url, r.code, loc)
                    url = r.request.url.resolve(loc)?.toString() ?: throw IllegalStateException("Неверный Location: $loc")
                    if (r.code in listOf(301, 302, 303) && curMethod != "HEAD") curMethod = "GET"
                    hop++
                    return@use null
                }
                val bytes = if (curMethod == "HEAD") ByteArray(0) else (r.body?.source()?.let { src ->
                    src.request(256 * 1024)
                    val buf = src.buffer
                    buf.snapshot(minOf(buf.size, 256L * 1024).toInt()).toByteArray()
                } ?: ByteArray(0))
                val elapsed = System.currentTimeMillis() - start
                val ct = r.header("Content-Type") ?: ""
                val text = if (ct.contains("image") || ct.contains("octet-stream") || ct.contains("video") || ct.contains("audio")) "[двоичные данные, ${bytes.size} байт]"
                else String(bytes, Charsets.UTF_8).let { if (it.length > 20000) it.take(20000) + "\n…[обрезано]" else it }
                val hs = r.headers.map { it.first to it.second }
                val hsk = r.handshake
                val tls = hsk?.let { "${it.tlsVersion.javaName} · ${it.cipherSuite.javaName}" }
                val cert = (hsk?.peerCertificates?.firstOrNull() as? X509Certificate)?.let { x ->
                    val f = SimpleDateFormat("dd.MM.yyyy", Locale.forLanguageTag("ru"))
                    val days = (x.notAfter.time - System.currentTimeMillis()) / 86_400_000L
                    "Кому: ${x.subjectX500Principal.name}\nКем выдан: ${x.issuerX500Principal.name}\nДействует: ${f.format(x.notBefore)} – ${f.format(x.notAfter)} (осталось $days дн.)"
                }
                HttpResponseInfo(
                    url, curMethod, r.code, r.message, r.protocol.toString().uppercase(), elapsed, hs, text,
                    r.body?.contentLength()?.takeIf { it >= 0 } ?: bytes.size.toLong(), ct, hops.toList(), tls, cert,
                    analyze(r.headers, url.startsWith("https"))
                )
            }?.let { return@withContext it }
        }
        @Suppress("UNREACHABLE_CODE")
        throw IllegalStateException("unreachable")
    }

    /** Анализ заголовков безопасности ответа. */
    fun analyze(h: Headers, https: Boolean): List<HeaderCheck> {
        val out = mutableListOf<HeaderCheck>()
        fun chk(name: String, note: String, goodIf: (String) -> Boolean = { true }) {
            val v = h[name]
            out += HeaderCheck(name, v != null, v != null && goodIf(v), if (v == null) "Нет: $note" else v.take(120))
        }
        if (https) chk("Strict-Transport-Security", "браузер может открыть сайт по HTTP") { it.contains("max-age") }
        chk("Content-Security-Policy", "нет защиты от XSS-внедрений")
        chk("X-Frame-Options", "страницу можно встроить во фрейм (clickjacking)")
        chk("X-Content-Type-Options", "возможна подмена MIME-типа") { it.equals("nosniff", true) }
        chk("Referrer-Policy", "адрес страницы утекает на другие сайты")
        chk("Permissions-Policy", "не ограничен доступ к камере/гео/микрофону")
        val server = h["Server"]
        if (server != null) out += HeaderCheck("Server", true, !server.any { it.isDigit() }, if (server.any { it.isDigit() }) "Раскрывает версию ПО: $server" else server)
        val powered = h["X-Powered-By"]
        if (powered != null) out += HeaderCheck("X-Powered-By", true, false, "Раскрывает технологию: $powered")
        h.values("Set-Cookie").forEach { ck ->
            val name = ck.substringBefore('=')
            val ok = ck.contains("HttpOnly", true) && (!https || ck.contains("Secure", true))
            out += HeaderCheck("Cookie $name", true, ok, if (ok) "HttpOnly/Secure" else "Нет флагов HttpOnly/Secure")
        }
        return out
    }
}
