package com.pultitool.remote.tools

import android.content.Context
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

enum class LanKind(val title: String, val emoji: String) {
    ROUTER("Роутер", "📶"),
    SELF("Этот телефон", "📱"),
    TV("ТВ / приставка", "📺"),
    CAMERA("Камера / DVR", "📷"),
    COMPUTER("Компьютер", "💻"),
    PRINTER("Принтер", "🖨"),
    PHONE("Смартфон / планшет", "📱"),
    NAS("Хранилище", "🗄"),
    IOT("Умный дом / IoT", "💡"),
    UNKNOWN("Устройство", "❔")
}

data class LanHost(
    val ip: String,
    val name: String,
    val ports: List<Int>,
    val kind: LanKind,
    val rttMs: Double?,
    val mac: String? = null
) {
    val label: String get() = name.ifEmpty { ip }
}

/** Быстрый обзор локальной сети: ICMP/TCP-проверка доступности, обратный DNS, тип по открытым портам. */
object LanScanner {
    private val probePorts = listOf(80, 443, 22, 445, 139, 53, 554, 8008, 8009, 8060, 8001, 7000, 62078, 5353, 9100, 631, 1883, 5000, 3000, 8080, 37777)

    fun hostRange(net: com.pultitool.remote.net.LocalNet): List<String> {
        val prefix = net.prefix.coerceIn(22, 30)
        val ip = Subnet.ipToLong(net.ip)
        val mask = Subnet.prefixMask(if (net.prefix < 24) 24 else prefix)
        val base = ip and mask
        val bc = base or (mask.inv() and 0xFFFFFFFFL)
        return ((base + 1) until bc).map { Subnet.longToIp(it) }
    }

    private fun arpTable(): Map<String, String> = try {
        File("/proc/net/arp").readLines().drop(1).mapNotNull { l ->
            val p = l.trim().split(Regex("\\s+"))
            if (p.size >= 4 && p[3] != "00:00:00:00:00:00") p[0] to p[3].uppercase() else null
        }.toMap()
    } catch (_: Exception) { emptyMap() }

    private fun classify(ip: String, ports: List<Int>, name: String, gw: String?, self: String): LanKind {
        val n = name.lowercase()
        return when {
            ip == self -> LanKind.SELF
            ip == gw -> LanKind.ROUTER
            554 in ports || 37777 in ports || n.contains("cam") || n.contains("ipc") || n.contains("dvr") || n.contains("nvr") -> LanKind.CAMERA
            8008 in ports || 8009 in ports || 8060 in ports || 8001 in ports || n.contains("tv") || n.contains("chromecast") || n.contains("roku") -> LanKind.TV
            9100 in ports || 631 in ports || n.contains("print") || n.contains("hp") || n.contains("epson") -> LanKind.PRINTER
            62078 in ports || n.contains("iphone") || n.contains("ipad") || n.contains("android") || n.contains("galaxy") || n.contains("redmi") -> LanKind.PHONE
            5000 in ports && 445 in ports || n.contains("nas") || n.contains("synology") || n.contains("diskstation") -> LanKind.NAS
            445 in ports || 139 in ports || 22 in ports || 3389 in ports || n.contains("pc") || n.contains("desktop") || n.contains("laptop") || n.contains("macbook") -> LanKind.COMPUTER
            1883 in ports || n.contains("esp") || n.contains("tasmota") || n.contains("shelly") || n.contains("yeelight") -> LanKind.IOT
            else -> LanKind.UNKNOWN
        }
    }

    suspend fun scan(context: Context, onProgress: (Int, Int) -> Unit, onHost: (LanHost) -> Unit): List<LanHost> = withContext(Dispatchers.IO) {
        val net = NetUtil.localNet(context) ?: throw IllegalStateException("Нет подключения к локальной сети")
        val ips = hostRange(net)
        val sem = Semaphore(48)
        var done = 0
        val lock = Any()
        val found = coroutineScope {
            ips.map { ip ->
                async {
                    sem.withPermit {
                        val r = probe(ip, net.gateway, net.ip)
                        val d = synchronized(lock) { ++done }
                        if (d % 8 == 0 || d == ips.size) onProgress(d, ips.size)
                        r?.also(onHost)
                    }
                }
            }.awaitAll().filterNotNull()
        }
        val arp = arpTable()
        found.map { h -> arp[h.ip]?.let { h.copy(mac = it) } ?: h }.sortedBy { Subnet.ipToLong(it.ip) }
    }

    private fun probe(ip: String, gw: String?, self: String): LanHost? {
        val t0 = System.nanoTime()
        var alive = ip == self
        var rtt: Double? = null
        try {
            if (!alive && InetAddress.getByName(ip).isReachable(350)) { alive = true; rtt = (System.nanoTime() - t0) / 1e6 }
        } catch (_: Exception) {
        }
        val open = mutableListOf<Int>()
        for (p in probePorts) {
            val s0 = System.nanoTime()
            try {
                Socket().use { it.connect(InetSocketAddress(ip, p), 180) }
                open += p
                alive = true
                if (rtt == null) rtt = (System.nanoTime() - s0) / 1e6
            } catch (e: java.net.ConnectException) {
                // «Connection refused» — хост ответил RST, значит он в сети
                if ((System.nanoTime() - s0) / 1e6 < 170) { alive = true; if (rtt == null) rtt = (System.nanoTime() - s0) / 1e6 }
            } catch (_: Exception) {
            }
            if (!alive && p == 445) break // если на первые порты тишина и ICMP молчит — считаем хост выключенным
        }
        if (!alive) return null
        val name = try {
            InetAddress.getByName(ip).canonicalHostName.takeIf { it != ip }?.removeSuffix(".local")?.removeSuffix(".lan")?.removeSuffix(".home") ?: ""
        } catch (_: Exception) { "" }
        return LanHost(ip, if (ip == self) "Этот телефон" else name, open, classify(ip, open, name, gw, self), rtt)
    }
}
