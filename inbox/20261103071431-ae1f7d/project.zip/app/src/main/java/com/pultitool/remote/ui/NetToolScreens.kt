package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.tools.Dns
import com.pultitool.remote.tools.HttpInspector
import com.pultitool.remote.tools.PortScan
import com.pultitool.remote.tools.Subnet
import com.pultitool.remote.tools.SubnetInfo
import com.pultitool.remote.util.Achievements

// ======================= Проверка портов =======================

@Composable
fun PortsScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.ports.collectAsState()
    var timeout by remember { mutableFloatStateOf(400f) }
    var banner by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { if (st.host.isEmpty()) vm.localNet()?.gateway?.let { gw -> tools.setPorts { it.copy(host = gw) } } }

    ToolScaffold("Проверка портов", "TCP-порты одного устройства", onBack = { tools.stopPorts(); vm.back() }) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Проверяйте только свои устройства или те, на которые у вас есть разрешение. Сканирование чужих узлов может нарушать закон.",
                color = Pal.yellow, fontSize = 12.sp)
        }
        ToolField(st.host, { v -> tools.setPorts { it.copy(host = v) } }, "IP-адрес или имя хоста")
        ToolField(st.spec, { v -> tools.setPorts { it.copy(spec = v) } }, "Порты: 22,80,443,8000-8100", keyboard = KeyboardType.Text, singleLine = false)
        ChipRow(PortScan.presets.map { it.first }) { i -> tools.setPorts { it.copy(spec = PortScan.presets[i].second) } }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Таймаут: ${timeout.toInt()} мс", color = Pal.textDim, fontSize = 12.sp)
            Slider(timeout, { timeout = it }, valueRange = 100f..2000f)
            ToggleRow("Читать приветствие сервиса", banner, "SSH, FTP, SMTP и др. сообщают версию") { banner = it }
        }
        if (st.running) GhostButton("Остановить", Modifier.fillMaxWidth()) { tools.stopPorts() }
        else GradientButton("Проверить порты", Modifier.fillMaxWidth(), Glyph.DOOR) { tools.startPorts(timeout.toInt(), banner) }
        ErrorText(st.error)
        if (st.total > 0) ProgressLine(st.done.toFloat() / st.total, "${st.done} из ${st.total} · открыто ${st.open.size} · ${st.elapsedMs / 1000.0} с")
        st.open.forEach { r ->
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)).background(Pal.green.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                    Text("${r.port}", color = Pal.green, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.service, color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (r.banner.isNotEmpty()) Text(r.banner, color = Pal.textDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace, maxLines = 2)
                }
                Text("%.0f мс".format(r.rttMs), color = Pal.textDim, fontSize = 11.sp)
            }
        }
        if (st.finished && !st.running && st.open.isEmpty() && st.error == null && st.total > 0)
            Text("Открытых портов не найдено (или они фильтруются брандмауэром)", color = Pal.textDim, fontSize = 13.sp)
    }
}

// ======================= Трассировка =======================

@Composable
fun TraceScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.trace.collectAsState()
    ToolScaffold("Трассировка", "Путь пакетов до узла (ping с растущим TTL)", onBack = { tools.stopTrace(); vm.back() }) {
        ToolField(st.host, { tools.setTraceHost(it) }, "Хост или IP", onGo = { tools.startTrace() })
        ChipRow(listOf("google.com", "ya.ru", "1.1.1.1", "8.8.8.8")) { i -> tools.setTraceHost(listOf("google.com", "ya.ru", "1.1.1.1", "8.8.8.8")[i]) }
        if (st.running) GhostButton("Остановить", Modifier.fillMaxWidth()) { tools.stopTrace() }
        else GradientButton("Начать трассировку", Modifier.fillMaxWidth(), Glyph.ROUTE) { tools.startTrace() }
        ErrorText(st.error)
        if (st.running) ProgressLine(st.hops.size / 30f, "Узел ${st.hops.size + 1}…")
        val maxRtt = (st.hops.mapNotNull { it.rttMs }.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        st.hops.forEachIndexed { i, h ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(36.dp)) {
                    Box(Modifier.size(28.dp).clip(CircleShape).background(if (h.reached) Pal.green else if (h.ip == null) Color(0x33FFFFFF) else LocalAccent.current.a),
                        contentAlignment = Alignment.Center) { Text("${h.ttl}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    if (i < st.hops.lastIndex || st.running) Box(Modifier.width(2.dp).height(22.dp).background(Color(0x33FFFFFF)))
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(h.ip ?: "* * *  (узел не ответил)", color = if (h.ip == null) Pal.textDim else Pal.text, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    if (h.host.isNotEmpty()) Text(h.host, color = Pal.textDim, fontSize = 11.sp, maxLines = 1)
                    h.rttMs?.let { r ->
                        Box(Modifier.padding(top = 3.dp).fillMaxWidth((r / maxRtt).toFloat().coerceIn(0.05f, 1f)).height(4.dp).clip(RoundedCornerShape(2.dp)).background(latencyColor(r)))
                    }
                }
                Text(h.rttMs?.let { "%.0f мс".format(it) } ?: "", color = latencyColor(h.rttMs), fontSize = 12.sp)
            }
        }
        if (st.finished && st.hops.lastOrNull()?.reached == true) Text("✓ Узел достигнут за ${st.hops.size} прыжков", color = Pal.green, fontSize = 13.sp)
    }
}

// ======================= DNS =======================

@Composable
fun DnsScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.dns.collectAsState()
    var query by remember { mutableStateOf("google.com") }
    var type by remember { mutableIntStateOf(0) }
    var resolver by remember { mutableIntStateOf(0) }
    val isReverse = Dns.isIp(query.trim())

    ToolScaffold("DNS-запрос", "Записи домена и обратный поиск по IP", onBack = { vm.back() }) {
        ToolField(query, { query = it }, "Домен или IP (для обратного запроса)", onGo = { tools.lookupDns(query, Dns.types[type], resolver) })
        if (!isReverse) {
            Row(Modifier.fillMaxWidth().horizontalScrollSafe(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Dns.types.forEachIndexed { i, t ->
                    Chip(t, if (i == type) LocalAccent.current.b else Pal.textDim, Modifier.clickable { type = i })
                }
            }
        } else Text("Обратный запрос PTR: ${runCatching { Dns.reverseName(query.trim()) }.getOrDefault("")}", color = Pal.textDim, fontSize = 12.sp)
        SegmentRow(Dns.resolvers.map { "DoH ${it.first}" }, resolver) { resolver = it }
        GradientButton(if (st.loading) "Запрос…" else "Найти", Modifier.fillMaxWidth(), Glyph.SEARCH, enabled = !st.loading) {
            tools.lookupDns(query, Dns.types[type], resolver)
        }
        ErrorText(st.error)
        st.data?.let { r ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.query, color = Pal.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Chip(r.status, if (r.status == "NOERROR") Pal.green else Pal.yellow)
                }
                InfoRow("Резолвер", "${r.resolver} (DoH) · ${r.dohMs} мс")
                InfoRow("Системный DNS", "${r.systemMs} мс")
            }
            if (r.systemAddrs.isNotEmpty()) {
                SectionTitle("Системный резолвер")
                MonoBox(r.systemAddrs.joinToString("\n"))
            }
            SectionTitle("Записи (${r.records.size})")
            if (r.records.isEmpty()) Text("Записей этого типа нет", color = Pal.textDim, fontSize = 13.sp)
            r.records.forEach { rec ->
                Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Chip(rec.type, LocalAccent.current.b)
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        SelectionContainer { Text(rec.data, color = Pal.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                        Text("${rec.name} · TTL ${rec.ttl} с", color = Pal.textDim, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// ======================= Внешний IP =======================

@Composable
fun PublicIpScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.ip.collectAsState()
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { if (st.data == null && !st.loading) tools.fetchIp() }
    val net = vm.localNet()

    ToolScaffold("Внешний IP", "Адрес, провайдер и примерное местоположение", onBack = { vm.back() }) {
        ErrorText(st.error)
        st.data?.let { d ->
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(d.flag, fontSize = 52.sp)
                SelectionContainer { Text(d.ip, color = Pal.text, fontSize = 26.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace) }
                Text(listOf(d.city, d.region, d.country).filter { it.isNotBlank() }.distinct().joinToString(", "), color = Pal.textDim, fontSize = 14.sp)
                Spacer(Modifier.height(8.dp))
                CopyChip(d.ip)
            }
            GlassCard(Modifier.fillMaxWidth()) {
                InfoRow("Провайдер", d.isp.ifBlank { "—" })
                InfoRow("ASN", d.asn.ifBlank { "—" })
                InfoRow("Часовой пояс", d.timezone.ifBlank { "—" })
                InfoRow("Координаты", "%.3f, %.3f".format(d.lat, d.lon))
                InfoRow("Источник", d.source)
                if (net != null) InfoRow("Локальный IP", net.ip)
            }
            val cgnat = d.ip.startsWith("100.") && (d.ip.split('.').getOrNull(1)?.toIntOrNull() ?: 0) in 64..127
            GlassCard(Modifier.fillMaxWidth()) {
                Text("Что это значит", color = Pal.text, fontWeight = FontWeight.Bold)
                Text(
                    (if (cgnat) "Адрес из диапазона CGNAT — провайдер выдаёт один IP на много абонентов, проброс портов работать не будет. " else "") +
                        "Это адрес, под которым ваш роутер виден в Интернете. Геолокация определяется по базе провайдеров и обычно точна до города.",
                    color = Pal.textDim, fontSize = 13.sp
                )
            }
            GhostButton("Открыть на карте", Modifier.fillMaxWidth()) {
                try {
                    ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                        android.net.Uri.parse("geo:${d.lat},${d.lon}?q=${d.lat},${d.lon}")))
                } catch (_: Exception) {
                    copyText(ctx, "${d.lat}, ${d.lon}")
                }
            }
        }
        GradientButton(if (st.loading) "Определяем…" else "Обновить", Modifier.fillMaxWidth(), Glyph.GLOBE, enabled = !st.loading) { tools.fetchIp() }
    }
}

// ======================= Калькулятор подсетей =======================

@Composable
fun SubnetScreen(vm: AppViewModel) {
    val net = remember { vm.localNet() }
    var input by remember { mutableStateOf(net?.let { "${it.ip}/${it.prefix}" } ?: "192.168.1.10/24") }
    var split by remember { mutableStateOf("") }
    val result: Result<SubnetInfo> = remember(input, split) { runCatching { Subnet.calc(input, split.trim().removePrefix("/").toIntOrNull()) } }
    LaunchedEffect(result.isSuccess) { if (result.isSuccess) Achievements.unlock("subnet") }

    ToolScaffold("Калькулятор подсетей", "IPv4: маска, диапазон, число хостов", onBack = { vm.back() }) {
        ToolField(input, { input = it }, "IP/префикс или IP маска", keyboard = KeyboardType.Text)
        ChipRow(listOf("/8", "/16", "/24", "/25", "/26", "/28", "/30")) { i ->
            input = input.substringBefore('/').substringBefore(' ') + listOf("/8", "/16", "/24", "/25", "/26", "/28", "/30")[i]
        }
        ToolField(split, { split = it }, "Разбить на подсети с префиксом (необязательно), например 26", keyboard = KeyboardType.Number)
        result.exceptionOrNull()?.let { ErrorText(it.message) }
        result.getOrNull()?.let { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat("/${r.prefix}", "префикс", Modifier.weight(1f), LocalAccent.current.b)
                MiniStat("%,d".format(r.hosts).replace(',', ' '), "хостов", Modifier.weight(1f), Pal.green)
                MiniStat(r.ipClass.take(1), "класс", Modifier.weight(1f))
            }
            GlassCard(Modifier.fillMaxWidth()) {
                InfoRow("Адрес", r.ip)
                InfoRow("Маска", r.mask)
                InfoRow("Обратная маска", r.wildcard)
                InfoRow("Сеть", r.network)
                InfoRow("Широковещательный", r.broadcast)
                InfoRow("Первый хост", r.firstHost)
                InfoRow("Последний хост", r.lastHost)
                InfoRow("Класс", r.ipClass)
                InfoRow("Тип", r.scope)
                InfoRow("HEX", r.hex)
            }
            SectionTitle("В двоичном виде")
            MonoBox("IP    ${r.binIp}\nМаска ${r.binMask}")
            if (r.subnets.isNotEmpty()) {
                SectionTitle("Подсети (${r.subnets.size}${if (r.subnets.size >= 64) "+" else ""})")
                MonoBox(r.subnets.joinToString("\n"))
            }
        }
    }
}

// ======================= HTTP-инспектор =======================

@Composable
fun HttpScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.http.collectAsState()
    var url by remember { mutableStateOf("https://example.com") }
    var method by remember { mutableIntStateOf(0) }
    var headers by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var follow by remember { mutableStateOf(true) }
    var ignoreCert by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    val m = HttpInspector.methods[method]

    ToolScaffold("HTTP-инспектор", "Запросы, заголовки, TLS и безопасность", onBack = { vm.back() }) {
        ToolField(url, { url = it }, "URL", onGo = { tools.sendHttp(url, m, headers, body, follow, ignoreCert) })
        Row(Modifier.fillMaxWidth().horizontalScrollSafe(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HttpInspector.methods.forEachIndexed { i, t -> Chip(t, if (i == method) LocalAccent.current.b else Pal.textDim, Modifier.clickable { method = i }) }
        }
        ToolField(headers, { headers = it }, "Заголовки (Имя: значение, по строке)", keyboard = KeyboardType.Text, singleLine = false, minLines = 2)
        if (m in listOf("POST", "PUT", "PATCH", "DELETE")) ToolField(body, { body = it }, "Тело запроса", keyboard = KeyboardType.Text, singleLine = false, minLines = 3)
        GlassCard(Modifier.fillMaxWidth()) {
            ToggleRow("Следовать редиректам", follow) { follow = it }
            ToggleRow("Игнорировать сертификат", ignoreCert, "Для устройств с самоподписанным HTTPS") { ignoreCert = it }
        }
        GradientButton(if (st.loading) "Отправка…" else "Отправить $m", Modifier.fillMaxWidth(), Glyph.CODE, enabled = !st.loading) {
            tools.sendHttp(url, m, headers, body, follow, ignoreCert)
        }
        ErrorText(st.error)
        st.data?.let { r ->
            val codeColor = when (r.code) { in 200..299 -> Pal.green; in 300..399 -> LocalAccent.current.b; in 400..499 -> Pal.yellow; else -> Pal.red }
            Row(Modifier.fillMaxWidth().glass().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${r.code}", color = codeColor, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(r.message.ifBlank { "HTTP ${r.code}" }, color = Pal.text, fontWeight = FontWeight.Bold)
                    Text("${r.protocol} · ${r.timeMs} мс · ${r.bodyBytes} байт", color = Pal.textDim, fontSize = 12.sp)
                    Text(r.finalUrl, color = Pal.textDim, fontSize = 11.sp, maxLines = 1)
                }
            }
            if (r.redirects.isNotEmpty()) GlassCard(Modifier.fillMaxWidth()) {
                Text("Редиректы", color = Pal.text, fontWeight = FontWeight.Bold)
                r.redirects.forEach { h -> Text("${h.code} ${h.url}\n   → ${h.location}", color = Pal.textDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
            }
            SegmentRow(listOf("Безопасность", "Заголовки", "Тело", "TLS"), tab) { tab = it }
            when (tab) {
                0 -> {
                    val good = r.checks.count { it.good }
                    Text("Пройдено проверок: $good из ${r.checks.size}", color = Pal.textDim, fontSize = 12.sp)
                    r.checks.forEach { c ->
                        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (c.good) "✓" else "✕", color = if (c.good) Pal.green else Pal.red, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.width(26.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.name, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(c.note, color = Pal.textDim, fontSize = 11.sp)
                            }
                        }
                    }
                }
                1 -> {
                    val text = r.headers.joinToString("\n") { "${it.first}: ${it.second}" }
                    CopyChip(text); MonoBox(text)
                }
                2 -> {
                    if (r.contentType.isNotBlank()) Text(r.contentType, color = Pal.textDim, fontSize = 12.sp)
                    CopyChip(r.body); MonoBox(r.body.ifEmpty { "(пусто)" })
                }
                else -> MonoBox(listOfNotNull(r.tls, r.cert).joinToString("\n\n").ifEmpty { "Соединение без TLS (HTTP)" })
            }
        }
    }
}
