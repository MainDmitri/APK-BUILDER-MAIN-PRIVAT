package com.pultitool.remote.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

data class PublicIpInfo(
    val ip: String,
    val country: String,
    val countryCode: String,
    val region: String,
    val city: String,
    val lat: Double,
    val lon: Double,
    val isp: String,
    val asn: String,
    val timezone: String,
    val source: String
) {
    val flag: String
        get() = if (countryCode.length == 2) countryCode.uppercase().map { Character.toChars(0x1F1E6 + (it - 'A')).concatToString() }.joinToString("") else "🌐"
}

object PublicIp {
    suspend fun fetch(): PublicIpInfo = withContext(Dispatchers.IO) {
        val errors = mutableListOf<String>()
        try {
            val o = JSONObject(Internet.getText("https://ipwho.is/"))
            if (o.optBoolean("success", false)) {
                val c = o.optJSONObject("connection")
                val tz = o.optJSONObject("timezone")
                return@withContext PublicIpInfo(
                    o.optString("ip"), o.optString("country"), o.optString("country_code"), o.optString("region"), o.optString("city"),
                    o.optDouble("latitude", 0.0), o.optDouble("longitude", 0.0),
                    c?.optString("isp")?.ifEmpty { c.optString("org") } ?: "", c?.optLong("asn")?.let { if (it > 0) "AS$it" else "" } ?: "",
                    tz?.optString("id") ?: "", "ipwho.is"
                )
            } else errors += "ipwho.is: ${o.optString("message")}"
        } catch (e: Exception) {
            errors += "ipwho.is: ${e.message}"
        }
        try {
            val o = JSONObject(Internet.getText("https://ipapi.co/json/"))
            if (!o.optBoolean("error", false)) {
                return@withContext PublicIpInfo(
                    o.optString("ip"), o.optString("country_name"), o.optString("country_code"), o.optString("region"), o.optString("city"),
                    o.optDouble("latitude", 0.0), o.optDouble("longitude", 0.0),
                    o.optString("org"), o.optString("asn"), o.optString("timezone"), "ipapi.co"
                )
            } else errors += "ipapi.co: ${o.optString("reason")}"
        } catch (e: Exception) {
            errors += "ipapi.co: ${e.message}"
        }
        throw IllegalStateException("Не удалось получить внешний IP. ${errors.joinToString("; ")}")
    }
}
