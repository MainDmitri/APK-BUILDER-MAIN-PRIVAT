package com.pultitool.remote.data

import org.json.JSONObject
import java.util.UUID

enum class Protocol(val title: String, val short: String) {
    ANDROID_TV("Android TV / Google TV", "Android TV"),
    SAMSUNG("Samsung Tizen", "Samsung"),
    LG("LG webOS", "LG"),
    ROKU("Roku ECP", "Roku"),
    PHILIPS("Philips JointSpace", "Philips"),
    SONY("Sony Bravia (IRCC)", "Sony");

    companion object {
        fun of(name: String?): Protocol = entries.firstOrNull { it.name == name } ?: ANDROID_TV
    }
}

data class TvDevice(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val ip: String = "",
    val protocol: Protocol,
    val brand: String = "",
    val model: String = "",
    val mac: String = "",
    val token: String = "",
    val psk: String = "",
    val paired: Boolean = false,
    val favorite: Boolean = false,
    val lastUsed: Long = 0L,
    val customApps: List<AppShortcut> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("ip", ip); put("protocol", protocol.name)
        put("brand", brand); put("model", model); put("mac", mac); put("token", token)
        put("psk", psk); put("paired", paired); put("favorite", favorite); put("lastUsed", lastUsed)
        val arr = org.json.JSONArray()
        customApps.forEach { arr.put(it.toJson()) }
        put("customApps", arr)
    }

    companion object {
        fun fromJson(o: JSONObject): TvDevice {
            val apps = mutableListOf<AppShortcut>()
            val arr = o.optJSONArray("customApps")
            if (arr != null) for (i in 0 until arr.length()) apps.add(AppShortcut.fromJson(arr.getJSONObject(i)))
            return TvDevice(
                id = o.optString("id", UUID.randomUUID().toString()),
                name = o.optString("name", "ТВ"),
                ip = o.optString("ip", ""),
                protocol = Protocol.of(o.optString("protocol")),
                brand = o.optString("brand", ""),
                model = o.optString("model", ""),
                mac = o.optString("mac", ""),
                token = o.optString("token", ""),
                psk = o.optString("psk", ""),
                paired = o.optBoolean("paired", false),
                favorite = o.optBoolean("favorite", false),
                lastUsed = o.optLong("lastUsed", 0L),
                customApps = apps
            )
        }
    }
}

/** Ярлык приложения: id зависит от протокола (deeplink, appId, channel id). */
data class AppShortcut(val title: String, val id: String, val color: Long = 0xFF6C5CE7) {
    fun toJson(): JSONObject = JSONObject().put("title", title).put("id", id).put("color", color)

    companion object {
        fun fromJson(o: JSONObject) = AppShortcut(o.optString("title"), o.optString("id"), o.optLong("color", 0xFF6C5CE7))
    }
}

/** Найденное при сканировании устройство. */
data class FoundDevice(
    val ip: String,
    val name: String,
    val protocol: Protocol,
    val brand: String,
    val model: String = "",
    val mac: String = "",
    val ports: List<Int> = emptyList(),
    val source: String = ""
)

enum class RKey {
    POWER, UP, DOWN, LEFT, RIGHT, OK, BACK, HOME, MENU,
    VOL_UP, VOL_DOWN, MUTE, CH_UP, CH_DOWN,
    D0, D1, D2, D3, D4, D5, D6, D7, D8, D9,
    PLAY_PAUSE, PLAY, PAUSE, STOP, REWIND, FAST_FORWARD, PREV, NEXT,
    INPUT, INFO, SETTINGS, EXIT, GUIDE, SEARCH,
    RED, GREEN, YELLOW, BLUE, DEL, ENTER;

    companion object {
        fun digit(d: Int): RKey = entries[D0.ordinal + d.coerceIn(0, 9)]
    }
}

data class AppSettings(
    val vibration: Boolean = true,
    val keepScreenOn: Boolean = false,
    val volumeKeys: Boolean = true,
    val accent: Int = 0,
    val autoConnect: Boolean = true,
    val sounds: Boolean = false,
    /** Чёрная AMOLED-тема (экономит заряд на OLED-экранах). */
    val amoled: Boolean = false,
    /** Встряхнуть телефон — выключить звук на ТВ. */
    val shakeMute: Boolean = false,
    /** Интервал проверки сети монитором, секунд. */
    val monitorInterval: Int = 60,
    /** Вибрация при появлении нового устройства в сети. */
    val monitorVibrate: Boolean = true
)
