package com.pultitool.remote.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/** Детектор встряхивания по акселерометру: два резких рывка (> 2.6 g) за 600 мс. */
class ShakeDetector(context: Context, private val onShake: () -> Unit) : SensorEventListener {
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private var lastPeak = 0L
    private var peaks = 0
    private var lastShake = 0L
    private var registered = false

    val available: Boolean get() = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null

    fun start() {
        if (registered) return
        val s = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        registered = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
    }

    fun stop() {
        if (!registered) return
        sm?.unregisterListener(this)
        registered = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val gx = e.values[0] / SensorManager.GRAVITY_EARTH
        val gy = e.values[1] / SensorManager.GRAVITY_EARTH
        val gz = e.values[2] / SensorManager.GRAVITY_EARTH
        val g = sqrt(gx * gx + gy * gy + gz * gz)
        if (g < 2.6f) return
        val now = System.currentTimeMillis()
        if (now - lastPeak > 600) peaks = 0
        if (now - lastPeak > 120) { peaks++; lastPeak = now }
        if (peaks >= 2 && now - lastShake > 1500) {
            lastShake = now
            peaks = 0
            onShake()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
