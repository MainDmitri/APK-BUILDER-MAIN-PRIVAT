package com.pultitool.remote.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.audit.portName
import com.pultitool.remote.tools.LanHost
import com.pultitool.remote.tools.LanKind
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private fun kindColor(k: LanKind): Color = when (k) {
    LanKind.ROUTER -> Color(0xFFFFC542)
    LanKind.SELF -> Color(0xFF2EE59D)
    LanKind.TV -> Color(0xFF00E5FF)
    LanKind.CAMERA -> Color(0xFFFF3B5C)
    LanKind.COMPUTER -> Color(0xFF7C4DFF)
    LanKind.PRINTER -> Color(0xFFFF9100)
    LanKind.PHONE -> Color(0xFF00E676)
    LanKind.NAS -> Color(0xFF536DFE)
    LanKind.IOT -> Color(0xFFFF4081)
    LanKind.UNKNOWN -> Color(0xFFA7A3C2)
}

@Composable
fun NetMapScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.map.collectAsState()
    var selected by remember { mutableStateOf<LanHost?>(null) }
    LaunchedEffect(Unit) { if (st.hosts.isEmpty() && !st.running) tools.scanMap() }

    val inf = rememberInfiniteTransition(label = "map")
    val rot by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(60000, easing = LinearEasing)), label = "rot")
    val pulse by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "pulse")
    val dash by inf.animateFloat(0f, 40f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "dash")

    val router = st.hosts.firstOrNull { it.kind == LanKind.ROUTER } ?: st.gateway?.let { LanHost(it, "Роутер", emptyList(), LanKind.ROUTER, null) }
    val others = st.hosts.filter { it.ip != router?.ip }
    // Позиции узлов в долях от центра: два кольца, если устройств много
    val positions = run {
        val inner = if (others.size > 12) others.take(others.size / 2) else others
        val outer = if (others.size > 12) others.drop(others.size / 2) else emptyList()
        val m = mutableMapOf<String, Pair<Float, Float>>()
        inner.forEachIndexed { i, h ->
            val a = Math.toRadians(rot + 360.0 * i / inner.size)
            m[h.ip] = (0.55f * cos(a).toFloat()) to (0.55f * sin(a).toFloat())
        }
        outer.forEachIndexed { i, h ->
            val a = Math.toRadians(-rot * 0.7 + 360.0 * i / outer.size + 15)
            m[h.ip] = (0.88f * cos(a).toFloat()) to (0.88f * sin(a).toFloat())
        }
        m
    }
    val posRef = rememberUpdatedState(positions)
    val othersRef = rememberUpdatedState(others)
    val routerRef = rememberUpdatedState(router)

    ToolScaffold("Карта сети", if (st.running) "Сканирование ${st.done}/${st.total}…" else "${st.hosts.size} устройств · коснитесь узла", onBack = { tools.stopMap(); vm.back() }) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).glass(RoundedCornerShape(28.dp))) {
            Canvas(
                Modifier.fillMaxWidth().aspectRatio(1f).pointerInput(Unit) {
                    detectTapGestures { tap ->
                        val cx = size.width / 2f
                        val cy = size.height / 2f
                        val r = min(cx, cy) * 0.86f
                        val router = routerRef.value
                        val others = othersRef.value
                        val positions = posRef.value
                        if (router != null && hypot(tap.x - cx, tap.y - cy) < 40f) { selected = router; return@detectTapGestures }
                        val hit = others.minByOrNull { h ->
                            val p = positions[h.ip] ?: return@minByOrNull Float.MAX_VALUE
                            hypot(tap.x - (cx + p.first * r), tap.y - (cy + p.second * r))
                        }
                        val p = hit?.let { positions[it.ip] }
                        if (hit != null && p != null && hypot(tap.x - (cx + p.first * r), tap.y - (cy + p.second * r)) < 60f) selected = hit
                    }
                }
            ) {
                val c = Offset(size.width / 2, size.height / 2)
                val r = min(c.x, c.y) * 0.86f
                // Кольца радара и волна сканирования
                listOf(0.55f, 0.88f).forEach { drawCircle(Color(0x1FFFFFFF), r * it, c, style = Stroke(1.5f)) }
                drawCircle(Color(0x33FFFFFF), r * pulse, c, style = Stroke(3f * (1 - pulse)))
                val paint = android.graphics.Paint().apply { color = android.graphics.Color.WHITE; textSize = 26f; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
                val sub = android.graphics.Paint(paint).apply { color = 0xFFA7A3C2.toInt(); textSize = 20f }
                others.forEach { h ->
                    val p = positions[h.ip] ?: return@forEach
                    val pos = Offset(c.x + p.first * r, c.y + p.second * r)
                    val col = kindColor(h.kind)
                    drawLine(col.copy(alpha = 0.45f), c, pos, 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), -dash))
                    drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.5f), Color.Transparent), pos, 46f), 46f, pos)
                    drawCircle(col, 20f, pos)
                    drawCircle(Color.White, 20f, pos, style = Stroke(if (selected?.ip == h.ip) 5f else 1.5f))
                    drawContext.canvas.nativeCanvas.drawText(h.kind.emoji, pos.x, pos.y + 9f, paint)
                    drawContext.canvas.nativeCanvas.drawText(h.label.take(14), pos.x, pos.y + 46f, sub)
                }
                if (router != null) {
                    drawCircle(Brush.radialGradient(listOf(Color(0xAAFFC542), Color.Transparent), c, 80f), 80f, c)
                    drawCircle(Color(0xFFFFC542), 34f, c)
                    drawContext.canvas.nativeCanvas.drawText("📶", c.x, c.y + 10f, paint)
                    drawContext.canvas.nativeCanvas.drawText(router.ip, c.x, c.y + 62f, sub)
                }
            }
            if (st.hosts.isEmpty() && !st.running) Text("Устройства не найдены", color = Pal.textDim, modifier = Modifier.align(Alignment.Center))
        }
        if (st.running) ProgressLine(if (st.total > 0) st.done.toFloat() / st.total else 0f, "Найдено ${st.hosts.size}")
        ErrorText(st.error)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (st.running) GhostButton("Остановить", Modifier.weight(1f)) { tools.stopMap() }
            else GradientButton("Пересканировать", Modifier.weight(1f), Glyph.RADAR) { tools.scanMap() }
            GhostButton("Аудит", Modifier.weight(0.6f)) { vm.navigate(Screen.AUDIT) }
        }
        // Легенда
        val kinds = st.hosts.groupBy { it.kind }
        if (kinds.isNotEmpty()) GlassCard(Modifier.fillMaxWidth()) {
            kinds.forEach { (k, l) ->
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                    StatusDot(kindColor(k)); Spacer(Modifier.width(8.dp))
                    Text("${k.emoji} ${k.title}", color = Pal.text, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text("${l.size}", color = Pal.textDim, fontSize = 13.sp)
                }
            }
        }
        st.hosts.forEach { h ->
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(h.kind.emoji, fontSize = 20.sp); Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(h.label, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
                    Text("${h.ip}${if (h.ports.isNotEmpty()) " · порты ${h.ports.joinToString(",")}" else ""}", color = Pal.textDim, fontSize = 11.sp, maxLines = 1)
                }
                h.rttMs?.let { Text("%.0f мс".format(it), color = latencyColor(it), fontSize = 11.sp) }
            }
        }
    }

    selected?.let { h ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text("${h.kind.emoji} ${h.label}") },
            text = {
                Column {
                    InfoRow("IP-адрес", h.ip)
                    InfoRow("Тип", h.kind.title)
                    InfoRow("Имя в сети", h.name.ifBlank { "—" })
                    h.mac?.let { InfoRow("MAC", it) }
                    InfoRow("Отклик", h.rttMs?.let { "%.0f мс".format(it) } ?: "—")
                    Spacer(Modifier.height(6.dp))
                    Text("Открытые порты", color = Pal.textDim, fontSize = 12.sp)
                    if (h.ports.isEmpty()) Text("Не обнаружены среди типовых", color = Pal.text, fontSize = 13.sp)
                    h.ports.forEach { Text("• $it — ${portName(it)}", color = Pal.text, fontSize = 13.sp) }
                }
            },
            confirmButton = {
                TextButton({
                    tools.setPing { it.copy(host = h.ip) }; selected = null; vm.navigate(Screen.PING)
                }) { Text("Пинг") }
            },
            dismissButton = {
                TextButton({
                    tools.setPorts { it.copy(host = h.ip) }; selected = null; vm.navigate(Screen.PORTS)
                }) { Text("Порты") }
            }
        )
    }
}
