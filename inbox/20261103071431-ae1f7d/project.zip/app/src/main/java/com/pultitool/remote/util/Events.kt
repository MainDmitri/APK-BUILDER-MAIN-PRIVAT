package com.pultitool.remote.util

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

enum class BannerKind { INFO, SUCCESS, WARNING, ACHIEVEMENT }

data class Banner(val title: String, val text: String, val kind: BannerKind = BannerKind.INFO, val id: Long = System.nanoTime())

/** Глобальная шина событий для всплывающих баннеров поверх любого экрана. */
object Events {
    private val _banners = MutableSharedFlow<Banner>(extraBufferCapacity = 16)
    val banners: SharedFlow<Banner> = _banners

    fun banner(title: String, text: String, kind: BannerKind = BannerKind.INFO) {
        _banners.tryEmit(Banner(title, text, kind))
    }
}
