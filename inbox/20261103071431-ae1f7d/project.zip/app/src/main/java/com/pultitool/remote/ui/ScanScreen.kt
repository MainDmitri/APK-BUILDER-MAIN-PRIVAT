package com.pultitool.remote.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.data.FoundDevice
import com.pultitool.remote.data.TvDevice
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ScanScreen(vm: AppViewModel) {
    val scan by vm.scan.collectAsState()
    val devices by vm.devices.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Header("Поиск", if (scan.running) "Сканирование сети…" else "Готово",
                leading = {
                    IconButton(onClick = { vm.stopScan(); vm.navigate(Screen.DEVICES) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = Pal.text)
                    }
                })
        }
        item {
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                Radar(scan.running, scan.found, Modifier.size(260.dp))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val prog by animateFloatAsState(scan.progress, tween(400), label = "p")
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Pal.glassStrong)) {
                    Box(Modifier.fillMaxWidth(prog.coerceIn(0f, 1f)).height(8.dp).clip(RoundedCornerShape(4.dp)).background(LocalAccent.current.brush))
                }
                Spacer(Modifier.height(10.dp))
                Text(scan.stage, color = Pal.textDim, fontSize = 13.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                if (scan.running) GhostButton("Остановить", onClick = { vm.stopScan() })
                else GradientButton("Сканировать снова", glyph = Glyph.RADAR, onClick = { vm.startScan() })
            }
        }
        if (scan.found.isNotEmpty()) item { SectionTitle("Найдено (${scan.found.size})", Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
        items(scan.found, key = { it.ip + it.protocol.name }) { f ->
            val saved = devices.any { it.ip == f.ip && it.protocol == f.protocol }
            AnimatedVisibility(visible = true, enter = fadeIn() + slideInVertically { it / 2 }) {
                FoundRow(f, saved, onAdd = { vm.addFound(f) }, onOpen = { vm.addFound(f, open = true) })
            }
        }
    }
}

@Composable
private fun FoundRow(f: FoundDevice, saved: Boolean, onAdd: () -> Unit, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).glass(RoundedCornerShape(22.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DeviceAvatar(TvDevice(name = f.name, protocol = f.protocol), 46)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1)
            Text(listOf(f.brand, f.model).filter { it.isNotBlank() }.joinToString(" "), color = Pal.textDim, fontSize = 12.sp, maxLines = 1)
            Text("${f.ip} · ${f.protocol.title}" + (if (f.source.isNotBlank()) " · ${f.source}" else ""), color = Pal.textDim, fontSize = 11.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            TextKey("Открыть", size = 0.dp, onClick = onOpen, fontSize = 13, background = LocalAccent.current.brush,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.width(92.dp).height(34.dp))
            if (!saved) TextKey("Сохранить", size = 0.dp, onClick = onAdd, fontSize = 12, shape = RoundedCornerShape(14.dp),
                modifier = Modifier.width(92.dp).height(30.dp))
            else Text("сохранено", color = Pal.green, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Radar(running: Boolean, found: List<FoundDevice>, modifier: Modifier) {
    val accent = LocalAccent.current
    val t = rememberInfiniteTransition(label = "radar")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "a")
    val pulse by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val dots = remember(found) {
        found.map { f ->
            val h = f.ip.hashCode()
            val a = Math.toRadians(((h and 0x7fffffff) % 360).toDouble())
            val r = 0.35f + ((h ushr 9) and 0xff) / 255f * 0.55f
            Triple(a, r, f)
        }
    }
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val rad = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(accent.a.copy(alpha = 0.18f), Color.Transparent), c, rad), rad, c)
        for (i in 1..4) drawCircle(Color(0x22FFFFFF), rad * i / 4f, c, style = Stroke(1.5f))
        drawLine(Color(0x18FFFFFF), Offset(c.x - rad, c.y), Offset(c.x + rad, c.y), 1.5f)
        drawLine(Color(0x18FFFFFF), Offset(c.x, c.y - rad), Offset(c.x, c.y + rad), 1.5f)
        if (running) {
            drawCircle(accent.b.copy(alpha = (1f - pulse) * 0.6f), rad * pulse, c, style = Stroke(3f))
            rotate(angle, c) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, accent.b.copy(alpha = 0.05f), accent.b.copy(alpha = 0.55f)), c),
                    startAngle = -90f, sweepAngle = 90f, useCenter = true,
                    topLeft = Offset(c.x - rad, c.y - rad), size = androidx.compose.ui.geometry.Size(rad * 2, rad * 2)
                )
                drawLine(accent.b, c, Offset(c.x, c.y - rad), 4f)
            }
        }
        dots.forEach { (a, r, _) ->
            val p = Offset(c.x + (cos(a) * rad * r).toFloat(), c.y + (sin(a) * rad * r).toFloat())
            drawCircle(accent.b.copy(alpha = 0.35f), 16f, p)
            drawCircle(Color.White, 7f, p)
        }
        drawCircle(accent.brush, 14f, c)
    }
}
