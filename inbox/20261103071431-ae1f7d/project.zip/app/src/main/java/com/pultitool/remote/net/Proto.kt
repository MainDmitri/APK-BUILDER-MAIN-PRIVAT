package com.pultitool.remote.net

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

/** Минимальный кодировщик protobuf (wire format) для протоколов Android TV Remote v2. */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    private fun varint(v: Long) {
        var x = v
        while (true) {
            if ((x and 0x7FL.inv()) == 0L) { out.write(x.toInt()); return }
            out.write(((x and 0x7F) or 0x80).toInt())
            x = x ushr 7
        }
    }

    private fun tag(field: Int, wire: Int) = varint(((field shl 3) or wire).toLong())

    fun int(field: Int, v: Long): ProtoWriter { tag(field, 0); varint(v); return this }
    fun int(field: Int, v: Int): ProtoWriter = int(field, v.toLong())
    fun bool(field: Int, v: Boolean): ProtoWriter = int(field, if (v) 1L else 0L)
    fun bytes(field: Int, b: ByteArray): ProtoWriter { tag(field, 2); varint(b.size.toLong()); out.write(b); return this }
    fun string(field: Int, s: String): ProtoWriter = bytes(field, s.toByteArray(Charsets.UTF_8))
    fun msg(field: Int, block: ProtoWriter.() -> Unit): ProtoWriter = bytes(field, ProtoWriter().apply(block).toByteArray())
    fun toByteArray(): ByteArray = out.toByteArray()
}

/** Разобранное protobuf-сообщение: поле -> список значений (Long для varint, ByteArray для length-delimited). */
class ProtoMsg(val fields: Map<Int, List<Any>>) {
    fun has(f: Int) = fields.containsKey(f)
    fun int(f: Int, def: Long = 0): Long = (fields[f]?.firstOrNull() as? Long) ?: def
    fun bytes(f: Int): ByteArray? = fields[f]?.firstOrNull() as? ByteArray
    fun msg(f: Int): ProtoMsg? = bytes(f)?.let { parse(it) }
    fun string(f: Int): String = bytes(f)?.toString(Charsets.UTF_8) ?: ""

    companion object {
        fun parse(data: ByteArray): ProtoMsg {
            val map = LinkedHashMap<Int, MutableList<Any>>()
            var i = 0
            fun readVarint(): Long {
                var shift = 0
                var result = 0L
                while (i < data.size) {
                    val b = data[i++].toInt() and 0xFF
                    result = result or ((b and 0x7F).toLong() shl shift)
                    if (b and 0x80 == 0) return result
                    shift += 7
                    if (shift > 63) break
                }
                return result
            }
            try {
                while (i < data.size) {
                    val key = readVarint()
                    val field = (key ushr 3).toInt()
                    when ((key and 7).toInt()) {
                        0 -> map.getOrPut(field) { mutableListOf() }.add(readVarint())
                        1 -> { i += 8 }
                        2 -> {
                            val len = readVarint().toInt()
                            if (len < 0 || i + len > data.size) break
                            map.getOrPut(field) { mutableListOf() }.add(data.copyOfRange(i, i + len))
                            i += len
                        }
                        5 -> { i += 4 }
                        else -> break
                    }
                }
            } catch (_: Exception) {
            }
            return ProtoMsg(map)
        }
    }
}

object ProtoIO {
    fun writeDelimited(out: OutputStream, payload: ByteArray) {
        val buf = ByteArrayOutputStream()
        var x = payload.size.toLong()
        while (true) {
            if ((x and 0x7FL.inv()) == 0L) { buf.write(x.toInt()); break }
            buf.write(((x and 0x7F) or 0x80).toInt())
            x = x ushr 7
        }
        buf.write(payload)
        synchronized(out) {
            out.write(buf.toByteArray())
            out.flush()
        }
    }

    /** Читает одно сообщение с префиксом-длиной varint. null — поток закрыт. */
    fun readDelimited(input: InputStream): ByteArray? {
        var shift = 0
        var len = 0L
        while (true) {
            val b = input.read()
            if (b < 0) return null
            len = len or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) break
            shift += 7
            if (shift > 35) return null
        }
        if (len > 1_000_000) return null
        val data = ByteArray(len.toInt())
        var off = 0
        while (off < data.size) {
            val r = input.read(data, off, data.size - off)
            if (r < 0) return null
            off += r
        }
        return data
    }
}
