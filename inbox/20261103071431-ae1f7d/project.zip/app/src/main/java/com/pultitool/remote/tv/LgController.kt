package com.pultitool.remote.tv

import android.content.Context
import com.pultitool.remote.data.AppShortcut
import com.pultitool.remote.data.RKey
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

/** LG webOS: SSAP поверх WebSocket ws://ip:3000 / wss://ip:3001, плюс сокет указателя для кнопок. */
class LgController(context: Context, d: TvDevice) : TvController(context, d) {
    private var ws: WebSocket? = null
    private var pointer: WebSocket? = null
    private val ids = AtomicInteger(1)
    @Volatile private var closedByUser = false
    @Volatile private var secure = false

    override val supportsTouchpad = true
    override val supportsToast = true

    private val permissions = listOf(
        "APP_TO_APP", "CLOSE", "CONTROL_AUDIO", "CONTROL_DISPLAY", "CONTROL_INPUT_JOYSTICK",
        "CONTROL_INPUT_MEDIA_PLAYBACK", "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_INPUT_TEXT",
        "CONTROL_INPUT_TV", "CONTROL_MOUSE_AND_KEYBOARD", "CONTROL_POWER", "CONTROL_TV_SCREEN",
        "LAUNCH", "LAUNCH_WEBAPP", "READ_APP_STATUS", "READ_COUNTRY_INFO", "READ_CURRENT_CHANNEL",
        "READ_INPUT_DEVICE_LIST", "READ_INSTALLED_APPS", "READ_LGE_SDX", "READ_LGE_TV_INPUT_EVENTS",
        "READ_NETWORK_STATE", "READ_NOTIFICATIONS", "READ_POWER_STATE", "READ_RUNNING_APPS",
        "READ_SETTINGS", "READ_TV_CHANNEL_LIST", "READ_TV_CURRENT_TIME", "READ_UPDATE_INFO", "SEARCH",
        "TEST_OPEN", "TEST_PROTECTED", "TEST_SECURE", "UPDATE_FROM_REMOTE_APP",
        "WRITE_NOTIFICATION_ALERT", "WRITE_NOTIFICATION_TOAST", "WRITE_SETTINGS"
    )

    override fun builtinApps() = listOf(
        AppShortcut("YouTube", "youtube.leanback.v4", AppColors.YOUTUBE),
        AppShortcut("Netflix", "netflix", AppColors.NETFLIX),
        AppShortcut("Prime Video", "amazon", AppColors.PRIME),
        AppShortcut("Кинопоиск", "com.kinopoisk.app", AppColors.KINOPOISK),
        AppShortcut("ivi", "ivi", AppColors.IVI),
        AppShortcut("Okko", "okko", AppColors.OKKO),
        AppShortcut("Spotify", "spotify-beehive", AppColors.SPOTIFY),
        AppShortcut("Браузер", "com.webos.app.browser", AppColors.BROWSER),
        AppShortcut("Live TV", "com.webos.app.livetv", AppColors.VK),
        AppShortcut("Плеер", "com.webos.app.mediadiscovery", AppColors.PLEX)
    )

    private fun pointerButton(k: RKey): String? = when (k) {
        RKey.UP -> "UP"; RKey.DOWN -> "DOWN"; RKey.LEFT -> "LEFT"; RKey.RIGHT -> "RIGHT"
        RKey.OK -> "ENTER"; RKey.BACK -> "BACK"; RKey.HOME -> "HOME"; RKey.MENU -> "MENU"
        RKey.EXIT -> "EXIT"; RKey.INFO -> "INFO"; RKey.SETTINGS -> "QMENU"; RKey.GUIDE -> "GUIDE"
        RKey.RED -> "RED"; RKey.GREEN -> "GREEN"; RKey.YELLOW -> "YELLOW"; RKey.BLUE -> "BLUE"
        RKey.D0 -> "0"; RKey.D1 -> "1"; RKey.D2 -> "2"; RKey.D3 -> "3"; RKey.D4 -> "4"
        RKey.D5 -> "5"; RKey.D6 -> "6"; RKey.D7 -> "7"; RKey.D8 -> "8"; RKey.D9 -> "9"
        RKey.VOL_UP -> "VOLUMEUP"; RKey.VOL_DOWN -> "VOLUMEDOWN"; RKey.MUTE -> "MUTE"
        RKey.CH_UP -> "CHANNELUP"; RKey.CH_DOWN -> "CHANNELDOWN"; RKey.INPUT -> null
        RKey.SEARCH -> "SEARCH"; RKey.DEL -> null; RKey.ENTER -> "ENTER"
        RKey.PLAY -> "PLAY"; RKey.PAUSE -> "PAUSE"; RKey.STOP -> "STOP"
        RKey.REWIND -> "REWIND"; RKey.FAST_FORWARD -> "FASTFORWARD"
        else -> null
    }

    override suspend fun connect() = withContext(Dispatchers.IO) {
        closedByUser = false
        ws?.cancel(); pointer?.cancel()
        val p3001 = NetUtil.isPortOpen(device.ip, 3001, 1200)
        val p3000 = !p3001 && NetUtil.isPortOpen(device.ip, 3000, 1200)
        if (!p3001 && !p3000) {
            _state.value = ConnState.Error("LG недоступен (порты 3000/3001 закрыты). Включите ТВ")
            return@withContext
        }
        secure = p3001
        _state.value = ConnState.Connecting("Подключение к LG…")
        val url = if (secure) "wss://${device.ip}:3001/" else "ws://${device.ip}:3000/"
        ws = NetUtil.ws.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val payload = JSONObject()
                    .put("forcePairing", false)
                    .put("pairingType", "PROMPT")
                    .put("manifest", JSONObject().put("appVersion", "1.1").put("manifestVersion", 1).put("permissions", JSONArray(permissions)))
                if (device.token.isNotEmpty()) payload.put("client-key", device.token)
                webSocket.send(JSONObject().put("type", "register").put("id", "register_0").put("payload", payload).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (closedByUser || ws !== webSocket) return
                _state.value = ConnState.Error("LG: ${t.message ?: "ошибка соединения"}")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!closedByUser && ws === webSocket) _state.value = ConnState.Error("Соединение закрыто ТВ")
            }
        })
    }

    private fun handle(text: String) {
        val o = try { JSONObject(text) } catch (_: Exception) { return }
        val type = o.optString("type")
        val id = o.optString("id")
        val payload = o.optJSONObject("payload")
        when {
            id == "register_0" && type == "response" && payload?.optString("pairingType") == "PROMPT" ->
                _state.value = ConnState.WaitTv("Подтвердите запрос на экране LG пультом ТВ")
            id == "register_0" && type == "registered" -> {
                val key = payload?.optString("client-key").orEmpty()
                if (key.isNotEmpty() && key != device.token) updateDevice(device.copy(token = key, paired = true))
                _state.value = ConnState.Connected(if (secure) "Защищённое соединение" else "Подключено")
                request("ssap://com.webos.service.networkinput/getPointerInputSocket", null, "pointer_0")
                request("ssap://audio/getVolume", null, "vol_sub", subscribe = true)
                request("ssap://com.webos.applicationManager/getForegroundAppInfo", null, "app_sub", subscribe = true)
            }
            id == "register_0" && type == "error" -> {
                if (device.token.isNotEmpty()) updateDevice(device.copy(token = "", paired = false))
                _state.value = ConnState.Error("LG отклонил регистрацию: ${o.optString("error")}")
            }
            id == "pointer_0" -> {
                val path = payload?.optString("socketPath").orEmpty()
                if (path.isNotEmpty()) openPointer(path)
            }
            id == "vol_sub" && payload != null -> {
                val vs = payload.optJSONObject("volumeStatus")
                val level = vs?.optInt("volume", -1) ?: payload.optInt("volume", -1)
                val muted = vs?.optBoolean("muteStatus") ?: payload.optBoolean("muted")
                val max = vs?.optInt("maxVolume", 100) ?: 100
                if (level >= 0) _volume.value = VolumeInfo(level, max, muted)
            }
            id == "app_sub" && payload != null -> {
                val app = payload.optString("appId")
                if (app.isNotEmpty()) _currentApp.value = app
            }
        }
    }

    private fun openPointer(path: String) {
        val url = if (secure) path.replace("ws://", "wss://").replace(":3000", ":3001") else path
        pointer = NetUtil.ws.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (pointer === webSocket) pointer = null
            }
        })
    }

    private fun request(uri: String, payload: JSONObject?, id: String = "req_${ids.getAndIncrement()}", subscribe: Boolean = false) {
        val msg = JSONObject().put("type", if (subscribe) "subscribe" else "request").put("id", id).put("uri", uri)
        if (payload != null) msg.put("payload", payload)
        val s = ws
        if (s == null || !s.send(msg.toString())) _state.value = ConnState.Error("Нет соединения с LG")
    }

    private fun pointerSend(text: String): Boolean = pointer?.send(text) == true

    override fun disconnect() {
        closedByUser = true
        pointer?.close(1000, null); ws?.close(1000, null)
        pointer = null; ws = null
        _state.value = ConnState.Idle
    }

    override suspend fun sendKey(key: RKey, longPress: Boolean) {
        when (key) {
            RKey.POWER -> request("ssap://system/turnOff", null)
            RKey.VOL_UP -> request("ssap://audio/volumeUp", null)
            RKey.VOL_DOWN -> request("ssap://audio/volumeDown", null)
            RKey.MUTE -> request("ssap://audio/setMute", JSONObject().put("mute", !(_volume.value?.muted ?: false)))
            RKey.CH_UP -> request("ssap://tv/channelUp", null)
            RKey.CH_DOWN -> request("ssap://tv/channelDown", null)
            RKey.PLAY, RKey.PLAY_PAUSE -> request("ssap://media.controls/play", null)
            RKey.PAUSE -> request("ssap://media.controls/pause", null)
            RKey.STOP -> request("ssap://media.controls/stop", null)
            RKey.REWIND, RKey.PREV -> request("ssap://media.controls/rewind", null)
            RKey.FAST_FORWARD, RKey.NEXT -> request("ssap://media.controls/fastForward", null)
            RKey.INPUT -> request("ssap://system.launcher/launch", JSONObject().put("id", "com.webos.app.inputpicker"))
            RKey.DEL -> request("ssap://com.webos.service.ime/deleteCharacters", JSONObject().put("count", 1))
            RKey.ENTER -> request("ssap://com.webos.service.ime/sendEnterKey", null)
            else -> {
                val b = pointerButton(key) ?: return
                if (!pointerSend("type:button\nname:$b\n\n")) {
                    // Повторно запрашиваем сокет указателя
                    request("ssap://com.webos.service.networkinput/getPointerInputSocket", null, "pointer_0")
                }
            }
        }
    }

    override suspend fun sendText(text: String) {
        request("ssap://com.webos.service.ime/insertText", JSONObject().put("text", text).put("replace", 0))
    }

    override suspend fun launchApp(app: AppShortcut) {
        request("ssap://system.launcher/launch", JSONObject().put("id", app.id))
    }

    override val supportsUrl = true
    override val supportsYouTube = true

    override suspend fun openUrl(url: String): Boolean {
        request("ssap://system.launcher/open", JSONObject().put("target", url)); return true
    }

    override suspend fun openYouTube(videoId: String): Boolean {
        request("ssap://system.launcher/launch", JSONObject().put("id", "youtube.leanback.v4").put("contentId", videoId)
            .put("params", JSONObject().put("contentTarget", "https://www.youtube.com/tv?v=$videoId")))
        return true
    }

    override suspend fun showToast(text: String) {
        request("ssap://system.notifications/createToast", JSONObject().put("message", text))
    }

    override suspend fun moveCursor(dx: Int, dy: Int) {
        pointerSend("type:move\ndx:$dx\ndy:$dy\ndown:0\n\n")
    }

    override suspend fun click() {
        if (!pointerSend("type:click\n\n")) sendKey(RKey.OK)
    }
}
