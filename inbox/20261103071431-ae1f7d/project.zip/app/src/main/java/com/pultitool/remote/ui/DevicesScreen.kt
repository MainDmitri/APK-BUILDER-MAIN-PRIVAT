package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.data.Protocol
import com.pultitool.remote.data.TvDevice
import com.pultitool.remote.net.NetUtil
import kotlinx.coroutines.launch

fun protocolColors(p: Protocol): List<Color> = when (p) {
    Protocol.ANDROID_TV -> listOf(Color(0xFF34A853), Color(0xFF4285F4))
    Protocol.SAMSUNG -> listOf(Color(0xFF1428A0), Color(0xFF4F7BFF))
    Protocol.LG -> listOf(Color(0xFFA50034), Color(0xFFFF4F7B))
    Protocol.ROKU -> listOf(Color(0xFF662D91), Color(0xFFA35DE0))
    Protocol.PHILIPS -> listOf(Color(0xFF0B5ED7), Color(0xFF00B4D8))
    Protocol.SONY -> listOf(Color(0xFF222222), Color(0xFF777777))
}

@Composable
fun DeviceAvatar(d: TvDevice, size: Int = 48) {
    Box(
        Modifier.size(size.dp).clip(RoundedCornerShape((size / 3).dp)).background(Brush.linearGradient(protocolColors(d.protocol))),
        contentAlignment = Alignment.Center
    ) {
        Text(d.protocol.short.take(2).uppercase(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (size / 3.2).sp)
    }
}

@Composable
fun DevicesScreen(vm: AppViewModel) {
    val devices by vm.devices.collectAsState()
    val online by vm.online.collectAsState()
    val controller by vm.controller.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TvDevice?>(null) }
    var deleting by remember { mutableStateOf<TvDevice?>(null) }
    val net = remember { vm.localNet() }

    val favorites = devices.filter { it.favorite }
    val sorted = devices.sortedByDescending { it.lastUsed }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            Header("Пульт Тул", net?.let { "Сеть: ${it.ip}/${it.prefix}" } ?: "Нет подключения к Wi-Fi",
                trailing = {
                    IconButton(onClick = { vm.refreshOnline() }) { Icon(Icons.Filled.Refresh, "Обновить", tint = Pal.text) }
                })
        }
        item { ScanHero(onScan = { vm.startScan() }, onAdd = { showAdd = true }) }
        if (favorites.isNotEmpty()) {
            item { SectionTitle("Избранное", Modifier.padding(horizontal = 16.dp)) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(favorites, key = { it.id }) { d ->
                        Column(
                            Modifier.width(110.dp).glass().clickable { vm.selectDevice(d) }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            DeviceAvatar(d, 54)
                            Spacer(Modifier.height(8.dp))
                            Text(d.name, color = Pal.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusDot(if (online[d.id] == true) Pal.green else Pal.textDim, 7.dp)
                                Spacer(Modifier.width(4.dp))
                                Text(d.protocol.short, color = Pal.textDim, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        item { SectionTitle(if (devices.isEmpty()) "Устройства" else "Недавние устройства", Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) }
        if (devices.isEmpty()) {
            item {
                EmptyState(Glyph.TV, "Пока нет телевизоров",
                    "Нажмите «Найти телевизоры» — приложение просканирует Wi-Fi сеть и найдёт Google TV, Android TV, Samsung, LG, Roku, Philips и Sony.")
            }
        }
        items(sorted, key = { it.id }) { d ->
            DeviceRow(
                d = d,
                active = controller?.device?.id == d.id,
                online = online[d.id],
                onOpen = { vm.selectDevice(d) },
                onFavorite = { vm.toggleFavorite(d) },
                onEdit = { editing = d },
                onWake = { vm.wake(d) },
                onDelete = { deleting = d }
            )
        }
    }

    if (showAdd) AddDeviceDialog(vm) { showAdd = false }
    editing?.let { d -> DeviceEditDialog(d, onDismiss = { editing = null }) { vm.editDevice(it); editing = null } }
    deleting?.let { d ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Удалить «${d.name}»?") },
            text = { Text("Сохранённые ключи сопряжения для этого устройства будут удалены.") },
            confirmButton = { TextButton(onClick = { vm.deleteDevice(d); deleting = null }) { Text("Удалить", color = Pal.red) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun ScanHero(onScan: () -> Unit, onAdd: () -> Unit) {
    val accent = LocalAccent.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(accent.a.copy(alpha = 0.35f), accent.b.copy(alpha = 0.18f))))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(28.dp))
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(Color(0x33FFFFFF)), contentAlignment = Alignment.Center) {
                GlyphIcon(Glyph.RADAR, tint = Color.White, size = 30.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Поиск телевизоров", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text("SSDP · mDNS · сканирование портов", color = Color(0xCCFFFFFF), fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GradientButton("Найти телевизоры", Modifier.weight(1f), glyph = Glyph.WIFI, onClick = onScan)
            GhostButton("Вручную", onClick = onAdd)
        }
    }
}

@Composable
private fun DeviceRow(
    d: TvDevice, active: Boolean, online: Boolean?,
    onOpen: () -> Unit, onFavorite: () -> Unit, onEdit: () -> Unit, onWake: () -> Unit, onDelete: () -> Unit
) {
    val accent = LocalAccent.current
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
            .glass(RoundedCornerShape(22.dp), strong = active)
            .then(if (active) Modifier.border(1.5.dp, accent.brush, RoundedCornerShape(22.dp)) else Modifier)
            .clickable(onClick = onOpen)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        DeviceAvatar(d)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(d.name, color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                val dot = when {
                    online == true -> Pal.green
                    online == false -> Pal.red
                    else -> Pal.textDim
                }
                StatusDot(dot, 8.dp)
                Spacer(Modifier.width(6.dp))
                val where = "${d.protocol.title} · ${d.ip}"
                Text(where, color = Pal.textDim, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        IconButton(onClick = onFavorite) {
            Icon(Icons.Filled.Star, "Избранное", tint = if (d.favorite) Pal.yellow else Color(0x55FFFFFF))
        }
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "Меню", tint = Pal.text) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Изменить") }, leadingIcon = { Icon(Icons.Filled.Edit, null) }, onClick = { menu = false; onEdit() })
                DropdownMenuItem(text = { Text("Включить по сети (WoL)") },
                    leadingIcon = { GlyphIcon(Glyph.POWER, tint = Pal.text, size = 20.dp) }, onClick = { menu = false; onWake() })
                DropdownMenuItem(text = { Text("Удалить", color = Pal.red) }, leadingIcon = { Icon(Icons.Filled.Delete, null, tint = Pal.red) }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProtocolPicker(selected: Protocol, onSelect: (Protocol) -> Unit) {
    val accent = LocalAccent.current
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Protocol.entries.forEach { p ->
            val on = p == selected
            Text(p.title, modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(if (on) accent.brush else Brush.linearGradient(listOf(Pal.glassStrong, Pal.glassStrong)))
                .clickable { onSelect(p) }
                .padding(horizontal = 12.dp, vertical = 7.dp),
                color = Pal.text, fontSize = 12.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun AddDeviceDialog(vm: AppViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var ip by remember { mutableStateOf(vm.localNet()?.base24 ?: "192.168.1.") }
    var mac by remember { mutableStateOf("") }
    var protocol by remember { mutableStateOf(Protocol.ANDROID_TV) }
    var probing by remember { mutableStateOf(false) }
    var hint by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val ipOk = NetUtil.isValidIp(ip.trim())

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Добавить устройство") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название (необязательно)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Text("Тип подключения", color = Pal.textDim, fontSize = 12.sp)
                ProtocolPicker(protocol) { protocol = it }
                run {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(ip, { ip = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("IP-адрес") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.weight(1f), isError = !ipOk)
                        Spacer(Modifier.width(8.dp))
                        if (probing) CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                        else TextButton(enabled = ipOk, onClick = {
                            probing = true; hint = ""
                            scope.launch {
                                val f = vm.probeManual(ip)
                                probing = false
                                if (f != null) {
                                    protocol = f.protocol
                                    if (name.isBlank()) name = f.name
                                    if (mac.isBlank()) mac = f.mac
                                    hint = "Найдено: ${f.brand} (${f.protocol.title})"
                                } else hint = "Не удалось определить — выберите тип вручную"
                            }
                        }) { Text("Определить") }
                    }
                    OutlinedTextField(mac, { mac = it }, label = { Text("MAC для Wake-on-LAN (необязательно)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (hint.isNotEmpty()) Text(hint, color = Pal.textDim, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(enabled = ipOk, onClick = { vm.addManual(name, ip, protocol, mac); onDismiss() }) {
                Text("Добавить")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
fun DeviceEditDialog(d: TvDevice, onDismiss: () -> Unit, onSave: (TvDevice) -> Unit) {
    var name by remember { mutableStateOf(d.name) }
    var ip by remember { mutableStateOf(d.ip) }
    var mac by remember { mutableStateOf(d.mac) }
    var protocol by remember { mutableStateOf(d.protocol) }
    val ipOk = NetUtil.isValidIp(ip.trim())
    val macOk = mac.isBlank() || NetUtil.normalizeMac(mac) != null
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Устройство") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Название") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                ProtocolPicker(protocol) { protocol = it }
                run {
                    OutlinedTextField(ip, { ip = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("IP-адрес") }, singleLine = true,
                        isError = !ipOk, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(mac, { mac = it }, label = { Text("MAC-адрес (для включения)") }, singleLine = true,
                        isError = !macOk, modifier = Modifier.fillMaxWidth())
                }
                if (protocol != d.protocol || ip != d.ip) Text("После смены IP или протокола потребуется повторное сопряжение", color = Pal.textDim, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = ipOk && macOk && name.isNotBlank(), onClick = {
                onSave(d.copy(name = name.trim(), ip = ip.trim(), mac = NetUtil.normalizeMac(mac) ?: "", protocol = protocol))
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

