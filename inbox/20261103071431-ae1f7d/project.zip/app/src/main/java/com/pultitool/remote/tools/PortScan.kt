package com.pultitool.remote.tools

import com.pultitool.remote.audit.portName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

data class PortResult(val port: Int, val service: String, val banner: String, val rttMs: Double)

object PortScan {
    const val MAX_PORTS = 10000

    val presets = listOf(
        "Популярные" to "21,22,23,25,53,80,110,139,143,443,445,554,631,1883,3389,5000,5353,5900,8000,8008,8009,8080,8443,8554,9000,37777",
        "Веб" to "80,81,443,591,3000,5000,5001,7000,8000,8001,8008,8080,8081,8088,8443,8888,9000,9443",
        "Камеры" to "80,443,554,8000,8080,8554,8899,10554,34567,37777,37778",
        "ТВ" to "1925,1926,3000,3001,6466,6467,7000,8001,8002,8008,8009,8060,9080",
        "1–1024" to "1-1024"
    )

    /** Разбор диапазона вида "22,80,8000-8100". */
    fun parse(spec: String): List<Int> {
        val set = sortedSetOf<Int>()
        spec.split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            if ('-' in part) {
                val a = part.substringBefore('-').trim().toIntOrNull() ?: throw IllegalArgumentException("Неверный диапазон: $part")
                val b = part.substringAfter('-').trim().toIntOrNull() ?: throw IllegalArgumentException("Неверный диапазон: $part")
                val lo = minOf(a, b).coerceIn(1, 65535)
                val hi = maxOf(a, b).coerceIn(1, 65535)
                for (p in lo..hi) { set.add(p); if (set.size > MAX_PORTS) throw IllegalArgumentException("Слишком много портов (максимум $MAX_PORTS)") }
            } else {
                val p = part.toIntOrNull() ?: throw IllegalArgumentException("Неверный порт: $part")
                if (p !in 1..65535) throw IllegalArgumentException("Порт вне диапазона: $p")
                set.add(p)
            }
        }
        if (set.isEmpty()) throw IllegalArgumentException("Укажите хотя бы один порт")
        return set.toList()
    }

    /** Проверка TCP-портов одного хоста. Только подключение и чтение приветствия сервиса — без отправки данных. */
    suspend fun scan(
        host: String,
        ports: List<Int>,
        timeoutMs: Int,
        grabBanner: Boolean,
        onProgress: (Int) -> Unit,
        onOpen: (PortResult) -> Unit
    ) = coroutineScope {
        val sem = Semaphore(100)
        var done = 0
        val lock = Any()
        ports.map { port ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    ensureActive()
                    val start = System.nanoTime()
                    try {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(host, port), timeoutMs)
                            val rtt = (System.nanoTime() - start) / 1_000_000.0
                            var banner = ""
                            if (grabBanner) {
                                try {
                                    s.soTimeout = 900
                                    val buf = ByteArray(160)
                                    val n = s.getInputStream().read(buf)
                                    if (n > 0) banner = String(buf, 0, n, Charsets.ISO_8859_1)
                                        .map { c -> if (c.code in 32..126) c else ' ' }.joinToString("").trim().replace(Regex("\\s+"), " ")
                                } catch (_: Exception) {
                                }
                            }
                            onOpen(PortResult(port, portName(port), banner, rtt))
                        }
                    } catch (_: Exception) {
                    }
                    val d = synchronized(lock) { ++done }
                    if (d % 10 == 0 || d == ports.size) onProgress(d)
                }
            }
        }.awaitAll()
    }

    suspend fun resolve(host: String): String? = withContext(Dispatchers.IO) {
        try { java.net.InetAddress.getByName(host.trim()).hostAddress } catch (_: Exception) { null }
    }
}
