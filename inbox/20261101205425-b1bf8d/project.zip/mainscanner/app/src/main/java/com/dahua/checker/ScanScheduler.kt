package com.dahua.checker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Планировщик сканирований.
 * Хранит расписания в SharedPreferences, ставит AlarmManager.
 */
data class ScanSchedule(
    val id: Int,
    val subnet: String,           // "192.168.1.0/24" или "10.0.0.1-255"
    val port: Int = DahuaScanner.DEFAULT_PORT,
    val multiPort: Boolean = true,
    val hour: Int,                 // 0-23
    val minute: Int,               // 0-59
    val daysOfWeek: Set<Int>,      // Calendar.MONDAY..SUNDAY, пустой = ежедневно
    val enabled: Boolean = true,
    val pluginId: String? = null,
    val lastRunMs: Long = 0L,
    val lastResultCount: Int = 0
)

object ScanScheduleStorage {
    private const val PREFS = "scan_schedules"
    private const val KEY = "schedules"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(ctx: Context, schedules: List<ScanSchedule>) {
        val arr = JSONArray()
        for (s in schedules) {
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("subnet", s.subnet)
                put("port", s.port)
                put("multiPort", s.multiPort)
                put("hour", s.hour)
                put("minute", s.minute)
                put("days", JSONArray(s.daysOfWeek.toList()))
                put("enabled", s.enabled)
                if (s.pluginId != null) put("pluginId", s.pluginId)
                put("lastRunMs", s.lastRunMs)
                put("lastResultCount", s.lastResultCount)
            })
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun load(ctx: Context): List<ScanSchedule> {
        val json = prefs(ctx).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val days = mutableSetOf<Int>()
                if (o.has("days")) {
                    val d = o.getJSONArray("days")
                    for (j in 0 until d.length()) days.add(d.getInt(j))
                }
                ScanSchedule(
                    id = o.getInt("id"),
                    subnet = o.getString("subnet"),
                    port = o.optInt("port", DahuaScanner.DEFAULT_PORT),
                    multiPort = o.optBoolean("multiPort", true),
                    hour = o.getInt("hour"),
                    minute = o.getInt("minute"),
                    daysOfWeek = days,
                    enabled = o.optBoolean("enabled", true),
                    pluginId = o.optString("pluginId", ""),
                    lastRunMs = o.optLong("lastRunMs", 0L),
                    lastResultCount = o.optInt("lastResultCount", 0)
                )
            }
        } catch (_: Exception) { emptyList() }
    }

    fun nextId(ctx: Context): Int {
        val existing = load(ctx)
        return (existing.maxOfOrNull { it.id } ?: 0) + 1
    }
}

object ScanScheduler {
    private const val TAG = "ScanScheduler"

    fun scheduleAlarm(ctx: Context, schedule: ScanSchedule) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, ScanAlarmReceiver::class.java).apply {
            action = "com.dahua.checker.SCHEDULED_SCAN"
            putExtra("schedule_id", schedule.id)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, schedule.id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, schedule.hour)
            set(Calendar.MINUTE, schedule.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // Если дни недели указаны — ищем ближайший подходящий день,
        // начиная с сегодня (если время ещё не прошло) или с завтра.
        if (schedule.daysOfWeek.isNotEmpty()) {
            // Сначала проверяем сегодня: если день подходит И время ещё впереди — берём сегодня.
            // Иначе ищем со следующего дня.
            val todayOk = cal.get(Calendar.DAY_OF_WEEK) in schedule.daysOfWeek
                && cal.timeInMillis > System.currentTimeMillis()
            if (!todayOk) {
                // Авансируем на 1 день и продолжаем поиск
                cal.add(Calendar.DAY_OF_YEAR, 1)
                var found = false
                for (i in 0 until 7) {
                    if (cal.get(Calendar.DAY_OF_WEEK) in schedule.daysOfWeek) { found = true; break }
                    cal.add(Calendar.DAY_OF_YEAR, 1)
                }
                if (!found) return
            }
        } else {
            // Ежедневно: если время уже прошло — сдвигаем на завтра
            if (cal.timeInMillis <= System.currentTimeMillis()) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
                }
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            }
            Log.d(TAG, "Alarm set for schedule ${schedule.id} at ${cal.time}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set alarm: ${e.message}")
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }

    fun cancelAlarm(ctx: Context, scheduleId: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(ctx, ScanAlarmReceiver::class.java).apply {
            action = "com.dahua.checker.SCHEDULED_SCAN"
            putExtra("schedule_id", scheduleId)
        }
        val pi = PendingIntent.getBroadcast(
            ctx, scheduleId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun rescheduleAll(ctx: Context) {
        val schedules = ScanScheduleStorage.load(ctx)
        for (s in schedules) {
            if (s.enabled) scheduleAlarm(ctx, s)
            else cancelAlarm(ctx, s.id)
        }
    }
}

/**
 * BroadcastReceiver: запускает сканирование по алярму.
 */
class ScanAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val scheduleId = intent?.getIntExtra("schedule_id", -1) ?: return
        if (scheduleId == -1) return

        val schedules = ScanScheduleStorage.load(context)
        val schedule = schedules.find { it.id == scheduleId } ?: return
        if (!schedule.enabled) return

        // Проверяем день недели
        if (schedule.daysOfWeek.isNotEmpty()) {
            val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
            if (today !in schedule.daysOfWeek) {
                // Перепланируем на следующий подходящий день
                ScanScheduler.scheduleAlarm(context, schedule)
                return
            }
        }

        // Парсим IP
        val ips = IpParser.parse(schedule.subnet)
        if (ips.isEmpty()) return

        // Запускаем ScanService
        ScanService.pendingIps = ips
        val sIntent = Intent(context, ScanService::class.java).apply {
            action = ScanService.ACTION_START
            putExtra(ScanService.EXTRA_PORT, schedule.port)
            putExtra(ScanService.EXTRA_MULTI_PORT, schedule.multiPort)
            if (schedule.pluginId != null) putExtra(ScanService.EXTRA_PLUGIN_ID, schedule.pluginId)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(sIntent)
            } else {
                context.startService(sIntent)
            }
        } catch (e: Exception) {
            Log.e("ScanAlarmReceiver", "Failed to start scan service: ${e.message}")
        }

        // Обновляем lastRunMs
        val updated = schedules.map {
            if (it.id == scheduleId) it.copy(lastRunMs = System.currentTimeMillis()) else it
        }
        ScanScheduleStorage.save(context, updated)

        // Перепланируем на следующий раз
        ScanScheduler.scheduleAlarm(context, schedule)
    }
}

/**
 * Восстанавливает аларма после перезагрузки устройства
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            ScanScheduler.rescheduleAll(context)
        }
    }
}
