package com.dahua.checker

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import javax.net.ssl.HostnameVerifier

data class ScanPlugin(
    val id: String,
    val name: String,
    val version: String,
    val author: String,
    val description: String,
    val icon: String,
    val ports: List<Int>,
    val credentials: List<Pair<String, String>>,
    val defaultCredentials: List<Pair<String, String>>,
    val checks: List<PluginCheck>,
    val extractors: Map<String, String>,
    val matchBannerRegex: String,
    val allowInsecureTls: Boolean,
    val delayBetweenRequestsMs: Long,
    val followRedirects: Boolean,
    val enabled: Boolean = true
)

data class PluginCheck(
    val type: String,              // "http_basic", "tcp_banner", "tcp_send", "http_chain"
    val path: String,
    val method: String,
    val successCodes: List<Int>,
    val brandDetect: String,
    val modelRegex: String,
    val snapshotPaths: List<String>,
    val sendHex: String,
    val readBytes: Int,
    val successPattern: String,
    val headers: Map<String, String>,
    val postBody: String,
    val steps: List<ChainStep>,     // для http_chain
    val responsePattern: String,    // regex для проверки body ответа
    val port: Int = 0              // порт для фильтрации (0 = любой)
)

data class ChainStep(
    val method: String,
    val path: String,
    val headers: Map<String, String>,
    val postBody: String,
    val extractRegex: String,       // regex для извлечения переменной
    val extractVar: String,         // имя переменной {{VAR}}
    val successCodes: List<Int>,
    val snapshotPaths: List<String>,
    val responsePattern: String = "" // regex для проверки body ответа на этом шаге
)

object PluginManager {

    private const val PREFS_NAME = "ms_plugins"
    private const val PLUGINS_DIR = "plugins"

    private var loadedPlugins: MutableList<ScanPlugin> = mutableListOf()
    @Volatile
    private var initialized = false

    // SSL context для самоподписанных сертификатов
    private val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    })
    private val insecureSslContext: SSLContext by lazy {
        SSLContext.getInstance("TLS").apply {
            init(null, trustAllCerts, SecureRandom())
        }
    }
    private val trustAllHostnames = HostnameVerifier { _, _ -> true }

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        val dir = File(context.filesDir, PLUGINS_DIR)
        if (!dir.exists()) dir.mkdirs()
        loadedPlugins.clear()

        // ═══ Загрузка встроенных плагинов из assets ═══
        // Копирует bundled плагины из assets/plugins/ в filesDir/plugins/
        // если они ещё не установлены (или версия обновилась)
        try {
            val assetPlugins = context.assets.list("plugins") ?: emptyArray()
            for (assetFile in assetPlugins) {
                if (!assetFile.endsWith(".json")) continue
                val targetFile = File(dir, assetFile)
                // Проверяем нужно ли обновить: если файла нет, или bundled версия новее
                val needCopy = if (!targetFile.exists()) {
                    true
                } else {
                    // Сравниваем версии: если bundled версия отличается — обновляем
                    try {
                        val bundledJson = context.assets.open("plugins/$assetFile").bufferedReader().readText()
                        val existingJson = targetFile.readText()
                        val bundledVersion = JSONObject(bundledJson).optString("version", "0")
                        val existingVersion = JSONObject(existingJson).optString("version", "0")
                        bundledVersion != existingVersion
                    } catch (_: Exception) { false }
                }
                if (needCopy) {
                    try {
                        val bundledContent = context.assets.open("plugins/$assetFile").bufferedReader().readText()
                        targetFile.writeText(bundledContent)
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}

        // ═══ Загрузка всех плагинов из filesDir ═══
        val files = dir.listFiles { f -> f.extension == "json" } ?: emptyArray()
        for (file in files) {
            try {
                val json = file.readText()
                val plugin = parsePlugin(json)
                if (plugin != null) {
                    val enabled = isPluginEnabled(context, plugin.id)
                    loadedPlugins.add(plugin.copy(enabled = enabled))
                }
            } catch (_: Exception) {}
        }
        initialized = true
    }

    @Synchronized
    fun getPlugins(): List<ScanPlugin> = loadedPlugins.toList()

    @Synchronized
    fun getEnabledPlugins(): List<ScanPlugin> = loadedPlugins.filter { it.enabled }

    @Synchronized
    fun installPlugin(context: Context, jsonContent: String): Result<ScanPlugin> {
        return try {
            val plugin = parsePlugin(jsonContent)
                ?: return Result.failure(Exception("Неверный формат плагина"))
            loadedPlugins.removeAll { it.id == plugin.id }
            val dir = File(context.filesDir, PLUGINS_DIR)
            if (!dir.exists()) dir.mkdirs()
            File(dir, "${plugin.id}.json").writeText(jsonContent)
            setPluginEnabled(context, plugin.id, true)
            loadedPlugins.add(plugin.copy(enabled = true))
            Result.success(plugin)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun installFromUrl(context: Context, url: String): Result<ScanPlugin> {
        return withContext(Dispatchers.IO) {
            // FIX: disconnect() в finally — на error path (responseCode != 200 или exception)
            // соединение не закрывалось; нужен finally чтобы TCP-сокет всегда освобождался
            val conn = URL(url).openConnection() as HttpURLConnection
            try {
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                conn.requestMethod = "GET"
                conn.instanceFollowRedirects = true
                conn.connect()
                if (conn.responseCode != 200) {
                    return@withContext Result.failure(Exception("HTTP ${conn.responseCode}"))
                }
                val json = conn.inputStream.bufferedReader().readText()
                installPlugin(context, json)
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                conn.disconnect()
            }
        }
    }

    @Synchronized
    fun removePlugin(context: Context, pluginId: String) {
        loadedPlugins.removeAll { it.id == pluginId }
        val file = File(File(context.filesDir, PLUGINS_DIR), "$pluginId.json")
        if (file.exists()) file.delete()
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove("enabled_$pluginId").apply()
    }

    @Synchronized
    fun setPluginEnabled(context: Context, pluginId: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean("enabled_$pluginId", enabled).apply()
        val idx = loadedPlugins.indexOfFirst { it.id == pluginId }
        if (idx >= 0) {
            loadedPlugins[idx] = loadedPlugins[idx].copy(enabled = enabled)
        }
    }

    private fun isPluginEnabled(context: Context, pluginId: String): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean("enabled_$pluginId", true)
    }

    // ═══════════════════════════════════════════
    //  СКАНИРОВАНИЕ
    // ═══════════════════════════════════════════

    fun scanWithPlugin(plugin: ScanPlugin, ip: String, selectedPorts: List<Int>? = null): ScanResult? {
        val portsToScan = if (!selectedPorts.isNullOrEmpty()) {
            plugin.ports.filter { it in selectedPorts }
        } else {
            plugin.ports
        }

        // Pre-flight: проверяем какие порты открыты
        val openPorts = mutableListOf<Int>()
        for (port in portsToScan) {
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, port), 1200) // 1200ms — не пропускаем медленные порты
                }
                openPorts.add(port)
            } catch (_: Exception) {
                continue
            }
        }

        if (openPorts.isEmpty()) return null

        for ((portIdx, port) in openPorts.withIndex()) {
            // Задержка между портами — не долбим камеру слишком быстро
            if (portIdx > 0 && plugin.delayBetweenRequestsMs > 0) {
                try { Thread.sleep(plugin.delayBetweenRequestsMs) } catch (_: InterruptedException) { return null }
            }

            // Banner fingerprint — фильтруем плагин если баннер не совпадает
            if (plugin.matchBannerRegex.isNotEmpty()) {
                val banner = readBanner(ip, port)
                if (banner != null) {
                    val matches = try {
                        Regex(plugin.matchBannerRegex).containsMatchIn(banner)
                    } catch (_: Exception) { true }
                    if (!matches) continue
                }
            }

            // Фильтруем чеки по порту — не гоняем tcp_send:554 на порте 80
            val checksForPort = plugin.checks.filter { check ->
                check.port <= 0 || check.port == port
            }

            for (check in checksForPort) {
                val result = when (check.type) {
                    "http_basic" -> tryHttpBasicCheck(plugin, check, ip, port)
                    "http_chain" -> tryHttpChainCheck(plugin, check, ip, port)
                    "tcp_banner" -> tryTcpBannerCheck(plugin, check, ip, port)
                    "tcp_send" -> tryTcpSendCheck(plugin, check, ip, port)
                    else -> null
                }
                if (result != null) return result
            }

            // Fallback — defaultCredentials только для HTTP портов
            if (plugin.defaultCredentials.isNotEmpty() && port !in listOf(554, 5554, 8554, 37777, 34567)) {
                for (check in checksForPort) {
                    if (check.type == "http_basic") {
                        val result = tryHttpBasicCheckWithCreds(
                            plugin, check, ip, port, plugin.defaultCredentials
                        )
                        if (result != null) return result
                    }
                }
            }
        }
        return null
    }

    private fun readBanner(ip: String, port: Int): String? {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), 2500)
                socket.soTimeout = 3000
                val buf = ByteArray(512)
                val n = socket.getInputStream().read(buf)
                if (n > 0) String(buf, 0, n, Charsets.UTF_8).trim() else null
            }
        } catch (_: Exception) { null }
    }

    // ─── HTTP Basic с Rate Limiting, SSL, Extractors ───

    private fun tryHttpBasicCheck(plugin: ScanPlugin, check: PluginCheck, ip: String, port: Int): ScanResult? {
        return tryHttpBasicCheckWithCreds(plugin, check, ip, port, plugin.credentials)
    }

    private fun tryHttpBasicCheckWithCreds(
        plugin: ScanPlugin, check: PluginCheck, ip: String, port: Int,
        credentials: List<Pair<String, String>>
    ): ScanResult? {
        var backoffMs = plugin.delayBetweenRequestsMs.coerceAtLeast(0)

        for ((login, password) in credentials) {
            try {
                // Rate limiting delay
                if (backoffMs > 0) {
                    try { Thread.sleep(backoffMs) } catch (_: InterruptedException) { return null }
                }

                val scheme = if (port in listOf(443, 8443) && plugin.allowInsecureTls) "https" else "http"
                val urlStr = "$scheme://$ip:$port${check.path}"
                val conn = openConnection(urlStr, plugin)

                conn.connectTimeout = 2500
                conn.readTimeout = 5000
                conn.requestMethod = check.method.ifEmpty { "GET" }
                conn.instanceFollowRedirects = plugin.followRedirects

                // Basic auth
                val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
                conn.setRequestProperty("Authorization", "Basic $auth")

                // Доп. заголовки
                for ((key, value) in check.headers) {
                    conn.setRequestProperty(key, value)
                }

                // POST body
                if (check.method.equals("POST", true) && check.postBody.isNotEmpty()) {
                    conn.doOutput = true
                    conn.outputStream.write(check.postBody.toByteArray())
                    conn.outputStream.flush()
                }

                conn.connect()
                val code = conn.responseCode

                // 503/429 — экспоненциальный backoff
                if (code == 503 || code == 429) {
                    conn.disconnect()
                    backoffMs = (backoffMs * 2).coerceAtMost(5000)
                    continue
                }

                // Обработка редиректов вручную
                if (!plugin.followRedirects && (code == 301 || code == 302)) {
                    val location = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (location != null && location.isNotEmpty()) {
                        val redirectUrl = if (location.startsWith("http")) location
                        else "$scheme://$ip:$port$location"
                        val redirConn = openConnection(redirectUrl, plugin)
                        redirConn.connectTimeout = 2500
                        redirConn.readTimeout = 5000
                        redirConn.requestMethod = "GET"
                        redirConn.setRequestProperty("Authorization", "Basic $auth")
                        redirConn.instanceFollowRedirects = false
                        redirConn.connect()
                        val redirCode = redirConn.responseCode
                        if (redirCode in check.successCodes || (check.successCodes.isEmpty() && redirCode == 200)) {
                            val body = readBody(redirConn)
                            redirConn.disconnect()
                            return buildResult(plugin, check, ip, port, login, password, body)
                        }
                        redirConn.disconnect()
                    }
                    continue
                }

                if (code in check.successCodes || (check.successCodes.isEmpty() && code == 200)) {
                    val body = readBody(conn)
                    conn.disconnect()

                    // responsePattern — доп. проверка тела ответа
                    if (check.responsePattern.isNotEmpty()) {
                        val matches = try {
                            Regex(check.responsePattern).containsMatchIn(body)
                        } catch (_: Exception) { false }
                        if (!matches) continue
                    }

                    return buildResult(plugin, check, ip, port, login, password, body)
                }
                conn.disconnect()
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    private fun buildResult(
        plugin: ScanPlugin, check: PluginCheck,
        ip: String, port: Int, login: String, password: String, body: String
    ): ScanResult {
        // Извлечь модель
        val model = if (check.modelRegex.isNotEmpty()) {
            try {
                Regex(check.modelRegex).find(body)?.groupValues?.getOrNull(1)
                    ?: check.brandDetect.ifEmpty { plugin.name }
            } catch (_: Exception) { check.brandDetect.ifEmpty { plugin.name } }
        } else {
            check.brandDetect.ifEmpty { plugin.name }
        }

        // Extractors — firmware, serial, mac, users и т.д.
        val metadata = mutableMapOf<String, String>()
        for ((key, regex) in plugin.extractors) {
            try {
                val match = Regex(regex).find(body)
                if (match != null) {
                    metadata[key] = match.groupValues.getOrElse(1) { match.value }
                }
            } catch (_: Exception) {}
        }

        // Снапшот
        val scheme = if (port in listOf(443, 8443) && plugin.allowInsecureTls) "https" else "http"
        val snapshot = getSnapshotFromPaths(check.snapshotPaths, ip, port, login, password, scheme, plugin)

        return ScanResult(
            ip = ip, port = port, login = login, password = password,
            model = model, channels = 1, snapshot = snapshot,
            brand = check.brandDetect.ifEmpty { plugin.name },
            metadata = metadata
        )
    }

    // ─── HTTP Chain — цепочки запросов с переменными {{VAR}} ───

    private fun tryHttpChainCheck(plugin: ScanPlugin, check: PluginCheck, ip: String, port: Int): ScanResult? {
        if (check.steps.isEmpty()) return null

        for ((login, password) in plugin.credentials) {
            try {
                if (plugin.delayBetweenRequestsMs > 0) {
                    try { Thread.sleep(plugin.delayBetweenRequestsMs) } catch (_: InterruptedException) { return null }
                }

                val variables = mutableMapOf<String, String>()
                variables["LOGIN"] = login
                variables["PASSWORD"] = password

                val scheme = if (port in listOf(443, 8443) && plugin.allowInsecureTls) "https" else "http"
                var lastBody = ""
                var success = true

                for (step in check.steps) {
                    val path = substituteVars(step.path, variables)
                    val urlStr = "$scheme://$ip:$port$path"
                    val conn = openConnection(urlStr, plugin)

                    conn.connectTimeout = 2500
                    conn.readTimeout = 5000
                    conn.requestMethod = step.method.ifEmpty { "GET" }
                    conn.instanceFollowRedirects = plugin.followRedirects

                    val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
                    conn.setRequestProperty("Authorization", "Basic $auth")

                    for ((key, value) in step.headers) {
                        conn.setRequestProperty(key, substituteVars(value, variables))
                    }

                    if (step.method.equals("POST", true) && step.postBody.isNotEmpty()) {
                        conn.doOutput = true
                        conn.outputStream.write(substituteVars(step.postBody, variables).toByteArray())
                        conn.outputStream.flush()
                    }

                    conn.connect()
                    val code = conn.responseCode

                    if (step.successCodes.isNotEmpty() && code !in step.successCodes) {
                        conn.disconnect()
                        success = false
                        break
                    }
                    if (step.successCodes.isEmpty() && code != 200) {
                        conn.disconnect()
                        success = false
                        break
                    }

                    lastBody = readBody(conn)
                    conn.disconnect()

                    // responsePattern — проверка body на этом шаге
                    if (step.responsePattern.isNotEmpty()) {
                        val matches = try {
                            Regex(step.responsePattern).containsMatchIn(lastBody)
                        } catch (_: Exception) { false }
                        if (!matches) {
                            success = false
                            break
                        }
                    }

                    // Извлечь переменную из ответа
                    if (step.extractRegex.isNotEmpty() && step.extractVar.isNotEmpty()) {
                        try {
                            val match = Regex(step.extractRegex).find(lastBody)
                            if (match != null) {
                                variables[step.extractVar] = match.groupValues.getOrElse(1) { match.value }
                            }
                        } catch (_: Exception) {}
                    }
                }

                if (success) {
                    // Берём snapshotPaths из последнего step или из check
                    val snapPaths = check.steps.lastOrNull()?.snapshotPaths?.takeIf { it.isNotEmpty() }
                        ?: check.snapshotPaths
                    val snapshot = getSnapshotFromPaths(snapPaths, ip, port, login, password, scheme, plugin)

                    val model = if (check.modelRegex.isNotEmpty()) {
                        try {
                            Regex(check.modelRegex).find(lastBody)?.groupValues?.getOrNull(1)
                                ?: check.brandDetect.ifEmpty { plugin.name }
                        } catch (_: Exception) { check.brandDetect.ifEmpty { plugin.name } }
                    } else {
                        check.brandDetect.ifEmpty { plugin.name }
                    }

                    val metadata = mutableMapOf<String, String>()
                    for ((key, regex) in plugin.extractors) {
                        try {
                            val match = Regex(regex).find(lastBody)
                            if (match != null) {
                                metadata[key] = match.groupValues.getOrElse(1) { match.value }
                            }
                        } catch (_: Exception) {}
                    }

                    return ScanResult(
                        ip = ip, port = port, login = login, password = password,
                        model = model, channels = 1, snapshot = snapshot,
                        brand = check.brandDetect.ifEmpty { plugin.name },
                        metadata = metadata
                    )
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    // ─── TCP Banner ───

    private fun tryTcpBannerCheck(plugin: ScanPlugin, check: PluginCheck, ip: String, port: Int): ScanResult? {
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), 2500)
                socket.soTimeout = 5000

                val buf = ByteArray(check.readBytes.coerceIn(1, 4096))
                val n = socket.getInputStream().read(buf)

                if (n > 0) {
                    val banner = String(buf, 0, n, Charsets.UTF_8).trim()
                    if (check.successPattern.isNotEmpty()) {
                        val matches = try {
                            Regex(check.successPattern).containsMatchIn(banner)
                        } catch (_: Exception) { false }
                        if (matches) {
                            val metadata = mutableMapOf<String, String>()
                            for ((key, regex) in plugin.extractors) {
                                try {
                                    val match = Regex(regex).find(banner)
                                    if (match != null) {
                                        metadata[key] = match.groupValues.getOrElse(1) { match.value }
                                    }
                                } catch (_: Exception) {}
                            }
                            return ScanResult(
                                ip = ip, port = port, login = "—", password = "—",
                                model = banner.take(60), channels = 0, snapshot = null,
                                brand = check.brandDetect.ifEmpty { plugin.name },
                                metadata = metadata
                            )
                        }
                    }
                }
            }
        } catch (_: Exception) {}
        return null
    }

    // ─── TCP Send ───

    private fun tryTcpSendCheck(plugin: ScanPlugin, check: PluginCheck, ip: String, port: Int): ScanResult? {
        if (check.sendHex.isEmpty()) return null

        for ((login, password) in plugin.credentials) {
            try {
                if (plugin.delayBetweenRequestsMs > 0) {
                    try { Thread.sleep(plugin.delayBetweenRequestsMs) } catch (_: InterruptedException) { return null }
                }

                val socket = Socket()
                socket.connect(InetSocketAddress(ip, port), 2500)
                socket.soTimeout = 5000

                var hexData = check.sendHex
                    .replace("{LOGIN}", login.toByteArray().joinToString("") { "%02x".format(it) })
                    .replace("{PASSWORD}", password.toByteArray().joinToString("") { "%02x".format(it) })
                    .replace(" ", "")

                val sendBytes = hexStringToBytes(hexData)
                socket.getOutputStream().write(sendBytes)
                socket.getOutputStream().flush()

                val buf = ByteArray(check.readBytes.coerceIn(1, 8192))
                val n = socket.getInputStream().read(buf)
                socket.close()

                if (n > 0) {
                    val response = String(buf, 0, n, Charsets.UTF_8)
                    if (check.successPattern.isNotEmpty()) {
                        val matches = try {
                            Regex(check.successPattern).containsMatchIn(response)
                        } catch (_: Exception) { false }
                        if (matches) {
                            val model = if (check.modelRegex.isNotEmpty()) {
                                try {
                                    Regex(check.modelRegex).find(response)?.groupValues?.getOrNull(1) ?: plugin.name
                                } catch (_: Exception) { plugin.name }
                            } else plugin.name

                            val metadata = mutableMapOf<String, String>()
                            for ((key, regex) in plugin.extractors) {
                                try {
                                    val match = Regex(regex).find(response)
                                    if (match != null) {
                                        metadata[key] = match.groupValues.getOrElse(1) { match.value }
                                    }
                                } catch (_: Exception) {}
                            }

                            // RTSP: построить stream URL с пробированием путей
                            val rtspModel = if (port == 554 || port == 5554 || port == 8554) {
                                val rtspUrl = probeRtspStreamPath(ip, port, login, password)
                                if (rtspUrl != null) {
                                    metadata["rtsp_url"] = rtspUrl
                                    rtspUrl
                                } else {
                                    val baseUrl = "rtsp://$ip:$port"
                                    metadata["rtsp_url"] = baseUrl
                                    if (model != plugin.name) "$model | $baseUrl" else baseUrl
                                }
                            } else null

                            return ScanResult(
                                ip = ip, port = port, login = login, password = password,
                                model = rtspModel ?: model, channels = 1, snapshot = null,
                                brand = check.brandDetect.ifEmpty { plugin.name },
                                metadata = metadata
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                continue
            }
        }
        return null
    }

    // ─── RTSP Stream Path Prober ───

    private val rtspPaths = listOf(
        "/Streaming/Channels/101",      // Hikvision
        "/Streaming/Channels/1",        // Hikvision alt
        "/cam/realmonitor?channel=1&subtype=0", // Dahua
        "/cam/realmonitor?channel=1&subtype=1", // Dahua sub
        "/live/ch00_0",                 // Uniview
        "/live/0/MAIN",                 // Uniview alt
        "/h264/ch1/main/av_stream",     // Axis
        "/axis-media/media.amp",        // Axis alt
        "/stream1",                     // Generic
        "/stream0",                     // Generic
        "/1",                           // Generic numeric
        "/",                            // Root
        "/live",                        // Generic
        "/ch0_0.h264",                  // XMeye
        "/user=admin_password=_channel=1_stream=0.sdp", // XMeye alt
        "/11",                          // Samsung
        "/MediaInput/h264/stream_1",    // Vivotek
        "/video1",                      // ACTi / generic
        "/videoMain",                   // AVTECH
        "/live.sdp",                    // Various
        "/media/video1",                // Bosch
        "/mpeg4/media.amp",             // Axis MPEG4
        "/Streaming/Channels/102",      // Hikvision sub
        "/cam/realmonitor?channel=1&subtype=2", // Dahua mobile
    )

    private fun probeRtspStreamPath(ip: String, port: Int, login: String, password: String): String? {
        val userInfo = if (login.isNotEmpty() && login != "—" && password.isNotEmpty() && password != "—") {
            "$login:$password@"
        } else ""

        // Быстрая проверка: сначала пробуем первые 6 самых популярных путей
        // Полный перебор только если ни один не сработал
        val priorityPaths = rtspPaths.take(6)
        val remainingPaths = rtspPaths.drop(6)

        for (pathList in listOf(priorityPaths, remainingPaths)) {
            for (path in pathList) {
                try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(ip, port), 1500)
                        socket.soTimeout = 3000

                        val uri = "rtsp://${userInfo}$ip:$port$path"
                        val req = "DESCRIBE $uri RTSP/1.0\r\nCSeq: 2\r\nUser-Agent: RTSP\r\nAccept: application/sdp\r\n\r\n"
                        socket.getOutputStream().write(req.toByteArray())
                        socket.getOutputStream().flush()

                        val buf = ByteArray(2048)
                        val n = socket.getInputStream().read(buf)

                        if (n > 0) {
                            val resp = String(buf, 0, n, Charsets.UTF_8)
                            // 200 OK с SDP = рабочий поток
                            if (Regex("RTSP/1\\.0\\s+200").containsMatchIn(resp) &&
                                (resp.contains("application/sdp", ignoreCase = true) ||
                                 resp.contains("v=0") || resp.contains("m=video"))) {
                                return "rtsp://${userInfo}$ip:$port$path"
                            }
                            // 401/403 = порт RTSP, но нет доступа — не пробуем дальше
                            if (Regex("RTSP/1\\.0\\s+(401|403)").containsMatchIn(resp)) {
                                return "rtsp://$ip:$port$path (auth required)"
                            }
                        }
                    }
                } catch (_: Exception) {
                    continue
                }
            }
            // Если priority paths уже пробовали и не нашли —
            // проверим, отвечает ли порт вообще RTSP перед полным перебором
            if (pathList === priorityPaths && remainingPaths.isNotEmpty()) {
                try {
                    Socket().use { socket ->
                        socket.connect(InetSocketAddress(ip, port), 1500)
                        socket.soTimeout = 2000
                        val buf = ByteArray(64)
                        val n = socket.getInputStream().read(buf)
                        if (n <= 0) return null  // Порт не отвечает — не RTSP
                    }
                } catch (_: Exception) {
                    return null  // Не можем подключиться — бесполезно продолжать
                }
            }
        }
        return null
    }

    // ═══════════════════════════════════════════
    //  УТИЛИТЫ
    // ═══════════════════════════════════════════

    private fun openConnection(urlStr: String, plugin: ScanPlugin): HttpURLConnection {
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        // Insecure TLS для самоподписанных сертификатов
        if (plugin.allowInsecureTls && conn is HttpsURLConnection) {
            conn.sslSocketFactory = insecureSslContext.socketFactory
            conn.hostnameVerifier = trustAllHostnames
        }
        return conn
    }

    private fun readBody(conn: HttpURLConnection): String {
        return try {
            conn.inputStream.bufferedReader().readText().take(16000)
        } catch (_: Exception) {
            try {
                conn.errorStream?.bufferedReader()?.readText()?.take(16000) ?: ""
            } catch (_: Exception) { "" }
        }
    }

    private fun substituteVars(template: String, vars: Map<String, String>): String {
        var result = template
        for ((key, value) in vars) {
            result = result.replace("{{$key}}", value)
        }
        return result
    }

    private fun getSnapshotFromPaths(
        paths: List<String>, ip: String, port: Int,
        login: String, password: String, scheme: String, plugin: ScanPlugin
    ): ByteArray? {
        if (paths.isEmpty()) return null
        val auth = Base64.encodeToString("$login:$password".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val urlStr = "$scheme://$ip:$port$path"
                val conn = openConnection(urlStr, plugin)
                conn.connectTimeout = 2500
                conn.readTimeout = 4000
                conn.requestMethod = "GET"
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.instanceFollowRedirects = true
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 100) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    private fun hexStringToBytes(hex: String): ByteArray {
        val clean = hex.replace(" ", "")
        return ByteArray(clean.length / 2) { i ->
            clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    // ═══════════════════════════════════════════
    //  ПАРСИНГ JSON
    // ═══════════════════════════════════════════

    private fun parsePlugin(jsonString: String): ScanPlugin? {
        return try {
            val json = JSONObject(jsonString)
            val id = json.getString("id")
            val name = json.getString("name")
            val version = json.optString("version", "1.0")
            val author = json.optString("author", "Unknown")
            val description = json.optString("description", "")
            val icon = json.optString("icon", "🔌")

            val portsArr = json.getJSONArray("ports")
            val ports = (0 until portsArr.length()).map { portsArr.getInt(it) }

            val credentials = parseCredentials(json.optJSONArray("credentials"))
            val defaultCredentials = parseCredentials(json.optJSONArray("defaultCredentials"))

            // Extractors
            val extractors = mutableMapOf<String, String>()
            val extObj = json.optJSONObject("extractors")
            if (extObj != null) {
                val keys = extObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    extractors[key] = extObj.getString(key)
                }
            }

            val matchBannerRegex = json.optString("matchBannerRegex", "")
            val allowInsecureTls = json.optBoolean("allowInsecureTls", false)
            val delayBetweenRequestsMs = json.optLong("delayBetweenRequestsMs", 0)
            val followRedirects = json.optBoolean("followRedirects", false)

            val checksArr = json.optJSONArray("checks") ?: JSONArray()
            val checks = mutableListOf<PluginCheck>()
            for (i in 0 until checksArr.length()) {
                val ch = checksArr.getJSONObject(i)
                checks.add(parseCheck(ch, name))
            }

            ScanPlugin(
                id, name, version, author, description, icon, ports,
                credentials, defaultCredentials, checks, extractors,
                matchBannerRegex, allowInsecureTls, delayBetweenRequestsMs,
                followRedirects
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseCredentials(arr: JSONArray?): List<Pair<String, String>> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { i ->
            val c = arr.getJSONObject(i)
            c.getString("login") to c.optString("password", "")
        }
    }

    private fun parseCheck(ch: JSONObject, pluginName: String): PluginCheck {
        val headersMap = mutableMapOf<String, String>()
        val headersObj = ch.optJSONObject("headers")
        if (headersObj != null) {
            val keys = headersObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                headersMap[key] = headersObj.getString(key)
            }
        }

        val successCodes = ch.optJSONArray("successCodes")?.let { arr ->
            (0 until arr.length()).map { arr.getInt(it) }
        } ?: emptyList()

        val snapshotPaths = ch.optJSONArray("snapshotPaths")?.let { arr ->
            (0 until arr.length()).map { arr.getString(it) }
        } ?: emptyList()

        // Steps для http_chain
        val steps = mutableListOf<ChainStep>()
        val stepsArr = ch.optJSONArray("steps")
        if (stepsArr != null) {
            for (j in 0 until stepsArr.length()) {
                val st = stepsArr.getJSONObject(j)
                val stepHeaders = mutableMapOf<String, String>()
                val stH = st.optJSONObject("headers")
                if (stH != null) {
                    val stKeys = stH.keys()
                    while (stKeys.hasNext()) {
                        val k = stKeys.next()
                        stepHeaders[k] = stH.getString(k)
                    }
                }
                val stepSuccessCodes = st.optJSONArray("successCodes")?.let { arr ->
                    (0 until arr.length()).map { arr.getInt(it) }
                } ?: emptyList()
                val stepSnap = st.optJSONArray("snapshotPaths")?.let { arr ->
                    (0 until arr.length()).map { arr.getString(it) }
                } ?: emptyList()

                steps.add(ChainStep(
                    method = st.optString("method", "GET"),
                    path = st.optString("path", "/"),
                    headers = stepHeaders,
                    postBody = st.optString("postBody", ""),
                    extractRegex = st.optString("extractRegex", ""),
                    extractVar = st.optString("extractVar", ""),
                    successCodes = stepSuccessCodes,
                    snapshotPaths = stepSnap,
                    responsePattern = st.optString("responsePattern", "")
                ))
            }
        }

        return PluginCheck(
            type = ch.optString("type", "http_basic"),
            path = ch.optString("path", "/"),
            method = ch.optString("method", "GET"),
            successCodes = successCodes,
            brandDetect = ch.optString("brandDetect", pluginName),
            modelRegex = ch.optString("modelRegex", ""),
            snapshotPaths = snapshotPaths,
            sendHex = ch.optString("sendHex", ""),
            readBytes = ch.optInt("readBytes", 256),
            successPattern = ch.optString("successPattern", ""),
            headers = headersMap,
            postBody = ch.optString("postBody", ""),
            steps = steps,
            responsePattern = ch.optString("responsePattern", ""),
            port = ch.optInt("port", 0)
        )
    }
}
