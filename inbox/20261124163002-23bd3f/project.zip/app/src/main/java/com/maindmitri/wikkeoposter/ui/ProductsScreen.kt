package com.maindmitri.wikkeoposter.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.ProductStatus
import com.maindmitri.wikkeoposter.network.AiClient
import com.maindmitri.wikkeoposter.network.ChannelPostPreview
import com.maindmitri.wikkeoposter.network.TelegramClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProductsScreen(
    products: List<Product>,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedFilter by remember { mutableStateOf<ProductStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var editingProductId by remember { mutableStateOf<String?>(null) }

    var checkingChannel by remember { mutableStateOf(false) }
    var pinningNav by remember { mutableStateOf(false) }
    var channelDialogPosts by remember { mutableStateOf<List<ChannelPostPreview>?>(null) }

    val editingProduct = products.firstOrNull { it.id == editingProductId }

    if (editingProduct != null) {
        ProductDetailEditor(
            product = editingProduct,
            settings = settings,
            dbHelper = dbHelper,
            onBack = { editingProductId = null },
            onProductsChanged = onProductsChanged,
            onNotify = onNotify
        )
        return
    }

    val publishedCount = remember(products) { products.count { it.status == ProductStatus.PUBLISHED } }
    val draftCount = remember(products) { products.count { it.status == ProductStatus.DRAFT } }

    val filtered = remember(products, selectedFilter, searchQuery) {
        val byStatus = if (selectedFilter == null) products else products.filter { it.status == selectedFilter }
        val q = searchQuery.trim()
        if (q.isBlank()) byStatus
        else byStatus.filter {
            it.title.contains(q, ignoreCase = true) ||
                it.url.contains(q, ignoreCase = true) ||
                it.seller.contains(q, ignoreCase = true) ||
                it.generatedPost.contains(q, ignoreCase = true)
        }
    }

    if (channelDialogPosts != null) {
        val posts = channelDialogPosts!!
        AlertDialog(
            onDismissRequest = { channelDialogPosts = null },
            title = { Text("Последние посты в канале (${posts.size})") },
            text = {
                if (posts.isEmpty()) {
                    Text("Посты не найдены или канал приватный.")
                } else {
                    LazyColumn(
                        modifier = Modifier.height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(posts, key = { it.messageId }) { post ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        openExternalUrl(context, post.postUrl)
                                    }
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = post.text.lines().firstOrNull().orEmpty().take(90),
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = "Пост #${post.messageId} • Нажми, чтобы открыть",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { channelDialogPosts = null }) {
                    Text("Закрыть")
                }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search + Check Channel row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Поиск или #хештег...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            FilledTonalButton(
                onClick = {
                    scope.launch {
                        checkingChannel = true
                        val (posts, msg) = TelegramClient.fetchRecentPublicChannelPosts(settings.telegramChannelId)
                        onNotify(msg)
                        if (posts.isNotEmpty()) {
                            // Sync local drafts that match live channel posts by title
                            val matchedCount = withContext(Dispatchers.IO) {
                                var synced = 0
                                val allLocal = dbHelper.getAll()
                                for (local in allLocal) {
                                    if (local.status != ProductStatus.PUBLISHED && local.title.length >= 4) {
                                        val match = posts.firstOrNull {
                                            it.text.contains(local.title, ignoreCase = true)
                                        }
                                        if (match != null) {
                                            dbHelper.upsert(
                                                local.copy(
                                                    status = ProductStatus.PUBLISHED,
                                                    telegramMessageId = match.messageId
                                                )
                                            )
                                            synced++
                                        }
                                    }
                                }
                                synced
                            }
                            if (matchedCount > 0) {
                                onProductsChanged()
                                onNotify("Синхронизировано с каналом: $matchedCount товаров")
                            }
                            channelDialogPosts = posts
                        }
                        checkingChannel = false
                    }
                },
                enabled = !checkingChannel
            ) {
                if (checkingChannel) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    Text("Канал")
                }
            }
        }

        // Filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == null,
                onClick = { selectedFilter = null },
                label = { Text("Все (${products.size})") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.PUBLISHED,
                onClick = { selectedFilter = ProductStatus.PUBLISHED },
                label = { Text("В канале ($publishedCount)") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.DRAFT,
                onClick = { selectedFilter = ProductStatus.DRAFT },
                label = { Text("Черновики ($draftCount)") }
            )
        }

        // Quick 1-tap pinned channel navigation menu button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            OutlinedButton(
                onClick = {
                    scope.launch {
                        pinningNav = true
                        val (_, msg) = TelegramClient.publishAndPinNavigation(settings)
                        onNotify(msg)
                        pinningNav = false
                    }
                },
                enabled = !pinningNav,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (pinningNav) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                } else {
                    Text("📌 Закрепить навигацию по хештегам в канале")
                }
            }
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "Ничего не найдено" else "Пока нет сохранённых товаров",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Открой вкладку Wikkeo, выбери товар или нажми «Автосбор в фоне» на странице каталога.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    ProductListCard(
                        product = item,
                        onClick = { editingProductId = item.id },
                        onOpenWikkeo = { openExternalUrl(context, item.url) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProductListCard(
    product: Product,
    onClick: () -> Unit,
    onOpenWikkeo: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LocalThumbImage(
                path = product.localImages.firstOrNull(),
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                val wholesaleStr = AiClient.formatRub(product.wholesalePrice)
                val finalStr = AiClient.formatRub(product.finalPrice ?: product.wholesalePrice)
                Text(
                    text = "Опт: $wholesaleStr → Пост: $finalStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusBadge(product.status)
                    Text(
                        text = "Фото: ${product.localImages.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Wikkeo ↗",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable(onClick = onOpenWikkeo)
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: ProductStatus) {
    val bg = when (status) {
        ProductStatus.PUBLISHED -> Color(0xFF2E7D32)
        ProductStatus.DRAFT -> Color(0xFF1565C0)
        ProductStatus.ERROR -> Color(0xFFC62828)
    }
    Surface(
        color = bg.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = if (status == ProductStatus.PUBLISHED) "✓ В канале" else status.labelRu,
            color = bg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun LocalThumbImage(path: String?, modifier: Modifier = Modifier) {
    var bitmap by remember(path) { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(path) {
        bitmap = withContext(Dispatchers.IO) {
            if (path.isNullOrBlank()) return@withContext null
            val f = File(path)
            if (!f.exists()) return@withContext null
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(f.absolutePath, opts)?.asImageBitmap()
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.ShoppingCart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductDetailEditor(
    product: Product,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onBack: () -> Unit,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var postText by remember(product.id, product.generatedPost) { mutableStateOf(product.generatedPost) }
    var priceText by remember(product.id, product.finalPrice) {
        mutableStateOf((product.finalPrice ?: product.wholesalePrice?.toInt())?.toString() ?: "")
    }
    var localImages by remember(product.id, product.localImages) { mutableStateOf(product.localImages) }
    var busy by remember { mutableStateOf(false) }

    BackHandler(enabled = !busy) { onBack() }

    fun currentEditedProduct(): Product = product.copy(
        finalPrice = priceText.toIntOrNull(),
        generatedPost = postText,
        localImages = localImages
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Text(
                    text = product.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                }
            },
            actions = {
                IconButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.delete(product.id) }
                            onProductsChanged()
                            onNotify("Товар удалён")
                            onBack()
                        }
                    },
                    enabled = !busy
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить")
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Owner-only Wikkeo source card (never sent to Telegram!)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Источник Wikkeo (только для владельца)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = product.url,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = { openExternalUrl(context, product.url) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("На Wikkeo")
                        }
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("Wikkeo URL", product.url))
                                onNotify("Ссылка на Wikkeo скопирована")
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Копировать")
                        }
                    }
                    if (localImages.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val savedCount = savePhotosToGallery(context, product.id, localImages)
                                    onNotify("Сохранено в Галерею (Pictures/WikkeoPoster): $savedCount фото")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Скачать все фото в Галерею (${localImages.size} шт.)")
                        }
                    }
                    val postUrl = TelegramClient.buildPostUrl(settings.telegramChannelId, product.telegramMessageId)
                    if (product.status == ProductStatus.PUBLISHED && postUrl != null) {
                        HorizontalDivider()
                        val dateStr = product.publishedAt?.let {
                            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(it))
                        }.orEmpty()
                        TextButton(
                            onClick = { openExternalUrl(context, postUrl) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✓ Опубликовано $dateStr — открыть пост в Telegram ↗")
                        }
                    }
                }
            }

            // Photos gallery
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Сохранённые фото (${localImages.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                StatusBadge(product.status)
            }

            if (localImages.isEmpty()) {
                Text(
                    text = "Фотографии не скачаны — пост уйдёт текстом.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(localImages, key = { it }) { imgPath ->
                        Box(modifier = Modifier.size(110.dp)) {
                            LocalThumbImage(
                                path = imgPath,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            IconButton(
                                onClick = {
                                    localImages = localImages.filterNot { it == imgPath }
                                    scope.launch(Dispatchers.IO) {
                                        runCatching { File(imgPath).delete() }
                                        dbHelper.upsert(currentEditedProduct())
                                        withContext(Dispatchers.Main) { onProductsChanged() }
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(26.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Убрать фото",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (product.lastError.isNotBlank()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = product.lastError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Price row
            OutlinedTextField(
                value = priceText,
                onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Цена в посте (₽)") },
                supportingText = {
                    Text("Опт на Wikkeo: ${AiClient.formatRub(product.wholesalePrice)}")
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Telegram Post HTML Editor
            OutlinedTextField(
                value = postText,
                onValueChange = { postText = it },
                label = { Text("Текст поста (Telegram HTML, без ссылки Wikkeo)") },
                supportingText = {
                    val color = if (postText.length > 1024) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                    Text("${postText.length} / 1024 символов", color = color)
                },
                minLines = 7,
                maxLines = 14,
                modifier = Modifier.fillMaxWidth()
            )

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            val res = AiClient.generateTelegramPost(edited, settings)
                            postText = res.postHtml
                            val updated = edited.copy(
                                generatedPost = res.postHtml,
                                lastError = if (res.success) "" else res.error
                            )
                            withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                            onProductsChanged()
                            onNotify(if (res.success) "Описание обновлено через ИИ" else res.error)
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("ИИ-текст")
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.upsert(currentEditedProduct()) }
                            onProductsChanged()
                            onNotify("Изменения сохранены")
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Сохранить")
                }
            }

            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        val edited = currentEditedProduct()
                        withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                        val tgRes = TelegramClient.publishProduct(edited, settings)
                        val updated = if (tgRes.success) {
                            edited.copy(
                                status = ProductStatus.PUBLISHED,
                                telegramMessageId = tgRes.messageId,
                                publishedAt = System.currentTimeMillis(),
                                lastError = ""
                            )
                        } else {
                            edited.copy(
                                status = ProductStatus.ERROR,
                                lastError = tgRes.error
                            )
                        }
                        withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                        onProductsChanged()
                        onNotify(
                            if (tgRes.success) "Опубликовано в Telegram-канал!"
                            else "Ошибка Telegram: ${tgRes.error}"
                        )
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Опубликовать в Telegram-канал")
                }
            }
        }
    }
}

private fun openExternalUrl(context: Context, url: String) {
    runCatching {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}

private suspend fun savePhotosToGallery(
    context: Context,
    productId: String,
    paths: List<String>
): Int = withContext(Dispatchers.IO) {
    var count = 0
    val resolver = context.contentResolver
    paths.forEachIndexed { idx, p ->
        val src = File(p)
        if (!src.exists()) return@forEachIndexed
        val fileName = "${productId}_${idx + 1}.jpg"
        runCatching {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(
                        MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/WikkeoPoster"
                    )
                }
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out ->
                    src.inputStream().use { it.copyTo(out) }
                }
                count++
            }
        }
    }
    count
}
