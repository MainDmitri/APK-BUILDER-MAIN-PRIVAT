import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../widgets/message_bubble.dart';
import 'media_gallery_screen.dart';

class ChatScreen extends StatefulWidget {
  final TgDialog dialog;
  const ChatScreen({super.key, required this.dialog});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  final _scrollCtrl = ScrollController();
  final _inputCtrl = TextEditingController();
  final _inputFocus = FocusNode();
  List<TgMessage> _messages = [];
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  bool _onlyMe = false;
  int? _replyToId;
  String? _replyToText;
  int? _editId;
  Timer? _pollTimer;
  int _lastMsgId = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
    _scrollCtrl.addListener(_onScroll);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pollTimer?.cancel();
    _scrollCtrl.dispose();
    _inputCtrl.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  ApiService get _api {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    return api;
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels <= 200 && !_loadingMore && _hasMore) {
      _loadMore();
    }
  }

  Future<void> _load() async {
    setState(() { _loading = true; });
    try {
      final data = await _api.getMessages(widget.dialog.id,
          limit: 60, onlyMe: _onlyMe);
      if (!mounted) return;
      final raw = (data['messages'] as List? ?? []);
      final msgs = raw.map((e) => TgMessage.fromJson(e as Map<String, dynamic>)).toList();
      msgs.sort((a, b) => a.id.compareTo(b.id));
      setState(() {
        _messages = msgs;
        _loading = false;
        if (msgs.isNotEmpty) _lastMsgId = msgs.last.id;
        _hasMore = msgs.length >= 60;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || _messages.isEmpty) return;
    setState(() => _loadingMore = true);
    try {
      final firstId = _messages.first.id;
      final data = await _api.getHistory(widget.dialog.id,
          beforeId: firstId, limit: 60, onlyMe: _onlyMe);
      if (!mounted) return;
      final raw = (data['messages'] as List? ?? []);
      final msgs = raw.map((e) => TgMessage.fromJson(e as Map<String, dynamic>)).toList();
      msgs.sort((a, b) => a.id.compareTo(b.id));
      final oldHeight = _scrollCtrl.position.maxScrollExtent;
      setState(() {
        _messages.insertAll(0, msgs);
        _loadingMore = false;
        _hasMore = msgs.length >= 60;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        final newHeight = _scrollCtrl.position.maxScrollExtent;
        _scrollCtrl.jumpTo(newHeight - oldHeight);
      });
    } catch (e) {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  Future<void> _poll() async {
    if (_lastMsgId == 0) return;
    try {
      final data = await _api.getMessages(widget.dialog.id,
          afterId: _lastMsgId, onlyMe: _onlyMe);
      if (!mounted) return;
      final raw = (data['messages'] as List? ?? []);
      if (raw.isEmpty) return;
      final msgs = raw.map((e) => TgMessage.fromJson(e as Map<String, dynamic>)).toList();
      msgs.sort((a, b) => a.id.compareTo(b.id));
      final atBottom = _scrollCtrl.hasClients &&
          _scrollCtrl.position.pixels >=
              _scrollCtrl.position.maxScrollExtent - 100;
      setState(() {
        _messages.addAll(msgs);
        _lastMsgId = msgs.last.id;
      });
      if (atBottom) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToBottom());
      }
    } catch (_) {}
  }

  void _scrollToBottom() {
    if (_scrollCtrl.hasClients) {
      _scrollCtrl.animateTo(
        _scrollCtrl.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;
    _inputCtrl.clear();
    final replyTo = _replyToId;
    final editId = _editId;
    setState(() { _replyToId = null; _replyToText = null; _editId = null; });
    bool ok;
    if (editId != null) {
      ok = await _api.editMessage(widget.dialog.id, editId, text);
    } else {
      ok = await _api.sendMessage(widget.dialog.id, text, replyTo: replyTo);
    }
    if (ok) await _poll();
  }

  void _setReply(TgMessage msg) {
    setState(() {
      _replyToId = msg.id;
      _replyToText = msg.text.isNotEmpty ? msg.text : '[медиа]';
      _editId = null;
    });
    _inputFocus.requestFocus();
  }

  void _setEdit(TgMessage msg) {
    setState(() {
      _editId = msg.id;
      _replyToId = null;
      _replyToText = null;
      _inputCtrl.text = msg.text;
    });
    _inputFocus.requestFocus();
  }

  void _clearReply() {
    setState(() { _replyToId = null; _replyToText = null; _editId = null; _inputCtrl.clear(); });
  }

  Future<void> _delete(TgMessage msg) async {
    final ok = await _api.deleteMessage(widget.dialog.id, msg.id);
    if (ok && mounted) {
      setState(() => _messages.removeWhere((m) => m.id == msg.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      resizeToAvoidBottomInset: true,
      body: Column(
        children: [
          _buildHeader(),
          Expanded(child: _buildMessages()),
          _buildInput(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 4,
          left: 4, right: 12, bottom: 8),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded,
                color: Color(0xFFF97316), size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () {/* open chat info */},
              child: Row(
                children: [
                  _buildAvatar(),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.dialog.title,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                        Text(_subtitle,
                            style: const TextStyle(
                                color: Color(0xFF71717A), fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, color: Color(0xFFA1A1AA)),
            color: const Color(0xFF18181B),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (v) {
              if (v == 'media') {
                Navigator.push(context, MaterialPageRoute(
                    builder: (_) => MediaGalleryScreen(dialog: widget.dialog)));
              } else if (v == 'only_me') {
                setState(() => _onlyMe = !_onlyMe);
                _load();
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'media',
                  child: Row(children: [
                    const Icon(Icons.photo_library_rounded,
                        color: Color(0xFFF97316), size: 18),
                    const SizedBox(width: 10),
                    const Text('Медиагалерея',
                        style: TextStyle(color: Colors.white)),
                  ])),
              PopupMenuItem(value: 'only_me',
                  child: Row(children: [
                    Icon(_onlyMe ? Icons.group_rounded : Icons.person_rounded,
                        color: const Color(0xFFF97316), size: 18),
                    const SizedBox(width: 10),
                    Text(_onlyMe ? 'Все сообщения' : 'Только мои',
                        style: const TextStyle(color: Colors.white)),
                  ])),
            ],
          ),
        ],
      ),
    );
  }

  String get _subtitle {
    if (widget.dialog.isChannel) return 'Канал';
    if (widget.dialog.isGroup) return 'Группа';
    if (widget.dialog.username.isNotEmpty) return '@${widget.dialog.username}';
    return 'Личное';
  }

  Widget _buildAvatar() {
    final colors = [
      const Color(0xFFF97316), const Color(0xFF8B5CF6),
      const Color(0xFF06B6D4), const Color(0xFF22C55E),
    ];
    final c = colors[(widget.dialog.title.isNotEmpty
            ? widget.dialog.title.codeUnitAt(0)
            : 0) %
        colors.length];
    return Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        gradient: LinearGradient(
            colors: [c, c.withOpacity(0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
            widget.dialog.title.isNotEmpty ? widget.dialog.title[0] : '?',
            style: const TextStyle(
                color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _buildMessages() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(
              color: Color(0xFFF97316), strokeWidth: 2));
    }
    return Stack(
      children: [
        ListView.builder(
          controller: _scrollCtrl,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          itemCount: _messages.length + (_loadingMore ? 1 : 0),
          itemBuilder: (ctx, i) {
            if (i == 0 && _loadingMore) {
              return const Center(
                  child: Padding(
                padding: EdgeInsets.all(8),
                child: CircularProgressIndicator(
                    color: Color(0xFFF97316), strokeWidth: 2),
              ));
            }
            final idx = _loadingMore ? i - 1 : i;
            if (idx >= _messages.length) return const SizedBox.shrink();
            final msg = _messages[idx];
            final prev = idx > 0 ? _messages[idx - 1] : null;
            final showDay = prev == null || prev.dayKey != msg.dayKey;
            return Column(
              children: [
                if (showDay) _DayDivider(label: msg.dayLabel),
                MessageBubble(
                  message: msg,
                  chatId: widget.dialog.id,
                  onReply: () => _setReply(msg),
                  onEdit: msg.out ? () => _setEdit(msg) : null,
                  onDelete: msg.out ? () => _showDeleteDialog(msg) : null,
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  void _showDeleteDialog(TgMessage msg) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF18181B),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Удалить сообщение?',
            style: TextStyle(color: Colors.white, fontSize: 17)),
        content: Text(msg.text.isNotEmpty ? msg.text : '[медиа]',
            maxLines: 3, overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 14)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Отмена', style: TextStyle(color: Color(0xFFA1A1AA))),
          ),
          TextButton(
            onPressed: () { Navigator.pop(ctx); _delete(msg); },
            child: const Text('Удалить', style: TextStyle(color: Color(0xFFEF4444))),
          ),
        ],
      ),
    );
  }

  Widget _buildInput() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(top: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).padding.bottom + 8,
        left: 12, right: 12, top: 8,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (_replyToId != null || _editId != null)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF18181B),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFF97316).withOpacity(0.4)),
              ),
              child: Row(
                children: [
                  Container(width: 3, height: 28,
                      decoration: BoxDecoration(
                          color: const Color(0xFFF97316),
                          borderRadius: BorderRadius.circular(2))),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_editId != null ? 'Редактирование' : 'Ответ',
                            style: const TextStyle(
                                color: Color(0xFFF97316),
                                fontSize: 12, fontWeight: FontWeight.w600)),
                        if (_replyToText != null)
                          Text(_replyToText!,
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Color(0xFFA1A1AA), fontSize: 12)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: _clearReply,
                    child: const Icon(Icons.close_rounded,
                        color: Color(0xFF71717A), size: 18),
                  ),
                ],
              ),
            ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFF18181B),
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(color: const Color(0xFF27272A)),
                  ),
                  child: TextField(
                    controller: _inputCtrl,
                    focusNode: _inputFocus,
                    maxLines: 5,
                    minLines: 1,
                    style: const TextStyle(color: Colors.white, fontSize: 16),
                    decoration: const InputDecoration(
                      hintText: 'Сообщение...',
                      hintStyle: TextStyle(color: Color(0xFF52525B)),
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      border: InputBorder.none,
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _send,
                child: Container(
                  width: 46, height: 46,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                        colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
                    borderRadius: BorderRadius.circular(23),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFF97316).withOpacity(0.4),
                        blurRadius: 12, offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: const Icon(Icons.send_rounded,
                      color: Colors.white, size: 20),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _DayDivider extends StatelessWidget {
  final String label;
  const _DayDivider({required this.label});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          const Expanded(child: Divider(color: Color(0xFF27272A))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xFF18181B),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(label,
                  style: const TextStyle(
                      color: Color(0xFF71717A), fontSize: 12)),
            ),
          ),
          const Expanded(child: Divider(color: Color(0xFF27272A))),
        ],
      ),
    );
  }
}
