import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _urlCtrl = TextEditingController();
  bool _testing = false;
  bool? _testResult;
  Map<String, dynamic>? _stats;
  bool _loadingStats = true;

  @override
  void initState() {
    super.initState();
    final state = context.read<AppState>();
    _urlCtrl.text = state.serverUrl;
    _loadStats();
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  ApiService get _api {
    final s = context.read<AppState>();
    final a = context.read<ApiService>();
    a.updateBase(s.serverUrl);
    return a;
  }

  Future<void> _loadStats() async {
    try {
      final data = await _api.getStats();
      if (mounted) setState(() { _stats = data; _loadingStats = false; });
    } catch (_) {
      if (mounted) setState(() => _loadingStats = false);
    }
  }

  Future<void> _testConnection() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) return;
    setState(() { _testing = true; _testResult = null; });
    try {
      final a = context.read<ApiService>();
      a.updateBase(url);
      final ok = await a.ping();
      if (mounted) setState(() { _testing = false; _testResult = ok; });
      if (ok && mounted) {
        context.read<AppState>().setServer(url);
        _loadStats();
      }
    } catch (_) {
      if (mounted) setState(() { _testing = false; _testResult = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: ListView(
        children: [
          _buildHeader(),
          if (_stats != null || _loadingStats) _buildAccountCard(_stats),
          _buildSection('Сервер', [
            _buildServerInput(),
          ]),
          _buildSection('Данные', [
            if (_stats != null) ...[
              _buildStatRow('Диалогов',
                  '${(_stats!['total_chats'] ?? 0)}'),
              _buildStatRow('Сообщений в кэше',
                  '${(_stats!['total_messages'] ?? 0)}'),
              _buildStatRow('Медиафайлов',
                  '${(_stats!['total_media'] ?? 0)}'),
            ],
            _buildStatRow('URL сервера', state.serverUrl,
                mono: true),
          ]),
          _buildSection('Безопасность', [
            _buildLockTile(context),
          ]),
          _buildSection('Приложение', [
            _buildInfoRow('Версия', '1.0.0'),
            _buildInfoRow('Платформа', 'Android'),
            _buildInfoRow('Режим', 'Телеграм клиент'),
          ]),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 8,
          bottom: 14, left: 20, right: 20),
      child: const Row(
        children: [
          Icon(Icons.settings_rounded, color: Color(0xFFF97316), size: 24),
          SizedBox(width: 12),
          Text('Настройки',
              style: TextStyle(color: Colors.white, fontSize: 20,
                  fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _buildAccountCard(Map<String, dynamic>? stats) {
    final account = stats?['account'] as Map<String, dynamic>?;
    final name = account?['name'] as String? ?? '—';
    final phone = account?['phone'] as String? ?? '—';
    final username = account?['username'] as String? ?? '';

    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFF97316).withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFF97316).withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFF97316), Color(0xFFEA580C)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFF97316).withOpacity(0.4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Center(
              child: Text(
                name.isNotEmpty ? name[0].toUpperCase() : '?',
                style: const TextStyle(color: Colors.white, fontSize: 24,
                    fontWeight: FontWeight.w700),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name,
                    style: const TextStyle(color: Colors.white, fontSize: 18,
                        fontWeight: FontWeight.w700)),
                if (username.isNotEmpty)
                  Text('@$username',
                      style: const TextStyle(
                          color: Color(0xFFF97316), fontSize: 13)),
                Text(phone,
                    style: const TextStyle(
                        color: Color(0xFF71717A), fontSize: 13)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFF22C55E).withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: const Color(0xFF22C55E).withOpacity(0.5)),
            ),
            child: const Text('Online',
                style: TextStyle(color: Color(0xFF22C55E),
                    fontSize: 12, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms).scale(
        begin: const Offset(0.97, 0.97), end: const Offset(1, 1));
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, top: 20, bottom: 8),
          child: Text(title.toUpperCase(),
              style: const TextStyle(
                  color: Color(0xFF52525B),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.0)),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFF0F0F14),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF1F1F28)),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _buildServerInput() {
    return Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('URL сервера',
              style: TextStyle(color: Color(0xFF71717A), fontSize: 12)),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 44,
                  decoration: BoxDecoration(
                    color: const Color(0xFF18181B),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF27272A)),
                  ),
                  child: TextField(
                    controller: _urlCtrl,
                    style: const TextStyle(
                        color: Colors.white, fontSize: 14,
                        fontFamily: 'monospace'),
                    decoration: const InputDecoration(
                      contentPadding: EdgeInsets.symmetric(horizontal: 12),
                      border: InputBorder.none,
                      hintText: 'http://192.168.1.x:5000',
                      hintStyle: TextStyle(color: Color(0xFF3F3F46)),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: _testing ? null : _testConnection,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  height: 44,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: _testResult == true
                        ? const Color(0xFF22C55E)
                        : _testResult == false
                            ? const Color(0xFFEF4444)
                            : const Color(0xFFF97316),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Center(
                    child: _testing
                        ? const SizedBox(
                            width: 18, height: 18,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : Icon(
                            _testResult == true
                                ? Icons.check_rounded
                                : _testResult == false
                                    ? Icons.close_rounded
                                    : Icons.wifi_rounded,
                            color: Colors.white, size: 20),
                  ),
                ),
              ),
            ],
          ),
          if (_testResult != null)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Text(
                _testResult! ? '✓ Подключено' : '✗ Не удалось подключиться',
                style: TextStyle(
                  color: _testResult!
                      ? const Color(0xFF22C55E)
                      : const Color(0xFFEF4444),
                  fontSize: 12,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatRow(String label, String value, {bool mono = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 15)),
          const Spacer(),
          Text(value,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontFamily: mono ? 'monospace' : null,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return _buildStatRow(label, value);
  }

  Widget _buildLockTile(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFFEF4444).withOpacity(0.2),
        ),
        child: const Icon(Icons.lock_rounded,
            color: Color(0xFFEF4444), size: 18),
      ),
      title: const Text('Заблокировать приложение',
          style: TextStyle(color: Color(0xFFEF4444), fontSize: 15)),
      subtitle: const Text('Вернёт к виду калькулятора',
          style: TextStyle(color: Color(0xFF71717A), fontSize: 12)),
      trailing: const Icon(Icons.arrow_forward_ios_rounded,
          color: Color(0xFF3F3F46), size: 14),
      onTap: () {
        context.read<AppState>().lock();
        Navigator.of(context).popUntil((r) => r.isFirst);
      },
    );
  }
}
