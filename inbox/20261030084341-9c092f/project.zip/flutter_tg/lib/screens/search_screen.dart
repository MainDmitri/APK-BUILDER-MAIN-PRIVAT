import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  final _focus = FocusNode();
  Timer? _debounce;
  List<Map<String, dynamic>> _results = [];
  bool _loading = false;
  String _lastQuery = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focus.requestFocus());
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  ApiService get _api {
    final s = context.read<AppState>();
    final a = context.read<ApiService>();
    a.updateBase(s.serverUrl);
    return a;
  }

  void _onChanged(String q) {
    _debounce?.cancel();
    if (q.trim().length < 2) {
      setState(() { _results = []; _loading = false; });
      return;
    }
    setState(() => _loading = true);
    _debounce = Timer(const Duration(milliseconds: 400), () => _search(q.trim()));
  }

  Future<void> _search(String q) async {
    if (q == _lastQuery) return;
    _lastQuery = q;
    try {
      final data = await _api.searchMessages(q);
      if (!mounted || q != _lastQuery) return;
      setState(() {
        _results = List<Map<String, dynamic>>.from(data['results'] ?? []);
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Column(
        children: [
          _buildSearchBar(),
          Expanded(child: _buildResults()),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 6,
          left: 16, right: 16, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 44,
              decoration: BoxDecoration(
                color: const Color(0xFF18181B),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFF27272A)),
              ),
              child: Row(
                children: [
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Icon(Icons.search_rounded,
                        color: Color(0xFF52525B), size: 20),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      focusNode: _focus,
                      onChanged: _onChanged,
                      style: const TextStyle(color: Colors.white, fontSize: 15),
                      decoration: const InputDecoration(
                        hintText: 'Поиск по сообщениям...',
                        hintStyle: TextStyle(color: Color(0xFF52525B)),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ),
                  if (_ctrl.text.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        _ctrl.clear();
                        setState(() { _results = []; _loading = false; _lastQuery = ''; });
                      },
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 12),
                        child: Icon(Icons.close_rounded,
                            color: Color(0xFF52525B), size: 18),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildResults() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(
              color: Color(0xFFF97316), strokeWidth: 2));
    }
    if (_ctrl.text.trim().length < 2) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.search_rounded,
                color: Color(0xFF3F3F46), size: 56),
            const SizedBox(height: 12),
            const Text('Введите текст для поиска',
                style: TextStyle(color: Color(0xFF52525B), fontSize: 16)),
            const SizedBox(height: 4),
            const Text('Минимум 2 символа',
                style: TextStyle(color: Color(0xFF3F3F46), fontSize: 13)),
          ],
        ),
      );
    }
    if (_results.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.inbox_rounded, color: Color(0xFF3F3F46), size: 56),
            const SizedBox(height: 12),
            Text('По запросу «${_ctrl.text}» ничего не найдено',
                textAlign: TextAlign.center,
                style: const TextStyle(color: Color(0xFF52525B), fontSize: 15)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: _results.length,
      itemBuilder: (ctx, i) {
        final r = _results[i];
        final chatTitle = r['chat_title'] as String? ?? 'Чат';
        final sender = r['sender'] as String? ?? '';
        final text = r['text'] as String? ?? '';
        final dayLabel = r['day_label'] as String? ?? '';
        final q = _ctrl.text.trim();
        return _ResultTile(
          chatTitle: chatTitle,
          sender: sender,
          text: text,
          query: q,
          dayLabel: dayLabel,
          index: i,
        );
      },
    );
  }
}

class _ResultTile extends StatelessWidget {
  final String chatTitle;
  final String sender;
  final String text;
  final String query;
  final String dayLabel;
  final int index;

  const _ResultTile({
    required this.chatTitle,
    required this.sender,
    required this.text,
    required this.query,
    required this.dayLabel,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF1F1F28)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        leading: Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [
                const Color(0xFFF97316).withOpacity(0.8),
                const Color(0xFF8B5CF6).withOpacity(0.8),
              ],
            ),
          ),
          child: Center(
            child: Text(
              chatTitle.isNotEmpty ? chatTitle[0] : '?',
              style: const TextStyle(color: Colors.white,
                  fontSize: 18, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        title: Row(
          children: [
            Expanded(
              child: Text(chatTitle,
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.w600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ),
            Text(dayLabel,
                style: const TextStyle(
                    color: Color(0xFF52525B), fontSize: 11)),
          ],
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (sender.isNotEmpty)
              Text(sender,
                  style: const TextStyle(
                      color: Color(0xFFF97316), fontSize: 12,
                      fontWeight: FontWeight.w500)),
            _HighlightedText(text: text, query: query),
          ],
        ),
      ),
    )
        .animate(delay: (index * 25).ms)
        .fadeIn(duration: 200.ms)
        .slideX(begin: 0.03, end: 0);
  }
}

class _HighlightedText extends StatelessWidget {
  final String text;
  final String query;
  const _HighlightedText({required this.text, required this.query});

  @override
  Widget build(BuildContext context) {
    if (query.isEmpty || !text.toLowerCase().contains(query.toLowerCase())) {
      return Text(
        text,
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Color(0xFFA1A1AA), fontSize: 13),
      );
    }
    final idx = text.toLowerCase().indexOf(query.toLowerCase());
    final pre = text.substring(0, idx);
    final match = text.substring(idx, idx + query.length);
    final post = text.substring(idx + query.length);
    const style = TextStyle(color: Color(0xFFA1A1AA), fontSize: 13);
    return Text.rich(
      TextSpan(children: [
        TextSpan(text: pre, style: style),
        TextSpan(
          text: match,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 13,
            fontWeight: FontWeight.w600,
            backgroundColor: Color(0x33F97316),
          ),
        ),
        TextSpan(text: post, style: style),
      ]),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }
}
