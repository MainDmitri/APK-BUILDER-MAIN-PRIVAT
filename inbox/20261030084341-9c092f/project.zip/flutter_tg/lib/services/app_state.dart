import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const _kUnlocked = 'app_unlocked';
  static const _kServer = 'server_url';
  static const _kAccount = 'current_account';

  SharedPreferences? _prefs;

  bool _unlocked = false;
  bool _hasServer = false;
  String _serverUrl = '';
  String _currentAccount = 'main';
  String _sessionsPath = '';

  bool get unlocked => _unlocked;
  bool get hasServer => _hasServer;
  String get serverUrl => _serverUrl;
  String get currentAccount => _currentAccount;
  String get sessionsPath => _sessionsPath;

  AppState();

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _unlocked = _prefs!.getBool(_kUnlocked) ?? false;
    _serverUrl = _prefs!.getString(_kServer) ?? '';
    _hasServer = _serverUrl.isNotEmpty;
    _currentAccount = _prefs!.getString(_kAccount) ?? 'main';
    notifyListeners();
  }

  void setSessionsPath(String path) {
    _sessionsPath = path;
    notifyListeners();
  }

  void unlock() {
    _unlocked = true;
    _prefs?.setBool(_kUnlocked, true);
    notifyListeners();
  }

  void lock() {
    _unlocked = false;
    _prefs?.setBool(_kUnlocked, false);
    notifyListeners();
  }

  Future<void> setServer(String url) async {
    _serverUrl = url.trimRight().replaceAll(RegExp(r'/+$'), '');
    _hasServer = _serverUrl.isNotEmpty;
    await _prefs?.setString(_kServer, _serverUrl);
    notifyListeners();
  }

  Future<void> setAccount(String name) async {
    _currentAccount = name;
    await _prefs?.setString(_kAccount, name);
    notifyListeners();
  }
}
