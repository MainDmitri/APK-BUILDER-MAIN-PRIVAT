import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Background sync service
// Uses WorkManager (via workmanager package) for periodic wake-ups on Android.
// Falls back to periodic isolate-based polling when WorkManager is unavailable.
//
// Registration:
//   1. Add to pubspec.yaml:  workmanager: ^0.5.2
//   2. Add to AndroidManifest.xml (inside <application>):
//      <service
//          android:name="be.tramckrijte.workmanager.BackgroundWorker"
//          android:exported="true" />
//   3. Call BackgroundSyncService.initialize() in main() before runApp().

class BackgroundSyncService {
  static const _taskName = 'tg_sync';
  static const _taskTag = 'tg_sync_periodic';
  static const _prefServer = 'server_url';
  static const _prefLastSync = 'bg_last_sync';
  static const _prefSyncCount = 'bg_sync_count';
  static Timer? _fallbackTimer;

  // Called once from main() — sets up periodic background sync
  static Future<void> initialize() async {
    // Register WorkManager callback
    // WorkManager.initialize(callbackDispatcher, isInDebugMode: kDebugMode);
    // Register periodic task every 15 minutes (Android minimum)
    // WorkManager.registerPeriodicTask(
    //   _taskTag,
    //   _taskName,
    //   frequency: const Duration(minutes: 15),
    //   constraints: Constraints(networkType: NetworkType.connected),
    //   existingWorkPolicy: ExistingWorkPolicy.keep,
    // );
    //
    // For now, use in-app foreground timer as the primary mechanism.
    // This runs while the app is alive (including when backgrounded briefly).
    // WorkManager integration requires adding the workmanager package.
    _startFallbackTimer();
  }

  // Start the foreground periodic timer (runs while app process is alive)
  static void _startFallbackTimer() {
    _fallbackTimer?.cancel();
    _fallbackTimer = Timer.periodic(const Duration(minutes: 2), (_) async {
      await _doSync();
    });
  }

  static void stop() {
    _fallbackTimer?.cancel();
    _fallbackTimer = null;
  }

  // The actual sync work — can be called from WorkManager callback or timer
  static Future<bool> _doSync() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final serverUrl = prefs.getString(_prefServer) ?? '';
      if (serverUrl.isEmpty) return false;

      final base = serverUrl.endsWith('/')
          ? serverUrl.substring(0, serverUrl.length - 1)
          : serverUrl;

      // 1. Ping server
      final ping = await http
          .get(Uri.parse('$base/api/ping'))
          .timeout(const Duration(seconds: 10));
      if (ping.statusCode != 200) return false;

      // 2. Pull dialogs list
      final dialogsRes = await http
          .get(Uri.parse('$base/api/dialogs'))
          .timeout(const Duration(seconds: 30));
      if (dialogsRes.statusCode != 200) return false;

      final dialogs = jsonDecode(dialogsRes.body) as Map<String, dynamic>;
      final items = dialogs['dialogs'] as List? ?? [];

      // 3. For each dialog, pull last 20 messages (touch cache)
      int synced = 0;
      for (final d in items.take(10)) {
        final chatId = d['id']?.toString() ?? '';
        if (chatId.isEmpty) continue;
        try {
          await http
              .get(Uri.parse('$base/api/chat/$chatId/messages?limit=20'))
              .timeout(const Duration(seconds: 15));
          synced++;
        } catch (_) {
          // continue with next dialog
        }
        // Small delay to avoid hammering the server
        await Future.delayed(const Duration(milliseconds: 200));
      }

      // 4. Update sync timestamp
      final now = DateTime.now().millisecondsSinceEpoch;
      await prefs.setInt(_prefLastSync, now);
      final count = (prefs.getInt(_prefSyncCount) ?? 0) + 1;
      await prefs.setInt(_prefSyncCount, count);

      debugPrint('[BgSync] Synced $synced/${items.length} chats at ${DateTime.now()}');
      return true;
    } catch (e) {
      debugPrint('[BgSync] Error: $e');
      return false;
    }
  }

  // Retrieve sync info for display in settings
  static Future<Map<String, dynamic>> getSyncInfo() async {
    final prefs = await SharedPreferences.getInstance();
    final lastSync = prefs.getInt(_prefLastSync);
    final count = prefs.getInt(_prefSyncCount) ?? 0;
    return {
      'last_sync': lastSync,
      'sync_count': count,
      'last_sync_label': lastSync != null
          ? _formatTime(DateTime.fromMillisecondsSinceEpoch(lastSync))
          : 'Никогда',
    };
  }

  static String _formatTime(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Только что';
    if (diff.inMinutes < 60) return '${diff.inMinutes} мин назад';
    if (diff.inHours < 24) return '${diff.inHours} ч назад';
    return '${dt.day}.${dt.month.toString().padLeft(2, '0')} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}';
  }
}

// WorkManager top-level callback (must be a top-level function)
// Uncomment when workmanager package is added:
//
// @pragma('vm:entry-point')
// void callbackDispatcher() {
//   WorkManager.executeTask((taskName, inputData) async {
//     if (taskName == BackgroundSyncService._taskName) {
//       return await BackgroundSyncService._doSync();
//     }
//     return true;
//   });
// }
