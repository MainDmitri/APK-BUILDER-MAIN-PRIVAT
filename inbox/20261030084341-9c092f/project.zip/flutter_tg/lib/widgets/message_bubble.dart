import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/message.dart';
import '../services/api_service.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';

class MessageBubble extends StatelessWidget {
  final TgMessage message;
  final String chatId;
  final VoidCallback? onReply;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const MessageBubble({
    super.key,
    required this.message,
    required this.chatId,
    this.onReply,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final isOut = message.out;
    return GestureDetector(
      onLongPress: () => _showActions(context),
      child: Padding(
        padding: EdgeInsets.only(
          left: isOut ? 64 : 0,
          right: isOut ? 0 : 64,
          top: 2,
          bottom: 2,
        ),
        child: Row(
          mainAxisAlignment:
              isOut ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isOut) ...[
              _buildAvatar(),
              const SizedBox(width: 6),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment:
                    isOut ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (!isOut && message.sender.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 2),
                      child: Text(message.sender,
                          style: TextStyle(
                            color: _senderColor(message.sender),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          )),
                    ),
                  _buildBubble(context, isOut),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate()
        .fadeIn(duration: 200.ms)
        .slideY(begin: 0.1, end: 0, duration: 200.ms, curve: Curves.easeOut);
  }

  Color _senderColor(String name) {
    final colors = [
      const Color(0xFFF97316),
      const Color(0xFF8B5CF6),
      const Color(0xFF06B6D4),
      const Color(0xFF22C55E),
      const Color(0xFFEC4899),
      const Color(0xFFF59E0B),
    ];
    int hash = 0;
    for (final c in name.codeUnits) {
      hash = (hash * 31 + c) & 0xFFFFFF;
    }
    return colors[hash % colors.length];
  }

  Widget _buildAvatar() {
    final c = _senderColor(message.sender);
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c, c.withOpacity(0.6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          message.sender.isNotEmpty ? message.sender[0] : '?',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildBubble(BuildContext context, bool isOut) {
    return Container(
      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
      decoration: BoxDecoration(
        color: isOut ? const Color(0xFF1A3A5C) : const Color(0xFF1A1A24),
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(isOut ? 18 : 4),
          bottomRight: Radius.circular(isOut ? 4 : 18),
        ),
        border: Border.all(
          color: isOut
              ? const Color(0xFF1E4A7A)
              : const Color(0xFF27272A),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            isOut ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (message.isOneTime) _buildOneTimeMedia(context),
          if (message.isPhoto && !message.isOneTime) _buildPhoto(context),
          if (message.isVideo && !message.isOneTime) _buildVideo(context),
          if (message.isVoice) _buildVoice(),
          if (message.isSticker) _buildSticker(context),
          if (message.isDocument && !message.isPhoto && !message.isVideo)
            _buildDocument(),
          if (message.text.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(
                left: 12,
                right: 12,
                top: _hasMedia ? 6 : 10,
                bottom: 4,
              ),
              child: Text(
                message.text,
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
            ),
          Padding(
            padding: const EdgeInsets.only(right: 10, bottom: 6, left: 10, top: 2),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  message.timeStr,
                  style: const TextStyle(
                    color: Color(0xFF71717A),
                    fontSize: 11,
                  ),
                ),
                if (isOut) ...[
                  const SizedBox(width: 4),
                  const Icon(Icons.done_all_rounded,
                      color: Color(0xFF3B82F6), size: 14),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool get _hasMedia =>
      message.isPhoto || message.isVideo || message.isOneTime ||
      message.isSticker || message.isVoice;

  Widget _buildOneTimeMedia(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(4),
      height: 200,
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F14),
        borderRadius: BorderRadius.circular(14),
        gradient: LinearGradient(
          colors: [
            const Color(0xFFF97316).withOpacity(0.2),
            const Color(0xFF8B5CF6).withOpacity(0.2),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFF97316).withOpacity(0.2),
              border: Border.all(
                  color: const Color(0xFFF97316).withOpacity(0.6), width: 2),
            ),
            child: const Icon(Icons.visibility_rounded,
                color: Color(0xFFF97316), size: 28),
          ),
          const SizedBox(height: 10),
          const Text('Одноразовое фото',
              style: TextStyle(color: Colors.white, fontSize: 14,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          GestureDetector(
            onTap: () => _openOneTimeMedia(context),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFF97316),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.play_arrow_rounded, color: Colors.white, size: 18),
                  SizedBox(width: 6),
                  Text('Открыть', style: TextStyle(color: Colors.white,
                      fontSize: 14, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openOneTimeMedia(BuildContext context) async {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    final url = api.mediaUrl(chatId, message.id);
    await showDialog(
      context: context,
      builder: (_) => _FullscreenMediaDialog(url: url, isVideo: message.isVideo),
    );
  }

  Widget _buildPhoto(BuildContext context) {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    final url = api.mediaUrl(chatId, message.id);
    return GestureDetector(
      onTap: () => showDialog(
        context: context,
        builder: (_) => _FullscreenMediaDialog(url: url, isVideo: false),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(17),
          topRight: Radius.circular(17),
        ),
        child: Image.network(
          url,
          height: 220,
          width: double.infinity,
          fit: BoxFit.cover,
          loadingBuilder: (ctx, child, progress) {
            if (progress == null) return child;
            return Container(
              height: 220,
              color: const Color(0xFF18181B),
              child: const Center(
                child: CircularProgressIndicator(
                    color: Color(0xFFF97316), strokeWidth: 2),
              ),
            );
          },
          errorBuilder: (_, __, ___) => Container(
            height: 80,
            color: const Color(0xFF18181B),
            child: const Center(
              child: Icon(Icons.broken_image_rounded,
                  color: Color(0xFF52525B), size: 32),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildVideo(BuildContext context) {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    final url = api.mediaUrl(chatId, message.id);
    return GestureDetector(
      onTap: () => showDialog(
        context: context,
        builder: (_) => _FullscreenMediaDialog(url: url, isVideo: true),
      ),
      child: Container(
        height: 200,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: const Color(0xFF18181B),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Stack(
          alignment: Alignment.center,
          children: [
            Icon(Icons.video_file_rounded, color: Color(0xFF52525B), size: 48),
            Positioned(
              bottom: 8,
              left: 12,
              child: Row(
                children: [
                  Icon(Icons.play_circle_rounded,
                      color: Color(0xFFF97316), size: 28),
                  SizedBox(width: 6),
                  Text('Видео', style: TextStyle(
                      color: Colors.white, fontSize: 13,
                      fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVoice() {
    return Container(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF18181B),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFF97316).withOpacity(0.2),
            ),
            child: const Icon(Icons.mic_rounded,
                color: Color(0xFFF97316), size: 20),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 100, height: 3,
                decoration: BoxDecoration(
                  color: const Color(0xFFF97316).withOpacity(0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 4),
              const Text('Голосовое',
                  style: TextStyle(color: Color(0xFF71717A), fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSticker(BuildContext context) {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    final url = api.mediaUrl(chatId, message.id);
    return Padding(
      padding: const EdgeInsets.all(4),
      child: Image.network(
        url,
        width: 120, height: 120,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => const SizedBox(
          width: 120, height: 80,
          child: Center(child: Text('🎭', style: TextStyle(fontSize: 36))),
        ),
      ),
    );
  }

  Widget _buildDocument() {
    return Container(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF18181B),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.insert_drive_file_rounded,
              color: Color(0xFF3B82F6), size: 28),
          SizedBox(width: 10),
          Text('Документ',
              style: TextStyle(color: Colors.white, fontSize: 14,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  void _showActions(BuildContext context) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF18181B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40, height: 4, margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF3F3F46),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            if (message.text.isNotEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Text(
                  message.text,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF71717A), fontSize: 13),
                ),
              ),
            const Divider(color: Color(0xFF27272A)),
            _ActionTile(
              icon: Icons.reply_rounded,
              label: 'Ответить',
              onTap: () { Navigator.pop(context); onReply?.call(); },
            ),
            _ActionTile(
              icon: Icons.copy_rounded,
              label: 'Копировать',
              onTap: () {
                Navigator.pop(context);
                Clipboard.setData(ClipboardData(text: message.text));
              },
            ),
            if (onEdit != null)
              _ActionTile(
                icon: Icons.edit_rounded,
                label: 'Редактировать',
                onTap: () { Navigator.pop(context); onEdit?.call(); },
              ),
            if (onDelete != null)
              _ActionTile(
                icon: Icons.delete_rounded,
                label: 'Удалить',
                color: const Color(0xFFEF4444),
                onTap: () { Navigator.pop(context); onDelete?.call(); },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _ActionTile({
    required this.icon, required this.label, required this.onTap,
    this.color = Colors.white,
  });
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color, size: 22),
      title: Text(label, style: TextStyle(color: color, fontSize: 16)),
      onTap: onTap,
    );
  }
}

class _FullscreenMediaDialog extends StatelessWidget {
  final String url;
  final bool isVideo;
  const _FullscreenMediaDialog({required this.url, required this.isVideo});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black,
      insetPadding: EdgeInsets.zero,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          InteractiveViewer(
            child: isVideo
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.play_circle_rounded,
                            color: Color(0xFFF97316), size: 72),
                        const SizedBox(height: 16),
                        const Text('Нажмите для воспроизведения',
                            style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  )
                : Image.network(url, fit: BoxFit.contain),
          ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            right: 12,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withOpacity(0.6),
                ),
                child: const Icon(Icons.close_rounded,
                    color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
