import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/app_state.dart';
import 'services/api_service.dart';
import 'services/background_service.dart';
import 'services/session_installer.dart';
import 'screens/calculator_screen.dart';
import 'screens/setup_screen.dart';
import 'screens/chat_list_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF07070A),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // 1. Extract bundled session files to app storage (idempotent)
  final sessionDir = await SessionInstaller.install();

  // 2. Load persisted app state
  final appState = AppState();
  await appState.init();

  // Store sessions path for reference
  appState.setSessionsPath(sessionDir);

  // 3. Start background sync
  await BackgroundSyncService.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appState),
        Provider(create: (_) => ApiService()),
      ],
      child: const TgApp(),
    ),
  );
}

class TgApp extends StatelessWidget {
  const TgApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFFF97316),
          secondary: const Color(0xFF8B5CF6),
          surface: const Color(0xFF0F0F14),
          background: const Color(0xFF07070A),
        ),
        scaffoldBackgroundColor: const Color(0xFF07070A),
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
      ),
      home: const RootRouter(),
    );
  }
}

class RootRouter extends StatelessWidget {
  const RootRouter({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    if (!state.unlocked) return const CalculatorScreen();
    if (!state.hasServer) return const SetupScreen();
    return const ChatListScreen();
  }
}
