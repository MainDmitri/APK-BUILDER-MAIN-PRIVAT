class TgMessage {
  final int id;
  final String text;
  final bool out;
  final String sender;
  final String senderUsername;
  final String mediaHtml;
  final String dayKey;
  final String dayLabel;
  final String date;

  // Computed
  final bool isPhoto;
  final bool isVideo;
  final bool isOneTime;
  final bool isSticker;
  final bool isVoice;
  final bool isDocument;

  TgMessage({
    required this.id,
    required this.text,
    required this.out,
    required this.sender,
    required this.senderUsername,
    required this.mediaHtml,
    required this.dayKey,
    required this.dayLabel,
    required this.date,
    required this.isPhoto,
    required this.isVideo,
    required this.isOneTime,
    required this.isSticker,
    required this.isVoice,
    required this.isDocument,
  });

  factory TgMessage.fromJson(Map<String, dynamic> j) {
    final media = (j['media_html'] as String? ?? '').toLowerCase();
    final isOneTime = media.contains('ot-card') ||
        media.contains('view_once') ||
        media.contains('одноразовое');
    final isPhoto = media.contains('<img') || media.contains('photo');
    final isVideo = media.contains('video') &&
        !media.contains('<img');
    final isVoice = media.contains('voice') || media.contains('audio');
    final isSticker = media.contains('sticker') || media.contains('.webp');
    final isDocument = media.contains('document') ||
        media.contains('file') && !isPhoto && !isVideo;

    return TgMessage(
      id: (j['id'] as num?)?.toInt() ?? (j['msg_id'] as num?)?.toInt() ?? 0,
      text: j['text'] as String? ?? '',
      out: j['out'] == true || j['out'] == 1,
      sender: j['sender'] as String? ?? '',
      senderUsername: j['sender_username'] as String? ?? '',
      mediaHtml: j['media_html'] as String? ?? '',
      dayKey: j['day_key'] as String? ?? '',
      dayLabel: j['day_label'] as String? ?? '',
      date: j['date'] as String? ?? '',
      isPhoto: isPhoto && !isOneTime,
      isVideo: isVideo && !isOneTime,
      isOneTime: isOneTime,
      isSticker: isSticker,
      isVoice: isVoice,
      isDocument: isDocument,
    );
  }

  String get timeStr {
    if (date.isEmpty) return '';
    try {
      final dt = DateTime.parse(date).toLocal();
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) { return ''; }
  }
}

class TgDialog {
  final String id;
  final String title;
  final String username;
  final String kind;
  final String lastMessage;
  final String lastSeen;
  final int unread;

  final bool isGroup;
  final bool isChannel;
  final bool isUser;

  TgDialog({
    required this.id,
    required this.title,
    required this.username,
    required this.kind,
    required this.lastMessage,
    required this.lastSeen,
    required this.unread,
    required this.isGroup,
    required this.isChannel,
    required this.isUser,
  });

  factory TgDialog.fromJson(Map<String, dynamic> j) {
    final kind = j['kind'] as String? ?? 'user';
    return TgDialog(
      id: j['id']?.toString() ?? '',
      title: j['title'] as String? ?? '',
      username: j['username'] as String? ?? '',
      kind: kind,
      lastMessage: j['last_message'] as String? ?? j['text'] as String? ?? '',
      lastSeen: j['last_seen'] as String? ?? '',
      unread: (j['unread'] as num?)?.toInt() ?? 0,
      isGroup: kind == 'group' || kind == 'supergroup' || kind == 'megagroup',
      isChannel: kind == 'channel' || kind == 'broadcast',
      isUser: kind == 'user' || kind == 'bot',
    );
  }
}
