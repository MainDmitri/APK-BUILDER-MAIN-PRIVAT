package com.maindmitri.wikkeoposter.data

import android.content.Context
import kotlin.math.max
import kotlin.math.roundToInt

enum class AiProvider(
    val code: String,
    val title: String,
    val defaultBaseUrl: String,
    val defaultModel: String,
    val suggestedModels: List<String>
) {
    RUSAPIX(
        code = "rusapix",
        title = "RusAPIX",
        defaultBaseUrl = "https://rusapix.ru/v1",
        defaultModel = "gpt-4o-mini",
        suggestedModels = listOf(
            "gpt-4o-mini",
            "gpt-4.1-mini",
            "gemini-2.5-flash",
            "deepseek-chat"
        )
    ),
    OPENROUTER(
        code = "openrouter",
        title = "OpenRouter",
        defaultBaseUrl = "https://openrouter.ai/api/v1",
        defaultModel = "google/gemini-2.5-flash",
        suggestedModels = listOf(
            "google/gemini-2.5-flash",
            "openai/gpt-4o-mini",
            "deepseek/deepseek-chat-v3-0324",
            "anthropic/claude-3.5-haiku"
        )
    );

    companion object {
        fun fromCode(code: String?): AiProvider =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: RUSAPIX
    }
}

data class AppSettings(
    val aiProvider: AiProvider = AiProvider.RUSAPIX,
    val rusapixApiKey: String = "",
    val rusapixBaseUrl: String = AiProvider.RUSAPIX.defaultBaseUrl,
    val rusapixModel: String = AiProvider.RUSAPIX.defaultModel,
    val openRouterApiKey: String = "",
    val openRouterModel: String = AiProvider.OPENROUTER.defaultModel,
    val customStyleHint: String = "Живой, продающий стиль без воды, акцент на выгоду и характеристики.",
    val telegramBotToken: String = "",
    val telegramChannelId: String = "",
    val orderContact: String = "",
    val buyButtonText: String = "🛒 Купить",
    val buyButtonUrl: String = "",
    val extraHashtags: String = "#новинка",
    val singlePhotoWithButton: Boolean = false,
    val includeSourceLink: Boolean = false,
    val autoPublish: Boolean = false,
    val vkAccessToken: String = "",
    val vkGroupId: String = "",
    val autoPublishVk: Boolean = false,
    val maxBotToken: String = "",
    val maxChatId: String = "",
    val autoPublishMax: Boolean = false,
    val markupPercent: Double = 20.0,
    val markupFixed: Int = 0,
    val roundTo: Int = 10,
    val maxProductsPerBatch: Int = 5,
    val maxPhotosPerPost: Int = 8
) {
    fun activeApiKey(): String = when (aiProvider) {
        AiProvider.RUSAPIX -> normalizeApiKey(rusapixApiKey)
        AiProvider.OPENROUTER -> normalizeApiKey(openRouterApiKey)
    }

    fun activeBaseUrl(): String = when (aiProvider) {
        AiProvider.RUSAPIX -> rusapixBaseUrl.trim().ifEmpty { AiProvider.RUSAPIX.defaultBaseUrl }
        AiProvider.OPENROUTER -> AiProvider.OPENROUTER.defaultBaseUrl
    }

    fun activeModel(): String = when (aiProvider) {
        AiProvider.RUSAPIX -> rusapixModel.trim().ifEmpty { AiProvider.RUSAPIX.defaultModel }
        AiProvider.OPENROUTER -> openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultModel }
    }

    fun calculateFinalPrice(wholesalePrice: Double?): Int? {
        if (wholesalePrice == null || wholesalePrice <= 0.0) return null
        var price = wholesalePrice * (1.0 + markupPercent / 100.0) + markupFixed
        if (roundTo > 1) {
            price = (price / roundTo).roundToInt() * roundTo.toDouble()
        }
        return max(1, price.roundToInt())
    }

    fun resolveBuyUrl(): String? {
        val raw = buyButtonUrl.trim().ifEmpty { orderContact.trim() }
        if (raw.isBlank()) return null
        return when {
            raw.startsWith("https://", ignoreCase = true) ||
                raw.startsWith("http://", ignoreCase = true) -> raw
            raw.startsWith("@") -> "https://t.me/${raw.removePrefix("@").trim()}"
            raw.startsWith("t.me/", ignoreCase = true) -> "https://$raw"
            !raw.contains(" ") && raw.matches(Regex("[a-zA-Z0-9_]{3,64}")) -> "https://t.me/$raw"
            else -> null
        }
    }

    companion object {
        /**
         * Accepts either a raw API key (sk-...) or a RusAPIX login link like https://rusapix.ru/login#k=sk-...
         */
        fun normalizeApiKey(raw: String): String {
            val trimmed = raw.trim()
            val match = Regex("(?:[#?&]k=)([^&#\\s]+)", RegexOption.IGNORE_CASE).find(trimmed)
            return if (match != null) match.groupValues[1].trim() else trimmed
        }
    }
}

class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "wikkeo_poster_prefs",
        Context.MODE_PRIVATE
    )

    fun load(): AppSettings = AppSettings(
        aiProvider = AiProvider.fromCode(prefs.getString("ai_provider", AiProvider.RUSAPIX.code)),
        rusapixApiKey = prefs.getString("rusapix_api_key", "") ?: "",
        rusapixBaseUrl = prefs.getString("rusapix_base_url", AiProvider.RUSAPIX.defaultBaseUrl)
            ?: AiProvider.RUSAPIX.defaultBaseUrl,
        rusapixModel = prefs.getString("rusapix_model", AiProvider.RUSAPIX.defaultModel)
            ?: AiProvider.RUSAPIX.defaultModel,
        openRouterApiKey = prefs.getString("openrouter_api_key", "") ?: "",
        openRouterModel = prefs.getString("openrouter_model", AiProvider.OPENROUTER.defaultModel)
            ?: AiProvider.OPENROUTER.defaultModel,
        customStyleHint = prefs.getString(
            "custom_style_hint",
            "Живой, продающий стиль без воды, акцент на выгоду и характеристики."
        ) ?: "",
        telegramBotToken = prefs.getString("telegram_bot_token", "") ?: "",
        telegramChannelId = prefs.getString("telegram_channel_id", "") ?: "",
        orderContact = prefs.getString("order_contact", "") ?: "",
        buyButtonText = prefs.getString("buy_button_text", "🛒 Купить") ?: "🛒 Купить",
        buyButtonUrl = prefs.getString("buy_button_url", "") ?: "",
        extraHashtags = prefs.getString("extra_hashtags", "#новинка") ?: "#новинка",
        singlePhotoWithButton = prefs.getBoolean("single_photo_with_button", false),
        includeSourceLink = prefs.getBoolean("include_source_link", false),
        autoPublish = prefs.getBoolean("auto_publish", false),
        vkAccessToken = prefs.getString("vk_access_token", "") ?: "",
        vkGroupId = prefs.getString("vk_group_id", "") ?: "",
        autoPublishVk = prefs.getBoolean("auto_publish_vk", false),
        maxBotToken = prefs.getString("max_bot_token", "") ?: "",
        maxChatId = prefs.getString("max_chat_id", "") ?: "",
        autoPublishMax = prefs.getBoolean("auto_publish_max", false),
        markupPercent = prefs.getFloat("markup_percent", 20f).toDouble(),
        markupFixed = prefs.getInt("markup_fixed", 0),
        roundTo = prefs.getInt("round_to", 10).coerceAtLeast(1),
        maxProductsPerBatch = prefs.getInt("max_products_per_batch", 5).coerceIn(1, 30),
        maxPhotosPerPost = prefs.getInt("max_photos_per_post", 8).coerceIn(1, 10)
    )

    fun save(settings: AppSettings) {
        prefs.edit()
            .putString("ai_provider", settings.aiProvider.code)
            .putString("rusapix_api_key", AppSettings.normalizeApiKey(settings.rusapixApiKey))
            .putString(
                "rusapix_base_url",
                settings.rusapixBaseUrl.trim().ifEmpty { AiProvider.RUSAPIX.defaultBaseUrl }
            )
            .putString(
                "rusapix_model",
                settings.rusapixModel.trim().ifEmpty { AiProvider.RUSAPIX.defaultModel }
            )
            .putString("openrouter_api_key", AppSettings.normalizeApiKey(settings.openRouterApiKey))
            .putString(
                "openrouter_model",
                settings.openRouterModel.trim().ifEmpty { AiProvider.OPENROUTER.defaultModel }
            )
            .putString("custom_style_hint", settings.customStyleHint.trim())
            .putString("telegram_bot_token", settings.telegramBotToken.trim())
            .putString("telegram_channel_id", settings.telegramChannelId.trim())
            .putString("order_contact", settings.orderContact.trim())
            .putString("buy_button_text", settings.buyButtonText.trim().ifEmpty { "🛒 Купить" })
            .putString("buy_button_url", settings.buyButtonUrl.trim())
            .putString("extra_hashtags", settings.extraHashtags.trim())
            .putBoolean("single_photo_with_button", settings.singlePhotoWithButton)
            .putBoolean("include_source_link", settings.includeSourceLink)
            .putBoolean("auto_publish", settings.autoPublish)
            .putString("vk_access_token", settings.vkAccessToken.trim())
            .putString("vk_group_id", settings.vkGroupId.trim())
            .putBoolean("auto_publish_vk", settings.autoPublishVk)
            .putString("max_bot_token", settings.maxBotToken.trim())
            .putString("max_chat_id", settings.maxChatId.trim())
            .putBoolean("auto_publish_max", settings.autoPublishMax)
            .putFloat("markup_percent", settings.markupPercent.toFloat())
            .putInt("markup_fixed", settings.markupFixed)
            .putInt("round_to", settings.roundTo.coerceAtLeast(1))
            .putInt("max_products_per_batch", settings.maxProductsPerBatch.coerceIn(1, 30))
            .putInt("max_photos_per_post", settings.maxPhotosPerPost.coerceIn(1, 10))
            .apply()
    }
}
