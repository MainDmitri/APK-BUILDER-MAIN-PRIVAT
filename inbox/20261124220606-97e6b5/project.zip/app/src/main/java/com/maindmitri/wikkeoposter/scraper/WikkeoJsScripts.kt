package com.maindmitri.wikkeoposter.scraper

import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.security.MessageDigest

object WikkeoJsScripts {

    const val EXTRACT_CATALOG_LINKS_JS: String = """
        (function() {
            const seen = new Set();
            const out = [];
            function addLink(raw) {
                if (!raw) return;
                try {
                    const u = new URL(raw, window.location.origin);
                    const clean = u.origin + u.pathname;
                    if (clean.indexOf('/item/') !== -1 && !seen.has(clean)) {
                        seen.add(clean);
                        out.push(clean);
                    }
                } catch (e) {}
            }
            document.querySelectorAll("a[href*='/item/']").forEach(function(a) {
                addLink(a.getAttribute('href'));
            });
            if (out.length < 3) {
                const html = document.documentElement ? document.documentElement.innerHTML : '';
                const matches = html.match(/https?:\/\/wikkeo\.com\/item\/[a-zA-Z0-9_\-]+|\/item\/[a-zA-Z0-9_\-]+/g) || [];
                matches.forEach(addLink);
            }
            return JSON.stringify(out);
        })();
    """

    const val EXTRACT_PRODUCT_JS: String = """
        (function() {
            function norm(s) {
                return (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
            }
            function parseRub(txt) {
                if (!txt) return null;
                var c = txt.replace(/\u00a0/g, ' ').replace(/\u202f/g, ' ');
                var m = c.match(/(\d[\d\s]{0,12}(?:[.,]\d{1,2})?)\s*(?:₽|руб\.?|RUB)/i)
                     || c.match(/(\d[\d\s]{0,12}(?:[.,]\d{1,2})?)/);
                if (!m) return null;
                var v = parseFloat(m[1].replace(/\s+/g, '').replace(',', '.'));
                return (isFinite(v) && v > 0) ? v : null;
            }
            function isUiBoilerplate(txt) {
                if (!txt) return true;
                var low = txt.toLowerCase();
                var markers = [
                    'безопасная сделка',
                    'укажите город в профиле',
                    'а мы рассчитаем доставку',
                    'вы получите заказанные товары',
                    'виккео доставка',
                    'wikkeo.com - это оптовый маркетплейс',
                    'item 1 of',
                    'в корзину',
                    'написать продавцу'
                ];
                var hits = 0;
                for (var i = 0; i < markers.length; i++) {
                    if (low.indexOf(markers[i]) !== -1) hits++;
                }
                return hits >= 2 || low.indexOf('укажите город в профиле') !== -1 || low.indexOf('безопасная сделка с виккео') !== -1;
            }
            function cleanDescriptionText(raw) {
                if (!raw) return '';
                var lines = raw.split(/\n+/).map(function(l) { return norm(l); }).filter(Boolean);
                var filtered = lines.filter(function(line) {
                    var low = line.toLowerCase();
                    if (/^item\s+\d+\s+of\s+\d+$/i.test(line)) return false;
                    if (/^\d+\s*\/\s*\d+$/.test(line)) return false;
                    if (/^продано\s+\d+/i.test(line)) return false;
                    if (/^осталось\s+\d+/i.test(line)) return false;
                    if (/^\d[\d\s]*₽$/.test(line)) return false;
                    if (/^\d+\s*-\s*\d+\s*шт/i.test(line)) return false;
                    if (low === 'описание' || low === 'описание товара' || low === 'виккео доставка') return false;
                    if (low.indexOf('укажите город в профиле') !== -1) return false;
                    if (low.indexOf('рассчитаем доставку') !== -1) return false;
                    if (low.indexOf('безопасная сделка') !== -1) return false;
                    if (low.indexOf('продавец вернет вам деньги') !== -1) return false;
                    if (low.indexOf('wikkeo.com - это оптовый') !== -1) return false;
                    if (low.indexOf('в корзину') !== -1 || low.indexOf('купить сейчас') !== -1) return false;
                    return true;
                });
                return filtered.join('\n').replace(/\(WVP-\d+\)/gi, '').trim();
            }

            var url = window.location.href.split('#')[0].split('?')[0];
            var h1 = document.querySelector('h1');
            var ogTitle = document.querySelector("meta[property='og:title']");
            var rawTitle = norm(h1 ? h1.innerText : '') || norm(ogTitle ? ogTitle.content : '') || norm(document.title) || 'Товар';
            var title = rawTitle.replace(/\s*\(WVP-\d+\)\s*/gi, ' ').replace(/\s*[-|]\s*Wikkeo.*$/i, '').trim();
            if (!title) title = 'Товар';

            var ldPrice = null;
            var ldDesc = '';
            var ldImages = [];
            document.querySelectorAll("script[type='application/ld+json']").forEach(function(sc) {
                try {
                    var parsed = JSON.parse(sc.textContent || '');
                    var arr = Array.isArray(parsed) ? parsed : [parsed];
                    arr.forEach(function(obj) {
                        if (obj && obj['@type'] === 'Product') {
                            if (obj.description && !ldDesc && !isUiBoilerplate(String(obj.description))) {
                                ldDesc = String(obj.description).trim();
                            }
                            if (typeof obj.image === 'string') ldImages.push(obj.image);
                            else if (Array.isArray(obj.image)) obj.image.forEach(function(i) { if (typeof i === 'string') ldImages.push(i); });
                            if (obj.offers) {
                                var p = obj.offers.price || obj.offers.lowPrice;
                                if (p != null) {
                                    var pv = parseFloat(String(p).replace(',', '.'));
                                    if (isFinite(pv) && pv > 0) ldPrice = pv;
                                }
                            }
                        }
                    });
                } catch (e) {}
            });

            var price = ldPrice;
            if (price == null) {
                var priceEls = document.querySelectorAll("[class*='price'], [class*='Price'], [data-testid*='price']");
                for (var i = 0; i < priceEls.length; i++) {
                    var el = priceEls[i];
                    var cls = (el.className || '').toString().toLowerCase();
                    var tag = (el.tagName || '').toLowerCase();
                    if (tag === 'del' || tag === 's' || cls.indexOf('old') !== -1 || cls.indexOf('cross') !== -1 || cls.indexOf('strike') !== -1) continue;
                    var t = norm(el.innerText);
                    if (t.indexOf('₽') !== -1 && t.length < 40) {
                        var pv2 = parseRub(t);
                        if (pv2 != null) { price = pv2; break; }
                    }
                }
            }
            if (price == null) {
                price = parseRub(document.body ? document.body.innerText : '');
            }

            var storeLink = document.querySelector("a[href*='/store/']");
            var seller = storeLink ? norm(storeLink.innerText) : '';

            var catLinks = document.querySelectorAll("a[href*='/category/']");
            var category = '';
            if (catLinks.length > 0) {
                category = norm(catLinks[catLinks.length - 1].innerText);
            }

            // 1) Try to locate the real "Описание" section specifically
            var rawDescription = cleanDescriptionText(ldDesc);
            if (!rawDescription) {
                var headings = document.querySelectorAll('h2, h3, h4, h5, p, span, div');
                for (var h = 0; h < headings.length; h++) {
                    var node = headings[h];
                    if (node.children && node.children.length > 0) continue;
                    var ht = norm(node.innerText).toLowerCase();
                    if (ht === 'описание' || ht === 'описание товара') {
                        var sibling = node.nextElementSibling;
                        var candidate = sibling ? (sibling.innerText || '') : '';
                        if (!candidate && node.parentElement && node.parentElement.nextElementSibling) {
                            candidate = node.parentElement.nextElementSibling.innerText || '';
                        }
                        if (!candidate && node.parentElement) {
                            candidate = (node.parentElement.innerText || '').replace(/^описание(\s+товара)?/i, '');
                        }
                        if (candidate && !isUiBoilerplate(candidate)) {
                            rawDescription = cleanDescriptionText(candidate);
                            if (rawDescription.length >= 15) break;
                        }
                    }
                }
            }

            // 2) Fallback: dedicated description classes only (never whole <article> wrapper)
            if (!rawDescription) {
                var descEls = document.querySelectorAll("[itemprop='description'], [class*='description'], [class*='Description']");
                var best = '';
                descEls.forEach(function(el) {
                    var txt = (el.innerText || '').trim();
                    if (txt.length > 15 && txt.length < 3000 && !isUiBoilerplate(txt)) {
                        var cleaned = cleanDescriptionText(txt);
                        if (cleaned.length > best.length) best = cleaned;
                    }
                });
                rawDescription = best;
            }

            // Extract real specs (skipping UI/delivery/stock rows)
            var specs = {};
            document.querySelectorAll("tr, [class*='spec'], [class*='char'], [class*='attribute']").forEach(function(row) {
                var kids = Array.from(row.children || []);
                if (kids.length === 2) {
                    var k = norm(kids[0].innerText).replace(/:$/, '');
                    var v = norm(kids[1].innerText);
                    var kl = k.toLowerCase();
                    if (k.length > 1 && k.length <= 45 && v.length > 0 && v.length <= 100
                        && kl.indexOf('условия') === -1
                        && kl.indexOf('доставк') === -1
                        && kl.indexOf('продано') === -1
                        && kl.indexOf('осталось') === -1
                        && !specs[k]) {
                        specs[k] = v;
                    }
                }
            });

            // Extract variant/color labels cleanly (e.g. "Синий Осталось 500шт" -> "Синий")
            var bodyLines = (document.body ? document.body.innerText : '').split(/\n+/).map(norm);
            var variants = [];
            for (var b = 0; b < bodyLines.length - 1; b++) {
                if (/^осталось\s+\d+\s*шт/i.test(bodyLines[b + 1])) {
                    var label = bodyLines[b];
                    if (label.length >= 2 && label.length <= 32 && !/\d{3,}|₽|WVP/i.test(label)) {
                        if (variants.indexOf(label) === -1) variants.push(label);
                    }
                }
            }
            if (variants.length > 0 && !specs['Варианты']) {
                specs['Варианты'] = variants.slice(0, 8).join(', ');
            }

            var badParts = ['default-shop-avatar', 'avatar', 'logo', 'favicon', 'icon', 'banner', 'promotion', 'badge', 'placeholder', 'no-photo', 'nophoto', 'sprite', '.svg', 'data:image'];
            var images = [];
            var seenImg = new Set();
            function addImg(src) {
                if (!src) return;
                try {
                    var full = new URL(src, window.location.href).href;
                    var low = full.toLowerCase();
                    if (!(low.startsWith('http://') || low.startsWith('https://'))) return;
                    for (var idx = 0; idx < badParts.length; idx++) {
                        if (low.indexOf(badParts[idx]) !== -1) return;
                    }
                    var canon = low.split('?')[0].split('#')[0].replace(/@\d+w_\d+h.*$/, '');
                    if (!seenImg.has(canon)) {
                        seenImg.add(canon);
                        images.push(full);
                    }
                } catch (e) {}
            }

            Array.from(document.images || []).forEach(function(im) {
                if (im.naturalWidth >= 200 && im.naturalHeight >= 200) {
                    addImg(im.currentSrc || im.src);
                }
            });
            ldImages.forEach(addImg);
            var ogImg = document.querySelector("meta[property='og:image']");
            if (ogImg && ogImg.content) addImg(ogImg.content);
            document.querySelectorAll('img').forEach(function(im) {
                addImg(im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('src'));
            });

            return JSON.stringify({
                url: url,
                title: title,
                price: price,
                minOrder: '',
                seller: seller,
                category: category,
                rawDescription: rawDescription,
                specs: specs,
                images: images
            });
        })();
    """

    fun decodeJsStringResult(rawResult: String?): String? {
        if (rawResult.isNullOrBlank() || rawResult == "null") return null
        return runCatching {
            val tokener = JSONTokener(rawResult)
            val value = tokener.nextValue()
            value?.toString()
        }.getOrNull()
    }

    fun parseCatalogLinks(rawJsResult: String?): List<String> {
        val jsonStr = decodeJsStringResult(rawJsResult) ?: return emptyList()
        val result = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val u = arr.optString(i, "")
                if (u.contains("/item/")) result.add(ProductDbHelper.cleanUrl(u))
            }
        }
        return result.distinct()
    }

    fun parseExtractedProduct(rawJsResult: String?): Product? {
        val jsonStr = decodeJsStringResult(rawJsResult) ?: return null
        return runCatching {
            val obj = JSONObject(jsonStr)
            val url = ProductDbHelper.cleanUrl(obj.optString("url", ""))
            if (url.isBlank()) return null

            val specs = linkedMapOf<String, String>()
            val specsObj = obj.optJSONObject("specs")
            if (specsObj != null) {
                val keys = specsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    specs[k] = specsObj.optString(k, "")
                }
            }

            val imgs = mutableListOf<String>()
            val imgArr = obj.optJSONArray("images")
            if (imgArr != null) {
                for (i in 0 until imgArr.length()) {
                    val s = imgArr.optString(i, "")
                    if (s.isNotBlank()) imgs.add(s)
                }
            }

            val priceVal = if (obj.isNull("price")) null else obj.optDouble("price", -1.0).takeIf { it > 0.0 }

            Product(
                id = extractProductId(url),
                url = url,
                title = obj.optString("title", "Товар").ifBlank { "Товар" },
                rawDescription = obj.optString("rawDescription", ""),
                specs = specs,
                wholesalePrice = priceVal,
                minOrder = "",
                seller = obj.optString("seller", ""),
                category = obj.optString("category", ""),
                imageUrls = imgs
            )
        }.getOrNull()
    }

    fun extractProductId(url: String): String {
        val match = Regex("wvp-\\d+", RegexOption.IGNORE_CASE).find(url)
        if (match != null) return match.value.lowercase()
        val tail = url.trimEnd('/').substringAfterLast('/')
        if (tail.isNotBlank() && tail.length <= 48) {
            return tail.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        }
        val md = MessageDigest.getInstance("SHA-1").digest(url.toByteArray(Charsets.UTF_8))
        return md.take(8).joinToString("") { "%02x".format(it) }
    }
}
