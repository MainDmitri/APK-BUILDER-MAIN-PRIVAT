package com.maindmitri.wikkeoposter.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ImageDownloader {

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    // Images with Hamming distance <= 6 on 64-bit dHash are visually identical (e.g. resized/recompressed copies)
    private const val DUPLICATE_HAMMING_THRESHOLD = 6

    private data class DecodedCandidate(
        val order: Int,
        val bytes: ByteArray,
        val width: Int,
        val height: Int,
        val dHash: Long
    )

    /**
     * Downloads up to [maxPhotos] unique, high-resolution product images concurrently.
     * Deduplicates both by canonical URL and visually via 64-bit perceptual dHash.
     */
    suspend fun downloadProductImages(
        imageUrls: List<String>,
        refererUrl: String,
        targetDir: File,
        maxPhotos: Int
    ): List<String> = withContext(Dispatchers.IO) {
        if (!targetDir.exists()) targetDir.mkdirs()

        // Clean any old saved photos in this product folder before re-saving
        targetDir.listFiles()?.forEach { f ->
            if (f.isFile && f.name.startsWith("photo_") && f.name.endsWith(".jpg")) {
                runCatching { f.delete() }
            }
        }

        // Deduplicate URLs by canonical path (ignoring resize query params)
        val canonicalSeen = linkedSetOf<String>()
        val candidates = mutableListOf<String>()
        for (rawUrl in imageUrls) {
            val key = canonicalImageKey(rawUrl)
            if (canonicalSeen.add(key)) {
                candidates.add(rawUrl)
            }
            if (candidates.size >= (maxPhotos + 8).coerceAtMost(24)) break
        }

        val downloaded: List<DecodedCandidate?> = coroutineScope {
            candidates.mapIndexed { idx, rawUrl ->
                async(Dispatchers.IO) {
                    val bytes = fetchBytes(rawUrl, refererUrl) ?: return@async null
                    if (bytes.size < 4096) return@async null
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return@async null
                    try {
                        if (bmp.width < 200 || bmp.height < 200) return@async null
                        val hash = computeDHash(bmp)
                        DecodedCandidate(
                            order = idx,
                            bytes = bytes,
                            width = bmp.width,
                            height = bmp.height,
                            dHash = hash
                        )
                    } finally {
                        bmp.recycle()
                    }
                }
            }.awaitAll()
        }

        // Prefer highest resolution when two candidates are visually identical, then restore original order
        val byResolutionDesc = downloaded.filterNotNull()
            .sortedByDescending { it.width.toLong() * it.height.toLong() }

        val unique = mutableListOf<DecodedCandidate>()
        for (cand in byResolutionDesc) {
            val isDuplicate = unique.any { existing ->
                hammingDistance(existing.dHash, cand.dHash) <= DUPLICATE_HAMMING_THRESHOLD
            }
            if (!isDuplicate) {
                unique.add(cand)
            }
        }

        val selected = unique.sortedBy { it.order }.take(maxPhotos)
        val saved = mutableListOf<String>()

        selected.forEachIndexed { idx, cand ->
            val bmp = BitmapFactory.decodeByteArray(cand.bytes, 0, cand.bytes.size) ?: return@forEachIndexed
            try {
                val outFile = File(targetDir, "photo_%02d.jpg".format(idx + 1))
                FileOutputStream(outFile).use { fos ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 88, fos)
                }
                saved.add(outFile.absolutePath)
            } finally {
                bmp.recycle()
            }
        }
        saved
    }

    private fun canonicalImageKey(url: String): String {
        val noQuery = url.substringBefore("?").substringBefore("#").trim().lowercase()
        // Normalize common CDN resize suffixes like @380w_285h.jpg or _300x300.jpg
        return noQuery
            .replace(Regex("@\\d+w_\\d+h.*$"), "")
            .replace(Regex("_\\d+x\\d+(?=\\.[a-z]+$)"), "")
    }

    /**
     * 64-bit difference hash (dHash): scales bitmap to 9x8 grayscale and compares adjacent horizontal pixels.
     */
    private fun computeDHash(bitmap: Bitmap): Long {
        val scaled = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        var hash = 0L
        var bit = 0
        try {
            for (y in 0 until 8) {
                var prevLuma = luma(scaled.getPixel(0, y))
                for (x in 1 until 9) {
                    val curLuma = luma(scaled.getPixel(x, y))
                    if (curLuma > prevLuma) {
                        hash = hash or (1L shl bit)
                    }
                    prevLuma = curLuma
                    bit++
                }
            }
        } finally {
            if (scaled !== bitmap) scaled.recycle()
        }
        return hash
    }

    private fun luma(pixel: Int): Int {
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    private fun hammingDistance(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    private fun fetchBytes(rawUrl: String, referer: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(rawUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 10_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Referer", referer)
                setRequestProperty("Accept", "image/webp,image/apng,image/*,*/*;q=0.8")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.use { it.readBytes() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
