package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AiProvider
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

data class AiResult(
    val success: Boolean,
    val postHtml: String,
    val error: String = ""
)

object AiClient {

    private const val TELEGRAM_CAPTION_LIMIT = 1024

    private fun buildSystemPrompt(styleHint: String): String = buildString {
        appendLine("Ты — профессиональный копирайтер для Telegram-магазина.")
        appendLine("Напиши красивое, живое и аккуратное описание товара на русском языке для покупателей.")
        appendLine("Правила:")
        appendLine("1. Используй только Telegram HTML-теги <b>...</b> и <i>...</i>. Никакого Markdown (** или #).")
        appendLine("2. Структура: яркий заголовок с 1 подходящим эмодзи в <b>...</b>, 1–2 коротких привлекательных предложения о товаре, и 3–4 кратких пункта с маркером • (цвета/варианты, особенности, кому подойдёт).")
        appendLine("3. Длина текста строго до 580 символов (чтобы ниже поместились цена и контакт).")
        appendLine("4. Цену, контакты, артикулы WVP, название магазина-поставщика, остатки на складе и доставку Виккео НЕ пиши.")
        appendLine("5. Полностью игнорируй любой технический мусор сайта (например, 'Item 1 of 4', 'Безопасная сделка', 'Укажите город', 'Продано 0 шт').")
        appendLine("6. Строго ЗАПРЕЩЕНО использовать слово «Условия».")
        appendLine("7. Хештеги сам не пиши — приложение добавит единые навигационные хештеги внизу поста.")
        if (styleHint.isNotBlank()) {
            appendLine("Пожелания по стилю: $styleHint")
        }
    }

    private fun candidateBaseUrls(provider: AiProvider, configuredBaseUrl: String): List<String> {
        val primary = configuredBaseUrl.trim().trimEnd('/')
        if (provider == AiProvider.OPENROUTER) {
            return listOf("https://openrouter.ai/api/v1")
        }
        val list = linkedSetOf<String>()
        if (primary.isNotBlank()) {
            list.add(primary)
            if (!primary.endsWith("/v1")) list.add("$primary/v1")
        }
        list.add("https://rusapix.ru/v1")
        list.add("https://api.rusapix.ru/v1")
        return list.toList()
    }

    suspend fun fetchAvailableModels(
        provider: AiProvider,
        apiKeyRaw: String,
        baseUrl: String
    ): Pair<List<String>, String> = withContext(Dispatchers.IO) {
        val apiKey = AppSettings.normalizeApiKey(apiKeyRaw)
        if (apiKey.isBlank()) return@withContext emptyList<String>() to "Сначала укажи API-ключ"

        var lastError = "Не удалось получить список моделей"
        for (base in candidateBaseUrls(provider, baseUrl)) {
            val (ok, bodyOrErr) = httpGet("$base/models", apiKey, provider)
            if (ok) {
                val models = runCatching {
                    val data = JSONObject(bodyOrErr).optJSONArray("data") ?: JSONArray()
                    val out = mutableListOf<String>()
                    for (i in 0 until data.length()) {
                        val id = data.getJSONObject(i).optString("id", "").trim()
                        if (id.isNotBlank()) out.add(id)
                    }
                    out.sorted()
                }.getOrDefault(emptyList())
                if (models.isNotEmpty()) {
                    return@withContext models to "Загружено моделей: ${models.size} ($base)"
                }
            } else {
                lastError = bodyOrErr
            }
        }
        emptyList<String>() to lastError
    }

    suspend fun testConnection(
        provider: AiProvider,
        apiKeyRaw: String,
        baseUrl: String,
        model: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val apiKey = AppSettings.normalizeApiKey(apiKeyRaw)
        if (apiKey.isBlank()) return@withContext false to "Укажи API-ключ для ${provider.title}"
        val cleanModel = model.trim().ifEmpty { provider.defaultModel }
        val (ok, msg) = callChatCompletions(
            provider = provider,
            apiKey = apiKey,
            baseUrl = baseUrl,
            model = cleanModel,
            systemPrompt = "Ответь одним словом: OK",
            userPrompt = "Проверка связи"
        )
        if (ok) true to "${provider.title} ($cleanModel) отвечает нормально!"
        else false to msg
    }

    /**
     * Rewrites an already-published Telegram channel post (even if not in local SQLite):
     * preserves its existing price, strips Wikkeo UI noise & "Условия", improves copy via AI,
     * and appends standardized navigation hashtags.
     */
    suspend fun rewriteExistingChannelPost(oldPostText: String, settings: AppSettings): AiResult =
        withContext(Dispatchers.IO) {
            val cleaned = stripMarketplaceNoise(oldPostText)
            val firstLine = oldPostText.lines()
                .map { it.trim() }
                .firstOrNull { it.length >= 3 && !it.startsWith("💰") && !it.startsWith("📩") && !it.startsWith("#") }
                .orEmpty()
                .replace(Regex("^[🔥✨🛍🎧👟🧥⌚️📱💡📦]+\\s*"), "")
                .take(80)
                .ifBlank { "Товар" }

            // Try to preserve existing ruble price from the channel post
            val priceMatch = Regex("(?:Цена\\s*:?\\s*)?(\\d[\\d\\s]{1,10})\\s*₽", RegexOption.IGNORE_CASE).find(oldPostText)
            val existingPrice = priceMatch?.groupValues?.get(1)?.replace(Regex("\\s+"), "")?.toIntOrNull()

            val pseudoProduct = Product(
                id = "channel_post",
                url = "",
                title = firstLine,
                rawDescription = cleaned,
                wholesalePrice = existingPrice?.toDouble(),
                finalPrice = existingPrice
            )
            generateTelegramPost(pseudoProduct, settings)
        }

    suspend fun generateTelegramPost(product: Product, settings: AppSettings): AiResult =
        withContext(Dispatchers.IO) {
            val apiKey = settings.activeApiKey()
            if (apiKey.isBlank()) {
                val fallback = assembleTelegramPost(buildFallbackBody(product), product, settings)
                return@withContext AiResult(
                    success = true,
                    postHtml = fallback,
                    error = "API-ключ ${settings.aiProvider.title} не задан — использован шаблон"
                )
            }

            val specsBlock = product.specs.entries.take(10)
                .joinToString("\n") { "- ${it.key}: ${it.value}" }
                .ifBlank { "не указаны" }

            val cleanRaw = stripMarketplaceNoise(product.rawDescription)
            val userPrompt = buildString {
                appendLine("Название товара: ${product.title}")
                if (product.category.isNotBlank()) appendLine("Категория: ${product.category}")
                appendLine("Описание от поставщика:")
                appendLine(
                    cleanRaw.take(1200).ifBlank {
                        "нет подробного описания — составь аккуратное описание по названию и вариантам"
                    }
                )
                appendLine()
                appendLine("Характеристики и варианты:")
                appendLine(specsBlock)
            }

            val (ok, textOrError) = callChatCompletions(
                provider = settings.aiProvider,
                apiKey = apiKey,
                baseUrl = settings.activeBaseUrl(),
                model = settings.activeModel(),
                systemPrompt = buildSystemPrompt(settings.customStyleHint),
                userPrompt = userPrompt
            )

            if (ok) {
                val post = assembleTelegramPost(textOrError, product, settings)
                AiResult(success = true, postHtml = post)
            } else {
                val fallback = assembleTelegramPost(buildFallbackBody(product), product, settings)
                AiResult(success = false, postHtml = fallback, error = textOrError)
            }
        }

    private fun callChatCompletions(
        provider: AiProvider,
        apiKey: String,
        baseUrl: String,
        model: String,
        systemPrompt: String,
        userPrompt: String
    ): Pair<Boolean, String> {
        val payload = JSONObject().apply {
            put("model", model)
            put("temperature", 0.7)
            put("max_tokens", 900)
            put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", systemPrompt))
                    .put(JSONObject().put("role", "user").put("content", userPrompt))
            )
        }.toString()

        var lastError = "Не удалось подключиться к ${provider.title}"
        for (base in candidateBaseUrls(provider, baseUrl)) {
            val endpoint = "$base/chat/completions"
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 40_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    if (provider == AiProvider.OPENROUTER) {
                        setRequestProperty("HTTP-Referer", "https://wikkeo.com")
                        setRequestProperty("X-Title", "Wikkeo Poster")
                    }
                }
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()

                if (code == 404) {
                    lastError = "HTTP 404 на $endpoint"
                    continue
                }
                if (code == 429 || code in 500..599) {
                    lastError = "Ошибка ${provider.title}: HTTP $code"
                    runCatching { Thread.sleep(1500) }
                    continue
                }
                if (code !in 200..299) {
                    val errMsg = runCatching {
                        val j = JSONObject(body)
                        j.optJSONObject("error")?.optString("message")
                            ?: j.optString("message")
                    }.getOrNull().orEmpty().ifBlank { "HTTP $code" }
                    return false to "Ошибка ${provider.title}: $errMsg"
                }

                val root = JSONObject(body)
                val choices = root.optJSONArray("choices")
                if (choices == null || choices.length() == 0) {
                    return false to "${provider.title} вернул пустой ответ"
                }
                val content = choices.getJSONObject(0)
                    .optJSONObject("message")
                    ?.optString("content", "")
                    .orEmpty()
                    .trim()
                if (content.isBlank()) {
                    return false to "Пустой текст в ответе ${provider.title}"
                }
                return true to content
            } catch (e: Exception) {
                lastError = "Сетевая ошибка (${provider.title}): ${e.message ?: "неизвестно"}"
            } finally {
                conn?.disconnect()
            }
        }
        return false to lastError
    }

    private fun httpGet(
        urlStr: String,
        apiKey: String,
        provider: AiProvider
    ): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12_000
                readTimeout = 20_000
                setRequestProperty("Authorization", "Bearer $apiKey")
                if (provider == AiProvider.OPENROUTER) {
                    setRequestProperty("HTTP-Referer", "https://wikkeo.com")
                    setRequestProperty("X-Title", "Wikkeo Poster")
                }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
            if (code in 200..299) true to body else false to "HTTP $code"
        } catch (e: Exception) {
            false to (e.message ?: "Сетевая ошибка")
        } finally {
            conn?.disconnect()
        }
    }

    fun stripMarketplaceNoise(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace(Regex("Item\\s+\\d+\\s+of\\s+\\d+", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\b\\d+/\\d+\\b"), " ")
            .replace(Regex("\\(WVP-\\d+\\)", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("Продано\\s+\\d+\\s*шт\\.?", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("Осталось\\s+\\d+\\s*шт\\.?", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("Виккео\\s+Доставка", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("Укажите город в профиле.*", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("Безопасная сделка.*", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("условия\\s*:?", RegexOption.IGNORE_CASE), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun formatRub(amount: Number?): String {
        if (amount == null) return "по запросу"
        val rounded = amount.toDouble().roundToInt()
        val s = rounded.toString()
        val grouped = s.reversed().chunked(3).joinToString(" ").reversed()
        return "$grouped ₽"
    }

    fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    fun sanitizeTelegramHtml(raw: String): String {
        var text = raw.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>")
        text = text.lines()
            .filterNot { it.contains("условия", ignoreCase = true) }
            .joinToString("\n")
        val allowed = setOf("b", "i", "u", "s", "code")
        text = text.replace(Regex("</?([a-zA-Z0-9]+)(?:\\s+[^>]*)?>")) { m ->
            val tag = m.groupValues[1].lowercase()
            if (tag in allowed) {
                val closing = m.value.startsWith("</")
                if (closing) "</$tag>" else "<$tag>"
            } else {
                ""
            }
        }
        for (tag in allowed) {
            val opens = Regex("<$tag>").findAll(text).count()
            val closes = Regex("</$tag>").findAll(text).count()
            if (opens > closes) {
                text += "</$tag>".repeat(opens - closes)
            } else if (closes > opens) {
                var diff = closes - opens
                while (diff > 0) {
                    text = text.replaceFirst("</$tag>", "")
                    diff--
                }
            }
        }
        return text.trim()
    }

    fun buildFallbackBody(product: Product): String = buildString {
        appendLine("🔥 <b>${escapeHtml(product.title)}</b>")
        val clean = stripMarketplaceNoise(product.rawDescription)
        if (clean.length >= 15) {
            appendLine()
            val clipped = if (clean.length > 340) clean.take(337).substringBeforeLast(" ") + "..." else clean
            appendLine(escapeHtml(clipped))
        }
        if (product.specs.isNotEmpty()) {
            appendLine()
            product.specs.entries
                .filterNot { it.key.contains("условия", ignoreCase = true) }
                .take(5)
                .forEach { (k, v) ->
                    appendLine("• <b>${escapeHtml(k)}:</b> ${escapeHtml(v)}")
                }
        }
    }.trim()

    fun generateHashtags(product: Product, extraHashtags: String = ""): String {
        val text = "${product.title} ${product.category} ${product.rawDescription}".lowercase()
        val tags = linkedSetOf<String>()

        // 1. Audience / Gender
        val isMen = Regex("мужск|мужчин|парн|для него|барсетк").containsMatchIn(text)
        val isWomen = Regex("женск|женщин|девуш|для неё|для нее|плать|юбк|туфл|косметик|помад|тушь|серьг|кольц|угг|ugг").containsMatchIn(text)
        val isKids = Regex("детск|ребен|ребён|малыш|игруш|пистолет|машинк|конструктор|школьн|подростк|сквиш|антистресс").containsMatchIn(text)

        if (isMen) tags.add("#мужское")
        if (isWomen) tags.add("#женское")
        if (isKids) tags.add("#детское")

        // 2. Category & Item Type
        val fashionHits = mutableListOf<String>()
        if (Regex("куртк|пуховик|ветровк|анорак|пальто|жилет").containsMatchIn(text)) {
            tags.add("#куртки"); tags.add("#одежда"); fashionHits.add("1")
        }
        if (Regex("свитер|кофт|худи|толстовк|футболк|рубашк|брюк|джинс|костюм|одежд|штаны|шорт|плать|балаклав|шапк|кепк").containsMatchIn(text)) {
            tags.add("#одежда"); fashionHits.add("1")
        }
        if (Regex("кроссовк|кед|nike|n1ke|adidas|ad1das|jordan|new balance|n1w balance|asics|as1cs|reebok|re1bok|dunk|force").containsMatchIn(text)) {
            tags.add("#кроссовки"); tags.add("#обувь"); fashionHits.add("1")
        }
        if (Regex("ботинк|сапог|обув|угг|ugг|туфл|лофер|тапк|сланц").containsMatchIn(text)) {
            tags.add("#обувь"); fashionHits.add("1")
        }
        if (Regex("сумк|рюкзак|кошелек|кошелёк|клатч|портфел|чемодан").containsMatchIn(text)) {
            tags.add("#сумки"); tags.add("#аксессуары"); fashionHits.add("1")
        }
        if (Regex("час[ыо]|watch|garmin|garm1n|rolex|браслет|whoop|wh00p").containsMatchIn(text)) {
            tags.add("#часы"); tags.add("#аксессуары"); fashionHits.add("1")
        }
        if (Regex("наушник|airpods|a1rp0ds|pods|гарнитур|xm6|anc").containsMatchIn(text)) {
            tags.add("#наушники"); tags.add("#электроника")
        }
        if (Regex("телефон|iphone|1ph0ne|samsung|xiaomi|x1aomi|poco|redmi|ноутбук|планшет|повербанк|зарядк|геймпад|ps5|джойстик|колонк|фен|dyson").containsMatchIn(text)) {
            tags.add("#гаджеты"); tags.add("#электроника")
        }
        if (Regex("духи|парфюм|аромат|туалетн|маслян").containsMatchIn(text)) {
            tags.add("#парфюм"); fashionHits.add("1")
        }
        if (Regex("крем|косметик|маск[аи]|помад|сыворотк|шампун").containsMatchIn(text)) {
            tags.add("#косметика")
        }
        if (Regex("игруш|машинк|сквиш|антистресс|пистолет|конструктор|пианино|кукл").containsMatchIn(text)) {
            tags.add("#игрушки")
        }
        if (Regex("авто|двигател|гранта|ваз|лада|компрессор|регистратор|бардачок|фар[аы]").containsMatchIn(text)) {
            tags.add("#автотовары")
        }
        if (Regex("дом|кухн|фонарь|посуд|светильник|ламп|плед|подушк|декор|новогодн").containsMatchIn(text)) {
            tags.add("#длядома")
        }
        if (Regex("спорт|фитнес|трениров|бег|гантел").containsMatchIn(text)) {
            tags.add("#спорт")
        }
        if (Regex("инструмент|шуруповерт|дрель|набор ключ").containsMatchIn(text)) {
            tags.add("#инструменты")
        }

        // 3. Unisex fallback for fashion items without explicit gender
        if (!isMen && !isWomen && !isKids && fashionHits.isNotEmpty()) {
            tags.add("#унисекс")
        }

        // 4. Style / Season tags
        if (fashionHits.isNotEmpty() || Regex("бренд|стиль|тренд|хит|модн|люкс|премиум|premium").containsMatchIn(text)) {
            tags.add("#модное")
        }
        if (Regex("зим|термо|мех|утеплен|утеплён|пуховик|угг|ugг").containsMatchIn(text)) {
            tags.add("#зима")
        }
        if (Regex("тренд|хит|тик-ток|tiktok").containsMatchIn(text)) {
            tags.add("#тренд")
        }

        // 5. User extra hashtags from Settings
        extraHashtags.split(Regex("\\s|[,;]+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .forEach { raw ->
                val clean = raw.removePrefix("#").replace(Regex("[^a-zA-Zа-яА-ЯёЁ0-9_]"), "")
                if (clean.isNotBlank()) tags.add("#${clean.lowercase()}")
            }

        if (tags.isEmpty()) {
            tags.add("#новинка")
            tags.add("#модное")
        }
        return tags.take(6).joinToString(" ")
    }

    fun assembleTelegramPost(bodyHtml: String, product: Product, settings: AppSettings): String {
        val priceNum: Number? = product.finalPrice ?: product.wholesalePrice
        val footerLines = mutableListOf<String>()
        footerLines.add("💰 <b>Цена:</b> ${formatRub(priceNum)}")
        if (settings.orderContact.isNotBlank()) {
            footerLines.add("📩 <b>Для заказа:</b> ${escapeHtml(settings.orderContact)}")
        }
        val hashtagsLine = generateHashtags(product, settings.extraHashtags)
        if (hashtagsLine.isNotBlank()) {
            footerLines.add("")
            footerLines.add(hashtagsLine)
        }


        val footer = footerLines.joinToString("\n")
        var cleanBody = sanitizeTelegramHtml(bodyHtml)
        val maxBodyLen = (TELEGRAM_CAPTION_LIMIT - footer.length - 4).coerceAtLeast(80)
        if (cleanBody.length > maxBodyLen) {
            val plain = cleanBody.replace(Regex("<[^>]+>"), "")
            val clipped = plain.take((maxBodyLen - 3).coerceAtLeast(50)).substringBeforeLast(" ") + "..."
            cleanBody = escapeHtml(clipped)
        }
        return "$cleanBody\n\n$footer".trim()
    }
}
