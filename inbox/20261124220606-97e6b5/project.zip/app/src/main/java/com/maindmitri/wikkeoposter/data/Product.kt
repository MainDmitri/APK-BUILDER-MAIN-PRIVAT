package com.maindmitri.wikkeoposter.data

import org.json.JSONArray
import org.json.JSONObject

enum class ProductStatus(val code: String, val labelRu: String) {
    DRAFT("draft", "Черновик"),
    PUBLISHED("published", "Опубликовано"),
    ERROR("error", "Ошибка");

    companion object {
        fun fromCode(code: String?): ProductStatus =
            entries.firstOrNull { it.code == code } ?: DRAFT
    }
}

data class Product(
    val id: String,
    val url: String,
    val title: String,
    val rawDescription: String = "",
    val specs: Map<String, String> = emptyMap(),
    val wholesalePrice: Double? = null,
    val finalPrice: Int? = null,
    val minOrder: String = "",
    val seller: String = "",
    val category: String = "",
    val imageUrls: List<String> = emptyList(),
    val localImages: List<String> = emptyList(),
    val generatedPost: String = "",
    val status: ProductStatus = ProductStatus.DRAFT,
    val telegramMessageId: Long? = null,
    val vkPostId: Long? = null,
    val maxMessageId: String? = null,
    val lastError: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val publishedAt: Long? = null
) {
    fun toJson(): String {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("url", url)
        obj.put("title", title)
        obj.put("rawDescription", rawDescription)
        val specsObj = JSONObject()
        specs.forEach { (k, v) -> specsObj.put(k, v) }
        obj.put("specs", specsObj)
        obj.put("wholesalePrice", wholesalePrice ?: JSONObject.NULL)
        obj.put("finalPrice", finalPrice ?: JSONObject.NULL)
        obj.put("minOrder", minOrder)
        obj.put("seller", seller)
        obj.put("category", category)
        obj.put("imageUrls", JSONArray(imageUrls))
        obj.put("localImages", JSONArray(localImages))
        obj.put("generatedPost", generatedPost)
        obj.put("status", status.code)
        obj.put("telegramMessageId", telegramMessageId ?: JSONObject.NULL)
        obj.put("vkPostId", vkPostId ?: JSONObject.NULL)
        obj.put("maxMessageId", maxMessageId ?: JSONObject.NULL)
        obj.put("lastError", lastError)
        obj.put("createdAt", createdAt)
        obj.put("publishedAt", publishedAt ?: JSONObject.NULL)
        return obj.toString(2)
    }
}
