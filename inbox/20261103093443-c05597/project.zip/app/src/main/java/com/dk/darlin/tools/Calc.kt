package com.dk.darlin.tools

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

/** Калькулятор выражений: + − × ÷ ^ %, скобки, !, функции (sqrt, sin в градусах, ln, log…), константы pi и e. */
object Calc {
    class CalcException(msg: String) : Exception(msg)

    fun eval(expr: String): Double = Parser(normalize(expr)).parseAll()

    /** Красивое число для озвучки: без экспоненты, до 10 значащих знаков, запятая как разделитель. */
    fun format(v: Double): String {
        if (v.isNaN()) return "не определено"
        if (v.isInfinite()) return if (v > 0) "бесконечность" else "минус бесконечность"
        if (v == 0.0) return "0"
        val abs = Math.abs(v)
        if (abs >= 1e15 || abs < 1e-9) return String.format(java.util.Locale.US, "%.6e", v).replace('.', ',')
        val bd = BigDecimal(v).round(MathContext(12, RoundingMode.HALF_EVEN)).stripTrailingZeros()
        var s = bd.toPlainString()
        if (s.contains('.')) {
            val (ip, fp) = s.split('.')
            s = ip + "," + fp.take(10).trimEnd('0')
            if (s.endsWith(",")) s = s.dropLast(1)
        }
        return s
    }

    fun normalize(e: String): String {
        var s = " " + e.lowercase().trim() + " "
        val words = listOf(
            "умножить на" to "*", "умноженное на" to "*", "разделить на" to "/", "делённое на" to "/", "деленное на" to "/",
            "в степени" to "^", "плюс" to "+", "минус" to "-", "корень из" to "sqrt ", "квадратный корень из" to "sqrt ",
            "пи" to "pi", "по модулю" to "mod", "остаток от деления на" to "mod", "процентов" to "%", "процента" to "%", "процент" to "%"
        )
        for ((a, b) in words) s = s.replace(Regex("(?<=\\s|^)" + Regex.escape(a) + "(?=\\s|$)"), b)
        s = s.replace('×', '*').replace('·', '*').replace('÷', '/').replace('−', '-').replace('–', '-').replace("**", "^")
            .replace("π", " pi ").replace("√", " sqrt ").replace("²", "^2").replace("³", "^3")
        // десятичная запятая между цифрами, пробелы-разделители тысяч
        s = s.replace(Regex("(\\d),(\\d)"), "$1.$2").replace(Regex("(\\d)\\s+(?=\\d{3}(\\D|$))"), "$1")
        return s.trim()
    }

    private class Parser(val s: String) {
        var p = 0
        fun parseAll(): Double {
            val v = expr()
            skip()
            if (p < s.length) throw CalcException("Непонятный символ «${s[p]}»")
            return v
        }
        fun skip() { while (p < s.length && s[p].isWhitespace()) p++ }
        fun peek(): Char? { skip(); return s.getOrNull(p) }
        fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { p++; val r = termOrPercent(v); v += r }
                    '-' -> { p++; val r = termOrPercent(v); v -= r }
                    else -> return v
                }
            }
        }
        /** «200 + 10%» = 220: процент справа от + и − берётся от левой части. */
        fun termOrPercent(left: Double): Double {
            val save = p
            val t = unaryPow()
            if (peek() == '%') {
                val after = p + 1
                var q = after; while (q < s.length && s[q].isWhitespace()) q++
                if (q >= s.length || s[q] == ')' || s[q] == '+' || s[q] == '-') { p = after; return left * t / 100 }
            }
            p = save
            return term()
        }
        fun term(): Double {
            var v = unaryPow()
            while (true) {
                val c = peek()
                when {
                    c == '*' -> { p++; v *= unaryPow() }
                    c == '/' -> { p++; val d = unaryPow(); if (d == 0.0) throw CalcException("Деление на ноль"); v /= d }
                    c == ':' -> { p++; val d = unaryPow(); if (d == 0.0) throw CalcException("Деление на ноль"); v /= d }
                    c == '%' -> {
                        p++
                        // «x % от y» или просто «x%»
                        skip()
                        if (s.startsWith("от", p)) { p += 2; v = v / 100 * unaryPow() }
                        else if (s.startsWith("mod", p)) { p += 3; v %= unaryPow() }
                        else v /= 100
                    }
                    c == 'm' && s.startsWith("mod", p) && s.getOrNull(p + 3)?.isLetter() != true -> {
                        p += 3; val d = unaryPow(); if (d == 0.0) throw CalcException("Деление на ноль"); v %= d
                    }
                    c == '(' || (c != null && c.isLetter()) -> v *= unaryPow() // неявное умножение: 2pi, 3(4+1)
                    else -> return v
                }
            }
        }
        fun unaryPow(): Double {
            val c = peek()
            if (c == '-') { p++; return -unaryPow() }
            if (c == '+') { p++; return unaryPow() }
            val base = postfix()
            if (peek() == '^') { p++; return base.pow(unaryPow()) }
            return base
        }
        fun postfix(): Double {
            var v = primary()
            while (peek() == '!') {
                p++
                if (v < 0 || v != floor(v) || v > 170) throw CalcException("Факториал только для целых от 0 до 170")
                var r = 1.0; for (i in 2..v.toInt()) r *= i; v = r
            }
            return v
        }
        fun primary(): Double {
            val c = peek() ?: throw CalcException("Выражение оборвалось")
            if (c == '(') {
                p++; val v = expr()
                if (peek() != ')') throw CalcException("Не хватает закрывающей скобки")
                p++; return v
            }
            if (c.isDigit() || c == '.') {
                val st = p
                while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
                if (p < s.length && (s[p] == 'e') && p + 1 < s.length && (s[p + 1].isDigit() || s[p + 1] == '-' || s[p + 1] == '+')) {
                    p += 2; while (p < s.length && s[p].isDigit()) p++
                }
                return s.substring(st, p).toDoubleOrNull() ?: throw CalcException("Неверное число")
            }
            if (c.isLetter()) {
                val st = p
                while (p < s.length && (s[p].isLetterOrDigit() || s[p] == '_')) p++
                val name = s.substring(st, p)
                when (name) { "pi" -> return PI; "e" -> return E; "tau" -> return 2 * PI }
                val arg = if (peek() == '(') { p++; val v = expr(); if (peek() == ',') { p++; val b = expr(); if (peek() != ')') throw CalcException("Нет «)»"); p++; return fn2(name, v, b) }; if (peek() != ')') throw CalcException("Нет «)»"); p++; v } else unaryPow()
                return fn(name, arg)
            }
            throw CalcException("Непонятный символ «$c»")
        }
        fun rad(d: Double) = Math.toRadians(d)
        fun fn(n: String, x: Double): Double = when (n) {
            "sqrt", "корень" -> { if (x < 0) throw CalcException("Корень из отрицательного числа"); sqrt(x) }
            "cbrt" -> cbrt(x)
            "abs", "модуль" -> abs(x)
            "sin" -> sin(rad(x)); "cos" -> cos(rad(x)); "tan", "tg" -> tan(rad(x)); "ctg", "cot" -> 1 / tan(rad(x))
            "asin", "arcsin" -> Math.toDegrees(asin(x)); "acos", "arccos" -> Math.toDegrees(acos(x)); "atan", "arctg", "arctan" -> Math.toDegrees(atan(x))
            "ln" -> { if (x <= 0) throw CalcException("Логарифм только от положительного числа"); ln(x) }
            "log", "lg", "log10" -> { if (x <= 0) throw CalcException("Логарифм только от положительного числа"); log10(x) }
            "log2" -> log2(x)
            "exp" -> exp(x)
            "round" -> Math.round(x).toDouble(); "floor" -> floor(x); "ceil" -> ceil(x)
            else -> throw CalcException("Неизвестная функция «$n»")
        }
        fun fn2(n: String, a: Double, b: Double): Double = when (n) {
            "log" -> ln(b) / ln(a)
            "pow" -> a.pow(b)
            "max" -> max(a, b); "min" -> min(a, b)
            "root" -> if (b == 0.0) throw CalcException("Корень нулевой степени") else a.pow(1 / b)
            "round" -> { val k = 10.0.pow(b); Math.round(a * k) / k }
            else -> throw CalcException("Неизвестная функция «$n»")
        }
    }
}

/** Перевод единиц измерения: длина, масса, объём, площадь, скорость, время, данные, энергия, давление, мощность, температура. */
object Units {
    private data class U(val cat: String, val factor: Double, val name: String)
    private val table = HashMap<String, U>()
    private fun add(cat: String, factor: Double, name: String, vararg aliases: String) {
        val u = U(cat, factor, name)
        for (a in aliases) table[a.lowercase()] = u
        table[name.lowercase()] = u
    }
    init {
        // длина, м
        add("длина", 0.001, "мм", "mm", "миллиметр", "миллиметров", "миллиметра", "миллиметры")
        add("длина", 0.01, "см", "cm", "сантиметр", "сантиметров", "сантиметра", "сантиметры")
        add("длина", 0.1, "дм", "dm", "дециметр", "дециметров")
        add("длина", 1.0, "м", "m", "метр", "метров", "метра", "метры")
        add("длина", 1000.0, "км", "km", "километр", "километров", "километра", "километры")
        add("длина", 0.0254, "дюйм", "in", "inch", "inches", "дюймов", "дюйма", "\"")
        add("длина", 0.3048, "фут", "ft", "foot", "feet", "футов", "фута")
        add("длина", 0.9144, "ярд", "yd", "yard", "yards", "ярдов", "ярда")
        add("длина", 1609.344, "миля", "mi", "mile", "miles", "миль", "мили")
        add("длина", 1852.0, "морская миля", "nmi", "морских миль", "морские мили")
        add("длина", 0.000001, "мкм", "µm", "um", "микрон", "микрометр")
        // масса, кг
        add("масса", 0.000001, "мг", "mg", "миллиграмм", "миллиграммов")
        add("масса", 0.001, "г", "g", "гр", "грамм", "граммов", "грамма")
        add("масса", 1.0, "кг", "kg", "килограмм", "килограммов", "килограмма", "кило")
        add("масса", 100.0, "ц", "центнер", "центнеров", "центнера")
        add("масса", 1000.0, "т", "t", "тонна", "тонн", "тонны", "тонну")
        add("масса", 0.45359237, "фунт", "lb", "lbs", "pound", "pounds", "фунтов", "фунта")
        add("масса", 0.028349523125, "унция", "oz", "ounce", "унций", "унции")
        add("масса", 0.0002, "карат", "ct", "карата", "каратов")
        // объём, л
        add("объём", 0.001, "мл", "ml", "миллилитр", "миллилитров", "миллилитра")
        add("объём", 1.0, "л", "l", "литр", "литров", "литра", "литры")
        add("объём", 1000.0, "м³", "m3", "м3", "кубометр", "кубометров", "кубический метр", "кубических метров")
        add("объём", 0.001, "см³", "cm3", "см3", "кубический сантиметр", "кубических сантиметров")
        add("объём", 3.785411784, "галлон", "gal", "gallon", "gallons", "галлонов", "галлона")
        add("объём", 0.946352946, "кварта", "qt", "quart")
        add("объём", 0.473176473, "пинта", "pt", "pint", "пинт", "пинты")
        add("объём", 0.2365882365, "чашка", "cup", "cups", "чашки", "чашек")
        add("объём", 0.0295735295625, "жидкая унция", "floz", "fl oz", "fl_oz")
        add("объём", 0.015, "ст. ложка", "tbsp", "столовая ложка", "столовых ложек", "столовые ложки")
        add("объём", 0.005, "ч. ложка", "tsp", "чайная ложка", "чайных ложек", "чайные ложки")
        add("объём", 158.987294928, "баррель", "bbl", "barrel", "баррелей", "барреля")
        // площадь, м²
        add("площадь", 0.0001, "см²", "cm2", "см2", "квадратный сантиметр", "квадратных сантиметров")
        add("площадь", 1.0, "м²", "m2", "м2", "кв м", "кв. м", "квадратный метр", "квадратных метров", "квадратных метра")
        add("площадь", 1e6, "км²", "km2", "км2", "квадратный километр", "квадратных километров")
        add("площадь", 100.0, "сотка", "сотки", "соток", "ар", "are")
        add("площадь", 10000.0, "га", "ha", "гектар", "гектаров", "гектара")
        add("площадь", 4046.8564224, "акр", "acre", "acres", "акров", "акра")
        add("площадь", 0.09290304, "фут²", "ft2", "sqft", "квадратный фут", "квадратных футов")
        // скорость, м/с
        add("скорость", 1.0, "м/с", "m/s", "mps", "метров в секунду", "метр в секунду")
        add("скорость", 1 / 3.6, "км/ч", "km/h", "kmh", "kph", "километров в час", "километр в час")
        add("скорость", 0.44704, "миль/ч", "mph", "миль в час", "миля в час")
        add("скорость", 0.514444444, "узел", "kn", "knot", "knots", "узлов", "узла")
        add("скорость", 343.0, "мах", "mach", "маха")
        // время, с
        add("время", 0.001, "мс", "ms", "миллисекунда", "миллисекунд", "миллисекунды")
        add("время", 1.0, "с", "s", "сек", "sec", "секунда", "секунд", "секунды", "секунду")
        add("время", 60.0, "мин", "min", "минута", "минут", "минуты", "минуту")
        add("время", 3600.0, "ч", "h", "hr", "час", "часов", "часа", "часы")
        add("время", 86400.0, "сут", "d", "day", "days", "день", "дней", "дня", "сутки", "суток")
        add("время", 604800.0, "нед", "week", "weeks", "неделя", "недель", "недели", "неделю")
        add("время", 2629746.0, "мес", "month", "months", "месяц", "месяцев", "месяца")
        add("время", 31556952.0, "год", "yr", "year", "years", "лет", "года", "годы")
        // данные, байт
        add("данные", 0.125, "бит", "bit", "bits", "битов", "бита")
        add("данные", 1.0, "байт", "b", "byte", "bytes", "байтов", "байта")
        add("данные", 1024.0, "КБ", "kb", "кб", "килобайт", "килобайта", "килобайтов", "kib")
        add("данные", 1024.0 * 1024, "МБ", "mb", "мб", "мегабайт", "мегабайта", "мегабайтов", "mib")
        add("данные", 1024.0 * 1024 * 1024, "ГБ", "gb", "гб", "гигабайт", "гигабайта", "гигабайтов", "gib")
        add("данные", 1024.0 * 1024 * 1024 * 1024, "ТБ", "tb", "тб", "терабайт", "терабайта", "терабайтов", "tib")
        add("данные", 125000.0, "Мбит", "mbit", "мбит", "мегабит", "мегабита", "мегабитов")
        add("данные", 1.25e8, "Гбит", "gbit", "гбит", "гигабит", "гигабита")
        // энергия, Дж
        add("энергия", 1.0, "Дж", "j", "дж", "джоуль", "джоулей", "джоуля")
        add("энергия", 1000.0, "кДж", "kj", "кдж", "килоджоуль", "килоджоулей")
        add("энергия", 4.184, "кал", "cal", "калория", "калорий", "калории")
        add("энергия", 4184.0, "ккал", "kcal", "килокалория", "килокалорий", "килокалории")
        add("энергия", 3.6e6, "кВт·ч", "kwh", "квтч", "квт*ч", "квт·ч", "киловатт-час", "киловатт-часов", "киловатт-часа")
        add("энергия", 3600.0, "Вт·ч", "wh", "втч", "ватт-час")
        // давление, Па
        add("давление", 1.0, "Па", "pa", "па", "паскаль", "паскалей")
        add("давление", 1000.0, "кПа", "kpa", "кпа", "килопаскаль", "килопаскалей")
        add("давление", 1e6, "МПа", "mpa", "мпа", "мегапаскаль")
        add("давление", 1e5, "бар", "bar", "бара", "баров")
        add("давление", 101325.0, "атм", "atm", "атмосфера", "атмосфер", "атмосферы")
        add("давление", 133.322387415, "мм рт. ст.", "mmhg", "мм рт ст", "ммртст", "миллиметров ртутного столба", "мм ртутного столба")
        add("давление", 6894.757293168, "psi", "фунт на кв дюйм")
        // мощность, Вт
        add("мощность", 1.0, "Вт", "w", "вт", "ватт", "ватта")
        add("мощность", 1000.0, "кВт", "kw", "квт", "киловатт", "киловатта")
        add("мощность", 735.49875, "л. с.", "hp", "лс", "л.с.", "лошадиная сила", "лошадиных сил", "лошадиные силы")
        // температура — отдельно
        for (a in listOf("c", "°c", "с", "°с", "цельсий", "цельсия", "градусов цельсия", "градус цельсия", "градусов")) table[a] = U("темп", 0.0, "°C")
        for (a in listOf("f", "°f", "фаренгейт", "фаренгейта", "градусов фаренгейта")) table[a] = U("темп", 1.0, "°F")
        for (a in listOf("k", "кельвин", "кельвина", "кельвинов")) table[a] = U("темп", 2.0, "K")
    }

    private fun find(raw: String): U? {
        val s = raw.lowercase().trim().replace("ё", "е").replace(Regex("\\s+"), " ")
        return table[s] ?: table[s.replace(" ", "")] ?: table[s.trimEnd('.')] ?: table[s.replace("²", "2").replace("³", "3")]
    }

    fun isKnown(unit: String) = find(unit) != null

    fun convert(value: Double, from: String, to: String): String {
        val a = find(from) ?: return "Не знаю единицу «$from»."
        val b = find(to) ?: return "Не знаю единицу «$to»."
        if (a.cat != b.cat) return "Нельзя перевести ${a.name} в ${b.name}: это разные величины (${a.cat} и ${b.cat})."
        val r = if (a.cat == "темп") {
            val c = when (a.name) { "°F" -> (value - 32) * 5 / 9; "K" -> value - 273.15; else -> value }
            when (b.name) { "°F" -> c * 9 / 5 + 32; "K" -> c + 273.15; else -> c }
        } else value * a.factor / b.factor
        return "${Calc.format(value)} ${a.name} = ${Calc.format(r)} ${b.name}"
    }
}
