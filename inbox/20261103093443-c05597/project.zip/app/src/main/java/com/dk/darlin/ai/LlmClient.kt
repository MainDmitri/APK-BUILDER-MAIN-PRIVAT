package com.dk.darlin.ai

import android.content.Context
import com.dk.darlin.core.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Клиент любого OpenAI-совместимого API (/chat/completions, /models). */
class LlmClient(private val ctx: Context) {
    companion object {
        @Volatile var streamSupported = true

        /** Картинка для vision-запроса (JPEG, не больше 1280 px по длинной стороне). */
        fun imagePart(bmp: android.graphics.Bitmap, maxSide: Int = 1280, quality: Int = 75): JSONObject {
            val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
            val b = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val bos = java.io.ByteArrayOutputStream()
            b.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, bos)
            val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
            return JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
        }
    }

    /** Разовый запрос без инструментов: системная инструкция + текст пользователя. */
    fun ask(system: String, user: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", user))
        return chat(msgs, null).optString("content").trim()
    }

    /** Вопрос по картинке (OCR, описание экрана, фото). */
    fun vision(system: String, prompt: String, bmp: android.graphics.Bitmap): String {
        val parts = JSONArray().put(JSONObject().put("type", "text").put("text", prompt)).put(imagePart(bmp, 1600, 82))
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", parts))
        return chat(msgs, null).optString("content").trim()
    }

    private fun open(path: String, method: String): HttpURLConnection {
        val url = URL(Prefs.baseUrl(ctx) + path)
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 180_000
        c.setRequestProperty("Authorization", "Bearer " + Prefs.apiKey(ctx))
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        c.setRequestProperty("Accept", "application/json")
        if (Prefs.providerId(ctx) == "openrouter") {
            c.setRequestProperty("HTTP-Referer", "https://github.com/darlin-assistant")
            c.setRequestProperty("X-Title", "Darlin Assistant")
        }
        return c
    }

    private fun readResponse(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw ChatWire.friendlyError(code, body, Prefs.model(ctx))
        return body
    }

    /** История в формате текущего провайдера (Gemini — с подписями мыслей, остальным — только стандартные поля). */
    private fun wire(messages: JSONArray): JSONArray =
        ChatWire.prepare(messages, ChatWire.isGemini(Prefs.baseUrl(ctx), Prefs.model(ctx)), Prefs.providerId(ctx) == "openrouter")

    /** Возвращает объект message первого варианта ответа. */
    fun chat(messages: JSONArray, tools: JSONArray?): JSONObject {
        val req = JSONObject()
        req.put("model", Prefs.model(ctx))
        req.put("messages", wire(messages))
        if (tools != null && tools.length() > 0) {
            req.put("tools", tools)
            req.put("tool_choice", "auto")
        }
        req.put("temperature", 0.6)
        val c = open("/chat/completions", "POST")
        c.doOutput = true
        c.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
        val body = readResponse(c)
        val j = JSONObject(body)
        val choices = j.optJSONArray("choices") ?: throw IOException("Пустой ответ модели: ${body.take(300)}")
        return choices.getJSONObject(0).getJSONObject("message")
    }

    /**
     * Потоковый запрос (stream=true, SSE): текст ответа приходит в [onDelta] по мере генерации,
     * чтобы показывать и озвучивать его сразу. Возвращает собранный message (как [chat]).
     * Если сервер не умеет stream — тихо откатывается на обычный запрос.
     */
    fun chatStream(messages: JSONArray, tools: JSONArray?, onDelta: (String) -> Unit): JSONObject {
        if (!streamSupported) return chat(messages, tools).also { m -> m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta) }
        val req = JSONObject()
        req.put("model", Prefs.model(ctx))
        req.put("messages", wire(messages))
        if (tools != null && tools.length() > 0) {
            req.put("tools", tools)
            req.put("tool_choice", "auto")
        }
        req.put("temperature", 0.6)
        req.put("stream", true)
        val c = open("/chat/completions", "POST")
        c.setRequestProperty("Accept", "text/event-stream")
        c.doOutput = true
        c.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        if (code !in 200..299) {
            val body = c.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code == 400 && body.contains("stream", ignoreCase = true) && !body.contains("signature", ignoreCase = true)) {
                streamSupported = false
                return chat(messages, tools).also { m -> m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta) }
            }
            throw ChatWire.friendlyError(code, body, Prefs.model(ctx))
        }
        val acc = StreamAccumulator(onDelta)
        val ctype = c.contentType ?: ""
        c.inputStream.bufferedReader(Charsets.UTF_8).use { r ->
            if (!ctype.contains("event-stream")) {
                // Сервер проигнорировал stream=true и вернул обычный JSON
                val j = JSONObject(r.readText())
                val m = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: throw IOException("Пустой ответ модели")
                m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta)
                return m
            }
            while (true) {
                val line = r.readLine() ?: break
                if (!acc.line(line)) break
            }
        }
        return acc.message()
    }

    fun listModels(): List<String> {
        val c = open("/models", "GET")
        val j = JSONObject(readResponse(c))
        val arr = j.optJSONArray("data") ?: JSONArray()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optString("id") ?: continue
            out.add(id.removePrefix("models/"))
        }
        return out.sorted()
    }
}

/** Собирает ответ из SSE-кусочков OpenAI-формата: текст + вызовы функций (аргументы приходят по частям). */
class StreamAccumulator(private val onDelta: (String) -> Unit) {
    private val content = StringBuilder()
    private val calls = ArrayList<JSONObject>()      // {id, type, function:{name, arguments}}
    private val args = ArrayList<StringBuilder>()
    private val extra = JSONObject()

    /** Обрабатывает строку SSE. false — поток завершён ([DONE]). */
    fun line(raw: String): Boolean {
        val line = raw.trim()
        if (!line.startsWith("data:")) return true
        val data = line.removePrefix("data:").trim()
        if (data == "[DONE]") return false
        if (data.isEmpty()) return true
        val j = try { JSONObject(data) } catch (_: Exception) { return true }
        j.optJSONObject("error")?.let { throw ChatWire.friendlyError(it.optInt("code", 400).let { c -> if (c in 100..599) c else 400 }, data, "") }
        val choices = j.optJSONArray("choices") ?: return true
        for (ci in 0 until choices.length()) {
            val delta = choices.optJSONObject(ci)?.let { it.optJSONObject("delta") ?: it.optJSONObject("message") } ?: continue
            val text = delta.optString("content", "")
            if (text.isNotEmpty() && text != "null") { content.append(text); onDelta(text) }
            // Прочие поля сообщения (extra_content с подписью Gemini, reasoning…) — сохраняем как есть
            val rest = JSONObject()
            for (k in delta.keys()) if (k != "content" && k != "tool_calls" && k != "role") rest.put(k, delta.opt(k))
            if (rest.length() > 0) ChatWire.merge(extra, rest, appendStrings = true)
            val tc = delta.optJSONArray("tool_calls") ?: continue
            for (k in 0 until tc.length()) {
                val t = tc.optJSONObject(k) ?: continue
                val id = t.optString("id", "")
                var idx = t.optInt("index", -1)
                if (idx < 0 || idx > calls.size) {
                    // У некоторых серверов (Gemini) нет index: новый id — новый вызов
                    idx = if (id.isNotEmpty() && calls.none { it.optString("id") == id }) calls.size else maxOf(0, calls.size - 1)
                }
                while (calls.size <= idx) {
                    calls += JSONObject().put("id", "").put("type", "function").put("function", JSONObject().put("name", "").put("arguments", ""))
                    args += StringBuilder()
                }
                val call = calls[idx]
                if (id.isNotEmpty()) call.put("id", id)
                t.optJSONObject("function")?.let { f ->
                    val n = f.optString("name", "")
                    if (n.isNotEmpty() && n != "null") call.getJSONObject("function").put("name", n)
                    val a = f.optString("arguments", "")
                    if (a.isNotEmpty() && a != "null") args[idx].append(a)
                }
                // extra_content.google.thought_signature и любые другие поля — без изменений (подпись может прийти отдельным куском)
                val other = JSONObject()
                for (k in t.keys()) if (k != "index" && k != "id" && k != "function") other.put(k, t.opt(k))
                if (other.length() > 0) ChatWire.merge(call, other, appendStrings = false)
            }
        }
        return true
    }

    fun message(): JSONObject {
        val m = ChatWire.copy(extra).put("role", "assistant").put("content", content.toString())
        if (calls.isNotEmpty()) {
            val arr = JSONArray()
            for ((i, c) in calls.withIndex()) {
                if (c.getJSONObject("function").optString("name").isEmpty()) continue
                if (c.optString("id").isEmpty()) c.put("id", "call_$i")
                c.getJSONObject("function").put("arguments", args[i].toString().ifBlank { "{}" })
                arr.put(c)
            }
            if (arr.length() > 0) m.put("tool_calls", arr)
        }
        return m
    }
}
