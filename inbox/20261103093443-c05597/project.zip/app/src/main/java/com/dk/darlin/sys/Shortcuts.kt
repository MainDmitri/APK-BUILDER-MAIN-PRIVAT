package com.dk.darlin.sys

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.dk.darlin.AssistActivity
import com.dk.darlin.R
import com.dk.darlin.core.Prefs

/** Быстрый вызов: постоянное уведомление «Спросить Дарлин» и виджет на рабочий стол. */
object QuickAccess {
    private const val CHANNEL = "quick"
    private const val ID = 4242

    fun assistIntent(c: Context, typing: Boolean = false): PendingIntent {
        val i = Intent(c, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra(AssistActivity.EXTRA_TYPE, typing)
        return PendingIntent.getActivity(c, if (typing) 2 else 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun update(c: Context) {
        val nm = NotificationManagerCompat.from(c)
        if (!Prefs.bool(c, Prefs.QUICK_NOTIF, false)) { nm.cancel(ID); return }
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Быстрый вызов", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Постоянное уведомление для вызова Дарлин из шторки"; setShowBadge(false)
            }
            c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_darlin_small)
            .setContentTitle("Спросить Дарлин")
            .setContentText("Нажмите, чтобы сказать команду")
            .setContentIntent(assistIntent(c))
            .addAction(R.drawable.ic_mic, "Голосом", assistIntent(c))
            .addAction(R.drawable.ic_chat, "Текстом", assistIntent(c, true))
            .setOngoing(true).setShowWhen(false).setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setCategory(Notification.CATEGORY_SERVICE)
            .build()
        try { nm.notify(ID, n) } catch (_: SecurityException) {}
    }
}

class DarlinWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, views(context))
    }

    companion object {
        fun views(c: Context) = RemoteViews(c.packageName, R.layout.widget_darlin).apply {
            setOnClickPendingIntent(R.id.widget_root, QuickAccess.assistIntent(c))
            setOnClickPendingIntent(R.id.widget_mic, QuickAccess.assistIntent(c))
            setOnClickPendingIntent(R.id.widget_text, QuickAccess.assistIntent(c, true))
        }

        fun requestPin(c: Context): Boolean {
            if (Build.VERSION.SDK_INT < 26) return false
            val mgr = c.getSystemService(AppWidgetManager::class.java) ?: return false
            if (!mgr.isRequestPinAppWidgetSupported) return false
            return mgr.requestPinAppWidget(ComponentName(c, DarlinWidget::class.java), null, null)
        }
    }
}
