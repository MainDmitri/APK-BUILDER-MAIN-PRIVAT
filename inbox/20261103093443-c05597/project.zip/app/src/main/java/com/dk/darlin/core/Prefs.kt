package com.dk.darlin.core

import android.content.Context
import android.content.SharedPreferences
import com.dk.darlin.tts.EdgeTts

data class Provider(val id: String, val title: String, val baseUrl: String, val model: String, val keyUrl: String)

object Prefs {
    val PROVIDERS = listOf(
        Provider("gemini", "Google Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-2.5-flash", "https://aistudio.google.com/apikey"),
        Provider("openai", "OpenAI (ChatGPT)", "https://api.openai.com/v1", "gpt-4.1-mini", "https://platform.openai.com/api-keys"),
        Provider("xai", "xAI Grok", "https://api.x.ai/v1", "grok-4-fast-non-reasoning", "https://console.x.ai"),
        Provider("deepseek", "DeepSeek", "https://api.deepseek.com/v1", "deepseek-chat", "https://platform.deepseek.com/api_keys"),
        Provider("openrouter", "OpenRouter", "https://openrouter.ai/api/v1", "google/gemini-2.5-flash", "https://openrouter.ai/keys"),
        Provider("custom", "Свой сервер (OpenAI-совместимый)", "", "", "")
    )

    fun sp(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences("darlin_prefs", Context.MODE_PRIVATE)

    fun providerId(c: Context) = sp(c).getString("provider", "gemini") ?: "gemini"
    fun provider(c: Context) = PROVIDERS.firstOrNull { it.id == providerId(c) } ?: PROVIDERS[0]
    fun baseUrl(c: Context): String {
        val custom = sp(c).getString("base_url_" + providerId(c), null)
        return (if (!custom.isNullOrBlank()) custom else provider(c).baseUrl).trim().trimEnd('/')
    }
    fun apiKey(c: Context) = (sp(c).getString("api_key_" + providerId(c), "") ?: "").trim()
    fun model(c: Context): String {
        val m = sp(c).getString("model_" + providerId(c), null)
        return (if (!m.isNullOrBlank()) m else provider(c).model).trim()
    }
    fun hasBrain(c: Context) = apiKey(c).isNotEmpty() && baseUrl(c).isNotEmpty() && model(c).isNotEmpty()

    fun setProvider(c: Context, id: String) = sp(c).edit().putString("provider", id).apply()
    fun setBaseUrl(c: Context, v: String) = sp(c).edit().putString("base_url_" + providerId(c), v).apply()
    fun setApiKey(c: Context, v: String) = sp(c).edit().putString("api_key_" + providerId(c), v).apply()
    fun setModel(c: Context, v: String) = sp(c).edit().putString("model_" + providerId(c), v).apply()

    fun voiceEngine(c: Context) = sp(c).getString("voice_engine", "edge") ?: "edge"
    fun edgeVoice(c: Context) = sp(c).getString("edge_voice", EdgeTts.DEFAULT_VOICE) ?: EdgeTts.DEFAULT_VOICE
    fun rate(c: Context) = sp(c).getInt("rate", 10) // чуть быстрее по умолчанию (+10%)
    fun pitch(c: Context) = sp(c).getInt("pitch", 0)

    fun bool(c: Context, key: String, def: Boolean) = sp(c).getBoolean(key, def)
    fun setBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()
    fun str(c: Context, key: String, def: String = "") = sp(c).getString(key, def) ?: def
    fun setStr(c: Context, key: String, v: String) = sp(c).edit().putString(key, v).apply()
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()

    // Ключи переключателей
    const val SPEAK = "speak_replies"          // озвучивать ответы
    const val AUTO_LISTEN = "auto_listen"      // слушать сразу при вызове
    const val CONTINUOUS = "continuous"        // продолжать диалог, если ассистент спросил
    const val SCREEN_TEXT = "screen_text"      // передавать ИИ текст с экрана
    const val SCREENSHOT = "screenshot"        // передавать снимок экрана (vision)
    const val HAPTICS = "haptics"
    const val CONVERSATION = "conversation"    // режим беседы: слушать после каждого ответа
    const val QUICK_NOTIF = "quick_notif"      // постоянное уведомление «Спросить Дарлин»
    const val AUTO_CLOSE = "auto_close"        // закрываться после действия
    const val USER_NAME = "user_name"
    const val CUSTOM_PROMPT = "custom_prompt"
    const val ONBOARDED = "onboarded"
}
