package com.dk.darlin.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Распознавание речи (ru-RU). Всегда использует чужой системный распознаватель, а не заглушку Дарлин. */
class VoiceInput(private val ctx: Context, private val listener: Listener) {
    interface Listener {
        fun onReady()
        fun onLevel(level: Float)
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onError(message: String, silent: Boolean)
    }

    private var sr: SpeechRecognizer? = null
    var isListening = false
        private set

    companion object {
        private val PREFERRED = listOf(
            "com.google.android.googlequicksearchbox", "com.google.android.tts", "com.google.android.as",
            "com.samsung.android.bixby.agent", "com.huawei.vassistant", "com.xiaomi.mibrain.speech", "ru.yandex.searchplugin"
        )

        /** Находит распознаватель речи другого приложения (Google и т. п.). */
        fun findRecognizer(ctx: Context): ComponentName? {
            val pm = ctx.packageManager
            @Suppress("DEPRECATION")
            val list = pm.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), PackageManager.GET_META_DATA)
                .map { ComponentName(it.serviceInfo.packageName, it.serviceInfo.name) }
                .filter { it.packageName != ctx.packageName }
            return list.sortedBy { c -> PREFERRED.indexOf(c.packageName).let { if (it < 0) 99 else it } }.firstOrNull()
        }

        fun create(ctx: Context): SpeechRecognizer? {
            val comp = findRecognizer(ctx)
            if (comp != null) return SpeechRecognizer.createSpeechRecognizer(ctx, comp)
            if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
                return SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
            }
            return null
        }
    }

    fun start() {
        stop()
        val r = create(ctx)
        if (r == null) {
            listener.onError("На телефоне нет службы распознавания речи. Установите приложение Google или «Распознавание речи Google».", false)
            return
        }
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listener.onReady() }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { listener.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listener.onLevel(0f) }
            override fun onError(error: Int) {
                isListening = false
                val (msg, silent) = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Я ничего не расслышала" to true
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет доступа к микрофону — откройте приложение Дарлин и разрешите его" to false
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Нет сети для распознавания речи" to false
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознаватель занят, попробуйте ещё раз" to false
                    SpeechRecognizer.ERROR_CLIENT -> "Распознавание остановлено" to true
                    else -> "Ошибка распознавания ($error)" to false
                }
                listener.onError(msg, silent)
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isBlank()) listener.onError("Я ничего не расслышала", true) else listener.onFinal(t)
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isNotBlank()) listener.onPartial(t)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Быстрый эндпоинтинг: реплика завершается почти сразу после паузы,
            // но минимальная длина не даёт обрезать, если пользователь начал говорить с задержкой.
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
        isListening = true
        try { r.startListening(intent) } catch (e: Exception) {
            isListening = false
            listener.onError("Не удалось включить микрофон: ${e.message}", false)
        }
    }

    fun stop() {
        isListening = false
        sr?.let { try { it.cancel(); it.destroy() } catch (_: Exception) {} }
        sr = null
    }

    fun finish() {
        try { sr?.stopListening() } catch (_: Exception) {}
    }
}
