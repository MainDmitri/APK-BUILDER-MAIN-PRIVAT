package com.dk.darlin.tools

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Погода (Open-Meteo), курсы (ЦБ РФ, open.er-api.com, CoinGecko), Википедия и новости (RSS). Разбор отделён от сети для тестов. */
object Info {
    data class Place(val name: String, val lat: Double, val lon: Double, val region: String = "", val country: String = "")

    // ---------- Погода ----------
    fun wmo(code: Int): String = when (code) {
        0 -> "ясно"; 1 -> "преимущественно ясно"; 2 -> "переменная облачность"; 3 -> "пасмурно"
        45, 48 -> "туман"
        51, 53, 55 -> "морось"; 56, 57 -> "ледяная морось"
        61 -> "небольшой дождь"; 63 -> "дождь"; 65 -> "сильный дождь"; 66, 67 -> "ледяной дождь"
        71 -> "небольшой снег"; 73 -> "снег"; 75 -> "сильный снег"; 77 -> "снежная крупа"
        80 -> "ливень"; 81 -> "ливни"; 82 -> "сильные ливни"; 85, 86 -> "снегопад"
        95 -> "гроза"; 96, 99 -> "гроза с градом"
        else -> "погода код $code"
    }

    fun geocodeUrl(name: String) = "https://geocoding-api.open-meteo.com/v1/search?count=1&language=ru&format=json&name=" + Net.enc(name)

    fun parseGeocode(json: String): Place? {
        val r = JSONObject(json).optJSONArray("results")?.optJSONObject(0) ?: return null
        return Place(r.optString("name"), r.optDouble("latitude"), r.optDouble("longitude"), r.optString("admin1"), r.optString("country"))
    }

    fun forecastUrl(lat: Double, lon: Double, days: Int) = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
        "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,wind_gusts_10m,precipitation,pressure_msl" +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,sunrise,sunset,wind_speed_10m_max,uv_index_max" +
        "&hourly=temperature_2m,precipitation_probability,weather_code" +
        "&timezone=auto&wind_speed_unit=ms&forecast_days=${days.coerceIn(1, 16)}"

    private fun t(v: Double): String { val r = v.roundToInt(); return if (r > 0) "+$r°" else "$r°" }

    /** Текст для озвучки. [day] = 0 — сегодня (с текущей погодой), 1 — завтра и т.д.; [days] > 1 — сводка на несколько дней. */
    fun formatWeather(json: String, place: String, day: Int = 0, days: Int = 1): String {
        val o = JSONObject(json)
        val sb = StringBuilder()
        val daily = o.optJSONObject("daily")
        val dates = daily?.optJSONArray("time")
        val dayNames = SimpleDateFormat("EEEE, d MMMM", Locale.forLanguageTag("ru"))
        val iso = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        fun dayLine(i: Int): String {
            val d = daily ?: return ""
            val date = dates?.optString(i)?.let { try { dayNames.format(iso.parse(it)!!) } catch (_: Exception) { it } } ?: ""
            val code = d.optJSONArray("weather_code")?.optInt(i) ?: -1
            val max = d.optJSONArray("temperature_2m_max")?.optDouble(i) ?: Double.NaN
            val min = d.optJSONArray("temperature_2m_min")?.optDouble(i) ?: Double.NaN
            val pp = d.optJSONArray("precipitation_probability_max")?.optInt(i, -1) ?: -1
            val wind = d.optJSONArray("wind_speed_10m_max")?.optDouble(i) ?: Double.NaN
            val s = StringBuilder("$date: ${wmo(code)}, ${t(min)}…${t(max)}")
            if (pp >= 0) s.append(", вероятность осадков $pp%")
            if (!wind.isNaN() && wind >= 8) s.append(", ветер до ${wind.roundToInt()} м/с")
            return s.toString()
        }
        if (day == 0) {
            val c = o.optJSONObject("current")
            if (c != null) {
                sb.append("$place сейчас: ${wmo(c.optInt("weather_code"))}, ${t(c.optDouble("temperature_2m"))}")
                val feel = c.optDouble("apparent_temperature")
                if (!feel.isNaN() && Math.abs(feel - c.optDouble("temperature_2m")) >= 2) sb.append(", ощущается как ${t(feel)}")
                sb.append(", ветер ${c.optDouble("wind_speed_10m").roundToInt()} м/с")
                val gust = c.optDouble("wind_gusts_10m")
                if (!gust.isNaN() && gust >= 10) sb.append(" (порывы до ${gust.roundToInt()})")
                sb.append(", влажность ${c.optInt("relative_humidity_2m")}%")
                val p = c.optDouble("pressure_msl")
                if (!p.isNaN()) sb.append(", давление ${(p * 0.750062).roundToInt()} мм рт. ст.")
                sb.append(".\n")
            }
            hourlyRain(o)?.let { sb.append(it).append("\n") }
        }
        val n = dates?.length() ?: 0
        val from = day.coerceIn(0, maxOf(0, n - 1))
        val to = minOf(n, from + maxOf(1, days))
        for (i in from until to) sb.append(if (day == 0 && i == 0) "Сегодня " + dayLine(i).substringAfter(": ").let { "— $it" } else dayLine(i)).append(".\n")
        if (day == 0 && daily != null) {
            val sr = daily.optJSONArray("sunrise")?.optString(0)?.substringAfter('T')
            val ss = daily.optJSONArray("sunset")?.optString(0)?.substringAfter('T')
            if (!sr.isNullOrBlank() && !ss.isNullOrBlank()) sb.append("Восход в $sr, закат в $ss.")
        }
        return sb.toString().trim()
    }

    /** «Дождь ожидается около 15:00» — по почасовому прогнозу на ближайшие 12 часов. */
    private fun hourlyRain(o: JSONObject): String? {
        val h = o.optJSONObject("hourly") ?: return null
        val times = h.optJSONArray("time") ?: return null
        val prob = h.optJSONArray("precipitation_probability") ?: return null
        val nowStr = o.optJSONObject("current")?.optString("time") ?: return null
        var start = -1
        for (i in 0 until times.length()) if (times.optString(i) >= nowStr.take(13)) { start = i; break }
        if (start < 0) return null
        for (i in start until minOf(times.length(), start + 12)) {
            if (prob.optInt(i, 0) >= 60) {
                val code = h.optJSONArray("weather_code")?.optInt(i) ?: 61
                val what = if (code in 71..77 || code in 85..86) "Снег" else "Осадки"
                return if (i == start) "$what идут или вот-вот начнутся." else "$what ожидаются около ${times.optString(i).substringAfter('T')} (вероятность ${prob.optInt(i)}%)."
            }
        }
        return "В ближайшие 12 часов осадков почти не ожидается."
    }

    // ---------- Валюты ----------
    private val currencyAliases = mapOf(
        "доллар" to "USD", "долларов" to "USD", "доллара" to "USD", "бакс" to "USD", "usd" to "USD", "$" to "USD",
        "евро" to "EUR", "eur" to "EUR", "€" to "EUR", "рубль" to "RUB", "рублей" to "RUB", "рубля" to "RUB", "руб" to "RUB", "₽" to "RUB",
        "юань" to "CNY", "юаней" to "CNY", "юаня" to "CNY", "фунт" to "GBP", "фунтов" to "GBP", "иена" to "JPY", "йена" to "JPY", "иен" to "JPY",
        "лира" to "TRY", "лир" to "TRY", "тенге" to "KZT", "гривна" to "UAH", "гривен" to "UAH", "белорусский рубль" to "BYN", "драм" to "AMD", "драмов" to "AMD",
        "лари" to "GEL", "сум" to "UZS", "сумов" to "UZS", "франк" to "CHF", "дирхам" to "AED", "дирхамов" to "AED", "бат" to "THB", "батов" to "THB",
        "рупия" to "INR", "рупий" to "INR", "вона" to "KRW", "вон" to "KRW", "злотый" to "PLN", "злотых" to "PLN", "крона" to "SEK", "манат" to "AZN", "сомони" to "TJS", "сом" to "KGS"
    )

    fun currencyCode(s: String): String? {
        val k = s.trim().lowercase()
        currencyAliases[k]?.let { return it }
        if (Regex("[a-zA-Z]{3}").matches(s.trim())) return s.trim().uppercase()
        currencyAliases.entries.firstOrNull { k.startsWith(it.key) && it.key.length >= 3 }?.let { return it.value }
        // «юани», «лирах», «вонах»: отбрасываем окончание и ищем по основе
        for (cut in 1..2) {
            val stem = k.dropLast(cut)
            if (stem.length < 3) break
            currencyAliases.entries.firstOrNull { it.key.length >= 4 && it.key.startsWith(stem) }?.let { return it.value }
        }
        return null
    }

    /** Курсы ЦБ РФ: код → рублей за 1 единицу. */
    fun parseCbr(json: String): Pair<String, Map<String, Double>> {
        val o = JSONObject(json)
        val v = o.getJSONObject("Valute")
        val m = HashMap<String, Double>()
        for (k in v.keys()) { val x = v.getJSONObject(k); m[k] = x.getDouble("Value") / x.optInt("Nominal", 1) }
        m["RUB"] = 1.0
        return o.optString("Date").take(10) to m
    }

    /** open.er-api.com: rates относительно base. */
    fun parseEr(json: String): Map<String, Double> {
        val r = JSONObject(json).getJSONObject("rates")
        return r.keys().asSequence().associateWith { r.getDouble(it) }
    }

    fun money(v: Double): String = if (Math.abs(v) >= 100) String.format(Locale.forLanguageTag("ru"), "%,.2f", v).replace('\u00a0', ' ') else String.format(Locale.forLanguageTag("ru"), "%.4f", v).trimEnd('0').trimEnd(',')

    // ---------- Крипта ----------
    val cryptoIds = mapOf(
        "биткоин" to "bitcoin", "биткойн" to "bitcoin", "btc" to "bitcoin", "bitcoin" to "bitcoin",
        "эфир" to "ethereum", "эфириум" to "ethereum", "eth" to "ethereum", "ethereum" to "ethereum",
        "тон" to "the-open-network", "toncoin" to "the-open-network", "ton" to "the-open-network",
        "usdt" to "tether", "тезер" to "tether", "tether" to "tether", "солана" to "solana", "sol" to "solana", "solana" to "solana",
        "xrp" to "ripple", "рипл" to "ripple", "догикоин" to "dogecoin", "doge" to "dogecoin", "dogecoin" to "dogecoin",
        "bnb" to "binancecoin", "лайткоин" to "litecoin", "ltc" to "litecoin", "трон" to "tron", "trx" to "tron",
        "кардано" to "cardano", "ada" to "cardano", "usdc" to "usd-coin", "нот" to "notcoin", "notcoin" to "notcoin"
    )

    fun parseCoinGecko(json: String, id: String, label: String): String? {
        val o = JSONObject(json).optJSONObject(id) ?: return null
        val sb = StringBuilder(label)
        val usd = o.optDouble("usd"); val rub = o.optDouble("rub")
        if (!usd.isNaN()) sb.append(": ${money(usd)} $")
        if (!rub.isNaN()) sb.append(" (≈ ${money(rub)} ₽)")
        val ch = o.optDouble("usd_24h_change")
        if (!ch.isNaN()) sb.append(", за сутки ${if (ch >= 0) "+" else ""}${String.format(Locale.forLanguageTag("ru"), "%.1f", ch)}%")
        return sb.append('.').toString()
    }

    // ---------- Википедия ----------
    fun wikiSearchUrl(q: String, lang: String = "ru") = "https://$lang.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=1&srsearch=" + Net.enc(q)
    fun wikiSummaryUrl(title: String, lang: String = "ru") = "https://$lang.wikipedia.org/api/rest_v1/page/summary/" + Net.enc(title.replace(' ', '_')).replace("+", "%20")
    fun parseWikiSearch(json: String): String? = JSONObject(json).optJSONObject("query")?.optJSONArray("search")?.optJSONObject(0)?.optString("title")?.takeIf { it.isNotBlank() }
    fun parseWikiSummary(json: String): Pair<String, String>? {
        val o = JSONObject(json)
        val ex = o.optString("extract").trim()
        if (ex.isBlank()) return null
        val url = o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page") ?: ""
        return (o.optString("title") + ": " + ex) to url
    }

    // ---------- Новости ----------
    val feeds = linkedMapOf(
        "lenta" to ("Лента.ру" to "https://lenta.ru/rss/news"),
        "ria" to ("РИА Новости" to "https://ria.ru/export/rss2/archive/index.xml"),
        "bbc" to ("Би-би-си" to "https://feeds.bbci.co.uk/russian/rss.xml"),
        "tass" to ("ТАСС" to "https://tass.ru/rss/v2.xml"),
        "habr" to ("Хабр" to "https://habr.com/ru/rss/articles/?fl=ru")
    )

    fun feedFor(source: String): Pair<String, String>? {
        val s = source.lowercase()
        return feeds[s] ?: when {
            s.contains("лент") -> feeds["lenta"]; s.contains("риа") || s.contains("ria") -> feeds["ria"]
            s.contains("bbc") || s.contains("би-би") || s.contains("бибиси") -> feeds["bbc"]
            s.contains("тасс") -> feeds["tass"]; s.contains("хабр") || s.contains("tech") || s.contains("технолог") -> feeds["habr"]
            else -> null
        }
    }

    data class NewsItem(val title: String, val link: String, val date: String, val desc: String)

    private fun clean(s: String) = s.replace(Regex("(?s)<!\\[CDATA\\[(.*?)]]>"), "$1").replace(Regex("<[^>]+>"), " ")
        .replace("&quot;", "\"").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&#39;", "'").replace("&nbsp;", " ")
        .replace("&laquo;", "«").replace("&raquo;", "»").replace("&mdash;", "—").replace(Regex("\\s+"), " ").trim()

    fun parseRss(xml: String): List<NewsItem> {
        val items = Regex("(?s)<(item|entry)[\\s>].*?</\\1>").findAll(xml)
        fun tag(block: String, name: String) = Regex("(?s)<$name(?:\\s[^>]*)?>(.*?)</$name>").find(block)?.groupValues?.get(1)?.let { clean(it) } ?: ""
        return items.map { m ->
            val b = m.value
            val link = tag(b, "link").ifBlank { Regex("<link[^>]*href=\"([^\"]+)\"").find(b)?.groupValues?.get(1) ?: "" }
            NewsItem(tag(b, "title"), link, tag(b, "pubDate").ifBlank { tag(b, "updated") }, tag(b, "description").ifBlank { tag(b, "summary") })
        }.filter { it.title.isNotBlank() }.toList()
    }

    fun formatNews(source: String, items: List<NewsItem>, limit: Int, withDesc: Boolean): String {
        if (items.isEmpty()) return "Новостей не нашла."
        val inFmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US)
        val outFmt = SimpleDateFormat("HH:mm", Locale.US)
        return "$source — главное:\n" + items.take(limit).mapIndexed { i, it ->
            val time = try { outFmt.format(inFmt.parse(it.date) ?: Date()) } catch (_: Exception) { "" }
            "${i + 1}. ${it.title}" + (if (time.isNotBlank()) " ($time)" else "") + (if (withDesc && it.desc.isNotBlank()) " — ${it.desc.take(200)}" else "")
        }.joinToString("\n")
    }

    // ---------- Геокодирование адреса для такси/карт ----------
    fun nominatimUrl(q: String) = "https://nominatim.openstreetmap.org/search?format=json&limit=1&accept-language=ru&q=" + Net.enc(q)
    fun parseNominatim(json: String): Place? {
        val a = JSONArray(json)
        val o = a.optJSONObject(0) ?: return null
        return Place(o.optString("display_name").split(',').take(3).joinToString(",").trim(), o.optString("lat").toDouble(), o.optString("lon").toDouble())
    }
}
