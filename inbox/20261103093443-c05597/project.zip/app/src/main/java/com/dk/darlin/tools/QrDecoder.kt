package com.dk.darlin.tools

import java.nio.ByteBuffer
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * Небольшой самостоятельный декодер QR-кодов (без внешних библиотек).
 * Рассчитан на скриншоты и чёткие изображения: бинаризация Оцу, поиск трёх поисковых узоров,
 * аффинная выборка модулей, формат-инфо, снятие маски, Рида–Соломона, режимы numeric/alnum/byte/kanji/ECI.
 */
object QrDecoder {
    /** На каждую версию 1..40 и уровень L,M,Q,H: ec на блок, блоков группы 1, данных в блоке 1, блоков группы 2, данных в блоке 2. */
    private val RS = intArrayOf(
        7,1,19,0,0, 10,1,16,0,0, 13,1,13,0,0, 17,1,9,0,0,
        10,1,34,0,0, 16,1,28,0,0, 22,1,22,0,0, 28,1,16,0,0,
        15,1,55,0,0, 26,1,44,0,0, 18,2,17,0,0, 22,2,13,0,0,
        20,1,80,0,0, 18,2,32,0,0, 26,2,24,0,0, 16,4,9,0,0,
        26,1,108,0,0, 24,2,43,0,0, 18,2,15,2,16, 22,2,11,2,12,
        18,2,68,0,0, 16,4,27,0,0, 24,4,19,0,0, 28,4,15,0,0,
        20,2,78,0,0, 18,4,31,0,0, 18,2,14,4,15, 26,4,13,1,14,
        24,2,97,0,0, 22,2,38,2,39, 22,4,18,2,19, 26,4,14,2,15,
        30,2,116,0,0, 22,3,36,2,37, 20,4,16,4,17, 24,4,12,4,13,
        18,2,68,2,69, 26,4,43,1,44, 24,6,19,2,20, 28,6,15,2,16,
        20,4,81,0,0, 30,1,50,4,51, 28,4,22,4,23, 24,3,12,8,13,
        24,2,92,2,93, 22,6,36,2,37, 26,4,20,6,21, 28,7,14,4,15,
        26,4,107,0,0, 22,8,37,1,38, 24,8,20,4,21, 22,12,11,4,12,
        30,3,115,1,116, 24,4,40,5,41, 20,11,16,5,17, 24,11,12,5,13,
        22,5,87,1,88, 24,5,41,5,42, 30,5,24,7,25, 24,11,12,7,13,
        24,5,98,1,99, 28,7,45,3,46, 24,15,19,2,20, 30,3,15,13,16,
        28,1,107,5,108, 28,10,46,1,47, 28,1,22,15,23, 28,2,14,17,15,
        30,5,120,1,121, 26,9,43,4,44, 28,17,22,1,23, 28,2,14,19,15,
        28,3,113,4,114, 26,3,44,11,45, 26,17,21,4,22, 26,9,13,16,14,
        28,3,107,5,108, 26,3,41,13,42, 30,15,24,5,25, 28,15,15,10,16,
        28,4,116,4,117, 26,17,42,0,0, 28,17,22,6,23, 30,19,16,6,17,
        28,2,111,7,112, 28,17,46,0,0, 30,7,24,16,25, 24,34,13,0,0,
        30,4,121,5,122, 28,4,47,14,48, 30,11,24,14,25, 30,16,15,14,16,
        30,6,117,4,118, 28,6,45,14,46, 30,11,24,16,25, 30,30,16,2,17,
        26,8,106,4,107, 28,8,47,13,48, 30,7,24,22,25, 30,22,15,13,16,
        28,10,114,2,115, 28,19,46,4,47, 28,28,22,6,23, 30,33,16,4,17,
        30,8,122,4,123, 28,22,45,3,46, 30,8,23,26,24, 30,12,15,28,16,
        30,3,117,10,118, 28,3,45,23,46, 30,4,24,31,25, 30,11,15,31,16,
        30,7,116,7,117, 28,21,45,7,46, 30,1,23,37,24, 30,19,15,26,16,
        30,5,115,10,116, 28,19,47,10,48, 30,15,24,25,25, 30,23,15,25,16,
        30,13,115,3,116, 28,2,46,29,47, 30,42,24,1,25, 30,23,15,28,16,
        30,17,115,0,0, 28,10,46,23,47, 30,10,24,35,25, 30,19,15,35,16,
        30,17,115,1,116, 28,14,46,21,47, 30,29,24,19,25, 30,11,15,46,16,
        30,13,115,6,116, 28,14,46,23,47, 30,44,24,7,25, 30,59,16,1,17,
        30,12,121,7,122, 28,12,47,26,48, 30,39,24,14,25, 30,22,15,41,16,
        30,6,121,14,122, 28,6,47,34,48, 30,46,24,10,25, 30,2,15,64,16,
        30,17,122,4,123, 28,29,46,14,47, 30,49,24,10,25, 30,24,15,46,16,
        30,4,122,18,123, 28,13,46,32,47, 30,48,24,14,25, 30,42,15,32,16,
        30,20,117,4,118, 28,40,47,7,48, 30,43,24,22,25, 30,10,15,67,16,
        30,19,118,6,119, 28,18,47,31,48, 30,34,24,34,25, 30,20,15,61,16,
    )

    /** lum — яркость 0..255 построчно. Возвращает текст или null. */
    fun decode(lum: IntArray, w: Int, h: Int): String? {
        if (w < 21 || h < 21 || lum.size < w * h) return null
        val t = otsu(lum, w * h)
        val dark = BooleanArray(w * h) { lum[it] < t }
        return decodeBinary(dark, w, h) ?: decodeBinary(BooleanArray(w * h) { !dark[it] }, w, h)
    }

    /** ARGB-пиксели (как Bitmap.getPixels). */
    fun decodeArgb(px: IntArray, w: Int, h: Int): String? = decode(IntArray(w * h) {
        val c = px[it]; ((c shr 16 and 255) * 299 + (c shr 8 and 255) * 587 + (c and 255) * 114) / 1000
    }, w, h)

    private fun otsu(lum: IntArray, n: Int): Int {
        val hist = IntArray(256)
        for (i in 0 until n) hist[lum[i].coerceIn(0, 255)]++
        var sum = 0.0
        for (i in 0..255) sum += i.toDouble() * hist[i]
        var sumB = 0.0; var wB = 0; var best = 0.0; var th = 128
        for (i in 0..255) {
            wB += hist[i]; if (wB == 0) continue
            val wF = n - wB; if (wF == 0) break
            sumB += i.toDouble() * hist[i]
            val mB = sumB / wB; val mF = (sum - sumB) / wF
            val between = wB.toDouble() * wF * (mB - mF) * (mB - mF)
            if (between > best) { best = between; th = i + 1 }
        }
        return th
    }

    private class Cand(var x: Double, var y: Double, var m: Double, var count: Int = 1)

    private fun ratioOk(r: IntArray): Boolean {
        val total = r.sum(); if (total < 7) return false
        val m = total / 7.0; val v = m * 0.7
        return Math.abs(m - r[0]) < v && Math.abs(m - r[1]) < v && Math.abs(3 * m - r[2]) < 3 * v &&
            Math.abs(m - r[3]) < v && Math.abs(m - r[4]) < v
    }

    /** Проверка по вертикали через (cx, cy); возвращает центр y и полную высоту узора. */
    private fun crossCheck(img: BooleanArray, w: Int, h: Int, cx: Int, cy: Int, vertical: Boolean, maxCount: Int): Pair<Double, Int>? {
        fun at(p: Int) = if (vertical) img[p * w + cx] else img[cy * w + p]
        val len = if (vertical) h else w
        val c = if (vertical) cy else cx
        val s = IntArray(5)
        var p = c
        while (p >= 0 && at(p)) { s[2]++; p-- }
        if (p < 0) return null
        while (p >= 0 && !at(p) && s[1] <= maxCount) { s[1]++; p-- }
        if (p < 0 || s[1] > maxCount) return null
        while (p >= 0 && at(p) && s[0] <= maxCount) { s[0]++; p-- }
        if (s[0] > maxCount) return null
        p = c + 1
        while (p < len && at(p)) { s[2]++; p++ }
        if (p == len) return null
        while (p < len && !at(p) && s[3] < maxCount) { s[3]++; p++ }
        if (p == len || s[3] >= maxCount) return null
        while (p < len && at(p) && s[4] < maxCount) { s[4]++; p++ }
        if (s[4] >= maxCount) return null
        if (!ratioOk(s)) return null
        return Pair(p - s[4] - s[3] - s[2] / 2.0, s.sum())
    }

    private fun findCandidates(img: BooleanArray, w: Int, h: Int): List<Cand> {
        val out = ArrayList<Cand>()
        val runs = IntArray(w + 1); val starts = IntArray(w + 1)
        for (y in 0 until h) {
            var n = 0; var x = 0
            val row = y * w
            while (x < w) {
                val col = img[row + x]; val st = x
                while (x < w && img[row + x] == col) x++
                starts[n] = st; runs[n] = if (col) (x - st) else -(x - st); n++
            }
            var i = 0
            while (i + 4 < n) {
                if (runs[i] > 0) {
                    val r = intArrayOf(runs[i], -runs[i + 1], runs[i + 2], -runs[i + 3], runs[i + 4])
                    if (ratioOk(r)) {
                        val cx = starts[i + 2] + runs[i + 2] / 2
                        val v = crossCheck(img, w, h, cx, y, true, r[2] * 2)
                        if (v != null) {
                            val cy = v.first.toInt()
                            val hc = crossCheck(img, w, h, cx, cy, false, r[2] * 2)
                            if (hc != null) {
                                val m = (hc.second + v.second) / 14.0
                                val fx = hc.first; val fy = v.first
                                val ex = out.firstOrNull { Math.abs(it.x - fx) <= m * 2 && Math.abs(it.y - fy) <= m * 2 && Math.abs(it.m - m) <= Math.max(1.0, it.m * 0.5) }
                                if (ex != null) {
                                    val k = ex.count
                                    ex.x = (ex.x * k + fx) / (k + 1); ex.y = (ex.y * k + fy) / (k + 1); ex.m = (ex.m * k + m) / (k + 1); ex.count++
                                } else out.add(Cand(fx, fy, m))
                            }
                        }
                    }
                }
                i++
            }
        }
        return out
    }

    /** Диагональная проверка 1:1:3:1:1 (отсекает ложные узоры в области данных). */
    private fun diagonalOk(img: BooleanArray, w: Int, h: Int, c: Cand): Boolean {
        val cx = c.x.toInt(); val cy = c.y.toInt()
        if (cx !in 0 until w || cy !in 0 until h || !img[cy * w + cx]) return false
        val maxC = (c.m * 3).toInt() + 2
        fun dark(x: Int, y: Int) = img[y * w + x]
        val st = IntArray(5)
        var i = 0
        while (cx - i >= 0 && cy - i >= 0 && dark(cx - i, cy - i)) { st[2]++; i++ }
        if (cx - i < 0 || cy - i < 0) return false
        while (cx - i >= 0 && cy - i >= 0 && !dark(cx - i, cy - i) && st[1] <= maxC) { st[1]++; i++ }
        if (cx - i < 0 || cy - i < 0 || st[1] > maxC) return false
        while (cx - i >= 0 && cy - i >= 0 && dark(cx - i, cy - i) && st[0] <= maxC) { st[0]++; i++ }
        if (st[0] > maxC) return false
        i = 1
        while (cx + i < w && cy + i < h && dark(cx + i, cy + i)) { st[2]++; i++ }
        if (cx + i >= w || cy + i >= h) return false
        while (cx + i < w && cy + i < h && !dark(cx + i, cy + i) && st[3] <= maxC) { st[3]++; i++ }
        if (cx + i >= w || cy + i >= h || st[3] > maxC) return false
        while (cx + i < w && cy + i < h && dark(cx + i, cy + i) && st[4] <= maxC) { st[4]++; i++ }
        if (st[4] > maxC) return false
        val total = st.sum(); val m = total / 7.0; val v = m / 1.333
        return Math.abs(m - st[0]) < v && Math.abs(m - st[1]) < v && Math.abs(3 * m - st[2]) < 3 * v &&
            Math.abs(m - st[3]) < v && Math.abs(m - st[4]) < v && Math.abs(total - c.m * 7 * Math.sqrt(2.0)) < c.m * 7 * 0.9
    }

    /** Доля совпадений с эталоном искателя 7×7 и светлой рамкой вокруг (9×9) в заданных осях. */
    private fun finderMatch(img: BooleanArray, w: Int, h: Int, c: Cand, ux: Double, uy: Double, vx: Double, vy: Double): Double {
        var ok = 0; var n = 0
        for (j in -4..4) for (i in -4..4) {
            val r = maxOf(Math.abs(i), Math.abs(j))
            val want = r <= 1 || r == 3
            val px = Math.floor(c.x + (i * ux + j * vx) * c.m).toInt()
            val py = Math.floor(c.y + (i * uy + j * vy) * c.m).toInt()
            n++
            val got = if (px < 0 || py < 0 || px >= w || py >= h) false else img[py * w + px]
            if (got == want) ok++
        }
        return ok.toDouble() / n
    }

    private fun decodeBinary(img: BooleanArray, w: Int, h: Int): String? {
        val all = findCandidates(img, w, h)
        val diag = all.filter { diagonalOk(img, w, h, it) }
        var cands = diag.filter { it.count >= 2 }
        if (cands.size < 3) cands = diag
        if (cands.size < 3) cands = all.filter { it.count >= 2 }
        if (cands.size < 3) cands = all
        if (cands.size < 3) return null
        val top = cands.sortedByDescending { it.count }.take(30)
        data class Tri(val tl: Cand, val tr: Cand, val bl: Cand, val score: Double, val match: Double)
        val tris = ArrayList<Tri>()
        for (a in top.indices) for (b in a + 1 until top.size) for (c in b + 1 until top.size) {
            val p = listOf(top[a], top[b], top[c])
            val ms = p.map { it.m }
            if (ms.max() / ms.min() > 1.5) continue
            fun d2(u: Cand, v: Cand) = (u.x - v.x) * (u.x - v.x) + (u.y - v.y) * (u.y - v.y)
            val d01 = d2(p[0], p[1]); val d02 = d2(p[0], p[2]); val d12 = d2(p[1], p[2])
            val tl: Cand; val o1: Cand; val o2: Cand; val hyp: Double
            when {
                d12 >= d01 && d12 >= d02 -> { tl = p[0]; o1 = p[1]; o2 = p[2]; hyp = d12 }
                d02 >= d01 && d02 >= d12 -> { tl = p[1]; o1 = p[0]; o2 = p[2]; hyp = d02 }
                else -> { tl = p[2]; o1 = p[0]; o2 = p[1]; hyp = d01 }
            }
            val l1 = d2(tl, o1); val l2 = d2(tl, o2)
            val rightErr = Math.abs(hyp - l1 - l2) / hyp
            val legErr = Math.abs(Math.sqrt(l1) - Math.sqrt(l2)) / Math.sqrt(Math.max(l1, l2))
            if (rightErr > 0.2 || legErr > 0.25) continue
            val m = ms.average()
            if (Math.sqrt(l1) / m < 10) continue
            val cross = (o1.x - tl.x) * (o2.y - tl.y) - (o1.y - tl.y) * (o2.x - tl.x)
            val (tr, bl) = if (cross > 0) o1 to o2 else o2 to o1
            // Оси модулей в системе этой тройки — проверяем шаблон 9×9 каждого узора (устойчиво к повороту)
            val lx = Math.hypot(tr.x - tl.x, tr.y - tl.y); val ly = Math.hypot(bl.x - tl.x, bl.y - tl.y)
            val ux = (tr.x - tl.x) / lx; val uy = (tr.y - tl.y) / lx
            val vx = (bl.x - tl.x) / ly; val vy = (bl.y - tl.y) / ly
            val match = minOf(finderMatch(img, w, h, tl, ux, uy, vx, vy), finderMatch(img, w, h, tr, ux, uy, vx, vy), finderMatch(img, w, h, bl, ux, uy, vx, vy))
            if (match < 0.8) continue
            tris.add(Tri(tl, tr, bl, rightErr + legErr, match))
        }
        for (t in tris.sortedWith(compareByDescending<Tri> { Math.round(it.match * 20) }.thenBy { it.score }).take(5)) {
            val m = (t.tl.m + t.tr.m + t.bl.m) / 3
            val dTr = Math.hypot(t.tr.x - t.tl.x, t.tr.y - t.tl.y) / m
            val dBl = Math.hypot(t.bl.x - t.tl.x, t.bl.y - t.tl.y) / m
            var dim = Math.round((dTr + dBl) / 2).toInt() + 7
            when (dim and 3) { 0 -> dim++; 2 -> dim--; 3 -> dim -= 2 }
            for (dd in intArrayOf(dim, dim + 4, dim - 4, dim + 8, dim - 8)) {
                if (dd < 21 || dd > 177) continue
                val grid = sample(img, w, h, t.tl, t.tr, t.bl, dd) ?: continue
                decodeGrid(grid, dd)?.let { return it }
                decodeGrid(Array(dd) { y -> BooleanArray(dd) { x -> grid[x][y] } }, dd)?.let { return it }
            }
        }
        return null
    }

    private fun sample(img: BooleanArray, w: Int, h: Int, tl: Cand, tr: Cand, bl: Cand, dim: Int): Array<BooleanArray>? {
        val k = (dim - 7).toDouble()
        val exX = (tr.x - tl.x) / k; val exY = (tr.y - tl.y) / k
        val eyX = (bl.x - tl.x) / k; val eyY = (bl.y - tl.y) / k
        return Array(dim) { v ->
            BooleanArray(dim) { u ->
                val du = u - 3.0; val dv = v - 3.0
                val px = Math.floor(tl.x + du * exX + dv * eyX).toInt()
                val py = Math.floor(tl.y + du * exY + dv * eyY).toInt()
                if (px < 0 || py < 0 || px >= w || py >= h) return null
                img[py * w + px]
            }
        }
    }

    // ---------- Матрица модулей → текст ----------

    /** grid[y][x], true = тёмный модуль. Публично для тестов. */
    fun decodeGrid(grid: Array<BooleanArray>, dim: Int): String? {
        val version = (dim - 17) / 4
        if (version !in 1..40 || version * 4 + 17 != dim) return null
        fun g(x: Int, y: Int) = grid[y][x]
        var f1 = 0
        fun cb(x: Int, y: Int, acc: Int) = (acc shl 1) or (if (g(x, y)) 1 else 0)
        for (i in 0 until 6) f1 = cb(i, 8, f1)
        f1 = cb(7, 8, f1); f1 = cb(8, 8, f1); f1 = cb(8, 7, f1)
        for (j in 5 downTo 0) f1 = cb(8, j, f1)
        var f2 = 0
        for (j in dim - 1 downTo dim - 7) f2 = cb(8, j, f2)
        for (i in dim - 8 until dim) f2 = cb(i, 8, f2)
        val fmt = formatInfo(f1, f2) ?: return null
        val ecLevel = when ((fmt shr 3) and 3) { 0 -> 1; 1 -> 0; 2 -> 3; else -> 2 } // M,L,H,Q → индекс L0 M1 Q2 H3
        val mask = fmt and 7

        val func = functionPattern(version, dim)
        val total = totalCodewords(version)
        val raw = IntArray(total)
        var off = 0; var cur = 0; var nb = 0
        var up = true
        var j = dim - 1
        while (j > 0) {
            if (j == 6) j--
            for (count in 0 until dim) {
                val i = if (up) dim - 1 - count else count
                for (col in 0 until 2) {
                    val x = j - col
                    if (!func[i][x]) {
                        var bit = g(x, i)
                        if (masked(mask, i, x)) bit = !bit
                        cur = (cur shl 1) or (if (bit) 1 else 0); nb++
                        if (nb == 8) { if (off < total) raw[off++] = cur; nb = 0; cur = 0 }
                    }
                }
            }
            up = !up
            j -= 2
        }
        if (off != total) return null
        val data = deinterleave(raw, version, ecLevel) ?: return null
        return parseBits(data, version)
    }

    private val FORMATS: IntArray by lazy {
        IntArray(32) { d ->
            var v = d shl 10
            for (i in 14 downTo 10) if ((v shr i) and 1 == 1) v = v xor (0x537 shl (i - 10))
            ((d shl 10) or (v and 0x3FF)) xor 0x5412
        }
    }

    private fun formatInfo(a: Int, b: Int): Int? {
        var best = -1; var bestD = 99
        for (d in 0 until 32) {
            val c = FORMATS[d]
            val da = Integer.bitCount(a xor c); val db = Integer.bitCount(b xor c)
            val m = minOf(da, db)
            if (m < bestD) { bestD = m; best = d }
        }
        return if (bestD <= 3) best else null
    }

    private fun masked(mask: Int, i: Int, j: Int): Boolean = when (mask) {
        0 -> (i + j) % 2 == 0
        1 -> i % 2 == 0
        2 -> j % 3 == 0
        3 -> (i + j) % 3 == 0
        4 -> (i / 2 + j / 3) % 2 == 0
        5 -> (i * j) % 2 + (i * j) % 3 == 0
        6 -> ((i * j) % 2 + (i * j) % 3) % 2 == 0
        else -> ((i + j) % 2 + (i * j) % 3) % 2 == 0
    }

    fun alignment(version: Int): IntArray {
        if (version == 1) return IntArray(0)
        val n = version / 7 + 2; val size = version * 4 + 17
        val step = (version * 8 + n * 3 + 5) / (n * 4 - 4) * 2
        val r = IntArray(n); r[0] = 6
        var pos = size - 7
        for (i in n - 1 downTo 1) { r[i] = pos; pos -= step }
        return r
    }

    /** [y][x] = true, если модуль служебный. */
    private fun functionPattern(version: Int, dim: Int): Array<BooleanArray> {
        val f = Array(dim) { BooleanArray(dim) }
        fun region(left: Int, top: Int, width: Int, height: Int) {
            for (y in top until top + height) for (x in left until left + width) if (x in 0 until dim && y in 0 until dim) f[y][x] = true
        }
        region(0, 0, 9, 9); region(dim - 8, 0, 8, 9); region(0, dim - 8, 9, 8)
        val al = alignment(version); val max = al.size
        for (i in 0 until max) for (j in 0 until max) {
            if ((i == 0 && (j == 0 || j == max - 1)) || (i == max - 1 && j == 0)) continue
            region(al[i] - 2, al[j] - 2, 5, 5)
        }
        region(6, 9, 1, dim - 17); region(9, 6, dim - 17, 1)
        if (version > 6) { region(dim - 11, 0, 3, 6); region(0, dim - 11, 6, 3) }
        return f
    }

    private fun totalCodewords(version: Int): Int {
        val b = (version - 1) * 20 // уровень L
        return RS[b + 1] * (RS[b + 2] + RS[b]) + RS[b + 3] * (RS[b + 4] + RS[b])
    }

    private fun deinterleave(raw: IntArray, version: Int, level: Int): IntArray? {
        val b = (version - 1) * 20 + level * 5
        val ec = RS[b]; val c1 = RS[b + 1]; val d1 = RS[b + 2]; val c2 = RS[b + 3]; val d2 = RS[b + 4]
        val n = c1 + c2
        val blocks = Array(n) { IntArray((if (it < c1) d1 else d2) + ec) }
        val shortData = d1
        var o = 0
        for (i in 0 until shortData) for (j in 0 until n) blocks[j][i] = raw[o++]
        for (j in c1 until n) blocks[j][shortData] = raw[o++]
        val max = blocks[n - 1].size
        for (i in shortData until max) for (j in 0 until n) {
            val io = if (j < c1) i else i + 1
            if (io < blocks[j].size) blocks[j][io] = raw[o++]
        }
        val out = ArrayList<Int>()
        for ((k, blk) in blocks.withIndex()) {
            if (!ReedSolomon.correct(blk, ec)) return null
            val dn = if (k < c1) d1 else d2
            for (i in 0 until dn) out.add(blk[i])
        }
        return out.toIntArray()
    }

    private const val ALNUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:"

    private fun parseBits(data: IntArray, version: Int): String? {
        var pos = 0
        val totalBits = data.size * 8
        fun avail() = totalBits - pos
        fun read(n: Int): Int {
            var v = 0
            for (k in 0 until n) {
                val byte = data[pos shr 3]
                val bit = (byte shr (7 - (pos and 7))) and 1
                v = (v shl 1) or bit; pos++
            }
            return v
        }
        val sb = StringBuilder()
        var eci: Charset? = null
        val sizeIdx = if (version <= 9) 0 else if (version <= 26) 1 else 2
        while (avail() >= 4) {
            val mode = read(4)
            when (mode) {
                0 -> break
                1 -> {
                    var count = read(intArrayOf(10, 12, 14)[sizeIdx])
                    while (count >= 3) { if (avail() < 10) return null; val v = read(10); if (v >= 1000) return null; sb.append(String.format(java.util.Locale.US, "%03d", v)); count -= 3 }
                    if (count == 2) { if (avail() < 7) return null; val v = read(7); if (v >= 100) return null; sb.append(String.format(java.util.Locale.US, "%02d", v)) }
                    else if (count == 1) { if (avail() < 4) return null; val v = read(4); if (v >= 10) return null; sb.append(v) }
                }
                2 -> {
                    var count = read(intArrayOf(9, 11, 13)[sizeIdx])
                    while (count >= 2) { if (avail() < 11) return null; val v = read(11); if (v / 45 >= 45) return null; sb.append(ALNUM[v / 45]).append(ALNUM[v % 45]); count -= 2 }
                    if (count == 1) { if (avail() < 6) return null; val v = read(6); if (v >= 45) return null; sb.append(ALNUM[v]) }
                }
                4 -> {
                    val count = read(intArrayOf(8, 16, 16)[sizeIdx])
                    if (avail() < count * 8) return null
                    val bytes = ByteArray(count) { read(8).toByte() }
                    sb.append(decodeBytes(bytes, eci))
                }
                8 -> {
                    val count = read(intArrayOf(8, 10, 12)[sizeIdx])
                    if (avail() < count * 13) return null
                    val bytes = ByteArray(count * 2)
                    for (k in 0 until count) {
                        val v = read(13)
                        var a = ((v / 0xC0) shl 8) or (v % 0xC0)
                        a += if (a < 0x1F00) 0x8140 else 0xC140
                        bytes[2 * k] = (a shr 8).toByte(); bytes[2 * k + 1] = a.toByte()
                    }
                    sb.append(String(bytes, Charset.forName("Shift_JIS")))
                }
                7 -> {
                    val first = read(8)
                    val value = when {
                        first and 0x80 == 0 -> first and 0x7F
                        first and 0xC0 == 0x80 -> ((first and 0x3F) shl 8) or read(8)
                        else -> ((first and 0x1F) shl 16) or read(16)
                    }
                    eci = when (value) {
                        26 -> Charsets.UTF_8; 3, 1 -> Charsets.ISO_8859_1; 22 -> Charset.forName("windows-1251")
                        7 -> Charset.forName("ISO-8859-5"); 20 -> Charset.forName("Shift_JIS"); 25 -> Charsets.UTF_16BE
                        else -> null
                    }
                }
                3 -> read(16)
                5 -> {}
                9 -> read(8)
                else -> return null
            }
        }
        return sb.toString()
    }

    private fun decodeBytes(b: ByteArray, eci: Charset?): String {
        if (eci != null) return String(b, eci)
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: Exception) {
            val high = b.count { (it.toInt() and 0xFF) >= 0xC0 }
            if (high * 3 >= b.size) String(b, Charset.forName("windows-1251")) else String(b, Charsets.ISO_8859_1)
        }
    }
}

/** Рида–Соломона над GF(256), примитивный полином 0x11D, корни α^0..α^(ec-1) (как в QR). */
object ReedSolomon {
    private val EXP = IntArray(512)
    private val LOG = IntArray(256)
    init {
        var x = 1
        for (i in 0 until 255) { EXP[i] = x; LOG[x] = i; x = x shl 1; if (x and 0x100 != 0) x = x xor 0x11D }
        for (i in 255 until 512) EXP[i] = EXP[i - 255]
    }
    fun mul(a: Int, b: Int) = if (a == 0 || b == 0) 0 else EXP[LOG[a] + LOG[b]]
    fun div(a: Int, b: Int): Int { require(b != 0); return if (a == 0) 0 else EXP[(LOG[a] + 255 - LOG[b]) % 255] }
    private fun inv(a: Int) = EXP[255 - LOG[a]]

    /** Генерирует ec проверочных байт (для тестов). */
    fun encode(data: IntArray, ec: Int): IntArray {
        var gen = intArrayOf(1)
        for (i in 0 until ec) {
            val ng = IntArray(gen.size + 1)
            for (k in gen.indices) { ng[k] = ng[k] xor gen[k]; ng[k + 1] = ng[k + 1] xor mul(gen[k], EXP[i]) }
            gen = ng
        }
        val rem = IntArray(ec)
        for (d in data) {
            val f = d xor rem[0]
            for (k in 0 until ec - 1) rem[k] = rem[k + 1] xor mul(gen[k + 1], f)
            rem[ec - 1] = mul(gen[ec], f)
        }
        return data + rem
    }

    /** Исправляет на месте; false — если ошибок слишком много. */
    fun correct(cw: IntArray, ec: Int): Boolean {
        val n = cw.size
        val s = IntArray(ec)
        var any = false
        for (i in 0 until ec) {
            var v = 0
            val a = EXP[i]
            for (c in cw) v = mul(v, a) xor c
            s[i] = v; if (v != 0) any = true
        }
        if (!any) return true
        // Берлекэмп–Мэсси
        var c = IntArray(ec + 1).also { it[0] = 1 }
        var b = IntArray(ec + 1).also { it[0] = 1 }
        var l = 0; var m = 1; var bb = 1
        for (k in 0 until ec) {
            var d = s[k]
            for (i in 1..l) d = d xor mul(c[i], s[k - i])
            if (d == 0) { m++; continue }
            val coef = div(d, bb)
            val t = c.copyOf()
            for (i in 0..ec - m) if (b[i] != 0) c[i + m] = c[i + m] xor mul(coef, b[i])
            if (2 * l <= k) { l = k + 1 - l; b = t; bb = d; m = 1 } else m++
        }
        if (2 * l > ec) return false
        // Ченя: позиции p, где Λ(X^-1)=0, X = α^(n-1-p)
        val pos = ArrayList<Int>()
        for (p in 0 until n) {
            val xinv = inv(EXP[(n - 1 - p) % 255])
            var v = 0; var xp = 1
            for (i in 0..l) { v = v xor mul(c[i], xp); xp = mul(xp, xinv) }
            if (v == 0) pos.add(p)
        }
        if (pos.size != l) return false
        // Ω = S·Λ mod x^ec
        val omega = IntArray(ec)
        for (i in 0 until ec) for (j in 0..minOf(i, l)) omega[i] = omega[i] xor mul(s[i - j], c[j])
        for (p in pos) {
            val x = EXP[(n - 1 - p) % 255]
            val xinv = inv(x)
            var om = 0; var xp = 1
            for (i in 0 until ec) { om = om xor mul(omega[i], xp); xp = mul(xp, xinv) }
            var der = 0; xp = 1
            for (i in 1..l step 2) {
                der = der xor mul(c[i], xp)
                xp = mul(xp, mul(xinv, xinv))
            }
            if (der == 0) return false
            cw[p] = cw[p] xor mul(x, div(om, der))
        }
        // Проверка
        for (i in 0 until ec) {
            var v = 0; val a = EXP[i]
            for (cc in cw) v = mul(v, a) xor cc
            if (v != 0) return false
        }
        return true
    }
}
