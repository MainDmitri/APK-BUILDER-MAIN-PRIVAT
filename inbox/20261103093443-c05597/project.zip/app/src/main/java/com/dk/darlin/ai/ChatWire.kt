package com.dk.darlin.ai

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Ошибка HTTP от API модели с уже понятным русским текстом. */
class LlmHttpException(val code: Int, val raw: String, message: String) : IOException(message) {
    /** Ошибка истории диалога (подписи Gemini, несогласованные tool_calls) — помогает сброс диалога. */
    val historyProblem: Boolean get() = code == 400 &&
        Regex("(?i)thought_signature|tool_call_id|tool_calls|function call|function response|functionResponse|functionCall").containsMatchIn(raw)
}

/**
 * Подготовка истории к отправке разным провайдерам.
 *
 * Gemini (OpenAI-совместимый режим) возвращает подпись мыслей в
 * `tool_calls[].extra_content.google.thought_signature` и требует вернуть её без изменений
 * в следующих запросах (иначе HTTP 400 «missing a thought_signature»). Поэтому вызовы функций
 * храним целиком, со всеми полями. Строгим API (OpenAI и др.) лишние поля не шлём.
 */
object ChatWire {
    /** Документированная «пустышка» для вызовов без подписи (старая история, другая модель). */
    const val DUMMY_SIGNATURE = "skip_thought_signature_validator"

    fun isGemini(baseUrl: String, model: String = ""): Boolean =
        baseUrl.contains("generativelanguage.googleapis.com") || baseUrl.contains("aiplatform.googleapis.com") ||
            (baseUrl.contains("/openai") && model.startsWith("gemini"))

    private val STD_MSG = setOf("role", "content", "name", "tool_calls", "tool_call_id")
    private val STD_CALL = setOf("id", "type", "function")

    fun copy(o: JSONObject) = JSONObject(o.toString())

    /** Копия истории в формате, который примет выбранный провайдер. */
    fun prepare(messages: JSONArray, gemini: Boolean, openrouter: Boolean = false): JSONArray {
        val out = JSONArray()
        for (i in 0 until messages.length()) {
            val m = messages.optJSONObject(i) ?: continue
            val c = copy(m)
            // Gemini: стандартные поля + extra_content (подписи) ровно как получили; OpenRouter: + reasoning_details
            val keepMsg = when { gemini -> STD_MSG + "extra_content"; openrouter -> STD_MSG + "reasoning_details"; else -> STD_MSG }
            val keepCall = if (gemini) STD_CALL + "extra_content" else STD_CALL
            for (k in c.keys().asSequence().toList()) if (k !in keepMsg || c.opt(k) == JSONObject.NULL && k != "content") c.remove(k)
            c.optJSONArray("tool_calls")?.let { calls ->
                for (j in 0 until calls.length()) {
                    val t = calls.optJSONObject(j) ?: continue
                    for (k in t.keys().asSequence().toList()) if (k !in keepCall) t.remove(k)
                    t.optJSONObject("function")?.let { f -> for (k in f.keys().asSequence().toList()) if (k != "name" && k != "arguments") f.remove(k) }
                }
            }
            if (gemini) addMissingSignature(c)
            out.put(c)
        }
        return out
    }

    /** Gemini 3 проверяет подпись первого вызова функции в каждом шаге. */
    private fun addMissingSignature(m: JSONObject) {
        if (m.optString("role") != "assistant") return
        val calls = m.optJSONArray("tool_calls") ?: return
        if (calls.length() == 0) return
        for (j in 0 until calls.length()) if (signatureOf(calls.optJSONObject(j)) != null) return
        val first = calls.optJSONObject(0) ?: return
        val extra = first.optJSONObject("extra_content") ?: JSONObject().also { first.put("extra_content", it) }
        val g = extra.optJSONObject("google") ?: JSONObject().also { extra.put("google", it) }
        g.put("thought_signature", DUMMY_SIGNATURE)
    }

    fun signatureOf(call: JSONObject?): String? =
        call?.optJSONObject("extra_content")?.optJSONObject("google")?.optString("thought_signature")?.takeIf { it.isNotEmpty() }

    /** Сообщение ассистента для истории: полная копия ответа (подписи, extra_content и т.д.). */
    fun assistantForHistory(reply: JSONObject): JSONObject {
        val a = copy(reply)
        a.put("role", "assistant")
        val c = a.opt("content")
        if (c == null || c == JSONObject.NULL || c == "null") a.put("content", "")
        return a
    }

    /** Глубокое слияние кусочков SSE: объекты сливаются, строки дописываются (кроме подписей), массивы дополняются. */
    fun merge(into: JSONObject, from: JSONObject, appendStrings: Boolean) {
        for (k in from.keys()) {
            val v = from.opt(k)
            val cur = into.opt(k)
            when {
                v is JSONObject && cur is JSONObject -> merge(cur, v, appendStrings)
                v is JSONArray && cur is JSONArray -> for (i in 0 until v.length()) cur.put(v.opt(i))
                v is String && cur is String && appendStrings && !k.contains("signature") && k != "id" && k != "type" -> into.put(k, cur + v)
                v == JSONObject.NULL -> {}
                v is JSONObject -> into.put(k, copy(v))
                else -> into.put(k, v)
            }
        }
    }

    /** Короткое понятное сообщение об ошибке API вместо сырого JSON. */
    fun friendlyError(code: Int, body: String, model: String): LlmHttpException {
        val msg = extractMessage(body)
        val short = msg.substringBefore(". ").substringBefore("\n").take(160).trim()
        val text = when {
            code == 400 && msg.contains("thought_signature", true) ->
                "Gemini отклонил историю диалога (нет подписи вызова функции). Я начала диалог заново — повторите, пожалуйста"
            code == 400 && Regex("(?i)api key|api_key").containsMatchIn(msg) -> "Ключ ИИ не подходит. Проверьте его в «Параметрах»"
            code == 400 -> "Сервис ИИ отклонил запрос: $short"
            code == 401 || code == 403 -> "Ключ ИИ не подходит или нет доступа к модели. Проверьте ключ в «Параметрах»"
            code == 404 -> "Модель «$model» не найдена у провайдера. Выберите другую в «Параметрах»"
            code == 402 -> "На счёте провайдера ИИ закончились средства"
            code == 429 -> "Слишком много запросов к ИИ или исчерпан лимит. Подождите минуту"
            code >= 500 -> "Сервер ИИ временно недоступен. Попробуйте ещё раз чуть позже"
            else -> "Ошибка сервиса ИИ: $short"
        }
        return LlmHttpException(code, msg, "$text (код $code).")
    }

    fun extractMessage(body: String): String = try {
        val t = body.trim()
        val j = if (t.startsWith("[")) JSONArray(t).optJSONObject(0) ?: JSONObject() else JSONObject(t)
        when (val e = j.opt("error")) {
            is JSONObject -> e.optString("message", body)
            is JSONArray -> e.optJSONObject(0)?.optString("message") ?: body
            is String -> e
            else -> body
        }
    } catch (_: Exception) { body }
}
