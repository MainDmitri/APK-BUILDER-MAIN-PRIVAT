package com.dk.darlin.ai

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.provider.Telephony
import android.view.KeyEvent
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.dk.darlin.core.Db
import com.dk.darlin.core.ScreenContext
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.sys.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.zip.ZipFile

/** Куда запускать внешние экраны (из сессии ассистента или из Activity). */
fun interface ActionHost {
    fun launch(intent: Intent): Boolean
    /** Свернуть панель ассистента, чтобы она не мешала работать в другом приложении. */
    fun minimize() {}
    /** Скрыть панель сразу после открытия чего-либо (без карточки «Стоп»); голос и задача продолжаются. */
    fun hideAfterLaunch() {}
}

/** Выполняет действия, которые просит модель (или локальный разбор команд). */
class ToolExecutor(context: Context, private val host: ActionHost) {
    private val ctx = context.applicationContext
    var screen: ScreenContext? = null

    /** Было ли открыто внешнее приложение/экран (после ответа окно ассистента можно скрыть). */
    var launchedSomething = false
    /** Не закрывать панель после ответа (ждём подтверждения пользователя). */
    var keepOpen = false
    /** Задача продолжается после сворачивания панели. */
    var keepAlive = false
    /** Идёт управление интерфейсом другого приложения — модели даётся больше шагов. */
    var uiTask = false
    /** Выполнено разовое действие (будильник, фонарик, файл…) — после ответа панель можно закрыть. */
    var didAction = false
    /** Панель уже скрыта после запуска внешнего экрана. */
    var hiddenAfterLaunch = false

    private val oneShot = setOf(
        "set_alarm", "set_timer", "set_reminder", "cancel_reminder", "add_note", "delete_note", "flashlight", "set_volume",
        "media_control", "play_music", "clipboard_set", "write_file", "make_dir", "copy_file", "move_file", "delete_file",
        "confirm_send", "global_action", "open_app", "open_url", "open_settings", "navigate", "call_phone", "open_file", "show_alarms"
    )

    val ui = UiAutomation(this)
    val extra = ExtraTools(this)

    /** Скрыть панель без карточки «Стоп» (для скриншота или быстрых настроек); ответ договаривается голосом. */
    internal suspend fun hideForCapture() = withContext(Dispatchers.Main) {
        if (!hiddenAfterLaunch) {
            hiddenAfterLaunch = true
            keepAlive = true
            try { host.hideAfterLaunch() } catch (_: Exception) {}
        }
    }
    internal val appContext get() = ctx

    internal suspend fun minimize() = withContext(Dispatchers.Main) {
        if (!keepAlive) {
            keepAlive = true
            try { host.minimize() } catch (_: Exception) {}
        }
        com.dk.darlin.core.Background.showWorking(ctx)
    }

    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
    private val humanFmt = SimpleDateFormat("d MMMM yyyy, HH:mm", Locale("ru"))

    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /**
     * Запускает внешний экран. Если он виден пользователю ([visible]) и включено «Закрываться после действия» —
     * панель Дарлин сразу скрывается, а ответ договаривается голосом уже поверх открытого приложения.
     */
    internal suspend fun start(intent: Intent, visible: Boolean = true): Boolean = withContext(Dispatchers.Main) {
        val ok = host.launch(intent)
        if (ok) {
            launchedSomething = true
            didAction = true
            if (visible && !hiddenAfterLaunch && com.dk.darlin.core.Prefs.bool(ctx, com.dk.darlin.core.Prefs.AUTO_CLOSE, true)) {
                hiddenAfterLaunch = true
                keepAlive = true
                try { host.hideAfterLaunch() } catch (_: Exception) {}
            }
        }
        ok
    }

    /** Подпись действия для показа в чате. */
    fun label(name: String, a: JSONObject): String = when (name) {
        "open_app" -> "Открываю «${a.optString("name")}»"
        "call_phone" -> "Звоню: ${a.optString("target")}"
        "send_sms" -> "Готовлю SMS"
        "set_alarm" -> "Будильник на %02d:%02d".format(a.optInt("hour"), a.optInt("minute"))
        "set_timer" -> "Таймер"
        "set_reminder" -> "Напоминание"
        "add_note" -> "Сохраняю заметку"
        "flashlight" -> if (a.optBoolean("on")) "Включаю фонарик" else "Выключаю фонарик"
        "web_search" -> "Ищу в интернете: ${a.optString("query")}"
        "fetch_url" -> "Читаю страницу"
        "navigate" -> "Маршрут: ${a.optString("destination")}"
        "read_file" -> "Читаю файл"
        "write_file" -> "Записываю файл"
        "search_files", "search_in_files" -> "Ищу файлы"
        "list_files" -> "Смотрю папку"
        "get_screen_text" -> "Смотрю на экран"
        "send_message" -> "Открываю чат: ${a.optString("contact")}"
        "confirm_send" -> "Отправляю сообщение"
        "cancel_send" -> "Отменяю отправку"
        "ui_snapshot" -> "Смотрю на экран"
        "ui_click" -> "Нажимаю" + (a.optString("text").takeIf { it.isNotBlank() }?.let { " «$it»" } ?: " [${a.optInt("index", -1)}]")
        "ui_type" -> "Ввожу текст"
        "ui_scroll" -> "Прокручиваю"
        "ui_wait" -> "Жду"
        "ui_back" -> "Назад"
        else -> ExtraTools.label(name, a) ?: "Действие: $name"
    }

    private fun mediaDone(action: String) = when (action) {
        "play" -> "Продолжаю воспроизведение"; "pause" -> "Пауза"; "stop" -> "Остановила"; "next" -> "Следующий трек"
        "previous" -> "Предыдущий трек"; "forward" -> "Перемотала вперёд на 30 секунд"; "rewind" -> "Перемотала назад на 15 секунд"
        else -> "Готово"
    }

    suspend fun run(name: String, a: JSONObject): String = try {
        if (name in oneShot || name in ExtraTools.oneShot) didAction = true
        when (name) {
            "open_app" -> openApp(a.optString("name")).let { r ->
                if (a.optBoolean("and_look", false) && r.startsWith("Открыто")) { uiTask = true; ui.afterLaunch(r) } else r
            }
            "send_message" -> ui.sendMessage(a.optString("app", "whatsapp"), a.optString("contact"), a.optString("text"))
            "confirm_send" -> if (com.dk.darlin.sys.DarlinNotificationListener.pending != null) { keepOpen = false; com.dk.darlin.sys.DarlinNotificationListener.confirmReply(ctx) } else ui.confirmSend()
            "cancel_send" -> if (com.dk.darlin.sys.DarlinNotificationListener.pending != null) { keepOpen = false; com.dk.darlin.sys.DarlinNotificationListener.cancelReply() } else ui.cancelSend()
            "ui_snapshot" -> ui.snapshotTool()
            "ui_click" -> ui.click(if (a.has("index")) a.optInt("index") else null, a.optString("text"), a.optBoolean("long", false))
            "ui_type" -> ui.type(if (a.has("index")) a.optInt("index") else null, a.optString("text"), a.optBoolean("press_enter", false))
            "ui_scroll" -> ui.scroll(if (a.has("index")) a.optInt("index") else null, a.optString("direction", "down"))
            "ui_wait" -> ui.waitTool(a.optInt("seconds", 2))
            "ui_back" -> ui.back()
            "list_apps" -> listApps(a.optString("filter"))
            "call_phone" -> call(a.optString("target"))
            "send_sms" -> sms(a.optString("target"), a.optString("text"))
            "find_contact" -> findContact(a.optString("name"))
            "read_sms" -> readSms(a.optInt("count", 5), a.optString("from"))
            "send_email" -> email(a.optString("to"), a.optString("subject"), a.optString("body"))
            "share_text" -> share(a.optString("text"), a.optString("app"))
            "set_alarm" -> setAlarm(a.optInt("hour"), a.optInt("minute"), a.optString("label"))
            "set_timer" -> setTimer(a.optInt("seconds"), a.optString("label"))
            "show_alarms" -> if (start(Intent(AlarmClock.ACTION_SHOW_ALARMS))) "Открыла будильники" else "Не нашла приложение часов"
            "add_calendar_event" -> addEvent(a)
            "list_calendar_events" -> listEvents(a.optInt("days", 1))
            "set_reminder" -> setReminder(a)
            "list_reminders" -> listReminders()
            "cancel_reminder" -> cancelReminder(a.optLong("id"))
            "add_note" -> { val id = Db.get(ctx).addNote(a.optString("text")); "Заметка сохранена (id $id)" }
            "list_notes" -> listNotes(a.optString("query"))
            "delete_note" -> if (Db.get(ctx).deleteNote(a.optLong("id"))) "Заметка удалена" else "Заметка не найдена"
            "flashlight" -> flashlight(a.optBoolean("on", !torchOn))
            "set_volume" -> volume(a.optString("stream", "media"), if (a.has("percent")) a.optInt("percent") else -1, a.optString("direction"))
            "media_control" -> a.optString("action").let { act ->
                if (com.dk.darlin.sys.DarlinNotificationListener.mediaAction(ctx, act)) mediaDone(act) else media(act)
            }
            "play_music" -> playMusic(a.optString("query"))
            "open_settings" -> openSettings(a.optString("page"))
            "web_search" -> webSearch(a.optString("query"))
            "fetch_url" -> fetchUrl(a.optString("url"))
            "open_url" -> openUrl(a.optString("url_or_query"))
            "navigate" -> navigate(a.optString("destination"), a.optString("mode", "drive"))
            "device_info" -> deviceInfo()
            "clipboard_get" -> clipGet()
            "clipboard_set" -> clipSet(a.optString("text"))
            "get_screen_text" -> screenText()
            "global_action" -> globalAction(a.optString("action"))
            "click_on_text" -> ui.click(null, a.optString("text"), false)
            "type_text" -> ui.type(null, a.optString("text"), false)
            "scroll_screen" -> ui.scroll(null, a.optString("direction", "down"))
            "list_files" -> Files.list(ctx, a.optString("path"))
            "search_files" -> Files.searchByName(ctx, a.optString("name"), a.optString("path"))
            "search_in_files" -> Files.searchContent(ctx, a.optString("text"), a.optString("path"))
            "read_file" -> Files.read(ctx, a.optString("path"), a.optInt("max_chars", 15000))
            "write_file" -> Files.write(ctx, a.optString("path"), a.optString("content"), a.optBoolean("append", false)).let { r ->
                if (a.optBoolean("open", false) && !r.startsWith("Ошибка") && !r.startsWith("Не ")) r + "\n" + openFile(a.optString("path")) else r
            }
            "make_dir" -> Files.mkdir(ctx, a.optString("path"))
            "copy_file" -> Files.copy(ctx, a.optString("from"), a.optString("to"), move = false)
            "move_file" -> Files.copy(ctx, a.optString("from"), a.optString("to"), move = true)
            "delete_file" -> Files.delete(ctx, a.optString("path"))
            "file_info" -> Files.info(ctx, a.optString("path"))
            "open_file" -> openFile(a.optString("path"))
            else -> extra.run(name, a) ?: "Неизвестная функция $name"
        }
    } catch (e: SecurityException) {
        "Нет разрешения: ${e.message}. Откройте приложение Дарлин → «Настройка» и выдайте доступ."
    } catch (e: Exception) {
        "Ошибка: ${e.message ?: e.javaClass.simpleName}"
    }

    // ---------- Приложения ----------
    private data class App(val label: String, val pkg: String)

    private fun apps(): List<App> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(i, 0).map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
    }

    private fun listApps(filter: String): String {
        val list = apps().map { it.label }.filter { filter.isBlank() || it.contains(filter, true) }.sorted()
        return if (list.isEmpty()) "Ничего не найдено" else list.joinToString(", ")
    }

    private val aliases = mapOf(
        "ютуб" to "youtube", "ютюб" to "youtube", "вотсап" to "whatsapp", "ватсап" to "whatsapp", "вацап" to "whatsapp",
        "вк" to "vk", "вконтакте" to "vk", "хром" to "chrome", "гугл" to "google", "телеграм" to "telegram", "телега" to "telegram",
        "инстаграм" to "instagram", "инста" to "instagram", "тикток" to "tiktok", "спотифай" to "spotify", "яндекс" to "yandex",
        "карты" to "maps", "камера" to "camera", "камеру" to "camera", "настройки" to "settings", "галерея" to "gallery", "галерею" to "gallery",
        "фото" to "photos", "почта" to "gmail", "почту" to "gmail", "плей маркет" to "play store", "магазин" to "store",
        "калькулятор" to "calculator", "часы" to "clock", "календарь" to "calendar", "контакты" to "contacts",
        "сообщения" to "messages", "телефон" to "phone", "музыка" to "music", "музыку" to "music", "браузер" to "chrome",
        "дискорд" to "discord", "твиттер" to "x", "икс" to "x", "файлы" to "files", "заметки" to "notes", "диск" to "drive",
        "озон" to "ozon", "вайлдберриз" to "wildberries", "сбер" to "sber", "тинькофф" to "t-bank", "т банк" to "t-bank", "кинопоиск" to "kinopoisk"
    )

    private fun norm(s: String) = s.lowercase(Locale("ru")).replace("ё", "е").replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun findApp(query: String): App? {
        val q = norm(query)
        if (q.isEmpty()) return null
        val cand = linkedSetOf(q, Translit.toLatin(q))
        aliases[q]?.let { cand.add(it) }
        // склонения: «телеграме», «ютубе»
        aliases[q.trimEnd('е', 'у', 'а', 'ю')]?.let { cand.add(it) }
        val all = apps()
        var best: App? = null
        var bestScore = 0.0
        for (app in all) {
            val l = norm(app.label)
            val ll = Translit.toLatin(l)
            for (c in cand) {
                val score = when {
                    l == c || ll == c -> 1.0
                    l.startsWith(c) || ll.startsWith(c) -> 0.9
                    l.contains(c) || ll.contains(c) || app.pkg.contains(c.replace(" ", "")) -> 0.8
                    else -> similarity(ll, Translit.toLatin(c))
                }
                if (score > bestScore) { bestScore = score; best = app }
            }
        }
        return if (bestScore >= 0.62) best else null
    }

    private fun similarity(a: String, b: String): Double {
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        }
        return 1.0 - d[a.length][b.length].toDouble() / maxOf(a.length, b.length)
    }

    private suspend fun openApp(name: String): String {
        val app = findApp(name) ?: return "Приложение «$name» не найдено. Установленные: " + apps().map { it.label }.sorted().take(60).joinToString(", ")
        val intent = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return "Не удалось открыть ${app.label}"
        return if (start(intent)) "Открыто приложение «${app.label}»" else "Не удалось открыть ${app.label}"
    }

    // ---------- Связь ----------
    internal fun lookupNumber(target: String): Pair<String, String>? {
        val digits = target.filter { it.isDigit() || it == '+' }
        if (digits.length >= 3 && digits.length >= target.count { it.isLetter() }) return target to digits
        if (!granted(Manifest.permission.READ_CONTACTS)) return null
        // SQLite LIKE не учитывает регистр только для латиницы, поэтому пробуем несколько написаний
        fun q(s: String): Pair<String, String>? {
            val variants = listOf(s, s.lowercase().replaceFirstChar { it.uppercase() }, s.lowercase(), s.uppercase()).distinct()
            for (v in variants) {
                ctx.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$v%"),
                    "${ContactsContract.CommonDataKinds.Phone.TIMES_CONTACTED} DESC"
                )?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
            }
            return null
        }
        val t = target.trim()
        q(t)?.let { return it }
        // Пробуем без падежного окончания (например «Максу» → «Макс», «маме» → «мам»)
        val first = t.split(" ").first()
        val stem = if (first.length > 3 && first.last().lowercaseChar() in "уеаюиыяой") first.dropLast(1) else first
        if (stem != t) q(stem)?.let { return it }
        return null
    }

    @SuppressLint("MissingPermission")
    private suspend fun call(target: String): String {
        val (who, number) = lookupNumber(target)
            ?: return if (!granted(Manifest.permission.READ_CONTACTS)) "Нет доступа к контактам — выдайте разрешение в приложении Дарлин" else "Контакт «$target» не найден"
        val direct = granted(Manifest.permission.CALL_PHONE)
        val i = Intent(if (direct) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))
        return if (start(i)) (if (direct) "Звоню: $who ($number)" else "Открыла номеронабиратель: $who ($number)") else "Не удалось позвонить"
    }

    private suspend fun sms(target: String, text: String): String {
        val (who, number) = lookupNumber(target) ?: return "Контакт «$target» не найден"
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text)
        return if (start(i)) "Открыла SMS для $who — осталось нажать «Отправить»" else "Нет приложения SMS"
    }

    private fun findContact(name: String): String {
        if (!granted(Manifest.permission.READ_CONTACTS)) return "Нет доступа к контактам"
        val out = ArrayList<String>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { while (it.moveToNext() && out.size < 15) out.add("${it.getString(0)}: ${it.getString(1)}") }
        return if (out.isEmpty()) "Не найдено" else out.joinToString("\n")
    }

    private fun readSms(count: Int, from: String): String {
        if (!granted(Manifest.permission.READ_SMS)) return "Нет доступа к SMS — выдайте разрешение в приложении Дарлин"
        val out = ArrayList<String>()
        val sel = if (from.isNotBlank()) "${Telephony.Sms.ADDRESS} LIKE ?" else null
        val args = if (from.isNotBlank()) arrayOf("%$from%") else null
        ctx.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI, arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            sel, args, Telephony.Sms.DEFAULT_SORT_ORDER
        )?.use {
            while (it.moveToNext() && out.size < count.coerceIn(1, 20)) {
                out.add("[${humanFmt.format(Date(it.getLong(2)))}] ${it.getString(0)}: ${it.getString(1)}")
            }
        }
        return if (out.isEmpty()) "Входящих SMS нет" else out.joinToString("\n")
    }

    private suspend fun email(to: String, subject: String, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + Uri.encode(to)))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(to)).putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, body)
        return if (start(i)) "Открыла письмо для $to" else "Нет почтового приложения"
    }

    private suspend fun share(text: String, app: String): String {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        val pkg = when (app.lowercase()) {
            "telegram", "телеграм" -> "org.telegram.messenger"
            "whatsapp", "вотсап", "ватсап" -> "com.whatsapp"
            "vk", "вк" -> "com.vkontakte.android"
            else -> null
        }
        if (pkg != null) {
            i.setPackage(pkg)
            if (start(i)) return "Открыла $app для отправки"
            i.setPackage(null)
        }
        return if (start(Intent.createChooser(i, "Отправить"))) "Открыла меню «Поделиться»" else "Не удалось"
    }

    // ---------- Время ----------
    private suspend fun setAlarm(h: Int, m: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        val ok = start(i, visible = false)
        launchedSomething = false // будильник ставится без открытия экрана
        return if (ok) "Будильник поставлен на %02d:%02d".format(h, m) else "Не нашла приложение часов"
    }

    private suspend fun setTimer(sec: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (label.isNotBlank()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label)
        val ok = start(i, visible = false)
        launchedSomething = false
        return if (ok) "Таймер запущен на ${fmtDuration(sec)}" else "Не нашла приложение часов"
    }

    private fun fmtDuration(sec: Int): String {
        val h = sec / 3600; val m = sec % 3600 / 60; val s = sec % 60
        return listOfNotNull(if (h > 0) "$h ч" else null, if (m > 0) "$m мин" else null, if (s > 0) "$s с" else null).joinToString(" ").ifEmpty { "0 с" }
    }

    private suspend fun addEvent(a: JSONObject): String {
        val start = dateFmt.parse(a.optString("start")) ?: return "Неверная дата начала"
        val end = a.optString("end").takeIf { it.isNotBlank() }?.let { dateFmt.parse(it) } ?: Date(start.time + 3600_000)
        val i = Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, a.optString("title"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start.time)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end.time)
            .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, a.optBoolean("all_day", false))
        if (a.optString("location").isNotBlank()) i.putExtra(CalendarContract.Events.EVENT_LOCATION, a.optString("location"))
        if (a.optString("description").isNotBlank()) i.putExtra(CalendarContract.Events.DESCRIPTION, a.optString("description"))
        return if (start(i)) "Открыла создание события «${a.optString("title")}» на ${humanFmt.format(start)} — подтвердите сохранение" else "Нет приложения календаря"
    }

    private fun listEvents(days: Int): String {
        if (!granted(Manifest.permission.READ_CALENDAR)) return "Нет доступа к календарю — выдайте разрешение в приложении Дарлин"
        val begin = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }.timeInMillis
        val end = begin + days.coerceIn(1, 31) * 86_400_000L
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().also {
            ContentUris.appendId(it, begin); ContentUris.appendId(it, end)
        }.build()
        val out = ArrayList<String>()
        ctx.contentResolver.query(
            uri, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.EVENT_LOCATION),
            null, null, CalendarContract.Instances.BEGIN + " ASC"
        )?.use {
            while (it.moveToNext() && out.size < 40) {
                val loc = it.getString(2)
                out.add("${humanFmt.format(Date(it.getLong(1)))} — ${it.getString(0)}" + if (!loc.isNullOrBlank()) " ($loc)" else "")
            }
        }
        return if (out.isEmpty()) "Событий нет" else out.joinToString("\n")
    }

    private fun setReminder(a: JSONObject): String {
        val text = a.optString("text").ifBlank { "Напоминание" }
        val at = when {
            a.has("in_minutes") && a.optInt("in_minutes") > 0 -> System.currentTimeMillis() + a.optInt("in_minutes") * 60_000L
            a.optString("datetime").isNotBlank() -> dateFmt.parse(a.optString("datetime"))?.time ?: return "Неверная дата"
            else -> return "Укажите время напоминания"
        }
        if (at < System.currentTimeMillis() - 60_000) return "Это время уже прошло"
        val id = Db.get(ctx).addReminder(text, at)
        val exact = ReminderScheduler.schedule(ctx, id, at)
        return "Напомню «$text» ${humanFmt.format(Date(at))} (id $id)" + if (!exact) ". Точные будильники запрещены системой — может прийти с небольшой задержкой" else ""
    }

    private fun listReminders(): String {
        val list = Db.get(ctx).reminders(true)
        return if (list.isEmpty()) "Активных напоминаний нет" else list.joinToString("\n") { "#${it.id} ${humanFmt.format(Date(it.at))} — ${it.text}" }
    }

    private fun cancelReminder(id: Long): String {
        ReminderScheduler.cancel(ctx, id)
        return if (Db.get(ctx).deleteReminder(id)) "Напоминание удалено" else "Не найдено"
    }

    private fun listNotes(q: String): String {
        val list = Db.get(ctx).notes(q)
        return if (list.isEmpty()) "Заметок нет" else list.take(50).joinToString("\n") { "#${it.id} (${humanFmt.format(Date(it.created))}): ${it.text}" }
    }

    // ---------- Железо ----------
    private fun flashlight(on: Boolean): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Фонарик не найден"
        cm.setTorchMode(id, on)
        torchOn = on
        return if (on) "Фонарик включён" else "Фонарик выключен"
    }

    private fun volume(stream: String, percent: Int, direction: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val s = when (stream) {
            "ring" -> AudioManager.STREAM_RING; "alarm" -> AudioManager.STREAM_ALARM
            "notification" -> AudioManager.STREAM_NOTIFICATION; "call" -> AudioManager.STREAM_VOICE_CALL
            else -> AudioManager.STREAM_MUSIC
        }
        val max = am.getStreamMaxVolume(s)
        when {
            percent >= 0 -> am.setStreamVolume(s, (max * percent.coerceIn(0, 100) / 100.0).toInt(), AudioManager.FLAG_SHOW_UI)
            direction == "up" -> repeat(2) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            direction == "down" -> repeat(2) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
            direction == "mute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            direction == "unmute" -> am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
        }
        val now = am.getStreamVolume(s)
        return "Громкость: ${now * 100 / maxOf(1, max)}%"
    }

    private fun media(action: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val code = when (action) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY; "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; "forward" -> KeyEvent.KEYCODE_MEDIA_FAST_FORWARD; "rewind" -> KeyEvent.KEYCODE_MEDIA_REWIND
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        val t = SystemClock.uptimeMillis()
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0))
        am.dispatchMediaKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0))
        return "Готово"
    }

    private suspend fun playMusic(q: String): String {
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*").putExtra(SearchManager.QUERY, q)
        if (start(i)) return "Включаю «$q»"
        return if (start(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=" + URLEncoder.encode(q, "UTF-8")))))
            "Открыла поиск музыки «$q»" else "Нет музыкального приложения"
    }

    private suspend fun openSettings(page: String): String {
        val action = when (page) {
            "wifi" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS
            "internet" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIRELESS_SETTINGS
            "volume_panel" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_VOLUME else Settings.ACTION_SOUND_SETTINGS
            "nfc" -> if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_NFC else Settings.ACTION_NFC_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "mobile_data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
            "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "notifications" -> "android.settings.NOTIFICATION_SETTINGS"
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "about" -> Settings.ACTION_DEVICE_INFO_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "security" -> Settings.ACTION_SECURITY_SETTINGS
            "assistant" -> Settings.ACTION_VOICE_INPUT_SETTINGS
            "dnd" -> "android.settings.ZEN_MODE_SETTINGS"
            "default_apps" -> Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        if (start(Intent(action))) return "Открыла настройки: $page"
        return if (start(Intent(Settings.ACTION_SETTINGS))) "Открыла настройки" else "Не удалось открыть настройки"
    }

    // ---------- Интернет ----------
    private fun httpGet(url: String, max: Int = 600_000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 20000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36")
        c.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
        c.inputStream.use { ins ->
            val bytes = ins.readBytes()
            return String(bytes, 0, minOf(bytes.size, max), Charsets.UTF_8)
        }
    }

    private fun htmlToText(html: String): String = html
        .replace(Regex("(?is)<(script|style|noscript|svg|head)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?i)<br\\s*/?>|</p>|</div>|</li>|</h\\d>"), "\n")
        .replace(Regex("<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")
        .replace(Regex("[ \\t]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n").trim()

    private suspend fun webSearch(q: String): String = withContext(Dispatchers.IO) {
        val html = httpGet("https://html.duckduckgo.com/html/?kl=ru-ru&q=" + URLEncoder.encode(q, "UTF-8"))
        val re = Regex("(?s)<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?class=\"result__snippet\"[^>]*>(.*?)</a>")
        val out = ArrayList<String>()
        for (m in re.findAll(html)) {
            var link = m.groupValues[1]
            Regex("uddg=([^&]+)").find(link)?.let { link = URLDecoder.decode(it.groupValues[1], "UTF-8") }
            if (link.contains("duckduckgo.com/y.js")) continue
            out.add("${out.size + 1}. ${htmlToText(m.groupValues[2])}\n$link\n${htmlToText(m.groupValues[3])}")
            if (out.size >= 6) break
        }
        if (out.isEmpty()) "Результатов не найдено" else "Результаты поиска «$q»:\n" + out.joinToString("\n\n")
    }

    private suspend fun fetchUrl(url: String): String = withContext(Dispatchers.IO) {
        val u = if (url.startsWith("http")) url else "https://$url"
        htmlToText(httpGet(u)).take(8000)
    }

    private suspend fun openUrl(v: String): String {
        val looksUrl = v.startsWith("http") || Regex("^[\\w-]+(\\.[\\w-]+)+(/.*)?$").matches(v)
        val uri = if (looksUrl) Uri.parse(if (v.startsWith("http")) v else "https://$v")
        else Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(v, "UTF-8"))
        return if (start(Intent(Intent.ACTION_VIEW, uri))) "Открыла в браузере" else "Нет браузера"
    }

    private suspend fun navigate(dest: String, mode: String): String {
        val enc = Uri.encode(dest)
        if (mode != "show") {
            val m = when (mode) { "walk" -> "w"; "bike" -> "b"; "transit" -> "r"; else -> "d" }
            val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$enc&mode=$m"))
            if (nav.resolveActivity(ctx.packageManager) != null && start(nav)) return "Строю маршрут до «$dest»"
            val yandex = Intent(Intent.ACTION_VIEW, Uri.parse("yandexnavi://map_search?text=$enc"))
            if (yandex.resolveActivity(ctx.packageManager) != null && start(yandex)) return "Открыла Яндекс Навигатор: $dest"
        }
        return if (start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc")))) "Показываю на карте: $dest"
        else if (start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$enc")))) "Открыла карты" else "Нет приложения карт"
    }

    // ---------- Устройство ----------
    private fun deviceInfo(): String {
        val sb = StringBuilder()
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bat != null) {
            val level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / maxOf(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
            val st = bat.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            val temp = bat.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
            sb.append("Батарея: $level%").append(if (charging) ", заряжается" else "").append(", ${temp}°C\n")
        }
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        sb.append("Память: свободно ${gb(stat.availableBytes)} из ${gb(stat.totalBytes)}\n")
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        sb.append("ОЗУ: свободно ${gb(mi.availMem)} из ${gb(mi.totalMem)}\n")
        sb.append("Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "нет подключения"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "мобильная сеть"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "есть"
        }
        sb.append("Сеть: $net\n")
        sb.append("Время работы: ${SystemClock.elapsedRealtime() / 3_600_000} ч")
        return sb.toString()
    }

    private fun gb(b: Long) = "%.1f ГБ".format(b / 1_073_741_824.0)

    private suspend fun clipGet(): String = withContext(Dispatchers.Main) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
        if (t.isNullOrEmpty()) "Буфер пуст или Android не разрешает его читать в фоне" else "Буфер обмена: $t"
    }

    private suspend fun clipSet(text: String): String = withContext(Dispatchers.Main) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Дарлин", text))
        "Скопировано в буфер обмена"
    }

    // ---------- Экран ----------
    private suspend fun screenText(): String {
        screen?.text?.takeIf { it.isNotBlank() }?.let { return "Текст на экране:\n" + it.take(6000) }
        val s = DarlinAccessibilityService.instance
            ?: return "Текст экрана недоступен. Включите «Использовать текст с экрана» в настройках цифрового помощника или службу спец. возможностей Дарлин."
        return withContext(Dispatchers.Main) { "Текст на экране:\n" + s.screenText().take(6000) }
    }

    private suspend fun a11y(block: (DarlinAccessibilityService) -> String): String {
        val s = DarlinAccessibilityService.instance
            ?: return "Нужна служба специальных возможностей «Дарлин» — включите её в приложении Дарлин → «Настройка»."
        return withContext(Dispatchers.Main) { block(s) }
    }

    private suspend fun globalAction(action: String): String = a11y {
        if (action in setOf("back", "home", "recents", "notifications", "quick_settings")) { keepAlive = true; host.minimize() }
        if (it.global(action)) "Выполнено: $action" else "Действие недоступно на этой версии Android"
    }

    private suspend fun openFile(path: String): String {
        val f = Files.resolve(path)
        if (!f.exists()) return "Файл не найден: ${f.path}"
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try {
            if (start(Intent.createChooser(i, "Открыть ${f.name}").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))) "Открываю ${f.name}" else "Нет приложения для этого файла"
        } catch (e: ActivityNotFoundException) { "Нет приложения для этого файла" }
    }

    companion object {
        @Volatile var torchOn = false
    }
}

/** Файловые операции. Требуют «Доступ ко всем файлам» (MANAGE_EXTERNAL_STORAGE) на Android 11+. */
object Files {
    val root: File get() = Environment.getExternalStorageDirectory()

    fun hasAccess(): Boolean = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun noAccess() = "Нет доступа ко всем файлам. Откройте Дарлин → «Настройка» → «Доступ ко всем файлам»."

    fun resolve(path: String): File {
        val p = path.trim().removePrefix("file://")
        if (p.isEmpty() || p == "/" || p == "~") return root
        if (p.startsWith("/")) return File(p)
        val aliases = mapOf("загрузки" to "Download", "downloads" to "Download", "документы" to "Documents",
            "фото" to "DCIM", "камера" to "DCIM/Camera", "музыка" to "Music", "видео" to "Movies", "картинки" to "Pictures")
        return File(root, aliases[p.lowercase()] ?: p)
    }

    private fun size(b: Long): String = when {
        b >= 1_073_741_824 -> "%.1f ГБ".format(b / 1_073_741_824.0)
        b >= 1_048_576 -> "%.1f МБ".format(b / 1_048_576.0)
        b >= 1024 -> "%.0f КБ".format(b / 1024.0)
        else -> "$b Б"
    }

    private val fmt = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.US)

    fun list(ctx: Context, path: String): String {
        if (!hasAccess()) return noAccess()
        val dir = resolve(path)
        if (!dir.exists()) return "Папка не найдена: ${dir.path}"
        if (!dir.isDirectory) return info(ctx, path)
        val items = dir.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: return "Нет доступа к ${dir.path}"
        val sb = StringBuilder("${dir.path} (${items.size} шт.):\n")
        for (f in items.take(150)) {
            sb.append(if (f.isDirectory) "📁 ${f.name}/" else "📄 ${f.name} — ${size(f.length())}, ${fmt.format(Date(f.lastModified()))}").append('\n')
        }
        if (items.size > 150) sb.append("…и ещё ${items.size - 150}")
        return sb.toString()
    }

    private fun walk(start: File, limit: Int = 40000): Sequence<File> =
        start.walkTopDown().onEnter { !it.name.startsWith(".") && it.name != "Android" || it == start }.take(limit)

    fun searchByName(ctx: Context, name: String, path: String): String {
        if (!hasAccess()) return noAccess()
        val q = name.lowercase().trim()
        val res = walk(resolve(path)).filter { it.isFile && it.name.lowercase().contains(q) }.take(60).toList()
        return if (res.isEmpty()) "Файлы «$name» не найдены" else res.joinToString("\n") { "${it.path} — ${size(it.length())}" }
    }

    private val textExt = setOf("txt", "md", "json", "csv", "xml", "html", "htm", "kt", "java", "py", "js", "ts", "c", "cpp", "h",
        "log", "ini", "cfg", "conf", "yaml", "yml", "properties", "sh", "sql", "srt", "tex", "rtf", "gradle", "kts", "css", "toml")

    fun searchContent(ctx: Context, text: String, path: String): String {
        if (!hasAccess()) return noAccess()
        val out = ArrayList<String>()
        for (f in walk(resolve(path), 20000)) {
            if (!f.isFile || f.length() > 2_000_000 || f.extension.lowercase() !in textExt) continue
            try {
                f.useLines { lines ->
                    lines.forEachIndexed { i, line ->
                        if (out.size < 40 && line.contains(text, true)) out.add("${f.path}:${i + 1}: ${line.trim().take(160)}")
                    }
                }
            } catch (_: Exception) {}
            if (out.size >= 40) break
        }
        return if (out.isEmpty()) "Не найдено" else out.joinToString("\n")
    }

    fun read(ctx: Context, path: String, max: Int): String {
        if (!hasAccess()) return noAccess()
        val f = resolve(path)
        if (!f.exists()) return "Файл не найден: ${f.path}"
        if (f.isDirectory) return list(ctx, path)
        val limit = max.coerceIn(500, 60000)
        val ext = f.extension.lowercase()
        val text = when {
            ext == "docx" -> docx(f)
            ext in setOf("html", "htm") -> f.readText().replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ")
            ext in textExt || looksText(f) -> f.bufferedReader().use { r -> val buf = CharArray(limit); val n = r.read(buf); if (n > 0) String(buf, 0, n) else "" }
            else -> return "Это не текстовый файл (${ext.ifEmpty { "без расширения" }}, ${size(f.length())}). Могу открыть его в приложении."
        }
        return "Файл ${f.name} (${size(f.length())}):\n" + text.take(limit) + if (text.length > limit) "\n…(обрезано)" else ""
    }

    private fun looksText(f: File): Boolean {
        if (f.length() > 5_000_000) return false
        val head = f.inputStream().use { val b = ByteArray(1024); val n = it.read(b); if (n <= 0) ByteArray(0) else b.copyOf(n) }
        return head.none { it == 0.toByte() }
    }

    private fun docx(f: File): String = ZipFile(f).use { z ->
        val e = z.getEntry("word/document.xml") ?: return "Пустой документ"
        val xml = z.getInputStream(e).bufferedReader().use { it.readText() }
        xml.replace(Regex("</w:p>"), "\n").replace(Regex("<w:tab/>"), "\t").replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
    }

    fun write(ctx: Context, path: String, content: String, append: Boolean): String {
        if (!hasAccess()) return noAccess()
        val f = resolve(path)
        f.parentFile?.mkdirs()
        if (append) f.appendText(content) else f.writeText(content)
        return "Записано: ${f.path} (${size(f.length())})"
    }

    fun mkdir(ctx: Context, path: String): String {
        if (!hasAccess()) return noAccess()
        val f = resolve(path)
        return if (f.exists() || f.mkdirs()) "Папка готова: ${f.path}" else "Не удалось создать ${f.path}"
    }

    fun copy(ctx: Context, from: String, to: String, move: Boolean): String {
        if (!hasAccess()) return noAccess()
        val src = resolve(from)
        if (!src.exists()) return "Не найдено: ${src.path}"
        var dst = resolve(to)
        if (dst.isDirectory) dst = File(dst, src.name)
        dst.parentFile?.mkdirs()
        if (move) {
            if (src.renameTo(dst)) return "Перемещено в ${dst.path}"
            src.copyRecursively(dst, overwrite = false)
            src.deleteRecursively()
            return "Перемещено в ${dst.path}"
        }
        src.copyRecursively(dst, overwrite = false)
        return "Скопировано в ${dst.path}"
    }

    fun delete(ctx: Context, path: String): String {
        if (!hasAccess()) return noAccess()
        val f = resolve(path)
        if (f == root || f.path.count { it == '/' } < 4) return "Удаление этой папки запрещено ради безопасности"
        if (!f.exists()) return "Не найдено: ${f.path}"
        if (f.isDirectory && (f.listFiles()?.isNotEmpty() == true)) return "Папка не пуста — удаление непустых папок отключено"
        return if (f.delete()) "Удалено: ${f.path}" else "Не удалось удалить"
    }

    fun info(ctx: Context, path: String): String {
        if (!hasAccess()) return noAccess()
        val f = resolve(path)
        if (!f.exists()) return "Не найдено: ${f.path}"
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "неизвестно"
        return "${f.path}\nТип: ${if (f.isDirectory) "папка" else mime}\nРазмер: ${size(if (f.isDirectory) f.walkTopDown().take(20000).filter { it.isFile }.sumOf { it.length() } else f.length())}\nИзменён: ${fmt.format(Date(f.lastModified()))}"
    }
}

/** Транслитерация для сопоставления «телеграм» ↔ «Telegram». */
object Translit {
    private val map = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i",
        'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t",
        'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sch", 'ъ' to "", 'ы' to "y", 'ь' to "",
        'э' to "e", 'ю' to "yu", 'я' to "ya"
    )
    fun toLatin(s: String) = buildString { for (c in s.lowercase()) append(map[c] ?: c.toString()) }
}
