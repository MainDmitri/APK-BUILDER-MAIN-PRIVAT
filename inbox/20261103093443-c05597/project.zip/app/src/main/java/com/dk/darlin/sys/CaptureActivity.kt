package com.dk.darlin.sys

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import kotlinx.coroutines.CompletableDeferred
import java.io.File

/** Прозрачный экран: снимок камерой или выбор картинки из галереи — результат (Uri) возвращается ассистенту. */
class CaptureActivity : ComponentActivity() {
    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_CAMERA = "camera"
        const val MODE_PICK = "pick"
        @Volatile var result: CompletableDeferred<Uri?>? = null

        fun intent(c: Context, mode: String): Intent = Intent(c, CaptureActivity::class.java)
            .putExtra(EXTRA_MODE, mode).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)

        fun photoFile(c: Context): File = File(c.cacheDir, "capture").apply { mkdirs() }.let { File(it, "photo.jpg") }
    }

    private var photoUri: Uri? = null
    private var launched = false

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        finishWith(if (ok) photoUri else null)
    }
    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> finishWith(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        launched = savedInstanceState?.getBoolean("launched") ?: false
        photoUri = savedInstanceState?.getString("uri")?.let(Uri::parse)
        if (launched) return
        launched = true
        try {
            if (intent.getStringExtra(EXTRA_MODE) == MODE_PICK) {
                pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            } else {
                val f = photoFile(this); f.delete()
                val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
                photoUri = uri
                takePicture.launch(uri)
            }
        } catch (e: Exception) { finishWith(null) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("launched", launched)
        photoUri?.let { outState.putString("uri", it.toString()) }
    }

    private fun finishWith(uri: Uri?) {
        result?.complete(uri)
        finish()
        @Suppress("DEPRECATION") overridePendingTransition(0, 0)
    }

    override fun onDestroy() {
        if (isFinishing && !isChangingConfigurations) result?.let { if (!it.isCompleted) it.complete(null) }
        super.onDestroy()
    }
}
