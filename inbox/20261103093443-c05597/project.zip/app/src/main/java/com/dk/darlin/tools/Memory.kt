package com.dk.darlin.tools

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Долговременная память Дарлин («запомни, что…») и пользовательские сценарии («доброе утро» → шаги). */
object Memory {
    private const val FILE = "darlin_memory"
    private const val FACTS = "facts"
    private const val ROUTINES = "routines"
    const val MAX_FACTS = 200

    data class Fact(val text: String, val time: Long)
    data class Routine(val name: String, val steps: String)

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun facts(c: Context): List<Fact> {
        val arr = try { JSONArray(sp(c).getString(FACTS, "[]")) } catch (_: Exception) { JSONArray() }
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.map { Fact(it.optString("t"), it.optLong("at")) }.filter { it.text.isNotBlank() }
    }

    private fun saveFacts(c: Context, list: List<Fact>) {
        val arr = JSONArray()
        list.takeLast(MAX_FACTS).forEach { arr.put(JSONObject().put("t", it.text).put("at", it.time)) }
        sp(c).edit().putString(FACTS, arr.toString()).apply()
    }

    private fun norm(s: String) = s.lowercase().replace('ё', 'е').replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    /** Добавляет факт; похожий старый факт заменяется. */
    fun remember(c: Context, text: String): String {
        val t = text.trim().trimEnd('.').replaceFirstChar { it.uppercase() }
        if (t.isBlank()) return "Нечего запоминать."
        val list = facts(c).toMutableList()
        val n = norm(t)
        list.removeAll { norm(it.text) == n }
        list.add(Fact(t, System.currentTimeMillis()))
        saveFacts(c, list)
        return "Запомнила: «$t»."
    }

    /** Удаляет факты, содержащие слова запроса. «всё» — очищает память. */
    fun forget(c: Context, query: String): String {
        val q = norm(query)
        if (q.isBlank() || q in setOf("все", "всё", "all", "вся память", "все факты")) {
            val n = facts(c).size
            saveFacts(c, emptyList())
            return if (n == 0) "Память и так пуста." else "Забыла всё ($n)."
        }
        val words = q.split(' ').filter { it.length > 2 }.ifEmpty { listOf(q) }
        val list = facts(c)
        val keep = list.filterNot { f -> val nf = norm(f.text); words.all { nf.contains(it.take(maxOf(3, it.length - 2))) } }
        if (keep.size == list.size) return "Не нашла в памяти ничего про «$query»."
        saveFacts(c, keep)
        val removed = list - keep.toSet()
        return "Забыла: " + removed.joinToString("; ") { "«${it.text}»" } + "."
    }

    /** Удалить ровно один факт (из экрана настроек). */
    fun forgetExact(c: Context, text: String) { saveFacts(c, facts(c).filterNot { it.text == text }) }

    fun list(c: Context): String {
        val f = facts(c)
        if (f.isEmpty()) return "Память пуста."
        return "Я помню (${f.size}):\n" + f.mapIndexed { i, x -> "${i + 1}. ${x.text}" }.joinToString("\n")
    }

    /** Для системного промпта. */
    fun promptBlock(c: Context, maxChars: Int = 3000): String {
        val f = facts(c)
        val r = routines(c)
        if (f.isEmpty() && r.isEmpty()) return ""
        val sb = StringBuilder()
        if (f.isNotEmpty()) {
            sb.append("ПАМЯТЬ (факты, которые пользователь просил запомнить; используй их, когда уместно):\n")
            var len = 0
            for (x in f.asReversed()) { val line = "- ${x.text}\n"; len += line.length; if (len > maxChars) break; sb.append(line) }
        }
        if (r.isNotEmpty()) {
            sb.append("СЦЕНАРИИ пользователя (если фраза совпадает с названием — выполни шаги по порядку функциями):\n")
            r.forEach { sb.append("- «${it.name}»: ${it.steps.take(400)}\n") }
        }
        return sb.toString()
    }

    fun routines(c: Context): List<Routine> {
        val o = try { JSONObject(sp(c).getString(ROUTINES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        return o.keys().asSequence().map { Routine(it, o.optString(it)) }.toList()
    }

    fun saveRoutine(c: Context, name: String, steps: String): String {
        val n = name.trim().lowercase()
        if (n.isBlank() || steps.isBlank()) return "Нужно название сценария и шаги."
        val o = try { JSONObject(sp(c).getString(ROUTINES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val existed = o.has(n)
        o.put(n, steps.trim())
        sp(c).edit().putString(ROUTINES, o.toString()).apply()
        return (if (existed) "Обновила" else "Сохранила") + " сценарий «$n»: ${steps.trim()}"
    }

    fun deleteRoutine(c: Context, name: String): String {
        val o = try { JSONObject(sp(c).getString(ROUTINES, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        val key = o.keys().asSequence().firstOrNull { it == name.trim().lowercase() } ?: o.keys().asSequence().firstOrNull { it.contains(name.trim().lowercase()) }
            ?: return "Сценарий «$name» не найден."
        o.remove(key)
        sp(c).edit().putString(ROUTINES, o.toString()).apply()
        return "Удалила сценарий «$key»."
    }

    fun findRoutine(c: Context, phrase: String): Routine? {
        val p = norm(phrase)
        return routines(c).firstOrNull { norm(it.name) == p }
    }

    fun clearAll(c: Context) { sp(c).edit().clear().apply() }
}
