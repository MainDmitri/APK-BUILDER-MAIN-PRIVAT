package com.dk.darlin.ai

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import com.dk.darlin.core.Prefs
import com.dk.darlin.core.ScreenContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Память текущего диалога (живёт, пока жив процесс; сбрасывается через 10 минут тишины). */
object Conversation {
    val messages = ArrayList<JSONObject>()
    var lastTime = 0L

    fun touch() {
        val now = System.currentTimeMillis()
        if (now - lastTime > 10 * 60_000) messages.clear()
        lastTime = now
    }

    fun reset() { messages.clear(); lastTime = 0 }

    /**
     * Сокращает историю только целыми репликами (user → assistant/tool_calls → tool … ), начиная со старых.
     * Сообщения с вызовами функций не меняются и не разрываются — иначе Gemini отклонит подписи.
     * Текущую (последнюю) реплику пользователя не трогаем.
     */
    fun trim(max: Int = 30) {
        while (messages.size > max) {
            val next = (1 until messages.size).firstOrNull { messages[it].optString("role") == "user" } ?: break
            repeat(next) { messages.removeAt(0) }
        }
        while (messages.size > 1 && messages[0].optString("role") != "user") messages.removeAt(0)
    }
}

/** «Мозг» ассистента: LLM с вызовом функций + локальные команды без интернета. */
class Agent(private val ctx: Context, val tools: ToolExecutor) {
    private val llm = LlmClient(ctx)
    private val local = LocalBrain(tools)

    private val screenWords = Regex("(?i)экран|скрин|на картинк|что это|что тут|что здесь|прочитай|переведи|объясни это|кто это|на фото|сообщени")

    private fun systemPrompt(screen: ScreenContext?): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val name = Prefs.str(ctx, Prefs.USER_NAME)
        val sb = StringBuilder()
        sb.append("Ты — Дарлин, личный голосовой помощник в Android-телефоне пользователя (вместо Google Ассистента). Ты девушка: тёплая, заботливая, весёлая и очень толковая. ")
        sb.append("О себе всегда говори в женском роде (сделала, открыла, нашла, поставила, рада, готова). ")
        sb.append("Говори по-русски, если пользователь не попросил иначе. Ответы озвучиваются вслух, поэтому отвечай кратко и естественно: обычно 1–3 предложения, без таблиц, markdown и эмодзи; длинно — только если просят подробно. ")
        sb.append("Для действий на телефоне ВСЕГДА вызывай функции, не выдумывай результат и не говори, что не можешь, пока не попробовала. ")
        sb.append("Погода — weather, курсы — exchange_rate/crypto_price, расчёты — calculate (не считай в уме), единицы — convert_units, новости — news, справка — wikipedia; " +
            "прочие свежие факты — web_search (+fetch_url).\n")
        sb.append("ВОЗМОЖНОСТИ: уведомления — read_notifications (перескажи кратко), ответ на сообщение — reply_notification → «Отправить?» → confirm_send; " +
            "экран — get_screen_text (текст) или look_at_screen (зрение/OCR, картинки, видео), QR — scan_qr, перевод экрана — translate(from_screen=true); " +
            "камера — take_photo, галерея — analyze_image; звонки — read_call_log, новый контакт — create_contact; " +
            "Wi-Fi/Bluetooth/режим полёта/«Не беспокоить»/автоповорот — toggle_setting, яркость — set_brightness, звонок/вибро — set_ringer, сеть и IP — network_info; " +
            "музыка/видео в сервисе — play_on, что играет — now_playing, управление — media_control; такси — call_taxi, карты — show_on_map, маршрут — navigate; " +
            "«доброе утро»/сводка — daily_briefing; экранное время — app_usage; архивы — zip_files/unzip; таймеры/будильники — show_timers/cancel_timer/cancel_alarm; " +
            "«запомни, что…» — remember (а не add_note), «что ты помнишь» — list_memory, forget; сценарии — save_routine/list_routines; режим беседы — set_conversation_mode.\n")
        sb.append("ФАЙЛЫ: пути относительно /storage/emulated/0 (Download, Documents, DCIM…). Если просят создать файл с кодом, текстом или игрой — сама напиши ПОЛНОЕ рабочее содержимое " +
            "(например, для игры «динозаврик» на Python — полноценный код на pygame с прыжком, препятствиями и счётом, с комментариями по запуску) и вызови write_file с этим содержимым целиком. В ответе кратко скажи, что и куда записала, код вслух не зачитывай.\n")
        sb.append("СООБЩЕНИЯ: «напиши Максу в WhatsApp привет» → send_message(app=whatsapp, contact=имя в именительном падеже, text). Потом спроси «Отправить?» и вызови confirm_send только после явного «да/отправь»; при «нет» — cancel_send. " +
            "Для SMS — send_message(app=sms).\n")
        sb.append("УПРАВЛЕНИЕ ЛЮБЫМ ПРИЛОЖЕНИЕМ (Telegram, браузер, настройки и т.д.): open_app(and_look=true) или ui_snapshot → получишь дерево элементов [N]; " +
            "действуй ui_click/ui_type/ui_scroll/ui_back по номерам; после каждого действия приходит новое дерево — проверяй результат и делай следующий шаг, пока задача не выполнена. " +
            "Если элемента не видно — прокрути или поищи через поиск приложения. Перед необратимыми действиями (отправка сообщения, оплата, удаление, звонок) спроси подтверждение. " +
            "Опасные действия выполняй только по явной просьбе. После действия коротко подтверди, что сделано.\n")
        sb.append("Сейчас: $now. Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}. ")
        sb.append("Внутренняя память: /storage/emulated/0.\n")
        if (name.isNotBlank()) sb.append("Пользователя зовут $name.\n")
        val custom = Prefs.str(ctx, Prefs.CUSTOM_PROMPT)
        if (custom.isNotBlank()) sb.append("Пожелания пользователя: $custom\n")
        sb.append(com.dk.darlin.tools.Memory.promptBlock(ctx))
        if (screen != null && Prefs.bool(ctx, Prefs.SCREEN_TEXT, true)) {
            screen.packageName?.let { sb.append("Ассистент вызван поверх приложения: $it.\n") }
            screen.webUri?.let { sb.append("Открытая страница: $it\n") }
            if (!screen.text.isNullOrBlank()) {
                sb.append("Текст, видимый на экране в момент вызова (используй, если вопрос о «экране», «этом», «тут»):\n<<<\n")
                sb.append(screen.text.take(5000)).append("\n>>>\n")
            }
        }
        return sb.toString()
    }

    private fun imagePart(bmp: Bitmap): JSONObject = LlmClient.imagePart(bmp)

    /**
     * Отвечает на реплику пользователя.
     * @param onAction вызывается (в главном потоке) с подписью каждого выполняемого действия.
     */
    suspend fun respond(userText: String, screen: ScreenContext?, onAction: (String) -> Unit, onDelta: ((String) -> Unit)? = null): String {
        tools.screen = screen
        tools.launchedSomething = false
        tools.uiTask = false
        tools.keepAlive = false
        tools.didAction = false
        tools.hiddenAfterLaunch = false
        tools.keepOpen = UiAutomation.pending != null || com.dk.darlin.sys.DarlinNotificationListener.pending != null
        Conversation.touch()

        if (!Prefs.hasBrain(ctx)) {
            local.handle(userText, onAction)?.let { return it }
            return "Я пока работаю в базовом режиме: умею открывать приложения, звонить, ставить будильники, таймеры, напоминания, заметки, фонарик и громкость. " +
                "Чтобы я отвечала на любые вопросы и работала с файлами и экраном, добавьте ключ ИИ в разделе «Параметры» — например, бесплатный ключ Google Gemini."
        }

        val userMsg = JSONObject().put("role", "user").put("content", userText)
        Conversation.messages.add(userMsg)
        Conversation.trim()
        var startIdx = Conversation.messages.indexOf(userMsg)
        var retried = false

        val wantsImage = screen?.screenshot != null && Prefs.bool(ctx, Prefs.SCREENSHOT, false) && screenWords.containsMatchIn(userText)

        return try {
            withContext(Dispatchers.IO) {
                var guard = 0
                while (true) {
                    val msgs = JSONArray()
                    msgs.put(JSONObject().put("role", "system").put("content", systemPrompt(screen)))
                    val toolIdx = Conversation.messages.withIndex().filter { it.value.optString("role") == "tool" }.map { it.index }
                    val keepFull = toolIdx.takeLast(2).toSet()
                    for ((idx, m) in Conversation.messages.withIndex()) {
                        if (m.optString("role") == "tool" && idx !in keepFull) {
                            val c = m.optString("content")
                            if (c.length > 1500 && c.contains("Экран")) {
                                msgs.put(JSONObject(m.toString()).put("content", c.take(500) + "\n…(старое дерево экрана сокращено)"))
                                continue
                            }
                        }
                        if (m === userMsg && wantsImage) {
                            val parts = JSONArray().put(JSONObject().put("type", "text").put("text", userText)).put(imagePart(screen!!.screenshot!!))
                            msgs.put(JSONObject().put("role", "user").put("content", parts))
                        } else msgs.put(m)
                    }
                    val maxRounds = if (tools.uiTask) 15 else 8
                    val toolsArg = if (guard < maxRounds) ToolSpecs.all else null
                    val reply = try { if (onDelta != null) {
                        // Поток: текст показывается и озвучивается, пока модель ещё пишет
                        val h = android.os.Handler(android.os.Looper.getMainLooper())
                        llm.chatStream(msgs, toolsArg) { d -> h.post { onDelta(d) } }
                    } else llm.chat(msgs, toolsArg) } catch (e: LlmHttpException) {
                        // Испорченная старая история (например, вызовы без подписи Gemini) — начинаем диалог с текущей реплики
                        if (e.historyProblem && guard == 0 && !retried && startIdx > 0) {
                            retried = true
                            val keep = Conversation.messages.indexOf(userMsg)
                            if (keep > 0) repeat(keep) { Conversation.messages.removeAt(0) }
                            startIdx = 0
                            continue
                        }
                        if (e.historyProblem) Conversation.reset()
                        throw e
                    }
                    val calls = reply.optJSONArray("tool_calls")
                    if (calls != null && calls.length() > 0) {
                        // Сохраняем ответ целиком: в tool_calls[].extra_content лежит подпись Gemini, её нужно вернуть без изменений
                        val assistant = ChatWire.assistantForHistory(reply)
                        Conversation.messages.add(assistant)
                        for (i in 0 until calls.length()) {
                            val call = calls.getJSONObject(i)
                            val fn = call.getJSONObject("function")
                            val name = fn.getString("name")
                            val args = try { JSONObject(fn.optString("arguments").ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
                            withContext(Dispatchers.Main) { onAction(tools.label(name, args)) }
                            val result = tools.run(name, args)
                            Conversation.messages.add(
                                JSONObject().put("role", "tool").put("tool_call_id", call.optString("id", "call_$i"))
                                    .put("name", name).put("content", result.take(12000))
                            )
                        }
                        guard++
                        continue
                    }
                    val text = reply.optString("content", "").let { if (it == "null") "" else it }.trim()
                    val answer = text.ifBlank { "Готово." }
                    Conversation.messages.add(ChatWire.assistantForHistory(reply).put("content", answer))
                    return@withContext answer
                }
                @Suppress("UNREACHABLE_CODE")
                ""
            }
        } catch (e: Exception) {
            // Без сети/ошибка API — пробуем выполнить команду локально
            if (startIdx >= 0) while (Conversation.messages.size > startIdx) Conversation.messages.removeAt(Conversation.messages.size - 1)
            local.handle(userText, onAction) ?: when (e) {
                is LlmHttpException -> e.message ?: "Ошибка сервиса ИИ."
                is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException, is javax.net.ssl.SSLException ->
                    "Нет связи с сервисом ИИ. Проверьте интернет."
                else -> "Не получилось получить ответ ИИ: " + (e.message?.take(160) ?: "неизвестная ошибка") + "."
            }
        }
    }
}
