package com.dk.darlin.tools

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Простые HTTP-запросы для информационных функций (вызывать в фоне). */
object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36 Darlin/1.0"

    fun get(url: String, max: Int = 800_000, ua: String = UA, timeoutMs: Int = 15000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = timeoutMs; c.readTimeout = timeoutMs + 5000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en;q=0.8")
        c.setRequestProperty("Accept-Encoding", "gzip")
        try {
            val code = c.responseCode
            if (code !in 200..299) throw java.io.IOException("HTTP $code")
            val raw = c.inputStream
            val ins = if (c.contentEncoding?.contains("gzip", true) == true)
                java.util.zip.GZIPInputStream(raw) else raw
            ins.use { stream ->
                // Читаем не больше нужного: не тянем всю большую страницу, раз всё равно обрежем.
                val cap = max + 4
                val buf = java.io.ByteArrayOutputStream(minOf(cap, 64 * 1024))
                val chunk = ByteArray(16 * 1024)
                while (buf.size() < cap) {
                    val n = stream.read(chunk)
                    if (n < 0) break
                    buf.write(chunk, 0, n)
                }
                val bytes = buf.toByteArray()
                val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(c.contentType ?: "")?.groupValues?.get(1)
                val enc = try { if (cs != null) charset(cs) else Charsets.UTF_8 } catch (_: Exception) { Charsets.UTF_8 }
                return String(bytes, 0, minOf(bytes.size, max), enc)
            }
        } finally { c.disconnect() }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
