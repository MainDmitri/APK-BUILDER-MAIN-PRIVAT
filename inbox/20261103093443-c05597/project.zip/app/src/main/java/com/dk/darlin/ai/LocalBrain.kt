package com.dk.darlin.ai

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Разбор простых команд без ИИ и интернета. Возвращает null, если команда не распознана. */
class LocalBrain(private val tools: ToolExecutor) {

    private val words = mapOf(
        "один" to 1, "одну" to 1, "одна" to 1, "два" to 2, "две" to 2, "три" to 3, "четыре" to 4, "пять" to 5, "шесть" to 6,
        "семь" to 7, "восемь" to 8, "девять" to 9, "десять" to 10, "одиннадцать" to 11, "двенадцать" to 12, "пятнадцать" to 15,
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "полчаса" to 30, "час" to 1
    )

    private fun num(s: String?): Int? = s?.toIntOrNull() ?: words[s?.lowercase()]

    private suspend fun exec(name: String, a: JSONObject, onAction: (String) -> Unit): String {
        onAction(tools.label(name, a))
        return tools.run(name, a)
    }

    suspend fun handle(raw: String, onAction: (String) -> Unit): String? {
        val t = raw.lowercase(Locale("ru")).replace("ё", "е").trim().trimEnd('.', '!', '?')

        // Подтверждение подготовленного сообщения
        if (UiAutomation.pending != null || com.dk.darlin.sys.DarlinNotificationListener.pending != null) {
            if (Regex("^(да|ага|угу|конечно|давай|отправь|отправляй|отправить|да отправь|верно)( .*)?$").matches(t)) return exec("confirm_send", JSONObject(), onAction)
            if (Regex("^(нет|не надо|не отправляй|отмена|отмени|стоп)( .*)?$").matches(t)) return exec("cancel_send", JSONObject(), onAction)
        }
        // «открой WhatsApp и напиши моему другу Максу привет», «напиши Максу в вотсап привет»
        val wa = "(?:whatsapp|вотсап|ватсап|вацап|воцап|ватсапп|вотсапп)"
        if (Regex(wa).containsMatchIn(t) && Regex("напиши|отправь|скажи|передай").containsMatchIn(t)) {
            val rest = t.replace(Regex("^(?:открой|зайди в|в)?\\s*$wa\\s*(?:и\\s*)?"), "")
                .replace(Regex("\\s*(?:в|во|через)\\s+$wa"), "")
            Regex("(?:напиши|отправь|скажи|передай)\\s+(?:сообщение\\s+)?(?:моему |моей |мой |моя )?(?:другу |подруге |брату |сестре |коллеге )?(\\p{L}+)\\s*[:,]?\\s*(.*)$").find(rest)?.let {
                val who = it.groupValues[1]
                val name = if (who.length > 3 && who.last() in "уеюи") who.dropLast(1) else who
                val text = it.groupValues[2].trim().ifEmpty { "Привет!" }.replaceFirstChar { c -> c.uppercase() }
                val r = exec("send_message", JSONObject().put("app", "whatsapp").put("contact", name).put("text", text), onAction)
                return if (UiAutomation.pending != null) "Открыла чат с ${UiAutomation.pending!!.who}, текст «$text». Отправить?" else r
            }
        }
        Regex("^(?:открой|запусти|включи приложение|открыть)\\s+(.+)$").find(t)?.let {
            return exec("open_app", JSONObject().put("name", it.groupValues[1]), onAction)
        }
        Regex("^(?:позвони|набери|вызов|звонок)\\s+(.+)$").find(t)?.let {
            return exec("call_phone", JSONObject().put("target", it.groupValues[1]), onAction)
        }
        Regex("(?:будильник|разбуди(?: меня)?)\\D*(\\d{1,2})(?:[:. ]|\\s*час\\w*\\s*)?(\\d{2})?").find(t)?.let {
            val h = it.groupValues[1].toInt()
            val m = it.groupValues[2].toIntOrNull() ?: 0
            val hour = if (t.contains("вечера") && h < 12) h + 12 else h
            return exec("set_alarm", JSONObject().put("hour", hour % 24).put("minute", m), onAction)
        }
        Regex("таймер\\D*?(\\d+|\\p{L}+)?\\s*(секунд|сек|минут|мин|час)").find(t)?.let {
            val n = num(it.groupValues[1]) ?: 1
            val unit = it.groupValues[2]
            val sec = when { unit.startsWith("сек") -> n; unit.startsWith("мин") -> n * 60; else -> n * 3600 }
            return exec("set_timer", JSONObject().put("seconds", sec), onAction)
        }
        if (t.contains("фонар")) {
            val on = !(t.contains("выключ") || t.contains("отключ") || t.contains("погаси"))
            return exec("flashlight", JSONObject().put("on", on), onAction)
        }
        if (Regex("котор\\w+ час|сколько (сейчас )?времени|какое (сейчас )?время").containsMatchIn(t)) {
            return "Сейчас " + SimpleDateFormat("HH:mm", Locale("ru")).format(Date())
        }
        if (Regex("какое (сегодня )?число|какой (сегодня )?день|какая (сегодня )?дата").containsMatchIn(t)) {
            return "Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("ru")).format(Date())
        }
        if (t.contains("заряд") || t.contains("батаре")) {
            return tools.run("device_info", JSONObject()).lineSequence().first()
        }
        Regex("^напомни(?: мне)?\\s+(?:через\\s+)?(\\d+|\\p{L}+)\\s*(минут\\w*|мин|час\\w*)\\s+(.+)$").find(t)?.let {
            val n = num(it.groupValues[1]) ?: return@let
            val mins = if (it.groupValues[2].startsWith("час")) n * 60 else n
            return exec("set_reminder", JSONObject().put("text", it.groupValues[3]).put("in_minutes", mins), onAction)
        }
        Regex("^запомни,?\\s+(?:что\\s+)(.+)$").find(t)?.let {
            return exec("remember", JSONObject().put("fact", raw.trim().replace(Regex("(?i)^запомни,?\\s+что\\s+"), "")), onAction)
        }
        if (Regex("^(?:что ты (?:обо мне )?помнишь|что ты знаешь обо мне|покажи память)$").matches(t)) return exec("list_memory", JSONObject(), onAction)
        if (Regex("^(?:доброе утро|сводка дня|утренняя сводка|что сегодня|какие планы на сегодня)$").matches(t)) return exec("daily_briefing", JSONObject(), onAction)
        Regex("^(?:какая |какая сейчас )?погода(?:\\s+(?:в|во)\\s+(.+?))?(?:\\s+(сегодня|завтра|послезавтра))?$").find(t)?.let {
            val day = when (it.groupValues[2]) { "завтра" -> 1; "послезавтра" -> 2; else -> 0 }
            return exec("weather", JSONObject().put("city", it.groupValues[1]).put("day", day), onAction)
        }
        Regex("^(?:курс|какой курс)\\s+(доллара|евро|юаня|фунта|биткоина|биткоин|эфира|тенге|лиры)$").find(t)?.let {
            val w = it.groupValues[1]
            return if (w.startsWith("битко") || w.startsWith("эфир")) exec("crypto_price", JSONObject().put("coin", if (w.startsWith("эфир")) "эфир" else "биткоин"), onAction)
            else exec("exchange_rate", JSONObject().put("from", mapOf("доллара" to "USD", "евро" to "EUR", "юаня" to "CNY", "фунта" to "GBP", "тенге" to "KZT", "лиры" to "TRY")[w] ?: "USD"), onAction)
        }
        Regex("^(?:сколько будет|посчитай|вычисли)\\s+(.+)$").find(t)?.let {
            return exec("calculate", JSONObject().put("expression", it.groupValues[1]), onAction)
        }
        if (Regex("^(?:новости|что нового|главные новости)$").matches(t)) return exec("news", JSONObject(), onAction)
        if (Regex("^(?:что играет|что за песня|что сейчас играет)$").matches(t)) return exec("now_playing", JSONObject(), onAction)
        if (Regex("^(?:прочитай |покажи |какие )?уведомления$").matches(t)) return exec("read_notifications", JSONObject(), onAction)
        if (t.contains("qr") || t.contains("куар") || t.contains("кьюар")) return exec("scan_qr", JSONObject(), onAction)
        Regex("^(?:запомни|заметка|запиши|создай заметку)[:,]?\\s+(.+)$").find(t)?.let {
            return exec("add_note", JSONObject().put("text", raw.substringAfter(' ').trim()), onAction)
        }
        if (Regex("^(?:покажи |мои )?заметки$").matches(t)) return exec("list_notes", JSONObject(), onAction)
        if (t == "громче" || t.contains("сделай громче") || t.contains("прибавь")) return exec("set_volume", JSONObject().put("direction", "up"), onAction)
        if (t == "тише" || t.contains("сделай тише") || t.contains("убавь")) return exec("set_volume", JSONObject().put("direction", "down"), onAction)
        if (t.contains("следующ") && (t.contains("трек") || t.contains("песн"))) return exec("media_control", JSONObject().put("action", "next"), onAction)
        if (t == "пауза" || t.contains("поставь на паузу")) return exec("media_control", JSONObject().put("action", "pause"), onAction)
        if (t == "назад") return exec("global_action", JSONObject().put("action", "back"), onAction)
        if (t == "домой" || t.contains("на главный экран")) return exec("global_action", JSONObject().put("action", "home"), onAction)
        if (t.contains("скриншот") || t.contains("снимок экрана")) return exec("global_action", JSONObject().put("action", "screenshot"), onAction)
        Regex("(?:настройки|открой настройки)\\s+(wi-?fi|вай ?фай|блютуз|bluetooth|экрана|звука|батареи)").find(t)?.let {
            val page = when {
                it.groupValues[1].contains("фай") || it.groupValues[1].contains("wi") -> "wifi"
                it.groupValues[1].contains("блют") || it.groupValues[1].contains("blue") -> "bluetooth"
                it.groupValues[1].contains("экран") -> "display"
                it.groupValues[1].contains("звук") -> "sound"
                else -> "battery"
            }
            return exec("open_settings", JSONObject().put("page", page), onAction)
        }
        if (t.contains("вай фай") || t.contains("wi-fi") || t.contains("wifi") || t.contains("вайфай")) return exec("open_settings", JSONObject().put("page", "wifi"), onAction)
        if (t.contains("блютуз") || t.contains("bluetooth")) return exec("open_settings", JSONObject().put("page", "bluetooth"), onAction)
        Regex("^(?:маршрут|проложи маршрут|как доехать|навигация)\\s+(?:до\\s+|к\\s+|в\\s+)?(.+)$").find(t)?.let {
            return exec("navigate", JSONObject().put("destination", it.groupValues[1]), onAction)
        }
        Regex("^(?:включи музыку|включи песню|включи|поставь)\\s+(.+)$").find(t)?.let {
            return exec("play_music", JSONObject().put("query", it.groupValues[1]), onAction)
        }
        Regex("^(?:найди в интернете|найди|погугли|поищи|загугли)\\s+(.+)$").find(t)?.let {
            return exec("open_url", JSONObject().put("url_or_query", it.groupValues[1]), onAction)
        }
        return null
    }
}
