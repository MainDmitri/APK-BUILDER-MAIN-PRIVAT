package com.dk.darlin.sys

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Bundle
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Доступ к уведомлениям: Дарлин может прочитать и пересказать уведомления, ответить на сообщение
 * (через кнопку «Ответить» в уведомлении — только после подтверждения) и управлять любым плеером через MediaSession.
 */
class DarlinNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn ?: return
        if (n.packageName == packageName) return
        val item = toItem(this, n) ?: return
        synchronized(recent) {
            recent.removeAll { it.key == item.key && it.text == item.text }
            recent.addLast(item)
            while (recent.size > 80) recent.removeFirst()
        }
    }

    data class Item(
        val key: String, val pkg: String, val app: String, val title: String, val text: String, val time: Long,
        val replyAction: Notification.Action?, val isMessage: Boolean, val ongoing: Boolean
    )

    data class PendingReply(val item: Item, val text: String)

    companion object {
        @Volatile var instance: DarlinNotificationListener? = null
        private val recent = ArrayDeque<Item>()
        @Volatile var pending: PendingReply? = null

        fun component(c: Context) = ComponentName(c, DarlinNotificationListener::class.java)

        fun isEnabled(c: Context): Boolean {
            val flat = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.split(':').any { ComponentName.unflattenFromString(it)?.packageName == c.packageName }
        }

        fun settingsIntent(): Intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)

        fun appLabel(c: Context, pkg: String): String = try {
            val pm = c.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: PackageManager.NameNotFoundException) { pkg }

        fun toItem(c: Context, sbn: StatusBarNotification): Item? {
            val n = sbn.notification ?: return null
            val ex: Bundle = n.extras ?: Bundle()
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
            val title = (ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: ex.getCharSequence(Notification.EXTRA_TITLE))?.toString() ?: ""
            var text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
            // Сообщения в стиле MessagingStyle: берём последние реплики
            @Suppress("DEPRECATION")
            val msgs = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (msgs != null && msgs.isNotEmpty()) {
                val parts = msgs.takeLast(4).mapNotNull { p ->
                    val b = p as? Bundle ?: return@mapNotNull null
                    val who = b.getCharSequence("sender")?.toString()
                    val t = b.getCharSequence("text")?.toString() ?: return@mapNotNull null
                    if (who.isNullOrBlank() || who == title) t else "$who: $t"
                }
                if (parts.isNotEmpty()) text = parts.joinToString(" / ")
            }
            if (title.isBlank() && text.isBlank()) return null
            val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }
            return Item(
                sbn.key, sbn.packageName, appLabel(c, sbn.packageName), title, text.take(600), sbn.postTime, reply,
                n.category == Notification.CATEGORY_MESSAGE || reply != null, sbn.isOngoing
            )
        }

        /** Активные уведомления (кроме своих и постоянных системных), новые сверху. */
        fun active(c: Context): List<Item> {
            val s = instance ?: return emptyList()
            val list = try { s.activeNotifications?.toList() ?: emptyList() } catch (_: Exception) { emptyList() }
            return list.filter { it.packageName != c.packageName }.mapNotNull { toItem(c, it) }
                .filterNot { it.ongoing && !it.isMessage }.sortedByDescending { it.time }
        }

        fun recentItems(): List<Item> = synchronized(recent) { recent.toList().asReversed() }

        private fun matches(i: Item, app: String, who: String): Boolean {
            val a = app.lowercase().trim(); val w = who.lowercase().trim()
            val okApp = a.isBlank() || i.app.lowercase().contains(a) || i.pkg.lowercase().contains(a) ||
                (a.contains("ватс") && i.pkg.contains("whatsapp")) || (a.contains("телег") && i.pkg.contains("telegram")) ||
                (a.contains("вк") && i.pkg.contains("vkontakte")) || (a.contains("смс") && (i.pkg.contains("messaging") || i.pkg.contains("mms")))
            val okWho = w.isBlank() || i.title.lowercase().contains(w) || i.text.lowercase().contains(w) ||
                (w.length > 3 && i.title.lowercase().contains(w.dropLast(1)))
            return okApp && okWho
        }

        fun read(c: Context, app: String, limit: Int, onlyMessages: Boolean): String {
            if (instance == null) return if (isEnabled(c)) "Доступ к уведомлениям включён, но служба ещё не подключилась — попробуйте через пару секунд."
            else "Нет доступа к уведомлениям. Включите его: Дарлин → «Настройка» → «Доступ к уведомлениям»."
            var items = active(c).filter { matches(it, app, "") }
            if (onlyMessages) items = items.filter { it.isMessage }
            if (items.isEmpty()) {
                val rec = recentItems().filter { matches(it, app, "") && (!onlyMessages || it.isMessage) }
                if (rec.isEmpty()) return if (app.isBlank()) "Новых уведомлений нет." else "Уведомлений от «$app» нет."
                items = rec
            }
            val fmt = SimpleDateFormat("HH:mm", Locale.US)
            val shown = items.take(limit.coerceIn(1, 30))
            return "Уведомления (${items.size}):\n" + shown.joinToString("\n") {
                "• ${fmt.format(Date(it.time))} ${it.app}: ${it.title}" + (if (it.text.isNotBlank()) " — ${it.text.take(300)}" else "") + (if (it.replyAction != null) " [можно ответить]" else "")
            }
        }

        /** Готовит ответ; отправка — только после confirm_send. */
        fun prepareReply(c: Context, app: String, who: String, text: String): String {
            if (instance == null) return "Нет доступа к уведомлениям — включите его в «Настройке», чтобы отвечать из уведомлений."
            if (text.isBlank()) return "Какой текст ответить?"
            val cand = (active(c) + recentItems()).filter { it.replyAction != null && matches(it, app, who) }
            val item = cand.maxByOrNull { it.time }
                ?: return "Не нашла уведомление с кнопкой «Ответить»" + (if (who.isNotBlank()) " от «$who»" else "") + (if (app.isNotBlank()) " в «$app»" else "") + "."
            pending = PendingReply(item, text)
            return "Готов ответ в ${item.app} для «${item.title}»: «$text». Ещё НЕ отправлено — спроси пользователя «Отправить?» и вызови confirm_send только после явного «да»."
        }

        fun confirmReply(c: Context): String {
            val p = pending ?: return "Нет подготовленного ответа."
            pending = null
            val action = p.item.replyAction ?: return "У уведомления нет кнопки ответа."
            val inputs = action.remoteInputs ?: return "У уведомления нет поля ответа."
            val intent = Intent()
            val res = Bundle()
            for (ri in inputs) res.putCharSequence(ri.resultKey, p.text)
            RemoteInput.addResultsToIntent(inputs, intent, res)
            return try {
                action.actionIntent.send(c, 0, intent)
                "Ответ «${p.text}» отправлен в ${p.item.app} (${p.item.title})."
            } catch (e: PendingIntent.CanceledException) { "Уведомление уже неактуально — откройте чат и ответьте там." }
        }

        fun cancelReply(): String { pending = null; return "Ответ отменён." }

        fun dismiss(c: Context, app: String): String {
            val s = instance ?: return "Нет доступа к уведомлениям."
            if (app.isBlank()) { s.cancelAllNotifications(); return "Убрала все уведомления, которые можно смахнуть." }
            val items = active(c).filter { matches(it, app, "") }
            if (items.isEmpty()) return "Уведомлений от «$app» нет."
            items.forEach { try { s.cancelNotification(it.key) } catch (_: Exception) {} }
            return "Убрала уведомления: ${items.size}."
        }

        // ---------- Медиа ----------
        fun controllers(c: Context): List<MediaController> {
            if (!isEnabled(c)) return emptyList()
            return try {
                val msm = c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                msm.getActiveSessions(component(c))
            } catch (_: SecurityException) { emptyList() } catch (_: Exception) { emptyList() }
        }

        fun nowPlaying(c: Context): String? {
            val list = controllers(c)
            if (list.isEmpty()) return null
            val mc = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.first()
            val md = mc.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            val playing = mc.playbackState?.state == PlaybackState.STATE_PLAYING
            val app = appLabel(c, mc.packageName)
            if (title.isNullOrBlank()) return "$app: ${if (playing) "играет" else "на паузе"}."
            return "${if (playing) "Сейчас играет" else "На паузе"} в $app: «$title»" + (if (!artist.isNullOrBlank()) " — $artist" else "") + "."
        }

        /** true — выполнено через MediaSession. */
        fun mediaAction(c: Context, action: String): Boolean {
            val list = controllers(c)
            val mc = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull() ?: return false
            val t = mc.transportControls
            when (action) {
                "play" -> t.play(); "pause" -> t.pause(); "stop" -> t.stop()
                "toggle" -> if (mc.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                "next" -> t.skipToNext(); "previous" -> t.skipToPrevious()
                "forward" -> t.seekTo((mc.playbackState?.position ?: 0) + 30_000)
                "rewind" -> t.seekTo(maxOf(0, (mc.playbackState?.position ?: 0) - 15_000))
                else -> return false
            }
            return true
        }
    }
}
