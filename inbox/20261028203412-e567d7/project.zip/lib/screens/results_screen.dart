// [context: Flutter/Dart 3.13.5, iOS-only, results viewer v3 premium]
// *trophy room — every camera the scanner ever found*

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/scan_result.dart';
import '../services/result_storage.dart';
import '../theme/palette.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});
  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  List<ScanResult> _results = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final r = await ResultStorage.loadAll();
    if (mounted) setState(() { _results = r; _loading = false; });
  }

  Future<void> _clearAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kSurfCon,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Clear all results?',
            style: TextStyle(color: kOnSurf, fontWeight: FontWeight.w700)),
        content: Text(
          'Permanently delete ${_results.length} saved cameras.',
          style: const TextStyle(color: kOutlineBr),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: kOutlineBr)),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: kError),
            child: const Text('Delete all'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await ResultStorage.clearAll();
      _load();
    }
  }

  // BUG FIX: snapshot BEFORE await, bounds check, no stale-index crash
  Future<void> _deleteAt(int idx) async {
    final snapshot = List<ScanResult>.from(_results);
    if (idx < 0 || idx >= snapshot.length) return;
    snapshot.removeAt(idx);
    await ResultStorage.clearAll();
    for (final r in snapshot.reversed) {
      await ResultStorage.addResult(r);
    }
    _load();
  }

  void _copyAll() {
    final buf = StringBuffer();
    for (final r in _results) {
      buf.writeln('${r.ip}:${r.port} | ${r.brand} | ${r.credentialLabel}');
    }
    Clipboard.setData(ClipboardData(text: buf.toString().trim()));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Copied ${_results.length} entries')));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: kSurfDark,
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: kPrimary))
          : RefreshIndicator(
              color:           kPrimary,
              backgroundColor: kSurfCon,
              onRefresh:       _load,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  // ── Header ─────────────────────────────────────────────────
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 18, 16, 14),
                      child: Row(
                        children: [
                          _results.isEmpty
                              ? const Icon(Icons.bookmark_border_rounded,
                                  size: 18, color: kOutlineBr)
                              : _CountPill('${_results.length}'),
                          const SizedBox(width: 8),
                          const Text('SAVED',
                              style: TextStyle(
                                color:         kOutlineBr,
                                fontSize:      10,
                                fontWeight:    FontWeight.w700,
                                letterSpacing: 1.8,
                              )),
                          const Spacer(),
                          if (_results.isNotEmpty) ...[
                            _HeaderBtn(
                              icon:  Icons.copy_all_rounded,
                              label: 'Copy all',
                              onTap: _copyAll,
                            ),
                            const SizedBox(width: 8),
                            _HeaderBtn(
                              icon:  Icons.delete_sweep_rounded,
                              label: 'Clear',
                              color: kError,
                              onTap: _clearAll,
                            ),
                          ],
                          const SizedBox(width: 8),
                          _HeaderBtn(
                            icon:  Icons.refresh_rounded,
                            label: 'Refresh',
                            onTap: _load,
                          ),
                        ],
                      ),
                    ),
                  ),

                  // ── Empty state ─────────────────────────────────────────────
                  if (_results.isEmpty)
                    SliverFillRemaining(
                      hasScrollBody: false,
                      child: _EmptyState(),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 30),
                      sliver: SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (ctx, i) => _AnimatedCard(
                            index:    i,
                            child:    _SavedCard(
                              r:        _results[i],
                              onDelete: () => _deleteAt(i),
                            ),
                          ),
                          childCount: _results.length,
                        ),
                      ),
                    ),
                ],
              ),
            ),
    );
  }
}

// ── Animated list entry ───────────────────────────────────────────────────────
class _AnimatedCard extends StatefulWidget {
  final int    index;
  final Widget child;
  const _AnimatedCard({required this.index, required this.child});
  @override
  State<_AnimatedCard> createState() => _AnimatedCardState();
}

class _AnimatedCardState extends State<_AnimatedCard>
    with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  late final Animation<double>   _fade;
  late final Animation<Offset>   _slide;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync:    this,
      duration: Duration(milliseconds: 300 + widget.index * 30),
    );
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _slide = Tween<Offset>(
      begin: const Offset(0, 0.08),
      end:   Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutCubic));
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _fade,
        child: SlideTransition(
          position: _slide,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: widget.child,
          ),
        ),
      );
}

// ── Count pill ────────────────────────────────────────────────────────────────
class _CountPill extends StatelessWidget {
  final String text;
  const _CountPill(this.text);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
        decoration: BoxDecoration(
          color:        kSuccess.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
          border:       Border.all(color: kSuccess.withOpacity(0.3)),
        ),
        child: Text(text,
            style: const TextStyle(
                color: kSuccess, fontSize: 13, fontWeight: FontWeight.w800)));
}

// ── Header button ─────────────────────────────────────────────────────────────
class _HeaderBtn extends StatelessWidget {
  final IconData     icon;
  final String       label;
  final Color        color;
  final VoidCallback onTap;
  const _HeaderBtn({required this.icon, required this.label,
                    required this.onTap, this.color = kOutlineBr});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color:        color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(8),
            border:       Border.all(color: color.withOpacity(0.25)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 14, color: color),
              const SizedBox(width: 4),
              Text(label, style: TextStyle(
                  color: color, fontSize: 11, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );
}

// ── Empty state ───────────────────────────────────────────────────────────────
class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color:  kSurfHigh,
                shape:  BoxShape.circle,
                border: Border.all(color: kOutline.withOpacity(0.4)),
              ),
              child: const Icon(Icons.bookmark_border_rounded,
                  size: 32, color: kOutlineBr),
            ),
            const SizedBox(height: 16),
            const Text('No saved cameras',
                style: TextStyle(
                    color: kOnSurf, fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text('Pull to refresh or start a scan',
                style: TextStyle(color: kOutlineBr, fontSize: 13)),
          ],
        ),
      );
}

// ── Saved card ────────────────────────────────────────────────────────────────
class _SavedCard extends StatefulWidget {
  final ScanResult   r;
  final VoidCallback onDelete;
  const _SavedCard({required this.r, required this.onDelete});
  @override
  State<_SavedCard> createState() => _SavedCardState();
}

class _SavedCardState extends State<_SavedCard> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final blocked = widget.r.blocked;
    final accent  = blocked ? kWarning : kBrandColor(widget.r.brand);
    final cred    = widget.r.credentialLabel;
    final now     = widget.r.foundAt;
    final date    = '${now.day.toString().padLeft(2,'0')}'
        '.${now.month.toString().padLeft(2,'0')}'
        ' ${now.hour.toString().padLeft(2,'0')}'
        ':${now.minute.toString().padLeft(2,'0')}';

    return GestureDetector(
      onTapDown:  (_) { if (!blocked) setState(() => _pressed = true); },
      onTapUp:    (_) {
        setState(() => _pressed = false);
        if (!blocked) {
          Clipboard.setData(ClipboardData(text: cred));
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content:  Text('Copied  $cred'),
              duration: const Duration(seconds: 1),
            ),
          );
        }
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale:    _pressed ? 0.975 : 1.0,
        duration: const Duration(milliseconds: 100),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            color:        _pressed ? accent.withOpacity(0.04) : kSurfCon,
            borderRadius: BorderRadius.circular(16),
            border:       Border.all(color: accent.withOpacity(_pressed ? 0.45 : 0.25)),
            boxShadow: [
              BoxShadow(
                color:     accent.withOpacity(_pressed ? 0.12 : 0.05),
                blurRadius: _pressed ? 18 : 10,
                offset:    const Offset(0, 3),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Top row ────────────────────────────────────────────────
                Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 180),
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color:        accent.withOpacity(_pressed ? 0.2 : 0.1),
                        borderRadius: BorderRadius.circular(10),
                        border:       Border.all(color: accent.withOpacity(0.3)),
                      ),
                      child: Icon(
                        blocked ? Icons.lock_rounded : Icons.videocam_rounded,
                        color: accent, size: 20,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [
                            Text(widget.r.ip,
                                style: const TextStyle(
                                    color: kOnSurf, fontWeight: FontWeight.w700,
                                    fontSize: 14, fontFamily: 'Menlo')),
                            Text(':${widget.r.port}',
                                style: TextStyle(
                                    color: accent, fontWeight: FontWeight.w700,
                                    fontSize: 14, fontFamily: 'Menlo')),
                          ]),
                          Text(date,
                              style: const TextStyle(color: kOutlineBr, fontSize: 10)),
                        ],
                      ),
                    ),
                    // Delete
                    GestureDetector(
                      onTap: widget.onDelete,
                      child: Container(
                        width: 32, height: 32,
                        decoration: BoxDecoration(
                          color:        kError.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(8),
                          border:       Border.all(color: kError.withOpacity(0.2)),
                        ),
                        child: const Icon(Icons.delete_outline_rounded,
                            size: 16, color: kError),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                // ── Pills ──────────────────────────────────────────────────
                Wrap(
                  spacing: 6,
                  children: [
                    _Pill(widget.r.brand, accent),
                    if (widget.r.model.isNotEmpty) _Pill(widget.r.model, kOutlineBr),
                    if (widget.r.channels > 1) _Pill('${widget.r.channels}ch', kSecondary),
                  ],
                ),
                const SizedBox(height: 8),
                // ── Credentials ────────────────────────────────────────────
                if (blocked)
                  Row(children: [
                    const Icon(Icons.block_rounded, size: 12, color: kWarning),
                    const SizedBox(width: 4),
                    const Text('Blocked by device',
                        style: TextStyle(color: kWarning, fontSize: 12)),
                  ])
                else
                  Container(
                    width:   double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color:        kSurfXHigh,
                      borderRadius: BorderRadius.circular(10),
                      border:       Border.all(color: kOutline.withOpacity(0.4)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.key_rounded, size: 13, color: kOutlineBr),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(cred,
                            style: const TextStyle(
                                color:      kSecondary,
                                fontSize:   13,
                                fontFamily: 'Menlo',
                                fontWeight: FontWeight.w500)),
                      ),
                      const Icon(Icons.copy_rounded, size: 13, color: kOutlineBr),
                    ]),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color  color;
  const _Pill(this.text, this.color);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(
          color:        color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(text,
            style: TextStyle(
                color: color, fontSize: 10, fontWeight: FontWeight.w700)));
}
