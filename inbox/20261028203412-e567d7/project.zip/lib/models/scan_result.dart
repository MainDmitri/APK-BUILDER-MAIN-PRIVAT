// [context: Flutter/Dart 3.13.5, iOS-only, scan result data model]
// *the vessel — every crack in the device funnel through this struct*

import 'dart:typed_data';

class ScanResult {
  final String    ip;
  final int       port;
  final String    brand;
  final String    login;
  final String    password;
  final String    model;
  final int       channels;
  final Uint8List? snapshot;
  final bool      blocked;
  final DateTime  foundAt;

  ScanResult({
    required this.ip,
    required this.port,
    required this.brand,
    required this.login,
    required this.password,
    this.model    = '',
    this.channels = 1,
    this.snapshot,
    this.blocked  = false,
    DateTime? foundAt,
  }) : foundAt = foundAt ?? DateTime.now();

  String get credentialLabel =>
      (login.isEmpty && password.isEmpty) ? '(open)' : '$login:$password';

  bool get isTerminal => const {'SSH-TTY', 'Telnet-TTY', 'VPS'}.contains(brand);

  Map<String, dynamic> toMap() => {
    'ip':        ip,
    'port':      port,
    'brand':     brand,
    'login':     login,
    'password':  password,
    'model':     model,
    'channels':  channels,
    'blocked':   blocked ? 1 : 0,
    'found_at':  foundAt.millisecondsSinceEpoch,
  };

  factory ScanResult.fromMap(Map<String, dynamic> m) => ScanResult(
    ip:       m['ip']       as String,
    port:     m['port']     as int,
    brand:    m['brand']    as String,
    login:    m['login']    as String,
    password: m['password'] as String,
    model:    (m['model']   as String?) ?? '',
    channels: (m['channels'] as int?) ?? 1,
    blocked:  ((m['blocked'] as int?) ?? 0) == 1,
    foundAt:  DateTime.fromMillisecondsSinceEpoch(m['found_at'] as int),
  );
}

class ScanProgress {
  final int  total;
  final int  checked;
  final int  found;
  final int  blocked;
  final int  openPorts;
  final int  elapsedMs;
  final bool finished;
  final bool cancelled;

  const ScanProgress({
    required this.total,
    this.checked   = 0,
    this.found     = 0,
    this.blocked   = 0,
    this.openPorts = 0,
    this.elapsedMs = 0,
    this.finished  = false,
    this.cancelled = false,
  });

  // compat getters so old scan_screen code still works
  int get successful => found;
}
