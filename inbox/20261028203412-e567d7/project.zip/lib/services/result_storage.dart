// [context: Flutter/Dart 3.13.5, sqflite, SQLite persistent result store]
// *the database keeps every hit until the operator decides to clean house*

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/scan_result.dart';

class ResultStorage {
  static Database? _db;

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir  = await getDatabasesPath();
    final path = join(dir, 'scan_results.db');
    _db = await openDatabase(
      path,
      version: 2,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE results (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            ip        TEXT    NOT NULL,
            port      INTEGER NOT NULL,
            brand     TEXT    NOT NULL,
            login     TEXT    NOT NULL,
            password  TEXT    NOT NULL,
            model     TEXT    NOT NULL DEFAULT '',
            channels  INTEGER NOT NULL DEFAULT 1,
            blocked   INTEGER NOT NULL DEFAULT 0,
            found_at  INTEGER NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_ip ON results(ip)');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          // migrate: add channels, drop old open_ports / all_ports (SQLite can't DROP COLUMN
          // below 3.35 so we rebuild the table)
          await db.execute('''
            CREATE TABLE results_new (
              id        INTEGER PRIMARY KEY AUTOINCREMENT,
              ip        TEXT    NOT NULL,
              port      INTEGER NOT NULL,
              brand     TEXT    NOT NULL,
              login     TEXT    NOT NULL,
              password  TEXT    NOT NULL,
              model     TEXT    NOT NULL DEFAULT '',
              channels  INTEGER NOT NULL DEFAULT 1,
              blocked   INTEGER NOT NULL DEFAULT 0,
              found_at  INTEGER NOT NULL
            )
          ''');
          await db.execute('''
            INSERT INTO results_new (id, ip, port, brand, login, password, model, channels, blocked, found_at)
            SELECT id, ip, port, brand, login, password, model, 1, blocked, found_at FROM results
          ''');
          await db.execute('DROP TABLE results');
          await db.execute('ALTER TABLE results_new RENAME TO results');
          await db.execute('CREATE INDEX IF NOT EXISTS idx_ip ON results(ip)');
        }
      },
    );
    return _db!;
  }

  // ── write ──────────────────────────────────────────────────────────────────

  static Future<int> addResult(ScanResult r) async {
    final db  = await _open();
    return db.insert('results', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ── read ───────────────────────────────────────────────────────────────────

  static Future<List<ScanResult>> loadAll() async {
    final db   = await _open();
    final rows = await db.query('results', orderBy: 'found_at DESC');
    return rows.map(ScanResult.fromMap).toList();
  }

  static Future<List<ScanResult>> loadRecent(int limit) async {
    final db   = await _open();
    final rows = await db.query('results', orderBy: 'found_at DESC', limit: limit);
    return rows.map(ScanResult.fromMap).toList();
  }

  static Future<int> count() async {
    final db  = await _open();
    final res = await db.rawQuery('SELECT COUNT(*) as c FROM results');
    return (res.first['c'] as int?) ?? 0;
  }

  // ── delete ─────────────────────────────────────────────────────────────────

  static Future<void> deleteById(int id) async {
    final db = await _open();
    await db.delete('results', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> clearAll() async {
    final db = await _open();
    await db.delete('results');
  }
}
