// [context: Flutter/Dart 3.13.5, iOS-only, HMAC-SHA256 activation, AES-256/CBC device lock]
// *the gatekeeper — no valid code, no scanner; every byte of this mirrors AuthManager.kt*

import 'dart:convert';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ── constants (mirrors AuthManager.kt) ────────────────────────────────────────
const _secretKey  = 'MainDmitri_secret_2024_xK9m';
const _codeAlpha  = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // 32 chars, no I/O/1/0
const _saltAdmin  = 'slt_x9k';
const _adminHash  = // sha256("MainC4yt552" + "slt_x9k") — pre-computed once
    'b8c4d2e6f1a3b7c9d5e2f4a6b8c1d3e5f7a9b2c4d6e8f0a1b3c5d7e9f1a3b5'; // placeholder computed below

// ─── AuthService ──────────────────────────────────────────────────────────────

class AuthService {

  // ── generate activation code from nickname (mirrors AuthManager.kt) ──────────
  // mac = HmacSHA256(key=SECRET_KEY, data=nickname.trim().lowercase())
  // code chars = CODEAPLPHA[ hash[i] % 32 ] for i in 0..11
  // formatted as XXXX-XXXX-XXXX
  static String generateCode(String nickname) {
    final keyBytes  = utf8.encode(_secretKey);
    final dataBytes = utf8.encode(nickname.trim().toLowerCase());
    final hmac      = Hmac(sha256, keyBytes);
    final digest    = hmac.convert(dataBytes);
    final hash      = Uint8List.fromList(digest.bytes);

    final sb = StringBuffer();
    for (int i = 0; i < 12; i++) {
      sb.write(_codeAlpha[hash[i] & 0xFF % _codeAlpha.length]);
    }
    final raw = sb.toString();
    return '${raw.substring(0, 4)}-${raw.substring(4, 8)}-${raw.substring(8, 12)}';
  }

  // ── verify activation: code matches nickname ──────────────────────────────────
  static bool verifyCode(String nickname, String code) {
    final expected = generateCode(nickname);
    return expected == code.toUpperCase().trim();
  }

  // ── compute lockHash (mirrors AuthManager.kt) ─────────────────────────────────
  // lockHash = sha256( deviceId + code + nickname )
  static String computeLockHash(String deviceId, String code, String nickname) {
    final raw  = deviceId + code + nickname;
    final hash = sha256.convert(utf8.encode(raw));
    return hash.toString();
  }

  // ── check if activated (prefs key 'activated' == true) ───────────────────────
  static Future<bool> isActivated() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('activated') ?? false;
  }

  // ── save activation after successful code check ───────────────────────────────
  static Future<void> saveActivation({
    required String nickname,
    required String code,
    required String deviceId,
  }) async {
    final lockHash = computeLockHash(deviceId, code, nickname);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('activated', true);
    await prefs.setString('nickname', nickname);
    await prefs.setString('code', code);
    await prefs.setString('device_id', deviceId);
    await prefs.setString('lock_hash', lockHash);
  }

  // ── verify device lock on cold start ─────────────────────────────────────────
  // recomputes lockHash and compares to stored — detects deviceId changes
  static Future<bool> verifyDeviceLock() async {
    final prefs    = await SharedPreferences.getInstance();
    final nickname = prefs.getString('nickname') ?? '';
    final code     = prefs.getString('code') ?? '';
    final deviceId = prefs.getString('device_id') ?? '';
    final stored   = prefs.getString('lock_hash') ?? '';
    if (nickname.isEmpty || code.isEmpty || deviceId.isEmpty || stored.isEmpty) {
      return false;
    }
    final expected = computeLockHash(deviceId, code, nickname);
    return expected == stored;
  }

  // ── admin password check ──────────────────────────────────────────────────────
  // sha256(password + "slt_x9k") == sha256("MainC4yt552" + "slt_x9k")
  static bool checkAdminPassword(String password) {
    final candidate = sha256.convert(utf8.encode(password + _saltAdmin)).toString();
    final reference = sha256.convert(utf8.encode('MainC4yt552' + _saltAdmin)).toString();
    return candidate == reference;
  }

  // ── get stored nickname ───────────────────────────────────────────────────────
  static Future<String> getNickname() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('nickname') ?? '';
  }

  // ── get stored deviceId ───────────────────────────────────────────────────────
  static Future<String> getDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('device_id') ?? '';
  }

  // ── clear activation (admin reset) ───────────────────────────────────────────
  static Future<void> clearActivation() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('activated');
    await prefs.remove('nickname');
    await prefs.remove('code');
    await prefs.remove('device_id');
    await prefs.remove('lock_hash');
  }

  // ── compat aliases used by auth_screen.dart ──────────────────────────────────
  static String generateCodeForNickname(String nickname) => generateCode(nickname);
  static bool verifyAdminPassword(String password) => checkAdminPassword(password);

  // ── activate: verify code then persist ───────────────────────────────────────
  // Returns null on success, error string on failure.
  static Future<String?> activate(String nickname, String code) async {
    if (nickname.trim().isEmpty) return 'Nickname cannot be empty';
    if (!verifyCode(nickname.trim(), code.trim())) return 'Invalid activation code';
    // generate or reuse device id
    final prefs    = await SharedPreferences.getInstance();
    String deviceId = prefs.getString('device_id') ?? '';
    if (deviceId.isEmpty) {
      // generate persistent device id from random bytes
      final bytes = List<int>.generate(16, (_) => DateTime.now().microsecondsSinceEpoch & 0xFF);
      deviceId = sha256.convert(bytes).toString().substring(0, 16);
    }
    await saveActivation(nickname: nickname.trim(), code: code.trim(), deviceId: deviceId);
    return null;
  }
}
