// [context: Flutter/Dart 3.13.5, iOS-only — shared color palette]
// *single source of truth; import this everywhere, touch nothing else*

import 'package:flutter/material.dart';

// ── Base surfaces ─────────────────────────────────────────────────────────────
const Color kSurfDark  = Color(0xFF0A0305); // page background
const Color kSurfCon   = Color(0xFF120810); // card background
const Color kSurfHigh  = Color(0xFF1C1020); // elevated surface (chips, inputs)
const Color kSurfXHigh = Color(0xFF251428); // extra-elevated (credential box)

// ── Brand ─────────────────────────────────────────────────────────────────────
const Color kPrimary   = Color(0xFF7B1C2E); // wine red — buttons, active chips
const Color kOnPrimary = Color(0xFFFFFFFF); // text on primary
const Color kSecondary = Color(0xFFCE93A8); // muted rose — credential text

// ── Semantic ──────────────────────────────────────────────────────────────────
const Color kSuccess   = Color(0xFF4CAF7D); // found counter, open port
const Color kWarning   = Color(0xFFFFB830); // blocked camera
const Color kError     = Color(0xFFCF6679); // delete, stop button

// ── Text & outlines ───────────────────────────────────────────────────────────
const Color kOnSurf    = Color(0xFFEEE0E8); // primary text
const Color kOutlineBr = Color(0xFF8B4D58); // dimmed text / borders
const Color kOutline   = Color(0xFF3D2035); // subtle divider / border

// ── Per-brand accent helper ───────────────────────────────────────────────────
Color kBrandColor(String brand) {
  return switch (brand.toLowerCase()) {
    String b when b.contains('dahua')   => const Color(0xFF2196F3),
    String b when b.contains('hikvis')  => const Color(0xFFFF5252),
    String b when b.contains('xmeye')   => const Color(0xFF9C27B0),
    String b when b.contains('reolink') => const Color(0xFF4CAF50),
    String b when b.contains('axis')    => const Color(0xFFFF9800),
    String b when b.contains('telnet')  => const Color(0xFF607D8B),
    String b when b.contains('ssh')     => const Color(0xFF009688),
    _                                   => kPrimary,
  };
}
