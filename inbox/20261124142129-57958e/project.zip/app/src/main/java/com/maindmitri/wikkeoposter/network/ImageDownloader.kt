package com.maindmitri.wikkeoposter.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ImageDownloader {

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    /**
     * Downloads up to [maxPhotos] valid product images concurrently for fast batch scraping.
     */
    suspend fun downloadProductImages(
        imageUrls: List<String>,
        refererUrl: String,
        targetDir: File,
        maxPhotos: Int
    ): List<String> = withContext(Dispatchers.IO) {
        if (!targetDir.exists()) targetDir.mkdirs()
        val candidates = imageUrls.distinct().take((maxPhotos + 4).coerceAtMost(16))

        val downloaded: List<Pair<Int, ByteArray>?> = coroutineScope {
            candidates.mapIndexed { idx, rawUrl ->
                async(Dispatchers.IO) {
                    val bytes = fetchBytes(rawUrl, refererUrl) ?: return@async null
                    if (bytes.size < 4096) return@async null
                    idx to bytes
                }
            }.awaitAll()
        }

        val saved = mutableListOf<String>()
        for (item in downloaded.filterNotNull().sortedBy { it.first }) {
            if (saved.size >= maxPhotos) break
            val bitmap = BitmapFactory.decodeByteArray(item.second, 0, item.second.size) ?: continue
            try {
                if (bitmap.width < 200 || bitmap.height < 200) continue
                val index = saved.size + 1
                val outFile = File(targetDir, "photo_%02d.jpg".format(index))
                FileOutputStream(outFile).use { fos ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 88, fos)
                }
                saved.add(outFile.absolutePath)
            } finally {
                bitmap.recycle()
            }
        }
        saved
    }

    private fun fetchBytes(rawUrl: String, referer: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(rawUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8_000
                readTimeout = 10_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Referer", referer)
                setRequestProperty("Accept", "image/webp,image/apng,image/*,*/*;q=0.8")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.use { it.readBytes() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
