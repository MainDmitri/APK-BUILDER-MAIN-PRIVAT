package com.dahua.checker

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Canvas
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore

class MainActivity : ComponentActivity() {

    private var scanServiceState = mutableStateOf<ScanService?>(null)
    private var serviceBound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            scanServiceState.value = (binder as ScanService.ScanBinder).getService()
            serviceBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            scanServiceState.value = null
            serviceBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        PluginManager.init(this)
        requestBatteryOptimization()
        requestNotificationPermission()

        setContent {
            val dark = darkColorScheme(
                primary = Wine,
                secondary = WineLight,
                tertiary = Red400,
                background = BgDark,        // 0xFF0A0305 — near-black red tint
                surface = SurfaceDark,      // 0xFF140A0E
                surfaceVariant = SurfaceDark2, // 0xFF1E1215
                onBackground = Color(0xFFEDE0E4),
                onSurface = Color(0xFFEDE0E4),
                onSurfaceVariant = Gray500,
                outline = BorderDark
            )
            MaterialTheme(colorScheme = dark) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppRoot(
                        onStartScan = { ips, port, multiPort, selectedPorts, pluginId, pluginPorts -> startScanService(ips, port, multiPort, selectedPorts, pluginId, pluginPorts) },
                        onStopScan = { scanServiceState.value?.stopScan() },
                        scanService = scanServiceState.value
                    )
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
    }

    override fun onStop() {
        super.onStop()
        if (serviceBound) { unbindService(connection); serviceBound = false }
    }

    private fun startScanService(ips: List<String>, port: Int, multiPort: Boolean, selectedPorts: List<Int>?, pluginId: String? = null, pluginPorts: List<Int>? = null) {
        if (!serviceBound) {
            Intent(this, ScanService::class.java).also { bindService(it, connection, Context.BIND_AUTO_CREATE) }
        }

        // Формирует Intent и запускает ScanService с уже известным списком IP
        fun doStart(finalIps: List<String>) {
            try {
                ScanService.pendingIps = finalIps
                val intent = Intent(this, ScanService::class.java).apply {
                    action = ScanService.ACTION_START
                    putExtra(ScanService.EXTRA_PORT, port)
                    putExtra(ScanService.EXTRA_MULTI_PORT, multiPort)
                    if (selectedPorts != null) putExtra(ScanService.EXTRA_SELECTED_PORTS, selectedPorts.toIntArray())
                    if (pluginId   != null) putExtra(ScanService.EXTRA_PLUGIN_ID, pluginId)
                    if (pluginPorts != null) putExtra(ScanService.EXTRA_PLUGIN_PORTS, pluginPorts.toIntArray())
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
                else startService(intent)
            } catch (e: Exception) {
                Toast.makeText(this, "Ошибка запуска: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        val fofaEmail = AuthManager.getFofaEmail(this)
        val fofaKey   = AuthManager.getFofaKey(this)

        if (fofaEmail.isNotEmpty() && fofaKey.isNotEmpty()) {
            // Сначала запрашиваем FOFA, потом стартуем скан с объединённым списком
            lifecycleScope.launch {
                val query = if (selectedPorts != null && 554 in selectedPorts)
                    OsintService.Queries.FOFA_RTSP else OsintService.Queries.FOFA_IPC
                val fofaResult = OsintService.searchFofa(fofaEmail, fofaKey, query, size = 200)
                val fofaIps = fofaResult.getOrNull()
                    ?.map { it.ip }?.filter { it.isNotEmpty() }
                    ?: emptyList()
                val merged = (ips + fofaIps).distinct()
                doStart(merged)
            }
        } else {
            doStart(ips)
        }
    }

    private fun requestBatteryOptimization() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (_: Exception) {}
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

// ─── Wine Dark Premium Palette v2 ───
val Wine        = Color(0xFFB23A48)       // основной акцент
val WineLight   = Color(0xFFD4626E)       // светлый
val WineDark    = Color(0xFF8B1A2B)       // тёмный (кнопки, иконки)
val WineAccent  = Color(0xFFE8899A)       // нежный акцент
val WineGlow    = Color(0x40B23A48)       // glow под картами
val BgDark      = Color(0xFF0A0305)       // почти чёрный с красным тинтом
val SurfaceDark = Color(0xFF140A0E)       // карты первого уровня
val SurfaceDark2 = Color(0xFF1E1215)      // карты второго уровня
val SurfaceEl   = Color(0xFF2A1A20)       // elevated
val BorderDark  = Color(0xFF3D2530)       // бордер
val BorderGlow  = Color(0x60B23A48)       // активный бордер
val Gray500     = Color(0xFF9E8B91)
val Red400      = Color(0xFFFF5252)
val Orange400   = Color(0xFFFFB74D)
val Yellow400   = Color(0xFFFFEE58)
val Cyan400     = Color(0xFFD4A5A5)
val Purple400   = Color(0xFFCE93D8)

/** Форматирует логин:пароль — пустые отображаются как (open) */
fun credentialLabel(login: String, password: String): String =
    if (login.isEmpty() && password.isEmpty()) "(open)" else "$login:$password"

fun brandColor(brand: String): Color = when {
    "Hikvision" in brand || "Annke" in brand -> Color(0xFFFF6B6B)
    "Dahua" in brand || "Amcrest" in brand || "Imou" in brand -> Wine
    "XMeye" in brand -> Purple400
    "Uniview" in brand -> Color(0xFF42A5F5)
    "Reolink" in brand -> Color(0xFF66BB6A)
    "Axis" in brand -> Color(0xFFFFCA28)
    "Hanwha" in brand -> Color(0xFF26C6DA)
    "Bosch" in brand -> Color(0xFFEF5350)
    "Vivotek" in brand -> Color(0xFF8D6E63)
    "TPLink" in brand || "Tenda" in brand -> Color(0xFF4FC3F7)
    "AliOS" in brand || "Tuya" in brand -> Color(0xFFFF8A65)
    "GeoVision" in brand -> Color(0xFFAB47BC)
    "ACTi" in brand -> Color(0xFF7E57C2)
    "Grandstream" in brand -> Color(0xFF5C6BC0)
    "Foscam" in brand || "VStarcam" in brand || "Wanscam" in brand || "Sricam" in brand -> Color(0xFF9CCC65)
    "Pelco" in brand -> Color(0xFFEC407A)
    "Milesight" in brand -> Color(0xFF29B6F6)
    "Mobotix" in brand -> Color(0xFFFFA726)
    "Lorex" in brand || "Swann" in brand || "ZOSI" in brand || "Hiseeu" in brand -> Color(0xFF78909C)
    "Tiandy" in brand || "TVT" in brand -> Color(0xFFE57373)
    "CPPlus" in brand -> Color(0xFFFF7043)
    "Sony" in brand -> Color(0xFF1565C0)
    "Samsung" in brand -> Color(0xFF1E88E5)
    "Panasonic" in brand -> Color(0xFF00897B)
    "Intelbras" in brand -> Color(0xFF43A047)
    "Herospeed" in brand -> Color(0xFFD81B60)
    "Honeywell" in brand -> Color(0xFFE53935)
    "FLIR" in brand -> Color(0xFF6D4C41)
    "Avigilon" in brand -> Color(0xFF546E7A)
    "Geutebruck" in brand -> Color(0xFF8E24AA)
    "TVIP" in brand -> Color(0xFF00ACC1)
    "RTSP" in brand -> Color(0xFF7CB342)
    "SSH" in brand -> Color(0xFFFFA726)
    "Telnet" in brand -> Color(0xFFEF5350)
    "VPS" in brand -> Color(0xFF00E676)
    // Server services
    "Redis" in brand       -> Color(0xFFFF5252)
    "MongoDB" in brand     -> Color(0xFF66BB6A)
    "Docker" in brand      -> Color(0xFF29B6F6)
    "Elasticsearch" in brand || "Elastic" in brand -> Color(0xFF00E5FF)
    "Grafana" in brand     -> Color(0xFFF57C00)
    "Jupyter" in brand     -> Color(0xFFFF8F00)
    "MySQL" in brand       -> Color(0xFF00897B)
    "PostgreSQL" in brand  -> Color(0xFF1565C0)
    "FTP" in brand         -> Color(0xFF26C6DA)
    "Webmin" in brand      -> Color(0xFF7C4DFF)
    "Jenkins" in brand     -> Color(0xFFD84315)
    "Portainer" in brand   -> Color(0xFF0288D1)
    "CouchDB" in brand     -> Color(0xFFE53935)
    "Memcached" in brand   -> Color(0xFF78909C)
    "MikroTik" in brand    -> Color(0xFF43A047)
    else -> WineLight
}

fun brandIcon(brand: String): String = when {
    "Redis" in brand       -> "⚡"
    "MongoDB" in brand     -> "🍃"
    "Docker" in brand      -> "🐳"
    "Elasticsearch" in brand -> "🔍"
    "Grafana" in brand     -> "📊"
    "Jupyter" in brand     -> "📓"
    "MySQL" in brand       -> "🗄"
    "PostgreSQL" in brand  -> "🐘"
    "FTP" in brand         -> "📁"
    "Webmin" in brand      -> "⚙"
    "Jenkins" in brand     -> "🔧"
    "Portainer" in brand   -> "📦"
    "CouchDB" in brand     -> "💾"
    "Memcached" in brand   -> "⚙"
    "MikroTik" in brand    -> "🌐"
    "SSH" in brand || "VPS" in brand -> "💻"
    "Telnet" in brand      -> "💻"
    else -> "📷"
}

val SERVER_BRANDS = setOf("Redis","MongoDB","Docker","Elasticsearch","Grafana","Jupyter",
    "MySQL","PostgreSQL","FTP-Anon","Webmin","Jenkins","Portainer","CouchDB","Memcached","MikroTik")

fun isTerminal(brand: String): Boolean = brand in setOf("SSH-TTY", "Telnet-TTY", "VPS")
fun isServer(brand: String): Boolean = SERVER_BRANDS.any { it in brand }

data class PortOption(val port: Int, val label: String, val color: Color)

val ALL_PORT_OPTIONS = listOf(
    PortOption(37777, "Dahua", Wine),
    PortOption(80, "HTTP 80", WineLight),
    PortOption(8080, "HTTP 8080", WineLight),
    PortOption(8000, "Hikvision", Color(0xFFFF6B6B)),
    PortOption(8001, "HTTP 8001", WineLight),
    PortOption(8008, "HTTP 8008", WineLight),
    PortOption(8081, "HTTP 8081", WineLight),
    PortOption(8082, "HTTP 8082", WineLight),
    PortOption(8083, "HTTP 8083", WineLight),
    PortOption(8084, "HTTP 8084", WineLight),
    PortOption(8085, "HTTP 8085", WineLight),
    PortOption(8086, "HTTP 8086", WineLight),
    PortOption(8087, "HTTP 8087", WineLight),
    PortOption(8088, "HTTP 8088", WineLight),
    PortOption(8089, "HTTP 8089", WineLight),
    PortOption(8090, "HTTP 8090", WineLight),
    PortOption(8181, "HTTP 8181", WineLight),
    PortOption(8443, "HTTPS 8443", Color(0xFF78909C)),
    PortOption(8899, "HTTP 8899", WineLight),
    PortOption(9000, "HTTP 9000", WineLight),
    PortOption(9090, "HTTP 9090", WineLight),
    PortOption(34567, "XMeye", Purple400),
    PortOption(554, "RTSP", Color(0xFF7CB342)),
    PortOption(5554, "RTSP Alt", Color(0xFF7CB342)),
    PortOption(8554, "RTSP 8554", Color(0xFF7CB342)),
    PortOption(8888, "Herospeed", Color(0xFFD81B60)),
    PortOption(8186, "XM SDK", WineLight),
    PortOption(22, "SSH", Color(0xFFFFA726)),
    PortOption(2222, "SSH Alt", Color(0xFFFFA726)),
    PortOption(23, "Telnet", Color(0xFFEF5350)),
    PortOption(2323, "Telnet Alt", Color(0xFFEF5350)),
    // Server services
    PortOption(21, "FTP", Color(0xFF26C6DA)),
    PortOption(2375, "Docker", Color(0xFF29B6F6)),
    PortOption(3000, "Grafana", Color(0xFFF57C00)),
    PortOption(3306, "MySQL", Color(0xFF00897B)),
    PortOption(5432, "PostgreSQL", Color(0xFF1565C0)),
    PortOption(5984, "CouchDB", Color(0xFFE53935)),
    PortOption(6379, "Redis", Color(0xFFE53935)),
    PortOption(8889, "Jupyter", Color(0xFFF57C00)),
    PortOption(9200, "Elastic", Color(0xFF00897B)),
    PortOption(10000, "Webmin", Color(0xFF5C6BC0)),
    PortOption(11211, "Memcached", Color(0xFF78909C)),
    PortOption(27017, "MongoDB", Color(0xFF43A047))
)

// ─── Корневой роутер: авторизация или приложение ───
@Composable
fun AppRoot(
    onStartScan: (List<String>, Int, Boolean, List<Int>?, String?, List<Int>?) -> Unit,
    onStopScan: () -> Unit,
    scanService: ScanService?
) {
    val context = LocalContext.current
    var isActivated by remember { mutableStateOf(AuthManager.isActivated(context)) }
    var showAdminPanel by remember { mutableStateOf(false) }

    if (!isActivated) {
        ActivationScreen(
            onActivated = { isActivated = true },
            onAdminRequest = { showAdminPanel = true }
        )
    } else {
        DahuaApp(
            onStartScan = onStartScan,
            onStopScan = onStopScan,
            scanService = scanService,
            onAdminRequest = { showAdminPanel = true }
        )
    }

    if (showAdminPanel) {
        AdminPanelFlow(onDismiss = { showAdminPanel = false })
    }
}

// ─── Экран активации ───
@Composable
fun ActivationScreen(
    onActivated: () -> Unit,
    onAdminRequest: () -> Unit
) {
    val context = LocalContext.current
    var nickname by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var attempts by remember { mutableIntStateOf(0) }
    var blocked by remember { mutableStateOf(false) }
    var blockTimeLeft by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var adminTapCount by remember { mutableIntStateOf(0) }
    var lastTapTime by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    // Таймер разблокировки (30 сек)
    LaunchedEffect(blocked) {
        if (blocked) {
            blockTimeLeft = 30
            while (blockTimeLeft > 0) {
                kotlinx.coroutines.delay(1000L)
                blockTimeLeft--
            }
            blocked = false
            attempts = 0
            error = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(BgDark, SurfaceDark, BgDark)))
    ) {
        // Невидимая кнопка админ-панели — правый верхний угол
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 40.dp, end = 8.dp)
                .size(48.dp)
                .pointerInput(Unit) {
                    detectTapGestures {
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 500) {
                            adminTapCount++
                        } else {
                            adminTapCount = 1
                        }
                        lastTapTime = now
                        if (adminTapCount >= 2) {
                            adminTapCount = 0
                            onAdminRequest()
                        }
                    }
                }
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.Center)
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Логотип
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.verticalGradient(listOf(Wine, WineDark))),
                contentAlignment = Alignment.Center
            ) {
                Text("🔍", fontSize = 40.sp)
            }

            Spacer(Modifier.height(20.dp))

            Text("Main Scanner", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Введите данные для активации", fontSize = 14.sp, color = Gray500)

            Spacer(Modifier.height(32.dp))

            // Поле ника
            OutlinedTextField(
                value = nickname,
                onValueChange = { nickname = it.take(20); error = null },
                label = { Text("Никнейм", color = Gray500) },
                placeholder = { Text("Ваш никнейм", color = Gray500.copy(alpha = 0.5f)) },
                singleLine = true,
                enabled = !blocked,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Wine,
                    unfocusedBorderColor = BorderDark,
                    cursorColor = Wine,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                )
            )

            Spacer(Modifier.height(12.dp))

            // Поле кода
            OutlinedTextField(
                value = code,
                onValueChange = { raw ->
                    // Автоформат: убираем всё кроме букв/цифр, вставляем дефисы
                    val clean = raw.uppercase().filter { it.isLetterOrDigit() }.take(12)
                    val formatted = clean.chunked(4).joinToString("-")
                    code = formatted
                    error = null
                },
                label = { Text("Код активации", color = Gray500) },
                placeholder = { Text("XXXX-XXXX-XXXX", color = Gray500.copy(alpha = 0.5f)) },
                singleLine = true,
                enabled = !blocked,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Wine,
                    unfocusedBorderColor = BorderDark,
                    cursorColor = Wine,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark
                )
            )

            if (error != null) {
                Spacer(Modifier.height(8.dp))
                Text(error!!, color = Red400, fontSize = 13.sp)
            }

            if (blocked) {
                Spacer(Modifier.height(8.dp))
                Text("Слишком много попыток. Подождите $blockTimeLeft сек.", color = Orange400, fontSize = 13.sp)
            }

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = {
                    if (blocked || loading) return@Button
                    if (nickname.isBlank()) { error = "Введите никнейм"; return@Button }
                    if (code.isBlank()) { error = "Введите код активации"; return@Button }
                    if (nickname.length < 2) { error = "Минимум 2 символа для никнейма"; return@Button }

                    loading = true
                    error = null
                    val result = AuthManager.activate(context, nickname.trim(), code.trim())
                    loading = false
                    result.onSuccess { success ->
                        if (success) {
                            Toast.makeText(context, "Активация успешна! Добро пожаловать, ${nickname.trim()}", Toast.LENGTH_LONG).show()
                            onActivated()
                        } else {
                            attempts++
                            if (attempts >= 5) {
                                blocked = true
                                error = "Неверный код"
                            } else {
                                error = "Неверный код активации (попытка $attempts/5)"
                            }
                        }
                    }.onFailure { e ->
                        error = "Ошибка: ${e.message}"
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                enabled = !blocked && !loading,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Wine,
                    contentColor = Color.White,
                    disabledContainerColor = Wine.copy(alpha = 0.3f)
                )
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Text("Проверка...", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                } else {
                    Icon(Icons.Default.Lock, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Активировать", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Код можно получить у администратора",
                fontSize = 12.sp,
                color = Gray500.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )
        }
    }
}

// ─── Админ-панель: сначала пароль, потом панель ───
@Composable
fun AdminPanelFlow(onDismiss: () -> Unit) {
    var authenticated by remember { mutableStateOf(false) }

    if (!authenticated) {
        AdminLoginDialog(
            onAuthenticated = { authenticated = true },
            onDismiss = onDismiss
        )
    } else {
        AdminPanelDialog(onDismiss = {
            authenticated = false
            onDismiss()
        })
    }
}

@Composable
fun AdminLoginDialog(onAuthenticated: () -> Unit, onDismiss: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var attempts by remember { mutableIntStateOf(0) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier.size(56.dp).clip(CircleShape).background(Wine.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Lock, null, tint = Wine, modifier = Modifier.size(28.dp))
                }

                Spacer(Modifier.height(16.dp))

                Text("Админ-панель", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Введите пароль администратора", fontSize = 13.sp, color = Gray500)

                Spacer(Modifier.height(16.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; error = null },
                    label = { Text("Пароль", color = Gray500) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Wine,
                        unfocusedBorderColor = BorderDark,
                        cursorColor = Wine,
                        focusedContainerColor = BgDark,
                        unfocusedContainerColor = BgDark
                    )
                )

                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(error!!, color = Red400, fontSize = 13.sp)
                }

                Spacer(Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Отмена", color = Gray500)
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (AuthManager.verifyAdminPassword(password)) {
                                onAuthenticated()
                            } else {
                                attempts++
                                error = if (attempts >= 3) "Доступ заблокирован" else "Неверный пароль ($attempts/3)"
                                if (attempts >= 3) {
                                    onDismiss()
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Wine)
                    ) {
                        Text("Войти", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPanelDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var selectedAdminTab by remember { mutableIntStateOf(0) }
    var genNickname by remember { mutableStateOf("") }
    var generatedCode by remember { mutableStateOf<String?>(null) }
    var genLoading by remember { mutableStateOf(false) }
    var genError by remember { mutableStateOf<String?>(null) }
    val users = remember { mutableStateListOf<UserInfo>() }
    var usersLoading by remember { mutableStateOf(true) }
    var usersError by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val result = AuthManager.getUsers(context)
        usersLoading = false
        result.onSuccess { list ->
            users.clear()
            users.addAll(list)
        }.onFailure { e ->
            usersError = "Ошибка загрузки: ${e.message}"
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp).fillMaxHeight(0.85f),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Заголовок
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(WineDark, SurfaceDark)))
                        .padding(20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(CircleShape).background(Wine.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Settings, null, tint = WineAccent, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Админ-панель", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Управление кодами и пользователями", fontSize = 12.sp, color = Gray500)
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, null, tint = Gray500)
                        }
                    }
                }

                // Табы админки
                TabRow(
                    selectedTabIndex = selectedAdminTab,
                    containerColor = SurfaceDark,
                    contentColor = Wine,
                    divider = { HorizontalDivider(color = BorderDark, thickness = 1.dp) },
                    indicator = { }
                ) {
                    Tab(selected = selectedAdminTab == 0, onClick = { selectedAdminTab = 0 },
                        text = { Text("🔑 Генерация", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) },
                        selectedContentColor = Wine, unselectedContentColor = Gray500)
                    Tab(selected = selectedAdminTab == 1, onClick = { selectedAdminTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("👥 Пользователи", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                if (users.isNotEmpty()) {
                                    Spacer(Modifier.width(4.dp))
                                    Box(modifier = Modifier.clip(CircleShape).background(Wine).padding(horizontal = 6.dp, vertical = 1.dp)) {
                                        Text("${users.size}", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        },
                        selectedContentColor = Wine, unselectedContentColor = Gray500)
                }

                when (selectedAdminTab) {
                    0 -> {
                        // Генерация кодов
                        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
                            Text("Генерация кода активации", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Введите никнейм пользователя для генерации уникального кода", fontSize = 13.sp, color = Gray500)

                            Spacer(Modifier.height(20.dp))

                            OutlinedTextField(
                                value = genNickname,
                                onValueChange = { genNickname = it.take(20); generatedCode = null },
                                label = { Text("Никнейм пользователя", color = Gray500) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Wine,
                                    unfocusedBorderColor = BorderDark,
                                    cursorColor = Wine,
                                    focusedContainerColor = BgDark,
                                    unfocusedContainerColor = BgDark
                                )
                            )

                            Spacer(Modifier.height(16.dp))

                            if (genError != null) {
                                Text(genError!!, color = Red400, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                            }

                            Button(
                                onClick = {
                                    if (genNickname.isNotBlank() && genNickname.length >= 2 && !genLoading) {
                                        genLoading = true
                                        genError = null
                                        val result = AuthManager.generateCode(context, genNickname.trim())
                                        genLoading = false
                                        result.onSuccess { code ->
                                            generatedCode = code
                                            AuthManager.getUsers(context).onSuccess { list ->
                                                users.clear()
                                                users.addAll(list)
                                            }
                                        }.onFailure { e ->
                                            genError = "Ошибка: ${e.message}"
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                enabled = genNickname.length >= 2 && !genLoading,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Wine,
                                    disabledContainerColor = Wine.copy(alpha = 0.3f)
                                )
                            ) {
                                if (genLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(if (genLoading) "Генерация..." else "Сгенерировать код", fontWeight = FontWeight.Bold)
                            }

                            if (generatedCode != null) {
                                Spacer(Modifier.height(24.dp))

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgDark),
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Wine.copy(alpha = 0.3f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(20.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("Код для: ${genNickname.trim()}", fontSize = 13.sp, color = Gray500)
                                        Spacer(Modifier.height(12.dp))
                                        Text(
                                            generatedCode!!,
                                            fontSize = 28.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            color = Wine,
                                            letterSpacing = 2.sp
                                        )
                                        Spacer(Modifier.height(16.dp))

                                        Button(
                                            onClick = {
                                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                cm.setPrimaryClip(ClipData.newPlainText("code", generatedCode))
                                                Toast.makeText(context, "Код скопирован", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Wine.copy(alpha = 0.2f), contentColor = Wine)
                                        ) {
                                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Копировать код", fontWeight = FontWeight.SemiBold)
                                        }

                                        Spacer(Modifier.height(8.dp))

                                        Button(
                                            onClick = {
                                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                val text = "Никнейм: ${genNickname.trim()}\nКод: $generatedCode"
                                                cm.setPrimaryClip(ClipData.newPlainText("code_full", text))
                                                Toast.makeText(context, "Скопировано с никнеймом", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark2, contentColor = WineLight)
                                        ) {
                                            Text("Копировать ник + код", fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        // Список пользователей
                        if (users.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("👥", fontSize = 48.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Text("Нет зарегистрированных пользователей", fontSize = 14.sp, color = Gray500)
                                }
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp)
                            ) {
                                item {
                                    Text(
                                        "Всего: ${users.size} пользователей",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = WineLight,
                                        modifier = Modifier.padding(bottom = 4.dp)
                                    )
                                }
                                items(users, key = { it.nickname }) { user ->
                                    val dateFmt = remember(user.activatedAt) {
                                        java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault())
                                            .format(java.util.Date(user.activatedAt))
                                    }
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgDark),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier.size(40.dp).clip(CircleShape).background(Wine.copy(alpha = 0.2f)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    user.nickname.take(1).uppercase(),
                                                    fontSize = 18.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Wine
                                                )
                                            }
                                            Spacer(Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(user.nickname, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                                                Text(user.code, fontSize = 12.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                                                Text(dateFmt, fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
                                            }
                                            // Удалить пользователя
                                            IconButton(onClick = {
                                                AuthManager.deleteUser(context, user.nickname)
                                                users.removeAll { it.nickname == user.nickname }
                                                Toast.makeText(context, "Удалён: ${user.nickname}", Toast.LENGTH_SHORT).show()
                                            }) {
                                                Icon(Icons.Default.Delete, null, tint = Red400.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─── Основное приложение ───
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DahuaApp(
    onStartScan: (List<String>, Int, Boolean, List<Int>?, String?, List<Int>?) -> Unit,
    onStopScan: () -> Unit,
    scanService: ScanService?,
    onAdminRequest: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var ipInput by remember { mutableStateOf("") }
    var portInput by remember { mutableStateOf("37777") }
    var parseError by remember { mutableStateOf<String?>(null) }
    var selectedResult by remember { mutableStateOf<ScanResult?>(null) }
    var multiPortMode by remember { mutableStateOf(false) }
    var portSelectMode by remember { mutableStateOf(false) }
    val selectedPorts = remember { mutableStateListOf<Int>() }
    var showAbout by remember { mutableStateOf(false) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showApiSettings by remember { mutableStateOf(false) }
    var activePluginId by remember { mutableStateOf<String?>(null) }
    val pluginSelectedPorts = remember { mutableStateListOf<Int>() }

    var isScanning by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<ScanProgress?>(null) }
    val results = remember { mutableStateListOf<ScanResult>() }
    val savedResults = remember { mutableStateListOf<ScanResult>() }
    val storedResults = remember { mutableStateListOf<ScanResult>() }
    val logLines = remember { mutableStateListOf<String>() }
    var showLogs by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // Переменные для скрытой кнопки админ-панели в хедере
    var adminTapCount by remember { mutableIntStateOf(0) }
    var lastAdminTap by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        val loaded = ResultStorage.load(context)
        storedResults.addAll(loaded)
    }

    LaunchedEffect(scanService) {
        scanService?.let { svc ->
            launch { svc.isScanning.collect { isScanning = it } }
            launch { svc.progress.collect { p -> if (p != null) progress = p } }
            launch { svc.results.collect { r ->
                results.add(0, r)
                if (!r.blocked) {
                    savedResults.add(0, r)
                    ResultStorage.addResult(context, r)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                    storedResults.add(0, r)
                }
            }}
            launch { svc.logLines.collect { lines ->
                logLines.clear()
                logLines.addAll(lines)
            }}
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // ─── Header Premium v3 ───
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF200810), Color(0xFF140609), BgDark))
                )
        ) {
            // Subtle glow line at bottom
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.horizontalGradient(listOf(Color.Transparent, WineGlow, Wine.copy(alpha = 0.4f), WineGlow, Color.Transparent)))
            )
            Column(modifier = Modifier.padding(top = 48.dp, bottom = 14.dp, start = 16.dp, end = 16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Логотип — многослойный градиентный круг с иконкой
                    Box(contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(WineGlow)
                        )
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(listOf(WineLight, Wine, WineDark))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Search, null, tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Main",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                "Scanner",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = WineAccent,
                                letterSpacing = 0.5.sp
                            )
                        }
                        val nickname = AuthManager.getActiveNickname(context)
                        val subtitle = when {
                            nickname.isNotEmpty() -> nickname
                            else -> "Dahua · Hikvision · CVE"
                        }
                        Text(subtitle, fontSize = 11.sp, color = Gray500, letterSpacing = 0.3.sp)
                    }
                    // Счётчик найденных — улучшенный стиль
                    if (results.any { !it.blocked }) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Brush.horizontalGradient(listOf(WineDark.copy(alpha = 0.6f), Wine.copy(alpha = 0.3f))))
                                .border(1.dp, Wine.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Wine))
                                Spacer(Modifier.width(5.dp))
                                Text(
                                    "${results.count { !it.blocked }}",
                                    color = WineAccent,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    // API ключи (FOFA, Shodan, Censys, ZoomEye)
                    Box(
                        modifier = Modifier.size(36.dp).clip(CircleShape)
                            .background(SurfaceDark2)
                            .border(1.dp, BorderDark, CircleShape)
                            .clickable { showApiSettings = true },
                        contentAlignment = Alignment.Center
                    ) { Text("🔑", fontSize = 15.sp) }
                    Spacer(Modifier.width(6.dp))
                    // Расписание
                    Box(
                        modifier = Modifier.size(36.dp).clip(CircleShape)
                            .background(SurfaceDark2)
                            .border(1.dp, BorderDark, CircleShape)
                            .clickable { showScheduleDialog = true },
                        contentAlignment = Alignment.Center
                    ) { Text("⏰", fontSize = 15.sp) }
                    Spacer(Modifier.width(6.dp))
                    // О приложении + скрытая кнопка админки
                    Box(
                        modifier = Modifier.size(36.dp).clip(CircleShape)
                            .background(SurfaceDark2)
                            .border(1.dp, BorderDark, CircleShape)
                            .clickable { showAbout = true }
                            .pointerInput(Unit) {
                                detectTapGestures {
                                    val now = System.currentTimeMillis()
                                    if (now - lastAdminTap < 500) adminTapCount++ else adminTapCount = 1
                                    lastAdminTap = now
                                    if (adminTapCount >= 2) { adminTapCount = 0; onAdminRequest() }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Info, null, tint = Gray500, modifier = Modifier.size(18.dp))
                    }
                }

                // Строка активных портов — только если выбраны конкретные
                val allPortsChosen = portSelectMode && selectedPorts.size >= ALL_PORT_OPTIONS.size
                if (portSelectMode && selectedPorts.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceDark2)
                            .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(WineAccent))
                        Spacer(Modifier.width(6.dp))
                        if (allPortsChosen) {
                            Text("Порты  ", fontSize = 11.sp, color = Gray500)
                            Text(
                                "Все порты → авто мульти-скан",
                                fontSize = 11.sp,
                                color = Color(0xFF7CB342),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else {
                            Text("Порты  ", fontSize = 11.sp, color = Gray500)
                            Text(
                                selectedPorts.sorted().joinToString(" · "),
                                fontSize = 11.sp,
                                color = WineAccent,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                } else if (multiPortMode) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.horizontalGradient(listOf(WineDark.copy(alpha = 0.4f), Wine.copy(alpha = 0.15f))))
                            .border(1.dp, Wine.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Wine))
                        Spacer(Modifier.width(6.dp))
                        Text("Multi-port × ${DahuaScanner.MAX_CONCURRENT}", fontSize = 11.sp, color = Wine, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // ─── Animated Segmented TabBar ───
        val pluginCount = try { PluginManager.getPlugins().size } catch (_: Exception) { 0 }
        val tabLabels = listOf("Сканер", "Находки", "Сохр.", "Плагины", "Страны")
        // Badge Находки — только результаты С credentials (без пустых login+password)
        val findingsBadge = results.count { !it.blocked && (it.login.isNotEmpty() || it.password.isNotEmpty()) }
        val tabBadges = listOf(0, findingsBadge, storedResults.size, pluginCount, 0)
        val tabColors = listOf(Wine, Wine, WineLight, Purple400, WineAccent)
        AnimatedSegmentedTabBar(
            tabs = tabLabels,
            badges = tabBadges,
            badgeColors = tabColors,
            selectedIndex = selectedTab,
            onTabSelected = { selectedTab = it }
        )

        when (selectedTab) {
            0 -> ScannerTab(
                ipInput = ipInput, onIpChange = { ipInput = it; parseError = null },
                portInput = portInput, onPortChange = { portInput = it.filter { c -> c.isDigit() }.take(5) },
                parseError = parseError, isScanning = isScanning, progress = progress, results = results,
                multiPortMode = multiPortMode, onMultiPortChange = { multiPortMode = it; if (it) portSelectMode = false },
                portSelectMode = portSelectMode, onPortSelectChange = { portSelectMode = it; if (it) multiPortMode = false },
                selectedPorts = selectedPorts,
                activePluginId = activePluginId,
                pluginSelectedPorts = pluginSelectedPorts,
                onScan = {
                    val ips = IpParser.parseMultiline(ipInput)
                    if (ips.isEmpty()) { parseError = "Некорректный ввод IP"; return@ScannerTab }
                    if (ips.size > 100_000) { parseError = "Максимум 100 000 IP"; return@ScannerTab }
                    val port = portInput.toIntOrNull() ?: DahuaScanner.DEFAULT_PORT
                    parseError = null; results.clear()
                    progress = ScanProgress(ips.size, 0, 0, 0, 0)
                    // Если выбраны ВСЕ порты из списка — это равнозначно multiPort режиму.
                    // Передаём null (= multiPort) чтобы избежать торможения от 30+ портов в quickPortScan.
                    val allPortsSelected = portSelectMode && selectedPorts.size >= ALL_PORT_OPTIONS.size
                    val ports = if (portSelectMode && selectedPorts.isNotEmpty() && !allPortsSelected) selectedPorts.toList() else null
                    val effectiveMultiPort = multiPortMode || allPortsSelected
                    val pPorts = if (activePluginId != null && pluginSelectedPorts.isNotEmpty()) pluginSelectedPorts.toList() else null
                    onStartScan(ips, port, effectiveMultiPort, ports, activePluginId, pPorts)
                },
                onStop = onStopScan,
                onResultClick = { selectedResult = it },
                logLines = logLines,
                showLogs = showLogs,
                onToggleLogs = { showLogs = !showLogs },
                onMyNetwork = {
                    val net = NetworkUtils.getLocalNetwork(context)
                    if (net != null) {
                        ipInput = net.subnet
                        val hosts = NetworkUtils.hostCount(net.prefix)
                        val gwStr = if (net.gateway.isNotEmpty()) " | GW: ${net.gateway}" else ""
                        val typeStr = if (net.networkType.isNotEmpty()) "${net.networkType} " else ""
                        Toast.makeText(
                            context,
                            "${typeStr}${net.ip} → ${net.subnet} ($hosts хостов)$gwStr",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(context, "Сеть не найдена — проверь WiFi/Ethernet", Toast.LENGTH_SHORT).show()
                    }
                },
                context = context
            )
            1 -> FindingsTab(results = results, onResultClick = { selectedResult = it }, context = context)
            2 -> StoredTab(
                results = storedResults,
                onResultClick = { selectedResult = it },
                onDelete = { r ->
                    ResultStorage.delete(context, r.ip, r.port)
                    storedResults.removeAll { it.ip == r.ip && it.port == r.port }
                },
                onClearAll = {
                    ResultStorage.clear(context)
                    storedResults.clear()
                },
                context = context
            )
            3 -> PluginsTab(
                activePluginId = activePluginId,
                onPluginSelected = { id ->
                    activePluginId = if (activePluginId == id) null else id
                    pluginSelectedPorts.clear()
                },
                onGoToScanner = { selectedTab = 0 },
                context = context
            )
            4 -> CountryTab(
                onIpsGenerated = { generatedIps ->
                    // Передаём сгенерированные IP прямо в ipInput через IpParser-совместимый формат
                    ipInput = generatedIps.joinToString("\n")
                },
                onGoToScanner = { selectedTab = 0 }
            )
        }
    }

    selectedResult?.let { r -> SnapshotFullDialog(r, context) { selectedResult = null } }

    if (showAbout) { AboutDialog { showAbout = false } }
    if (showScheduleDialog) { ScheduleDialog(context) { showScheduleDialog = false } }
    if (showApiSettings) { ApiSettingsDialog(context) { showApiSettings = false } }
}

// ─── Вкладка "Плагины" ───
@Composable
fun PluginsTab(activePluginId: String?, onPluginSelected: (String) -> Unit, onGoToScanner: () -> Unit, context: Context) {
    val plugins = remember { mutableStateListOf<ScanPlugin>() }
    var showInstallDialog by remember { mutableStateOf(false) }
    var showJsonInput by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        try {
            plugins.clear()
            plugins.addAll(PluginManager.getPlugins())
        } catch (_: Exception) {}
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Кнопки управления
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { showInstallDialog = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Color.White)
            ) {
                Text("📥 Установить", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { showJsonInput = true },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Wine),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight)
            ) {
                Text("📋 Вставить JSON", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (activePluginId != null) {
            val active = plugins.find { it.id == activePluginId }
            if (active != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = Wine.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚡", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Активный плагин", fontSize = 11.sp, color = Gray500)
                            Text(active.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Wine)
                        }
                        TextButton(onClick = { onPluginSelected(activePluginId) }) {
                            Text("Выкл", color = Red400, fontSize = 12.sp)
                        }
                    }
                    // Кнопка перехода к сканеру
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onGoToScanner,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Color.White)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Перейти к сканеру →", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        if (plugins.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔌", fontSize = 56.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("Нет установленных плагинов", fontSize = 15.sp, color = Gray500)
                    Spacer(Modifier.height(8.dp))
                    Text("Плагины добавляют новые\nметоды сканирования", fontSize = 13.sp, color = Gray500.copy(alpha = 0.7f), textAlign = TextAlign.Center)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
            ) {
                items(plugins, key = { it.id }) { plugin ->
                    PluginCard(
                        plugin = plugin,
                        isActive = plugin.id == activePluginId,
                        onToggle = { onPluginSelected(plugin.id) },
                        onEnable = { enabled ->
                            PluginManager.setPluginEnabled(context, plugin.id, enabled)
                            val idx = plugins.indexOfFirst { it.id == plugin.id }
                            if (idx >= 0) plugins[idx] = plugins[idx].copy(enabled = enabled)
                        },
                        onDelete = {
                            PluginManager.removePlugin(context, plugin.id)
                            plugins.removeAll { it.id == plugin.id }
                            if (activePluginId == plugin.id) onPluginSelected(plugin.id)
                            Toast.makeText(context, "Удалён: ${plugin.name}", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    // Диалог установки по URL
    if (showInstallDialog) {
        var url by remember { mutableStateOf("") }
        var loading by remember { mutableStateOf(false) }
        var error by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { if (!loading) showInstallDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("📥 Установить плагин", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("Вставьте URL файла плагина (.json)", fontSize = 13.sp, color = Gray500)
                    Spacer(Modifier.height(16.dp))

                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it; error = null },
                        label = { Text("URL плагина", color = Gray500) },
                        placeholder = { Text("https://...", color = Gray500.copy(alpha = 0.5f)) },
                        singleLine = true,
                        enabled = !loading,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine,
                            unfocusedBorderColor = BorderDark,
                            cursorColor = Wine,
                            focusedContainerColor = BgDark,
                            unfocusedContainerColor = BgDark
                        )
                    )

                    if (error != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(error!!, color = Red400, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showInstallDialog = false }, enabled = !loading) {
                            Text("Отмена", color = Gray500)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (url.isBlank()) { error = "Вставьте URL"; return@Button }
                                loading = true
                                error = null
                                scope.launch {
                                    PluginManager.installFromUrl(context, url.trim()).onSuccess { p ->
                                        plugins.clear()
                                        plugins.addAll(PluginManager.getPlugins())
                                        Toast.makeText(context, "Установлен: ${p.name}", Toast.LENGTH_SHORT).show()
                                        showInstallDialog = false
                                    }.onFailure { e ->
                                        error = "Ошибка: ${e.message}"
                                    }
                                    loading = false
                                }
                            },
                            enabled = !loading,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Wine)
                        ) {
                            if (loading) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(Modifier.width(6.dp))
                            }
                            Text("Установить")
                        }
                    }
                }
            }
        }
    }

    // Диалог вставки JSON
    if (showJsonInput) {
        var jsonText by remember { mutableStateOf("") }
        var error by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { showJsonInput = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("📋 Вставить плагин", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(4.dp))
                    Text("Вставьте JSON-код плагина", fontSize = 13.sp, color = Gray500)
                    Spacer(Modifier.height(16.dp))

                    OutlinedTextField(
                        value = jsonText,
                        onValueChange = { jsonText = it; error = null },
                        label = { Text("JSON", color = Gray500) },
                        placeholder = { Text("{\"id\": \"...\", ...}", color = Gray500.copy(alpha = 0.5f)) },
                        modifier = Modifier.fillMaxWidth().height(200.dp),
                        maxLines = 15,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine,
                            unfocusedBorderColor = BorderDark,
                            cursorColor = Wine,
                            focusedContainerColor = BgDark,
                            unfocusedContainerColor = BgDark
                        )
                    )

                    if (error != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(error!!, color = Red400, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showJsonInput = false }) {
                            Text("Отмена", color = Gray500)
                        }
                        Spacer(Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (jsonText.isBlank()) { error = "Вставьте JSON"; return@Button }
                                PluginManager.installPlugin(context, jsonText.trim()).onSuccess { p ->
                                    plugins.clear()
                                    plugins.addAll(PluginManager.getPlugins())
                                    Toast.makeText(context, "Установлен: ${p.name}", Toast.LENGTH_SHORT).show()
                                    showJsonInput = false
                                }.onFailure { e ->
                                    error = "Ошибка: ${e.message}"
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Wine)
                        ) {
                            Text("Установить")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PluginCard(
    plugin: ScanPlugin,
    isActive: Boolean,
    onToggle: () -> Unit,
    onEnable: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val cardBorderColor by animateColorAsState(
        targetValue = if (isActive) Wine else Color.Transparent,
        animationSpec = tween(250), label = "pluginBorder"
    )
    val cardBg by animateColorAsState(
        targetValue = if (isActive) Wine.copy(alpha = 0.1f) else BgDark,
        animationSpec = tween(250), label = "pluginBg"
    )
    Card(
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, cardBorderColor)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Иконка
                val iconBg by animateColorAsState(
                    targetValue = if (plugin.enabled) Wine.copy(alpha = 0.2f) else SurfaceDark2,
                    animationSpec = tween(200), label = "pluginIconBg"
                )
                Box(
                    modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Text(plugin.icon, fontSize = 22.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(plugin.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = if (plugin.enabled) Color.White else Gray500)
                    Text("v${plugin.version} • ${plugin.author}", fontSize = 11.sp, color = Gray500)
                    if (plugin.description.isNotEmpty()) {
                        Text(plugin.description, fontSize = 12.sp, color = Gray500.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                // Кнопка активации для сканирования
                IconButton(onClick = onToggle) {
                    if (isActive) {
                        Icon(Icons.Default.PlayArrow, null, tint = Wine, modifier = Modifier.size(24.dp))
                    } else {
                        Icon(Icons.Default.PlayArrow, null, tint = Gray500, modifier = Modifier.size(24.dp))
                    }
                }
                // Развернуть
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        null, tint = Gray500, modifier = Modifier.size(20.dp)
                    )
                }
            }

            // AnimatedVisibility так что контент появляется/исчезает плавно
            // вместе с animateContentSize на Column выше → двойная анимация ✓
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn(tween(200)) + expandVertically(spring(stiffness = Spring.StiffnessMediumLow)),
                exit = fadeOut(tween(150)) + shrinkVertically(spring(stiffness = Spring.StiffnessMediumLow))
            ) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    HorizontalDivider(color = BorderDark, thickness = 1.dp)
                    Spacer(Modifier.height(12.dp))

                    // Инфо
                    Text("Порты: ${plugin.ports.joinToString(", ")}", fontSize = 12.sp, color = Gray500)
                    Text("Логины: ${plugin.credentials.size} пар", fontSize = 12.sp, color = Gray500)
                    Text("Проверки: ${plugin.checks.size} методов", fontSize = 12.sp, color = Gray500)
                    val maxChecksToShow = 15
                    plugin.checks.take(maxChecksToShow).forEach { check ->
                        Text("  • ${check.type}: ${check.path.ifEmpty { "port ${check.readBytes}b" }}", fontSize = 11.sp, color = Gray500.copy(alpha = 0.7f))
                    }
                    if (plugin.checks.size > maxChecksToShow) {
                        Text("  ... и ещё ${plugin.checks.size - maxChecksToShow} проверок", fontSize = 11.sp, color = Gray500.copy(alpha = 0.5f))
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Вкл/выкл
                        OutlinedButton(
                            onClick = { onEnable(!plugin.enabled) },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (plugin.enabled) Wine else Gray500),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (plugin.enabled) "Включён" else "Выключен",
                                fontSize = 12.sp,
                                color = if (plugin.enabled) Wine else Gray500
                            )
                        }
                        // Удалить
                        OutlinedButton(
                            onClick = onDelete,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Red400.copy(alpha = 0.5f)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text("Удалить", fontSize = 12.sp, color = Red400)
                        }
                    }
                }
            }
        }
    }
}

// ─── Диалог "О приложении" ───
@Composable
fun AboutDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(24.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(24.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(20.dp))
                        .background(Brush.verticalGradient(listOf(Wine, WineDark))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🔍", fontSize = 36.sp)
                }

                Spacer(Modifier.height(16.dp))

                Text("Main Scanner", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)

                Spacer(Modifier.height(4.dp))

                Text("v3.5.0", fontSize = 14.sp, color = Gray500)

                Spacer(Modifier.height(20.dp))

                HorizontalDivider(color = BorderDark, thickness = 1.dp)

                Spacer(Modifier.height(20.dp))

                Text("Разработчик", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Gray500, letterSpacing = 1.sp)

                Spacer(Modifier.height(6.dp))

                Text("MainDmitri", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Wine)

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/+M8O1wJodXPo2Y2Jk"))
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            Toast.makeText(context, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2AABEE), contentColor = Color.White)
                ) {
                    Text("✈", fontSize = 18.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("Telegram канал", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    "Многопортовый сканер сетевых устройств.\nПоддержка Dahua, Hikvision, XMeye, SSH, Telnet.",
                    fontSize = 13.sp, color = Gray500, textAlign = TextAlign.Center, lineHeight = 18.sp
                )

                Spacer(Modifier.height(20.dp))

                TextButton(onClick = onDismiss) {
                    Text("Закрыть", color = WineLight, fontSize = 14.sp)
                }
            }
        }
    }
}

// ─── Диалог настроек API ключей (FOFA, Shodan, Censys, ZoomEye) ───
@Composable
fun ApiSettingsDialog(context: Context, onDismiss: () -> Unit) {
    // Загружаем сохранённые значения
    var fofaEmail  by remember { mutableStateOf(AuthManager.getFofaEmail(context)) }
    var fofaKey    by remember { mutableStateOf(AuthManager.getFofaKey(context)) }
    var shodanKey  by remember { mutableStateOf(AuthManager.getShodanKey(context)) }
    var censysId   by remember { mutableStateOf(AuthManager.getCensysId(context)) }
    var censysSec  by remember { mutableStateOf(AuthManager.getCensysSecret(context)) }
    var zoomeyeKey by remember { mutableStateOf(AuthManager.getZoomEyeKey(context)) }
    var savedOk    by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Заголовок
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔑", fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("API Ключи", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Ключи для поиска камер через FOFA, Shodan, Censys, ZoomEye",
                    fontSize = 12.sp, color = Gray500, lineHeight = 16.sp
                )
                Spacer(Modifier.height(18.dp))

                // ── FOFA ──────────────────────────────────────────────────
                ApiSectionHeader("FOFA", "🔍", Color(0xFF1565C0))
                Spacer(Modifier.height(8.dp))
                ApiTextField(
                    value = fofaEmail,
                    onValueChange = { fofaEmail = it },
                    label = "Email (FOFA аккаунт)",
                    placeholder = "user@example.com"
                )
                Spacer(Modifier.height(6.dp))
                ApiTextField(
                    value = fofaKey,
                    onValueChange = { fofaKey = it },
                    label = "API Key",
                    placeholder = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                    isSecret = true
                )
                Spacer(Modifier.height(14.dp))

                // ── Shodan ────────────────────────────────────────────────
                ApiSectionHeader("Shodan", "📡", Color(0xFFFF5722))
                Spacer(Modifier.height(8.dp))
                ApiTextField(
                    value = shodanKey,
                    onValueChange = { shodanKey = it },
                    label = "API Key",
                    placeholder = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                    isSecret = true
                )
                Spacer(Modifier.height(14.dp))

                // ── Censys ────────────────────────────────────────────────
                ApiSectionHeader("Censys", "🔭", Color(0xFF6A1B9A))
                Spacer(Modifier.height(8.dp))
                ApiTextField(
                    value = censysId,
                    onValueChange = { censysId = it },
                    label = "API ID",
                    placeholder = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                )
                Spacer(Modifier.height(6.dp))
                ApiTextField(
                    value = censysSec,
                    onValueChange = { censysSec = it },
                    label = "API Secret",
                    placeholder = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                    isSecret = true
                )
                Spacer(Modifier.height(14.dp))

                // ── ZoomEye ───────────────────────────────────────────────
                ApiSectionHeader("ZoomEye", "👁", Color(0xFF00838F))
                Spacer(Modifier.height(8.dp))
                ApiTextField(
                    value = zoomeyeKey,
                    onValueChange = { zoomeyeKey = it },
                    label = "API Key",
                    placeholder = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
                    isSecret = true
                )

                Spacer(Modifier.height(20.dp))

                if (savedOk) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1B5E20).copy(alpha = 0.6f))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("✓", fontSize = 16.sp, color = Color(0xFF66BB6A))
                        Spacer(Modifier.width(8.dp))
                        Text("Ключи сохранены", fontSize = 13.sp, color = Color(0xFF66BB6A))
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Отмена", color = Gray500)
                    }
                    Button(
                        onClick = {
                            // Сохраняем все ключи
                            AuthManager.saveFofaCredentials(context, fofaEmail.trim(), fofaKey.trim())
                            AuthManager.saveShodanKey(context, shodanKey.trim())
                            AuthManager.saveCensysCredentials(context, censysId.trim(), censysSec.trim())
                            AuthManager.saveZoomEyeKey(context, zoomeyeKey.trim())
                            savedOk = true
                        },
                        modifier = Modifier.weight(2f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Wine)
                    ) {
                        Text("💾  Сохранить", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ApiSectionHeader(name: String, icon: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(icon, fontSize = 16.sp)
        Spacer(Modifier.width(8.dp))
        Text(name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
fun ApiTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    isSecret: Boolean = false
) {
    var visible by remember { mutableStateOf(!isSecret) }
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, fontSize = 12.sp) },
        placeholder = { Text(placeholder, fontSize = 12.sp, color = Gray500) },
        modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (!visible) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = if (isSecret) ({
            IconButton(onClick = { visible = !visible }) {
                Text(if (visible) "🙈" else "👁", fontSize = 14.sp)
            }
        }) else null,
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = WineAccent,
            unfocusedBorderColor = BorderDark,
            focusedLabelColor = WineLight,
            unfocusedLabelColor = Gray500,
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            cursorColor = WineAccent
        ),
        textStyle = LocalTextStyle.current.copy(
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace
        ),
        shape = RoundedCornerShape(10.dp)
    )
}

// ─── Диалог расписания сканирования ───
@Composable
fun ScheduleDialog(context: Context, onDismiss: () -> Unit) {
    val schedules = remember { mutableStateListOf<ScanSchedule>() }
    var showAddDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        schedules.clear()
        schedules.addAll(ScanScheduleStorage.load(context))
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp).heightIn(max = 500.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("⏰ Расписание", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    TextButton(onClick = { showAddDialog = true }) {
                        Text("+ Добавить", color = Wine)
                    }
                }

                Spacer(Modifier.height(8.dp))

                if (schedules.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("⏰", fontSize = 36.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Нет запланированных сканирований", fontSize = 14.sp, color = Gray500)
                            Spacer(Modifier.height(4.dp))
                            Text("Нажмите «Добавить» для создания", fontSize = 12.sp, color = Gray500.copy(alpha = 0.6f))
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(schedules.toList(), key = { it.id }) { schedule ->
                            ScheduleItemCard(
                                schedule = schedule,
                                onToggle = {
                                    val updated = schedule.copy(enabled = !schedule.enabled)
                                    val idx = schedules.indexOfFirst { it.id == schedule.id }
                                    if (idx >= 0) schedules[idx] = updated
                                    val all = schedules.toList()
                                    ScanScheduleStorage.save(context, all)
                                    if (updated.enabled) ScanScheduler.scheduleAlarm(context, updated)
                                    else ScanScheduler.cancelAlarm(context, updated.id)
                                },
                                onDelete = {
                                    ScanScheduler.cancelAlarm(context, schedule.id)
                                    schedules.removeAll { it.id == schedule.id }
                                    ScanScheduleStorage.save(context, schedules.toList())
                                }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))
                TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Закрыть", color = WineLight)
                }
            }
        }
    }

    if (showAddDialog) {
        AddScheduleDialog(
            context = context,
            onDismiss = { showAddDialog = false },
            onAdd = { newSchedule ->
                schedules.add(newSchedule)
                ScanScheduleStorage.save(context, schedules.toList())
                ScanScheduler.scheduleAlarm(context, newSchedule)
                showAddDialog = false
                Toast.makeText(context, "Расписание добавлено: ${"%02d:%02d".format(newSchedule.hour, newSchedule.minute)}", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun ScheduleItemCard(schedule: ScanSchedule, onToggle: () -> Unit, onDelete: () -> Unit) {
    val dayNames = mapOf(
        Calendar.MONDAY to "Пн", Calendar.TUESDAY to "Вт", Calendar.WEDNESDAY to "Ср",
        Calendar.THURSDAY to "Чт", Calendar.FRIDAY to "Пт", Calendar.SATURDAY to "Сб", Calendar.SUNDAY to "Вс"
    )

    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark2), shape = RoundedCornerShape(12.dp)) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "%02d:%02d".format(schedule.hour, schedule.minute),
                        fontSize = 22.sp, fontWeight = FontWeight.Bold,
                        color = if (schedule.enabled) Wine else Gray500
                    )
                    Spacer(Modifier.width(8.dp))
                    if (schedule.pluginId != null) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Purple400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🔌 ${schedule.pluginId}", fontSize = 10.sp, color = Purple400)
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Text(schedule.subnet, fontSize = 12.sp, color = WineLight, fontFamily = FontFamily.Monospace)
                if (schedule.daysOfWeek.isNotEmpty()) {
                    val days = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)
                        .filter { it in schedule.daysOfWeek }
                        .mapNotNull { dayNames[it] }
                        .joinToString(", ")
                    Text(days, fontSize = 11.sp, color = Gray500)
                } else {
                    Text("Ежедневно", fontSize = 11.sp, color = Gray500)
                }
                if (schedule.lastRunMs > 0) {
                    val fmt = java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(schedule.lastRunMs))
                    Text("Последний: $fmt (${schedule.lastResultCount} найдено)", fontSize = 10.sp, color = Gray500.copy(alpha = 0.6f))
                }
            }
            Switch(
                checked = schedule.enabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(checkedTrackColor = Wine, checkedThumbColor = Color.White)
            )
            Spacer(Modifier.width(4.dp))
            Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(Red400.copy(alpha = 0.1f)).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun AddScheduleDialog(context: Context, onDismiss: () -> Unit, onAdd: (ScanSchedule) -> Unit) {
    var subnet by remember { mutableStateOf("") }
    var hour by remember { mutableStateOf("08") }
    var minute by remember { mutableStateOf("00") }
    var multiPort by remember { mutableStateOf(true) }
    val selectedDays = remember { mutableStateListOf<Int>() }
    var error by remember { mutableStateOf<String?>(null) }

    val daysList = listOf(
        Calendar.MONDAY to "Пн", Calendar.TUESDAY to "Вт", Calendar.WEDNESDAY to "Ср",
        Calendar.THURSDAY to "Чт", Calendar.FRIDAY to "Пт", Calendar.SATURDAY to "Сб", Calendar.SUNDAY to "Вс"
    )

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("Новое расписание", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)

                Spacer(Modifier.height(12.dp))

                // Подсеть
                OutlinedTextField(
                    value = subnet, onValueChange = { subnet = it; error = null },
                    label = { Text("Подсеть / диапазон") },
                    placeholder = { Text("192.168.1.0/24") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Wine, unfocusedBorderColor = BorderDark,
                        focusedLabelColor = Wine, cursorColor = Wine,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    ),
                    singleLine = true
                )

                Spacer(Modifier.height(12.dp))

                // Время
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = hour,
                        onValueChange = { v -> hour = v.filter { it.isDigit() }.take(2).let { if (it.isEmpty()) "" else if (it.toInt() > 23) "23" else it } },
                        label = { Text("Час") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine, unfocusedBorderColor = BorderDark,
                            focusedLabelColor = Wine, cursorColor = Wine,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = minute,
                        onValueChange = { v -> minute = v.filter { it.isDigit() }.take(2).let { if (it.isEmpty()) "" else if (it.toInt() > 59) "59" else it } },
                        label = { Text("Минута") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Wine, unfocusedBorderColor = BorderDark,
                            focusedLabelColor = Wine, cursorColor = Wine,
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }

                Spacer(Modifier.height(12.dp))

                // Дни недели
                Text("Дни недели (пусто = ежедневно)", fontSize = 12.sp, color = Gray500)
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    daysList.forEach { (day, name) ->
                        FilterChip(
                            selected = day in selectedDays,
                            onClick = { if (day in selectedDays) selectedDays.remove(day) else selectedDays.add(day) },
                            label = { Text(name, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Wine.copy(alpha = 0.2f),
                                selectedLabelColor = Wine
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true, selected = day in selectedDays,
                                borderColor = BorderDark, selectedBorderColor = Wine.copy(alpha = 0.5f)
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Multi-port
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Multi-port сканирование", fontSize = 13.sp, color = Color.White, modifier = Modifier.weight(1f))
                    Switch(
                        checked = multiPort,
                        onCheckedChange = { multiPort = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = Wine, checkedThumbColor = Color.White)
                    )
                }

                if (error != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(error!!, fontSize = 12.sp, color = Red400)
                }

                Spacer(Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gray500),
                        border = BorderStroke(1.dp, BorderDark)
                    ) { Text("Отмена") }

                    Button(
                        onClick = {
                            val trimmed = subnet.trim()
                            if (trimmed.isEmpty()) { error = "Введите подсеть"; return@Button }
                            val ips = IpParser.parse(trimmed)
                            if (ips.isEmpty()) { error = "Неверный формат подсети"; return@Button }
                            val h = hour.toIntOrNull() ?: 8
                            val m = minute.toIntOrNull() ?: 0

                            val newSchedule = ScanSchedule(
                                id = ScanScheduleStorage.nextId(context),
                                subnet = trimmed,
                                port = DahuaScanner.DEFAULT_PORT,
                                multiPort = multiPort,
                                hour = h,
                                minute = m,
                                daysOfWeek = selectedDays.toSet()
                            )
                            onAdd(newSchedule)
                        },
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Wine, contentColor = Color.White)
                    ) { Text("Добавить") }
                }
            }
        }
    }
}

@Composable
fun ScannerTab(
    ipInput: String, onIpChange: (String) -> Unit,
    portInput: String, onPortChange: (String) -> Unit,
    parseError: String?, isScanning: Boolean, progress: ScanProgress?,
    results: List<ScanResult>,
    multiPortMode: Boolean, onMultiPortChange: (Boolean) -> Unit,
    portSelectMode: Boolean, onPortSelectChange: (Boolean) -> Unit,
    selectedPorts: MutableList<Int>,
    activePluginId: String? = null,
    pluginSelectedPorts: MutableList<Int> = mutableListOf(),
    onScan: () -> Unit, onStop: () -> Unit,
    onResultClick: (ScanResult) -> Unit,
    onMyNetwork: () -> Unit,
    context: Context,
    logLines: List<String> = emptyList(),
    showLogs: Boolean = false,
    onToggleLogs: () -> Unit = {}
) {
    // ── Пикер файлов ip:port ──
    // Парсим строки вида: ip:port, ip, диапазоны, CIDR — всё что знает IpParser
    // Дополнительно: если строка содержит ":" — вытаскиваем ip-часть
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val lines = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readLines() ?: emptyList()
            val parsed = buildString {
                for (raw in lines) {
                    val trimmed = raw.trim()
                    if (trimmed.isEmpty() || trimmed.startsWith("#")) continue
                    // ip:port → берём только ip часть для IpParser, порт игнорируем
                    // (IpParser сам не понимает ip:port, добавляем только ip)
                    val ipPart = if (trimmed.matches(Regex("\\d+\\.\\d+\\.\\d+\\.\\d+:\\d+"))) {
                        trimmed.substringBefore(":")
                    } else trimmed
                    if (ipPart.isNotEmpty()) appendLine(ipPart)
                }
            }.trimEnd()
            if (parsed.isNotEmpty()) {
                val newInput = if (ipInput.isBlank()) parsed else "${ipInput.trimEnd()}\n$parsed"
                onIpChange(newInput)
                Toast.makeText(context, "Загружено ${lines.count { it.isNotBlank() }} строк", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Ошибка чтения файла: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // ── OSINT загрузка IP (адаптивно: показываем кнопки только для настроенных сервисов) ──
    val osintScope = rememberCoroutineScope()

    // Читаем ключи — перечитываем при каждой композиции чтобы отражать изменения в настройках
    val hasFofa    = remember { mutableStateOf(AuthManager.getFofaEmail(context).isNotEmpty() && AuthManager.getFofaKey(context).isNotEmpty()) }
    val hasShodan  = remember { mutableStateOf(AuthManager.getShodanKey(context).isNotEmpty()) }
    val hasZoomEye = remember { mutableStateOf(AuthManager.getZoomEyeKey(context).isNotEmpty()) }
    val hasCensys  = remember { mutableStateOf(AuthManager.getCensysId(context).isNotEmpty() && AuthManager.getCensysSecret(context).isNotEmpty()) }

    // Перечитываем ключи при каждом показе (на случай если пользователь только что сохранил)
    LaunchedEffect(Unit) {
        hasFofa.value    = AuthManager.getFofaEmail(context).isNotEmpty() && AuthManager.getFofaKey(context).isNotEmpty()
        hasShodan.value  = AuthManager.getShodanKey(context).isNotEmpty()
        hasZoomEye.value = AuthManager.getZoomEyeKey(context).isNotEmpty()
        hasCensys.value  = AuthManager.getCensysId(context).isNotEmpty() && AuthManager.getCensysSecret(context).isNotEmpty()
    }

    // loadingService: null = никто не грузит, иначе имя сервиса
    var osintLoading by remember { mutableStateOf<String?>(null) }
    var osintStatusMsg by remember { mutableStateOf<String?>(null) }

    fun loadOsintIps(service: String) {
        osintLoading = service
        osintStatusMsg = "Запрос к $service..."
        osintScope.launch {
            val result: Result<List<OsintService.OsintResult>> = when (service) {
                "FOFA" -> {
                    val q = if (selectedPorts.contains(554)) OsintService.Queries.FOFA_RTSP else OsintService.Queries.FOFA_IPC
                    OsintService.searchFofa(AuthManager.getFofaEmail(context), AuthManager.getFofaKey(context), q, size = 500)
                }
                "Shodan" -> {
                    val q = if (selectedPorts.contains(554)) OsintService.Queries.SHODAN_RTSP else OsintService.Queries.SHODAN_IPC
                    OsintService.searchShodan(AuthManager.getShodanKey(context), q, pages = 3)
                }
                "ZoomEye" -> {
                    val q = if (selectedPorts.contains(554)) OsintService.Queries.ZOOMEYE_RTSP else OsintService.Queries.ZOOMEYE_IPC
                    OsintService.searchZoomEye(AuthManager.getZoomEyeKey(context), q, pages = 3)
                }
                "Censys" -> {
                    val q = if (selectedPorts.contains(554)) OsintService.Queries.CENSYS_RTSP else OsintService.Queries.CENSYS_IPC
                    OsintService.searchCensys(AuthManager.getCensysId(context), AuthManager.getCensysSecret(context), q, perPage = 100)
                }
                else -> Result.failure(Exception("Unknown service"))
            }
            osintLoading = null
            result.onSuccess { list ->
                val newIps = list.map { it.ip }.filter { it.isNotEmpty() }.distinct()
                if (newIps.isEmpty()) {
                    osintStatusMsg = "$service: ничего не найдено"
                    return@onSuccess
                }
                val merged = if (ipInput.isBlank()) newIps.joinToString("\n")
                             else "${ipInput.trimEnd()}\n${newIps.joinToString("\n")}"
                onIpChange(merged)
                osintStatusMsg = "$service: +${newIps.size} IP ✓"
                Toast.makeText(context, "$service добавил ${newIps.size} IP", Toast.LENGTH_SHORT).show()
            }.onFailure { e ->
                osintStatusMsg = "$service ошибка: ${e.message?.take(50)}"
            }
        }
    }

    // FIX: results — mutableStateListOf, remember(results) НЕ триггерится при add().
    // Используем results.size как ключ — перекомпозиция гарантирована при каждом новом элементе.
    // successResults — только результаты С логином/паролем (не пустые credentials)
    // Результаты с пустыми login+password → в blockedResults (нет доступа)
    val successResults = remember(results.size) { results.filter { !it.blocked && (it.login.isNotEmpty() || it.password.isNotEmpty()) } }
    val blockedResults = remember(results.size) { results.filter { it.blocked || (it.login.isEmpty() && it.password.isEmpty()) } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Цель", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Gray500)
                        OutlinedButton(
                            onClick = onMyNetwork,
                            enabled = !isScanning,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("📡", fontSize = 14.sp)
                            Spacer(Modifier.width(4.dp))
                            Text("Моя сеть", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // --- Локальный IP инфо-блок ---
                    val localNet = remember { mutableStateOf<LocalNetwork?>(null) }
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            localNet.value = NetworkUtils.getLocalNetwork(context)
                        }
                    }
                    localNet.value?.let { net ->
                        Spacer(Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BgDark, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val typeIcon = when (net.networkType) {
                                "WiFi" -> "📶"
                                "Ethernet" -> "🔌"
                                "USB" -> "🔗"
                                "VPN" -> "🛡️"
                                "Mobile" -> "📱"
                                else -> "🌐"
                            }
                            Text(
                                "$typeIcon ${net.ip}",
                                fontSize = 12.sp,
                                color = Color(0xFF4FC3F7),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Medium
                            )
                            if (net.gateway.isNotEmpty()) {
                                Text(
                                    "GW: ${net.gateway}",
                                    fontSize = 11.sp,
                                    color = Gray500,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Performance: when ipInput is huge (file-loaded IPs), a standard
                    // OutlinedTextField re-measures the entire multi-thousand-line string
                    // on every recomposition. We switch to two modes:
                    //  • < 50 lines → normal BasicTextField (full editable, looks same)
                    //  • ≥ 50 lines → compact read-only badge showing count + first 3 lines,
                    //    with a "Редактировать" chip to switch back to edit mode
                    val ipLineCount = remember(ipInput) { ipInput.count { it == '\n' } + 1 }
                    var ipEditMode by remember { mutableStateOf(false) }
                    // Auto-collapse edit mode when new bulk IPs are loaded
                    LaunchedEffect(ipLineCount) { if (ipLineCount >= 50) ipEditMode = false }

                    if (ipLineCount >= 50 && !ipEditMode) {
                        // ── Компактный режим: только счётчик + превью ──
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(BgDark)
                                .border(1.dp, if (parseError != null) Red400 else BorderDark, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Wine.copy(alpha = 0.15f))
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                "$ipLineCount строк",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = WineAccent,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        Spacer(Modifier.width(8.dp))
                                        Text("загружено", fontSize = 11.sp, color = Gray500)
                                    }
                                    if (!isScanning) {
                                        Text(
                                            "✎ Ред.",
                                            fontSize = 11.sp,
                                            color = WineAccent,
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .clickable { ipEditMode = true }
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                // Первые 3 строки как превью
                                val previewLines = remember(ipInput) {
                                    ipInput.lineSequence().take(3).joinToString("\n")
                                }
                                Text(
                                    "$previewLines\n…",
                                    fontSize = 11.sp,
                                    color = Gray500,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    } else {
                        // ── Обычный режим редактирования (< 50 строк или явно открыт) ──
                        val borderColor = when {
                            parseError != null -> Red400
                            else -> BorderDark
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(BgDark)
                                .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            BasicTextField(
                                value = ipInput,
                                onValueChange = { if (!isScanning) onIpChange(it) },
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                    color = Color.White,
                                    lineHeight = 20.sp
                                ),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                                enabled = !isScanning,
                                cursorBrush = SolidColor(Wine),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 72.dp, max = 200.dp),
                                maxLines = 12,
                                decorationBox = { innerTextField ->
                                    Box {
                                        if (ipInput.isEmpty()) {
                                            Text(
                                                "192.168.1.1\n10.0.0.1-10.0.0.50\n172.16.0.0/24",
                                                color = Gray500.copy(alpha = 0.5f),
                                                fontSize = 13.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 20.sp
                                            )
                                        }
                                        innerTextField()
                                    }
                                }
                            )
                        }
                        if (ipLineCount >= 50) {
                            // Кнопка "свернуть" когда в режиме редактирования с большим списком
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "▲ Свернуть",
                                fontSize = 11.sp,
                                color = Gray500,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { ipEditMode = false }
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // ── Кнопка загрузки файла ip:port ──
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { filePicker.launch("text/*") },
                            enabled = !isScanning,
                            shape = RoundedCornerShape(20.dp),
                            border = BorderStroke(1.dp, Color(0xFF4FC3F7).copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF4FC3F7)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("📁", fontSize = 14.sp)
                            Spacer(Modifier.width(4.dp))
                            Text("Загрузить IP из файла", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (ipInput.isNotBlank()) {
                            OutlinedButton(
                                onClick = { onIpChange("") },
                                enabled = !isScanning,
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, Red400.copy(alpha = 0.4f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("✕", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(3.dp))
                                Text("Очистить", fontSize = 11.sp)
                            }
                        }
                    }

                    // ── OSINT кнопки (только для настроенных сервисов) ──
                    val osintServices = buildList {
                        if (hasFofa.value)    add(Triple("FOFA",    "🛰", Color(0xFFFF6B35)))
                        if (hasShodan.value)  add(Triple("Shodan",  "📡", Color(0xFF00BCD4)))
                        if (hasZoomEye.value) add(Triple("ZoomEye", "🔭", Color(0xFF9C27B0)))
                        if (hasCensys.value)  add(Triple("Censys",  "🌐", Color(0xFF4CAF50)))
                    }

                    if (osintServices.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        // Заголовок секции
                        Text(
                            "🔍 Добавить IP из OSINT",
                            fontSize = 11.sp,
                            color = Gray500,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(4.dp))
                        // Кнопки — разбиваем на строки по 2 если сервисов > 2
                        val chunked = osintServices.chunked(2)
                        chunked.forEach { rowItems ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                rowItems.forEach { (name, icon, color) ->
                                    val isLoading = osintLoading == name
                                    OutlinedButton(
                                        onClick = { loadOsintIps(name) },
                                        enabled = !isScanning && osintLoading == null,
                                        shape = RoundedCornerShape(20.dp),
                                        border = BorderStroke(1.dp, color.copy(alpha = if (isLoading) 0.3f else 0.6f)),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = color),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(30.dp).weight(1f)
                                    ) {
                                        if (isLoading) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(12.dp),
                                                color = color,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Text(icon, fontSize = 13.sp)
                                        }
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            if (isLoading) "$name..." else name,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                                // Заполнитель если нечётное количество
                                if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                            }
                            if (rowItems != chunked.last()) Spacer(Modifier.height(4.dp))
                        }

                        // Статус последней операции
                        if (osintStatusMsg != null) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                osintStatusMsg!!,
                                color = when {
                                    osintStatusMsg!!.contains("✓")     -> Color(0xFF4CAF50)
                                    osintStatusMsg!!.contains("ошибка") -> Red400
                                    else                                -> Color(0xFFFF9800)
                                },
                                fontSize = 11.sp,
                                modifier = Modifier.padding(start = 2.dp)
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                    }

                    if (parseError != null) {
                        Text(parseError, color = Red400, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Multi-port сканирование", fontSize = 13.sp, color = Color.White)
                            Text(
                                if (multiPortMode) "Все порты: 37777, 80, 8080, 34567..." else "Только порт Dahua (37777)",
                                fontSize = 11.sp, color = Gray500
                            )
                        }
                        Switch(
                            checked = multiPortMode,
                            onCheckedChange = onMultiPortChange,
                            enabled = !isScanning,
                            colors = SwitchDefaults.colors(checkedTrackColor = Wine, checkedThumbColor = Color.White)
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Выбор портов", fontSize = 13.sp, color = Color.White)
                            Text(
                                if (portSelectMode && selectedPorts.isNotEmpty()) "Выбрано: ${selectedPorts.size} портов"
                                else "Выберите нужные порты вручную",
                                fontSize = 11.sp, color = Gray500
                            )
                        }
                        Switch(
                            checked = portSelectMode,
                            onCheckedChange = onPortSelectChange,
                            enabled = !isScanning,
                            colors = SwitchDefaults.colors(checkedTrackColor = WineLight, checkedThumbColor = Color.White)
                        )
                    }

                    if (portSelectMode) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val allSelected = selectedPorts.size == ALL_PORT_OPTIONS.size
                            FilterChip(
                                selected = allSelected,
                                onClick = {
                                    if (allSelected) {
                                        // Снимаем "все" — очищаем порты
                                        selectedPorts.clear()
                                    } else {
                                        // "Все порты" = режим multiPort (он сканирует все CAMERA_PORTS эффективно)
                                        // Вместо набивки 30+ портов в selectedPorts просто переключаемся в multiPort
                                        selectedPorts.clear()
                                        selectedPorts.addAll(ALL_PORT_OPTIONS.map { it.port })
                                    }
                                },
                                label = { Text("Все", fontSize = 11.sp) },
                                enabled = !isScanning,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Wine.copy(alpha = 0.2f),
                                    selectedLabelColor = Wine
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = allSelected,
                                    borderColor = BorderDark, selectedBorderColor = Wine.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )

                            ALL_PORT_OPTIONS.forEach { opt ->
                                val sel = opt.port in selectedPorts
                                // Плавный переход цвета при выборе/снятии порта
                                val chipBg by animateColorAsState(
                                    targetValue = if (sel) opt.color.copy(alpha = 0.2f) else Color.Transparent,
                                    animationSpec = tween(180), label = "chip_bg_${opt.port}"
                                )
                                val chipLabel by animateColorAsState(
                                    targetValue = if (sel) opt.color else Gray500,
                                    animationSpec = tween(180), label = "chip_label_${opt.port}"
                                )
                                val chipBorder by animateColorAsState(
                                    targetValue = if (sel) opt.color.copy(alpha = 0.5f) else BorderDark,
                                    animationSpec = tween(180), label = "chip_border_${opt.port}"
                                )
                                FilterChip(
                                    selected = sel,
                                    onClick = {
                                        if (sel) selectedPorts.remove(opt.port)
                                        else selectedPorts.add(opt.port)
                                    },
                                    label = { Text(opt.label, fontSize = 11.sp, color = chipLabel) },
                                    enabled = !isScanning,
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = chipBg,
                                        containerColor = chipBg,
                                        selectedLabelColor = chipLabel,
                                        labelColor = chipLabel
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = sel,
                                        borderColor = chipBorder, selectedBorderColor = chipBorder
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    if (!multiPortMode && !portSelectMode) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Порт:", fontSize = 13.sp, color = Gray500)
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = portInput, onValueChange = onPortChange,
                                modifier = Modifier.width(100.dp),
                                textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
                                singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                enabled = !isScanning, shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Wine, unfocusedBorderColor = BorderDark,
                                    focusedContainerColor = BgDark, unfocusedContainerColor = BgDark)
                            )
                        }
                    }

                    // Баннер активного плагина + выбор портов
                    if (activePluginId != null) {
                        val activePlugin = remember(activePluginId) { PluginManager.getPlugins().find { it.id == activePluginId } }
                        if (activePlugin != null) {
                            Spacer(Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = Purple400.copy(alpha = 0.12f)),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, Purple400.copy(alpha = 0.3f))
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("⚡", fontSize = 16.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Плагин: ${activePlugin.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Purple400)
                                            val portsLabel = if (pluginSelectedPorts.isNotEmpty())
                                                "${activePlugin.checks.size} проверок • ${pluginSelectedPorts.size}/${activePlugin.ports.size} портов"
                                            else
                                                "${activePlugin.checks.size} проверок • ${activePlugin.ports.size} портов (все)"
                                            Text(portsLabel, fontSize = 10.sp, color = Gray500)
                                        }
                                        Box(
                                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Purple400.copy(alpha = 0.2f)).padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text("Активен", fontSize = 10.sp, color = Purple400, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    // Выбор портов плагина
                                    if (activePlugin.ports.size > 1) {
                                        Spacer(Modifier.height(8.dp))
                                        Text("Порты плагина:", fontSize = 11.sp, color = Gray500)
                                        Spacer(Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            // Кнопка "Все"
                                            val allPluginSelected = pluginSelectedPorts.isEmpty() ||
                                                pluginSelectedPorts.size == activePlugin.ports.size
                                            FilterChip(
                                                selected = allPluginSelected,
                                                onClick = {
                                                    pluginSelectedPorts.clear()
                                                },
                                                label = { Text("Все", fontSize = 11.sp) },
                                                enabled = !isScanning,
                                                colors = FilterChipDefaults.filterChipColors(
                                                    selectedContainerColor = Purple400.copy(alpha = 0.2f),
                                                    selectedLabelColor = Purple400
                                                ),
                                                border = FilterChipDefaults.filterChipBorder(
                                                    enabled = true, selected = allPluginSelected,
                                                    borderColor = BorderDark, selectedBorderColor = Purple400.copy(alpha = 0.5f)
                                                ),
                                                shape = RoundedCornerShape(20.dp)
                                            )

                                            activePlugin.ports.forEach { port ->
                                                val sel = if (pluginSelectedPorts.isEmpty()) true else port in pluginSelectedPorts
                                                FilterChip(
                                                    selected = sel,
                                                    onClick = {
                                                        if (pluginSelectedPorts.isEmpty()) {
                                                            // Переход из режима "все" — выбираем все кроме нажатого
                                                            pluginSelectedPorts.addAll(activePlugin.ports.filter { it != port })
                                                        } else if (port in pluginSelectedPorts) {
                                                            pluginSelectedPorts.remove(port)
                                                            // Если убрали все — вернуть в режим "все"
                                                            if (pluginSelectedPorts.isEmpty()) {
                                                                // пустой = все
                                                            }
                                                        } else {
                                                            pluginSelectedPorts.add(port)
                                                            // Если выбрали все обратно — сбросить в режим "все"
                                                            if (pluginSelectedPorts.size == activePlugin.ports.size) {
                                                                pluginSelectedPorts.clear()
                                                            }
                                                        }
                                                    },
                                                    label = { Text("$port", fontSize = 11.sp) },
                                                    enabled = !isScanning,
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = Purple400.copy(alpha = 0.2f),
                                                        selectedLabelColor = Purple400
                                                    ),
                                                    border = FilterChipDefaults.filterChipBorder(
                                                        enabled = true, selected = sel,
                                                        borderColor = BorderDark, selectedBorderColor = Purple400.copy(alpha = 0.5f)
                                                    ),
                                                    shape = RoundedCornerShape(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // ─── Кнопки управления сканом ────────────────────────────────────────────
                    // Infinite transition всегда зарегистрирована (Compose правила хуков),
                    // но используем её значение только когда isScanning = true
                    val scanPulse = rememberInfiniteTransition(label = "scanPulse")
                    val scanGlowRaw by scanPulse.animateFloat(
                        initialValue = 0.55f, targetValue = 1f,
                        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
                        label = "scanGlowAlpha"
                    )
                    // Когда не сканируем — возвращаем 1f (нет пульса), при сканировании — живое значение
                    val scanGlow = if (isScanning) scanGlowRaw else 1f
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Кнопка СКАНИРОВАТЬ — с градиентным фоном
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (!isScanning && ipInput.isNotBlank())
                                        Brush.horizontalGradient(listOf(WineDark, Wine, WineLight.copy(alpha = 0.8f)))
                                    else
                                        Brush.horizontalGradient(listOf(Wine.copy(alpha = 0.3f), Wine.copy(alpha = 0.2f)))
                                )
                                .border(
                                    1.dp,
                                    if (isScanning) Wine.copy(alpha = scanGlow * 0.5f) else Wine.copy(alpha = 0.4f),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable(enabled = !isScanning && ipInput.isNotBlank()) { onScan() },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                                if (isScanning) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = Color.White.copy(alpha = 0.85f),
                                        strokeWidth = 2.dp,
                                        trackColor = Color.Transparent
                                    )
                                } else {
                                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(20.dp), tint = Color.White)
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    if (isScanning) "Сканирование..." else if (activePluginId != null) "⚡ Плагин-скан" else "Сканировать",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 15.sp,
                                    color = Color.White,
                                    letterSpacing = 0.3.sp
                                )
                            }
                        }
                        if (isScanning) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Red400.copy(alpha = 0.12f))
                                    .border(1.dp, Red400.copy(alpha = scanGlow * 0.6f), RoundedCornerShape(14.dp))
                                    .clickable { onStop() },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Close, null, modifier = Modifier.size(20.dp), tint = Red400)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Стоп", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Red400)
                                }
                            }
                        }
                    }
                }
            }
        }

        progress?.let { p -> if (p.total > 0) { item { ProgressCard(p, isScanning) } } }

        // ── Лог-панель ──
        if ((isScanning || logLines.isNotEmpty()) && progress != null && progress.total > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF080808)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1A2A1A))
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(8.dp).background(
                                    if (isScanning) Color(0xFF00FF88) else Color(0xFF334433),
                                    CircleShape
                                ))
                                Spacer(Modifier.width(6.dp))
                                Text("TERMINAL", fontSize = 9.sp, fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00CC66), letterSpacing = 2.sp)
                                if (logLines.isNotEmpty()) {
                                    Spacer(Modifier.width(6.dp))
                                    Text("[${logLines.size}]", fontSize = 9.sp, color = Color(0xFF336633), fontFamily = FontFamily.Monospace)
                                }
                            }
                            TextButton(onClick = onToggleLogs, contentPadding = PaddingValues(0.dp)) {
                                Text(if (showLogs) "скрыть ▲" else "развернуть ▼",
                                    fontSize = 10.sp, color = Color(0xFF666666))
                            }
                        }
                        // Последняя строка — всегда видна
                        if (logLines.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            val lastLine = logLines.last()
                            val lastIsSuccess = "✓" in lastLine
                            val lastIsServer  = listOf("Redis","MongoDB","Docker","Elastic","Grafana","Jupyter","MySQL","Postgres","FTP","Webmin","Jenkins","Portainer","CouchDB","Memcached").any { it in lastLine }
                            val lastColor = when {
                                lastIsSuccess || lastIsServer -> Color(0xFF00E676)
                                "🔒" in lastLine -> Color(0xFFFF7043)
                                "CVE" in lastLine || "⚡" in lastLine -> Color(0xFFFFB300)
                                "SSH" in lastLine -> Color(0xFFFFA726)
                                else -> Color(0xFF4A7A4A)
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0A120A))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("▶ ", fontSize = 10.sp, color = lastColor, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Text(
                                    lastLine,
                                    fontSize = 10.sp,
                                    color = lastColor,
                                    fontFamily = FontFamily.Monospace,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    fontWeight = if (lastIsSuccess || lastIsServer) FontWeight.Medium else FontWeight.Normal
                                )
                            }
                        }
                        // Полный лог — только если развёрнут
                        if (showLogs && logLines.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            val visibleLines = remember(logLines.size) {
                                if (logLines.size > 120) logLines.subList(logLines.size - 120, logLines.size).toList()
                                else logLines.toList()
                            }
                            Box(modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF080C08))
                                .border(1.dp, Color(0xFF1E2E1E), RoundedCornerShape(10.dp))
                            ) {
                                val logScrollState = rememberScrollState(Int.MAX_VALUE)
                                LaunchedEffect(visibleLines.size) {
                                    logScrollState.scrollTo(logScrollState.maxValue)
                                }
                                Column(modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(logScrollState)
                                    .padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    visibleLines.forEach { line ->
                                        // Определяем тип строки и форматируем красиво
                                        val isSuccess   = "✓" in line
                                        val isCve       = "CVE" in line || "exploit" in line.lowercase() || "🔍" in line
                                        val isOpen      = "открыты порты" in line || "OPEN" in line || "открыт" in line
                                        val isEmpty     = "нет результата" in line || "❌" in line
                                        val isError     = "ERROR" in line || "ошибка" in line.lowercase()
                                        val isBlocked   = "🔒" in line || "blocked" in line.lowercase()
                                        val isSsh       = "SSH" in line || "Telnet" in line
                                        val isServer    = listOf("Redis","MongoDB","Docker","Elastic","Grafana","Jupyter","MySQL","Postgres","FTP","Webmin","Jenkins","Portainer","CouchDB","Memcached").any { it in line }

                                        // Иконка + цвет по типу
                                        val (icon, textColor, dimColor) = when {
                                            isSuccess  -> Triple("✦", Color(0xFF00E676), Color(0xFF004D1A))
                                            isServer   -> Triple("⬡", Color(0xFF29B6F6), Color(0xFF003050))
                                            isCve      -> Triple("⚡", Color(0xFFFFB300), Color(0xFF3A2800))
                                            isBlocked  -> Triple("🔒", Color(0xFFBF360C), Color(0xFF2A0A00))
                                            isSsh      -> Triple("⌨", Color(0xFFFFA726), Color(0xFF2A1800))
                                            isOpen     -> Triple("◉", Color(0xFF4FC3F7), Color(0xFF00203A))
                                            isEmpty    -> Triple("·", Color(0xFF1E3A1E), Color(0xFF0A0F0A))
                                            isError    -> Triple("✗", Color(0xFFEF5350), Color(0xFF2A0000))
                                            else       -> Triple("›", Color(0xFF3A6A3A), Color(0xFF080C08))
                                        }

                                        // Очищаем технический мусор из строки
                                        val cleanLine = line
                                            .replace(Regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}:\\d+ → "), "")
                                            .let { if (isSuccess || isServer || isCve || isBlocked) line else it }
                                            .trim()

                                        if (!isEmpty) { // скрываем мусорные строки "нет результата"
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 1.dp)
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(if (isSuccess || isServer) dimColor else Color.Transparent)
                                                    .padding(horizontal = if (isSuccess || isServer) 6.dp else 0.dp, vertical = if (isSuccess || isServer) 2.dp else 0.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    icon,
                                                    fontSize = 9.sp,
                                                    color = textColor,
                                                    fontFamily = FontFamily.Monospace,
                                                    modifier = Modifier.width(14.dp)
                                                )
                                                Text(
                                                    cleanLine,
                                                    fontSize = 9.5.sp,
                                                    color = textColor,
                                                    fontFamily = FontFamily.Monospace,
                                                    lineHeight = 14.sp,
                                                    fontWeight = if (isSuccess || isServer) FontWeight.Medium else FontWeight.Normal
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (results.isNotEmpty()) { item { StatsStrip(results) } }

        if (successResults.isNotEmpty()) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Brush.horizontalGradient(listOf(WineDark.copy(alpha = 0.5f), Wine.copy(alpha = 0.2f))))
                            .border(1.dp, Wine.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(WineAccent))
                            Spacer(Modifier.width(5.dp))
                            Text("НАЙДЕНО", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = WineAccent, letterSpacing = 1.5.sp)
                            Spacer(Modifier.width(6.dp))
                            Text("${successResults.size}", fontSize = 10.sp, color = Wine, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items(successResults, key = { "${it.ip}:${it.port}:${it.timestampMs}" }) { result -> ResultCard(result, context) { onResultClick(result) } }
        }
        if (blockedResults.isNotEmpty()) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Orange400.copy(alpha = 0.12f))
                            .border(1.dp, Orange400.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Orange400))
                            Spacer(Modifier.width(5.dp))
                            Text("ЗАБЛОКИРОВАНО", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Orange400, letterSpacing = 1.5.sp)
                            Spacer(Modifier.width(6.dp))
                            Text("${blockedResults.size}", fontSize = 10.sp, color = Orange400.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            items(blockedResults, key = { "blocked_${it.ip}:${it.timestampMs}" }) { result ->
                val timeFmt = remember(result.timestampMs) {
                    java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Orange400.copy(alpha = 0.18f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(12.dp))
                                .background(Brush.radialGradient(listOf(Orange400.copy(alpha = 0.2f), Orange400.copy(alpha = 0.05f)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, null, tint = Orange400, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(result.ip, fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("порт ${result.port} · $timeFmt", fontSize = 11.sp, color = Gray500)
                        }
                        Box(
                            modifier = Modifier.clip(RoundedCornerShape(8.dp))
                                .background(Orange400.copy(alpha = 0.12f))
                                .border(1.dp, Orange400.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("БЛОК", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Orange400, letterSpacing = 0.8.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FindingsTab(results: List<ScanResult>, onResultClick: (ScanResult) -> Unit, context: Context) {
    // ═══ ФИКС Bug 2: remember должны быть ДО любого conditional return ═══
    // Если remember вызывается ПОСЛЕ условного return — Compose теряет стабильность
    // при переходе empty→non-empty и не перекомпоновывает правильно.
    // Решение: все remember вверху, empty state через if внутри LazyColumn.
    var filterBrand by remember { mutableStateOf<String?>(null) }
    var filterPort by remember { mutableStateOf<Int?>(null) }
    // ZIP экспорт — state на уровне FindingsTab, не внутри LazyColumn item
    val findingsScope = rememberCoroutineScope()
    var zipExporting by remember { mutableStateOf(false) }
    var eightZipExporting by remember { mutableStateOf(false) }

    val filteredResults = remember(results, filterBrand, filterPort) {
        results.filter { r ->
            // Только с credentials — пустые login+password в FindingsTab не показываем
            !r.blocked && (r.login.isNotEmpty() || r.password.isNotEmpty()) &&
            (filterBrand == null || r.brand == filterBrand) &&
            (filterPort == null || r.port == filterPort)
        }
    }
    val cameras = remember(filteredResults) { filteredResults.filter { !isTerminal(it.brand) } }
    val terminals = remember(filteredResults) { filteredResults.filter { isTerminal(it.brand) } }
    val withSnapshotsCount = remember(results) { results.count { it.snapshot != null && it.snapshot.size > 100 } }

    // Все уникальные бренды и порты из всех результатов (не фильтрованных)
    val allBrands = remember(results) { results.map { it.brand }.distinct().sorted() }
    val allPorts = remember(results) { results.map { it.port }.distinct().sorted() }

    // Empty state — без ранного return, чтобы не нарушать порядок remember-вызовов
    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .clip(CircleShape)
                        .background(SurfaceDark2)
                        .border(1.dp, BorderDark, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("📷", fontSize = 40.sp)
                }
                Spacer(Modifier.height(16.dp))
                Text("Пока ничего не найдено", fontSize = 16.sp, color = Gray500, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text("Запустите сканирование на вкладке", fontSize = 13.sp, color = Gray500.copy(alpha = 0.5f))
                Text("«Сканер»", fontSize = 13.sp, color = WineAccent.copy(alpha = 0.7f), fontWeight = FontWeight.SemiBold)
            }
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
            ) {
                Column {
                    // Gradient top bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            .background(Brush.horizontalGradient(listOf(WineDark, Wine, WineAccent, Wine, WineDark)))
                    )
                    Column(modifier = Modifier.padding(16.dp)) {
                    val withCreds = results.count { !it.blocked && (it.login.isNotEmpty() || it.password.isNotEmpty()) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("$withCreds", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = WineAccent)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("найдено", fontSize = 12.sp, color = Gray500)
                            if (filterBrand != null || filterPort != null) {
                                Text("показано: ${filteredResults.size}", fontSize = 11.sp, color = WineLight)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("📷 ${cameras.size} камер", Wine, Modifier.weight(1f))
                        StatChip("💻 ${terminals.size} терм.", Color(0xFFFFA726), Modifier.weight(1f))
                    }

                    // ─── Фильтр по бренду ───
                    if (allBrands.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Text("Фильтр по бренду:", fontSize = 11.sp, color = Gray500)
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = filterBrand == null,
                                onClick = { filterBrand = null },
                                label = { Text("Все", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Wine.copy(alpha = 0.2f),
                                    selectedLabelColor = Wine
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = filterBrand == null,
                                    borderColor = BorderDark, selectedBorderColor = Wine.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            allBrands.forEach { brand ->
                                val count = results.count { it.brand == brand }
                                FilterChip(
                                    selected = filterBrand == brand,
                                    onClick = { filterBrand = if (filterBrand == brand) null else brand },
                                    label = { Text("$brand ($count)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = brandColor(brand).copy(alpha = 0.2f),
                                        selectedLabelColor = brandColor(brand)
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = filterBrand == brand,
                                        borderColor = BorderDark, selectedBorderColor = brandColor(brand).copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    // ─── Фильтр по порту ───
                    if (allPorts.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        Text("Фильтр по порту:", fontSize = 11.sp, color = Gray500)
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = filterPort == null,
                                onClick = { filterPort = null },
                                label = { Text("Все", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = WineLight.copy(alpha = 0.2f),
                                    selectedLabelColor = WineLight
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = filterPort == null,
                                    borderColor = BorderDark, selectedBorderColor = WineLight.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            allPorts.forEach { port ->
                                val count = results.count { it.port == port }
                                FilterChip(
                                    selected = filterPort == port,
                                    onClick = { filterPort = if (filterPort == port) null else port },
                                    label = { Text("$port ($count)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WineLight.copy(alpha = 0.2f),
                                        selectedLabelColor = WineLight
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = filterPort == port,
                                        borderColor = BorderDark, selectedBorderColor = WineLight.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    // ─── Сброс фильтров ───
                    if (filterBrand != null || filterPort != null) {
                        Spacer(Modifier.height(6.dp))
                        TextButton(
                            onClick = { filterBrand = null; filterPort = null },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✕ Сбросить фильтры", fontSize = 12.sp, color = Red400)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val exportList = if (filterBrand != null || filterPort != null) filteredResults else results
                            val text = exportList.joinToString("\n") { r -> "${r.ip}:${r.port} ${credentialLabel(r.login, r.password)} [${r.brand}] ${r.model} ${r.channels}ch" }
                            cm.setPrimaryClip(ClipData.newPlainText("camera_all", text))
                            Toast.makeText(context, "Скопировано (${exportList.size})", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight), border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (filterBrand != null || filterPort != null) "Копировать отфильтрованные (${filteredResults.size})" else "Копировать все", fontSize = 13.sp)
                    }

                    // ── ZIP Экспорт со скриншотами ──
                    if (withSnapshotsCount > 0) {
                        Spacer(Modifier.height(6.dp))
                        Button(
                            onClick = {
                                if (!zipExporting) {
                                    zipExporting = true
                                    val exportList = if (filterBrand != null || filterPort != null) filteredResults else results
                                    findingsScope.launch {
                                        val ok = exportResultsZip(context, exportList)
                                        zipExporting = false
                                        if (ok) {
                                            Toast.makeText(context, "ZIP сохранён в Downloads/", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Ошибка создания ZIP", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20))
                        ) {
                            if (zipExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Создаётся ZIP...", fontSize = 13.sp)
                            } else {
                                Text("📦", fontSize = 14.sp)
                                Spacer(Modifier.width(6.dp))
                                Text("Скачать ZIP со скриншотами ($withSnapshotsCount фото)", fontSize = 13.sp)
                            }
                        }
                    }

                    // ── Кнопка: скачать ZIP с 8xxx IP:port ──
                    val eightPortsSet = setOf(8000, 8001, 8008, 8080, 8081, 8082, 8083, 8084, 8085, 8086, 8087, 8088, 8089, 8090, 8181, 8888, 8899)
                    val eightIpList = buildList {
                        for (r in results) {
                            if (r.port in eightPortsSet) add("${r.ip}:${r.port}")
                            for (p in r.openPortsList) {
                                if (p in eightPortsSet && p != r.port) add("${r.ip}:$p")
                            }
                        }
                    }.distinct()
                    if (eightIpList.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Button(
                            onClick = {
                                if (!eightZipExporting) {
                                    eightZipExporting = true
                                    findingsScope.launch {
                                        val ok = export8xxxZip(context, eightIpList)
                                        eightZipExporting = false
                                        if (ok) {
                                            Toast.makeText(context, "8xxx ZIP сохранён в Downloads/", Toast.LENGTH_LONG).show()
                                        } else {
                                            Toast.makeText(context, "Ошибка создания ZIP", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D47A1))
                        ) {
                            if (eightZipExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Создаётся 8xxx ZIP...", fontSize = 13.sp)
                            } else {
                                Text("🗂️", fontSize = 14.sp)
                                Spacer(Modifier.width(6.dp))
                                Text("Скачать 8xxx ZIP (${eightIpList.size} адресов)", fontSize = 13.sp)
                            }
                        }
                    } // end if (eightIpList.isNotEmpty())
                    } // end inner Column(padding)
                } // end outer Column
            }
        }

        if (cameras.isNotEmpty()) {
            item { Text("📷 КАМЕРЫ (${cameras.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Wine, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            val camWithPhoto = cameras.filter { it.snapshot != null && it.snapshot.size > 100 }
            val camWithoutPhoto = cameras.filter { it.snapshot == null || it.snapshot.size <= 100 }
            if (camWithPhoto.isNotEmpty()) {
                itemsIndexed(camWithPhoto, key = { _, r -> "cf_${r.ip}:${r.port}:${r.timestampMs}" }) { idx, result ->
                    AnimatedResultItem(idx) { FindingCard(result, context) { onResultClick(result) } }
                }
            }
            if (camWithoutPhoto.isNotEmpty()) {
                itemsIndexed(camWithoutPhoto, key = { _, r -> "cn_${r.ip}:${r.port}:${r.timestampMs}" }) { idx, result ->
                    AnimatedResultItem(camWithPhoto.size + idx) { ResultCard(result, context) { onResultClick(result) } }
                }
            }
        }

        if (terminals.isNotEmpty()) {
            item { Text("💻 ТЕРМИНАЛЫ (${terminals.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFA726), letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            itemsIndexed(terminals, key = { _, r -> "t_${r.ip}:${r.port}:${r.timestampMs}" }) { idx, result ->
                AnimatedResultItem(idx) { ResultCard(result, context) { onResultClick(result) } }
            }
        }
    }
}
// end FindingsTab

@Composable
fun FindingCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    var pressed by remember { mutableStateOf(false) }
    val cardScale by animateFloatAsState(
        targetValue = if (pressed) 0.974f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "findingScale"
    )
    val borderAlpha by animateFloatAsState(
        targetValue = if (pressed) 0.55f else 0.22f,
        animationSpec = tween(120),
        label = "findingBorderAlpha"
    )
    val accent = brandColor(result.brand)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = cardScale; scaleY = cardScale }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { onClick() }
                )
            },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = borderAlpha))
    ) {
        Column {
            if (result.snapshot != null && result.snapshot.size > 100) {
                val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot, 0, result.snapshot.size) }
                if (bmp != null) {
                    Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                        contentScale = ContentScale.Crop)
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${credentialLabel(result.login, result.password)}"))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Wine.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(credentialLabel(result.login, result.password), fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                    if (result.hasMic) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Red400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🎤", fontSize = 10.sp)
                        }
                    }
                    if (result.model.isNotEmpty() && result.model != "unknown") {
                        Text(result.model, fontSize = 11.sp, color = WineLight, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(timeFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun ProgressCard(p: ScanProgress, scanning: Boolean) {
    val rawPct = if (p.total > 0) (p.checked.toFloat() / p.total) else 0f
    val speed = if (p.ipsPerSecond > 0) p.ipsPerSecond.toDouble() else if (p.elapsedMs > 200) (p.checked * 1000.0 / p.elapsedMs) else 0.0
    val eta = if (p.etaMs > 0) (p.etaMs / 1000).toInt() else if (speed > 0.01 && p.checked < p.total) ((p.total - p.checked) / speed).toInt() else 0

    // Animated progress bar
    val animPct by animateFloatAsState(
        targetValue = rawPct,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "progressAnim"
    )
    val pct = animPct

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(18.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (scanning) BorderGlow.copy(alpha = 0.5f) else BorderDark)
    ) {
        Box {
            // Subtle gradient tint overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp))
                    .background(Brush.horizontalGradient(listOf(WineDark, Wine, WineLight, Wine, WineDark)))
            )
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (scanning) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Wine)
                            Spacer(Modifier.width(8.dp))
                        } else {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(
                                when { p.finished -> Wine; p.cancelled -> Orange400; else -> Gray500 }
                            ))
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(
                            if (p.finished) "Завершено" else if (p.cancelled) "Отменено" else "Сканирование",
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            color = when { p.finished -> WineAccent; p.cancelled -> Orange400; else -> Color.White }
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Wine.copy(alpha = 0.15f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("${(pct * 100).toInt()}%", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = WineAccent)
                    }
                }
                Spacer(Modifier.height(10.dp))
                // Улучшенная полоса прогресса
                Box(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(BgDark)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(pct.coerceIn(0f, 1f))
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Brush.horizontalGradient(listOf(WineDark, Wine, WineLight)))
                    )
                }
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(BgDark)
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatMini("Проверено", "${p.checked}/${p.total}", WineLight)
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderDark))
                    StatMini("Найдено", "${p.successful}", Wine)
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderDark))
                    StatMini("Порты", "${p.openPorts}", Color(0xFF4FC3F7))
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderDark))
                    StatMini("Блок", "${p.blocked}", Orange400)
                }
                if (speed > 0.01 || (scanning && eta > 0)) {
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        if (speed > 0.01) StatMini("Скорость", "${"%.1f".format(speed)}/с", Color.White)
                        if (scanning && eta > 0) StatMini("ETA", "%d:%02d".format(eta / 60, eta % 60), Yellow400)
                    }
                }
            }
        }
    }
}

@Composable
fun StatMini(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = (-0.3).sp)
        Text(label, fontSize = 9.sp, color = Gray500, letterSpacing = 0.3.sp)
    }
}

@Composable
fun StatsStrip(results: List<ScanResult>) {
    val withPhoto = results.count { it.snapshot != null && it.snapshot.size > 100 }
    val withoutPhoto = results.count { !it.blocked && (it.snapshot == null || it.snapshot.size <= 100) }
    val blocked = results.count { it.blocked }
    val total = results.count { !it.blocked }
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderDark)
    ) {
        Column {
            // Тонкая цветная полоска сверху
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                    .background(Brush.horizontalGradient(listOf(Wine, WineAccent, WineLight)))
            )
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatCell(total.toString(), "Всего", WineAccent, Modifier.weight(1f))
                Box(modifier = Modifier.width(1.dp).height(32.dp).background(BorderDark))
                StatCell(withPhoto.toString(), "С фото", Wine, Modifier.weight(1f))
                Box(modifier = Modifier.width(1.dp).height(32.dp).background(BorderDark))
                StatCell(withoutPhoto.toString(), "Без фото", WineLight, Modifier.weight(1f))
                if (blocked > 0) {
                    Box(modifier = Modifier.width(1.dp).height(32.dp).background(BorderDark))
                    StatCell(blocked.toString(), "Блок", Orange400, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun StatCell(value: String, label: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = (-0.5).sp)
        Text(label, fontSize = 9.sp, color = Gray500, letterSpacing = 0.3.sp)
    }
}

@Composable
fun StatChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.1f))
            .border(1.dp, color.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun ResultCard(result: ScanResult, context: Context, onClick: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val timeFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }

    // RTSP preview state
    val isCamera = !isTerminal(result.brand)
    var previewSnap by remember { mutableStateOf<ByteArray?>(null) }
    var previewLoading by remember { mutableStateOf(false) }
    var previewFailed by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val showPhoto = hasPhoto || (previewSnap != null && previewSnap!!.size > 100)
    val photoData = previewSnap ?: result.snapshot

    // Press feedback animation
    var pressed by remember { mutableStateOf(false) }
    val cardScale by animateFloatAsState(
        targetValue = if (pressed) 0.974f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )
    val accent = brandColor(result.brand)
    val borderAlpha by animateFloatAsState(
        targetValue = if (pressed) 0.55f else 0.18f,
        animationSpec = tween(120),
        label = "borderAlpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = cardScale; scaleY = cardScale }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onClick() }
                )
            },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = borderAlpha))
    ) {
        Column {
            // Цветная полоска бренда сверху
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(Brush.horizontalGradient(listOf(accent.copy(alpha = 0.7f), accent, accent.copy(alpha = 0.4f))))
            )
            // Показываем превью если получили
            if (showPhoto && photoData != null && photoData.size > 100) {
                val bmp = remember(photoData) { BitmapFactory.decodeByteArray(photoData, 0, photoData.size) }
                if (bmp != null) {
                    Box {
                        Image(bitmap = bmp.asImageBitmap(), contentDescription = null,
                            modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                            contentScale = ContentScale.Crop)
                        // Gradient overlay at bottom of photo
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .align(Alignment.BottomCenter)
                                .background(Brush.verticalGradient(listOf(Color.Transparent, SurfaceDark.copy(alpha = 0.85f))))
                        )
                    }
                }
            }
            Row(modifier = Modifier.padding(12.dp, if (showPhoto) 8.dp else 12.dp, 12.dp, 12.dp)) {
                if (!showPhoto) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.radialGradient(listOf(SurfaceEl, SurfaceDark2)))
                            .border(1.dp, accent.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (previewLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = Wine)
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(brandIcon(result.brand), fontSize = 26.sp)
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    // IP адрес — крупнее и заметнее
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(result.ip, fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace, fontSize = 16.sp, color = Color.White, modifier = Modifier.weight(1f, fill = false))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            ":${result.port}",
                            fontSize = 12.sp,
                            color = Gray500,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.weight(1f))
                        // Кнопка копирования
                        Box(modifier = Modifier.size(26.dp).clip(CircleShape)
                            .background(SurfaceDark2)
                            .border(1.dp, BorderDark, CircleShape)
                            .clickable {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${credentialLabel(result.login, result.password)}"))
                                Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                            }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(13.dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    // Badges row
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        // Credentials badge — улучшенный стиль
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Brush.horizontalGradient(listOf(WineDark.copy(alpha = 0.5f), Wine.copy(alpha = 0.2f))))
                                .border(1.dp, Wine.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(credentialLabel(result.login, result.password), fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
                        }
                        // Brand badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(brandColor(result.brand).copy(alpha = 0.15f))
                                .border(1.dp, brandColor(result.brand).copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand), fontWeight = FontWeight.SemiBold)
                        }
                        if (result.hasMic) {
                            Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Red400.copy(alpha = 0.15f)).border(1.dp, Red400.copy(alpha = 0.25f), RoundedCornerShape(6.dp)).padding(horizontal = 5.dp, vertical = 3.dp)) {
                                Text("🎤", fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(5.dp))
                    // Модель и время
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        if (result.model.isNotEmpty() && result.model != "unknown" && !result.model.startsWith("rtsp://")) {
                            Text(result.model, fontSize = 11.sp, color = Gray500.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                            Spacer(Modifier.width(4.dp))
                        }
                        if (result.channels > 0) {
                            Text("${result.channels}ch", fontSize = 11.sp, color = Gray500)
                            Spacer(Modifier.width(4.dp))
                        }
                        Spacer(Modifier.weight(1f))
                        Text(timeFmt, fontSize = 10.sp, color = Gray500.copy(alpha = 0.6f))
                    }
                    // ── Кнопка RTSP: открыть стрим в плеере ──
                    if (result.model.startsWith("rtsp://")) {
                        Spacer(Modifier.height(4.dp))
                        val displayUrl = if (result.login.isNotEmpty()) {
                            "rtsp://${result.login}:${result.password}@${result.ip}:${result.port}${result.model.substringAfter(":${result.port}")}"
                        } else result.model
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                "▶ Открыть стрим",
                                fontSize = 11.sp,
                                color = Color(0xFF4FC3F7),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF1565C0).copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                    .clickable {
                                        openRtspInPlayer(context, displayUrl)
                                    }
                            )
                            Text(
                                "📋",
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                    .clickable {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        cm.setPrimaryClip(ClipData.newPlainText("rtsp", displayUrl))
                                        Toast.makeText(context, "URL скопирован", Toast.LENGTH_SHORT).show()
                                    }
                            )
                        }
                    }
                    // Кнопка RTSP превью для камер без фото
                    if (!showPhoto && isCamera && !previewLoading) {
                        Spacer(Modifier.height(4.dp))
                        if (previewFailed) {
                            Text("превью недоступно", fontSize = 11.sp, color = Gray500.copy(alpha = 0.5f))
                        } else {
                            Text(
                                "📸 Получить превью",
                                fontSize = 11.sp,
                                color = Wine,
                                modifier = Modifier.clickable {
                                    previewLoading = true
                                    scope.launch {
                                        val snap = SnapshotGrabber.tryGrabSnapshot(result.ip, result.login, result.password, result.port)
                                        previewLoading = false
                                        if (snap != null) previewSnap = snap
                                        else previewFailed = true
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SnapshotFullDialog(result: ScanResult, context: Context, onDismiss: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Card(modifier = Modifier.fillMaxWidth().padding(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(brandColor(result.brand)))
                    Spacer(Modifier.width(8.dp))
                    Text(result.ip, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 11.sp, color = brandColor(result.brand))
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
                    Spacer(Modifier.height(12.dp))
                }
                InfoRow("Порт", "${result.port}")
                InfoRow("Логин", result.login.ifEmpty { "(open)" })
                InfoRow("Пароль", result.password.ifEmpty { "(open)" })
                InfoRow("Бренд", result.brand)
                InfoRow("Тип", when {
                    isServer(result.brand)   -> "${brandIcon(result.brand)} Сервер"
                    isTerminal(result.brand) -> "💻 Терминал"
                    else                     -> "📷 Камера"
                })
                if (result.model.isNotEmpty() && result.model != "unknown") InfoRow("Модель", result.model)
                InfoRow("Каналов", "${result.channels}")
                InfoRow("Микрофон", if (result.hasMic) "🎤 Да" else "Нет")
                if (result.openPortsList.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Top) {
                        Text("Открытые порты", fontSize = 12.sp, color = Color(0xFF888888),
                            modifier = Modifier.width(120.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            result.openPortsList.joinToString("  "),
                            fontSize = 11.sp,
                            color = Color(0xFF4FC3F7),
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                }
                if (result.metadata.isNotEmpty()) {
                    Spacer(Modifier.height(4.dp))
                    Text("📋 Метаданные", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = WineLight)
                    for ((key, value) in result.metadata) {
                        InfoRow(key.replaceFirstChar { it.uppercase() }, value)
                    }
                }
                // ── RTSP кнопки (открыть + скопировать URL) ──
                val rtspUrl = result.model.takeIf { it.startsWith("rtsp://") }
                if (rtspUrl != null) {
                    Spacer(Modifier.height(8.dp))
                    // Показываем URL (с кредами если есть)
                    val displayUrl = if (result.login.isNotEmpty()) {
                        "rtsp://${result.login}:${result.password}@${result.ip}:${result.port}${rtspUrl.substringAfter(":${result.port}")}"
                    } else rtspUrl
                    Text(
                        displayUrl,
                        fontSize = 10.sp,
                        color = Color(0xFF4FC3F7),
                        fontFamily = FontFamily.Monospace,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF0D1F2D))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .clickable {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("rtsp", displayUrl))
                                Toast.makeText(context, "RTSP URL скопирован", Toast.LENGTH_SHORT).show()
                            }
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Кнопка открыть в плеере
                        Button(
                            onClick = { openRtspInPlayer(context, displayUrl) },
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF1565C0))
                        ) {
                            Text("▶ Открыть", fontSize = 13.sp)
                        }
                        // Кнопка скопировать URL
                        Button(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("rtsp", displayUrl))
                                Toast.makeText(context, "URL скопирован", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) {
                            Text("📋 Копировать URL", fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val info = buildString {
                            appendLine("IP: ${result.ip}:${result.port}")
                            appendLine("Login: ${result.login}")
                            appendLine("Password: ${result.password}")
                            appendLine("Brand: ${result.brand}")
                            if (result.model.isNotEmpty()) appendLine("Model: ${result.model}")
                            appendLine("Channels: ${result.channels}")
                            if (result.metadata.isNotEmpty()) {
                                for ((k, v) in result.metadata) appendLine("$k: $v")
                            }
                        }
                        cm.setPrimaryClip(ClipData.newPlainText("cam", info))
                        Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                    }) { Text("Копировать", color = WineLight) }
                    TextButton(onClick = onDismiss) { Text("Закрыть", color = Gray500) }
                }
            }
        }
    }
}

@Composable
fun StoredTab(
    results: List<ScanResult>,
    onResultClick: (ScanResult) -> Unit,
    onDelete: (ScanResult) -> Unit,
    onClearAll: () -> Unit,
    context: Context
) {
    // ═══ ФИКС Bug 2: remember вверху, до любого conditional return ═══
    var filterBrand by remember { mutableStateOf<String?>(null) }
    var filterPort by remember { mutableStateOf<Int?>(null) }

    val filteredResults = remember(results, filterBrand, filterPort) {
        results.filter { r ->
            (filterBrand == null || r.brand == filterBrand) &&
            (filterPort == null || r.port == filterPort)
        }
    }
    val cameras = remember(filteredResults) { filteredResults.filter { !isTerminal(it.brand) } }
    val terminals = remember(filteredResults) { filteredResults.filter { isTerminal(it.brand) } }

    val allBrands = remember(results) { results.map { it.brand }.distinct().sorted() }
    val allPorts = remember(results) { results.map { it.port }.distinct().sorted() }

    if (results.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("💾", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("Нет сохранённых результатов", fontSize = 16.sp, color = Gray500)
                Text("Найденные устройства сохраняются автоматически", fontSize = 13.sp, color = Gray500.copy(alpha = 0.6f))
            }
        }
        return
    }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("💾 Сохранено: ${results.size}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = WineLight)
                    if (filterBrand != null || filterPort != null) {
                        Text("Показано: ${filteredResults.size}", fontSize = 12.sp, color = WineLight)
                    } else {
                        Text("Данные хранятся локально на устройстве", fontSize = 12.sp, color = Gray500)
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("📷 ${cameras.size} камер", Wine, Modifier.weight(1f))
                        StatChip("💻 ${terminals.size} терм.", Color(0xFFFFA726), Modifier.weight(1f))
                    }

                    // ─── Фильтр по бренду ───
                    if (allBrands.size > 1) {
                        Spacer(Modifier.height(8.dp))
                        Text("Фильтр по бренду:", fontSize = 11.sp, color = Gray500)
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = filterBrand == null,
                                onClick = { filterBrand = null },
                                label = { Text("Все", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Wine.copy(alpha = 0.2f),
                                    selectedLabelColor = Wine
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = filterBrand == null,
                                    borderColor = BorderDark, selectedBorderColor = Wine.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            allBrands.forEach { brand ->
                                val count = results.count { it.brand == brand }
                                FilterChip(
                                    selected = filterBrand == brand,
                                    onClick = { filterBrand = if (filterBrand == brand) null else brand },
                                    label = { Text("$brand ($count)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = brandColor(brand).copy(alpha = 0.2f),
                                        selectedLabelColor = brandColor(brand)
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = filterBrand == brand,
                                        borderColor = BorderDark, selectedBorderColor = brandColor(brand).copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    // ─── Фильтр по порту ───
                    if (allPorts.size > 1) {
                        Spacer(Modifier.height(6.dp))
                        Text("Фильтр по порту:", fontSize = 11.sp, color = Gray500)
                        Spacer(Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            FilterChip(
                                selected = filterPort == null,
                                onClick = { filterPort = null },
                                label = { Text("Все", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = WineLight.copy(alpha = 0.2f),
                                    selectedLabelColor = WineLight
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = filterPort == null,
                                    borderColor = BorderDark, selectedBorderColor = WineLight.copy(alpha = 0.5f)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            allPorts.forEach { port ->
                                val count = results.count { it.port == port }
                                FilterChip(
                                    selected = filterPort == port,
                                    onClick = { filterPort = if (filterPort == port) null else port },
                                    label = { Text("$port ($count)", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = WineLight.copy(alpha = 0.2f),
                                        selectedLabelColor = WineLight
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true, selected = filterPort == port,
                                        borderColor = BorderDark, selectedBorderColor = WineLight.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(20.dp)
                                )
                            }
                        }
                    }

                    // ─── Сброс фильтров ───
                    if (filterBrand != null || filterPort != null) {
                        Spacer(Modifier.height(6.dp))
                        TextButton(
                            onClick = { filterBrand = null; filterPort = null },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✕ Сбросить фильтры", fontSize = 12.sp, color = Red400)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val exportList = if (filterBrand != null || filterPort != null) filteredResults else results
                                val text = exportList.joinToString("\n") { r -> "${r.ip}:${r.port} ${credentialLabel(r.login, r.password)} [${r.brand}] ${r.model}" }
                                cm.setPrimaryClip(ClipData.newPlainText("stored_all", text))
                                Toast.makeText(context, "Скопировано (${exportList.size})", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WineLight), border = BorderStroke(1.dp, WineLight.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (filterBrand != null || filterPort != null) "Копировать (${filteredResults.size})" else "Копировать", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = onClearAll,
                            modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Red400), border = BorderStroke(1.dp, Red400.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Очистить всё", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (cameras.isNotEmpty()) {
            item { Text("📷 КАМЕРЫ (${cameras.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Wine, letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            itemsIndexed(cameras, key = { _, r -> "stored_cam_${r.ip}:${r.port}:${r.timestampMs}" }) { idx, result ->
                AnimatedResultItem(idx) {
                    StoredResultCard(result, context, onClick = { onResultClick(result) }, onDelete = { onDelete(result) })
                }
            }
        }

        if (terminals.isNotEmpty()) {
            item { Text("💻 ТЕРМИНАЛЫ (${terminals.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFFA726), letterSpacing = 1.5.sp, modifier = Modifier.padding(top = 4.dp)) }
            itemsIndexed(terminals, key = { _, r -> "stored_term_${r.ip}:${r.port}:${r.timestampMs}" }) { idx, result ->
                AnimatedResultItem(idx) {
                    StoredResultCard(result, context, onClick = { onResultClick(result) }, onDelete = { onDelete(result) })
                }
            }
        }
    }
}

@Composable
fun StoredResultCard(result: ScanResult, context: Context, onClick: () -> Unit, onDelete: () -> Unit) {
    val hasPhoto = result.snapshot != null && result.snapshot.size > 100
    val dateFmt = remember(result.timestampMs) {
        java.text.SimpleDateFormat("dd.MM HH:mm", java.util.Locale.getDefault()).format(java.util.Date(result.timestampMs))
    }
    // Press animation
    var pressed by remember { mutableStateOf(false) }
    val cardScale by animateFloatAsState(
        targetValue = if (pressed) 0.974f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "storedCardScale"
    )
    val accent = brandColor(result.brand)
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = cardScale; scaleY = cardScale }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { onClick() }
                )
            },
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = if (pressed) 0.45f else 0.15f))
    ) {
        Row(modifier = Modifier.padding(12.dp)) {
            Box(modifier = Modifier.size(72.dp).clip(RoundedCornerShape(10.dp)).background(if (hasPhoto) Color.Transparent else SurfaceDark2), contentAlignment = Alignment.Center) {
                if (hasPhoto) {
                    val bmp = remember(result.snapshot) { BitmapFactory.decodeByteArray(result.snapshot, 0, result.snapshot.size) }
                    if (bmp != null) Image(bitmap = bmp.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                } else {
                    Text(brandIcon(result.brand), fontSize = 28.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(result.ip, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 15.sp, color = Color.White)
                    Row {
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(SurfaceDark2).clickable {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("cam", "${result.ip}:${result.port} ${credentialLabel(result.login, result.password)}"))
                            Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                        }, contentAlignment = Alignment.Center) { Icon(Icons.Default.Share, null, tint = Gray500, modifier = Modifier.size(14.dp)) }
                        Spacer(Modifier.width(4.dp))
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(Red400.copy(alpha = 0.15f)).clickable { onDelete() }, contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Delete, null, tint = Red400, modifier = Modifier.size(14.dp))
                        }
                    }
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Wine.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text("${result.login}:${result.password}", fontSize = 12.sp, color = WineAccent, fontFamily = FontFamily.Monospace)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(brandColor(result.brand).copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                        Text(result.brand, fontSize = 10.sp, color = brandColor(result.brand))
                    }
                    if (result.hasMic) {
                        Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Red400.copy(alpha = 0.15f)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                            Text("🎤", fontSize = 10.sp)
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    if (result.model.isNotEmpty() && result.model != "unknown") Text(result.model, fontSize = 11.sp, color = WineLight, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Text(":${result.port}", fontSize = 11.sp, color = Gray500, fontFamily = FontFamily.Monospace)
                    Spacer(Modifier.width(4.dp))
                    Text(dateFmt, fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = Gray500)
        Text(value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

// ─── Staggered animated entry for list items ───────────────────────────────
@Composable
fun AnimatedResultItem(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay((index * 35L).coerceAtMost(400L))
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(220)) + slideInVertically(
            animationSpec = tween(260, easing = FastOutSlowInEasing),
            initialOffsetY = { it / 6 }
        )
    ) {
        content()
    }
}

// ─── Animated Segmented TabBar ─────────────────────────────────────────────
@Composable
fun AnimatedSegmentedTabBar(
    tabs: List<String>,
    badges: List<Int>,
    badgeColors: List<Color>,
    selectedIndex: Int,
    onTabSelected: (Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(Color(0xFF120508), BgDark)))
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                tabs.forEachIndexed { idx, label ->
                    val selected = selectedIndex == idx
                    val accent = badgeColors.getOrElse(idx) { Wine }
                    val bgColor by animateColorAsState(
                        targetValue = if (selected) accent.copy(alpha = 0.2f) else Color.Transparent,
                        animationSpec = tween(220),
                        label = "tabBg$idx"
                    )
                    val labelColor by animateColorAsState(
                        targetValue = if (selected) accent else Gray500,
                        animationSpec = tween(220),
                        label = "tabLabel$idx"
                    )
                    val scale by animateFloatAsState(
                        targetValue = if (selected) 1.02f else 0.97f,
                        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                        label = "tabScale$idx"
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .graphicsLayer { scaleX = scale; scaleY = scale }
                            .clip(RoundedCornerShape(10.dp))
                            .background(bgColor)
                            .then(
                                if (selected) Modifier.border(1.dp, accent.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                                else Modifier
                            )
                            .clickable { onTabSelected(idx) }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val badge = badges.getOrElse(idx) { 0 }
                        // Текст таба + бейдж рядом в одну строку
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                label,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                color = labelColor
                            )
                            if (badge > 0) {
                                Spacer(Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(accent.copy(alpha = if (selected) 0.9f else 0.45f))
                                        .size(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        if (badge > 99) "99+" else "$badge",
                                        color = Color.White,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
            // Separator line
            HorizontalDivider(color = BorderDark.copy(alpha = 0.5f), thickness = 1.dp)
            // Animated glow indicator under selected tab
            val tabWidth = 1f / tabs.size
            val pillOffset by animateFloatAsState(
                targetValue = selectedIndex.toFloat() / tabs.size,
                animationSpec = spring(stiffness = Spring.StiffnessMedium),
                label = "tabPill"
            )
            val accentRaw = badgeColors.getOrElse(selectedIndex) { Wine }
            val accentAnimated by animateColorAsState(
                targetValue = accentRaw,
                animationSpec = tween(220),
                label = "tabIndicatorColor"
            )
            Canvas(modifier = Modifier.fillMaxWidth().height(3.dp)) {
                val barWidth = size.width * tabWidth
                val startX = size.width * pillOffset + 24f
                val barW = barWidth - 48f
                // Glow effect — wider softer rect behind
                drawRect(
                    color = accentAnimated.copy(alpha = 0.25f),
                    topLeft = androidx.compose.ui.geometry.Offset(startX - 6f, 0f),
                    size = androidx.compose.ui.geometry.Size(barW + 12f, size.height)
                )
                // Main indicator
                drawRect(
                    color = accentAnimated,
                    topLeft = androidx.compose.ui.geometry.Offset(startX, 0f),
                    size = androidx.compose.ui.geometry.Size(barW, size.height)
                )
            }
        }
    }
}

// ─── Вкладка "Страны" — генератор IP диапазонов ───

@Composable
fun CountryTab(
    onIpsGenerated: (List<String>) -> Unit,
    onGoToScanner: () -> Unit
) {
    val countries = IpRangeGenerator.COUNTRIES
    var selectedCountryCode by remember { mutableStateOf<String?>(null) }
    var selectedCidrs = remember { mutableStateListOf<String>() }
    var generatedCount by remember { mutableIntStateOf(0) }
    var maxIps by remember { mutableIntStateOf(20000) }
    var showCidrPicker by remember { mutableStateOf(false) }
    var customCidrInput by remember { mutableStateOf("") }
    var customCidrError by remember { mutableStateOf<String?>(null) }
    // Hoisted out of lazy item — state inside a lazy item can be lost on scroll
    var freeInput by remember { mutableStateOf("") }
    var freeError by remember { mutableStateOf<String?>(null) }

    val selectedCountry = countries.find { it.code == selectedCountryCode }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 80.dp)
    ) {

        // ─── Заголовок секции ─────────────────
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(3.dp).height(14.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Wine)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "ВЫБОР СТРАНЫ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Wine,
                    letterSpacing = 1.5.sp
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Реальные BGP/ISP блоки из RIPE · APNIC · ARIN",
                fontSize = 11.sp,
                color = Gray500
            )
        }

        // ─── Сетка стран ──────────────────────
        // Разбиваем по 2 в ряд
        val rows = countries.chunked(2)
        items(rows) { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (country in row) {
                    val isSelected = selectedCountryCode == country.code
                    val totalIps = IpRangeGenerator.estimateCount(country.code)
                    val totalM = if (totalIps > 1_000_000) "%.1fM".format(totalIps / 1_000_000.0)
                               else if (totalIps > 1000) "${totalIps / 1000}K"
                               else "$totalIps"

                    Card(
                        onClick = {
                            if (isSelected) {
                                selectedCountryCode = null
                                selectedCidrs.clear()
                                showCidrPicker = false
                            } else {
                                selectedCountryCode = country.code
                                selectedCidrs.clear()
                                showCidrPicker = false
                            }
                        },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Wine.copy(alpha = 0.12f) else SurfaceDark
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            if (isSelected) 1.dp else 0.5.dp,
                            if (isSelected) Wine else BorderDark
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(country.flag, fontSize = 20.sp)
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(Wine),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Check,
                                            null,
                                            tint = Color.White,
                                            modifier = Modifier.size(10.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                country.nameRu,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.85f)
                            )
                            Text(
                                country.code,
                                fontSize = 10.sp,
                                color = if (isSelected) WineAccent else Gray500,
                                fontFamily = FontFamily.Monospace
                            )
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "~$totalM IP",
                                    fontSize = 10.sp,
                                    color = Gray500,
                                    fontFamily = FontFamily.Monospace
                                )
                                if (country.estimatedCameras > 0) {
                                    Text(
                                        "📷 ${if (country.estimatedCameras > 1000) "${country.estimatedCameras/1000}K" else "${country.estimatedCameras}"}",
                                        fontSize = 10.sp,
                                        color = WineLight
                                    )
                                }
                            }
                        }
                    }
                }
                // Если нечётное кол-во — пустая заглушка
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        // ─── Настройки генерации (показываем если страна выбрана) ────
        if (selectedCountry != null) {

            item {
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(3.dp).height(14.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(WineLight)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${selectedCountry.flag} ${selectedCountry.nameRu.uppercase()} — НАСТРОЙКИ",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = WineLight,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Лимит IP
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark2),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Максимум IP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (limit in listOf(5_000, 20_000, 50_000, 100_000)) {
                                val selected = maxIps == limit
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (selected) Wine else SurfaceDark
                                        )
                                        .clickable { maxIps = limit }
                                        .padding(vertical = 7.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        if (limit >= 1000) "${limit / 1000}K" else "$limit",
                                        fontSize = 12.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selected) Color.White else Gray500
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Выбор CIDR блоков
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark2),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                "CIDR блоки",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                if (selectedCidrs.isEmpty()) "Все (${selectedCountry.cidrBlocks.size})"
                                else "Выбрано: ${selectedCidrs.size}",
                                fontSize = 11.sp,
                                color = if (selectedCidrs.isEmpty()) Gray500 else WineAccent
                            )
                            Spacer(Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Wine.copy(alpha = 0.12f))
                                    .clickable { showCidrPicker = !showCidrPicker }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    if (showCidrPicker) "Свернуть" else "Выбрать",
                                    fontSize = 11.sp,
                                    color = WineAccent
                                )
                            }
                        }

                        AnimatedVisibility(
                            visible = showCidrPicker,
                            enter = fadeIn(tween(200)) + expandVertically(spring(stiffness = Spring.StiffnessMediumLow)),
                            exit = fadeOut(tween(150)) + shrinkVertically(spring(stiffness = Spring.StiffnessMediumLow))
                        ) {
                            Column {
                                Spacer(Modifier.height(8.dp))
                                // Кнопка "все / снять всё"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Text(
                                        "Все",
                                        fontSize = 11.sp,
                                        color = WineAccent,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                selectedCidrs.clear()
                                                selectedCidrs.addAll(selectedCountry.cidrBlocks)
                                            }
                                            .padding(4.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        "Снять",
                                        fontSize = 11.sp,
                                        color = Gray500,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable { selectedCidrs.clear() }
                                            .padding(4.dp)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                // Чекбоксы для каждого CIDR
                                for (cidr in selectedCountry.cidrBlocks) {
                                    val checked = selectedCidrs.contains(cidr)
                                    val prefix = cidr.substringAfter("/").toIntOrNull() ?: 32
                                    val hostCount = if (prefix < 32) (1L shl (32 - prefix)) - 2 else 0L
                                    val countStr = if (hostCount > 1000) "${hostCount/1000}K" else "$hostCount"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable {
                                                if (checked) selectedCidrs.remove(cidr)
                                                else selectedCidrs.add(cidr)
                                            }
                                            .padding(vertical = 4.dp, horizontal = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(if (checked) Wine else SurfaceDark)
                                                .border(1.dp, if (checked) Wine else BorderDark, RoundedCornerShape(4.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (checked) Icon(
                                                Icons.Default.Check,
                                                null,
                                                tint = Color.White,
                                                modifier = Modifier.size(10.dp)
                                            )
                                        }
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            cidr,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (checked) Color.White else Color.White.copy(alpha = 0.6f),
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            countStr,
                                            fontSize = 10.sp,
                                            color = Gray500,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Кастомный CIDR ввод
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark2),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Свой CIDR / диапазон",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(6.dp))
                        BasicTextField(
                            value = customCidrInput,
                            onValueChange = { v -> customCidrInput = v; customCidrError = null },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color.White,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            cursorBrush = SolidColor(WineAccent),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceDark)
                                .padding(10.dp),
                            decorationBox = { innerTextField ->
                                Box {
                                    if (customCidrInput.isEmpty()) {
                                        Text(
                                            "192.168.1.0/24 или 1.2.3.4-1.2.3.100",
                                            color = Gray500,
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                    innerTextField()
                                }
                            }
                        )
                        if (customCidrError != null) {
                            Spacer(Modifier.height(4.dp))
                            Text(customCidrError!!, fontSize = 11.sp, color = Orange400)
                        }
                    }
                }
            }

            // ─── Кнопка "Сгенерировать и сканировать" ────────────────
            item {
                val cidrList = if (selectedCidrs.isNotEmpty()) selectedCidrs.toList()
                               else selectedCountry.cidrBlocks

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Превью — сколько IP будет
                    val totalEstimate = cidrList.sumOf { cidr ->
                        val p = cidr.substringAfter("/").toIntOrNull() ?: 32
                        if (p < 32) minOf((1L shl (32 - p)) - 2L, 4096L) else 0L
                    }
                    val finalCount = minOf(totalEstimate, maxIps.toLong())
                    Text(
                        "≈ $finalCount IP будет передано в сканер",
                        fontSize = 11.sp,
                        color = Gray500,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Основная кнопка
                    Button(
                        onClick = {
                            val customIps = if (customCidrInput.isNotBlank()) {
                                IpRangeGenerator.parseUserInput(customCidrInput)
                            } else emptyList()

                            val countryIps = IpRangeGenerator.generateForCountry(
                                countryCode = selectedCountry.code,
                                maxTotal = maxIps,
                                shuffle = true,
                                cidrFilter = if (selectedCidrs.isNotEmpty()) selectedCidrs.toList() else null
                            )

                            val allIps = (customIps + countryIps).distinct().take(maxIps)
                            if (allIps.isEmpty()) {
                                customCidrError = "Не удалось сгенерировать IP"
                                return@Button
                            }
                            generatedCount = allIps.size
                            onIpsGenerated(allIps)
                            onGoToScanner()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Wine),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(
                            Icons.Default.PlayArrow,
                            null,
                            modifier = Modifier.size(18.dp),
                            tint = Color.White
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "${selectedCountry.flag} Сканировать ${selectedCountry.nameRu}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // ─── Кастомный ввод (без страны) ─────────────────────────────
        item {
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.width(3.dp).height(14.dp)
                    .clip(RoundedCornerShape(2.dp)).background(Gray500))
                Spacer(Modifier.width(8.dp))
                Text(
                    "СВОЙ ДИАПАЗОН",
                    fontSize = 11.sp, fontWeight = FontWeight.Bold,
                    color = Gray500, letterSpacing = 1.sp
                )
            }
            Spacer(Modifier.height(6.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "CIDR, диапазон или список IP",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White
                    )
                    Spacer(Modifier.height(6.dp))
                    BasicTextField(
                        value = freeInput,
                        onValueChange = { v -> freeInput = v; freeError = null },
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color.White, fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(WineAccent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceDark2)
                            .padding(10.dp)
                            .heightIn(min = 60.dp),
                        maxLines = 8,
                        decorationBox = { innerTextField ->
                            Box {
                                if (freeInput.isEmpty()) {
                                    Text(
                                        "10.0.0.0/16\n192.168.0.1-192.168.0.254\n1.2.3.4",
                                        color = Gray500.copy(alpha = 0.5f),
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 16.sp
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                    if (freeError != null) {
                        Spacer(Modifier.height(4.dp))
                        Text(freeError!!, fontSize = 11.sp, color = Orange400)
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (freeInput.isBlank()) { freeError = "Введи IP или CIDR"; return@Button }
                            val ips = IpRangeGenerator.parseUserInput(freeInput)
                            if (ips.isEmpty()) { freeError = "Некорректный формат"; return@Button }
                            onIpsGenerated(ips.take(100_000))
                            onGoToScanner()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark2),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, BorderDark),
                        modifier = Modifier.fillMaxWidth().height(42.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp), tint = WineAccent)
                        Spacer(Modifier.width(6.dp))
                        Text("Использовать этот диапазон", fontSize = 13.sp, color = WineAccent)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// RTSP Player Helper — пробует плееры по приоритету, fallback копирует URL
// ─────────────────────────────────────────────────────────────────────────────
fun openRtspInPlayer(context: Context, rtspUrl: String) {
    // Приоритет: VLC → MX Player → любой плеер через ACTION_VIEW
    // VLC package names на разных ROM
    val vlcPackages = listOf(
        "org.videolan.vlc",          // VLC official
        "org.videolan.vlc.debug"     // VLC debug build
    )
    val mxPackages = listOf(
        "com.mxtech.videoplayer.ad", // MX Player free
        "com.mxtech.videoplayer.pro" // MX Player pro
    )

    val uri = android.net.Uri.parse(rtspUrl)

    // Пробуем каждый плеер напрямую
    for (pkg in vlcPackages + mxPackages) {
        try {
            val pm = context.packageManager
            pm.getPackageInfo(pkg, 0) // бросит если не установлен
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(pkg)
                setDataAndType(uri, "video/rtsp")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        } catch (_: Exception) {}
    }

    // Fallback: стандартный chooser — может найти другой плеер
    try {
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setDataAndType(uri, "video/rtsp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chooser = Intent.createChooser(intent, "Открыть RTSP").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (_: Exception) {
        // Абсолютный fallback — копируем URL в буфер
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("rtsp_url", rtspUrl))
        Toast.makeText(context,
            "Плеер не найден. URL скопирован — откройте VLC → Stream",
            Toast.LENGTH_LONG).show()
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// ZIP Экспорт результатов со скриншотами → Downloads/
// Структура:
//   findings_export_<timestamp>/
//     index.txt           — все результаты текстом
//     cameras/
//       <ip>_<port>.jpg   — скриншот камеры
// ─────────────────────────────────────────────────────────────────────────────
suspend fun exportResultsZip(context: Context, results: List<ScanResult>): Boolean = withContext(Dispatchers.IO) {
    // MediaStore.Downloads требует API 29+
    if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) {
        android.util.Log.w("ZipExport", "MediaStore.Downloads not available below API 29")
        return@withContext false
    }
    try {
        val ts = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
        val zipName = "findings_$ts.zip"

        // Собираем ZIP в памяти
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            // ── index.txt ──
            val indexSb = StringBuilder()
            indexSb.appendLine("MainScanner Export — $ts")
            indexSb.appendLine("Total: ${results.size}")
            indexSb.appendLine("With screenshots: ${results.count { it.snapshot != null && it.snapshot.size > 100 }}")
            indexSb.appendLine("=" .repeat(60))
            indexSb.appendLine()
            for (r in results) {
                indexSb.appendLine("[${r.brand}] ${r.ip}:${r.port}")
                indexSb.appendLine("  Login:    ${r.login.ifEmpty { "(open)" }}")
                indexSb.appendLine("  Password: ${r.password.ifEmpty { "(open)" }}")
                if (r.model.isNotEmpty() && r.model != "unknown") indexSb.appendLine("  Model:    ${r.model}")
                if (r.channels > 0) indexSb.appendLine("  Channels: ${r.channels}")
                if (r.hasMic) indexSb.appendLine("  Mic:      YES")
                if (r.openPortsList.isNotEmpty()) indexSb.appendLine("  Ports:    ${r.openPortsList.joinToString(", ")}")
                if (r.snapshot != null && r.snapshot.size > 100) indexSb.appendLine("  Snapshot: cameras/${r.ip.replace(".", "_")}_${r.port}.jpg")
                indexSb.appendLine()
            }
            zos.putNextEntry(ZipEntry("index.txt"))
            zos.write(indexSb.toString().toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            // ── open_8xxx.txt — все IP:port где открыты порты 8ХХХ (CamXploit расширенный список) ──
            val eightPorts = setOf(8000, 8001, 8008, 8080, 8081, 8082, 8083, 8084, 8085, 8086, 8087, 8088, 8089, 8090, 8181, 8888, 8899)
            val eightSb = StringBuilder()
            for (r in results) {
                // Сам порт результата
                if (r.port in eightPorts) {
                    eightSb.appendLine("${r.ip}:${r.port}")
                }
                // Дополнительные открытые порты на том же IP
                for (p in r.openPortsList) {
                    if (p in eightPorts && p != r.port) {
                        eightSb.appendLine("${r.ip}:$p")
                    }
                }
            }
            if (eightSb.isNotEmpty()) {
                // Дедупликация — убираем дубли
                val dedupLines = eightSb.toString().lines().filter { it.isNotBlank() }.distinct()
                zos.putNextEntry(ZipEntry("open_8xxx.txt"))
                zos.write(dedupLines.joinToString("\n").toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }

            // ── скриншоты ──
            for (r in results) {
                val snap = r.snapshot ?: continue
                if (snap.size <= 100) continue
                val safeName = "cameras/${r.ip.replace(".", "_")}_${r.port}.jpg"
                zos.putNextEntry(ZipEntry(safeName))
                zos.write(snap)
                zos.closeEntry()
            }
        }

        val zipBytes = baos.toByteArray()

        // Сохраняем через MediaStore → Downloads (API 29+, без permissions)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, zipName)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val itemUri = resolver.insert(collection, values) ?: return@withContext false

        resolver.openOutputStream(itemUri)?.use { it.write(zipBytes) }

        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(itemUri, values, null, null)

        true
    } catch (e: Exception) {
        android.util.Log.e("ZipExport", "Failed: ${e.message}", e)
        false
    }
}

// ── Отдельный ZIP только с 8xxx IP:port (без скриншотов) ──
suspend fun export8xxxZip(context: Context, ipPortList: List<String>): Boolean = withContext(Dispatchers.IO) {
    try {
        val ts = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
        val fileName = "8xxx_ports_$ts.zip"

        val baos = java.io.ByteArrayOutputStream()
        val zos = java.util.zip.ZipOutputStream(baos)

        // open_8xxx.txt — IP:port per line
        val content = ipPortList.joinToString("\n")
        zos.putNextEntry(java.util.zip.ZipEntry("open_8xxx.txt"))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()

        zos.finish()
        zos.close()
        val bytes = baos.toByteArray()

        val resolver = context.contentResolver
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(android.provider.MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(android.provider.MediaStore.Downloads.IS_PENDING, 1)
        }
        val itemUri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return@withContext false

        resolver.openOutputStream(itemUri)?.use { out -> out.write(bytes) }

        values.clear()
        values.put(android.provider.MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(itemUri, values, null, null)

        true
    } catch (e: Exception) {
        android.util.Log.e("8xxxZipExport", "Failed: ${e.message}", e)
        false
    }
}
