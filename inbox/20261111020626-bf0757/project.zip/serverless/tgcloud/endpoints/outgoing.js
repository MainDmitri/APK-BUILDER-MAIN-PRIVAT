import { recordOutgoing, verifyAuth } from '../lib/database.js';

/**
 * POST /api/outgoing
 * Official Mini App endpoint signature: (input, ctx)
 */
export default async function (input, ctx) {
  const hasInitData = !!(ctx?.initData?.user);
  const authOk = hasInitData || verifyAuth(ctx || input || {});

  if (!authOk) {
    return { ok: false, error: 'Unauthorized' };
  }

  const payload = input || ctx?.body || {};
  try {
    await recordOutgoing(payload);
    return { ok: true };
  } catch (e) {
    console.error('outgoing endpoint error:', e.message);
    return { ok: false, error: 'Internal error' };
  }
}
