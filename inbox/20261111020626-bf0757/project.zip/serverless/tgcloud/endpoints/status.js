import { getStats, verifyAuth } from '../lib/database.js';

/**
 * POST /api/status
 * Official Mini App endpoint signature: (input, ctx)
 */
export default async function (input, ctx) {
  // Soft auth: allow if initData present (platform-verified) or fallback token check for tests
  const hasInitData = !!(ctx?.initData?.user);
  const authOk = hasInitData || verifyAuth(ctx || input || {});

  if (!authOk) {
    return { ok: false, error: 'Unauthorized' };
  }

  try {
    const stats = await getStats();
    return {
      ok: true,
      paired: true,
      serverless: true,
      chats: stats.chats,
      messages: stats.messages
    };
  } catch (e) {
    console.error('status endpoint error:', e.message);
    return { ok: false, error: 'Internal error' };
  }
}
