import { getSyncData, verifyAuth } from '../lib/database.js';

/**
 * POST /api/sync
 * Official Mini App endpoint signature: (input, ctx)
 */
export default async function (input, ctx) {
  const hasInitData = !!(ctx?.initData?.user);
  const authOk = hasInitData || verifyAuth(ctx || input || {});

  if (!authOk) {
    return { ok: false, error: 'Unauthorized' };
  }

  const since = Number(input?.since || ctx?.query?.since || 0);
  const limit = Math.min(Number(input?.limit || ctx?.query?.limit || 200), 500);

  try {
    const result = await getSyncData(since, limit);
    return {
      ok: true,
      chats: result.chats || [],
      messages: result.messages || [],
      next: result.nextCursor,
      has_more: result.hasMore
    };
  } catch (e) {
    console.error('sync endpoint error:', e.message);
    return { ok: false, error: 'Internal error' };
  }
}
