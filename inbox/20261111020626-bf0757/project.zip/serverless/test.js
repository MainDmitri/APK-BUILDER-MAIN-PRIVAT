import { saveMessage, getSyncData, getStats, getAutoReplyText, verifyAuth } from './tgcloud/lib/database.js';
import messageHandler from './tgcloud/handlers/message.js';
import statusEndpoint from './tgcloud/endpoints/status.js';
import syncEndpoint from './tgcloud/endpoints/sync.js';

async function runTests() {
  console.log('Testing Telegram Serverless modules...');

  const replyText = await getAutoReplyText();
  console.log('Default auto-reply:', replyText);
  if (!replyText.includes('Ожидайте')) throw new Error('Auto reply text mismatch');

  const fakeEvent = {
    message: {
      message_id: 101,
      date: Math.floor(Date.now() / 1000),
      chat: { id: 777123, first_name: 'Иван', username: 'ivan_tg', type: 'private' },
      from: { id: 777123, first_name: 'Иван', is_bot: false },
      text: 'Здравствуйте! Мне нужна помощь.'
    }
  };

  await messageHandler(fakeEvent);
  console.log('Processed incoming user message successfully.');

  const stats = await getStats();
  console.log('Database stats:', stats);
  if (stats.chats < 1 || stats.messages < 1) throw new Error('Stats empty');

  const mockCtx = {
    headers: { authorization: 'Bearer app12345:secret_token_abc' },
    query: { since: 0, limit: 50 }
  };

  const statusRes = await statusEndpoint(mockCtx);
  console.log('Status endpoint response:', statusRes);
  if (!statusRes.ok) throw new Error('Status failed');

  const syncRes = await syncEndpoint(mockCtx);
  console.log(`Sync endpoint response: chats=${syncRes.chats.length}, messages=${syncRes.messages.length}`);
  if (!syncRes.ok || syncRes.chats.length === 0) throw new Error('Sync failed');

  console.log('✅ ALL SERVERLESS TESTS PASSED!');
}

runTests().catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
