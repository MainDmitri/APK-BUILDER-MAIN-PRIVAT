package com.example.tgbotclient

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Receiving mode: local long-polling (getUpdates) or Telegram Serverless. */
object Mode {
    const val LOCAL = "local"
    const val CLOUD = "cloud"
    fun get(context: Context): String = Prefs.of(context).getString("mode", CLOUD) ?: CLOUD
    fun isCloud(context: Context) = get(context) == CLOUD
}

class BridgeException(message: String, val code: Int) : IOException(message)

data class CloudState(
    val syncing: Boolean = false,
    val lastSync: Long = 0L,
    val error: String? = null,
    val lastNew: Int = 0
)

data class BridgeStatus(val paired: Boolean, val chats: Int, val messages: Int)

/**
 * Pulls history from Telegram Serverless SQLite database or bridge.
 * Cursor-based, idempotent: re-running a sync never duplicates messages.
 */
object CloudSync {
    private val JSON = "application/json".toMediaType()
    private val lock = Mutex()
    private val _state = MutableStateFlow(CloudState())
    val state: StateFlow<CloudState> = _state.asStateFlow()

    private const val PAGE = 200
    private const val MAX_PAGES = 25
    private const val WORK_NAME = "cloud_sync"

    fun bridgeUrl(context: Context): String {
        val prefs = Prefs.of(context)
        val customUrl = prefs.getString(Prefs.KEY_BRIDGE_URL, "").orEmpty().trim().trimEnd('/')
        if (customUrl.isNotEmpty()) return customUrl

        val sToken = prefs.getString(Prefs.KEY_SERVERLESS_TOKEN, "").orEmpty().trim()
        val (parsedUrl, _) = parseServerlessCliToken(sToken)
        return parsedUrl.ifBlank { "" }
    }

    fun appKey(context: Context): String {
        val prefs = Prefs.of(context)
        val customKey = prefs.getString(Prefs.KEY_BRIDGE_KEY, "").orEmpty().trim()
        if (customKey.isNotEmpty()) return customKey

        return prefs.getString(Prefs.KEY_SERVERLESS_TOKEN, "").orEmpty().trim()
    }

    fun isConfigured(context: Context): Boolean {
        val url = bridgeUrl(context)
        val key = appKey(context)
        return (url.startsWith("https://") || url.startsWith("http://")) && key.isNotEmpty()
    }

    private fun request(context: Context, path: String, body: JSONObject? = null): JSONObject {
        val url = bridgeUrl(context)
        if (!url.startsWith("https://") && !url.startsWith("http://")) {
            throw BridgeException("Укажите Serverless CLI токен в настройках", 0)
        }
        val key = appKey(context)

        // Try /api/ and /v1/ routes for maximum compatibility with Telegram Serverless and bridges
        val candidatePaths = when {
            path.startsWith("/api/") -> listOf(path, path.replaceFirst("/api/", "/v1/"))
            path.startsWith("/v1/") -> listOf(path, path.replaceFirst("/v1/", "/api/"))
            else -> listOf("/api$path", "/v1$path", path)
        }

        var lastEx: Exception? = null
        for (i in candidatePaths.indices) {
            val p = candidatePaths[i]
            val isLast = i == candidatePaths.lastIndex
            try {
                val fullUrl = url + p
                val b = Request.Builder().url(fullUrl)
                if (key.isNotEmpty()) {
                    b.header("Authorization", "Bearer $key")
                    b.header("X-Serverless-Token", key)
                }

                if (body != null) {
                    val bodyPayload = JSONObject(body.toString())
                    if (key.isNotEmpty() && !bodyPayload.has("token")) {
                        bodyPayload.put("token", key)
                    }
                    b.post(bodyPayload.toString().toRequestBody(JSON))
                }

                TelegramApi.client.newCall(b.build()).execute().use { resp ->
                    if (resp.code == 404 && !isLast) {
                        return@use // try next candidate path
                    }
                    val raw = resp.body?.string().orEmpty()
                    val json = try { JSONObject(raw.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
                    if (!resp.isSuccessful || !json.optBoolean("ok", true)) {
                        val msg = when (resp.code) {
                            401 -> "Serverless отклонил токен (401 Unauthorized)"
                            403 -> "Доступ к Serverless запрещён (403 Forbidden)"
                            429 -> "Слишком много запросов к Serverless, подождите"
                            404 -> "Эндпоинт $p не найден на сервере (404)"
                            else -> json.optString("error", "Serverless ответил HTTP ${resp.code}")
                        }
                        throw BridgeException(msg, resp.code)
                    }
                    return json
                }
            } catch (be: BridgeException) {
                throw be
            } catch (e: Exception) {
                lastEx = e
            }
        }
        throw lastEx ?: BridgeException("Не удалось связаться с Telegram Serverless", 0)
    }

    suspend fun status(context: Context): BridgeStatus = withContext(Dispatchers.IO) {
        val j = request(context, "/api/status", JSONObject())
        BridgeStatus(j.optBoolean("paired", true), j.optInt("chats"), j.optInt("messages"))
    }

    /** Records a message the app sent via Bot API so the cloud history contains outgoing messages too. */
    suspend fun recordOutgoing(context: Context, chatId: Long, messageId: Long, text: String, replyTo: Long?, time: Long) {
        val item = JSONObject().put("chat_id", chatId).put("message_id", messageId).put("text", text)
            .put("date", time).put("from_name", "Бот").apply { if (replyTo != null) put("reply_to", replyTo) }
        withContext(Dispatchers.IO) {
            try {
                request(context, "/api/outgoing", item)
            } catch (e: Exception) {
                enqueueOutgoing(context, item) // retried on the next sync
            }
        }
    }

    private fun enqueueOutgoing(context: Context, item: JSONObject) = synchronized(this) {
        val prefs = Prefs.of(context)
        val arr = JSONArray(prefs.getString("pending_outgoing", "[]"))
        if (arr.length() < 500) arr.put(item)
        prefs.edit().putString("pending_outgoing", arr.toString()).apply()
    }

    private fun flushOutgoing(context: Context) {
        val prefs = Prefs.of(context)
        val arr = synchronized(this) { JSONArray(prefs.getString("pending_outgoing", "[]")) }
        if (arr.length() == 0) return
        val left = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            try {
                request(context, "/api/outgoing", item)
            } catch (e: BridgeException) {
                if (e.code != 400) left.put(item)
            } catch (_: Exception) {
                left.put(item)
            }
        }
        synchronized(this) { prefs.edit().putString("pending_outgoing", left.toString()).apply() }
    }

    /**
     * Downloads all changes since the saved cursor. Returns the number of new incoming messages.
     * [notify] shows notifications for them (background worker).
     */
    suspend fun sync(context: Context, notify: Boolean = false): Int = lock.withLock {
        if (!Mode.isCloud(context) || !isConfigured(context)) return 0
        _state.value = _state.value.copy(syncing = true)
        withContext(Dispatchers.IO) {
            val prefs = Prefs.of(context)
            val storage = Storage.get(context)
            var newIncoming = 0
            try {
                flushOutgoing(context)
                var cursor = prefs.getLong("sync_cursor", 0L)
                val notifyQueue = mutableListOf<TgMessage>()
                for (page in 0 until MAX_PAGES) {
                    val j = request(context, "/api/sync?since=$cursor&limit=$PAGE")
                    val chats = HashMap<Long, Pair<String, String>>()
                    j.optJSONArray("chats")?.let { a ->
                        for (i in 0 until a.length()) {
                            val c = a.getJSONObject(i)
                            chats[c.getLong("id")] = c.optString("title") to c.optString("type", "private")
                        }
                    }
                    val msgs = j.optJSONArray("messages") ?: JSONArray()
                    for (i in 0 until msgs.length()) {
                        val m = msgs.getJSONObject(i)
                        val chatId = m.getLong("chat_id")
                        val msg = TgMessage(
                            id = m.getLong("id").takeIf { it > 0 } ?: m.optLong("message_id"),
                            chatId = chatId,
                            fromName = m.optString("from_name").ifBlank { "Пользователь" },
                            text = m.optString("text"),
                            time = m.getLong("time").takeIf { it > 0 } ?: m.optLong("date", System.currentTimeMillis()),
                            isBot = m.optInt("is_bot") == 1,
                            replyTo = if (m.isNull("reply_to")) null else m.getLong("reply_to"),
                            mediaType = if (m.isNull("media_type")) null else m.getString("media_type")
                        )
                        val isNew = !storage.messageExists(chatId, msg.id)
                        val countIt = isNew && !msg.isBot && MessageBus.openChatId != chatId
                        val (title, type) = chats[chatId] ?: (null to null)
                        storage.saveMessage(msg, title?.ifBlank { null }, type, countUnread = countIt)
                        if (countIt) {
                            newIncoming++
                            notifyQueue.add(msg)
                        }
                    }
                    cursor = j.optLong("next", cursor)
                    prefs.edit().putLong("sync_cursor", cursor).apply()
                    if (!j.optBoolean("has_more")) break
                }
                if (notify) {
                    notifyQueue.groupBy { it.chatId }.forEach { (chatId, list) ->
                        val last = list.last()
                        val text = if (list.size > 1) "${last.text}  (+${list.size - 1})" else last.text
                        Notifier.showMessage(context, last.fromName, text, chatId)
                    }
                }
                _state.value = CloudState(syncing = false, lastSync = System.currentTimeMillis(), error = null, lastNew = newIncoming)
            } catch (e: Exception) {
                _state.value = _state.value.copy(syncing = false, error = humanBridgeError(e))
            }
            if (newIncoming > 0) MessageBus.notifyChanged()
            newIncoming
        }
    }

    fun humanBridgeError(e: Throwable): String = when (e) {
        is BridgeException -> e.message.orEmpty()
        else -> humanError(e)
    }

    /** Resets the cursor so the whole bridge history is downloaded again (dedup keeps it safe). */
    fun resetCursor(context: Context) {
        Prefs.of(context).edit().putLong("sync_cursor", 0L).apply()
    }

    fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}

/** Background sync while the app is closed (Android runs it about every 15 minutes, when online). */
class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!Mode.isCloud(applicationContext)) return Result.success()
        CloudSync.sync(applicationContext, notify = true)
        return if (CloudSync.state.value.error == null) Result.success() else Result.retry()
    }
}
