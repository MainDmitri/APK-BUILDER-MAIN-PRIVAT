package com.tvtool.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var ip: EditText
    private lateinit var url: EditText
    private lateinit var out: TextView
    private lateinit var box: LinearLayout
    private lateinit var a: Adb
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("t", 0) }
    private val HOME = "com.tvtool.app/.HomeActivity"
    private val DNS = "dns.adguard-dns.com"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        a = Adb(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ip = EditText(this).apply { hint = "IP телевизора"; setText(prefs.getString("ip", "")); inputType = InputType.TYPE_CLASS_PHONE }
        url = EditText(this).apply { hint = "URL APK"; setText("https://github.com/yuliskov/SmartTube/releases/latest/download/smarttube_stable.apk") }
        out = TextView(this).apply { textSize = 12f; setTextIsSelectable(true) }
        box.addView(ip); box.addView(url)

        sec("1. Подключение")
        btn("🔍 Найти ТВ в сети (порт 5555)") { run("Сканирование /24") { val l = Adb.scan(); log(if (l.isEmpty()) "Ничего не найдено" else "Найдено: $l"); if (l.isNotEmpty()) runOnUiThread { ip.setText(l[0]) } } }
        btn("Подключиться + инфо") { conn { info() } }
        btn("Отключиться") { a.close(); log("Отключено") }

        sec("2. Загрузка и установка APK")
        btn("⬇ Скачать по URL и установить") { conn { fetch(url.text.toString(), true) } }
        btn("⬇ Только скачать на телефон") { run("Скачивание") { fetch(url.text.toString(), false) } }
        btn("GitHub-каталог: релиз owner/repo…") { ask("owner/repo", prefs.getString("repo", "yuliskov/SmartTube")!!) { r -> prefs.edit().putString("repo", r).apply(); github(r) } }
        btn("Установить APK с телефона") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), 1) }
        btn("Установить ЭТОТ лаунчер на ТВ и сделать главным") { conn { a.conn().install(File(applicationInfo.sourceDir)); log(a.sh("cmd package set-home-activity $HOME")); a.sh("input keyevent 3"); log("✔ TvLauncher установлен") } }

        sec("3. Приложения")
        btn("Заморозить…") { pick("Заморозить", "pm list packages -e") { l -> run("Заморозка") { val s = frozen(); l.forEach { log("$it: " + a.sh("pm disable-user --user 0 $it")); s.add(it) }; prefs.edit().putStringSet("frozen", s).apply() } } }
        btn("Вернуть как было") { conn { val s = frozen(); s.toList().forEach { val r = a.sh("pm enable $it"); log("$it: $r"); if (r.contains("enabled")) s.remove(it) }; prefs.edit().putStringSet("frozen", s).apply(); log(if (s.isEmpty()) "✔ Всё включено" else "Осталось ${s.size}, повторите") } }
        btn("Запустить на ТВ…") { pick("Запуск", "pm list packages -3") { l -> run("") { l.forEach { a.sh("monkey -p $it -c android.intent.category.LAUNCHER 1") } } } }
        btn("Удалить…") { pick("Удалить", "pm list packages -3") { l -> run("Удаление") { l.forEach { log("$it: " + a.sh("pm uninstall --user 0 $it")) } } } }
        btn("Очистить данные…") { pick("Очистить", "pm list packages -3") { l -> run("Очистка") { l.forEach { log("$it: " + a.sh("pm clear $it")) } } } }
        btn("💾 Резервная копия APK с ТВ на телефон") { pick("Сохранить APK", "pm list packages -3") { l -> run("Бэкап") { l.forEach { p -> val path = a.sh("pm path $p").lines().first().removePrefix("package:"); val f = File(dir("backup"), "$p.apk"); a.conn().pull(f, path); log("✔ ${f.path}") } } } }

        sec("4. Уникальное")
        btn("📸 Снимок системы (запомнить)") { conn { prefs.edit().putString("snap", snap()).apply(); log("✔ Снимок сохранён") } }
        btn("🔎 Что изменилось с момента снимка") { conn { diff() } }
        btn("📊 Монитор ТВ (RAM/CPU/темп.) 10 сек") { conn { repeat(5) { mon(); Thread.sleep(2000) } } }
        btn("⚡ Турбо: скорость анимаций…") { AlertDialog.Builder(this).setItems(arrayOf("0.5×", "Выключить", "Стандарт 1×")) { _, w -> val v = arrayOf("0.5", "0", "1")[w]; run("Анимации $v") { listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale").forEach { a.sh("settings put global $it $v") }; a.sh("am kill-all") } }.show() }
        btn("😴 Таймер сна ТВ") { ask("Минут до сна", "30") { m -> run("Таймер") { a.sh("nohup sh -c 'sleep ${(m.toIntOrNull() ?: 30) * 60}; input keyevent 223' </dev/null >/dev/null 2>&1 &"); log("✔ ТВ уснёт через $m мин") } } }
        btn("🎥 Запись экрана ТВ 10 сек") { conn { a.sh("screenrecord --time-limit 10 /sdcard/tvtool.mp4"); val f = File(dir("rec"), "rec${System.currentTimeMillis()}.mp4"); a.conn().pull(f, "/sdcard/tvtool.mp4"); log("✔ ${f.path}") } }
        btn("📸 Скриншот ТВ") { conn { a.sh("screencap -p /sdcard/tvtool.png"); val f = File(dir("shots"), "s.png"); a.conn().pull(f, "/sdcard/tvtool.png"); runOnUiThread { AlertDialog.Builder(this).setView(ImageView(this).apply { setImageBitmap(BitmapFactory.decodeFile(f.path)) }).show() } } }
        btn("📜 Logcat ТВ → поделиться") { conn { share(a.sh("logcat -d -t 400").takeLast(90000)) } }

        sec("5. Файлы ТВ")
        btn("Список папки…") { ask("Путь на ТВ", "/sdcard/") { p -> run("ls") { log(a.sh("ls -la '$p'")) } } }
        btn("Скачать файл с ТВ…") { ask("Путь к файлу", "/sdcard/Download/") { p -> run("pull") { val f = File(dir("tv"), p.substringAfterLast('/')); a.conn().pull(f, p); log("✔ ${f.path}") } } }
        btn("Отправить файл на ТВ (Download)") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), 2) }

        sec("6. DNS и пульт")
        btn("AdGuard DNS + автооткат") { conn { dnsOn() } }
        btn("DNS: вернуть как было") { conn { dnsOff() } }
        val pad = LinearLayout(this)
        listOf("◀" to 21, "▲" to 19, "▼" to 20, "▶" to 22, "OK" to 23, "⮌" to 4, "⌂" to 3, "🔊" to 24, "🔉" to 25).forEach { (t, k) ->
            pad.addView(Button(this).apply { text = t; setPadding(0, 0, 0, 0); setOnClickListener { run("") { a.sh("input keyevent $k") } } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        box.addView(pad)
        btn("⌨ Текст на ТВ") { ask("Текст", "") { t -> run("") { a.sh("input text '" + t.replace(" ", "%s").replace("'", "") + "'") } } }
        btn("🔁 Перезагрузка ТВ") { conn { a.sh("reboot") } }
        btn("📤 Отчёт → поделиться") { conn { share(report()) } }
        box.addView(out)

        val sv = ScrollView(this).apply { clipToPadding = false; addView(box) }
        ViewCompat.setOnApplyWindowInsetsListener(sv) { v, i -> val s = i.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(s.left + 24, s.top + 24, s.right + 24, s.bottom + 24); i }
        setContentView(sv)
    }

    // ---------- инфраструктура ----------
    private fun log(s: String) = runOnUiThread { out.append(s + "\n") }
    private fun run(label: String, f: () -> Unit) = io.execute {
        try { if (label.isNotEmpty()) log("▶ $label"); f() } catch (e: Throwable) { log("✖ ${e.message ?: e.javaClass.simpleName}"); a.close() }
    }
    private fun conn(f: () -> Unit) {
        val h = ip.text.toString().trim(); prefs.edit().putString("ip", h).apply()
        run("") { if (a.host != h) a.close(); a.host = h; a.conn(); f() }
    }
    private fun btn(t: String, f: () -> Unit) = box.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
    private fun sec(t: String) = box.addView(TextView(this).apply { text = t; textSize = 18f; setPadding(0, 28, 0, 4) })
    private fun dir(n: String) = File(getExternalFilesDir(null), n).apply { mkdirs() }
    private fun frozen() = prefs.getStringSet("frozen", emptySet())!!.toMutableSet()
    private fun ask(title: String, def: String, ok: (String) -> Unit) {
        val e = EditText(this).apply { setText(def) }
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("OK") { _, _ -> ok(e.text.toString().trim()) }.show()
    }
    private fun share(t: String) = runOnUiThread { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Поделиться")) }
    private fun pick(title: String, cmd: String, ok: (List<String>) -> Unit) = conn {
        val l = a.sh(cmd).lines().map { it.removePrefix("package:") }.filter { it.isNotBlank() }.sorted()
        runOnUiThread {
            val sel = BooleanArray(l.size)
            AlertDialog.Builder(this).setTitle(title).setMultiChoiceItems(l.toTypedArray(), sel) { _, i, c -> sel[i] = c }
                .setPositiveButton("OK") { _, _ -> ok(l.filterIndexed { i, _ -> sel[i] }) }.show()
        }
    }

    // ---------- функции ----------
    private fun info() {
        log("✔ ${a.sh("getprop ro.product.model")} / Android ${a.sh("getprop ro.build.version.release")}")
        log("Экран: ${a.sh("wm size")}\nДиск: ${a.sh("df /data | tail -1")}")
    }
    private fun fetch(u: String, install: Boolean) {
        val name = u.substringAfterLast('/').substringBefore('?').ifBlank { "app.apk" }
        val f = File(dir("apk"), name); log("⬇ $name")
        Adb.download(u, f) { log("  $it%") }
        log("SHA-256: ${Adb.sha256(f)}\nСохранён: ${f.path}")
        if (install) { a.conn().install(f); log("✔ Установлено") }
    }
    private fun github(repo: String) = run("GitHub $repo") {
        val l = Adb.releaseApks(repo)
        if (l.isEmpty()) { log("В релизе нет APK"); return@run }
        runOnUiThread {
            AlertDialog.Builder(this).setTitle("Выберите APK").setItems(l.map { it.first }.toTypedArray()) { _, i ->
                url.setText(l[i].second); conn { fetch(l[i].second, true) }
            }.show()
        }
    }
    private fun snap(): String {
        val dis = a.sh("pm list packages -d").lines().toSet()
        return a.sh("pm list packages").lines().filter { it.startsWith("package:") }.joinToString("\n") { it.removePrefix("package:") + "|" + (if (it in dis) "d" else "e") }
    }
    private fun diff() {
        val old = prefs.getString("snap", null) ?: return log("Сначала сделайте снимок")
        fun m(s: String) = s.lines().filter { "|" in it }.associate { it.substringBefore('|') to it.substringAfter('|') }
        val o = m(old); val n = m(snap())
        (n.keys - o.keys).forEach { log("＋ появилось: $it") }
        (o.keys - n.keys).forEach { log("－ удалено: $it") }
        n.filter { (k, v) -> o[k] != null && o[k] != v }.forEach { (k, v) -> log("⟳ $k: ${if (v == "d") "выключено" else "включено"}") }
        log("Сравнение завершено")
    }
    private fun mon() {
        val mem = a.sh("grep -E 'MemTotal|MemAvailable' /proc/meminfo").replace(Regex("\\s+"), " ").replace("\n", " | ")
        val t = a.sh("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null").toIntOrNull()?.div(1000)
        log("$mem | load ${a.sh("cat /proc/loadavg").substringBefore(" 0/").take(14)} | ${t ?: "?"}°C")
    }
    private fun dnsOn() {
        if (!prefs.contains("dnsMode")) prefs.edit().putString("dnsMode", a.sh("settings get global private_dns_mode")).putString("dnsSpec", a.sh("settings get global private_dns_specifier")).apply()
        a.sh("settings put global private_dns_specifier $DNS"); a.sh("settings put global private_dns_mode hostname")
        Thread.sleep(3000)
        if (Regex("[1-9]\\d* (packets )?received").containsMatchIn(a.sh("ping -c 1 -W 3 example.com"))) log("✔ DNS $DNS работает")
        else { log("✖ Интернет пропал — откат"); dnsOff() }
    }
    private fun dnsOff() {
        val m = prefs.getString("dnsMode", "opportunistic")!!.ifBlank { "opportunistic" }; val s = prefs.getString("dnsSpec", "") ?: ""
        if (s.isNotBlank() && s != "null") a.sh("settings put global private_dns_specifier $s")
        a.sh("settings put global private_dns_mode $m"); prefs.edit().remove("dnsMode").remove("dnsSpec").apply(); log("✔ DNS возвращён: $m")
    }
    private fun report() = "TvTool отчёт\n${a.sh("getprop ro.product.model")} Android ${a.sh("getprop ro.build.version.release")}\n" +
        "Польз. приложений: ${a.sh("pm list packages -3").lines().size}\nЗаморожено: ${frozen().joinToString()}\n" +
        "DNS: ${a.sh("settings get global private_dns_mode")} ${a.sh("settings get global private_dns_specifier")}\n${a.sh("grep MemAvailable /proc/meminfo")}"

    @Deprecated("simple")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        val u = d?.data ?: return
        val name = u.lastPathSegment?.substringAfterLast('/')?.ifBlank { null } ?: "file"
        conn {
            val f = File(cacheDir, if (r == 1) "pick.apk" else name)
            contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
            if (r == 1) { a.conn().install(f); log("✔ Установлено") } else { a.conn().push(f, "/sdcard/Download/$name"); log("✔ Отправлено в /sdcard/Download/$name") }
        }
    }
}
