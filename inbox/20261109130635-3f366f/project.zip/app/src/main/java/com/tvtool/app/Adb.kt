package com.tvtool.app

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import org.json.JSONObject
import java.io.File
import java.net.*
import java.security.MessageDigest
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class Adb(private val ctx: Context) {
    private var d: Dadb? = null
    var host = ""
    fun conn(): Dadb = d ?: run {
        val pk = File(ctx.filesDir, "adbkey"); val pb = File(ctx.filesDir, "adbkey.pub")
        if (!pk.exists()) AdbKeyPair.generate(pk, pb)
        Dadb.create(host, 5555, AdbKeyPair.read(pk, pb)).also { d = it }
    }
    fun sh(c: String): String = conn().shell(c).allOutput.trim()
    fun close() { try { d?.close() } catch (_: Throwable) {}; d = null }

    companion object {
        /** Ищет в подсети /24 устройства с открытым ADB-портом 5555 */
        fun scan(): List<String> {
            val me = NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress ?: return emptyList()
            val pre = me.substringBeforeLast('.') + "."
            val ex = Executors.newFixedThreadPool(64)
            val fs = (1..254).map { i ->
                ex.submit(Callable<String?> {
                    val h = pre + i
                    try { Socket().use { it.connect(InetSocketAddress(h, 5555), 450) }; h } catch (_: Throwable) { null }
                })
            }
            val r = fs.mapNotNull { it.get() }; ex.shutdown(); return r
        }

        fun download(u: String, dst: File, onP: (Int) -> Unit) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = true; c.connectTimeout = 15000; c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "TvTool")
            val len = c.contentLengthLong; var done = 0L; var last = -1
            c.inputStream.use { i -> dst.outputStream().use { o ->
                val b = ByteArray(65536)
                while (true) {
                    val n = i.read(b); if (n < 0) break
                    o.write(b, 0, n); done += n
                    if (len > 0) { val p = (done * 100 / len).toInt() / 20 * 20; if (p != last) { last = p; onP(p) } }
                }
            } }
        }

        fun sha256(f: File): String {
            val m = MessageDigest.getInstance("SHA-256")
            f.inputStream().use { i -> val b = ByteArray(65536); while (true) { val n = i.read(b); if (n < 0) break; m.update(b, 0, n) } }
            return m.digest().joinToString("") { "%02x".format(it) }
        }

        /** APK-файлы последнего релиза GitHub-репозитория owner/repo */
        fun releaseApks(repo: String): List<Pair<String, String>> {
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("User-Agent", "TvTool")
            val a = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("assets")
            return (0 until a.length()).map { a.getJSONObject(it) }
                .filter { it.getString("name").endsWith(".apk") }
                .map { it.getString("name") to it.getString("browser_download_url") }
        }
    }
}
