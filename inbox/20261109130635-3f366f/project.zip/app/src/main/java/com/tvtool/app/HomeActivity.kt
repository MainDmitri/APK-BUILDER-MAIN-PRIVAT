package com.tvtool.app

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : Activity() {
    private lateinit var grid: GridView
    private lateinit var info: TextView
    private var apps = listOf<ResolveInfo>()
    private val p by lazy { getSharedPreferences("l", 0) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15, 17, 26)) }
        val top = LinearLayout(this)
        top.addView(TextClock(this).apply {
            format12Hour = "HH:mm · EEE d MMM"; format24Hour = "HH:mm · EEE d MMM"; textSize = 28f; setTextColor(Color.WHITE)
            setOnClickListener { p.edit().remove("hide").apply(); load() } // клик по часам — показать скрытые
        }, LinearLayout.LayoutParams(0, -2, 1f))
        info = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 14f }
        top.addView(info)
        root.addView(top)
        grid = GridView(this).apply {
            numColumns = 6; verticalSpacing = 16; horizontalSpacing = 16; setPadding(0, 24, 0, 0)
            selector = ColorDrawable(0x55FFFFFF); isFocusable = true
            setOnItemClickListener { _, _, i, _ -> open(i) }
            setOnItemLongClickListener { _, _, i, _ -> menu(i); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -1))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, i -> val s = i.getInsets(WindowInsetsCompat.Type.systemBars()); v.setPadding(s.left + 48, s.top + 32, s.right + 48, s.bottom + 16); i }
        setContentView(root)
    }

    private fun open(i: Int) {
        if (i >= apps.size) { startActivity(Intent(Settings.ACTION_SETTINGS)); return }
        packageManager.getLaunchIntentForPackage(apps[i].activityInfo.packageName)?.let { startActivity(it) }
    }

    private fun menu(i: Int) {
        if (i >= apps.size) return
        val pkg = apps[i].activityInfo.packageName
        AlertDialog.Builder(this).setItems(arrayOf("Закрепить / открепить", "Скрыть", "Удалить", "О приложении")) { _, w ->
            fun tog(k: String) { val s = p.getStringSet(k, emptySet())!!.toMutableSet(); if (!s.add(pkg)) s.remove(pkg); p.edit().putStringSet(k, s).apply(); load() }
            when (w) {
                0 -> tog("pin"); 1 -> tog("hide")
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            }
        }.show()
    }

    override fun onResume() { super.onResume(); load() }
    @Deprecated("home") override fun onBackPressed() {}

    private fun load() {
        val pm = packageManager
        val pin = p.getStringSet("pin", emptySet())!!; val hide = p.getStringSet("hide", emptySet())!!
        apps = (pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0) +
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in hide }
            .sortedWith(compareBy({ it.activityInfo.packageName !in pin }, { it.loadLabel(pm).toString().lowercase() }))
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        info.text = "RAM свободно ${mi.availMem / 1048576} МБ · приложений ${apps.size}"
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size + 1
            override fun getItem(i: Int) = i
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, par: ViewGroup?): View = TextView(this@HomeActivity).apply {
                setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 14f; setPadding(8, 16, 8, 16); setBackgroundColor(Color.rgb(28, 31, 46))
                if (i < apps.size) {
                    val a = apps[i]
                    text = (if (a.activityInfo.packageName in pin) "★ " else "") + a.loadLabel(pm)
                    setCompoundDrawablesWithIntrinsicBounds(null, a.loadIcon(pm), null, null)
                } else text = "⚙\nНастройки"
            }
        }
    }
}
