// [context: Flutter/Dart 3.13.5, iOS + Android, Wine Dark Material3 theme]
// *the root — dark wine palette, tab navigator, auth gate on every cold start*

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/auth_service.dart';
import 'screens/auth_screen.dart';
import 'screens/scan_screen.dart';
import 'screens/results_screen.dart';

// ── Wine Dark palette — mirrors Android Material3 scheme ──────────────────────
const _seed       = Color(0xFF7B1C2E); // deep wine red
const _surfDark   = Color(0xFF120608); // near-black base
const _surfCon    = Color(0xFF1E0C0F); // elevated container
const _surfHigh   = Color(0xFF2C1318); // highest container
const _onSurf     = Color(0xFFF0DDE0); // light cream
const _outline    = Color(0xFF6B3B42); // muted wine border
const _primary    = Color(0xFFCF6679); // rose-red primary
const _onPrimary  = Color(0xFF1C0008);
const _secondary  = Color(0xFFE8B4BC); // pale pink secondary
const _onSec      = Color(0xFF2D0012);
const _error      = Color(0xFFFF5370);

final _darkScheme = ColorScheme(
  brightness: Brightness.dark,
  primary:   _primary,    onPrimary: _onPrimary,
  secondary: _secondary,  onSecondary: _onSec,
  error:     _error,      onError: Colors.black,
  surface:   _surfDark,   onSurface: _onSurf,
  outline:   _outline,
  surfaceContainerLow:     const Color(0xFF180A0D),
  surfaceContainer:        _surfCon,
  surfaceContainerHigh:    _surfHigh,
  surfaceContainerHighest: const Color(0xFF3A1A21),
);

final _theme = ThemeData(
  colorScheme:   _darkScheme,
  useMaterial3: true,
  scaffoldBackgroundColor: _surfDark,
  appBarTheme: AppBarTheme(
    backgroundColor: _surfDark,
    foregroundColor: _onSurf,
    elevation: 0,
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  ),
  tabBarTheme: TabBarThemeData(
    labelColor:         _primary,
    unselectedLabelColor: _outline,
    indicatorColor:     _primary,
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: FilledButton.styleFrom(
      backgroundColor: _primary,
      foregroundColor: _onPrimary,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: _primary,
      side: const BorderSide(color: _primary),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    labelStyle:  TextStyle(color: _outline),
    hintStyle:   TextStyle(color: _outline.withOpacity(0.6)),
    prefixIconColor: _primary,
    enabledBorder:  OutlineInputBorder(
      borderSide: BorderSide(color: _outline),
      borderRadius: BorderRadius.circular(10),
    ),
    focusedBorder:  OutlineInputBorder(
      borderSide: BorderSide(color: _primary, width: 2),
      borderRadius: BorderRadius.circular(10),
    ),
    fillColor: _surfHigh,
    filled: true,
  ),
  cardTheme: CardThemeData(
    color: _surfCon,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
      side: BorderSide(color: _outline.withOpacity(0.3)),
    ),
  ),
  chipTheme: ChipThemeData(
    backgroundColor: _surfHigh,
    selectedColor: _primary.withOpacity(0.25),
    labelStyle: TextStyle(color: _onSurf, fontSize: 11),
    side: BorderSide(color: _outline.withOpacity(0.5)),
  ),
  switchTheme: SwitchThemeData(
    thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? _primary : _outline),
    trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? _primary.withOpacity(0.3) : _surfHigh),
  ),
  progressIndicatorTheme: const ProgressIndicatorThemeData(color: _primary),
  dividerColor: _outline.withOpacity(0.3),
);

// ── entry point ───────────────────────────────────────────────────────────────

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const MainScannerApp());
}

class MainScannerApp extends StatelessWidget {
  const MainScannerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Main Scanner',
      debugShowCheckedModeBanner: false,
      theme: _theme,
      home: const _AppRoot(),
    );
  }
}

// ── auth gate ─────────────────────────────────────────────────────────────────

class _AppRoot extends StatefulWidget {
  const _AppRoot();

  @override
  State<_AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<_AppRoot> {
  bool? _activated;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final act  = await AuthService.isActivated();
    final lock = await AuthService.verifyDeviceLock();
    final ok   = act && lock;
    if (mounted) setState(() => _activated = ok);
  }

  @override
  Widget build(BuildContext context) {
    if (_activated == null) {
      return Scaffold(
        backgroundColor: _surfDark,
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    if (!_activated!) {
      return AuthScreen(onActivated: () => setState(() => _activated = true));
    }
    return const _MainShell();
  }
}

// ── main shell — Scanner / Findings / Saved tabs ──────────────────────────────

class _MainShell extends StatefulWidget {
  const _MainShell();

  @override
  State<_MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<_MainShell> with SingleTickerProviderStateMixin {
  late final TabController _tc = TabController(length: 2, vsync: this);

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.surface,
      appBar: AppBar(
        backgroundColor: cs.surface,
        title: Row(
          children: [
            Icon(Icons.radar, color: cs.primary, size: 22),
            const SizedBox(width: 8),
            const Text('Main Scanner',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
          ],
        ),
        bottom: TabBar(
          controller: _tc,
          tabs: const [
            Tab(icon: Icon(Icons.wifi_find), text: 'Scanner'),
            Tab(icon: Icon(Icons.storage),   text: 'Saved'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tc,
        children: const [
          ScanScreen(),
          ResultsScreen(),
        ],
      ),
    );
  }
}
