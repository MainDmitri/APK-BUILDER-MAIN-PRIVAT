// [context: Flutter/Dart 3.13.5, sqflite, SQLite persistent result store]
// *the database keeps every hit until the operator decides to clean house*

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/scan_result.dart';

class ResultStorage {
  static Database? _db;

  static Future<Database> _open() async {
    if (_db != null) return _db!;
    final dir  = await getDatabasesPath();
    final path = join(dir, 'scan_results.db');
    _db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, _) async {
        await db.execute('''
          CREATE TABLE results (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            ip        TEXT    NOT NULL,
            port      INTEGER NOT NULL,
            brand     TEXT    NOT NULL,
            login     TEXT    NOT NULL,
            password  TEXT    NOT NULL,
            model     TEXT    NOT NULL DEFAULT '',
            blocked   INTEGER NOT NULL DEFAULT 0,
            open_ports TEXT   NOT NULL DEFAULT '',
            all_ports  TEXT   NOT NULL DEFAULT '',
            found_at  INTEGER NOT NULL
          )
        ''');
        await db.execute('CREATE INDEX idx_ip ON results(ip)');
      },
    );
    return _db!;
  }

  // ── write ──────────────────────────────────────────────────────────────────

  static Future<int> addResult(ScanResult r) async {
    final db  = await _open();
    return db.insert('results', r.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ── read ───────────────────────────────────────────────────────────────────

  static Future<List<ScanResult>> loadAll() async {
    final db   = await _open();
    final rows = await db.query('results', orderBy: 'found_at DESC');
    return rows.map(ScanResult.fromMap).toList();
  }

  static Future<List<ScanResult>> loadRecent(int limit) async {
    final db   = await _open();
    final rows = await db.query('results', orderBy: 'found_at DESC', limit: limit);
    return rows.map(ScanResult.fromMap).toList();
  }

  static Future<int> count() async {
    final db  = await _open();
    final res = await db.rawQuery('SELECT COUNT(*) as c FROM results');
    return (res.first['c'] as int?) ?? 0;
  }

  // ── delete ─────────────────────────────────────────────────────────────────

  static Future<void> deleteById(int id) async {
    final db = await _open();
    await db.delete('results', where: 'id = ?', whereArgs: [id]);
  }

  static Future<void> clearAll() async {
    final db = await _open();
    await db.delete('results');
  }
}
