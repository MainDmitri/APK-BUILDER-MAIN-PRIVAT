// [context: Flutter/Dart 3.13.5, iOS + Android, HMAC-SHA256 activation, shared_preferences]
// *the activation gate — each nick gets one valid code, bound to this device forever after*

import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Mirrors Android AuthManager:
///   activationCode = HMAC-SHA256(key=nickname.bytes, data="ACTIVATE").toUpperCase().take(12)
///                    formatted as XXXX-XXXX-XXXX
///   lockHash       = SHA-256(deviceId + code + nickname) — stored at activation,
///                    verified each launch
class AuthService {
  static const _kActivated    = 'activated';
  static const _kNickname     = 'nickname';
  static const _kCode         = 'code';
  static const _kDeviceId     = 'device_id';
  static const _kLockHash     = 'lock_hash';

  // Admin password — bcrypt would be overkill; SHA-256 of "Admin2024!" matches Android
  static const _adminPassHash =
      'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3'; // sha256("123")

  static const _tgcloudUrl  = 'https://cloud.telegram.org/app9052071852/api/check';
  static const _endpointSec = 'msx9k_MainDmitri_2024_lock';

  // ── public API ──────────────────────────────────────────────────────────

  static Future<bool> isActivated() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(_kActivated) ?? false;
  }

  static Future<String> getActiveNickname() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_kNickname) ?? '';
  }

  static Future<String> getDeviceId() async {
    final p = await SharedPreferences.getInstance();
    var id = p.getString(_kDeviceId);
    if (id == null || id.isEmpty) {
      // Generate once: use platform identifier bits + random bytes mixed
      // On iOS there's no ANDROID_ID — we derive from platform string + timestamp
      final raw = '${Platform.operatingSystem}_${Platform.operatingSystemVersion}_'
          '${DateTime.now().microsecondsSinceEpoch}';
      final hash = sha256.convert(utf8.encode(raw));
      id = hash.toString().substring(0, 16);
      await p.setString(_kDeviceId, id);
    }
    return id;
  }

  /// Validate nickname+code pair and persist if correct.
  /// Returns null on success, error string on failure.
  static Future<String?> activate(String nickname, String rawCode) async {
    // Strip dashes, uppercase
    final code = rawCode.replaceAll('-', '').toUpperCase();
    final expected = _generateCode(nickname);

    if (code != expected) return 'Неверный код активации';

    // Build lock hash — device binding
    final deviceId = await getDeviceId();
    final lockInput = '$deviceId$code$nickname';
    final lockHash = sha256.convert(utf8.encode(lockInput)).toString();

    final p = await SharedPreferences.getInstance();
    await p.setBool(_kActivated, true);
    await p.setString(_kNickname, nickname);
    await p.setString(_kCode, code);
    await p.setString(_kLockHash, lockHash);

    // Notify tgcloud (fire-and-forget)
    _notifyActivation(nickname, deviceId, code);

    return null; // success
  }

  /// Verify device lock — call on each app launch.
  /// Returns false if device/code/nick combo doesn't match stored lock hash.
  static Future<bool> verifyDeviceLock() async {
    final p = await SharedPreferences.getInstance();
    if (!(p.getBool(_kActivated) ?? false)) return true; // not activated yet — ok

    final stored = p.getString(_kLockHash) ?? '';
    if (stored.isEmpty) return true;

    final deviceId = p.getString(_kDeviceId) ?? '';
    final code     = p.getString(_kCode) ?? '';
    final nickname = p.getString(_kNickname) ?? '';

    final expected = sha256.convert(utf8.encode('$deviceId$code$nickname')).toString();
    return stored == expected;
  }

  static Future<void> deactivate() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kActivated);
    await p.remove(_kNickname);
    await p.remove(_kCode);
    await p.remove(_kLockHash);
  }

  /// Generate activation code for a nickname.
  /// HMAC-SHA256(key=nickname.bytes, data="ACTIVATE") → uppercase hex, take 12 chars
  static String generateCodeForNickname(String nickname) {
    return _generateCode(nickname);
  }

  static bool verifyAdminPassword(String pass) {
    final h = sha256.convert(utf8.encode(pass)).toString();
    return h == _adminPassHash;
  }

  // ── internal ────────────────────────────────────────────────────────────

  static String _generateCode(String nickname) {
    final key  = utf8.encode(nickname);
    final data = utf8.encode('ACTIVATE');
    final hmac = Hmac(sha256, key);
    final dig  = hmac.convert(data);
    // 12 uppercase hex chars → format XXXX-XXXX-XXXX
    return dig.toString().toUpperCase().substring(0, 12);
  }

  static void _notifyActivation(String nickname, String deviceId, String code) async {
    // *the endpoint whispers back to the admin: someone just woke up*
    try {
      final client = HttpClient();
      client.connectionTimeout = const Duration(seconds: 6);
      final uri = Uri.parse(_tgcloudUrl);
      final req = await client.postUrl(uri);
      req.headers.set('Content-Type', 'application/json');
      final body = jsonEncode({
        'secret'  : _endpointSec,
        'nickname': nickname,
        'deviceId': deviceId,
        'code'    : code,
      });
      req.contentLength = utf8.encode(body).length;
      req.write(body);
      await req.close();
      client.close();
    } catch (_) {
      // Fallback: direct bot message
      try {
        final client = HttpClient();
        final uri = Uri.parse(
          'https://api.telegram.org/bot9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY/sendMessage',
        );
        final req = await client.postUrl(uri);
        req.headers.set('Content-Type', 'application/json');
        final body = jsonEncode({
          'chat_id': '6365916323',
          'text'   : '🔑 Активация (iOS/Flutter)\n👤 $nickname\n📱 $deviceId',
        });
        req.contentLength = utf8.encode(body).length;
        req.write(body);
        await req.close();
        client.close();
      } catch (_) {}
    }
  }
}
