// [context: Flutter/Dart 3.13.5, iOS + Android, SQLite results viewer, Wine Dark]
// *the trophy room — every camera the scanner ever found, until the operator wipes it*

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/scan_result.dart';
import '../services/result_storage.dart';

class ResultsScreen extends StatefulWidget {
  const ResultsScreen({super.key});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  List<ScanResult> _results = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final r = await ResultStorage.loadAll();
    if (mounted) setState(() { _results = r; _loading = false; });
  }

  Future<void> _clearAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear all results?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Clear')),
        ],
      ),
    );
    if (ok == true) {
      await ResultStorage.clearAll();
      _load();
    }
  }

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Copied'), duration: Duration(seconds: 1)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.surface,
      appBar: AppBar(
        backgroundColor: cs.surface,
        title: Text('Saved  (${_results.length})',
            style: TextStyle(color: cs.onSurface)),
        actions: [
          if (_results.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined),
              onPressed: _clearAll,
              tooltip: 'Clear all',
            ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _load,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _results.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.search_off, size: 56, color: cs.outline),
                      const SizedBox(height: 12),
                      Text('No saved results',
                          style: TextStyle(color: cs.outline, fontSize: 16)),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: _results.length,
                    itemBuilder: (ctx, i) => _SavedCard(
                      r: _results[i],
                      onCopy: _copy,
                      onDelete: () async {
                        // find by ip+port+foundAt — no id exposed in model, delete & reload
                        // for simplicity, clear all isn't ideal but per-item needs id
                        // We reload from DB to get the real SQLite id
                        final all = await ResultStorage.loadAll();
                        final match = all.where((x) =>
                            x.ip == _results[i].ip &&
                            x.port == _results[i].port &&
                            x.foundAt == _results[i].foundAt).toList();
                        // We can't delete by id without exposing it — use clearAll + reinsert
                        // Simple approach: rebuild DB (small sets in practice)
                        await ResultStorage.clearAll();
                        final remaining = List<ScanResult>.from(_results)..removeAt(i);
                        for (final r in remaining.reversed) {
                          await ResultStorage.addResult(r);
                        }
                        _load();
                      },
                    ),
                  ),
                ),
    );
  }
}

class _SavedCard extends StatelessWidget {
  final ScanResult r;
  final void Function(String) onCopy;
  final VoidCallback onDelete;

  const _SavedCard({required this.r, required this.onCopy, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final date = '${r.foundAt.day.toString().padLeft(2,'0')}.${r.foundAt.month.toString().padLeft(2,'0')} '
        '${r.foundAt.hour.toString().padLeft(2,'0')}:${r.foundAt.minute.toString().padLeft(2,'0')}';

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      color: cs.surfaceContainerHigh,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header row
            Row(
              children: [
                Icon(Icons.videocam, color: cs.primary, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${r.ip}:${r.port}',
                    style: TextStyle(
                        color: cs.onSurface,
                        fontWeight: FontWeight.w700,
                        fontSize: 15),
                  ),
                ),
                Text(date, style: TextStyle(color: cs.outline, fontSize: 11)),
                IconButton(
                  icon: Icon(Icons.delete_outline, size: 18, color: cs.error),
                  onPressed: onDelete,
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
            const SizedBox(height: 4),
            // Brand / model
            Text(r.brand + (r.model.isNotEmpty ? ' · ${r.model}' : ''),
                style: TextStyle(color: cs.primary, fontSize: 12)),
            const SizedBox(height: 6),
            // Credentials
            GestureDetector(
              onTap: () => onCopy(r.credentialLabel),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: cs.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.vpn_key, size: 13, color: cs.outline),
                    const SizedBox(width: 4),
                    Text(r.credentialLabel,
                        style: TextStyle(
                            fontFamily: 'monospace',
                            fontSize: 12,
                            color: cs.onSurface)),
                    const SizedBox(width: 6),
                    Icon(Icons.copy, size: 12, color: cs.outline),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
