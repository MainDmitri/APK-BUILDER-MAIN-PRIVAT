// [context: Flutter/Dart 3.13.5, iOS + Android, Material3 Wine Dark, activation UI]
// *the gate — wrong code three times and the timer starts ticking*

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  final VoidCallback onActivated;
  const AuthScreen({super.key, required this.onActivated});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _nickCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _formKey  = GlobalKey<FormState>();

  bool   _loading       = false;
  String _error         = '';
  int    _failCount     = 0;
  bool   _locked        = false;
  int    _lockSecs      = 0;
  Timer? _lockTimer;

  // Hidden admin panel: double-tap version chip
  int    _tapCount     = 0;
  Timer? _tapTimer;
  bool   _adminVisible = false;
  final  _adminCtrl    = TextEditingController();

  @override
  void dispose() {
    _lockTimer?.cancel();
    _tapTimer?.cancel();
    _nickCtrl.dispose();
    _codeCtrl.dispose();
    _adminCtrl.dispose();
    super.dispose();
  }

  // ── activation ─────────────────────────────────────────────────────────────

  Future<void> _activate() async {
    if (_locked) return;
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() { _loading = true; _error = ''; });

    final err = await AuthService.activate(
      _nickCtrl.text.trim(),
      _codeCtrl.text.trim(),
    );

    if (!mounted) return;
    setState(() => _loading = false);

    if (err == null) {
      widget.onActivated();
    } else {
      _failCount++;
      if (_failCount >= 5) _startLockout();
      setState(() => _error = err);
    }
  }

  void _startLockout() {
    _lockSecs = 30;
    _locked   = true;
    _failCount = 0;
    _lockTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() {
        _lockSecs--;
        if (_lockSecs <= 0) { _locked = false; t.cancel(); }
      });
    });
  }

  // ── code auto-format XXXX-XXXX-XXXX ───────────────────────────────────────

  void _onCodeChanged(String v) {
    final raw = v.replaceAll('-', '').toUpperCase();
    if (raw.length > 12) return;
    final formatted = StringBuffer();
    for (var i = 0; i < raw.length; i++) {
      if (i > 0 && i % 4 == 0) formatted.write('-');
      formatted.write(raw[i]);
    }
    final result = formatted.toString();
    if (result != v) {
      _codeCtrl.value = TextEditingValue(
        text: result,
        selection: TextSelection.collapsed(offset: result.length),
      );
    }
  }

  // ── hidden admin tap ───────────────────────────────────────────────────────

  void _onVersionTap() {
    _tapTimer?.cancel();
    _tapCount++;
    if (_tapCount >= 7) {
      _tapCount = 0;
      setState(() => _adminVisible = !_adminVisible);
      return;
    }
    _tapTimer = Timer(const Duration(milliseconds: 600), () => _tapCount = 0);
  }

  Future<void> _adminLogin() async {
    if (AuthService.verifyAdminPassword(_adminCtrl.text.trim())) {
      // bypass activation — use admin nick
      await AuthService.activate('Admin', AuthService.generateCodeForNickname('Admin'));
      if (mounted) widget.onActivated();
    } else {
      setState(() => _error = 'Wrong admin password');
    }
  }

  // ── build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.surface,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Logo / title
                Icon(Icons.radar, size: 64, color: cs.primary),
                const SizedBox(height: 12),
                Text('Main Scanner',
                    style: Theme.of(context)
                        .textTheme
                        .headlineMedium
                        ?.copyWith(color: cs.onSurface, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                GestureDetector(
                  onTap: _onVersionTap,
                  child: Text('v2.0.0',
                      style: TextStyle(color: cs.outline, fontSize: 12)),
                ),
                const SizedBox(height: 32),

                // Form
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      _buildField(
                        ctrl: _nickCtrl,
                        label: 'Nickname',
                        icon: Icons.person_outline,
                        validator: (v) =>
                            (v == null || v.trim().isEmpty) ? 'Enter nickname' : null,
                      ),
                      const SizedBox(height: 16),
                      _buildField(
                        ctrl: _codeCtrl,
                        label: 'Activation Code  (XXXX-XXXX-XXXX)',
                        icon: Icons.vpn_key_outlined,
                        onChanged: _onCodeChanged,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\-]')),
                          LengthLimitingTextInputFormatter(14),
                        ],
                        validator: (v) {
                          final raw = (v ?? '').replaceAll('-', '');
                          return raw.length != 12 ? 'Code must be 12 chars' : null;
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // Error
                if (_error.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text(_error, style: TextStyle(color: cs.error, fontSize: 13)),
                  ),

                // Lockout timer
                if (_locked)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: Text('Too many attempts. Wait $_lockSecs s',
                        style: TextStyle(color: cs.error, fontSize: 13)),
                  ),

                // Activate button
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: FilledButton(
                    onPressed: (_loading || _locked) ? null : _activate,
                    child: _loading
                        ? const SizedBox(width: 22, height: 22,
                              child: CircularProgressIndicator(strokeWidth: 2))
                        : const Text('Activate', style: TextStyle(fontSize: 16)),
                  ),
                ),

                // Admin panel (hidden)
                if (_adminVisible) ...[
                  const SizedBox(height: 24),
                  Divider(color: cs.outline.withOpacity(0.3)),
                  const SizedBox(height: 12),
                  _buildField(
                    ctrl: _adminCtrl,
                    label: 'Admin Password',
                    icon: Icons.lock_outline,
                    obscure: true,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    height: 46,
                    child: OutlinedButton(
                      onPressed: _adminLogin,
                      child: const Text('Admin Login'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController ctrl,
    required String label,
    required IconData icon,
    void Function(String)? onChanged,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    bool obscure = false,
  }) {
    final cs = Theme.of(context).colorScheme;
    return TextFormField(
      controller: ctrl,
      obscureText: obscure,
      onChanged: onChanged,
      inputFormatters: inputFormatters,
      validator: validator,
      style: TextStyle(color: cs.onSurface),
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: cs.primary),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
        filled: true,
        fillColor: cs.surfaceContainerHigh,
      ),
    );
  }
}
