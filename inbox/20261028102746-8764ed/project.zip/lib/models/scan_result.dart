// [context: Flutter/Dart 3.13.5, iOS + Android, scan result data model]

class ScanResult {
  final String ip;
  final int port;
  final String brand;
  final String login;
  final String password;
  final String model;
  final bool blocked;
  final List<int> openPortsList;
  final List<int> allOpenPorts;
  final DateTime foundAt;

  const ScanResult({
    required this.ip,
    required this.port,
    required this.brand,
    required this.login,
    required this.password,
    this.model = '',
    this.blocked = false,
    this.openPortsList = const [],
    this.allOpenPorts = const [],
    required this.foundAt,
  });

  // *every open port gets its own TCP handshake — the socket knows when it lands*
  String get credentialLabel =>
      (login.isEmpty && password.isEmpty) ? '(open)' : '$login:$password';

  bool get isTerminal => const {'SSH-TTY', 'Telnet-TTY', 'VPS'}.contains(brand);

  Map<String, dynamic> toMap() => {
        'ip': ip,
        'port': port,
        'brand': brand,
        'login': login,
        'password': password,
        'model': model,
        'blocked': blocked ? 1 : 0,
        'open_ports': openPortsList.join(','),
        'all_ports': allOpenPorts.join(','),
        'found_at': foundAt.millisecondsSinceEpoch,
      };

  factory ScanResult.fromMap(Map<String, dynamic> m) => ScanResult(
        ip: m['ip'] as String,
        port: m['port'] as int,
        brand: m['brand'] as String,
        login: m['login'] as String,
        password: m['password'] as String,
        model: (m['model'] as String?) ?? '',
        blocked: (m['blocked'] as int) == 1,
        openPortsList: _parsePorts(m['open_ports'] as String?),
        allOpenPorts: _parsePorts(m['all_ports'] as String?),
        foundAt: DateTime.fromMillisecondsSinceEpoch(m['found_at'] as int),
      );

  static List<int> _parsePorts(String? s) {
    if (s == null || s.isEmpty) return [];
    return s.split(',').map((e) => int.tryParse(e) ?? 0).where((v) => v > 0).toList();
  }
}

class ScanProgress {
  final int total;
  final int checked;
  final int successful;
  final int blocked;
  final int openPorts;
  final bool finished;
  final bool cancelled;
  final String lastLogLine;

  const ScanProgress({
    required this.total,
    this.checked = 0,
    this.successful = 0,
    this.blocked = 0,
    this.openPorts = 0,
    this.finished = false,
    this.cancelled = false,
    this.lastLogLine = '',
  });

  ScanProgress copyWith({
    int? total,
    int? checked,
    int? successful,
    int? blocked,
    int? openPorts,
    bool? finished,
    bool? cancelled,
    String? lastLogLine,
  }) =>
      ScanProgress(
        total: total ?? this.total,
        checked: checked ?? this.checked,
        successful: successful ?? this.successful,
        blocked: blocked ?? this.blocked,
        openPorts: openPorts ?? this.openPorts,
        finished: finished ?? this.finished,
        cancelled: cancelled ?? this.cancelled,
        lastLogLine: lastLogLine ?? this.lastLogLine,
      );
}
