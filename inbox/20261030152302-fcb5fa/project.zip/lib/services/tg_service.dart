// ignore_for_file: avoid_print
import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:teleflutter/teleflutter.dart';

import '../models/message.dart';
import 'sqlite_cache.dart';

// ─── Auth states ────────────────────────────────────────────────────────────

enum TgAuthState {
  idle,
  connecting,
  waitingPhoneNumber,
  waitingCode,
  waitingPassword,
  ready,
  error,
}

// ─── TgService ──────────────────────────────────────────────────────────────

class TgService extends ChangeNotifier {
  TgService._();
  static final TgService instance = TgService._();

  TelegramClient? _client;

  TgAuthState _authState = TgAuthState.idle;
  String _statusMessage = '';
  int _myUserId = 0;
  bool _initialized = false;

  List<TgDialog> _dialogs = [];

  final _chatStreamCtrl = StreamController<List<TgDialog>>.broadcast();
  final _newMsgCtrl = StreamController<TgMessage>.broadcast();

  String _pendingPhone = '';
  String _pendingPhoneCodeHash = '';

  TgAuthState get authState => _authState;
  String get statusMessage => _statusMessage;
  int get myUserId => _myUserId;
  List<TgDialog> get dialogs => List.unmodifiable(_dialogs);
  Stream<List<TgDialog>> get chatStream => _chatStreamCtrl.stream;
  Stream<TgMessage> get newMessageStream => _newMsgCtrl.stream;

  static const int _apiId = 21099690;
  static const String _apiHash = '9c1130843fda5f6516d7c8197ec26281';

  // ─── Init ─────────────────────────────────────────────────────────────────

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    _setState(TgAuthState.connecting, 'Загрузка кэша...');

    // Show cached data immediately
    await _loadCachedDialogs();

    try {
      final sessionString = await _loadSessionString();
      await _connect(sessionString);
    } catch (e) {
      print('[TgService] initialize error: $e');
      _setState(TgAuthState.waitingPhoneNumber, 'Требуется авторизация');
    }
  }

  // ─── Session ──────────────────────────────────────────────────────────────

  Future<String> _loadSessionString() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final sessionDir = Directory(p.join(docsDir.path, 'tg_sessions'));
    await sessionDir.create(recursive: true);

    final sessionFile = File(p.join(sessionDir.path, 'main.session'));
    if (!await sessionFile.exists()) {
      final data = await rootBundle.load('assets/sessions/main.session');
      await sessionFile.writeAsBytes(
        data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
      );
    }

    return (await sessionFile.readAsString()).trim();
  }

  // ─── Connect ──────────────────────────────────────────────────────────────

  Future<void> _connect(String sessionString) async {
    _setState(TgAuthState.connecting, 'Подключение к Telegram...');
    try {
      // teleflutter: TelegramClient(session, apiId, apiHash)
      // Pass StringSession with saved session string to resume without re-auth
      _client = TelegramClient(
        StringSession(sessionString),
        _apiId,
        _apiHash,
      );

      await _client!.connect();
      _subscribeToEvents();

      // Verify authorization
      final authorized = await _checkAuth();
      if (authorized) {
        await _onReady();
      } else {
        _setState(TgAuthState.waitingPhoneNumber, 'Введите номер телефона');
      }
    } catch (e) {
      print('[TgService] connect error: $e');
      _setState(TgAuthState.waitingPhoneNumber, 'Требуется авторизация');
    }
  }

  Future<bool> _checkAuth() async {
    try {
      // teleflutter high-level: client.getMe() or client.invoke(GetMe())
      final me = await _client!.getMe();
      if (me != null) {
        _myUserId = me.id;
        return true;
      }
      return false;
    } catch (e) {
      print('[TgService] checkAuth error: $e');
      return false;
    }
  }

  Future<void> _onReady() async {
    _setState(TgAuthState.ready, 'Подключено');
    unawaited(_fetchAndCacheDialogs());
  }

  // ─── Events ───────────────────────────────────────────────────────────────

  void _subscribeToEvents() {
    try {
      _client!.on(NewMessage(), _onNewMessage);
    } catch (e) {
      print('[TgService] subscribeToEvents error: $e');
    }
  }

  Future<void> _onNewMessage(dynamic event) async {
    try {
      final msg = event?.message ?? event;
      final tgMsg = _parseMsgDynamic(msg);
      if (tgMsg == null) return;

      final db = await SqliteCache.open();
      await db.saveMessage(tgMsg);
      _updateDialogLastMsg(tgMsg);

      _newMsgCtrl.add(tgMsg);
      _chatStreamCtrl.add(_dialogs);
      notifyListeners();
    } catch (e) {
      print('[TgService] onNewMessage error: $e');
    }
  }

  // ─── Fetch dialogs ────────────────────────────────────────────────────────

  Future<void> _fetchAndCacheDialogs() async {
    if (_client == null) return;
    try {
      // Use teleflutter high-level getDialogs
      final dialogs = await _client!.getDialogs(limit: 100);
      if (dialogs == null || dialogs.isEmpty) return;

      final tgDialogs = <TgDialog>[];
      for (final d in dialogs) {
        final tgD = _parseDialogEntity(d);
        if (tgD != null) tgDialogs.add(tgD);
      }

      if (tgDialogs.isNotEmpty) {
        _dialogs = tgDialogs;
        final db = await SqliteCache.open();
        for (final d in tgDialogs) {
          await db.upsertChat(d);
        }
        _chatStreamCtrl.add(_dialogs);
        notifyListeners();
      }
    } catch (e) {
      print('[TgService] fetchDialogs error: $e');
      // Not fatal — cached data already displayed
    }
  }

  TgDialog? _parseDialogEntity(dynamic d) {
    try {
      // teleflutter dialog entity exposes: id, title, username, isUser, isGroup, isChannel, unreadCount, message
      final int chatId = d.id as int? ?? 0;
      if (chatId == 0) return null;

      final String title = d.title as String? ?? d.name as String? ?? 'Чат $chatId';
      final String username = d.username as String? ?? '';
      final bool isBot = d.bot as bool? ?? false;
      final bool isGroup = d.isGroup as bool? ?? d.isChat as bool? ?? false;
      final bool isChannel = d.isChannel as bool? ?? d.isBroadcast as bool? ?? false;
      final int unread = d.unreadCount as int? ?? 0;

      String kind = 'user';
      if (isBot) kind = 'bot';
      else if (isChannel) kind = 'channel';
      else if (isGroup) kind = 'group';

      String lastMsg = '';
      String lastSeen = '';
      try {
        final m = d.message;
        if (m != null) {
          lastMsg = m.message as String? ?? m.text as String? ?? '';
          final dateUnix = m.date as int? ?? 0;
          if (dateUnix > 0) {
            lastSeen = DateTime.fromMillisecondsSinceEpoch(dateUnix * 1000).toIso8601String();
          }
        }
      } catch (_) {}

      return TgDialog(
        chatId: chatId,
        title: title.isNotEmpty ? title : 'Чат $chatId',
        username: username,
        kind: kind,
        lastMessage: lastMsg,
        lastSeen: lastSeen,
        unreadCount: unread,
      );
    } catch (e) {
      return null;
    }
  }

  // ─── Load cached dialogs ──────────────────────────────────────────────────

  Future<void> _loadCachedDialogs() async {
    try {
      final db = await SqliteCache.open();
      _dialogs = await db.loadChats();
      if (_dialogs.isNotEmpty) {
        _chatStreamCtrl.add(_dialogs);
        notifyListeners();
      }
    } catch (e) {
      print('[TgService] cache load error: $e');
    }
  }

  void _updateDialogLastMsg(TgMessage msg) {
    final idx = _dialogs.indexWhere((d) => d.chatId == msg.chatId);
    if (idx >= 0) {
      final old = _dialogs[idx];
      _dialogs[idx] = TgDialog(
        chatId: old.chatId,
        title: old.title,
        username: old.username,
        kind: old.kind,
        lastMessage: msg.text,
        lastSeen: msg.date,
        unreadCount: old.unreadCount + (msg.out ? 0 : 1),
      );
      _dialogs.sort((a, b) => b.lastSeen.compareTo(a.lastSeen));
    }
  }

  // ─── Parse raw message object ─────────────────────────────────────────────

  TgMessage? _parseMsgDynamic(dynamic msg) {
    if (msg == null) return null;
    try {
      final int msgId = msg.id as int? ?? 0;
      if (msgId == 0) return null;

      // Determine chatId from peer
      int chatId = 0;
      final peer = msg.peerId ?? msg.toId ?? msg.peer;
      if (peer != null) {
        final pType = peer.runtimeType.toString().toLowerCase();
        if (pType.contains('peeruser') || pType.contains('user')) {
          chatId = peer.userId as int? ?? 0;
        } else if (pType.contains('peerchat') || pType.contains('chat')) {
          chatId = peer.chatId as int? ?? 0;
        } else if (pType.contains('peerchannel') || pType.contains('channel')) {
          final rawId = peer.channelId as int? ?? 0;
          chatId = rawId > 0 ? -1000000000000 - rawId : 0;
        }
      }
      if (chatId == 0) return null;

      final text = msg.message as String? ?? msg.text as String? ?? '';
      final isOut = msg.out == true;
      final dateUnix = msg.date as int? ?? 0;
      final dt = dateUnix > 0
          ? DateTime.fromMillisecondsSinceEpoch(dateUnix * 1000).toLocal()
          : DateTime.now().toLocal();
      final dateIso = dt.toIso8601String();
      final dayKey =
          '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';
      final dayLabel = _formatDayLabel(dt);

      String sender = '';
      try {
        final from = msg.fromId ?? msg.sender;
        if (from != null) {
          final ft = from.runtimeType.toString().toLowerCase();
          if (ft.contains('user')) {
            sender = 'User ${from.userId ?? from.id ?? ''}';
          }
        }
      } catch (_) {}

      String mediaHtml = '';
      try {
        final media = msg.media;
        if (media != null) mediaHtml = _mediaHtml(media);
      } catch (_) {}

      return TgMessage(
        msgId: msgId,
        chatId: chatId,
        text: text,
        out: isOut,
        sender: sender,
        senderUsername: '',
        mediaHtml: mediaHtml,
        dayKey: dayKey,
        dayLabel: dayLabel,
        date: dateIso,
      );
    } catch (e) {
      print('[TgService] parseMsgDynamic error: $e');
      return null;
    }
  }

  String _mediaHtml(dynamic media) {
    final t = media.runtimeType.toString().toLowerCase();
    if (t.contains('photo')) return '<img class="msg-photo" />';
    if (t.contains('document')) {
      try {
        for (final attr in media.document?.attributes ?? []) {
          final at = attr.runtimeType.toString().toLowerCase();
          if (at.contains('video')) return '<video class="msg-video" />';
          if (at.contains('audio')) return '<audio class="msg-voice" />';
          if (at.contains('sticker')) return '<img class="msg-sticker" />';
        }
      } catch (_) {}
      return '<div class="msg-document">📄 Файл</div>';
    }
    return '';
  }

  String _formatDayLabel(DateTime dt) {
    final now = DateTime.now();
    if (dt.day == now.day && dt.month == now.month && dt.year == now.year) {
      return 'Сегодня';
    }
    final yesterday = now.subtract(const Duration(days: 1));
    if (dt.day == yesterday.day && dt.month == yesterday.month && dt.year == yesterday.year) {
      return 'Вчера';
    }
    const months = ['', 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
      'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
    return '${dt.day} ${months[dt.month]} ${dt.year}';
  }

  // ─── Public API ───────────────────────────────────────────────────────────

  Future<List<TgMessage>> getHistory(int chatId, {int limit = 50}) async {
    final db = await SqliteCache.open();
    if (_client == null || _authState != TgAuthState.ready) {
      return db.loadMessages(chatId, limit: limit);
    }
    try {
      // teleflutter high-level getMessages / getHistory
      final msgs = await _client!.getMessages(chatId, limit: limit);
      if (msgs == null || msgs.isEmpty) {
        return db.loadMessages(chatId, limit: limit);
      }
      final tgMsgs = <TgMessage>[];
      for (final m in msgs) {
        final tgM = _parseMsgDynamic(m);
        if (tgM != null) {
          tgMsgs.add(tgM);
          await db.saveMessage(tgM);
        }
      }
      return tgMsgs.reversed.toList();
    } catch (e) {
      print('[TgService] getHistory error: $e');
      return db.loadMessages(chatId, limit: limit);
    }
  }

  Future<void> sendMessage(int chatId, String text, {int? replyToMsgId}) async {
    if (_client == null) throw Exception('Not connected');
    // teleflutter high-level sendMessage(peer, text)
    await _client!.sendMessage(chatId, text);
  }

  Future<void> editMessage(int chatId, int msgId, String text) async {
    if (_client == null) throw Exception('Not connected');
    await _client!.editMessage(chatId, msgId, text);
  }

  Future<void> deleteMessage(int chatId, int msgId) async {
    if (_client == null) throw Exception('Not connected');
    await _client!.deleteMessages(chatId, [msgId], revoke: true);
  }

  // ─── Auth flow ────────────────────────────────────────────────────────────

  Future<void> setPhoneNumber(String phone) async {
    _pendingPhone = phone;
    if (_client == null) {
      _client = TelegramClient(StringSession(''), _apiId, _apiHash);
      await _client!.connect();
    }
    final result = await _client!.sendCode(phone);
    _pendingPhoneCodeHash = result?.phoneCodeHash as String? ?? '';
    _setState(TgAuthState.waitingCode, 'Введите код из SMS');
  }

  Future<void> setCode(String code) async {
    if (_client == null) throw Exception('Not connected');
    await _client!.signIn(
      phoneNumber: _pendingPhone,
      phoneCodeHash: _pendingPhoneCodeHash,
      phoneCode: code,
    );
    final ok = await _checkAuth();
    if (ok) {
      await _onReady();
    } else {
      _setState(TgAuthState.waitingPassword, 'Введите пароль 2FA');
    }
  }

  Future<void> setPassword(String password) async {
    if (_client == null) throw Exception('Not connected');
    await _client!.checkPassword(password);
    final ok = await _checkAuth();
    if (ok) await _onReady();
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  void _setState(TgAuthState state, String message) {
    _authState = state;
    _statusMessage = message;
    notifyListeners();
  }

  @override
  void dispose() {
    _chatStreamCtrl.close();
    _newMsgCtrl.close();
    try { _client?.disconnect(); } catch (_) {}
    super.dispose();
  }
}
