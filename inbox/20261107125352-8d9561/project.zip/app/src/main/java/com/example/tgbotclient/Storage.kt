package com.example.tgbotclient

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

data class Chat(
    val id: Long,
    val title: String,
    val type: String,
    val lastMessage: String,
    val lastTime: Long
)

data class TgMessage(
    val id: Long,
    val chatId: Long,
    val fromName: String,
    val text: String,
    val time: Long,
    val isBot: Boolean,
    val replyTo: Long? = null,
    val mediaType: String? = null
)

class Storage(context: Context) : SQLiteOpenHelper(context, "tgbot.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE chats (
                id INTEGER PRIMARY KEY,
                title TEXT,
                type TEXT,
                last_message TEXT,
                last_time INTEGER
            )
        """)
        db.execSQL("""
            CREATE TABLE messages (
                id INTEGER PRIMARY KEY,
                chat_id INTEGER,
                from_name TEXT,
                text TEXT,
                time INTEGER,
                is_bot INTEGER,
                reply_to INTEGER,
                media_type TEXT
            )
        """)
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {}

    fun saveMessage(msg: TgMessage) {
        val cv = ContentValues().apply {
            put("id", msg.id)
            put("chat_id", msg.chatId)
            put("from_name", msg.fromName)
            put("text", msg.text)
            put("time", msg.time)
            put("is_bot", if (msg.isBot) 1 else 0)
            put("reply_to", msg.replyTo)
            put("media_type", msg.mediaType)
        }
        writableDatabase.insertWithOnConflict("messages", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

        val chatTitle = msg.fromName
        val chatCv = ContentValues().apply {
            put("id", msg.chatId)
            put("title", chatTitle)
            put("type", "private")
            put("last_message", msg.text.take(100))
            put("last_time", msg.time)
        }
        writableDatabase.insertWithOnConflict("chats", null, chatCv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun getChats(): List<Chat> {
        val list = mutableListOf<Chat>()
        val c = readableDatabase.query("chats", null, null, null, null, null, "last_time DESC")
        c.use {
            while (it.moveToNext()) {
                list.add(Chat(
                    it.getLong(0),
                    it.getString(1) ?: "",
                    it.getString(2) ?: "",
                    it.getString(3) ?: "",
                    it.getLong(4)
                ))
            }
        }
        return list
    }

    fun getMessages(chatId: Long): List<TgMessage> {
        val list = mutableListOf<TgMessage>()
        val c = readableDatabase.query(
            "messages", null, "chat_id=?", arrayOf(chatId.toString()),
            null, null, "time ASC", "200"
        )
        c.use {
            while (it.moveToNext()) {
                list.add(TgMessage(
                    it.getLong(0),
                    it.getLong(1),
                    it.getString(2) ?: "",
                    it.getString(3) ?: "",
                    it.getLong(4),
                    it.getInt(5) == 1,
                    if (it.isNull(6)) null else it.getLong(6),
                    it.getString(7)
                ))
            }
        }
        return list
    }

    fun clearAll() {
        writableDatabase.delete("messages", null, null)
        writableDatabase.delete("chats", null, null)
    }
}
