package com.example.tgbotclient

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object MessageBus {
    var onNewMessage: ((TgMessage) -> Unit)? = null
}

class BotPollingService : Service() {

    private var job: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(40, TimeUnit.SECONDS)
        .build()
    private lateinit var storage: Storage

    override fun onCreate() {
        super.onCreate()
        storage = Storage(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.getStringExtra("action")) {
            "stop" -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForegroundService()
                startPolling()
            }
        }
        return START_STICKY
    }

    private fun startForegroundService() {
        val channelId = "bot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Bot Messages", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("TG Bot Client Pro")
            .setContentText("Long-polling активен")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()

        startForeground(1, notification)

        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tgbot:polling")
        wakeLock?.acquire(60 * 60 * 1000L)
    }

    private fun startPolling() {
        job?.cancel()
        job = scope.launch {
            val prefs = getSharedPreferences("bot", Context.MODE_PRIVATE)
            val token = prefs.getString("token", "") ?: return@launch
            var offset = prefs.getLong("offset", 0L)

            // Validate token
            try {
                val me = getMe(token)
                if (me != null) {
                    prefs.edit().putString("bot_name", me.optString("first_name")).apply()
                }
            } catch (_: Exception) {}

            while (isActive) {
                try {
                    val url = "https://api.telegram.org/bot$token/getUpdates?offset=$offset&timeout=25&allowed_updates=[\"message\",\"edited_message\",\"callback_query\"]"
                    val req = Request.Builder().url(url).build()
                    val resp = client.newCall(req).execute()
                    val body = resp.body?.string() ?: continue
                    val json = JSONObject(body)

                    if (json.optBoolean("ok")) {
                        val results = json.getJSONArray("result")
                        for (i in 0 until results.length()) {
                            val update = results.getJSONObject(i)
                            offset = update.getLong("update_id") + 1
                            prefs.edit().putLong("offset", offset).apply()

                            handleUpdate(update, token)
                        }
                    }
                } catch (e: Exception) {
                    delay(4000)
                }
            }
        }
    }

    private fun handleUpdate(update: JSONObject, token: String) {
        // Message / edited
        val message = update.optJSONObject("message")
            ?: update.optJSONObject("edited_message")

        if (message != null) {
            val chat = message.getJSONObject("chat")
            val chatId = chat.getLong("id")
            val from = message.optJSONObject("from")
            val fromName = from?.optString("first_name") ?: chat.optString("title") ?: "Unknown"
            val text = when {
                message.has("text") -> message.getString("text")
                message.has("caption") -> message.optString("caption") + " " + mediaLabel(message)
                message.has("photo") -> "[Фото]"
                message.has("document") -> "[Документ: ${message.getJSONObject("document").optString("file_name")}]"
                message.has("voice") -> "[Голосовое]"
                message.has("video") -> "[Видео]"
                message.has("sticker") -> "[Стикер]"
                message.has("location") -> "[Геолокация]"
                message.has("contact") -> "[Контакт]"
                else -> "[Сообщение]"
            }
            val msgId = message.getLong("message_id")
            val time = message.getLong("date") * 1000
            val replyTo = message.optJSONObject("reply_to_message")?.getLong("message_id")

            val tgMsg = TgMessage(msgId, chatId, fromName, text, time, false, replyTo)
            storage.saveMessage(tgMsg)
            MessageBus.onNewMessage?.invoke(tgMsg)
            showNotification(fromName, text, chatId)
            return
        }

        // Callback query
        val cb = update.optJSONObject("callback_query")
        if (cb != null) {
            val data = cb.optString("data")
            val from = cb.optJSONObject("from")?.optString("first_name") ?: "?"
            val msg = cb.optJSONObject("message")
            if (msg != null) {
                val chatId = msg.getJSONObject("chat").getLong("id")
                val text = "[Кнопка] $from нажал: $data"
                val tgMsg = TgMessage(System.currentTimeMillis(), chatId, from, text, System.currentTimeMillis(), false)
                storage.saveMessage(tgMsg)
                MessageBus.onNewMessage?.invoke(tgMsg)
                showNotification(from, text, chatId)
            }
            // Answer callback to remove loading
            try {
                val answer = Request.Builder()
                    .url("https://api.telegram.org/bot$token/answerCallbackQuery?callback_query_id=${cb.getString("id")}")
                    .build()
                client.newCall(answer).execute().close()
            } catch (_: Exception) {}
        }
    }

    private fun mediaLabel(message: JSONObject): String = when {
        message.has("photo") -> "[Фото]"
        message.has("document") -> "[Документ]"
        message.has("video") -> "[Видео]"
        else -> ""
    }

    private fun showNotification(from: String, text: String, chatId: Long) {
        val channelId = "bot_channel"
        val openIntent = PendingIntent.getActivity(
            this, chatId.toInt(), Intent(this, MainActivity::class.java).apply {
                putExtra("open_chat", chatId)
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setContentTitle(from)
            .setContentText(text.take(120))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(openIntent)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify((chatId % 100000).toInt(), n)
    }

    private fun getMe(token: String): JSONObject? {
        val req = Request.Builder().url("https://api.telegram.org/bot$token/getMe").build()
        val resp = client.newCall(req).execute()
        val body = resp.body?.string() ?: return null
        val json = JSONObject(body)
        return if (json.optBoolean("ok")) json.getJSONObject("result") else null
    }

    override fun onDestroy() {
        job?.cancel()
        wakeLock?.release()
        scope.cancel()
        super.onDestroy()
    }
}
