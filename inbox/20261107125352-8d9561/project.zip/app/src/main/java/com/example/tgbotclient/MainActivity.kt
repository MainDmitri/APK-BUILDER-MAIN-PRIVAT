package com.example.tgbotclient

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private val requestNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { pendingFileUri = it }
    }
    var pendingFileUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotif.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    val openChat = intent?.getLongExtra("open_chat", -1L) ?: -1L
                    AppRoot(initialChat = if (openChat > 0) openChat else null)
                }
            }
        }
    }
}

@Composable
fun AppRoot(initialChat: Long? = null) {
    val context = LocalContext.current
    var screen by remember { mutableStateOf(if (initialChat != null) "chat" else "chats") }
    var selectedChat by remember { mutableStateOf(initialChat) }
    var refresh by remember { mutableStateOf(0) }

    LaunchedEffect(Unit) {
        MessageBus.onNewMessage = { refresh++ }
    }

    when (screen) {
        "settings" -> SettingsScreen(
            onBack = { screen = "chats" },
            onStart = { screen = "chats" }
        )
        "chat" -> selectedChat?.let { id ->
            ChatScreen(chatId = id, onBack = { screen = "chats" }, refresh = refresh)
        }
        else -> ChatsScreen(
            refresh = refresh,
            onOpenChat = { id ->
                selectedChat = id
                screen = "chat"
            },
            onSettings = { screen = "settings" }
        )
    }
}

@Composable
fun ChatsScreen(refresh: Int, onOpenChat: (Long) -> Unit, onSettings: () -> Unit) {
    val context = LocalContext.current
    val storage = remember { Storage(context) }
    var chats by remember { mutableStateOf(storage.getChats()) }
    val botName = remember { context.getSharedPreferences("bot", Context.MODE_PRIVATE).getString("bot_name", "Бот") }

    LaunchedEffect(refresh) { chats = storage.getChats() }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("TG Bot Client Pro", style = MaterialTheme.typography.headlineSmall)
                Text("Бот: $botName", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onSettings) { Text("Настройки") }
        }

        if (chats.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Нет чатов. Запустите бота в настройках и напишите ему.")
            }
        } else {
            LazyColumn {
                items(chats) { chat ->
                    Card(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                            .clickable { onOpenChat(chat.id) }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(chat.title, style = MaterialTheme.typography.titleMedium)
                            Text(chat.lastMessage, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                SimpleDateFormat("HH:mm dd.MM", Locale.getDefault()).format(Date(chat.lastTime)),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(chatId: Long, onBack: () -> Unit, refresh: Int) {
    val context = LocalContext.current
    val storage = remember { Storage(context) }
    var messages by remember { mutableStateOf(storage.getMessages(chatId)) }
    var text by remember { mutableStateOf("") }
    var replyTo by remember { mutableStateOf<TgMessage?>(null) }
    val scope = rememberCoroutineScope()
    val token = context.getSharedPreferences("bot", Context.MODE_PRIVATE).getString("token", "") ?: ""

    LaunchedEffect(refresh) { messages = storage.getMessages(chatId) }

    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(8.dp))
            Text("Чат $chatId", style = MaterialTheme.typography.titleLarge)
        }

        LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp)) {
            items(messages) { msg ->
                val align = if (msg.isBot) Alignment.End else Alignment.Start
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 2.dp).clickable { replyTo = msg },
                    horizontalAlignment = align
                ) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (msg.isBot) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(Modifier.padding(8.dp)) {
                            if (msg.replyTo != null) Text("↩ reply", style = MaterialTheme.typography.labelSmall)
                            Text(msg.fromName, style = MaterialTheme.typography.labelSmall)
                            Text(msg.text)
                            Text(
                                SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.time)),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }

        if (replyTo != null) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Ответ на: ${replyTo!!.text.take(40)}", Modifier.weight(1f))
                TextButton(onClick = { replyTo = null }) { Text("✕") }
            }
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Сообщение") }
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (text.isNotBlank() && token.isNotBlank()) {
                    scope.launch {
                        sendText(token, chatId, text, replyTo?.id)
                        val botMsg = TgMessage(
                            System.currentTimeMillis(), chatId, "Бот", text,
                            System.currentTimeMillis(), true, replyTo?.id
                        )
                        storage.saveMessage(botMsg)
                        messages = storage.getMessages(chatId)
                        text = ""
                        replyTo = null
                    }
                }
            }) { Text("→") }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onStart: () -> Unit) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("bot", Context.MODE_PRIVATE)
    var token by remember { mutableStateOf(prefs.getString("token", "") ?: "") }
    var status by remember { mutableStateOf("Остановлен") }
    var botInfo by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack) { Text("←") }
            Spacer(Modifier.width(8.dp))
            Text("Настройки", style = MaterialTheme.typography.headlineSmall)
        }
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("Bot Token") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                prefs.edit().putString("token", token).apply()
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, BotPollingService::class.java).apply { putExtra("action", "start") }
                )
                status = "Запущен"
                onStart()
            }) { Text("Старт") }

            Button(onClick = {
                context.startService(Intent(context, BotPollingService::class.java).apply {
                    putExtra("action", "stop")
                })
                status = "Остановлен"
            }) { Text("Стоп") }
        }

        Spacer(Modifier.height(8.dp))
        Text("Статус: $status")
        if (botInfo.isNotBlank()) Text(botInfo)

        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            Storage(context).clearAll()
            botInfo = "История очищена"
        }) { Text("Очистить историю") }

        Spacer(Modifier.height(8.dp))
        Text(
            "Функции:\n• Long-polling в фоне\n• Сохранение чатов и сообщений\n• Уведомления\n• Отправка текста\n• Reply\n• getMe\n• Обработка фото/документов/стикеров\n• Callback queries (отображение)",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

suspend fun sendText(token: String, chatId: Long, text: String, replyTo: Long?) {
    withContext(Dispatchers.IO) {
        val client = OkHttpClient()
        val body = JSONObject().apply {
            put("chat_id", chatId)
            put("text", text)
            if (replyTo != null) put("reply_to_message_id", replyTo)
        }
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$token/sendMessage")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().close()
    }
}
