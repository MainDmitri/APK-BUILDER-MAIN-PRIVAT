package com.maindmitri.wikkeoposter.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class ProductDbHelper(private val appContext: Context) :
    SQLiteOpenHelper(appContext, "wikkeo_products.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE products (
                id TEXT PRIMARY KEY,
                url TEXT UNIQUE NOT NULL,
                title TEXT NOT NULL,
                raw_description TEXT NOT NULL DEFAULT '',
                specs_json TEXT NOT NULL DEFAULT '{}',
                wholesale_price REAL,
                final_price INTEGER,
                min_order TEXT NOT NULL DEFAULT '',
                seller TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL DEFAULT '',
                image_urls_json TEXT NOT NULL DEFAULT '[]',
                local_images_json TEXT NOT NULL DEFAULT '[]',
                generated_post TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'draft',
                telegram_message_id INTEGER,
                last_error TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                published_at INTEGER
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_products_created ON products(created_at DESC)")
        db.execSQL("CREATE INDEX idx_products_status ON products(status)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Initial version
    }

    fun productFolder(productId: String): File {
        val safe = productId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val dir = File(appContext.filesDir, "products/$safe")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun existsByUrl(url: String): Boolean {
        val clean = cleanUrl(url)
        readableDatabase.rawQuery(
            "SELECT 1 FROM products WHERE url = ? LIMIT 1",
            arrayOf(clean)
        ).use { cursor ->
            return cursor.moveToFirst()
        }
    }

    fun upsert(product: Product) {
        val values = ContentValues().apply {
            put("id", product.id)
            put("url", cleanUrl(product.url))
            put("title", product.title)
            put("raw_description", product.rawDescription)
            val specsObj = JSONObject()
            product.specs.forEach { (k, v) -> specsObj.put(k, v) }
            put("specs_json", specsObj.toString())
            if (product.wholesalePrice != null) put("wholesale_price", product.wholesalePrice) else putNull("wholesale_price")
            if (product.finalPrice != null) put("final_price", product.finalPrice) else putNull("final_price")
            put("min_order", product.minOrder)
            put("seller", product.seller)
            put("category", product.category)
            put("image_urls_json", JSONArray(product.imageUrls).toString())
            put("local_images_json", JSONArray(product.localImages).toString())
            put("generated_post", product.generatedPost)
            put("status", product.status.code)
            if (product.telegramMessageId != null) put("telegram_message_id", product.telegramMessageId) else putNull("telegram_message_id")
            put("last_error", product.lastError)
            put("created_at", product.createdAt)
            if (product.publishedAt != null) put("published_at", product.publishedAt) else putNull("published_at")
        }
        writableDatabase.insertWithOnConflict(
            "products",
            null,
            values,
            SQLiteDatabase.CONFLICT_REPLACE
        )
        runCatching {
            val metaFile = File(productFolder(product.id), "product.json")
            metaFile.writeText(product.toJson(), Charsets.UTF_8)
        }
    }

    fun getAll(): List<Product> {
        val list = mutableListOf<Product>()
        readableDatabase.rawQuery(
            "SELECT * FROM products ORDER BY created_at DESC",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                list.add(cursorToProduct(cursor))
            }
        }
        return list
    }

    fun getById(id: String): Product? {
        readableDatabase.rawQuery(
            "SELECT * FROM products WHERE id = ? LIMIT 1",
            arrayOf(id)
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursorToProduct(cursor) else null
        }
    }

    fun delete(productId: String) {
        writableDatabase.delete("products", "id = ?", arrayOf(productId))
        runCatching {
            productFolder(productId).deleteRecursively()
        }
    }

    private fun cursorToProduct(c: Cursor): Product {
        val specsMap = linkedMapOf<String, String>()
        runCatching {
            val obj = JSONObject(c.getString(c.getColumnIndexOrThrow("specs_json")))
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                specsMap[k] = obj.optString(k, "")
            }
        }
        val imageUrls = jsonArrayToList(c.getString(c.getColumnIndexOrThrow("image_urls_json")))
        val localImages = jsonArrayToList(c.getString(c.getColumnIndexOrThrow("local_images_json")))
            .filter { File(it).exists() }

        val wIdx = c.getColumnIndexOrThrow("wholesale_price")
        val fIdx = c.getColumnIndexOrThrow("final_price")
        val msgIdx = c.getColumnIndexOrThrow("telegram_message_id")
        val pubIdx = c.getColumnIndexOrThrow("published_at")

        return Product(
            id = c.getString(c.getColumnIndexOrThrow("id")),
            url = c.getString(c.getColumnIndexOrThrow("url")),
            title = c.getString(c.getColumnIndexOrThrow("title")),
            rawDescription = c.getString(c.getColumnIndexOrThrow("raw_description")),
            specs = specsMap,
            wholesalePrice = if (c.isNull(wIdx)) null else c.getDouble(wIdx),
            finalPrice = if (c.isNull(fIdx)) null else c.getInt(fIdx),
            minOrder = c.getString(c.getColumnIndexOrThrow("min_order")),
            seller = c.getString(c.getColumnIndexOrThrow("seller")),
            category = c.getString(c.getColumnIndexOrThrow("category")),
            imageUrls = imageUrls,
            localImages = localImages,
            generatedPost = c.getString(c.getColumnIndexOrThrow("generated_post")),
            status = ProductStatus.fromCode(c.getString(c.getColumnIndexOrThrow("status"))),
            telegramMessageId = if (c.isNull(msgIdx)) null else c.getLong(msgIdx),
            lastError = c.getString(c.getColumnIndexOrThrow("last_error")),
            createdAt = c.getLong(c.getColumnIndexOrThrow("created_at")),
            publishedAt = if (c.isNull(pubIdx)) null else c.getLong(pubIdx)
        )
    }

    private fun jsonArrayToList(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        val result = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val item = arr.optString(i, "")
                if (item.isNotBlank()) result.add(item)
            }
        }
        return result
    }

    companion object {
        fun cleanUrl(url: String): String =
            url.substringBefore("#").substringBefore("?").trim()
    }
}
