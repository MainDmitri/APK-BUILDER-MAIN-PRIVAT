package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

data class TelegramResult(
    val success: Boolean,
    val messageId: Long? = null,
    val error: String = ""
)

data class ChannelPostPreview(
    val messageId: Long,
    val text: String,
    val postUrl: String
)

object TelegramClient {

    suspend fun testConnection(botToken: String, channelId: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            val token = botToken.trim()
            val chat = channelId.trim()
            if (token.isBlank()) return@withContext false to "Укажи Bot Token от @BotFather"
            if (chat.isBlank()) return@withContext false to "Укажи @username или ID канала"

            val meResp = getJson("https://api.telegram.org/bot$token/getMe")
            if (!meResp.first) return@withContext false to "Неверный токен бота: ${meResp.second}"
            val botUser = runCatching {
                JSONObject(meResp.second).getJSONObject("result").optString("username", "bot")
            }.getOrDefault("bot")

            val encodedChat = URLEncoder.encode(chat, "UTF-8")
            val chatResp = getJson("https://api.telegram.org/bot$token/getChat?chat_id=$encodedChat")
            if (!chatResp.first) {
                return@withContext false to "Бот @$botUser найден, но канал недоступен: ${chatResp.second}. Добавь бота админом в канал."
            }
            val chatTitle = runCatching {
                JSONObject(chatResp.second).getJSONObject("result").optString("title", chat)
            }.getOrDefault(chat)

            true to "Готово! Бот @$botUser подключён к каналу «$chatTitle»."
        }

    fun buildPostUrl(channelId: String, messageId: Long?): String? {
        if (messageId == null || messageId <= 0) return null
        val username = extractChannelUsername(channelId) ?: return null
        return "https://t.me/$username/$messageId"
    }

    fun extractChannelUsername(channelId: String): String? {
        val raw = channelId.trim()
        return when {
            raw.startsWith("@") -> raw.removePrefix("@").trim().takeIf { it.isNotBlank() }
            raw.contains("t.me/", ignoreCase = true) ->
                raw.substringAfter("t.me/").substringBefore("/").substringBefore("?").takeIf { it.isNotBlank() && !it.startsWith("+") }
            else -> null
        }
    }

    /**
     * Reads recent posts from a public Telegram channel via https://t.me/s/<username>
     * so the owner can inspect what products are already live in the channel.
     */
    suspend fun fetchRecentPublicChannelPosts(channelId: String): Pair<List<ChannelPostPreview>, String> =
        withContext(Dispatchers.IO) {
            val username = extractChannelUsername(channelId)
                ?: return@withContext emptyList<ChannelPostPreview>() to
                    "Для онлайн-проверки канала укажи его публичный @username в Настройках (приватные -100... проверяются по локальной базе)."

            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://t.me/s/$username")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 12_000
                    readTimeout = 20_000
                    setRequestProperty(
                        "User-Agent",
                        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"
                    )
                }
                if (conn.responseCode !in 200..299) {
                    return@withContext emptyList<ChannelPostPreview>() to "Не удалось открыть t.me/s/$username (HTTP ${conn.responseCode})"
                }
                val html = conn.inputStream.bufferedReader(Charsets.UTF_8).readText()
                val posts = mutableListOf<ChannelPostPreview>()
                val blocks = html.split("data-post=\"$username/")
                for (i in 1 until blocks.size) {
                    val block = blocks[i]
                    val msgId = block.substringBefore("\"").toLongOrNull() ?: continue
                    val textMatch = Regex(
                        "<div class=\"tgme_widget_message_text[^\"]*\"[^>]*>(.*?)</div>",
                        setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
                    ).find(block)
                    val rawHtml = textMatch?.groupValues?.get(1).orEmpty()
                    val plain = rawHtml
                        .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
                        .replace(Regex("<[^>]+>"), "")
                        .replace("&nbsp;", " ")
                        .replace("&amp;", "&")
                        .replace("&lt;", "<")
                        .replace("&gt;", ">")
                        .replace("&quot;", "\"")
                        .replace("&#39;", "'")
                        .trim()
                    if (plain.isNotBlank()) {
                        posts.add(
                            ChannelPostPreview(
                                messageId = msgId,
                                text = plain,
                                postUrl = "https://t.me/$username/$msgId"
                            )
                        )
                    }
                }
                val sorted = posts.distinctBy { it.messageId }.sortedByDescending { it.messageId }
                sorted to "Загружено последних постов из @$username: ${sorted.size}"
            } catch (e: Exception) {
                emptyList<ChannelPostPreview>() to "Ошибка загрузки канала: ${e.message ?: "неизвестно"}"
            } finally {
                conn?.disconnect()
            }
        }

    private fun buildBuyReplyMarkupJson(settings: AppSettings): String? {
        val url = settings.resolveBuyUrl() ?: return null
        val btnText = settings.buyButtonText.trim().ifEmpty { "🛒 Купить" }
        val button = JSONObject()
            .put("text", btnText)
            .put("url", url)
        val row = JSONArray().put(button)
        val keyboard = JSONArray().put(row)
        return JSONObject().put("inline_keyboard", keyboard).toString()
    }

    suspend fun publishProduct(product: Product, settings: AppSettings): TelegramResult =
        withContext(Dispatchers.IO) {
            val token = settings.telegramBotToken.trim()
            val chatId = settings.telegramChannelId.trim()
            if (token.isBlank() || chatId.isBlank()) {
                return@withContext TelegramResult(
                    success = false,
                    error = "Заполни Bot Token и ID канала в Настройках"
                )
            }

            // Guarantee no wikkeo.com links ever appear in the Telegram post
            val captionRaw = product.generatedPost.ifBlank {
                AiClient.assembleTelegramPost(
                    AiClient.buildFallbackBody(product),
                    product,
                    settings
                )
            }
            val caption = captionRaw
                .lines()
                .filterNot { it.contains("wikkeo.com", ignoreCase = true) }
                .joinToString("\n")
                .trim()

            val replyMarkup = buildBuyReplyMarkupJson(settings)
            val maxAllowed = if (settings.singlePhotoWithButton) 1 else settings.maxPhotosPerPost.coerceIn(1, 10)
            val photos = product.localImages
                .map { File(it) }
                .filter { it.exists() && it.length() > 0 }
                .take(maxAllowed)

            return@withContext when (photos.size) {
                0 -> sendTextMessage(token, chatId, caption, replyMarkup)
                1 -> sendSinglePhoto(token, chatId, photos.first(), caption, replyMarkup)
                else -> {
                    val albumRes = sendMediaGroup(token, chatId, photos, caption)
                    if (albumRes.success && replyMarkup != null) {
                        val priceStr = AiClient.formatRub(product.finalPrice ?: product.wholesalePrice)
                        val ctaText = "🛍 <b>${AiClient.escapeHtml(product.title)}</b> — <b>$priceStr</b>"
                        sendTextMessage(token, chatId, ctaText, replyMarkup)
                    }
                    albumRes
                }
            }
        }

    private fun sendTextMessage(
        token: String,
        chatId: String,
        htmlText: String,
        replyMarkupJson: String? = null
    ): TelegramResult {
        val fields = linkedMapOf(
            "chat_id" to chatId,
            "text" to htmlText,
            "parse_mode" to "HTML",
            "disable_web_page_preview" to "true"
        )
        if (!replyMarkupJson.isNullOrBlank()) {
            fields["reply_markup"] = replyMarkupJson
        }
        return postMultipart(
            urlStr = "https://api.telegram.org/bot$token/sendMessage",
            fields = fields,
            files = emptyMap()
        )
    }

    private fun sendSinglePhoto(
        token: String,
        chatId: String,
        photo: File,
        caption: String,
        replyMarkupJson: String? = null
    ): TelegramResult {
        val fields = linkedMapOf(
            "chat_id" to chatId,
            "caption" to caption.take(1024),
            "parse_mode" to "HTML"
        )
        if (!replyMarkupJson.isNullOrBlank()) {
            fields["reply_markup"] = replyMarkupJson
        }
        return postMultipart(
            urlStr = "https://api.telegram.org/bot$token/sendPhoto",
            fields = fields,
            files = mapOf("photo" to photo)
        )
    }

    private fun sendMediaGroup(
        token: String,
        chatId: String,
        photos: List<File>,
        caption: String
    ): TelegramResult {
        val mediaArray = JSONArray()
        val filesMap = linkedMapOf<String, File>()

        photos.forEachIndexed { idx, file ->
            val attachName = "photo$idx"
            filesMap[attachName] = file
            val item = JSONObject().apply {
                put("type", "photo")
                put("media", "attach://$attachName")
                if (idx == 0) {
                    put("caption", caption.take(1024))
                    put("parse_mode", "HTML")
                }
            }
            mediaArray.put(item)
        }

        val fields = linkedMapOf(
            "chat_id" to chatId,
            "media" to mediaArray.toString()
        )
        return postMultipart(
            urlStr = "https://api.telegram.org/bot$token/sendMediaGroup",
            fields = fields,
            files = filesMap
        )
    }

    private fun getJson(urlStr: String): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12_000
                readTimeout = 15_000
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()
            if (code in 200..299) {
                true to body
            } else {
                val desc = runCatching { JSONObject(body).optString("description") }.getOrNull()
                false to (desc?.ifBlank { null } ?: "HTTP $code")
            }
        } catch (e: Exception) {
            false to (e.message ?: "Сетевая ошибка")
        } finally {
            conn?.disconnect()
        }
    }

    private fun postMultipart(
        urlStr: String,
        fields: Map<String, String>,
        files: Map<String, File>
    ): TelegramResult {
        val boundary = "----WikkeoBoundary${UUID.randomUUID().toString().replace("-", "")}"
        val crlf = "\r\n"
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            DataOutputStream(conn.outputStream).use { out ->
                fields.forEach { (name, value) ->
                    out.writeBytes("--$boundary$crlf")
                    out.writeBytes("Content-Disposition: form-data; name=\"$name\"$crlf")
                    out.writeBytes("Content-Type: text/plain; charset=UTF-8$crlf$crlf")
                    out.write(value.toByteArray(Charsets.UTF_8))
                    out.writeBytes(crlf)
                }
                files.forEach { (fieldName, file) ->
                    out.writeBytes("--$boundary$crlf")
                    out.writeBytes("Content-Disposition: form-data; name=\"$fieldName\"; filename=\"${file.name}\"$crlf")
                    out.writeBytes("Content-Type: image/jpeg$crlf$crlf")
                    file.inputStream().use { it.copyTo(out) }
                    out.writeBytes(crlf)
                }
                out.writeBytes("--$boundary--$crlf")
                out.flush()
            }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()

            if (code !in 200..299) {
                val desc = runCatching { JSONObject(body).optString("description") }.getOrNull()
                return TelegramResult(
                    success = false,
                    error = desc?.ifBlank { null } ?: "Telegram HTTP $code"
                )
            }

            val json = JSONObject(body)
            if (!json.optBoolean("ok", false)) {
                return TelegramResult(
                    success = false,
                    error = json.optString("description", "Неизвестная ошибка Telegram")
                )
            }
            val resultObj = json.opt("result")
            val msgId = when (resultObj) {
                is JSONObject -> resultObj.optLong("message_id").takeIf { it > 0 }
                is JSONArray -> if (resultObj.length() > 0) {
                    resultObj.getJSONObject(0).optLong("message_id").takeIf { it > 0 }
                } else null
                else -> null
            }
            TelegramResult(success = true, messageId = msgId)
        } catch (e: Exception) {
            TelegramResult(success = false, error = "Сетевая ошибка Telegram: ${e.message ?: "неизвестно"}")
        } finally {
            conn?.disconnect()
        }
    }
}
