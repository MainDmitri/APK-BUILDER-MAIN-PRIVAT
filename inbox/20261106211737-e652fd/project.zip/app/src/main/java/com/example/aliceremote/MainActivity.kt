package com.example.aliceremote

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.IOException
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private val bluetoothManager by lazy { getSystemService(BluetoothManager::class.java) }
    private val bluetoothAdapter: BluetoothAdapter? by lazy { bluetoothManager.adapter }

    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* UI reacts via hasPermissions */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AliceRemoteApp(
                activity = this,
                bluetoothAdapter = bluetoothAdapter,
                sppUuid = sppUuid,
                onRequestPermissions = {
                    requestPermissions.launch(
                        arrayOf(
                            Manifest.permission.BLUETOOTH_SCAN,
                            Manifest.permission.BLUETOOTH_CONNECT,
                            Manifest.permission.ACCESS_FINE_LOCATION
                        )
                    )
                },
                hasPermissions = {
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                }
            )
        }
    }
}

@Composable
fun AliceRemoteApp(
    activity: ComponentActivity,
    bluetoothAdapter: BluetoothAdapter?,
    sppUuid: UUID,
    onRequestPermissions: () -> Unit,
    hasPermissions: () -> Boolean
) {
    var devices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var connectedDevice by remember { mutableStateOf<BluetoothDevice?>(null) }
    var socket by remember { mutableStateOf<BluetoothSocket?>(null) }
    var status by remember { mutableStateOf("Готов к сканированию") }
    var commandText by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("") }
    var isDiscovering by remember { mutableStateOf(false) }

    val receiver = remember {
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        device?.let { d ->
                            if (devices.none { it.address == d.address }) {
                                devices = devices + d
                                status = "Найдено устройств: ${devices.size}"
                            }
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        isDiscovering = false
                        status = "Сканирование завершено. Устройств: ${devices.size}"
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        activity.registerReceiver(receiver, filter)
        onDispose {
            try { activity.unregisterReceiver(receiver) } catch (_: Exception) {}
            socket?.close()
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7B1FA2),
            secondary = Color(0xFFCE93D8),
            background = Color(0xFF1A1A2E),
            surface = Color(0xFF16213E)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Алиса Пульт Bluetooth",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFCE93D8)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(status, color = Color.White, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(16.dp))

                if (!hasPermissions()) {
                    Button(onClick = onRequestPermissions) {
                        Text("Запросить разрешения Bluetooth")
                    }
                } else if (bluetoothAdapter == null) {
                    Text("Bluetooth не поддерживается", color = Color.Red)
                } else {
                    Button(
                        onClick = {
                            if (!bluetoothAdapter.isEnabled) {
                                status = "Включите Bluetooth в системе"
                                return@Button
                            }
                            devices = emptyList()
                            isDiscovering = true
                            status = "Сканирование..."
                            bluetoothAdapter.startDiscovery()
                        },
                        enabled = !isDiscovering
                    ) {
                        Text(if (isDiscovering) "Сканирование..." else "Сканировать устройства")
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(modifier = Modifier.height(140.dp)) {
                        items(devices) { device ->
                            Button(
                                onClick = {
                                    status = "Подключение к ${device.name ?: device.address}..."
                                    thread {
                                        try {
                                            bluetoothAdapter.cancelDiscovery()
                                            val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                                            sock.connect()
                                            activity.runOnUiThread {
                                                socket = sock
                                                connectedDevice = device
                                                status = "Подключено к ${device.name ?: "Unknown"}"
                                                log += "Connected: ${device.name} (${device.address})\n"
                                            }
                                        } catch (e: IOException) {
                                            activity.runOnUiThread {
                                                status = "Ошибка: ${e.message}"
                                                log += "Connect fail: ${e.message}\n"
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().padding(2.dp)
                            ) {
                                Text("${device.name ?: "Unknown"} (${device.address})")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (connectedDevice != null) {
                        Text("Канал: ${connectedDevice?.name}", color = Color(0xFF81C784))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            RemoteButton("⏮", "prev") { sendCmd(socket, "prev", log) { log = it } }
                            RemoteButton("⏯", "playpause") { sendCmd(socket, "playpause", log) { log = it } }
                            RemoteButton("⏭", "next") { sendCmd(socket, "next", log) { log = it } }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            RemoteButton("Vol+", "volup") { sendCmd(socket, "volup", log) { log = it } }
                            RemoteButton("Vol-", "voldown") { sendCmd(socket, "voldown", log) { log = it } }
                            RemoteButton("Mute", "mute") { sendCmd(socket, "mute", log) { log = it } }
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = commandText,
                            onValueChange = { commandText = it },
                            label = { Text("Команда для Алисы") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = {
                            if (commandText.isNotBlank()) {
                                sendCmd(socket, "alice:$commandText", log) { log = it }
                                commandText = ""
                            }
                        }) {
                            Text("Отправить команду")
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                thread {
                                    try { socket?.close() } catch (_: Exception) {}
                                    activity.runOnUiThread {
                                        socket = null
                                        connectedDevice = null
                                        status = "Отключено"
                                        log += "Disconnected\n"
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
                        ) {
                            Text("Отключить")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Лог канала:", color = Color.Gray, fontSize = 12.sp)
                    Text(log.takeLast(600), color = Color.LightGray, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
fun RemoteButton(label: String, cmd: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.size(72.dp)) {
        Text(label, fontSize = 16.sp)
    }
}

fun sendCmd(socket: BluetoothSocket?, cmd: String, currentLog: String, updateLog: (String) -> Unit) {
    if (socket == null || !socket.isConnected) {
        updateLog(currentLog + "Нет активного канала\n")
        return
    }
    thread {
        try {
            socket.outputStream.write("$cmd\n".toByteArray())
            socket.outputStream.flush()
            updateLog(currentLog + "TX: $cmd\n")
        } catch (e: IOException) {
            updateLog(currentLog + "TX fail: ${e.message}\n")
        }
    }
}
