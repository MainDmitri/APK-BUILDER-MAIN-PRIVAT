package com.calc.pro

import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {

    private val CHANNEL = "com.calc.pro/termux"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "launchTermux" -> {
                        val command = call.argument<String>("command") ?: ""
                        val launched = launchInTermux(command)
                        result.success(launched)
                    }
                    "isTermuxInstalled" -> {
                        result.success(isTermuxInstalled())
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun isTermuxInstalled(): Boolean {
        return try {
            packageManager.getPackageInfo("com.termux", 0)
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Запускает команду в Termux через RUN_COMMAND Intent.
     * Termux должен быть установлен и иметь разрешение com.termux.permission.RUN_COMMAND.
     *
     * Альтернатива: открывает Termux и набирает команду через AccessibilityService —
     * здесь используем официальный API через Intent.
     */
    private fun launchInTermux(command: String): Boolean {
        return try {
            // Метод 1: Termux:API RUN_COMMAND (требует разрешения в Termux)
            val intent = Intent().apply {
                setClassName("com.termux", "com.termux.app.RunCommandService")
                action = "com.termux.RUN_COMMAND"
                putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
                putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
                putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
                putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
                putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0")
            }
            startForegroundService(intent)
            true
        } catch (e1: Exception) {
            try {
                // Метод 2: Fallback — открываем Termux с командой через URI
                val uri = Uri.parse("termux://open?command=${Uri.encode(command)}")
                val intent2 = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage("com.termux")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                startActivity(intent2)
                true
            } catch (e2: Exception) {
                false
            }
        }
    }
}
