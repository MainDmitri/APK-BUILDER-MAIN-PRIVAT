import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/message.dart';
import '../services/td_service.dart';

class MessageBubble extends StatelessWidget {
  final TgMessage message;
  final int myUserId;
  final VoidCallback? onReply;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;
  final VoidCallback? onCopy;

  const MessageBubble({
    super.key,
    required this.message,
    required this.myUserId,
    this.onReply,
    this.onEdit,
    this.onDelete,
    this.onCopy,
  });

  @override
  Widget build(BuildContext context) {
    final isOut = message.out;
    return GestureDetector(
      onLongPress: () => _showActions(context),
      child: Padding(
        padding: EdgeInsets.only(
          left: isOut ? 64 : 8,
          right: isOut ? 8 : 64,
          top: 2,
          bottom: 2,
        ),
        child: Row(
          mainAxisAlignment:
              isOut ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (!isOut) ...[
              _buildAvatar(),
              const SizedBox(width: 6),
            ],
            Flexible(
              child: Column(
                crossAxisAlignment:
                    isOut ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (!isOut && message.sender.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(left: 4, bottom: 2),
                      child: Text(
                        message.sender,
                        style: TextStyle(
                          color: _senderColor(message.sender),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  _buildBubble(context, isOut),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate()
        .fadeIn(duration: 200.ms)
        .slideY(begin: 0.08, end: 0, duration: 200.ms, curve: Curves.easeOut);
  }

  Color _senderColor(String name) {
    const colors = [
      Color(0xFFF97316),
      Color(0xFF8B5CF6),
      Color(0xFF06B6D4),
      Color(0xFF22C55E),
      Color(0xFFEC4899),
      Color(0xFFF59E0B),
    ];
    int hash = 0;
    for (final c in name.codeUnits) {
      hash = (hash * 31 + c) & 0xFFFFFF;
    }
    return colors[hash % colors.length];
  }

  Widget _buildAvatar() {
    final c = _senderColor(message.sender);
    return Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [c, c.withOpacity(0.6)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          message.sender.isNotEmpty ? message.sender[0].toUpperCase() : '?',
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildBubble(BuildContext context, bool isOut) {
    return Container(
      constraints:
          BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
      decoration: BoxDecoration(
        color: isOut ? const Color(0xFF1A3A5C) : const Color(0xFF1A1A24),
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(18),
          topRight: const Radius.circular(18),
          bottomLeft: Radius.circular(isOut ? 18 : 4),
          bottomRight: Radius.circular(isOut ? 4 : 18),
        ),
        border: Border.all(
          color:
              isOut ? const Color(0xFF1E4A7A) : const Color(0xFF27272A),
        ),
      ),
      child: Column(
        crossAxisAlignment:
            isOut ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          if (message.isOneTime) _buildOneTimeMedia(context),
          if (message.isPhoto && !message.isOneTime) _buildPhoto(context),
          if (message.isVideo && !message.isOneTime) _buildVideoThumb(context),
          if (message.isVoice) _buildVoice(),
          if (message.isSticker) _buildStickerPlaceholder(),
          if (message.isDocument &&
              !message.isPhoto &&
              !message.isVideo)
            _buildDocument(),
          if (message.text.isNotEmpty)
            Padding(
              padding: EdgeInsets.only(
                left: 12,
                right: 12,
                top: message.hasMedia ? 6 : 10,
                bottom: 4,
              ),
              child: Text(
                message.text,
                style: const TextStyle(color: Colors.white, fontSize: 15),
              ),
            ),
          Padding(
            padding:
                const EdgeInsets.only(right: 10, bottom: 6, left: 10, top: 2),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  message.timeStr,
                  style: const TextStyle(
                      color: Color(0xFF71717A), fontSize: 11),
                ),
                if (isOut) ...[
                  const SizedBox(width: 4),
                  const Icon(Icons.done_all_rounded,
                      color: Color(0xFF3B82F6), size: 14),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Media widgets ─────────────────────────────────────────────────────────

  Widget _buildOneTimeMedia(BuildContext context) {
    return GestureDetector(
      onTap: () => _openMedia(context, isVideo: false),
      child: Container(
        margin: const EdgeInsets.all(4),
        height: 200,
        decoration: BoxDecoration(
          color: const Color(0xFF0F0F14),
          borderRadius: BorderRadius.circular(14),
          gradient: LinearGradient(
            colors: [
              const Color(0xFFF97316).withOpacity(0.2),
              const Color(0xFF8B5CF6).withOpacity(0.2),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xFFF97316).withOpacity(0.2),
                border: Border.all(
                    color: const Color(0xFFF97316).withOpacity(0.6),
                    width: 2),
              ),
              child: const Icon(Icons.visibility_rounded,
                  color: Color(0xFFF97316), size: 28),
            ),
            const SizedBox(height: 10),
            const Text('Одноразовое фото',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 24),
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: const Color(0xFFF97316),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.play_arrow_rounded,
                      color: Colors.white, size: 18),
                  SizedBox(width: 6),
                  Text('Открыть',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhoto(BuildContext context) {
    return GestureDetector(
      onTap: () => _openMedia(context, isVideo: false),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(17),
          topRight: Radius.circular(17),
        ),
        child: _TdlibImage(
          chatId: message.chatId,
          msgId: message.msgId,
          height: 220,
        ),
      ),
    );
  }

  Widget _buildVideoThumb(BuildContext context) {
    return GestureDetector(
      onTap: () => _openMedia(context, isVideo: true),
      child: Container(
        height: 200,
        margin: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          color: const Color(0xFF18181B),
          borderRadius: BorderRadius.circular(14),
        ),
        child: const Stack(
          alignment: Alignment.center,
          children: [
            Icon(Icons.video_file_rounded,
                color: Color(0xFF52525B), size: 48),
            Positioned(
              bottom: 8,
              left: 12,
              child: Row(
                children: [
                  Icon(Icons.play_circle_rounded,
                      color: Color(0xFFF97316), size: 28),
                  SizedBox(width: 6),
                  Text('Видео',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 13,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVoice() {
    return Container(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF18181B),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFF97316).withOpacity(0.2),
            ),
            child: const Icon(Icons.mic_rounded,
                color: Color(0xFFF97316), size: 20),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 100,
                height: 3,
                decoration: BoxDecoration(
                  color: const Color(0xFFF97316).withOpacity(0.4),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 4),
              const Text('Голосовое',
                  style: TextStyle(
                      color: Color(0xFF71717A), fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStickerPlaceholder() {
    return Container(
      margin: const EdgeInsets.all(8),
      width: 100,
      height: 100,
      child: const Center(
        child: Text('🎭', style: TextStyle(fontSize: 48)),
      ),
    );
  }

  Widget _buildDocument() {
    return Container(
      margin: const EdgeInsets.all(8),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF18181B),
        borderRadius: BorderRadius.circular(12),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.insert_drive_file_rounded,
              color: Color(0xFF3B82F6), size: 28),
          SizedBox(width: 10),
          Text('Документ',
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  // ── Media viewer ──────────────────────────────────────────────────────────

  void _openMedia(BuildContext context, {required bool isVideo}) {
    showDialog(
      context: context,
      builder: (_) => _MediaDialog(
        chatId: message.chatId,
        msgId: message.msgId,
        isVideo: isVideo,
      ),
    );
  }

  // ── Actions sheet ─────────────────────────────────────────────────────────

  void _showActions(BuildContext context) {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF18181B),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(
                color: const Color(0xFF3F3F46),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            if (message.text.isNotEmpty)
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Text(
                  message.text,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: Color(0xFF71717A), fontSize: 13),
                ),
              ),
            const Divider(color: Color(0xFF27272A)),
            _ActionTile(
              icon: Icons.reply_rounded,
              label: 'Ответить',
              onTap: () {
                Navigator.pop(context);
                onReply?.call();
              },
            ),
            if (message.text.isNotEmpty)
              _ActionTile(
                icon: Icons.copy_rounded,
                label: 'Копировать',
                onTap: () {
                  Navigator.pop(context);
                  onCopy?.call();
                },
              ),
            if (onEdit != null)
              _ActionTile(
                icon: Icons.edit_rounded,
                label: 'Редактировать',
                onTap: () {
                  Navigator.pop(context);
                  onEdit?.call();
                },
              ),
            if (onDelete != null)
              _ActionTile(
                icon: Icons.delete_rounded,
                label: 'Удалить',
                color: const Color(0xFFEF4444),
                onTap: () {
                  Navigator.pop(context);
                  onDelete?.call();
                },
              ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

// ── TDLib-backed image widget ─────────────────────────────────────────────

class _TdlibImage extends StatefulWidget {
  final int chatId;
  final int msgId;
  final double height;
  const _TdlibImage(
      {required this.chatId, required this.msgId, required this.height});

  @override
  State<_TdlibImage> createState() => _TdlibImageState();
}

class _TdlibImageState extends State<_TdlibImage> {
  String? _localPath;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _download();
  }

  Future<void> _download() async {
    try {
      final path = await TdService.instance
          .downloadFile(widget.chatId, widget.msgId);
      if (mounted) setState(() { _localPath = path; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return SizedBox(
        height: widget.height,
        child: const Center(
          child: CircularProgressIndicator(
              color: Color(0xFFF97316), strokeWidth: 2),
        ),
      );
    }
    if (_localPath == null) {
      return SizedBox(
        height: widget.height,
        child: const Center(
          child: Icon(Icons.broken_image_rounded,
              color: Color(0xFF52525B), size: 32),
        ),
      );
    }
    return Image.file(
      File(_localPath!),
      height: widget.height,
      width: double.infinity,
      fit: BoxFit.cover,
      errorBuilder: (_, __, ___) => SizedBox(
        height: widget.height,
        child: const Center(
          child: Icon(Icons.broken_image_rounded,
              color: Color(0xFF52525B), size: 32),
        ),
      ),
    );
  }
}

// ── Fullscreen media dialog ───────────────────────────────────────────────

class _MediaDialog extends StatefulWidget {
  final int chatId;
  final int msgId;
  final bool isVideo;
  const _MediaDialog(
      {required this.chatId, required this.msgId, required this.isVideo});

  @override
  State<_MediaDialog> createState() => _MediaDialogState();
}

class _MediaDialogState extends State<_MediaDialog> {
  String? _path;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    TdService.instance
        .downloadFile(widget.chatId, widget.msgId)
        .then((p) {
      if (mounted) setState(() { _path = p; _loading = false; });
    }).catchError((_) {
      if (mounted) setState(() => _loading = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.black,
      insetPadding: EdgeInsets.zero,
      child: Stack(
        alignment: Alignment.topRight,
        children: [
          if (_loading)
            const Center(
              child: CircularProgressIndicator(color: Color(0xFFF97316)),
            )
          else if (_path == null)
            const Center(
              child: Icon(Icons.error_outline_rounded,
                  color: Color(0xFFEF4444), size: 56),
            )
          else if (widget.isVideo)
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.play_circle_rounded,
                    color: Color(0xFFF97316), size: 72),
                SizedBox(height: 16),
                Text('Видеофайл загружен',
                    style: TextStyle(color: Colors.white)),
              ],
            )
          else
            InteractiveViewer(
              child: Image.file(File(_path!), fit: BoxFit.contain),
            ),
          Positioned(
            top: MediaQuery.of(context).padding.top + 8,
            right: 12,
            child: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withOpacity(0.6),
                ),
                child: const Icon(Icons.close_rounded,
                    color: Colors.white, size: 20),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Action tile ───────────────────────────────────────────────────────────

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _ActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color = Colors.white,
  });
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(icon, color: color, size: 22),
      title: Text(label, style: TextStyle(color: color, fontSize: 16)),
      onTap: onTap,
    );
  }
}
