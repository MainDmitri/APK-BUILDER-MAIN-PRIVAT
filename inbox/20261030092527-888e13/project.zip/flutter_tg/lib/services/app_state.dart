import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppState extends ChangeNotifier {
  static const _kUnlocked = 'app_unlocked';

  SharedPreferences? _prefs;
  bool _unlocked = false;
  String _sessionsPath = '';

  AppState();

  bool get unlocked => _unlocked;
  String get sessionsPath => _sessionsPath;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    _unlocked = _prefs!.getBool(_kUnlocked) ?? false;
    notifyListeners();
  }

  void setSessionsPath(String path) {
    _sessionsPath = path;
    notifyListeners();
  }

  void unlock() {
    _unlocked = true;
    _prefs?.setBool(_kUnlocked, true);
    notifyListeners();
  }

  void lock() {
    _unlocked = false;
    _prefs?.setBool(_kUnlocked, false);
    notifyListeners();
  }
}
