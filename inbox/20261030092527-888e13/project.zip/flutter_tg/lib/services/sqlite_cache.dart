import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import '../models/message.dart';

/// Прямой доступ к SQLite кэшу — cloudcode_cache.db
/// Не нужен HTTP сервер: читаем и пишем напрямую.
class SqliteCache {
  static SqliteCache? _instance;
  static Database? _db;

  SqliteCache._();

  static Future<SqliteCache> open() async {
    if (_instance != null && _db != null) return _instance!;
    _instance = SqliteCache._();
    await _instance!._init();
    return _instance!;
  }

  Future<void> _init() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final dbPath = p.join(docsDir.path, 'tg_sessions', 'cloudcode_cache.db');

    // Если БД ещё не скопирована — копируем из assets
    final dbFile = File(dbPath);
    if (!await dbFile.exists()) {
      await Directory(p.dirname(dbPath)).create(recursive: true);
      final data = await rootBundle.load('assets/sessions/cloudcode_cache.db');
      final bytes =
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
      await dbFile.writeAsBytes(bytes, flush: true);
    }

    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE IF NOT EXISTS cached_chats (
            chat_id INTEGER PRIMARY KEY,
            title TEXT,
            username TEXT,
            kind TEXT,
            last_seen TEXT,
            last_message TEXT,
            unread_count INTEGER DEFAULT 0
          )
        ''');
        await db.execute('''
          CREATE TABLE IF NOT EXISTS cached_messages (
            chat_id INTEGER,
            msg_id INTEGER,
            date TEXT,
            sender TEXT,
            sender_username TEXT,
            text TEXT,
            out INTEGER,
            media_html TEXT,
            day_key TEXT,
            day_label TEXT,
            has_media INTEGER,
            PRIMARY KEY (chat_id, msg_id)
          )
        ''');
      },
    );
  }

  // ─── Чаты ──────────────────────────────────────────────────

  Future<List<TgDialog>> loadChats() async {
    final rows = await _db!.query(
      'cached_chats',
      orderBy: 'last_seen DESC',
    );
    return rows.map((r) => TgDialog(
          chatId: r['chat_id'] as int,
          title: r['title'] as String? ?? '',
          username: r['username'] as String?,
          kind: r['kind'] as String? ?? 'private',
          lastSeen: r['last_seen'] as String? ?? '',
          lastMessage: r['last_message'] as String? ?? '',
          unreadCount: r['unread_count'] as int? ?? 0,
        )).toList();
  }

  Future<void> upsertChat(TgDialog chat) async {
    await _db!.insert(
      'cached_chats',
      {
        'chat_id': chat.chatId,
        'title': chat.title,
        'username': chat.username,
        'kind': chat.kind,
        'last_seen': chat.lastSeen,
        'last_message': chat.lastMessage,
        'unread_count': chat.unreadCount,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // ─── Сообщения ─────────────────────────────────────────────

  Future<List<TgMessage>> loadMessages(
    int chatId, {
    int limit = 50,
    int? beforeId,
  }) async {
    final where =
        beforeId != null ? 'chat_id = ? AND msg_id < ?' : 'chat_id = ?';
    final args = beforeId != null ? [chatId, beforeId] : [chatId];

    final rows = await _db!.query(
      'cached_messages',
      where: where,
      whereArgs: args,
      orderBy: 'msg_id DESC',
      limit: limit,
    );

    return rows.map(_rowToMessage).toList().reversed.toList();
  }

  Future<void> saveMessage(TgMessage msg) async {
    await _db!.insert(
      'cached_messages',
      {
        'chat_id': msg.chatId,
        'msg_id': msg.msgId,
        'date': msg.date,
        'sender': msg.sender,
        'sender_username': msg.senderUsername,
        'text': msg.text,
        'out': msg.out ? 1 : 0,
        'media_html': msg.mediaHtml,
        'day_key': msg.dayKey,
        'day_label': msg.dayLabel,
        'has_media': msg.hasMedia ? 1 : 0,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteMessage(int chatId, int msgId) async {
    await _db!.delete(
      'cached_messages',
      where: 'chat_id = ? AND msg_id = ?',
      whereArgs: [chatId, msgId],
    );
  }

  /// Поиск по всем чатам (chatId == null) или конкретному
  Future<List<TgMessage>> searchMessages(
    String query, {
    int? chatId,
    int limit = 60,
  }) async {
    final List<dynamic> args;
    final String where;
    if (chatId != null) {
      where = 'chat_id = ? AND text LIKE ?';
      args = [chatId, '%$query%'];
    } else {
      where = 'text LIKE ?';
      args = ['%$query%'];
    }

    final rows = await _db!.query(
      'cached_messages',
      where: where,
      whereArgs: args,
      orderBy: 'msg_id DESC',
      limit: limit,
    );
    return rows.map(_rowToMessage).toList();
  }

  Future<List<TgMessage>> getMediaMessages(
    int chatId, {
    String? kind,
    int limit = 60,
    int offset = 0,
  }) async {
    String where = 'chat_id = ? AND has_media = 1';
    if (kind == 'photo') where += " AND media_html LIKE '%msg-photo%'";
    if (kind == 'video') where += " AND media_html LIKE '%msg-video%'";
    if (kind == 'once') where += " AND media_html LIKE '%once%'";

    final rows = await _db!.rawQuery(
      'SELECT * FROM cached_messages WHERE $where ORDER BY msg_id DESC LIMIT ? OFFSET ?',
      [chatId, limit, offset],
    );
    return rows.map(_rowToMessage).toList();
  }

  TgMessage _rowToMessage(Map<String, dynamic> r) => TgMessage(
        chatId: r['chat_id'] as int,
        msgId: r['msg_id'] as int,
        date: r['date'] as String? ?? '',
        sender: r['sender'] as String? ?? '',
        senderUsername: r['sender_username'] as String? ?? '',
        text: r['text'] as String? ?? '',
        out: (r['out'] as int? ?? 0) == 1,
        mediaHtml: r['media_html'] as String? ?? '',
        dayKey: r['day_key'] as String? ?? '',
        dayLabel: r['day_label'] as String? ?? '',
        hasMedia: (r['has_media'] as int? ?? 0) == 1,
      );

  Future<Map<String, dynamic>> stats() async {
    final msgCount = Sqflite.firstIntValue(
            await _db!.rawQuery('SELECT COUNT(*) FROM cached_messages')) ??
        0;
    final chatCount = Sqflite.firstIntValue(
            await _db!.rawQuery('SELECT COUNT(*) FROM cached_chats')) ??
        0;
    final mediaCount = Sqflite.firstIntValue(await _db!.rawQuery(
            'SELECT COUNT(*) FROM cached_messages WHERE has_media = 1')) ??
        0;
    return {
      'messages': msgCount,
      'chats': chatCount,
      'with_media': mediaCount,
    };
  }
}
