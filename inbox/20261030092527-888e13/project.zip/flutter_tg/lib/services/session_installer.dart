import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Copies bundled session files from assets → app documents dir on first launch.
/// The Python backend (main.py) should be told to look for sessions there.
class SessionInstaller {
  static const _doneKey = 'sessions_installed_v1';

  // Files to extract from assets/sessions/
  static const _files = [
    'main.session',
    'cloudcode_accounts.json',
    'cloudcode_cache.db',
  ];

  /// Call once at startup. Idempotent — skips if already done.
  static Future<String> install() async {
    final prefs = await SharedPreferences.getInstance();
    final dir = await getApplicationDocumentsDirectory();
    final sessionDir = Directory('${dir.path}/tg_sessions');

    // Always ensure directory exists
    if (!await sessionDir.exists()) {
      await sessionDir.create(recursive: true);
    }

    // Check if already installed
    final alreadyDone = prefs.getBool(_doneKey) ?? false;
    if (alreadyDone) {
      // Verify files are still there
      bool allPresent = true;
      for (final f in _files) {
        final target = File('${sessionDir.path}/$f');
        if (!await target.exists()) { allPresent = false; break; }
      }
      if (allPresent) return sessionDir.path;
    }

    // Extract from assets
    for (final fileName in _files) {
      final assetPath = 'assets/sessions/$fileName';
      final targetPath = '${sessionDir.path}/$fileName';
      try {
        final data = await rootBundle.load(assetPath);
        final bytes = data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes);
        await File(targetPath).writeAsBytes(bytes, flush: true);
      } catch (e) {
        // Asset not found or write failed — non-fatal
      }
    }

    await prefs.setBool(_doneKey, true);
    return sessionDir.path;
  }

  /// Returns path to the sessions directory (may not exist if install() not called).
  static Future<String> get sessionsPath async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/tg_sessions';
  }

  /// Returns path to the main.session file.
  static Future<String> get mainSessionPath async {
    return '${await sessionsPath}/main.session';
  }

  /// Returns contents of cloudcode_accounts.json as a string.
  static Future<String> get accountsJson async {
    final path = '${await sessionsPath}/cloudcode_accounts.json';
    final f = File(path);
    if (await f.exists()) return f.readAsString();
    // Fallback to asset
    return rootBundle.loadString('assets/sessions/cloudcode_accounts.json');
  }

  /// Returns path to the SQLite cache database.
  static Future<String> get cachePath async {
    return '${await sessionsPath}/cloudcode_cache.db';
  }
}
