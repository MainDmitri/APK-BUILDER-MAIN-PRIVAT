import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:handy_tdlib_next/handy_tdlib_next.dart' as td;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/message.dart';
import 'session_installer.dart';

/// Статус авторизации TDLib
enum TdAuthState {
  initial,
  waitingPhoneNumber,
  waitingCode,
  waitingPassword,
  ready,
  error,
  closed,
}

/// Главный сервис — обёртка над TDLib.
/// Читает сессию из main.session (Telethon формат) ИЛИ создаёт свою TDLib сессию.
class TdService extends ChangeNotifier {
  static TdService? _instance;
  static TdService get instance => _instance ??= TdService._();
  TdService._();

  td.TdClient? _client;
  bool _initialized = false;

  TdAuthState _authState = TdAuthState.initial;
  TdAuthState get authState => _authState;

  String _errorMessage = '';
  String get errorMessage => _errorMessage;

  // Текущий пользователь
  int _myUserId = 0;
  int get myUserId => _myUserId;

  // Кэш чатов и сообщений из SQLite (быстрый старт)
  final List<TgDialog> _cachedChats = [];
  List<TgDialog> get cachedChats => List.unmodifiable(_cachedChats);

  // Живые чаты из TDLib
  final Map<int, td.Chat> _tdChats = {};
  final Map<int, td.User> _tdUsers = {};

  // Streams для UI
  final _chatUpdates = StreamController<List<TgDialog>>.broadcast();
  Stream<List<TgDialog>> get chatStream => _chatUpdates.stream;

  final _newMessages = StreamController<TgMessage>.broadcast();
  Stream<TgMessage> get newMessageStream => _newMessages.stream;

  final _authStateStream = StreamController<TdAuthState>.broadcast();
  Stream<TdAuthState> get authStream => _authStateStream.stream;

  /// Инициализация: сначала грузим SQLite кэш, потом поднимаем TDLib
  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    await _loadSqliteCache();
    await _startTdLib();
  }

  // ─── SQLite кэш ───────────────────────────────────────────

  Future<void> _loadSqliteCache() async {
    try {
      final db = await SqliteCache.open();
      final chats = await db.loadChats();
      _cachedChats
        ..clear()
        ..addAll(chats);
      notifyListeners();
      debugPrint('[TdService] SQLite: ${chats.length} chats loaded');
    } catch (e) {
      debugPrint('[TdService] SQLite error: $e');
    }
  }

  // ─── TDLib ────────────────────────────────────────────────

  Future<void> _startTdLib() async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final tdDir = '${docsDir.path}/tdlib_data';

      // Читаем API credentials из sessions/cloudcode_accounts.json
      final accountJson = await SessionInstaller.accountsJson;
      final accountData = jsonDecode(accountJson) as Map<String, dynamic>;
      final accounts = accountData['accounts'] as List? ?? [];
      final account = accounts.isNotEmpty
          ? accounts.first as Map<String, dynamic>
          : <String, dynamic>{};

      final apiId = 21099690; // из main.py
      final apiHash = '9c1130843fda5f6516d7c8197ec26281';
      final phone = account['phone'] as String? ?? '';
      final deviceModel = account['device_model'] as String? ?? 'Android';
      final systemVersion =
          account['system_version'] as String? ?? 'Android 10';
      final appVersion = account['app_version'] as String? ?? '1.0';
      final langCode = account['lang_code'] as String? ?? 'ru';

      await td.TdPlugin.initialize();

      _client = td.TdClient();

      // Слушаем все апдейты
      _client!.updates.listen(_onUpdate);

      // Параметры TDLib
      await _client!.send(td.SetTdlibParameters(
        useTestDc: false,
        databaseDirectory: tdDir,
        filesDirectory: '${docsDir.path}/tdlib_files',
        databaseEncryptionKey: [],
        useFileDatabase: true,
        useChatInfoDatabase: true,
        useMessageDatabase: true,
        useSecretChats: false,
        apiId: apiId,
        apiHash: apiHash,
        systemLanguageCode: langCode,
        deviceModel: deviceModel,
        systemVersion: systemVersion,
        applicationVersion: appVersion,
      ));
    } catch (e) {
      debugPrint('[TdService] TDLib init error: $e');
      _setAuthState(TdAuthState.error);
      _errorMessage = e.toString();
    }
  }

  void _onUpdate(td.TdObject update) {
    if (update is td.UpdateAuthorizationState) {
      _handleAuthState(update.authorizationState);
    } else if (update is td.UpdateNewChat) {
      _tdChats[update.chat.id] = update.chat;
      _refreshChatList();
    } else if (update is td.UpdateChatLastMessage) {
      if (_tdChats.containsKey(update.chatId)) {
        _refreshChatList();
      }
    } else if (update is td.UpdateNewMessage) {
      final msg = _tdMessageToTg(update.message);
      if (msg != null) {
        _newMessages.add(msg);
        _updateLastMessageInCache(msg);
      }
    } else if (update is td.UpdateUser) {
      _tdUsers[update.user.id] = update.user;
    } else if (update is td.UpdateChatReadInbox) {
      _refreshChatList();
    }
  }

  void _handleAuthState(td.AuthorizationState state) {
    if (state is td.AuthorizationStateWaitTdlibParameters) {
      // Уже отправлено в _startTdLib
    } else if (state is td.AuthorizationStateWaitPhoneNumber) {
      _setAuthState(TdAuthState.waitingPhoneNumber);
    } else if (state is td.AuthorizationStateWaitCode) {
      _setAuthState(TdAuthState.waitingCode);
    } else if (state is td.AuthorizationStateWaitPassword) {
      _setAuthState(TdAuthState.waitingPassword);
    } else if (state is td.AuthorizationStateReady) {
      _setAuthState(TdAuthState.ready);
      _onAuthorized();
    } else if (state is td.AuthorizationStateClosed) {
      _setAuthState(TdAuthState.closed);
    }
  }

  void _setAuthState(TdAuthState state) {
    _authState = state;
    _authStateStream.add(state);
    notifyListeners();
  }

  Future<void> _onAuthorized() async {
    debugPrint('[TdService] Authorized! Loading chats...');
    try {
      // Загружаем список чатов
      await _client!.send(td.LoadChats(
        chatList: td.ChatListMain(),
        limit: 50,
      ));
      // Получаем свой ID
      final me = await _client!.send(td.GetMe()) as td.User?;
      if (me != null) _myUserId = me.id;
    } catch (e) {
      debugPrint('[TdService] _onAuthorized error: $e');
    }
  }

  // ─── Auth actions (для UI авторизации) ─────────────────────

  Future<void> sendPhoneNumber(String phone) async {
    await _client?.send(td.SetAuthenticationPhoneNumber(
      phoneNumber: phone,
      settings: td.PhoneNumberAuthenticationSettings(
        allowFlashCall: false,
        allowMissedCall: false,
        isCurrentPhoneNumber: false,
        hasUnknownPhoneNumber: false,
        allowSmsRetrieverApi: false,
        firefbaseAuthenticationSettings: null,
        authenticationTokens: [],
      ),
    ));
  }

  Future<void> sendCode(String code) async {
    await _client?.send(td.CheckAuthenticationCode(code: code));
  }

  Future<void> sendPassword(String password) async {
    await _client?.send(td.CheckAuthenticationPassword(password: password));
  }

  // ─── Данные ────────────────────────────────────────────────

  /// Список диалогов — сначала из TDLib, fallback SQLite кэш
  List<TgDialog> get dialogs {
    if (_tdChats.isNotEmpty && _authState == TdAuthState.ready) {
      return _tdChatsToDialogs();
    }
    return _cachedChats;
  }

  List<TgDialog> _tdChatsToDialogs() {
    final list = _tdChats.values.toList()
      ..sort((a, b) {
        final at = a.lastMessage?.date ?? 0;
        final bt = b.lastMessage?.date ?? 0;
        return bt.compareTo(at);
      });

    return list.map((chat) {
      final lastMsg = chat.lastMessage;
      String lastText = '';
      if (lastMsg?.content is td.MessageText) {
        lastText =
            (lastMsg!.content as td.MessageText).text.text;
      } else if (lastMsg != null) {
        lastText = _contentTypeLabel(lastMsg.content);
      }

      final kind = _chatKind(chat.type);
      return TgDialog(
        chatId: chat.id,
        title: chat.title,
        username: null,
        kind: kind,
        lastSeen: lastMsg != null
            ? DateTime.fromMillisecondsSinceEpoch(lastMsg.date * 1000)
                .toIso8601String()
            : '',
        lastMessage: lastText,
        unreadCount: chat.unreadCount,
      );
    }).toList();
  }

  String _chatKind(td.ChatType type) {
    if (type is td.ChatTypePrivate) return 'private';
    if (type is td.ChatTypeBasicGroup) return 'group';
    if (type is td.ChatTypeSupergroup) {
      return (type as td.ChatTypeSupergroup).isChannel
          ? 'channel'
          : 'group';
    }
    return 'private';
  }

  String _contentTypeLabel(td.MessageContent content) {
    if (content is td.MessagePhoto) return '🖼 Фото';
    if (content is td.MessageVideo) return '🎬 Видео';
    if (content is td.MessageAudio) return '🎵 Аудио';
    if (content is td.MessageDocument) return '📄 Файл';
    if (content is td.MessageSticker) return '😊 Стикер';
    if (content is td.MessageVoiceNote) return '🎤 Голосовое';
    if (content is td.MessageVideoNote) return '📹 Видеосообщение';
    if (content is td.MessageAnimation) return '🎭 GIF';
    return '📎 Медиа';
  }

  void _refreshChatList() {
    _chatUpdates.add(dialogs);
    notifyListeners();
  }

  void _updateLastMessageInCache(TgMessage msg) {
    _chatUpdates.add(dialogs);
    notifyListeners();
  }

  TgMessage? _tdMessageToTg(td.Message msg) {
    String text = '';
    if (msg.content is td.MessageText) {
      text = (msg.content as td.MessageText).text.text;
    }
    final sender = msg.senderId;
    int senderId = 0;
    if (sender is td.MessageSenderUser) senderId = sender.userId;
    return TgMessage(
      chatId: msg.chatId,
      msgId: msg.id,
      date: _formatDate(msg.date),
      sender: _tdUsers[senderId]?.firstName ?? '',
      senderUsername: _tdUsers[senderId]?.username?.activeUsernames.firstOrNull ?? '',
      text: text,
      out: msg.isOutgoing,
      mediaHtml: '',
      dayKey: '',
      dayLabel: '',
      hasMedia: msg.content is! td.MessageText,
    );
  }

  String _formatDate(int unixSec) {
    final dt = DateTime.fromMillisecondsSinceEpoch(unixSec * 1000);
    final d = dt.day.toString().padLeft(2, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final y = dt.year.toString().substring(2);
    final h = dt.hour.toString().padLeft(2, '0');
    final min = dt.minute.toString().padLeft(2, '0');
    return '$d.$m.$y $h:$min';
  }

  // ─── Получить историю чата ─────────────────────────────────

  Future<List<TgMessage>> getHistory(int chatId,
      {int fromMessageId = 0, int limit = 50}) async {
    // Если TDLib готов — берём оттуда
    if (_authState == TdAuthState.ready && _client != null) {
      try {
        final result = await _client!.send(td.GetChatHistory(
          chatId: chatId,
          fromMessageId: fromMessageId,
          offset: 0,
          limit: limit,
          onlyLocal: false,
        )) as td.Messages?;

        if (result != null && result.messages.isNotEmpty) {
          return result.messages
              .map(_tdMessageToTg)
              .whereType<TgMessage>()
              .toList();
        }
      } catch (e) {
        debugPrint('[TdService] getHistory TDLib error: $e');
      }
    }

    // Fallback — SQLite кэш
    final db = await SqliteCache.open();
    return db.loadMessages(chatId, limit: limit);
  }

  /// Загрузить сообщения из SQLite кэша (быстро, оффлайн)
  Future<List<TgMessage>> getCachedMessages(int chatId,
      {int limit = 50, int? beforeId}) async {
    final db = await SqliteCache.open();
    return db.loadMessages(chatId, limit: limit, beforeId: beforeId);
  }

  // ─── Отправка сообщений ────────────────────────────────────

  Future<bool> sendMessage(int chatId, String text,
      {int? replyToMsgId}) async {
    if (_client == null || _authState != TdAuthState.ready) return false;
    try {
      await _client!.send(td.SendMessage(
        chatId: chatId,
        messageThreadId: 0,
        replyTo: replyToMsgId != null
            ? td.InputMessageReplyToMessage(
                chatId: chatId, messageId: replyToMsgId, quote: null)
            : null,
        options: td.MessageSendOptions(
          disableNotification: false,
          fromBackground: false,
          protectContent: false,
          updateOrderOfInstalledStickerSets: false,
          schedulingState: null,
          effectId: 0,
          sendingId: 0,
          onlyPreview: false,
        ),
        replyMarkup: null,
        inputMessageContent: td.InputMessageText(
          text: td.FormattedText(text: text, entities: []),
          linkPreviewOptions: td.LinkPreviewOptions(
            isDisabled: true,
            url: '',
            forceLargeMedia: false,
            forceSmallMedia: false,
            showAboveText: false,
          ),
          clearDraft: true,
        ),
      ));
      return true;
    } catch (e) {
      debugPrint('[TdService] sendMessage error: $e');
      return false;
    }
  }

  Future<bool> deleteMessage(int chatId, int messageId) async {
    if (_client == null || _authState != TdAuthState.ready) return false;
    try {
      await _client!.send(td.DeleteMessages(
        chatId: chatId,
        messageIds: [messageId],
        revoke: true,
      ));
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> editMessage(
      int chatId, int messageId, String newText) async {
    if (_client == null || _authState != TdAuthState.ready) return false;
    try {
      await _client!.send(td.EditMessageText(
        chatId: chatId,
        messageId: messageId,
        replyMarkup: null,
        inputMessageContent: td.InputMessageText(
          text: td.FormattedText(text: newText, entities: []),
          linkPreviewOptions: td.LinkPreviewOptions(
            isDisabled: true,
            url: '',
            forceLargeMedia: false,
            forceSmallMedia: false,
            showAboveText: false,
          ),
          clearDraft: false,
        ),
      ));
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<void> markRead(int chatId, int lastReadMessageId) async {
    if (_client == null) return;
    try {
      await _client!.send(td.ViewMessages(
        chatId: chatId,
        messageIds: [lastReadMessageId],
        source: null,
        forceRead: true,
      ));
    } catch (_) {}
  }

  // ─── URL для медиа ─────────────────────────────────────────

  /// Скачать медиафайл сообщения через TDLib, вернуть локальный путь.
  /// Принимает (chatId, msgId) — сам достаёт fileId из объекта сообщения.
  Future<String?> downloadFile(int chatId, int msgId) async {
    if (_client == null) return null;
    try {
      final msg = await _client!.send(td.GetMessage(
        chatId: chatId,
        messageId: msgId,
      )) as td.Message?;
      if (msg == null) return null;

      int? fileId = _extractFileId(msg.content);
      if (fileId == null) return null;

      final file = await _client!.send(td.DownloadFile(
        fileId: fileId,
        priority: 1,
        offset: 0,
        limit: 0,
        synchronous: true,
      )) as td.File?;
      return file?.local.path?.isEmpty ?? true ? null : file?.local.path;
    } catch (e) {
      debugPrint('[TdService] downloadFile error: $e');
      return null;
    }
  }

  /// Извлечь TDLib fileId из контента сообщения
  int? _extractFileId(td.MessageContent content) {
    if (content is td.MessagePhoto) {
      final sizes = content.photo.sizes;
      return sizes.isNotEmpty ? sizes.last.photo.id : null;
    }
    if (content is td.MessageVideo) return content.video.video.id;
    if (content is td.MessageDocument) return content.document.document.id;
    if (content is td.MessageAudio) return content.audio.audio.id;
    if (content is td.MessageVoiceNote) return content.voiceNote.voice.id;
    if (content is td.MessageVideoNote) return content.videoNote.video.id;
    if (content is td.MessageSticker) return content.sticker.sticker.id;
    if (content is td.MessageAnimation) return content.animation.animation.id;
    return null;
  }

  /// Скачать файл по прямому TDLib fileId (для превью и т.п.)
  Future<String?> downloadFileById(int fileId) async {
    if (_client == null) return null;
    try {
      final file = await _client!.send(td.DownloadFile(
        fileId: fileId,
        priority: 1,
        offset: 0,
        limit: 0,
        synchronous: true,
      )) as td.File?;
      final path = file?.local.path;
      return (path == null || path.isEmpty) ? null : path;
    } catch (_) {
      return null;
    }
  }

  @override
  void dispose() {
    _client?.close();
    _chatUpdates.close();
    _newMessages.close();
    _authStateStream.close();
    super.dispose();
  }
}
