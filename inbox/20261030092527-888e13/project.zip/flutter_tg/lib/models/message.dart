class TgMessage {
  final int msgId;        // primary key
  final int chatId;       // which chat
  final String text;
  final bool out;
  final String sender;
  final String senderUsername;
  final String mediaHtml;
  final String dayKey;
  final String dayLabel;
  final String date;

  // Computed media flags
  final bool isPhoto;
  final bool isVideo;
  final bool isOneTime;
  final bool isSticker;
  final bool isVoice;
  final bool isDocument;
  final bool hasMedia;

  TgMessage({
    required this.msgId,
    required this.chatId,
    required this.text,
    required this.out,
    required this.sender,
    required this.senderUsername,
    required this.mediaHtml,
    required this.dayKey,
    required this.dayLabel,
    required this.date,
    // media flags optional — computed from mediaHtml if omitted
    bool? isPhoto,
    bool? isVideo,
    bool? isOneTime,
    bool? isSticker,
    bool? isVoice,
    bool? isDocument,
    bool? hasMedia,
  })  : isOneTime = isOneTime ?? (_mediaContains(mediaHtml, 'ot-card') ||
              _mediaContains(mediaHtml, 'view_once') ||
              _mediaContains(mediaHtml, 'одноразовое')),
        isPhoto = isPhoto ??
            ((_mediaContains(mediaHtml, '<img') ||
                    _mediaContains(mediaHtml, 'photo')) &&
                !(_mediaContains(mediaHtml, 'ot-card') ||
                    _mediaContains(mediaHtml, 'view_once'))),
        isVideo = isVideo ??
            (_mediaContains(mediaHtml, 'video') &&
                !_mediaContains(mediaHtml, '<img') &&
                !(_mediaContains(mediaHtml, 'ot-card') ||
                    _mediaContains(mediaHtml, 'view_once'))),
        isVoice = isVoice ??
            (_mediaContains(mediaHtml, 'voice') ||
                _mediaContains(mediaHtml, 'audio')),
        isSticker = isSticker ??
            (_mediaContains(mediaHtml, 'sticker') ||
                _mediaContains(mediaHtml, '.webp')),
        isDocument = isDocument ??
            (_mediaContains(mediaHtml, 'document') ||
                (_mediaContains(mediaHtml, 'file') &&
                    !_mediaContains(mediaHtml, '<img') &&
                    !_mediaContains(mediaHtml, 'video'))),
        hasMedia = hasMedia ?? mediaHtml.isNotEmpty;

  static bool _mediaContains(String html, String s) =>
      html.toLowerCase().contains(s);

  factory TgMessage.fromJson(Map<String, dynamic> j) {
    return TgMessage(
      msgId: (j['msg_id'] as num?)?.toInt() ??
          (j['id'] as num?)?.toInt() ?? 0,
      chatId: (j['chat_id'] as num?)?.toInt() ?? 0,
      text: j['text'] as String? ?? '',
      out: j['out'] == true || j['out'] == 1,
      sender: j['sender'] as String? ?? '',
      senderUsername: j['sender_username'] as String? ?? '',
      mediaHtml: j['media_html'] as String? ?? '',
      dayKey: j['day_key'] as String? ?? '',
      dayLabel: j['day_label'] as String? ?? '',
      date: j['date'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'msg_id': msgId,
        'chat_id': chatId,
        'text': text,
        'out': out,
        'sender': sender,
        'sender_username': senderUsername,
        'media_html': mediaHtml,
        'day_key': dayKey,
        'day_label': dayLabel,
        'date': date,
      };

  String get timeStr {
    if (date.isEmpty) return '';
    try {
      final dt = DateTime.parse(date).toLocal();
      return '${dt.hour.toString().padLeft(2, '0')}:'
          '${dt.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  TgMessage copyWith({String? text, String? mediaHtml}) => TgMessage(
        msgId: msgId,
        chatId: chatId,
        text: text ?? this.text,
        out: out,
        sender: sender,
        senderUsername: senderUsername,
        mediaHtml: mediaHtml ?? this.mediaHtml,
        dayKey: dayKey,
        dayLabel: dayLabel,
        date: date,
      );
}

class TgDialog {
  final int chatId;       // numeric TDLib chat id
  final String title;
  final String username;
  final String kind;      // user | bot | group | supergroup | channel
  final String lastMessage;
  final String lastSeen;
  final int unreadCount;

  final bool isGroup;
  final bool isChannel;
  final bool isUser;

  TgDialog({
    required this.chatId,
    required this.title,
    String? username,
    required this.kind,
    required this.lastMessage,
    required this.lastSeen,
    required this.unreadCount,
    bool? isGroup,
    bool? isChannel,
    bool? isUser,
  })  : username = username ?? '',
        isGroup = isGroup ??
            (kind == 'group' ||
                kind == 'supergroup' ||
                kind == 'megagroup'),
        isChannel = isChannel ??
            (kind == 'channel' || kind == 'broadcast'),
        isUser = isUser ?? (kind == 'user' || kind == 'bot' || kind == 'private');

  factory TgDialog.fromJson(Map<String, dynamic> j) {
    final kind = j['kind'] as String? ?? 'user';
    return TgDialog(
      chatId: (j['chat_id'] as num?)?.toInt() ??
          int.tryParse(j['id']?.toString() ?? '') ?? 0,
      title: j['title'] as String? ?? '',
      username: j['username'] as String? ?? '',
      kind: kind,
      lastMessage:
          j['last_message'] as String? ?? j['text'] as String? ?? '',
      lastSeen: j['last_seen'] as String? ?? '',
      unreadCount:
          (j['unread_count'] as num?)?.toInt() ??
          (j['unread'] as num?)?.toInt() ?? 0,
      isGroup: kind == 'group' ||
          kind == 'supergroup' ||
          kind == 'megagroup',
      isChannel: kind == 'channel' || kind == 'broadcast',
      isUser: kind == 'user' || kind == 'bot',
    );
  }

  String get idString => chatId.toString();
}
