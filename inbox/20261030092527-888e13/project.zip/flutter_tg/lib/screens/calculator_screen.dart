import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});
  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen>
    with TickerProviderStateMixin {
  String _display = '0';
  String _expression = '';
  String _prevResult = '';
  bool _justCalc = false;

  // Secret sequence tracker: 772+9902=
  final _secretSeq = '772+9902=';
  String _inputSeq = '';

  late AnimationController _shakeCtrl;
  late AnimationController _glowCtrl;

  static const _bg = Color(0xFF1C1C1E);
  static const _panel = Color(0xFF2C2C2E);
  static const _acc = Color(0xFFF97316);
  static const _text = Colors.white;
  static const _textDim = Color(0xFF8E8E93);

  @override
  void initState() {
    super.initState();
    _shakeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _glowCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  void _onBtn(String val) {
    HapticFeedback.lightImpact();
    _trackSecret(val);

    setState(() {
      if (val == 'AC') {
        _display = '0';
        _expression = '';
        _prevResult = '';
        _justCalc = false;
      } else if (val == '⌫') {
        if (_display.length > 1) {
          _display = _display.substring(0, _display.length - 1);
        } else {
          _display = '0';
        }
      } else if (val == '±') {
        if (_display != '0') {
          _display = _display.startsWith('-')
              ? _display.substring(1)
              : '-$_display';
        }
      } else if (val == '%') {
        final n = double.tryParse(_display) ?? 0;
        _display = _fmt(n / 100);
      } else if (val == '=') {
        _calc();
      } else if ('+-×÷'.contains(val)) {
        if (_justCalc) {
          _expression = _display + val;
        } else {
          if (_expression.isNotEmpty &&
              '+-×÷'.contains(_expression[_expression.length - 1])) {
            _expression = _expression.substring(0, _expression.length - 1) + val;
          } else {
            _expression += _display + val;
          }
        }
        _display = '0';
        _justCalc = false;
      } else if (val == '.') {
        if (_justCalc) {
          _display = '0.';
          _justCalc = false;
        } else if (!_display.contains('.')) {
          _display += '.';
        }
      } else {
        if (_justCalc || _display == '0') {
          _display = val;
          _justCalc = false;
        } else {
          if (_display.length < 15) _display += val;
        }
      }
    });
  }

  void _trackSecret(String val) {
    // Map button labels to secret sequence chars
    final char = val == '×' ? '*' : val == '÷' ? '/' : val;
    // Build what the user is typing in terms of the sequence
    // Secret: 772+9902=
    // Map: + stays +, = stays =
    final mapped = val == '×' ? '×' : val == '÷' ? '÷' : val;
    _inputSeq += mapped;
    // Check if inputSeq ends with secret
    if (_inputSeq.endsWith(_secretSeq)) {
      _inputSeq = '';
      Future.delayed(const Duration(milliseconds: 300), () {
        if (!mounted) return;
        _glowCtrl.forward(from: 0);
        Future.delayed(const Duration(milliseconds: 600), () {
          if (!mounted) return;
          context.read<AppState>().unlock();
        });
      });
    }
    // Keep only last 20 chars to avoid unbounded growth
    if (_inputSeq.length > 20) {
      _inputSeq = _inputSeq.substring(_inputSeq.length - 20);
    }
  }

  void _calc() {
    try {
      final expr = _expression + _display;
      // Simple eval via dart arithmetic
      final result = _evalExpr(expr);
      _prevResult = _expression + _display + '=';
      _display = _fmt(result);
      _expression = '';
      _justCalc = true;
    } catch (_) {
      _shakeCtrl.forward(from: 0);
      _display = 'Ошибка';
      Future.delayed(const Duration(seconds: 1), () {
        if (mounted) setState(() => _display = '0');
      });
    }
  }

  double _evalExpr(String expr) {
    // Replace × ÷ with * /
    expr = expr.replaceAll('×', '*').replaceAll('÷', '/');
    // Tokenize and eval with correct operator precedence
    final tokens = _tokenize(expr);
    return _parseExpr(tokens, 0).$1;
  }

  List<String> _tokenize(String expr) {
    final out = <String>[];
    var num = '';
    for (int i = 0; i < expr.length; i++) {
      final c = expr[i];
      if ('0123456789.'.contains(c)) {
        num += c;
      } else if ('+-*/'.contains(c)) {
        if (num.isNotEmpty) { out.add(num); num = ''; }
        // Handle unary minus
        if (c == '-' && (out.isEmpty || '+-*/'.contains(out.last))) {
          num = '-';
        } else {
          out.add(c);
        }
      }
    }
    if (num.isNotEmpty) out.add(num);
    return out;
  }

  (double, int) _parseExpr(List<String> tokens, int pos) {
    var (left, i) = _parseTerm(tokens, pos);
    while (i < tokens.length && (tokens[i] == '+' || tokens[i] == '-')) {
      final op = tokens[i]; i++;
      final (right, ni) = _parseTerm(tokens, i);
      left = op == '+' ? left + right : left - right;
      i = ni;
    }
    return (left, i);
  }

  (double, int) _parseTerm(List<String> tokens, int pos) {
    var (left, i) = _parseNum(tokens, pos);
    while (i < tokens.length && (tokens[i] == '*' || tokens[i] == '/')) {
      final op = tokens[i]; i++;
      final (right, ni) = _parseNum(tokens, i);
      left = op == '*' ? left * right : left / right;
      i = ni;
    }
    return (left, i);
  }

  (double, int) _parseNum(List<String> tokens, int pos) {
    if (pos >= tokens.length) return (0, pos);
    return (double.parse(tokens[pos]), pos + 1);
  }

  String _fmt(double n) {
    if (n == n.truncateToDouble() && !n.isInfinite) {
      final s = n.toInt().toString();
      return s;
    }
    // Up to 10 sig figs
    final s = n.toStringAsPrecision(10).replaceAll(RegExp(r'0+$'), '');
    return s.endsWith('.') ? s.substring(0, s.length - 1) : s;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      body: AnimatedBuilder(
        animation: _glowCtrl,
        builder: (ctx, child) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color.lerp(
                      _bg, const Color(0xFFF97316), _glowCtrl.value * 0.3)!,
                  _bg,
                ],
              ),
            ),
            child: child,
          );
        },
        child: SafeArea(
          child: Column(
            children: [
              _buildDisplay(),
              _buildKeypad(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDisplay() {
    return Expanded(
      flex: 3,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        alignment: Alignment.bottomRight,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            if (_prevResult.isNotEmpty || _expression.isNotEmpty)
              Text(
                _prevResult.isNotEmpty ? _prevResult : _expression,
                style: TextStyle(
                  color: _textDim,
                  fontSize: 18,
                  fontWeight: FontWeight.w300,
                ),
                textAlign: TextAlign.right,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ).animate().fadeIn(duration: 200.ms),
            const SizedBox(height: 8),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerRight,
              child: Text(
                _display,
                style: const TextStyle(
                  color: _text,
                  fontSize: 72,
                  fontWeight: FontWeight.w200,
                  letterSpacing: -2,
                ),
              ),
            ).animate(controller: _shakeCtrl, autoPlay: false).shake(
                  hz: 4,
                  curve: Curves.easeInOut,
                  duration: 400.ms,
                ),
          ],
        ),
      ),
    );
  }

  Widget _buildKeypad() {
    final rows = [
      ['AC', '±', '%', '÷'],
      ['7', '8', '9', '×'],
      ['4', '5', '6', '-'],
      ['1', '2', '3', '+'],
      ['⌫', '0', '.', '='],
    ];
    return Expanded(
      flex: 5,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: rows.map((row) {
            return Expanded(
              child: Row(
                children: row.map((lbl) {
                  return Expanded(child: _CalcBtn(
                    label: lbl,
                    onTap: () => _onBtn(lbl),
                    type: _btnType(lbl),
                  ));
                }).toList(),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  _BtnType _btnType(String lbl) {
    if (lbl == '=') return _BtnType.accent;
    if ('÷×-+'.contains(lbl)) return _BtnType.op;
    if ('AC±%⌫'.contains(lbl)) return _BtnType.func;
    return _BtnType.num;
  }
}

enum _BtnType { num, op, func, accent }

class _CalcBtn extends StatefulWidget {
  final String label;
  final VoidCallback onTap;
  final _BtnType type;
  const _CalcBtn({required this.label, required this.onTap, required this.type});
  @override
  State<_CalcBtn> createState() => _CalcBtnState();
}

class _CalcBtnState extends State<_CalcBtn>
    with SingleTickerProviderStateMixin {
  late AnimationController _ac;
  late Animation<double> _scale;

  static const _bg = Color(0xFF1C1C1E);
  static const _numBg = Color(0xFF333335);
  static const _opBg = Color(0xFFF97316);
  static const _funcBg = Color(0xFF636366);
  static const _accBg = Color(0xFFF97316);

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 80));
    _scale = Tween(begin: 1.0, end: 0.88).animate(
        CurvedAnimation(parent: _ac, curve: Curves.easeOut));
  }

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  Color get _bgColor {
    switch (widget.type) {
      case _BtnType.num:
        return _numBg;
      case _BtnType.op:
        return _opBg;
      case _BtnType.func:
        return _funcBg;
      case _BtnType.accent:
        return _accBg;
    }
  }

  Color get _fgColor {
    if (widget.type == _BtnType.op || widget.type == _BtnType.accent) {
      return Colors.white;
    }
    return Colors.white;
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ac.forward(),
      onTapUp: (_) {
        _ac.reverse();
        widget.onTap();
      },
      onTapCancel: () => _ac.reverse(),
      child: ScaleTransition(
        scale: _scale,
        child: Container(
          margin: const EdgeInsets.all(5),
          decoration: BoxDecoration(
            color: _bgColor,
            borderRadius: BorderRadius.circular(50),
            boxShadow: [
              BoxShadow(
                color: widget.type == _BtnType.accent
                    ? const Color(0xFFF97316).withOpacity(0.4)
                    : Colors.black.withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Center(
            child: Text(
              widget.label,
              style: TextStyle(
                color: _fgColor,
                fontSize: 24,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
