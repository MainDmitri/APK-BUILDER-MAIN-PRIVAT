import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/td_service.dart';
import '../services/sqlite_cache.dart';
import '../widgets/message_bubble.dart';
import 'media_gallery_screen.dart';

class ChatScreen extends StatefulWidget {
  final TgDialog dialog;
  const ChatScreen({super.key, required this.dialog});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  final _scrollCtrl = ScrollController();
  final _inputCtrl = TextEditingController();
  final _inputFocus = FocusNode();
  List<TgMessage> _messages = [];
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;
  bool _onlyMe = false;
  int? _replyToId;
  String? _replyToText;
  int? _editId;
  StreamSubscription? _newMsgSub;

  TdService get _td => context.read<TdService>();
  TgDialog get _dialog => widget.dialog;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadMessages();
    _scrollCtrl.addListener(_onScroll);
    // Слушаем новые сообщения из TDLib
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _newMsgSub = _td.newMessageStream.listen((msg) {
        if (msg.chatId == _dialog.chatId && mounted) {
          setState(() => _messages.add(msg));
          _scrollToBottom();
        }
      });
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _newMsgSub?.cancel();
    _scrollCtrl.dispose();
    _inputCtrl.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollCtrl.position.pixels <=
        _scrollCtrl.position.minScrollExtent + 200) {
      _loadMore();
    }
  }

  Future<void> _loadMessages() async {
    setState(() => _loading = true);
    try {
      // Сначала из кэша (мгновенно)
      final db = await SqliteCache.open();
      final cached = await db.loadMessages(_dialog.chatId, limit: 50);
      if (mounted) setState(() { _messages = cached; _loading = false; });
      _scrollToBottom();

      // Потом live из TDLib (если авторизован)
      if (_td.authState == TdAuthState.ready) {
        final live = await _td.getHistory(_dialog.chatId, limit: 50);
        if (mounted && live.isNotEmpty) {
          setState(() => _messages = live);
          _scrollToBottom();
        }
      }
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _loadMore() async {
    if (_loadingMore || !_hasMore || _messages.isEmpty) return;
    setState(() => _loadingMore = true);
    try {
      final oldestId = _messages.first.msgId;
      final db = await SqliteCache.open();
      final older = await db.loadMessages(
        _dialog.chatId, limit: 50, beforeId: oldestId);
      if (!mounted) return;
      if (older.isEmpty) {
        setState(() { _hasMore = false; _loadingMore = false; });
      } else {
        setState(() {
          _messages.insertAll(0, older);
          _loadingMore = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => _loadingMore = false);
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send() async {
    final text = _inputCtrl.text.trim();
    if (text.isEmpty) return;
    _inputCtrl.clear();

    if (_editId != null) {
      final id = _editId!;
      setState(() { _editId = null; _replyToId = null; _replyToText = null; });
      await _td.editMessage(_dialog.chatId, id, text);
      // Обновляем в списке локально
      setState(() {
        final idx = _messages.indexWhere((m) => m.msgId == id);
        if (idx >= 0) {
          final old = _messages[idx];
          _messages[idx] = TgMessage(
            chatId: old.chatId, msgId: old.msgId, date: old.date,
            sender: old.sender, senderUsername: old.senderUsername,
            text: text, out: old.out, mediaHtml: old.mediaHtml,
            dayKey: old.dayKey, dayLabel: old.dayLabel, hasMedia: old.hasMedia,
          );
        }
      });
    } else {
      final replyId = _replyToId;
      setState(() { _replyToId = null; _replyToText = null; });
      await _td.sendMessage(_dialog.chatId, text, replyToMsgId: replyId);
    }
  }

  void _startEdit(TgMessage msg) {
    setState(() {
      _editId = msg.msgId;
      _replyToId = null;
      _replyToText = null;
      _inputCtrl.text = msg.text;
    });
    _inputFocus.requestFocus();
  }

  void _startReply(TgMessage msg) {
    setState(() {
      _replyToId = msg.msgId;
      _replyToText = msg.text.length > 60
          ? msg.text.substring(0, 60) + '...'
          : msg.text;
      _editId = null;
    });
    _inputFocus.requestFocus();
  }

  void _cancelEdit() {
    setState(() {
      _editId = null;
      _replyToId = null;
      _replyToText = null;
      _inputCtrl.clear();
    });
  }

  Future<void> _delete(TgMessage msg) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF141418),
        title: const Text('Удалить сообщение?',
            style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена')),
          TextButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Удалить',
                  style: TextStyle(color: Color(0xFFEF4444)))),
        ],
      ),
    );
    if (ok == true) {
      await _td.deleteMessage(_dialog.chatId, msg.msgId);
      if (mounted) {
        setState(() => _messages.removeWhere((m) => m.msgId == msg.msgId));
      }
      // Удаляем из кэша
      final db = await SqliteCache.open();
      await db.deleteMessage(_dialog.chatId, msg.msgId);
    }
  }

  List<TgMessage> get _filtered {
    if (!_onlyMe) return _messages;
    return _messages.where((m) => m.out).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Column(
        children: [
          _buildAppBar(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(
                    color: Color(0xFFF97316)))
                : _buildMessageList(),
          ),
          _buildCompose(),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 6,
        left: 4, right: 16, bottom: 10,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0F),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back_ios_new_rounded,
                color: Colors.white, size: 20),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(
                  builder: (_) => MediaGalleryScreen(dialog: _dialog))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_dialog.title, style: const TextStyle(
                      color: Colors.white, fontSize: 16,
                      fontWeight: FontWeight.w600),
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(
                    _td.authState == TdAuthState.ready ? 'онлайн' : 'кэш',
                    style: const TextStyle(color: Color(0xFF71717A), fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          // Только мои
          GestureDetector(
            onTap: () => setState(() => _onlyMe = !_onlyMe),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: _onlyMe
                    ? const Color(0xFFF97316).withOpacity(0.2)
                    : const Color(0xFF1A1A22),
                border: Border.all(
                  color: _onlyMe
                      ? const Color(0xFFF97316)
                      : const Color(0xFF27272A),
                ),
              ),
              child: Text('Мои',
                  style: TextStyle(
                    color: _onlyMe
                        ? const Color(0xFFF97316)
                        : const Color(0xFF71717A),
                    fontSize: 12,
                  )),
            ),
          ),
          const SizedBox(width: 8),
          // Медиа-галерея
          IconButton(
            onPressed: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => MediaGalleryScreen(dialog: _dialog))),
            icon: const Icon(Icons.photo_library_outlined,
                color: Color(0xFF71717A), size: 22),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    final msgs = _filtered;
    if (msgs.isEmpty) {
      return const Center(
        child: Text('Нет сообщений',
            style: TextStyle(color: Color(0xFF71717A))));
    }
    return ListView.builder(
      controller: _scrollCtrl,
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: msgs.length + (_loadingMore ? 1 : 0),
      itemBuilder: (_, i) {
        if (_loadingMore && i == 0) {
          return const Center(
              child: Padding(
                padding: EdgeInsets.all(8),
                child: SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(
                        color: Color(0xFFF97316), strokeWidth: 2)),
              ));
        }
        final idx = _loadingMore ? i - 1 : i;
        final msg = msgs[idx];
        // Day separator
        final showDay = idx == 0 ||
            msgs[idx - 1].dayKey != msg.dayKey && msg.dayKey.isNotEmpty;

        return Column(
          children: [
            if (showDay && msg.dayLabel.isNotEmpty) _buildDaySeparator(msg.dayLabel),
            MessageBubble(
              message: msg,
              myUserId: _td.myUserId,
              onReply: () => _startReply(msg),
              onEdit: msg.out ? () => _startEdit(msg) : null,
              onDelete: msg.out ? () => _delete(msg) : null,
              onCopy: () {
                Clipboard.setData(ClipboardData(text: msg.text));
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                    content: Text('Скопировано'),
                    duration: Duration(seconds: 1)));
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildDaySeparator(String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(children: [
        const Expanded(child: Divider(color: Color(0xFF27272A))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Text(label, style: const TextStyle(
              color: Color(0xFF52525B), fontSize: 12)),
        ),
        const Expanded(child: Divider(color: Color(0xFF27272A))),
      ]),
    );
  }

  Widget _buildCompose() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0F),
        border: Border(top: BorderSide(color: Color(0xFF1F1F28))),
      ),
      child: Column(
        children: [
          if (_replyToText != null || _editId != null)
            _buildReplyBar(),
          Padding(
            padding: EdgeInsets.only(
              left: 8, right: 8, top: 8,
              bottom: MediaQuery.of(context).padding.bottom + 8,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(maxHeight: 120),
                    decoration: BoxDecoration(
                      color: const Color(0xFF141418),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: const Color(0xFF27272A)),
                    ),
                    child: TextField(
                      controller: _inputCtrl,
                      focusNode: _inputFocus,
                      maxLines: null,
                      style: const TextStyle(color: Colors.white, fontSize: 15),
                      decoration: const InputDecoration(
                        hintText: 'Сообщение...',
                        hintStyle: TextStyle(color: Color(0xFF3F3F46)),
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        border: InputBorder.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                GestureDetector(
                  onTap: _send,
                  child: Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: const LinearGradient(
                          colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
                      boxShadow: [BoxShadow(
                        color: const Color(0xFFF97316).withOpacity(0.3),
                        blurRadius: 8,
                      )],
                    ),
                    child: const Icon(Icons.send_rounded,
                        color: Colors.white, size: 20),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildReplyBar() {
    final isEdit = _editId != null;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 8, 0),
      child: Row(
        children: [
          Container(width: 3, height: 36,
              color: const Color(0xFFF97316),
              margin: const EdgeInsets.only(right: 10)),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(isEdit ? 'Редактировать' : 'Ответить',
                    style: const TextStyle(
                        color: Color(0xFFF97316), fontSize: 12,
                        fontWeight: FontWeight.w600)),
                Text(_replyToText ?? _inputCtrl.text,
                    style: const TextStyle(
                        color: Color(0xFF71717A), fontSize: 12),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          IconButton(
            onPressed: _cancelEdit,
            icon: const Icon(Icons.close_rounded,
                color: Color(0xFF71717A), size: 20),
          ),
        ],
      ),
    );
  }
}
