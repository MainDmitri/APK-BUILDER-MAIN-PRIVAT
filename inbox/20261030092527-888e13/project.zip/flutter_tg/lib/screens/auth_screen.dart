import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/td_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _ctrl = TextEditingController();
  bool _loading = false;
  String _error = '';

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_ctrl.text.trim().isEmpty) return;
    setState(() { _loading = true; _error = ''; });
    final td = context.read<TdService>();
    try {
      switch (td.authState) {
        case TdAuthState.waitingPhoneNumber:
          await td.sendPhoneNumber(_ctrl.text.trim());
        case TdAuthState.waitingCode:
          await td.sendCode(_ctrl.text.trim());
        case TdAuthState.waitingPassword:
          await td.sendPassword(_ctrl.text.trim());
        default:
          break;
      }
      _ctrl.clear();
    } catch (e) {
      setState(() { _error = e.toString(); });
    } finally {
      if (mounted) setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final td = context.watch<TdService>();
    final state = td.authState;

    String title, hint, btnLabel;
    switch (state) {
      case TdAuthState.waitingPhoneNumber:
        title = 'Введите номер телефона';
        hint = '+7 900 000 00 00';
        btnLabel = 'Получить код';
      case TdAuthState.waitingCode:
        title = 'Код из Telegram';
        hint = '12345';
        btnLabel = 'Подтвердить';
      case TdAuthState.waitingPassword:
        title = '2FA пароль';
        hint = '••••••';
        btnLabel = 'Войти';
      default:
        title = 'Авторизация...';
        hint = '';
        btnLabel = '';
    }

    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 72, height: 72,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
                  boxShadow: [BoxShadow(
                    color: const Color(0xFFF97316).withOpacity(0.4),
                    blurRadius: 24)],
                ),
                child: const Icon(Icons.lock_open_rounded,
                    color: Colors.white, size: 32),
              ).animate().scale(duration: 400.ms, curve: Curves.elasticOut),
              const SizedBox(height: 24),
              Text(title, style: const TextStyle(
                  color: Colors.white, fontSize: 20,
                  fontWeight: FontWeight.w700))
                  .animate().fadeIn(delay: 100.ms),
              const SizedBox(height: 8),
              const Text(
                'Сессия истекла — нужна повторная авторизация',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF71717A), fontSize: 13),
              ).animate().fadeIn(delay: 150.ms),
              const SizedBox(height: 28),
              Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF0F0F14),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF27272A)),
                ),
                child: TextField(
                  controller: _ctrl,
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                  keyboardType: state == TdAuthState.waitingPhoneNumber
                      ? TextInputType.phone
                      : TextInputType.number,
                  obscureText: state == TdAuthState.waitingPassword,
                  decoration: InputDecoration(
                    hintText: hint,
                    hintStyle: const TextStyle(color: Color(0xFF3F3F46)),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    border: InputBorder.none,
                  ),
                  onSubmitted: (_) => _submit(),
                ),
              ).animate().fadeIn(delay: 200.ms),
              if (_error.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(_error, style: const TextStyle(
                    color: Color(0xFFEF4444), fontSize: 12)),
              ],
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: GestureDetector(
                  onTap: _loading ? null : _submit,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(14),
                      gradient: const LinearGradient(
                          colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
                    ),
                    child: Center(
                      child: _loading
                          ? const SizedBox(
                              width: 20, height: 20,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2))
                          : Text(btnLabel, style: const TextStyle(
                              color: Colors.white, fontSize: 16,
                              fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
              ).animate().fadeIn(delay: 250.ms),
            ],
          ),
        ),
      ),
    );
  }
}
