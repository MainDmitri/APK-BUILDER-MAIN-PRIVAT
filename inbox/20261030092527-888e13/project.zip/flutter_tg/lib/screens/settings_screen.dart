import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../services/td_service.dart';
import '../services/sqlite_cache.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  Map<String, dynamic>? _dbStats;
  bool _loadingStats = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    try {
      final db = await SqliteCache.open();
      final s = await db.stats();
      if (mounted) setState(() { _dbStats = s; _loadingStats = false; });
    } catch (_) {
      if (mounted) setState(() => _loadingStats = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final td = context.watch<TdService>();
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: ListView(
        children: [
          _buildHeader(),
          _buildAccountCard(td),
          _buildSection('Соединение TDLib', [
            _buildStatRow('Статус', _authLabel(td.authState)),
            _buildStatRow('API ID', '21099690'),
            _buildStatRow('Режим', 'Нативный TDLib'),
          ]),
          _buildSection('Кэш SQLite', [
            if (_loadingStats)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                    child: CircularProgressIndicator(
                        color: Color(0xFFF97316), strokeWidth: 2)),
              )
            else if (_dbStats != null) ...[
              _buildStatRow('Диалогов',
                  '${_dbStats!['chats'] ?? 0}'),
              _buildStatRow('Сообщений',
                  '${_dbStats!['messages'] ?? 0}'),
              _buildStatRow('С медиа',
                  '${_dbStats!['with_media'] ?? 0}'),
            ] else
              _buildStatRow('Кэш', 'недоступен'),
          ]),
          _buildSection('Безопасность', [
            _buildLockTile(context),
          ]),
          _buildSection('Приложение', [
            _buildStatRow('Версия', '1.0.0'),
            _buildStatRow('Платформа', 'Android'),
            _buildStatRow('Режим', 'Нативный Flutter + TDLib'),
          ]),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  String _authLabel(TdAuthState s) {
    switch (s) {
      case TdAuthState.initial:
        return 'Инициализация...';
      case TdAuthState.waitingPhoneNumber:
        return 'Ожидание номера';
      case TdAuthState.waitingCode:
        return 'Ожидание кода';
      case TdAuthState.waitingPassword:
        return 'Ожидание пароля';
      case TdAuthState.ready:
        return '✓ Подключён';
      case TdAuthState.closed:
        return 'Закрыт';
      case TdAuthState.error:
        return '✗ Ошибка';
    }
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 8,
          bottom: 14, left: 20, right: 20),
      child: const Row(
        children: [
          Icon(Icons.settings_rounded, color: Color(0xFFF97316), size: 24),
          SizedBox(width: 12),
          Text('Настройки',
              style: TextStyle(color: Colors.white, fontSize: 20,
                  fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _buildAccountCard(TdService td) {
    final isReady = td.authState == TdAuthState.ready;
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1A1A2E), Color(0xFF16213E)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
            color: const Color(0xFFF97316).withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFF97316).withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 56, height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFF97316), Color(0xFFEA580C)],
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFF97316).withOpacity(0.4),
                  blurRadius: 12,
                ),
              ],
            ),
            child: const Center(
              child: Icon(Icons.person_rounded,
                  color: Colors.white, size: 28),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Telegram аккаунт',
                    style: TextStyle(color: Colors.white, fontSize: 16,
                        fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  isReady ? 'Сессия активна' : 'Используется кэш',
                  style: const TextStyle(
                      color: Color(0xFF71717A), fontSize: 13),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: isReady
                  ? const Color(0xFF22C55E).withOpacity(0.2)
                  : const Color(0xFFF97316).withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                  color: isReady
                      ? const Color(0xFF22C55E).withOpacity(0.5)
                      : const Color(0xFFF97316).withOpacity(0.5)),
            ),
            child: Text(isReady ? 'Online' : 'Cache',
                style: TextStyle(
                    color: isReady
                        ? const Color(0xFF22C55E)
                        : const Color(0xFFF97316),
                    fontSize: 12,
                    fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    ).animate().fadeIn(duration: 300.ms).scale(
        begin: const Offset(0.97, 0.97), end: const Offset(1, 1));
  }

  Widget _buildSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, top: 20, bottom: 8),
          child: Text(title.toUpperCase(),
              style: const TextStyle(
                  color: Color(0xFF52525B),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.0)),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
            color: const Color(0xFF0F0F14),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFF1F1F28)),
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  Widget _buildStatRow(String label, String value, {bool mono = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(
                  color: Color(0xFFA1A1AA), fontSize: 15)),
          const Spacer(),
          Text(value,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontFamily: mono ? 'monospace' : null,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }

  Widget _buildLockTile(BuildContext context) {
    return ListTile(
      contentPadding:
          const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      leading: Container(
        width: 36, height: 36,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFFEF4444).withOpacity(0.2),
        ),
        child: const Icon(Icons.lock_rounded,
            color: Color(0xFFEF4444), size: 18),
      ),
      title: const Text('Заблокировать приложение',
          style: TextStyle(
              color: Color(0xFFEF4444), fontSize: 15)),
      subtitle: const Text('Вернёт к виду калькулятора',
          style: TextStyle(color: Color(0xFF71717A), fontSize: 12)),
      trailing: const Icon(Icons.arrow_forward_ios_rounded,
          color: Color(0xFF3F3F46), size: 14),
      onTap: () {
        context.read<AppState>().lock();
        Navigator.of(context).popUntil((r) => r.isFirst);
      },
    );
  }
}
