#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Telegram CloudCode v3.6 - Mobile Pro Edition (Android Optimized)

Изменения v3.6:
  • Просмотр и сохранение одноразовых (view-once) фото
  • Специальная карточка вместо "неподдерживаемый тип" для view-once
  • Улучшенный cyberpunk-дизайн (темнее, неоновые акценты)
  • Бейдж 1× на одноразовых медиа + автосохранение в кэш при просмотре
Изменения v3.5:
  • SQLite-кэш ВСЕХ сообщений → читаем историю, даже когда клиент офлайн
  • Страница /cached — список сохранённых чатов (в т.ч. удалённых)
  • Фильтр "только мои сообщения" (only_me) + страница /my
  • Страница /adult — поиск 18+ сообщений среди своих
Изменения v3.4:
  • История: убраны дыры при подгрузке старых сообщений
  • max_id + дедуп по id, страницы по 60, IntersectionObserver + сохранение скролла
  • Фото не попадают в Галерею Android
  • Просмотр стикерпака + отправка стикера из пака
"""
import asyncio
import os
import re
import atexit
import threading
import hashlib
import json
import tempfile
import shutil
import zipfile
import mimetypes
import traceback
import sqlite3
from datetime import datetime
from functools import wraps
from urllib.parse import quote

from flask import Flask, jsonify, redirect, request, send_file, Response
from telethon import TelegramClient, errors
from telethon.tl.functions.contacts import BlockRequest, UnblockRequest, GetBlockedRequest
from telethon.tl.functions.messages import DeleteHistoryRequest, GetStickerSetRequest
from telethon.tl.types import (
    User, Chat, Channel,
    DocumentAttributeFilename, DocumentAttributeSticker,
    InputMessagesFilterPhotos, InputMessagesFilterDocument,
    InputMessagesFilterUrl, InputMessagesFilterMusic,
    InputStickerSetID, InputStickerSetShortName, InputStickerSetEmpty,
    InputDocument,
)

# --- Конфигурация ---
API_ID = int(os.environ.get("TG_API_ID", "21099690"))
API_HASH = os.environ.get("TG_API_HASH", "9c1130843fda5f6516d7c8197ec26281")
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# SESSION_DIR env позволяет Flutter-приложению указать папку с сессиями
SESSION_DIR = os.environ.get("SESSION_DIR", BASE_DIR)
SESSION_NAME = os.environ.get("TG_SESSION", "main")
SESSION_PATH = os.path.join(SESSION_DIR, SESSION_NAME)
MEDIA_DIR = os.path.join(SESSION_DIR, "tg_media")
UPLOAD_DIR = os.path.join(SESSION_DIR, "tg_uploads")
STICKER_DIR = os.path.join(MEDIA_DIR, "stickers")
DB_PATH = os.path.join(SESSION_DIR, "cloudcode_cache.db")
os.makedirs(MEDIA_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(STICKER_DIR, exist_ok=True)


def _ensure_nomedia(*dirs):
    """Android: скрыть кэш от Медиахранилища / Галереи."""
    for d in dirs:
        try:
            os.makedirs(d, exist_ok=True)
            marker = os.path.join(d, ".nomedia")
            if not os.path.exists(marker):
                with open(marker, "wb") as fh:
                    fh.write(b"")
        except OSError:
            pass


_ensure_nomedia(MEDIA_DIR, UPLOAD_DIR, STICKER_DIR)
STICKER_DOC_CACHE = {}
PACK_SESSIONS = {}
SENDER_CACHE = {}
mimetypes.add_type("image/webp", ".webp")
mimetypes.add_type("video/webm", ".webm")
mimetypes.add_type("application/x-tgsticker", ".tgs")
HOST = os.environ.get("TG_HOST", "0.0.0.0")
PORT = int(os.environ.get("TG_PORT", "5000"))

# Список ключевых слов для поиска 18+ своих сообщений
ADULT_KEYWORDS = [
    "секс", "sex", "порно", "porno", "porn", "интим", "intim", "голая", "голый", "голые",
    "nude", "naked", "инцест", "incest", "минет", "blowjob", "анал", "anal",
    "оргазм", "orgasm", "эротик", "erotic", "эротика", "xxx", "ххх", "x-rated",
    "18+", "секстинг", "sexting", "пошл", "похоть", "трах", "fuck", "fucking",
    "сиськ", "tits", "попк", "ass", "киск", "pussy", "член", "cock", "dick",
    "возбуд", "arousal", "ласк", "ласкать", "мастурб", "masturb", "masturbation",
    "влагалищ", "vagina", "пенис", "penis", "сперм", "sperm", "cum", "cumshot",
    "шлюх", "slut", "whore", "блядь", "сука", "милф", "milf", "дроч", "дрочить",
    "hentai", "хентай", "yaoi", "яой", "лесби", "lesbi", "гей-секс", "bdsm",
    "bondage", "фетиш", "fetish", "эскорт", "escort", "минет", "орал", "oral",
    "стриптиз", "striptease", "транс", "trans", "she male", "shemale",
    "изнасил", "rape", "жёстк", "жёсткий секс", "групповух", "оргия", "orgy",
]

app = Flask(__name__)
loop = asyncio.new_event_loop()
client = TelegramClient(
    SESSION_PATH, API_ID, API_HASH,
    device_model="IPhone 16", system_version="ios",
    app_version="6.2 Enterprise", lang_code="ru", system_lang_code="ru-RU",
)
state = {
    "phase": "boot",
    "message": "Инициализация подсистем...",
    "qr_url": "", "qr_html": "", "me": None, "error": "",
    "pinned": set(), "archived": set(),
}


def run_coro(coro, timeout=120):
    fut = asyncio.run_coroutine_threadsafe(coro, loop)
    return fut.result(timeout=timeout)


def on_exit():
    try:
        if client.is_connected():
            try:
                run_coro(client.disconnect(), timeout=10)
            except Exception:
                pass
    except Exception:
        pass
    try:
        if loop.is_running():
            loop.call_soon_threadsafe(loop.stop)
    except Exception:
        pass


atexit.register(on_exit)


def run_loop():
    asyncio.set_event_loop(loop)
    loop.run_forever()


threading.Thread(target=run_loop, daemon=True).start()


# ==================== SQLite cache ====================
def _db():
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    return con


def db_init():
    try:
        con = _db()
        con.executescript("""
            CREATE TABLE IF NOT EXISTS cached_messages (
                chat_id INTEGER NOT NULL,
                msg_id INTEGER NOT NULL,
                date TEXT,
                sender TEXT,
                sender_username TEXT,
                text TEXT,
                out INTEGER DEFAULT 0,
                media_html TEXT,
                day_key TEXT,
                day_label TEXT,
                has_media INTEGER DEFAULT 0,
                PRIMARY KEY (chat_id, msg_id)
            );
            CREATE INDEX IF NOT EXISTS idx_cm_chat ON cached_messages(chat_id, msg_id);
            CREATE INDEX IF NOT EXISTS idx_cm_chat_out ON cached_messages(chat_id, out);
            CREATE TABLE IF NOT EXISTS cached_chats (
                chat_id INTEGER PRIMARY KEY,
                title TEXT,
                username TEXT,
                kind TEXT,
                last_seen TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_cc_title ON cached_chats(title);
            CREATE INDEX IF NOT EXISTS idx_cm_has_media ON cached_messages(chat_id, has_media, msg_id);
        """)
        con.commit()
        con.close()
    except Exception as e:
        print(f"[DB] init error: {e}", flush=True)


db_init()


def db_save_messages(chat_id, messages, chat_title=None, chat_username=None, chat_kind=None):
    """Сохранить сообщения и метаданные чата в локальный кэш."""
    if not messages and not chat_title:
        return
    try:
        con = _db()
        cur = con.cursor()
        for m in messages or []:
            mid = m.get("id")
            if not mid:
                continue
            cur.execute("""
                INSERT OR REPLACE INTO cached_messages
                (chat_id, msg_id, date, sender, sender_username, text, out,
                 media_html, day_key, day_label, has_media)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (
                chat_id, mid, m.get("date") or "", m.get("sender") or "",
                m.get("sender_username") or "", m.get("text") or "",
                1 if m.get("out") else 0, m.get("media_html") or "",
                m.get("day_key") or "", m.get("day_label") or "",
                1 if m.get("media_html") else 0
            ))
        if chat_title:
            cur.execute("""
                INSERT INTO cached_chats (chat_id, title, username, kind, last_seen)
                VALUES (?,?,?,?,?)
                ON CONFLICT(chat_id) DO UPDATE SET
                    title=COALESCE(excluded.title, title),
                    username=COALESCE(excluded.username, username),
                    kind=COALESCE(excluded.kind, kind),
                    last_seen=excluded.last_seen
            """, (chat_id, chat_title, chat_username, chat_kind, datetime.now().isoformat()))
        con.commit()
        con.close()
    except Exception as e:
        print(f"[DB] save error: {e}", flush=True)


def db_load_messages(chat_id, before_id=None, after_id=None, limit=60, only_me=False, search=None):
    """Загрузить сообщения из локального кэша."""
    out = []
    try:
        con = _db()
        cur = con.cursor()
        sql = "SELECT * FROM cached_messages WHERE chat_id=?"
        args = [chat_id]
        if before_id:
            sql += " AND msg_id < ?"
            args.append(before_id)
        if after_id:
            sql += " AND msg_id > ?"
            args.append(after_id)
        if only_me:
            sql += " AND out=1"
        if search:
            sql += " AND LOWER(text) LIKE ?"
            args.append(f"%{search.lower()}%")
        sql += " ORDER BY msg_id DESC LIMIT ?"
        args.append(limit)
        rows = cur.execute(sql, args).fetchall()
        rows = rows[::-1]
        for r in rows:
            out.append({
                "id": r["msg_id"], "date": r["date"], "sender": r["sender"],
                "sender_username": r["sender_username"], "text": r["text"],
                "raw_text": r["text"], "out": bool(r["out"]),
                "media_html": r["media_html"] or "",
                "day_key": r["day_key"] or "", "day_label": r["day_label"] or "",
                "sender_id": None, "reactions": [],
            })
        con.close()
    except Exception as e:
        print(f"[DB] load error: {e}", flush=True)
    return out


def db_load_media_messages(chat_id, media_type=None, limit=120, before_id=None):
    """Load only messages with media from cache. media_type: 'photo','video','one_time',None=all."""
    out = []
    try:
        con = _db()
        cur = con.cursor()
        sql = "SELECT * FROM cached_messages WHERE chat_id=? AND has_media=1"
        args = [chat_id]
        if before_id:
            sql += " AND msg_id < ?"
            args.append(before_id)
        if media_type == "photo":
            sql += " AND (media_html LIKE '%<img%' OR media_html LIKE '%msg-photo%') AND media_html NOT LIKE '%ot-card%' AND media_html NOT LIKE '%video%'"
        elif media_type == "video":
            sql += " AND (media_html LIKE '%<video%' OR media_html LIKE '%video%')"
        elif media_type == "one_time":
            sql += " AND media_html LIKE '%ot-card%'"
        sql += " ORDER BY msg_id DESC LIMIT ?"
        args.append(limit)
        rows = cur.execute(sql, args).fetchall()
        for r in rows:
            out.append({
                "id": r["msg_id"], "date": r["date"], "sender": r["sender"],
                "sender_username": r["sender_username"], "text": r["text"] or "",
                "out": bool(r["out"]), "media_html": r["media_html"] or "",
                "day_key": r["day_key"] or "", "day_label": r["day_label"] or "",
            })
        con.close()
    except Exception as e:
        print(f"[DB] media load error: {e}", flush=True)
    return out


def db_count_media(chat_id):
    """Return counts of media by type for a chat."""
    counts = {"all": 0, "photo": 0, "video": 0, "one_time": 0}
    try:
        con = _db()
        cur = con.cursor()
        rows = cur.execute(
            "SELECT media_html FROM cached_messages WHERE chat_id=? AND has_media=1", (chat_id,)
        ).fetchall()
        for r in rows:
            mh = r["media_html"] or ""
            counts["all"] += 1
            if "ot-card" in mh:
                counts["one_time"] += 1
            elif "<video" in mh or "video" in mh.lower():
                counts["video"] += 1
            else:
                counts["photo"] += 1
        con.close()
    except Exception as e:
        print(f"[DB] count_media error: {e}", flush=True)
    return counts


def db_list_chats():
    out = []
    try:
        con = _db()
        cur = con.cursor()
        rows = cur.execute("SELECT * FROM cached_chats ORDER BY last_seen DESC").fetchall()
        for r in rows:
            cnt = cur.execute("SELECT COUNT(*) FROM cached_messages WHERE chat_id=?",
                              (r["chat_id"],)).fetchone()[0]
            mine = cur.execute("SELECT COUNT(*) FROM cached_messages WHERE chat_id=? AND out=1",
                               (r["chat_id"],)).fetchone()[0]
            out.append({
                "id": r["chat_id"], "title": r["title"] or f"Чат {r['chat_id']}",
                "username": r["username"], "kind": r["kind"] or "unknown",
                "count": cnt, "mine_count": mine, "last_seen": r["last_seen"] or "",
            })
        con.close()
    except Exception as e:
        print(f"[DB] list error: {e}", flush=True)
    return out


def db_get_chat(chat_id):
    try:
        con = _db()
        cur = con.cursor()
        r = cur.execute("SELECT * FROM cached_chats WHERE chat_id=?", (chat_id,)).fetchone()
        con.close()
        if r:
            return {"title": r["title"], "username": r["username"], "kind": r["kind"]}
    except Exception as e:
        print(f"[DB] get error: {e}", flush=True)
    return None


def db_search_adult(limit=300):
    """Найти свои сообщения с 18+ ключевыми словами."""
    out = []
    try:
        con = _db()
        cur = con.cursor()
        clauses = " OR ".join(["LOWER(text) LIKE ?"] * len(ADULT_KEYWORDS))
        args = [f"%{k.lower()}%" for k in ADULT_KEYWORDS]
        sql = (f"SELECT * FROM cached_messages WHERE out=1 AND ({clauses}) "
               f"ORDER BY msg_id DESC LIMIT ?")
        args.append(limit)
        rows = cur.execute(sql, args).fetchall()
        titles = {r["chat_id"]: (r["title"] or f"Чат {r['chat_id']}")
                  for r in cur.execute("SELECT chat_id, title FROM cached_chats").fetchall()}
        for r in rows:
            matched = [k for k in ADULT_KEYWORDS if k.lower() in (r["text"] or "").lower()]
            out.append({
                "id": r["msg_id"], "chat_id": r["chat_id"],
                "chat_title": titles.get(r["chat_id"], f"Чат {r['chat_id']}"),
                "date": r["date"], "sender": r["sender"],
                "text": r["text"], "raw_text": r["text"], "out": bool(r["out"]),
                "media_html": r["media_html"] or "",
                "day_key": r["day_key"] or "", "day_label": r["day_label"] or "",
                "matched": matched[:5],
            })
        con.close()
    except Exception as e:
        print(f"[DB] adult search error: {e}", flush=True)
    return out


def db_stats():
    try:
        con = _db()
        cur = con.cursor()
        total = cur.execute("SELECT COUNT(*) FROM cached_messages").fetchone()[0]
        mine = cur.execute("SELECT COUNT(*) FROM cached_messages WHERE out=1").fetchone()[0]
        chats = cur.execute("SELECT COUNT(*) FROM cached_chats").fetchone()[0]
        size = os.path.getsize(DB_PATH) if os.path.exists(DB_PATH) else 0
        con.close()
        return {"total": total, "mine": mine, "chats": chats, "size": size}
    except Exception:
        return {"total": 0, "mine": 0, "chats": 0, "size": 0}


# --- Утилиты ---
def avatar_color(name):
    if not name:
        return "#6366f1"
    h = int(hashlib.md5(name.encode()).hexdigest()[:6], 16)
    colors = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4",
              "#3b82f6", "#8b5cf6", "#ec4899", "#14b8a6"]
    return colors[h % len(colors)]


def avatar_svg(name, size=40):
    color = avatar_color(name or "?")
    name = (name or "?").strip()
    parts = name.split()
    initials = (parts[0][0] + parts[1][0]).upper() if len(parts) >= 2 else (parts[0][:2] if parts else "??").upper()
    font_size = size * 0.4
    return f'''<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}" xmlns="http://www.w3.org/2000/svg" class="avatar">
<rect width="{size}" height="{size}" rx="{size//2}" fill="{color}"/>
<text x="50%" y="50%" dy=".35em" text-anchor="middle" fill="white"
font-family="Inter, sans-serif" font-weight="600" font-size="{font_size}">{esc(initials)}</text>
</svg>'''


def build_qr_html(url):
    try:
        import qrcode
        qr = qrcode.QRCode(box_size=1, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        matrix = qr.get_matrix()
        size = len(matrix)
        html = f'<div class="qr-container" style="grid-template-columns:repeat({size}, 1fr);">'
        for row in matrix:
            for col in row:
                html += f'<div style="background:{"#000" if col else "#fff"};"></div>'
        return html + "</div>"
    except Exception as e:
        return f"<pre style='color:var(--bad);'>{esc(str(e))}</pre>"


def _svg_icon_bytes():
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192">'
           '<rect width="192" height="192" rx="42" fill="#dc2626"/>'
           '<text x="96" y="128" font-family="sans-serif" font-weight="800" '
           'font-size="112" text-anchor="middle" fill="#fff">T</text></svg>')
    return svg.encode("utf-8")


# --- SVG Иконки ---
ICONS = {
    "search": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>',
    "send": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>',
    "paperclip": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 17.93 8.8l-8.58 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>',
    "smile": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/></svg>',
    "copy": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>',
    "reply": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>',
    "trash": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/></svg>',
    "check": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
    "x": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',
    "users": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
    "user": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
    "inbox": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/></svg>',
    "megaphone": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>',
    "settings": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>',
    "menu": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>',
    "arrow-left": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>',
    "image": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>',
    "file": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>',
    "music": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
    "link": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
    "ghost": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 10h.01"/><path d="M15 10h.01"/><path d="M12 2a8 8 0 0 0-8 8v12l3-3 2 3 3-3 2 3 3-3 2 3 1-3V10a8 8 0 0 0-8-8z"/><path d="M16 14h.01"/></svg>',
    "download": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>',
    "command": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>',
    "clock": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
    "bell-off": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.7 3A6 6 0 0 1 18 8a7.2 7.2 0 0 1-.5 2.6l.9.9 2.2 2.2L18 16.5"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/><path d="M2 8c0-2.2.7-4.3 2-6"/><path d="M22 8a8.3 8.3 0 0 0-1.8-4.4"/><path d="M4 14.5V16a2 2 0 0 0 2 2h.4"/><path d="M16.5 18H16a2 2 0 0 1-2-2v-1.5"/><path d="m2 2 20 20"/></svg>',
    "plus": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>',
    "zap": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
    "server": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="8" x="2" y="2" rx="2" ry="2"/><rect width="20" height="8" x="2" y="14" rx="2" ry="2"/><line x1="6" x2="6.01" y1="6" y2="6"/><line x1="6" x2="6.01" y1="18" y2="18"/></svg>',
    "at-sign": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8"/></svg>',
    "pin": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16h14v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>',
    "logout": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>',
    "more": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg>',
    "chevron-down": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>',
    "chevron-up": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>',
    "chevron-left": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>',
    "chevron-right": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>',
    "eye": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>',
    "play": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="6 3 20 12 6 21 6 3"/></svg>',
    "video": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5"/><rect x="2" y="6" width="14" height="12" rx="2"/></svg>',
    "loader": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>',
    "edit": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>',
    "forward": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 17 20 12 15 7"/><path d="M4 18v-2a4 4 0 0 1 4-4h12"/></svg>',
    "mic": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-10"/><line x1="12" x2="12" y1="19" y2="22"/></svg>',
    "wifi-off": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 2l20 20"/><path d="M8.5 16.5a5 5 0 0 1 7 0"/><path d="M2 8.82a15 15 0 0 1 4.17-2.65"/><path d="M10.66 5c4.01-.36 8.14.9 11.34 3.76"/><path d="M16.85 11.25a10 10 0 0 1 2.22 1.68"/><path d="M5 12.55a11 11 0 0 1 5.17-2.39"/><line x1="12" x2="12.01" y1="20" y2="20"/></svg>',
    "bomb": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="13" r="8"/><path d="M14.5 5.5 17 3"/><path d="m16 6 3-3"/><path d="M15 9l1-1"/><path d="M11 21v-3"/><path d="m18 4 2 2"/><path d="m20 2 1 1"/></svg>',
    "shield-off": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m2 2 20 20"/></svg>',
    "flame": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/></svg>',
    "database": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/></svg>',
    "heart": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>',
}


def icon(name, cls=""):
    return f'<span class="icon {cls}">{ICONS.get(name, "")}</span>'


# --- CSS ---
CSS = """
:root {
--bg:#07070a; --bg-elevated:#0f0f14; --panel:rgba(16,16,22,0.92); --panel-solid:#121218;
--sidebar:rgba(10,10,14,0.95); --text:#f4f4f5; --text-dim:#a1a1aa; --text-muted:#71717a;
--acc:#f97316; --acc-soft:rgba(249,115,22,0.15); --acc-glow:rgba(249,115,22,0.55);
--neon:#22d3ee; --neon-soft:rgba(34,211,238,0.12);
--border:rgba(255,255,255,0.08); --border-hover:rgba(249,115,22,0.4);
--msg-in:#16161c; --msg-out:linear-gradient(135deg,#9a3412 0%,#ea580c 100%);
--bad:#ef4444; --ok:#22c55e; --warn:#eab308;
--font:"Inter",-apple-system,BlinkMacSystemFont,"Segoe UI",system-ui,sans-serif;
--mono:"JetBrains Mono","Fira Code","SF Mono",monospace;
--radius:14px; --radius-sm:10px; --radius-lg:18px; --sidebar-w:360px;
--transition:cubic-bezier(0.4,0,0.2,1);
--bnav-h:0px;
}

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent;}
html,body{height:100%;overscroll-behavior-y:none;}
body{
background:var(--bg);color:var(--text);font-family:var(--font);font-size:14.5px;line-height:1.5;
overflow:hidden;-webkit-font-smoothing:antialiased;
background-image:radial-gradient(at 20% 0%,rgba(249,115,22,0.08) 0px,transparent 50%),
radial-gradient(at 80% 100%,rgba(139,92,246,0.06) 0px,transparent 50%);
background-attachment:fixed;
}
.icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;flex-shrink:0;}
.icon svg{width:100%;height:100%;pointer-events:none;}
.icon-lg{width:20px;height:20px;} .icon-sm{width:14px;height:14px;}
.avatar{flex-shrink:0;box-shadow:0 2px 8px rgba(0,0,0,0.3);}
::-webkit-scrollbar{width:6px;height:6px;}
::-webkit-scrollbar-track{background:transparent;}
::-webkit-scrollbar-thumb{background:#2a2a30;border-radius:3px;}
.app{display:flex;height:100%;width:100%;overflow:hidden;height:100dvh;}
.sidebar{width:var(--sidebar-w);flex-shrink:0;background:var(--sidebar);backdrop-filter:blur(24px);
border-right:1px solid var(--border);display:flex;flex-direction:column;
transition:transform 0.3s var(--transition),width 0.3s var(--transition);z-index:50;}
.main{flex:1;display:flex;flex-direction:column;min-width:0;background:var(--bg);position:relative;}
.sb-header{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;}
.sb-brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:15px;color:var(--text);text-decoration:none;flex:1;}
.sb-brand-mark{width:28px;height:28px;background:linear-gradient(135deg,var(--acc),#c2410c);border-radius:8px;
display:flex;align-items:center;justify-content:center;color:#fff;font-size:13px;font-weight:800;}
.sb-me{display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(249,115,22,0.06);
border:1px solid rgba(249,115,22,0.15);border-radius:var(--radius-sm);margin:12px 14px;}
.sb-me-info{flex:1;min-width:0;}
.sb-me-name{font-weight:600;font-size:13px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.sb-me-user{font-size:11px;color:var(--acc);font-family:var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.sb-search{padding:0 14px 12px;position:relative;}
.sb-search-wrap{position:relative;display:flex;align-items:center;}
.sb-search-input{width:100%;background:rgba(255,255,255,0.04);border:1px solid var(--border);color:var(--text);
padding:9px 12px 9px 36px;border-radius:var(--radius-sm);font-size:16px;font-family:var(--font);outline:none;transition:all 0.2s;}
.sb-search-icon{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--text-muted);pointer-events:none;}
.sb-search-kbd{position:absolute;right:8px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,0.05);
border:1px solid var(--border);color:var(--text-muted);font-family:var(--mono);font-size:10.5px;padding:2px 6px;border-radius:4px;pointer-events:none;}
.sb-tabs{display:flex;padding:0 14px 10px;gap:4px;overflow-x:auto;scrollbar-width:none;}
.sb-tab{padding:6px 11px;border-radius:999px;font-size:12.5px;font-weight:500;color:var(--text-dim);text-decoration:none;
white-space:nowrap;display:inline-flex;align-items:center;gap:5px;border:1px solid transparent;}
.sb-tab.active{background:var(--acc-soft);color:var(--acc);border-color:rgba(249,115,22,0.25);}
.sb-list{flex:1;overflow-y:auto;overflow-x:hidden;-webkit-overflow-scrolling:touch;}
.sb-item{display:flex;gap:12px;padding:10px 14px;text-decoration:none;color:inherit;border-left:3px solid transparent;position:relative;align-items:center;}
.sb-item.active{background:rgba(249,115,22,0.08);border-left-color:var(--acc);}
.sb-item-body{flex:1;min-width:0;}
.sb-item-top{display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:2px;}
.sb-item-title{font-weight:600;font-size:14px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;}
.sb-item-time{font-size:11px;color:var(--text-muted);font-family:var(--mono);flex-shrink:0;}
.sb-item-preview{color:var(--text-dim);font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.sb-badge{background:var(--acc);color:#fff;padding:1px 7px;border-radius:999px;font-size:10.5px;font-weight:700;font-family:var(--mono);margin-left:6px;}
.sb-empty{padding:40px 20px;text-align:center;color:var(--text-muted);font-size:13px;}
.sb-footer{border-top:1px solid var(--border);padding:10px 12px;display:flex;gap:6px;flex-wrap:wrap;}
.sb-footer-btn{flex:1;min-width:calc(50% - 3px);background:rgba(255,255,255,0.03);border:1px solid var(--border);color:var(--text-dim);
padding:8px;border-radius:var(--radius-sm);font-size:12px;text-decoration:none;display:flex;align-items:center;justify-content:center;gap:6px;cursor:pointer;}
.sb-footer-btn:hover{border-color:var(--border-hover);}
.sb-footer-btn.destroy{background:linear-gradient(135deg,rgba(239,68,68,0.15),rgba(220,38,38,0.08));
border-color:rgba(239,68,68,0.4);color:#fca5a5;font-weight:700;}
.sb-footer-btn.destroy:hover{background:linear-gradient(135deg,rgba(239,68,68,0.25),rgba(220,38,38,0.15));color:#fff;}
.sb-footer-btn.cache{background:linear-gradient(135deg,rgba(59,130,246,0.12),rgba(37,99,235,0.06));
border-color:rgba(59,130,246,0.35);color:#93c5fd;font-weight:600;}
.sb-footer-btn.adult{background:linear-gradient(135deg,rgba(236,72,153,0.12),rgba(190,24,93,0.06));
border-color:rgba(236,72,153,0.35);color:#f9a8d4;font-weight:600;}
.mn-header{padding:14px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;
background:rgba(10,10,12,0.7);backdrop-filter:blur(16px);position:sticky;top:0;z-index:20;}
.mn-menu-btn{display:none;background:transparent;border:1px solid var(--border);color:var(--text);width:36px;height:36px;
border-radius:var(--radius-sm);cursor:pointer;align-items:center;justify-content:center;flex-shrink:0;text-decoration:none;}
.mn-title{font-weight:700;font-size:16px;flex:1;min-width:0;}
.mn-actions{display:flex;gap:6px;}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;
background:linear-gradient(135deg,var(--acc) 0%,#c2410c 100%);color:#fff;border:none;border-radius:var(--radius-sm);
padding:9px 16px;font-weight:600;font-family:var(--font);cursor:pointer;font-size:13.5px;text-decoration:none;
transition:transform 0.1s var(--transition);}
.btn:active{transform:scale(0.97);}
.btn-ghost,.btn-outline{background:transparent;border:1px solid var(--border);color:var(--text-dim);}
.btn-icon{width:36px;height:36px;padding:0;border-radius:var(--radius-sm);background:transparent;
border:1px solid var(--border);color:var(--text-dim);cursor:pointer;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;}
.btn-danger{background:transparent;border:1px solid rgba(239,68,68,0.3);color:var(--bad);}
.btn-destroy{background:linear-gradient(135deg,#dc2626 0%,#991b1b 100%);color:#fff;font-weight:800;
letter-spacing:0.05em;text-transform:uppercase;border:none;padding:14px 20px;font-size:14px;}
.btn-destroy:disabled{opacity:0.4;cursor:not-allowed;}
input,textarea,select{background:rgba(255,255,255,0.03);color:var(--text);border:1px solid var(--border);
border-radius:var(--radius-sm);padding:10px 14px;font-size:16px;font-family:var(--font);outline:none;}
textarea{resize:vertical;min-height:44px;}
.chat-wrap{flex:1;display:flex;flex-direction:column;min-height:0;}
.chat-scroll{flex:1;overflow-y:auto;overflow-x:hidden;padding:20px 24px;display:flex;flex-direction:column;gap:2px;
-webkit-overflow-scrolling:touch;overscroll-behavior-y:contain;touch-action:pan-y;}
.chat-group{display:flex;gap:10px;margin-bottom:14px;max-width:85%;animation:slideUp 0.3s ease-out;}
.chat-group.out{margin-left:auto;flex-direction:row-reverse;}
.chat-group-avatar{flex-shrink:0;padding-top:2px;}
.chat-group-body{flex:1;min-width:0;}
.chat-group-header{display:flex;align-items:center;gap:8px;margin-bottom:4px;font-size:12px;color:var(--text-dim);font-family:var(--mono);}
.chat-group.out .chat-group-header{justify-content:flex-end;}
.chat-group-name{font-weight:600;color:var(--acc);}
.msg-bubble{background:var(--msg-in);border-radius:14px;border-top-left-radius:4px;padding:10px 14px;font-size:14.5px;
word-wrap:break-word;position:relative;border:1px solid rgba(255,255,255,0.04);-webkit-user-select:text;user-select:text;}
.chat-group.out .msg-bubble{background:var(--msg-out);border-top-left-radius:14px;border-top-right-radius:4px;
border-color:rgba(249,115,22,0.25);color:#fff;}
.msg-bubble + .msg-bubble{margin-top:2px;}
.msg-bubble.selected{outline:2px solid var(--acc);}
.msg-bubble.ctx-target{outline:2px solid var(--acc-glow);}
@media (hover:hover) and (pointer:fine){
.msg-actions{position:absolute;top:6px;right:6px;display:flex;gap:2px;opacity:0;transform:translateY(-2px);
transition:all 0.2s;background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);border-radius:6px;padding:2px;border:1px solid rgba(255,255,255,0.08);}
.msg-bubble:hover .msg-actions{opacity:1;transform:translateY(0);}
.msg-action{background:transparent;border:none;color:var(--text-dim);width:26px;height:26px;display:flex;
align-items:center;justify-content:center;border-radius:4px;cursor:pointer;}
.msg-action:hover{color:var(--acc);background:var(--acc-soft);}
}
.msg-meta{display:flex;justify-content:flex-end;align-items:center;gap:6px;margin-top:4px;font-size:11px;
color:rgba(255,255,255,0.5);font-family:var(--mono);flex-wrap:wrap;}
.chat-group.out .msg-meta{color:rgba(255,255,255,0.75);}
.react-chips{display:inline-flex;gap:4px;margin-right:auto;}
.react-chip{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);border-radius:999px;
padding:1px 7px;font-size:11px;cursor:pointer;color:#fff;}
.react-chip:hover{background:var(--acc-soft);border-color:var(--acc);}
.msg-body img,.msg-body video{max-width:100%;border-radius:8px;margin-top:6px;display:block;cursor:pointer;}
.msg-body audio{width:100%;margin-top:6px;}
.msg-body code{background:rgba(0,0,0,0.5);padding:2px 6px;border-radius:4px;font-family:var(--mono);font-size:13px;color:#fdba74;}
.msg-body pre{background:rgba(0,0,0,0.5);padding:10px 12px;border-radius:8px;overflow-x:auto;margin:6px 0;}
.msg-body pre code{background:transparent;padding:0;border:none;color:#fff;}
.msg-body b{color:#fff;font-weight:700;}
.msg-body a{color:#fb923c;text-decoration:none;border-bottom:1px dashed rgba(251,146,60,0.4);}
.doc-link{display:inline-flex;align-items:center;gap:8px;margin-top:8px;background:rgba(0,0,0,0.4);padding:8px 12px;
border-radius:8px;text-decoration:none;color:#fff;font-weight:500;font-size:13px;border:1px solid rgba(255,255,255,0.1);}
.chat-empty{margin:auto;text-align:center;color:var(--text-muted);font-family:var(--mono);padding:40px 20px;}
.chat-input{border-top:1px solid var(--border);padding:12px 20px 14px;background:rgba(14,14,18,0.7);backdrop-filter:blur(16px);}
.chat-reply{display:flex;align-items:center;gap:10px;padding:8px 12px;background:rgba(249,115,22,0.06);
border-left:3px solid var(--acc);border-radius:var(--radius-sm);margin-bottom:8px;font-size:13px;}
.chat-reply-body{flex:1;min-width:0;}
.chat-reply-label{color:var(--acc);font-size:11px;font-family:var(--mono);margin-bottom:2px;}
.chat-reply-text{color:var(--text-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.chat-reply-close{background:transparent;border:none;color:var(--text-muted);cursor:pointer;padding:4px;display:flex;}
.chat-files{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;}
.file-chip{display:flex;align-items:center;gap:6px;background:var(--acc-soft);border:1px solid rgba(249,115,22,0.25);
padding:5px 8px;border-radius:6px;font-size:12px;font-family:var(--mono);color:var(--acc);}
.file-chip-name{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.file-chip-close{background:transparent;border:none;color:var(--acc);cursor:pointer;display:flex;opacity:0.7;}
.chat-input-row{display:flex;gap:8px;align-items:flex-end;background:rgba(255,255,255,0.03);
border:1px solid var(--border);border-radius:var(--radius);padding:6px 6px 6px 12px;}
.chat-input-field{flex:1;background:transparent !important;border:none !important;padding:8px 4px !important;
outline:none !important;box-shadow:none !important;resize:none;max-height:120px;line-height:1.5;
font-family:var(--font);font-size:16px;}
.chat-input-tools{display:flex;gap:2px;}
.chat-input-send{width:40px;height:40px;padding:0;border-radius:10px;flex-shrink:0;}
.chat-input-options{display:flex;gap:10px;margin-top:8px;padding:0 4px;align-items:center;flex-wrap:wrap;}
.opt-label{display:flex;align-items:center;gap:5px;font-size:12px;color:var(--text-muted);cursor:pointer;padding:4px 8px;border-radius:6px;}
.opt-label input[type="checkbox"]{accent-color:var(--acc);width:14px;height:14px;}
.opt-label input[type="datetime-local"]{background:rgba(0,0,0,0.3);color:var(--text);border:1px solid var(--border);
padding:3px 6px;border-radius:4px;font-family:var(--mono);font-size:11.5px;}
.opt-sep{width:1px;height:16px;background:var(--border);}
.ghost-banner{background:rgba(34,197,94,0.08);border:1px solid rgba(34,197,94,0.25);color:#4ade80;padding:8px 14px;
border-radius:var(--radius-sm);font-size:12.5px;display:flex;justify-content:space-between;align-items:center;
margin:0 24px 8px;font-family:var(--mono);}
.cache-banner{background:rgba(59,130,246,0.08);border:1px solid rgba(59,130,246,0.28);color:#93c5fd;padding:8px 14px;
border-radius:var(--radius-sm);font-size:12px;display:flex;gap:10px;align-items:center;
margin:0 24px 8px;font-family:var(--mono);flex-wrap:wrap;}
.cache-banner a{color:#93c5fd;text-decoration:none;border-bottom:1px dashed rgba(147,197,253,0.5);}
.onlyme-toggle{display:inline-flex;align-items:center;gap:6px;padding:7px 12px;border-radius:999px;
font-size:12px;font-weight:600;text-decoration:none;border:1px solid var(--border);color:var(--text-dim);
background:rgba(255,255,255,0.03);cursor:pointer;white-space:nowrap;}
.onlyme-toggle:hover{border-color:var(--border-hover);color:var(--text);}
.onlyme-toggle.active{background:rgba(249,115,22,0.15);border-color:rgba(249,115,22,0.5);color:var(--acc);}
.offline-banner{display:none;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;
padding:6px 14px;border-radius:var(--radius-sm);font-size:12px;margin:8px 24px 0;font-family:var(--mono);
align-items:center;gap:8px;}
body.offline .offline-banner{display:flex;}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.6);backdrop-filter:blur(4px);z-index:1000;
display:none;align-items:flex-start;justify-content:center;padding-top:15vh;}
.modal-overlay.active{display:flex;}
.modal{background:var(--panel-solid);border:1px solid var(--border);border-radius:var(--radius-lg);
width:min(560px,90vw);max-height:70vh;display:flex;flex-direction:column;box-shadow:0 25px 60px rgba(0,0,0,0.5);}
.modal-header{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.modal-input{flex:1;background:transparent !important;border:none !important;font-size:15px;padding:0 !important;outline:none !important;}
.modal-body{overflow-y:auto;padding:8px;-webkit-overflow-scrolling:touch;}
.modal-item{padding:10px 12px;border-radius:var(--radius-sm);cursor:pointer;display:flex;align-items:center;gap:12px;text-decoration:none;color:inherit;transition:background 0.15s;}
.modal-item:hover{background:rgba(255,255,255,0.05);}
.modal-item.selected{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.4);}
.modal-item-title{flex:1;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.modal-item-sub{color:var(--text-muted);font-size:12px;font-family:var(--mono);}
.modal-footer{padding:8px 14px;border-top:1px solid var(--border);font-size:11px;color:var(--text-muted);
display:flex;gap:14px;flex-wrap:wrap;font-family:var(--mono);}
.auth-wrap{height:100vh;height:100dvh;display:flex;align-items:center;justify-content:center;padding:20px;overflow-y:auto;}
.auth-card{background:var(--panel-solid);border:1px solid var(--border);border-radius:var(--radius-lg);padding:32px;width:min(420px,100%);}
.auth-brand{display:flex;align-items:center;gap:10px;margin-bottom:24px;}
.auth-title{font-size:20px;font-weight:700;margin-bottom:6px;}
.auth-sub{color:var(--acc);font-family:var(--mono);font-size:12.5px;margin-bottom:20px;}
.auth-error{color:var(--bad);font-size:13px;margin-bottom:12px;padding:8px 12px;background:rgba(239,68,68,0.08);
border:1px solid rgba(239,68,68,0.2);border-radius:var(--radius-sm);}
.auth-success{color:var(--ok);font-size:13px;margin-bottom:12px;padding:8px 12px;background:rgba(34,197,94,0.08);
border:1px solid rgba(34,197,94,0.2);border-radius:var(--radius-sm);}
.qr-container{display:grid;background:#fff;padding:16px;border-radius:var(--radius-sm);margin:16px auto;max-width:240px;aspect-ratio:1/1;}
.qr-url{font-size:10.5px;color:var(--text-muted);word-break:break-all;font-family:var(--mono);text-align:center;
margin-top:10px;padding:8px;background:rgba(0,0,0,0.3);border-radius:var(--radius-sm);}
.emoji-picker{position:absolute;bottom:100%;left:0;margin-bottom:8px;background:var(--panel-solid);
border:1px solid var(--border);border-radius:var(--radius-sm);padding:8px;width:280px;max-height:260px;
overflow-y:auto;box-shadow:0 15px 40px rgba(0,0,0,0.5);display:none;z-index:20;}
.emoji-picker.active{display:block;}
.emoji-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:4px;}
.emoji-btn{background:transparent;border:none;font-size:24px;cursor:pointer;padding:8px;border-radius:4px;line-height:1;}
.search-wrap,.settings-wrap{padding:20px;max-width:920px;margin:0 auto;overflow-y:auto;height:100%;-webkit-overflow-scrolling:touch;}
.search-result{background:var(--panel-solid);border:1px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:12px;}
.search-result-head{display:flex;justify-content:space-between;margin-bottom:8px;gap:10px;}
.search-result-chat{font-weight:600;color:#fff;font-size:13.5px;overflow:hidden;text-overflow:ellipsis;}
.search-result-date{font-size:11px;color:var(--text-muted);font-family:var(--mono);flex-shrink:0;}
.search-result-sender{font-size:12px;color:var(--acc);font-family:var(--mono);margin-bottom:8px;}
.search-result-body{background:rgba(0,0,0,0.3);padding:10px 14px;border-radius:var(--radius-sm);
border:1px solid var(--border);font-size:14px;word-break:break-word;}
mark{background:rgba(249,115,22,0.25);color:var(--acc);padding:0 3px;border-radius:3px;font-weight:600;}
mark.kw{background:rgba(236,72,153,0.3);color:#f9a8d4;}
.settings-section{margin-bottom:20px;}
.settings-section-title{font-size:12px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.08em;
font-family:var(--mono);margin-bottom:10px;font-weight:600;}
.settings-card{background:var(--panel-solid);border:1px solid var(--border);border-radius:var(--radius-sm);padding:18px;}
.settings-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border);font-size:13.5px;gap:12px;}
.settings-row:last-child{border-bottom:none;}
.settings-row-label{color:var(--text-dim);}
.settings-row-value{color:var(--text);font-family:var(--mono);font-size:12.5px;text-align:right;word-break:break-all;}
#toast-container{position:fixed;bottom:calc(24px + env(safe-area-inset-bottom));right:24px;z-index:9999;display:flex;flex-direction:column;gap:8px;pointer-events:none;max-width:calc(100vw - 40px);}
.toast{background:var(--panel-solid);color:#fff;padding:12px 16px;border-radius:var(--radius-sm);
border:1px solid var(--border);border-left:3px solid var(--acc);font-size:13px;box-shadow:0 10px 30px rgba(0,0,0,0.5);
display:flex;align-items:center;gap:10px;font-family:var(--font);pointer-events:auto;min-width:220px;animation:slideUp 0.25s ease-out;}
.toast.ok{border-left-color:var(--ok);} .toast.error{border-left-color:var(--bad);}
.toast .icon{color:var(--acc);} .toast.ok .icon{color:var(--ok);} .toast.error .icon{color:var(--bad);}
.skeleton{background:linear-gradient(90deg,rgba(255,255,255,0.04) 0%,rgba(255,255,255,0.08) 50%,rgba(255,255,255,0.04) 100%);
background-size:200% 100%;border-radius:6px;animation:shimmer 1.5s infinite;}
@keyframes shimmer{0%{background-position:200% 0;}100%{background-position:-200% 0;}}
.skel-line{height:12px;margin-bottom:6px;} .skel-avatar{width:40px;height:40px;border-radius:50%;}
.skel-item{display:flex;gap:12px;padding:12px 14px;} .skel-body{flex:1;}
.day-separator{display:flex;align-items:center;justify-content:center;margin:14px 0 10px;position:sticky;top:8px;z-index:5;pointer-events:none;}
.day-separator span{background:rgba(20,20,24,0.85);backdrop-filter:blur(8px);border:1px solid var(--border);
color:var(--text-dim);font-size:11.5px;font-family:var(--mono);font-weight:500;padding:4px 14px;border-radius:999px;}
.history-loader{display:flex;justify-content:center;padding:6px 0 14px;}
.history-loader button{display:inline-flex;align-items:center;gap:7px;background:rgba(255,255,255,0.04);
border:1px solid var(--border);color:var(--text-dim);padding:7px 18px;border-radius:999px;font-size:12.5px;
font-family:var(--font);cursor:pointer;transition:all 0.2s;}
.history-loader button:hover:not(:disabled){border-color:var(--acc);color:var(--acc);background:var(--acc-soft);}
.history-loader button:disabled{opacity:0.5;cursor:default;}
.history-loader .spin{animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
.history-end{text-align:center;color:var(--text-muted);font-size:11.5px;font-family:var(--mono);padding:10px 0 4px;}
.mn-title-wrap{display:flex;flex-direction:column;flex:1;min-width:0;}
.mn-title-sub{font-size:11.5px;color:var(--text-muted);font-family:var(--mono);display:flex;align-items:center;gap:4px;flex-wrap:wrap;}
.copy-field{display:inline-flex;align-items:center;gap:6px;cursor:pointer;border-radius:6px;padding:2px 6px;margin-left:-6px;transition:background 0.15s;}
.copy-field:hover{background:var(--acc-soft);}
.menu-wrap{position:relative;}
.dropdown{position:absolute;right:0;top:calc(100% + 6px);min-width:240px;background:var(--panel-solid);
border:1px solid var(--border);border-radius:var(--radius-sm);box-shadow:0 15px 40px rgba(0,0,0,0.5);
padding:6px;display:none;z-index:60;}
.dropdown.active{display:block;animation:slideUp 0.15s ease-out;}
.dropdown-item{display:flex;align-items:center;gap:10px;width:100%;background:transparent;border:none;
color:var(--text-dim);padding:9px 12px;border-radius:6px;font-size:13px;font-family:var(--font);cursor:pointer;text-align:left;text-decoration:none;}
.dropdown-item:hover{background:rgba(255,255,255,0.05);color:#fff;}
.dropdown-item.danger{color:var(--bad);}
.dropdown-item.danger:hover{background:rgba(239,68,68,0.1);color:var(--bad);}
.dropdown-item.adult{color:#f9a8d4;}
.dropdown-item.adult:hover{background:rgba(236,72,153,0.1);color:#f9a8d4;}
.dropdown-sep{height:1px;background:var(--border);margin:5px 4px;}
.sticker-box{display:flex;flex-direction:column;align-items:flex-start;gap:4px;margin-top:6px;}
.sticker-media{width:180px;height:180px;object-fit:contain;border-radius:8px;cursor:pointer;}
lottie-player{width:180px;height:180px;}
.sticker-dl{font-size:11px;color:var(--text-muted);font-family:var(--mono);text-decoration:none;opacity:0.7;}
.sticker-dl:hover{color:var(--acc);opacity:1;}
.chat-group.out .sticker-dl{color:rgba(255,255,255,0.6);}
.chat-fab{position:absolute;right:22px;bottom:118px;width:44px;height:44px;border-radius:50%;background:var(--panel-solid);
border:1px solid var(--border);color:var(--text);cursor:pointer;display:none;align-items:center;justify-content:center;
box-shadow:0 8px 24px rgba(0,0,0,0.5);z-index:10;transition:all 0.2s;}
.chat-fab:hover{border-color:var(--acc);color:var(--acc);}
.fab-count{position:absolute;top:-7px;right:-7px;background:var(--acc);color:#fff;font-size:10px;font-weight:700;
border-radius:999px;padding:1px 7px;font-family:var(--mono);}
.sb-pin{color:var(--acc);display:inline-flex;margin-right:5px;vertical-align:-2px;}
.exp-form{padding:16px;display:flex;flex-direction:column;gap:12px;}
.exp-form label{display:flex;flex-direction:column;gap:6px;font-size:12.5px;color:var(--text-dim);font-weight:500;}
.exp-form label.row{flex-direction:row;align-items:center;gap:8px;cursor:pointer;}
.exp-hint{font-size:11.5px;color:var(--text-muted);font-family:var(--mono);}
.exp-actions{display:flex;gap:8px;padding:0 16px 16px;}
.exp-actions .btn{flex:1;justify-content:center;}
.username-chip{display:inline-flex;align-items:center;gap:4px;background:transparent;border:1px solid transparent;
border-radius:6px;padding:1px 6px;color:var(--acc);font-family:var(--mono);font-size:11.5px;cursor:pointer;transition:all 0.15s;}
.username-chip:hover{background:var(--acc-soft);border-color:rgba(249,115,22,0.3);}
.username-chip .icon{width:11px;height:11px;}
.chat-group-header .chat-group-name{cursor:pointer;}
.chat-group-header .chat-group-name:hover{text-decoration:underline;}
.msg-highlight{animation:flashMsg 1.6s ease-out;border-radius:14px;}
@keyframes flashMsg{0%{box-shadow:0 0 0 2px var(--acc);}100%{box-shadow:0 0 0 0 transparent;}}
@keyframes slideUp{from{opacity:0;transform:translateY(8px);}to{opacity:1;transform:translateY(0);}}

.bottom-nav{position:fixed;left:0;right:0;bottom:0;height:calc(58px + env(safe-area-inset-bottom));
background:rgba(14,14,18,0.95);backdrop-filter:blur(20px);border-top:1px solid var(--border);
display:none;align-items:stretch;justify-content:space-around;z-index:100;
padding-bottom:env(safe-area-inset-bottom);}
.bnav-item{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;
color:var(--text-muted);text-decoration:none;font-size:10px;font-family:var(--mono);}
.bnav-item.active{color:var(--acc);}
.bnav-item.adult.active{color:#f9a8d4;}
.bnav-item .icon{width:20px;height:20px;}
body.has-bnav .chat-scroll,body.has-bnav .search-wrap,body.has-bnav .settings-wrap{padding-bottom:calc(70px + env(safe-area-inset-bottom));}

.ctx-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.55);backdrop-filter:blur(3px);z-index:1200;
display:none;align-items:flex-end;justify-content:center;}
.ctx-overlay.active{display:flex;}
.ctx-sheet{background:var(--panel-solid);border:1px solid var(--border);border-bottom:none;
border-radius:18px 18px 0 0;width:100%;max-width:520px;max-height:75vh;overflow-y:auto;
padding:10px 12px calc(14px + env(safe-area-inset-bottom));animation:ctxUp 0.22s var(--transition);-webkit-overflow-scrolling:touch;}
@keyframes ctxUp{from{transform:translateY(40px);opacity:0;}to{transform:translateY(0);opacity:1;}}
.ctx-grab{width:38px;height:4px;background:var(--border-hover);border-radius:2px;margin:0 auto 12px;}
.ctx-preview{background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:var(--radius-sm);
padding:9px 12px;margin-bottom:10px;font-size:12.5px;color:var(--text-dim);max-height:64px;overflow:hidden;}
.ctx-reacts{display:flex;gap:6px;justify-content:center;padding:8px 0;margin-bottom:8px;
border-bottom:1px solid var(--border);}
.ctx-react{background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:999px;
width:40px;height:40px;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;}
.ctx-react:hover,.ctx-react:active{background:var(--acc-soft);border-color:var(--acc);transform:scale(1.08);}
.ctx-item{display:flex;align-items:center;gap:12px;width:100%;background:transparent;border:none;
color:var(--text);padding:12px 12px;border-radius:10px;font-size:14.5px;font-family:var(--font);cursor:pointer;text-align:left;}
.ctx-item:hover,.ctx-item:active{background:rgba(255,255,255,0.06);}
.ctx-item .icon{width:18px;height:18px;color:var(--text-dim);}
.ctx-item.danger{color:var(--bad);} .ctx-item.danger .icon{color:var(--bad);}
.ctx-sep{height:1px;background:var(--border);margin:6px 4px;}

.select-bar{position:sticky;top:0;z-index:30;display:none;align-items:center;gap:12px;
background:rgba(249,115,22,0.12);backdrop-filter:blur(12px);border:1px solid rgba(249,115,22,0.3);
border-radius:var(--radius-sm);padding:9px 14px;margin-bottom:10px;}
.select-bar.active{display:flex;}
.select-bar-count{font-weight:700;color:var(--acc);font-family:var(--mono);font-size:13px;flex:1;}
.select-actions{position:fixed;left:0;right:0;bottom:0;display:none;gap:10px;z-index:150;
background:rgba(14,14,18,0.96);backdrop-filter:blur(20px);border-top:1px solid var(--border);
padding:12px 16px calc(12px + env(safe-area-inset-bottom));}
.select-actions.active{display:flex;}
.select-actions .btn{flex:1;}

.voice-bar{display:none;align-items:center;gap:12px;padding:10px 14px;background:rgba(239,68,68,0.1);
border:1px solid rgba(239,68,68,0.3);border-radius:var(--radius-sm);margin-bottom:8px;}
.voice-bar.active{display:flex;}
.voice-dot{width:10px;height:10px;border-radius:50%;background:var(--bad);animation:pulse 1s infinite;}
@keyframes pulse{0%,100%{opacity:1;}50%{opacity:0.3;}}
.voice-timer{font-family:var(--mono);color:var(--bad);font-weight:700;flex:1;}

.edit-banner{display:none;align-items:center;gap:10px;padding:8px 12px;background:rgba(59,130,246,0.08);
border-left:3px solid #3b82f6;border-radius:var(--radius-sm);margin-bottom:8px;font-size:13px;}
.edit-banner.active{display:flex;}
.edit-banner-label{color:#60a5fa;font-size:11px;font-family:var(--mono);margin-bottom:2px;}

.ptr-indicator{position:absolute;top:0;left:50%;transform:translate(-50%,-100%);background:var(--panel-solid);
border:1px solid var(--border);border-radius:50%;width:36px;height:36px;display:flex;align-items:center;
justify-content:center;color:var(--acc);z-index:25;transition:transform 0.2s,opacity 0.2s;opacity:0;pointer-events:none;}
.ptr-indicator.active{transform:translate(-50%,10px);opacity:1;}
.ptr-indicator.spin .icon{animation:spin 0.9s linear infinite;}

.destroy-modal{background:linear-gradient(180deg,#1a0f0f 0%,var(--panel-solid) 100%);
border:1px solid rgba(239,68,68,0.35);border-radius:var(--radius-lg);
width:min(520px,94vw);max-height:85vh;display:flex;flex-direction:column;
box-shadow:0 25px 60px rgba(220,38,38,0.25);}
.destroy-header{padding:18px 20px;border-bottom:1px solid rgba(239,68,68,0.2);display:flex;align-items:center;gap:12px;
background:linear-gradient(135deg,rgba(239,68,68,0.1),transparent);}
.destroy-header .icon{color:#fca5a5;width:24px;height:24px;}
.destroy-title{font-weight:800;font-size:17px;color:#fca5a5;letter-spacing:0.03em;text-transform:uppercase;}
.destroy-sub{font-size:11.5px;color:#f87171;font-family:var(--mono);margin-top:2px;text-transform:none;letter-spacing:0;}
.destroy-warn{background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.25);border-radius:var(--radius-sm);
padding:12px 14px;margin:14px 16px 0;font-size:12.5px;color:#fca5a5;font-family:var(--mono);line-height:1.55;}
.destroy-warn strong{color:#fff;font-weight:700;}
.destroy-search{padding:12px 16px 0;}
.destroy-search input{width:100%;background:rgba(239,68,68,0.05);border-color:rgba(239,68,68,0.25);}
.destroy-search input:focus{border-color:var(--bad);}
.destroy-list{flex:1;overflow-y:auto;padding:8px 12px;-webkit-overflow-scrolling:touch;max-height:42vh;}
.destroy-user{display:flex;align-items:center;gap:12px;padding:10px 12px;border-radius:var(--radius-sm);
cursor:pointer;border:1px solid transparent;transition:all 0.15s;user-select:none;-webkit-user-select:none;}
.destroy-user:hover{background:rgba(239,68,68,0.06);}
.destroy-user.selected{background:rgba(239,68,68,0.15);border-color:rgba(239,68,68,0.5);}
.destroy-user-radio{width:20px;height:20px;border-radius:50%;border:2px solid rgba(239,68,68,0.4);
display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.15s;}
.destroy-user.selected .destroy-user-radio{border-color:var(--bad);background:var(--bad);}
.destroy-user.selected .destroy-user-radio::after{content:'';width:8px;height:8px;border-radius:50%;background:#fff;}
.destroy-user-body{flex:1;min-width:0;}
.destroy-user-name{font-weight:600;font-size:14px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.destroy-user-sub{font-size:11.5px;color:var(--text-muted);font-family:var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.destroy-footer{padding:14px 16px calc(14px + env(safe-area-inset-bottom));
border-top:1px solid rgba(239,68,68,0.2);background:rgba(0,0,0,0.3);
display:flex;flex-direction:column;gap:10px;}
.destroy-selected-info{font-size:12px;color:var(--text-dim);font-family:var(--mono);text-align:center;min-height:16px;}
.destroy-selected-info.active{color:#fca5a5;font-weight:600;}
.destroy-actions{display:flex;gap:10px;}
.destroy-actions .btn{flex:1;justify-content:center;}
.destroy-progress{display:none;flex-direction:column;gap:6px;padding:8px 0;}
.destroy-progress.active{display:flex;}
.destroy-progress-bar{height:4px;background:rgba(239,68,68,0.15);border-radius:2px;overflow:hidden;}
.destroy-progress-fill{height:100%;background:linear-gradient(90deg,#dc2626,#f87171);
border-radius:2px;width:0%;transition:width 0.3s ease-out;}
.destroy-progress-label{font-size:11.5px;color:#fca5a5;font-family:var(--mono);text-align:center;}

.media-viewer{position:fixed;inset:0;z-index:2000;display:none;align-items:center;justify-content:center;
background:rgba(0,0,0,0.92);touch-action:none;}
.media-viewer.active{display:flex;}
.media-viewer img,.media-viewer video{max-width:96vw;max-height:86vh;object-fit:contain;border-radius:8px;
-webkit-touch-callout:none;-webkit-user-select:none;user-select:none;pointer-events:auto;}
.media-viewer-close{position:absolute;top:calc(12px + env(safe-area-inset-top));right:14px;width:44px;height:44px;
border-radius:50%;border:1px solid var(--border);background:rgba(20,20,24,0.8);color:#fff;
display:flex;align-items:center;justify-content:center;cursor:pointer;}
.msg-body img,.msg-body video,.sticker-media{
-webkit-touch-callout:none;-webkit-user-select:none;user-select:none;}
.sticker-actions{display:flex;gap:8px;flex-wrap:wrap;}
.pack-modal{width:min(560px,96vw);max-height:88vh;}
.pack-head{padding:14px 16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;}
.pack-title{font-weight:700;font-size:15px;flex:1;min-width:0;}
.pack-sub{font-size:11.5px;color:var(--text-muted);font-family:var(--mono);}
.pack-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:12px;overflow-y:auto;
max-height:58vh;-webkit-overflow-scrolling:touch;}
.pack-item{background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:10px;
aspect-ratio:1;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:6px;}
.pack-item:hover,.pack-item:active{border-color:var(--acc);background:var(--acc-soft);}
.pack-item img,.pack-item video,.pack-item lottie-player{width:100%;height:100%;object-fit:contain;}
.pack-foot{padding:10px 16px calc(12px + env(safe-area-inset-bottom));border-top:1px solid var(--border);
display:flex;gap:8px;align-items:center;justify-content:space-between;}

.adult-hero{background:linear-gradient(135deg,rgba(236,72,153,0.15),rgba(190,24,93,0.06));
border:1px solid rgba(236,72,153,0.3);border-radius:var(--radius-lg);padding:20px;margin-bottom:20px;
text-align:center;}
.adult-hero-icon{width:56px;height:56px;background:linear-gradient(135deg,#ec4899,#be185d);
border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;color:#fff;}
.adult-hero-title{font-weight:800;font-size:18px;color:#f9a8d4;margin-bottom:6px;}
.adult-hero-sub{font-size:12.5px;color:var(--text-dim);font-family:var(--mono);}
.kw-chip{display:inline-block;background:rgba(236,72,153,0.15);border:1px solid rgba(236,72,153,0.3);
color:#f9a8d4;border-radius:999px;padding:2px 8px;font-size:10.5px;font-family:var(--mono);margin:2px;}



/* Design polish v3.6 */
.sb-brand-mark{box-shadow:0 0 12px rgba(249,115,22,0.4);}
.btn{box-shadow:0 2px 10px rgba(249,115,22,0.25);}
.btn:hover{box-shadow:0 4px 16px rgba(249,115,22,0.45);}
.msg-bubble{transition:transform 0.15s ease, box-shadow 0.15s;}
.msg-bubble:hover{transform:translateY(-1px);}
.chat-group.out .msg-bubble{box-shadow:0 4px 14px rgba(234,88,12,0.2);}


.ot-card{background:rgba(249,115,22,0.06);border:1px dashed rgba(249,115,22,0.4);border-radius:12px;padding:16px;text-align:center;}
.ot-placeholder{display:flex;flex-direction:column;align-items:center;gap:6px;}
.ot-icon{color:var(--acc);opacity:0.8;}
.ot-title{font-weight:700;color:#fff;font-size:14px;}
.ot-sub{font-size:12px;color:var(--text-dim);margin-bottom:8px;}
.ot-view-btn{padding:8px 16px;font-size:13px;margin-top:4px;}

.ot-badge{position:absolute;top:8px;right:8px;background:linear-gradient(135deg,#f97316,#ea580c);
color:#fff;font-size:11px;font-weight:800;padding:2px 7px;border-radius:999px;font-family:var(--mono);
box-shadow:0 2px 8px rgba(249,115,22,0.5);z-index:2;pointer-events:none;}
.msg-body-media.one-time{position:relative;}
.msg-body-media.one-time img{filter:saturate(1.1);box-shadow:0 0 0 1px rgba(249,115,22,0.3);}
.msg-body-media.one-time::after{content:'';position:absolute;inset:0;border-radius:8px;
box-shadow:inset 0 0 20px rgba(249,115,22,0.15);pointer-events:none;}

/* ── Media Gallery ─────────────────────────────────────────────── */
.media-gallery-wrap{display:flex;flex-direction:column;height:100%;overflow:hidden;}
.media-tabs{display:flex;gap:4px;padding:10px 12px 0;background:var(--header);border-bottom:1px solid var(--border);flex-shrink:0;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;}
.media-tabs::-webkit-scrollbar{display:none;}
.media-tab{display:flex;align-items:center;gap:5px;padding:8px 14px;border-radius:8px 8px 0 0;font-size:12.5px;color:var(--text-muted);white-space:nowrap;text-decoration:none;transition:background .15s,color .15s;border-bottom:2px solid transparent;}
.media-tab:hover{color:#fff;background:rgba(255,255,255,0.06);}
.media-tab.active{color:var(--acc);border-bottom-color:var(--acc);background:rgba(249,115,22,0.08);}
.media-tab-cnt{background:rgba(255,255,255,0.1);border-radius:20px;padding:1px 7px;font-size:10px;font-family:var(--mono);}
.media-grid{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;display:grid;grid-template-columns:repeat(3,1fr);gap:3px;padding:3px;align-content:start;}
@media(min-width:600px){.media-grid{grid-template-columns:repeat(4,1fr);}}
@media(min-width:900px){.media-grid{grid-template-columns:repeat(5,1fr);}}
.media-cell{aspect-ratio:1/1;position:relative;border-radius:6px;overflow:hidden;cursor:pointer;background:var(--surface);display:flex;align-items:center;justify-content:center;}
.media-cell:active{opacity:.7;}
.media-cell-img{width:100%;height:100%;object-fit:cover;display:block;}
.media-cell.video-cell::before{content:'';position:absolute;inset:0;background:rgba(0,0,0,.2);}
.media-cell-play{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,.5);border-radius:50%;width:32px;height:32px;display:flex;align-items:center;justify-content:center;z-index:1;color:#fff;}
.media-cell.ot-cell{background:rgba(249,115,22,0.08);border:1px dashed rgba(249,115,22,0.4);flex-direction:column;gap:4px;}
.media-cell-ot-icon{color:#f97316;opacity:.8;}
.media-cell-ot-lbl{font-size:9.5px;color:#f97316;font-family:var(--mono);text-align:center;}
.media-grid-loading{grid-column:1/-1;display:flex;align-items:center;justify-content:center;gap:10px;padding:40px;color:var(--text-muted);font-size:14px;}
.media-empty{display:none;flex-direction:column;align-items:center;justify-content:center;gap:14px;padding:60px 20px;color:var(--text-muted);text-align:center;height:100%;}

/* ── Media Viewer ──────────────────────────────────────────────── */
.media-viewer-overlay{position:fixed;inset:0;background:rgba(0,0,0,.96);z-index:9000;display:flex;flex-direction:column;opacity:0;pointer-events:none;transition:opacity .2s;}
.media-viewer-overlay.active{opacity:1;pointer-events:all;}
.media-viewer-bar{display:flex;align-items:center;gap:8px;padding:10px 12px;background:rgba(0,0,0,.5);flex-shrink:0;min-height:54px;}
.media-viewer-info{flex:1;font-size:12px;color:var(--text-muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.media-viewer-btn{background:none;border:none;color:#fff;width:40px;height:40px;display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;text-decoration:none;}
.media-viewer-btn:hover{background:rgba(255,255,255,.1);}
.media-viewer-body{flex:1;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden;}
.media-viewer-content{max-width:100%;max-height:100%;display:flex;align-items:center;justify-content:center;}
.media-viewer-nav{position:absolute;top:50%;transform:translateY(-50%);background:rgba(0,0,0,.5);border:none;color:#fff;width:44px;height:44px;border-radius:50%;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:opacity .2s;}
.media-viewer-nav.left{left:12px;}
.media-viewer-nav.right{right:12px;}
@media(max-width:600px){.media-viewer-nav{width:36px;height:36px;}}
.viewer-ot{display:flex;flex-direction:column;align-items:center;gap:12px;color:#fff;text-align:center;}
.viewer-ot-icon{color:#f97316;opacity:.8;}
.viewer-ot-title{font-size:15px;font-weight:600;}

@media (max-width:900px){
:root{--bnav-h:58px;}
.sidebar{position:fixed;inset:0 auto 0 0;width:85vw;max-width:320px;transform:translateX(-100%);box-shadow:0 0 40px rgba(0,0,0,0.5);}
.sidebar.open{transform:translateX(0);}
.mn-menu-btn{display:flex;}
.sb-search-kbd{display:none;}
.chat-group{max-width:96%;}
.chat-scroll{padding:8px 6px;}
/* bigger bubble text for mobile */
.msg-bubble{font-size:15px;line-height:1.45;padding:9px 12px;}
/* spacious input */
.chat-input{padding:8px 10px calc(10px + env(safe-area-inset-bottom));gap:6px;}
.chat-input-field{font-size:16px;line-height:1.4;padding:10px 6px !important;min-height:44px;}
/* larger tap targets */
.mn-menu-btn,.btn-icon,.chat-input-send{width:46px;height:46px;}
.chat-input-send{width:46px;height:46px;min-width:46px;border-radius:50%;flex-shrink:0;}
.chat-input-tools{gap:4px;}
.chat-input-tools label,.chat-input-tools button{width:40px;height:40px;}
.msg-actions{display:flex;gap:6px;justify-content:flex-end;width:100%;margin-top:8px;padding-top:6px;border-top:1px solid rgba(255,255,255,0.05);}
.msg-action{background:rgba(255,255,255,0.08);border:none;color:var(--text-dim);width:38px;height:38px;
display:flex;align-items:center;justify-content:center;border-radius:8px;cursor:pointer;}
.msg-meta{flex-direction:column;align-items:flex-end;}
.bottom-nav{display:flex;}
.ghost-banner{margin:0 8px 6px;font-size:11.5px;padding:6px 10px;}
.cache-banner{margin:0 8px 6px;font-size:11px;padding:6px 10px;}
.offline-banner{margin:8px 8px 0;}
.chat-fab{bottom:calc(88px + env(safe-area-inset-bottom));right:14px;width:46px;height:46px;}
.mn-header{padding:10px 10px;gap:8px;}
.mn-title{font-size:16px;}
.modal-overlay{padding-top:4vh;align-items:flex-start;}
.modal{width:96vw;max-height:88vh;}
.destroy-modal{width:96vw;max-height:92vh;}
.sidebar-backdrop{position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:40;display:none;}
.sidebar-backdrop.active{display:block;}
.bnav-item{font-size:10px;}
.bnav-item .icon{width:20px;height:20px;}
/* bottom nav taller touch area */
.bottom-nav{height:calc(62px + env(safe-area-inset-bottom));padding-bottom:env(safe-area-inset-bottom);}
/* context sheet bigger touch */
.ctx-item{min-height:48px;font-size:15px;}
.ctx-react{width:46px;height:46px;font-size:22px;}
/* search input */
.mn-actions form input{font-size:16px !important;}
/* gallery grid: 3 cols on mobile */
.media-grid{grid-template-columns:repeat(3,1fr);gap:2px;padding:2px;}
/* viewer nav hidden on small — use swipe */
.media-viewer-nav{display:none;}
/* bigger ot-view-btn */
.ot-view-btn{padding:10px 20px;font-size:14px;}
}
@media (max-width:500px){
.chat-input-options{font-size:11px;justify-content:space-between;}
.opt-sep{display:none;}
.mn-actions form input{width:80px !important;}
.mn-title{font-size:15px;}
.sb-footer-btn{min-width:calc(50% - 3px);font-size:11.5px;}
.chat-group{max-width:100%;}
.media-grid{grid-template-columns:repeat(3,1fr);}
}
.sidebar-backdrop{position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:40;display:none;}
.sidebar-backdrop.active{display:block;}
"""


# --- Page builder ---
def page(body, title="Telegram CloudCode", with_sidebar=True, active_chat=None,
         active_tab="all", dialogs=None, search_q="", bottom_nav=True, active_bnav="home"):
    me = state.get("me")
    sidebar_html = ""
    if with_sidebar and me:
        tabs = [("all", "Все", "inbox"), ("users", "Личные", "user"),
                ("groups", "Группы", "users"), ("channels", "Каналы", "megaphone")]
        tabs_html = "".join(
            f'<a class="sb-tab {"active" if t == active_tab else ""}" href="/?tab={t}">{icon(i, "icon-sm")} {n}</a>'
            for t, n, i in tabs)
        items_html = ""
        if dialogs is not None and len(dialogs) > 0:
            for d in dialogs:
                active = "active" if active_chat and str(d["id"]) == str(active_chat) else ""
                pinned = "pinned" if d.get("pinned") else ""
                unread = int(d.get("unread") or 0)
                badge = f'<span class="sb-badge">{unread}</span>' if unread > 0 else ""
                pin = f'<span class="sb-pin">{icon("pin", "icon-sm")}</span>' if d.get("pinned") else ""
                avatar = avatar_svg(d["title"], 40)
                items_html += f'''
<a class="sb-item {active} {pinned}" href="/chat/{d["id"]}">
{avatar}
<div class="sb-item-body">
<div class="sb-item-top">
<span class="sb-item-title">{pin}{esc(d["title"])}</span>
<span class="sb-item-time">{esc(d.get("time", ""))}</span>
</div>
<div class="sb-item-preview">{esc(d.get("preview", ""))}{badge}</div>
</div>
</a>'''
        elif dialogs is None:
            items_html = "".join('''<div class="skel-item"><div class="skeleton skel-avatar"></div>
<div class="skel-body"><div class="skeleton skel-line" style="width:70%;"></div>
<div class="skeleton skel-line" style="width:90%;"></div></div></div>''' for _ in range(8))
        else:
            items_html = '<div class="sb-empty">Диалоги не найдены</div>'
        me_avatar = avatar_svg(me.get("name", "?"), 32)
        me_un = me.get("username")
        if me_un:
            me_user_html = ('<div class="sb-me-user copy-field" data-copy="@' + esc(me_un) +
                            '" onclick="copyToClipboard(this.dataset.copy)" title="Скопировать username">@' +
                            esc(me_un) + '</div>')
        else:
            me_user_html = '<div class="sb-me-user">—</div>'
        dbs = db_stats()
        sidebar_html = f'''
<aside class="sidebar" id="sidebar">
<div class="sb-header"><a class="sb-brand" href="/"><div class="sb-brand-mark">T</div><span>CloudCode</span></a></div>
<div class="sb-me">{me_avatar}<div class="sb-me-info"><div class="sb-me-name">{esc(me.get("name", ""))}</div>{me_user_html}</div></div>
<div class="sb-search"><div class="sb-search-wrap">{icon("search", "sb-search-icon icon-sm")}
<input class="sb-search-input" id="cmdInput" placeholder="Поиск чатов..." value="{esc(search_q)}" autocomplete="off">
<span class="sb-search-kbd">Ctrl K</span></div></div>
<div class="sb-tabs">{tabs_html}</div>
<div class="sb-list" id="sbList">{items_html}</div>
<div class="sb-footer">
<a class="sb-footer-btn" href="/my">{icon("user", "icon-sm")} Мои</a>
<a class="sb-footer-btn adult" href="/adult">{icon("flame", "icon-sm")} 18+</a>
<a class="sb-footer-btn cache" href="/cached">{icon("database", "icon-sm")} Кэш ({dbs["chats"]})</a>
<a class="sb-footer-btn" href="/search">{icon("search", "icon-sm")} Поиск</a>
<a class="sb-footer-btn" href="/settings">{icon("settings", "icon-sm")} Настройки</a>
<button class="sb-footer-btn destroy" style="min-width:100%;" onclick="openDestroy()">{icon("bomb", "icon-sm")} Уничтожить</button>
</div>
</aside>
<div class="sidebar-backdrop" id="sbBackdrop" onclick="toggleSidebar()"></div>'''

    bnav_html = ""
    if bottom_nav and me:
        def cls(n):
            return "active" if active_bnav == n else ""
        bnav_html = f'''
<nav class="bottom-nav">
<a class="bnav-item {cls('home')}" href="/">{icon("inbox")} Чаты</a>
<a class="bnav-item {cls('my')}" href="/my">{icon("user")} Мои</a>
<a class="bnav-item {cls('search')}" href="/search">{icon("search")} Поиск</a>
<a class="bnav-item adult {cls('adult')}" href="/adult">{icon("flame")} 18+</a>
<a class="bnav-item {cls('settings')}" href="/settings">{icon("settings")} Ещё</a>
</nav>'''

    destroy_modal = ""
    if with_sidebar and me:
        destroy_modal = f'''
<div class="modal-overlay" id="destroyModal" onclick="if(event.target===this)hideDestroy()">
<div class="destroy-modal">
<div class="destroy-header">
{icon("bomb")}
<div style="flex:1;min-width:0;">
<div class="destroy-title">Уничтожить</div>
<div class="destroy-sub">block + wipe + delete dialog</div>
</div>
<button class="chat-reply-close" onclick="hideDestroy()">{icon("x", "icon-lg")}</button>
</div>
<div class="destroy-warn">
<strong>ВНИМАНИЕ:</strong> Это НЕОБРАТИМОЕ действие. Будет выполнено:<br>
• Пользователь будет <strong>заблокирован</strong><br>
• Вся переписка будет <strong>удалена у вас и у него</strong><br>
• Диалог будет <strong>удалён из списка чатов</strong>
</div>
<div class="destroy-search">
<input type="text" id="destroySearch" placeholder="Поиск пользователя..." oninput="filterDestroy()" autocomplete="off">
</div>
<div class="destroy-list" id="destroyList">
<div style="padding:40px 20px;text-align:center;color:var(--text-muted);font-family:var(--mono);font-size:13px;">Загрузка...</div>
</div>
<div class="destroy-footer">
<div class="destroy-selected-info" id="destroyInfo">Никто не выбран</div>
<div class="destroy-progress" id="destroyProgress">
<div class="destroy-progress-bar"><div class="destroy-progress-fill" id="destroyProgressFill"></div></div>
<div class="destroy-progress-label" id="destroyProgressLabel">Подготовка...</div>
</div>
<div class="destroy-actions" id="destroyActions">
<button class="btn btn-ghost" onclick="hideDestroy()">{icon("x", "icon-sm")} Отмена</button>
<button class="btn btn-destroy" id="destroyConfirmBtn" onclick="doDestroy()" disabled>{icon("bomb", "icon-sm")} Уничтожить</button>
</div>
</div>
</div>
</div>'''

    html = f"""<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover">
<meta name="theme-color" content="#0a0a0c">
<meta name="color-scheme" content="dark">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="CloudCode">
<meta name="format-detection" content="telephone=no">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="icon" type="image/svg+xml" href="/favicon.ico">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<script src="https://unpkg.com/@lottiefiles/lottie-player@2/dist/lottie-player.js"></script>
<title>{esc(title)}</title>
<style>{CSS}</style>
</head>
<body class="{'has-bnav' if (bottom_nav and me) else ''}">
<div class="app">
{sidebar_html}
<div class="main">
{body}
</div>
</div>
{bnav_html}
{destroy_modal}
<div class="modal-overlay" id="cmdModal" onclick="if(event.target===this)hideCmd()">
<div class="modal">
<div class="modal-header">{icon("command", "icon-lg")}
<input class="modal-input" id="cmdModalInput" placeholder="Быстрый переход к чату..." autocomplete="off"></div>
<div class="modal-body" id="cmdResults"></div>
<div class="modal-footer"><span>{icon("arrow-left", "icon-sm")} навигация</span><span>↵ открыть</span><span>esc закрыть</span></div>
</div>
</div>
<div id="toast-container"></div>
<div class="media-viewer" id="mediaViewer" onclick="if(event.target===this)closeMediaViewer()">
  <button class="media-viewer-close" onclick="closeMediaViewer()">{icon("x", "icon-lg")}</button>
  <div id="mediaViewerBody"></div>
</div>
<div class="modal-overlay" id="packModal" onclick="if(event.target===this)hidePack()">
  <div class="modal pack-modal">
    <div class="pack-head">
      {icon("smile", "icon-lg")}
      <div style="flex:1;min-width:0;">
        <div class="pack-title" id="packTitle">Стикерпак</div>
        <div class="pack-sub" id="packSub"></div>
      </div>
      <button class="chat-reply-close" onclick="hidePack()">{icon("x", "icon-lg")}</button>
    </div>
    <div class="pack-grid" id="packGrid">
      <div style="grid-column:1/-1;padding:30px;text-align:center;color:var(--text-muted);font-family:var(--mono);">Загрузка...</div>
    </div>
    <div class="pack-foot">
      <span class="pack-sub" id="packCount"></span>
      <button class="btn btn-ghost" onclick="hidePack()">Закрыть</button>
    </div>
  </div>
</div>
<script>
window.__CSRF_SAFE__ = true;
function showToast(msg, type) {{
  type = type || 'default';
  const c = document.getElementById('toast-container');
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  const iconMap = {{ ok: `{icon("check")}`, error: `{icon("x")}`, default: `{icon("zap")}` }};
  t.innerHTML = iconMap[type] + '<span>' + msg + '</span>';
  c.appendChild(t);
  setTimeout(() => {{ t.style.opacity='0'; t.style.transition='opacity 0.25s'; setTimeout(()=>t.remove(),250); }}, 4000);
}}
function closeMediaViewer() {{
  const v = document.getElementById('mediaViewer');
  const b = document.getElementById('mediaViewerBody');
  if (v) v.classList.remove('active');
  if (b) b.innerHTML = '';
  if (window.popHistoryGuard) popHistoryGuard();
}}

async function openOneTime(img, url) {{
  // Для одноразовых: сначала убеждаемся что файл скачан и сохранён локально
  showToast('Сохраняю одноразовое фото...','default');
  try {{
    const r = await fetch(url);
    if (r.ok) {{
      // теперь открываем viewer (файл уже в кэше)
      openMediaViewer(url, 'image');
      showToast('Сохранено в кэш','ok');
    }} else {{
      showToast('Не удалось сохранить','error');
    }}
  }} catch(e) {{
    showToast('Ошибка сети','error');
  }}
}}

function openMediaViewer(url, kind) {{
  const v = document.getElementById('mediaViewer');
  const b = document.getElementById('mediaViewerBody');
  if (!v || !b || !url) return;
  kind = kind || 'image';
  const safe = escHtml(url);
  if (kind === 'video') {{
    b.innerHTML = '<video src="'+safe+'" controls playsinline autoplay style="max-width:96vw;max-height:86vh;border-radius:8px;"></video>';
  }} else {{
    b.innerHTML = '<img src="'+safe+'" alt="" draggable="false" oncontextmenu="return false">';
  }}
  v.classList.add('active');
  if (window.pushHistoryGuard) pushHistoryGuard();
}}
let packChatId = null;
function hidePack() {{
  const m = document.getElementById('packModal');
  if (m) m.classList.remove('active');
  if (window.popHistoryGuard) popHistoryGuard();
}}
function packItemHtml(s) {{
  const src = s.url || '';
  let media = '';
  if (s.kind === 'tgs') media = '<lottie-player src="'+src+'" background="transparent" speed="1" loop autoplay></lottie-player>';
  else if (s.kind === 'webm') media = '<video src="'+src+'" autoplay loop muted playsinline></video>';
  else media = '<img src="'+src+'" alt="" draggable="false">';
  const canSend = packChatId ? '1' : '0';
  return '<button class="pack-item" data-token="'+(s.token||'')+'" data-idx="'+(s.idx||0)+'" data-cansend="'+canSend+'" onclick="onPackSticker(this)">'+media+'</button>';
}}
async function openStickerPack(chatId, msgId) {{
  const m = document.getElementById('packModal');
  const grid = document.getElementById('packGrid');
  const title = document.getElementById('packTitle');
  const sub = document.getElementById('packSub');
  const cnt = document.getElementById('packCount');
  if (!m || !grid) {{ showToast('Просмотр пака недоступен','error'); return; }}
  packChatId = chatId || (typeof CHAT_ID !== 'undefined' ? CHAT_ID : null);
  m.classList.add('active');
  if (window.pushHistoryGuard) pushHistoryGuard();
  if (title) title.textContent = 'Стикерпак';
  if (sub) sub.textContent = 'загрузка...';
  if (cnt) cnt.textContent = '';
  grid.innerHTML = '<div style="grid-column:1/-1;padding:30px;text-align:center;color:var(--text-muted);font-family:var(--mono);">Загрузка пака...</div>';
  try {{
    const r = await fetch('/api/stickerset?chat_id='+encodeURIComponent(chatId)+'&msg_id='+encodeURIComponent(msgId));
    const d = await r.json();
    if (!d.ok) {{
      grid.innerHTML = '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--bad);font-family:var(--mono);">'+(escHtml(d.error)||'Не удалось открыть пак')+'</div>';
      if (sub) sub.textContent = '';
      return;
    }}
    if (title) title.textContent = d.title || 'Стикерпак';
    if (sub) sub.textContent = (d.short_name ? '/'+d.short_name+' · ' : '') + (d.count||0) + ' шт.';
    if (cnt) cnt.textContent = packChatId ? 'Нажмите стикер, чтобы отправить' : 'Только просмотр';
    const items = d.stickers || [];
    grid.innerHTML = items.length ? items.map(packItemHtml).join('') :
      '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--text-muted);">Пустой пак</div>';
  }} catch(e) {{
    grid.innerHTML = '<div style="grid-column:1/-1;padding:24px;text-align:center;color:var(--bad);">Ошибка сети</div>';
  }}
}}
async function onPackSticker(el) {{
  if (!el) return;
  const token = el.dataset.token;
  const idx = el.dataset.idx;
  const src = el.querySelector('img,video,lottie-player')?.getAttribute('src') || '';
  if (!packChatId || el.dataset.cansend !== '1') {{
    if (src) openMediaViewer(src, 'image');
    return;
  }}
  try {{
    const r = await fetch('/api/chat/'+packChatId+'/send_sticker', {{
      method:'POST', headers:{{'Content-Type':'application/json'}},
      body: JSON.stringify({{ token: token, idx: parseInt(idx,10) }})
    }});
    const d = await r.json();
    if (d.ok) {{
      showToast('Стикер отправлен','ok');
      hidePack();
      if (typeof pollNewMessages === 'function') setTimeout(()=>pollNewMessages(packChatId), 400);
    }} else showToast('Не отправлено: '+(d.error||''),'error');
  }} catch(e) {{
    showToast('Ошибка сети','error');
  }}
}}
function copyToClipboard(text) {{
  if (!text) {{ showToast('Нечего копировать','error'); return; }}
  if (navigator.clipboard && window.isSecureContext) {{
    navigator.clipboard.writeText(text).then(()=>showToast('Скопировано','ok'),()=>fallbackCopy(text));
  }} else fallbackCopy(text);
}}
function fallbackCopy(text) {{
  const ta=document.createElement('textarea'); ta.value=text;
  ta.style.position='fixed'; ta.style.top='-9999px';
  document.body.appendChild(ta); ta.focus(); ta.select();
  try {{ document.execCommand('copy'); showToast('Скопировано','ok'); }}
  catch(e) {{ showToast('Не удалось','error'); }}
  ta.remove();
}}
function toggleSidebar() {{
  const sb=document.getElementById('sidebar'); const bd=document.getElementById('sbBackdrop');
  if (sb && bd) {{ sb.classList.toggle('open'); bd.classList.toggle('active'); }}
}}
function escHtml(s) {{ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }}
let __historyGuard = false;
function pushHistoryGuard() {{
  if (__historyGuard) return;
  __historyGuard = true;
  try {{ history.pushState({{ guard: true }}, ''); }} catch(e) {{}}
}}
function popHistoryGuard() {{
  if (!__historyGuard) return;
  __historyGuard = false;
  try {{ history.back(); }} catch(e) {{}}
}}
window.addEventListener('popstate', () => {{
  __historyGuard = false;
  let handled = false;
  const sb = document.getElementById('sidebar');
  if (sb && sb.classList.contains('open')) {{ toggleSidebar(); handled = true; }}
  const m1=document.getElementById('cmdModal'); if(m1&&m1.classList.contains('active')){{ if(window.hideCmd)hideCmd(); handled=true; }}
  const m2=document.getElementById('delModal'); if(m2&&m2.classList.contains('active')){{ if(window.hideDelete)hideDelete(); handled=true; }}
  const m3=document.getElementById('fwdModal'); if(m3&&m3.classList.contains('active')){{ if(window.hideForward)hideForward(); handled=true; }}
  const m4=document.getElementById('membersModal'); if(m4&&m4.classList.contains('active')){{ if(window.hideMembers)hideMembers(); handled=true; }}
  const m5=document.getElementById('exportModal'); if(m5&&m5.classList.contains('active')){{ if(window.hideExport)hideExport(); handled=true; }}
  const m6=document.getElementById('ctxMenu'); if(m6&&m6.classList.contains('active')){{ if(window.closeCtx)closeCtx(); handled=true; }}
  const m7=document.getElementById('destroyModal'); if(m7&&m7.classList.contains('active')){{ if(window.hideDestroy)hideDestroy(); handled=true; }}
  const m8=document.getElementById('packModal'); if(m8&&m8.classList.contains('active')){{ if(window.hidePack)hidePack(); handled=true; }}
  const m9=document.getElementById('mediaViewer'); if(m9&&m9.classList.contains('active')){{ if(window.closeMediaViewer)closeMediaViewer(); handled=true; }}
  const s=document.getElementById('selectActions');
  if (s && s.classList.contains('active')) {{ if(window.exitSelect){{exitSelect(); handled=true;}} }}
}});
let cmdData=[]; let cmdSelected=-1;
function showCmd() {{
  const m=document.getElementById('cmdModal'); if(!m) return;
  pushHistoryGuard();
  m.classList.add('active');
  const inp=document.getElementById('cmdModalInput'); inp.value=''; inp.focus();
  if (!cmdData.length) loadCmdData().then(()=>filterCmd('')); else filterCmd('');
}}
function hideCmd() {{ const m=document.getElementById('cmdModal'); if(m) m.classList.remove('active'); popHistoryGuard(); }}
async function loadCmdData() {{ try {{ const r=await fetch('/api/dialogs'); const d=await r.json(); cmdData=d.dialogs||[]; }} catch(e) {{ cmdData=[]; }} }}
function renderCmd(items) {{
  const box=document.getElementById('cmdResults');
  if (!items.length) {{ box.innerHTML='<div style="padding:20px;text-align:center;color:var(--text-muted);font-family:var(--mono);">Ничего не найдено</div>'; cmdSelected=-1; return; }}
  box.innerHTML = items.map((it,i)=>`<a href="/chat/${{it.id}}" class="modal-item ${{i===cmdSelected?'selected':''}}">${{it.avatar}}<span class="modal-item-title">${{escHtml(it.title)}}</span><span class="modal-item-sub">ID ${{it.id}}</span></a>`).join('');
}}
function filterCmd(q) {{
  q=(q||'').toLowerCase();
  const filtered=cmdData.filter(d=>d.title.toLowerCase().includes(q)).slice(0,12);
  cmdSelected=0; renderCmd(filtered);
}}
document.getElementById('cmdInput')?.addEventListener('focus',(e)=>{{ e.target.blur(); if(cmdData.length===0) loadCmdData().then(showCmd); else showCmd(); }});
document.getElementById('cmdModalInput')?.addEventListener('input',e=>filterCmd(e.target.value));
document.addEventListener('keydown',e=>{{
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){{e.preventDefault(); showCmd();}}
  if(e.key==='Escape'){{ if (document.getElementById('cmdModal')?.classList.contains('active')) hideCmd(); }}
}});
function updateOnline() {{ document.body.classList.toggle('offline', !navigator.onLine); }}
window.addEventListener('online', updateOnline);
window.addEventListener('offline', updateOnline);
updateOnline();
if ('serviceWorker' in navigator) {{
  window.addEventListener('load', () => {{ navigator.serviceWorker.register('/sw.js').catch(()=>{{}}); }});
}}

// ================= УНИЧТОЖЕНИЕ =================
let destroyUsers = [];
let destroySelected = null;
let destroyLoading = false;

async function openDestroy() {{
  const m = document.getElementById('destroyModal');
  if (!m) {{ showToast('Модалка недоступна','error'); return; }}
  pushHistoryGuard();
  m.classList.add('active');
  destroySelected = null;
  updateDestroyUI();
  const inp = document.getElementById('destroySearch');
  if (inp) inp.value = '';
  const list = document.getElementById('destroyList');
  if (list) list.innerHTML = '<div style="padding:40px 20px;text-align:center;color:var(--text-muted);font-family:var(--mono);font-size:13px;">Загрузка...</div>';
  await loadDestroyUsers();
}}
function hideDestroy() {{
  const m = document.getElementById('destroyModal');
  if (m) m.classList.remove('active');
  destroySelected = null;
  updateDestroyUI();
  popHistoryGuard();
}}
async function loadDestroyUsers() {{
  if (destroyLoading) return;
  destroyLoading = true;
  try {{
    const r = await fetch('/api/dialogs?tab=users');
    const d = await r.json();
    destroyUsers = (d.dialogs || []).filter(u => u && u.id);
    renderDestroyList();
  }} catch(e) {{
    const list = document.getElementById('destroyList');
    if (list) list.innerHTML = '<div style="padding:20px;color:var(--bad);text-align:center;font-family:var(--mono);font-size:12px;">Ошибка загрузки</div>';
  }} finally {{
    destroyLoading = false;
  }}
}}
function renderDestroyList() {{
  const list = document.getElementById('destroyList');
  if (!list) return;
  const q = (document.getElementById('destroySearch')?.value || '').toLowerCase();
  const items = destroyUsers.filter(u => (u.title||'').toLowerCase().includes(q));
  if (!items.length) {{
    list.innerHTML = '<div style="padding:40px 20px;text-align:center;color:var(--text-muted);font-family:var(--mono);font-size:13px;">' +
                     (destroyUsers.length ? 'Ничего не найдено' : 'Нет личных чатов') + '</div>';
    return;
  }}
  list.innerHTML = items.map(u => {{
    const sel = destroySelected && destroySelected.id === u.id ? 'selected' : '';
    const av = u.avatar || '';
    const title = escHtml(u.title || 'Без имени');
    const sub = 'ID ' + u.id;
    return `<div class="destroy-user ${{sel}}" data-id="${{u.id}}" onclick="selectDestroyUser(${{u.id}})">
      <div class="destroy-user-radio"></div>
      ${{av}}
      <div class="destroy-user-body">
        <div class="destroy-user-name">${{title}}</div>
        <div class="destroy-user-sub">${{sub}}</div>
      </div>
    </div>`;
  }}).join('');
}}
function filterDestroy() {{ renderDestroyList(); }}
function selectDestroyUser(id) {{
  const u = destroyUsers.find(x => x.id === id);
  if (!u) return;
  if (destroySelected && destroySelected.id === id) destroySelected = null;
  else destroySelected = u;
  document.querySelectorAll('.destroy-user').forEach(el => {{
    const elId = parseInt(el.dataset.id, 10);
    el.classList.toggle('selected', !!destroySelected && destroySelected.id === elId);
  }});
  updateDestroyUI();
  if (navigator.vibrate) try {{ navigator.vibrate(6); }} catch(e){{}}
}}
function updateDestroyUI() {{
  const info = document.getElementById('destroyInfo');
  const btn = document.getElementById('destroyConfirmBtn');
  if (!info || !btn) return;
  if (destroySelected) {{
    info.classList.add('active');
    info.textContent = 'Цель: ' + (destroySelected.title || destroySelected.id);
    btn.disabled = false;
  }} else {{
    info.classList.remove('active');
    info.textContent = 'Никто не выбран';
    btn.disabled = true;
  }}
}}
async function doDestroy() {{
  if (!destroySelected) {{ showToast('Выберите пользователя','error'); return; }}
  const u = destroySelected;
  const confirmName = u.title || u.id;
  if (!confirm('УНИЧТОЖИТЬ пользователя "' + confirmName + '"?\\n\\n• Заблокировать\\n• Удалить всю переписку у обоих\\n• Удалить диалог\\n\\nЭто действие НЕОБРАТИМО.')) return;

  const prog = document.getElementById('destroyProgress');
  const progFill = document.getElementById('destroyProgressFill');
  const progLabel = document.getElementById('destroyProgressLabel');
  const actions = document.getElementById('destroyActions');
  if (prog) prog.classList.add('active');
  if (actions) actions.style.display = 'none';
  if (progFill) progFill.style.width = '15%';
  if (progLabel) progLabel.textContent = 'Блокировка + удаление...';

  try {{
    const res = await fetch('/api/destroy_user', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{ user_id: u.id, title: u.title || '' }})
    }});
    const data = await res.json();
    console.log('[DESTROY]', data);

    if (data.ok) {{
      if (progFill) progFill.style.width = '100%';
      if (progLabel) progLabel.textContent = 'Готово ✔';
      if (navigator.vibrate) try {{ navigator.vibrate([40,30,40,30,80]); }} catch(e){{}}
      showToast('Уничтожено: ' + confirmName, 'ok');
      destroyUsers = destroyUsers.filter(x => x.id !== u.id);
      destroySelected = null;
      renderDestroyList();
      updateDestroyUI();
      setTimeout(() => {{
        hideDestroy();
        if (location.pathname === '/chat/' + u.id) location.href = '/';
        else setTimeout(() => location.reload(), 800);
      }}, 700);
    }} else {{
      const det = data.details || {{}};
      const errs = (det.errors || []).join(' · ') || data.error || 'неизвестно';
      const rem = (det.message_count_remaining != null) ? ' (осталось ' + det.message_count_remaining + ')' : '';
      if (progLabel) progLabel.textContent = 'ОШИБКА: ' + errs + rem;
      if (progFill) progFill.style.background = 'var(--bad)';
      console.error('[DESTROY] failed', det);
      showToast('Не удалось: ' + errs.slice(0,120), 'error');
      setTimeout(() => {{
        if (prog) prog.classList.remove('active');
        if (actions) actions.style.display = '';
        if (progFill) {{ progFill.style.width = '0%'; progFill.style.background = ''; }}
      }}, 4000);
    }}
  }} catch(e) {{
    if (progLabel) progLabel.textContent = 'Ошибка сети';
    showToast('Ошибка сети: ' + e.message, 'error');
    setTimeout(() => {{
      if (prog) prog.classList.remove('active');
      if (actions) actions.style.display = '';
    }}, 2500);
  }}
}}
</script>
</body>
</html>"""
    return html


def need_auth(fn):
    @wraps(fn)
    def wrap(*a, **k):
        if state["phase"] != "ready":
            return redirect("/login")
        return fn(*a, **k)
    return wrap


def esc(s):
    if s is None:
        return ""
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def safe_attr(s):
    if s is None:
        return ""
    return esc(s).replace("\n", "&#10;").replace("'", "&#39;")


def parse_markdown(text):
    if not text:
        return ""
    text = esc(text)
    text = re.sub(r'```(.*?)```', r'<pre><code>\1</code></pre>', text, flags=re.DOTALL)
    text = re.sub(r'`(.*?)`', r'<code>\1</code>', text)
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    text = re.sub(r'__(.*?)__', r'<i>\1</i>', text)
    text = re.sub(r'(https?://[^\s<]+)', r'<a href="\1" target="_blank" rel="noopener">\1</a>', text)
    return text.replace('\n', '<br>')


async def refresh_me():
    try:
        if await client.is_user_authorized():
            me = await client.get_me()
            if me:
                state["me"] = {
                    "id": me.id,
                    "name": " ".join(x for x in [me.first_name, me.last_name] if x) or (me.username or "Пользователь"),
                    "username": me.username,
                }
                state["phase"] = "ready"
                state["message"] = "Сессия активна"
                state["error"] = ""
                return True
    except Exception as e:
        state["error"] = str(e)
    return False


async def login_flow():
    try:
        await client.connect()
        if await refresh_me():
            return
        state["phase"] = "qr"
        state["message"] = "Отсканируйте QR-код в Telegram"
        state["error"] = ""
        qr = await client.qr_login()
        state["qr_url"] = qr.url or ""
        state["qr_html"] = build_qr_html(state["qr_url"]) if state["qr_url"] else ""

        async def watch_qr():
            while state["phase"] == "qr":
                await asyncio.sleep(1)
                if qr.url and qr.url != state["qr_url"]:
                    state["qr_url"] = qr.url
                    state["qr_html"] = build_qr_html(qr.url)

        watcher = asyncio.create_task(watch_qr())
        try:
            await qr.wait(timeout=180)
            await refresh_me()
        except errors.SessionPasswordNeededError:
            state["phase"] = "2fa"
            state["message"] = "Требуется облачный пароль (2FA)"
        except (asyncio.TimeoutError, errors.TimeoutError):
            state["phase"] = "error"
            state["message"] = "Срок действия QR истек. Обновите страницу."
        finally:
            watcher.cancel()
            try:
                await watcher
            except Exception:
                pass
    except Exception as e:
        state["phase"] = "error"
        state["error"] = str(e)
        state["message"] = "Ошибка авторизации"


async def do_2fa(password):
    try:
        await client.sign_in(password=password)
        await refresh_me()
    except Exception as e:
        state["error"] = str(e)
        state["phase"] = "2fa"
        state["message"] = "Неверный пароль"


def fmt_date(dt):
    if isinstance(dt, datetime):
        local_dt = dt.astimezone() if dt.tzinfo else dt
        now = datetime.now(local_dt.tzinfo)
        if local_dt.date() == now.date():
            return local_dt.strftime("%H:%M")
        delta = (now.date() - local_dt.date()).days
        if delta < 7:
            return ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"][local_dt.weekday()]
        return local_dt.strftime("%d.%m.%y")
    return ""


def fmt_full_date(dt):
    if isinstance(dt, datetime):
        local_dt = dt.astimezone() if dt.tzinfo else dt
        return local_dt.strftime("%d.%m.%y %H:%M")
    return ""


RU_MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня",
             "июля", "августа", "сентября", "октября", "ноября", "декабря"]


def fmt_day(dt):
    if not isinstance(dt, datetime):
        return "", ""
    local_dt = dt.astimezone() if dt.tzinfo else dt
    key = local_dt.strftime("%Y-%m-%d")
    now = datetime.now(local_dt.tzinfo)
    today = now.strftime("%Y-%m-%d")
    diff = (now.date() - local_dt.date()).days
    if key == today:
        label = "Сегодня"
    elif diff == 1:
        label = "Вчера"
    elif local_dt.year == now.year:
        label = f"{local_dt.day} {RU_MONTHS[local_dt.month - 1]}"
    else:
        label = f"{local_dt.day} {RU_MONTHS[local_dt.month - 1]} {local_dt.year}"
    return key, label


def preview_text(msg):
    if not msg:
        return ""
    text = getattr(msg, "message", None)
    if text:
        t = text.replace("\n", " ")
        return t[:60] + ("..." if len(t) > 60 else "")
    if msg.media:
        return "📎 Медиафайл"
    return "Служебное сообщение"


async def entity_info(eid):
    try:
        ent = await client.get_entity(eid)
        if isinstance(ent, User):
            title = " ".join(x for x in [ent.first_name, ent.last_name] if x) or str(ent.id)
            kind = "user"
        elif isinstance(ent, Channel):
            title = getattr(ent, "title", str(eid))
            kind = "channel" if getattr(ent, "broadcast", False) else "group"
        else:
            title = getattr(ent, "title", str(eid))
            kind = "group"
        return {"title": title, "username": getattr(ent, "username", None), "kind": kind}
    except Exception:
        cached = db_get_chat(eid)
        if cached:
            return {"title": cached.get("title") or str(eid),
                    "username": cached.get("username"),
                    "kind": cached.get("kind") or "unknown"}
        return {"title": str(eid), "username": None, "kind": "unknown"}


def sticker_kind_from_doc(doc):
    if not doc or not getattr(doc, "attributes", None):
        return None
    if not any(isinstance(a, DocumentAttributeSticker) for a in doc.attributes):
        return None
    mime = (doc.mime_type or "")
    has_name = any(isinstance(a, DocumentAttributeFilename) for a in doc.attributes)
    if mime == "video/webm" or mime == "video/mp4":
        return "webm"
    if mime == "application/x-tgsticker" or not has_name:
        return "tgs"
    return "webp"


def get_sticker_kind(m):
    return sticker_kind_from_doc(getattr(m, "document", None))


def extract_stickerset(doc):
    if not doc or not getattr(doc, "attributes", None):
        return None
    for a in doc.attributes:
        if isinstance(a, DocumentAttributeSticker):
            ss = getattr(a, "stickerset", None)
            if ss and not isinstance(ss, InputStickerSetEmpty):
                return ss
    return None


def media_label(m):
    if not m.media:
        return ""
    if get_sticker_kind(m):
        return "[стикер]"
    if getattr(m, "photo", None):
        return "[фото]"
    doc = getattr(m, "document", None)
    if doc:
        if getattr(m, "voice", None):
            return "[голосовое]"
        if getattr(m, "video", None) or (doc.mime_type or "").startswith("video/"):
            return "[видео]"
        mt = doc.mime_type or ""
        if mt.startswith("audio/"):
            return "[аудио]"
        if mt.startswith("image/"):
            return "[изображение]"
        name = ""
        for a in doc.attributes:
            if isinstance(a, DocumentAttributeFilename) and getattr(a, "file_name", None):
                name = a.file_name
                break
        return f"[файл: {name}]" if name else "[файл]"
    return "[медиа]"


def guess_msg_ext(m):
    sk = get_sticker_kind(m)
    if sk == "tgs":
        return ".tgs"
    if sk == "webm":
        return ".webm"
    doc = getattr(m, "document", None)
    if doc:
        for a in doc.attributes:
            if isinstance(a, DocumentAttributeFilename) and getattr(a, "file_name", None) and "." in a.file_name:
                e = "." + re.sub(r"[^A-Za-z0-9]", "", a.file_name.rsplit(".", 1)[1][:8])
                if len(e) > 1:
                    return e
        if doc.mime_type:
            e = mimetypes.guess_extension(doc.mime_type)
            if e:
                return e.split(";")[0]
    if getattr(m, "photo", None):
        return ".jpg"
    if sk == "webp":
        return ".webp"
    return ".bin"


async def entity_title(eid):
    return (await entity_info(eid))["title"]


async def sender_info(msg):
    try:
        if msg.out:
            return {"name": "Вы", "username": (state.get("me") or {}).get("username")}
        sid = getattr(msg, "sender_id", None)
        if sid and sid in SENDER_CACHE:
            return SENDER_CACHE[sid]
        s = await msg.get_sender()
        if not s:
            info = {"name": "Аноним", "username": None}
        else:
            name = getattr(s, "first_name", None) or getattr(s, "title", None) or str(s.id)
            last = getattr(s, "last_name", None)
            if last and getattr(s, "first_name", None):
                name = f"{s.first_name} {last}"
            info = {"name": name, "username": getattr(s, "username", None)}
        if sid:
            SENDER_CACHE[sid] = info
        return info
    except Exception:
        return {"name": "-", "username": None}


async def sender_name(msg):
    return (await sender_info(msg))["name"]


def extract_reactions(m):
    out = []
    try:
        reac = getattr(m, "reactions", None)
        if not reac:
            return out
        results = getattr(reac, "results", None) or []
        for rr in results:
            r = getattr(rr, "reaction", "")
            if hasattr(r, "emo"):
                r = r.emo
            elif not isinstance(r, str):
                r = getattr(r, "alt", "") or ""
            if r:
                out.append({"e": str(r), "c": int(getattr(rr, "count", 1) or 1)})
    except Exception:
        pass
    return out


def reactions_html(reactions):
    if not reactions:
        return ""
    chips = "".join(
        f'<span class="react-chip" onclick="quickReact(this,\'{esc(r["e"])}\')">{esc(r["e"])} {r["c"]}</span>'
        for r in reactions if r.get("e"))
    return f'<span class="react-chips">{chips}</span>' if chips else ""



def is_one_time_media(msg):
    """Определить одноразовое (view-once) медиа."""
    if not msg or not getattr(msg, "media", None):
        return False
    media = msg.media
    media_name = type(media).__name__
    # MessageMediaPhoto / Document с ttl_seconds
    if getattr(media, "ttl_seconds", None):
        return True
    # Чистый view-once часто приходит как MessageMediaUnsupported
    if media_name == "MessageMediaUnsupported":
        return True
    # Альтернативные признаки
    if getattr(msg, "ttl_period", None) and (getattr(media, "photo", None) or getattr(media, "document", None)):
        return True
    # media_unread + пустой текст часто означает одноразовое
    if getattr(msg, "media_unread", False) and not (msg.message or "").strip() and media_name in ("MessageMediaPhoto", "MessageMediaDocument", "MessageMediaUnsupported"):
        return True
    return False

def get_media_html(msg, chat_id):
    if not msg.media:
        return ""
    url = f"/media/{chat_id}/{msg.id}"
    sk = get_sticker_kind(msg)
    one_time = is_one_time_media(msg)
    ot_badge = '<span class="ot-badge" title="Одноразовое медиа">1×</span>' if one_time else ''
    ot_class = ' one-time' if one_time else ''
    pack_btn = (
        f'<button type="button" class="sticker-dl" '
        f'onclick="event.stopPropagation();openStickerPack({chat_id},{msg.id})">'
        f'Пак стикеров</button>'
    )
    no_save = 'draggable="false" oncontextmenu="return false"'
    if sk == "tgs":
        return (f'<div class="msg-body-media sticker-box">'
                f'<lottie-player src="{url}" background="transparent" speed="1" loop autoplay></lottie-player>'
                f'<div class="sticker-actions">{pack_btn}</div></div>')
    if sk == "webm":
        return (f'<div class="msg-body-media sticker-box">'
                f'<video src="{url}" class="sticker-media" autoplay loop muted playsinline {no_save}></video>'
                f'<div class="sticker-actions">{pack_btn}</div></div>')
    if sk == "webp":
        return (f'<div class="msg-body-media sticker-box">'
                f'<img src="{url}" loading="lazy" class="sticker-media" {no_save} '
                f'onclick="openMediaViewer(this.src,\'image\')">'
                f'<div class="sticker-actions">{pack_btn}</div></div>')
    if hasattr(msg.media, 'photo') and msg.media.photo:
        click_handler = "openOneTime(this, '" + url + "')" if one_time else "openMediaViewer(this.src,'image')"
        return (f'<div class="msg-body-media{ot_class}">'
                f'{ot_badge}'
                f'<img src="{url}" loading="lazy" {no_save} '
                f'onclick="{click_handler}"></div>')
    elif hasattr(msg.media, 'document') and msg.media.document:
        mime = msg.media.document.mime_type or ""
        if mime.startswith('video/'):
            return (f'<div class="msg-body-media">'
                    f'<video src="{url}" controls preload="metadata" playsinline '
                    f'draggable="false"></video></div>')
        elif mime.startswith('audio/'):
            return f'<div class="msg-body-media"><audio src="{url}" controls preload="metadata"></audio></div>'
        elif mime.startswith('image/'):
            click_handler = "openOneTime(this, '" + url + "')" if one_time else "openMediaViewer(this.src,'image')"
            return (f'<div class="msg-body-media{ot_class}">'
                    f'{ot_badge}'
                    f'<img src="{url}" loading="lazy" {no_save} '
                    f'onclick="{click_handler}"></div>')
        name = "Вложение"
        size = getattr(msg.media.document, 'size', 0)
        for attr in msg.media.document.attributes:
            if hasattr(attr, 'file_name') and attr.file_name:
                name = attr.file_name
                break
        size_str = ""
        if size:
            if size > 1048576:
                size_str = f" · {size/1048576:.1f} MB"
            elif size > 1024:
                size_str = f" · {size/1024:.1f} KB"
        return f'<a class="doc-link" href="{url}" target="_blank">{icon("download")} {esc(name)}{size_str}</a>'
    # Одноразовые / unsupported — показываем специальную карточку вместо "неподдерживаемый тип"
    if one_time or type(msg.media).__name__ == "MessageMediaUnsupported":
        btn = f'<button class="btn ot-view-btn" onclick="openOneTime(this, \'{url}\')">Просмотреть и сохранить</button>'
        return (f'<div class="msg-body-media one-time ot-card">'
                f'{ot_badge}'
                f'<div class="ot-placeholder">'
                f'<div class="ot-icon">{icon("image", "icon-lg")}</div>'
                f'<div class="ot-title">Одноразовое фото</div>'
                f'<div class="ot-sub">Нажмите, чтобы просмотреть и сохранить в кэш</div>'
                f'{btn}'
                f'</div></div>')
    return '<div class="doc-link" style="color:var(--text-muted);">Неподдерживаемый тип</div>'


def msg_bubble_html(m, chat_id):
    content = parse_markdown(m["text"]) + m["media_html"]
    safe_text_attr = safe_attr(m["raw_text"])
    out_flag = "1" if m["out"] else "0"
    edit_btn = ""
    if m["out"] and m["raw_text"]:
        edit_btn = (f'<button class="msg-action" data-text="{safe_text_attr}" '
                    f'onclick="startEdit({m["id"]}, this.dataset.text)" title="Редактировать">'
                    f'{icon("edit", "icon-sm")}</button>')
    return f'''
<div class="msg-bubble" id="msg_{m["id"]}" data-id="{m["id"]}" data-out="{out_flag}" data-text="{safe_text_attr}">
<div class="msg-body">{content}</div>
<div class="msg-meta">
{reactions_html(m.get("reactions"))}
<span>{esc(m["date"])}</span>
<div class="msg-actions">
<button class="msg-action" data-text="{safe_text_attr}" onclick="copyToClipboard(this.dataset.text)" title="Копировать">{icon("copy", "icon-sm")}</button>
<button class="msg-action" data-text="{safe_text_attr}" onclick="quoteText(this.dataset.text,{m["id"]})" title="Ответить">{icon("reply", "icon-sm")}</button>
{edit_btn}
<button class="msg-action" onclick="openForward([{m["id"]}])" title="Переслать">{icon("forward", "icon-sm")}</button>
<button class="msg-action" onclick="togglePinMsg({m["id"]})" title="Закрепить">{icon("pin", "icon-sm")}</button>
<button class="msg-action" onclick="deleteDialog([{m["id"]}])" title="Удалить">{icon("trash", "icon-sm")}</button>
</div>
</div>
</div>'''


def sender_head_html(name, username):
    copy_val = f"@{username}" if username else (name or "")
    uname = ""
    if username:
        uname = ('<button class="username-chip" data-copy="@' + esc(username) +
                 '" onclick="event.stopPropagation(); copyToClipboard(this.dataset.copy)" title="Скопировать username">' +
                 icon("at-sign") + '<span>@' + esc(username) + '</span></button>')
    return (f'<span class="chat-group-name" data-copy="{esc(copy_val)}" '
            f'onclick="copyToClipboard(this.dataset.copy)" title="Скопировать {esc(copy_val)}">{esc(name)}</span>{uname}')


def group_messages(messages):
    groups = []
    for m in messages:
        last = groups[-1] if groups else None
        if (last and last["sender"] == m["sender"] and last["out"] == m["out"]
                and last.get("day_key") == m.get("day_key") and not m["media_html"]):
            last["messages"].append(m)
        else:
            groups.append({"sender": m["sender"], "sender_username": m.get("sender_username"),
                           "out": m["out"], "day_key": m.get("day_key", ""),
                           "day_label": m.get("day_label", ""), "messages": [m]})
    return groups


def group_html(g, chat_id):
    avatar = avatar_svg(g["sender"], 36)
    out_cls = "out" if g["out"] else "in"
    msgs = "".join(msg_bubble_html(m, chat_id) for m in g["messages"])
    head = sender_head_html(g["sender"], g.get("sender_username"))
    data_key = safe_attr(f'{g["sender"]}|{1 if g["out"] else 0}|{g.get("day_key", "")}')
    return f'''
<div class="chat-group {out_cls}" data-key="{data_key}">
<div class="chat-group-avatar">{avatar}</div>
<div class="chat-group-body">
<div class="chat-group-header">{head}</div>
{msgs}
</div>
</div>'''


def chat_blocks_html(messages, chat_id):
    parts = []
    prev_day = None
    for g in group_messages(messages):
        if g["day_key"] and g["day_key"] != prev_day:
            parts.append(f'<div class="day-separator" data-day="{esc(g["day_key"])}">'
                         f'<span>{esc(g["day_label"])}</span></div>')
            prev_day = g["day_key"]
        parts.append(group_html(g, chat_id))
    return "".join(parts)


async def fetch_media_file(chat_id, msg_id):
    try:
        chat = await client.get_entity(chat_id)
        msg = await client.get_messages(chat, ids=msg_id)
        if not msg or not msg.media:
            return None
        media_type = type(msg.media).__name__ if msg.media else "None"
        if is_one_time_media(msg) or media_type == "MessageMediaUnsupported":
            print(f"[ONE-TIME] Downloading {media_type} {chat_id}/{msg_id}", flush=True)
        _ensure_nomedia(MEDIA_DIR, UPLOAD_DIR, STICKER_DIR)
        prefix = f"{chat_id}_{msg_id}_"
        for f in os.listdir(MEDIA_DIR):
            if f.startswith(prefix) and f != ".nomedia":
                return os.path.join(MEDIA_DIR, f)
        saved = await client.download_media(msg, file=os.path.join(MEDIA_DIR, prefix))
        if saved and isinstance(saved, str) and os.path.exists(saved):
            return saved
        for f in os.listdir(MEDIA_DIR):
            if f.startswith(prefix):
                return os.path.join(MEDIA_DIR, f)
        return None
    except Exception:
        return None


async def list_dialogs(filter_mode="all", limit=60):
    out = []
    try:
        async for d in client.iter_dialogs(limit=limit):
            is_user = d.is_user
            is_group = d.is_group
            is_channel = d.is_channel
            if filter_mode == "users" and not is_user:
                continue
            if filter_mode == "groups" and not is_group:
                continue
            if filter_mode == "channels" and not (is_channel and not is_group):
                continue
            msg = d.message
            out.append({
                "id": d.id,
                "title": d.name or "Без названия",
                "preview": preview_text(msg),
                "time": fmt_date(getattr(msg, 'date', None)) if msg else "",
                "unread": int(d.unread_count or 0),
                "pinned": bool(getattr(d, "pinned", False)) or (d.id in state["pinned"]),
            })
    except Exception:
        # Фолбэк: кэшированные чаты
        cached = db_list_chats()
        for c in cached:
            if filter_mode in ("all", "users", "groups", "channels"):
                out.append({
                    "id": c["id"], "title": c["title"], "preview": f"[кэш] {c['count']} сообщений",
                    "time": "", "unread": 0, "pinned": c["id"] in state["pinned"],
                })
    out.sort(key=lambda x: (not x["pinned"],))
    return out


async def load_messages(eid, q=None, limit=50, min_id=0, offset_id=None, max_id=None, only_me=False):
    """Загружает сообщения. Пишет в кэш. При ошибке — читает из кэша."""
    try:
        title = await entity_title(eid)
    except Exception:
        cached = db_get_chat(eid) or {}
        title = cached.get("title") or str(eid)

    messages = []
    seen = set()
    from_cache_only = False
    try:
        kwargs = {"limit": limit}
        if q:
            kwargs["search"] = q
        if min_id:
            kwargs["min_id"] = min_id
        if offset_id:
            kwargs["offset_id"] = offset_id
        if max_id:
            kwargs["max_id"] = max_id
        if only_me:
            kwargs["from_user"] = "me"
        it = client.iter_messages(eid, **kwargs)
        async for m in it:
            if not m or not getattr(m, "id", None):
                continue
            if m.id in seen:
                continue
            if offset_id and m.id >= offset_id:
                continue
            if max_id and m.id >= max_id:
                continue
            if only_me and not getattr(m, "out", False):
                continue
            seen.add(m.id)
            day_key, day_label = fmt_day(m.date)
            sinfo = await sender_info(m)
            messages.append({
                "id": m.id,
                "date": fmt_full_date(m.date),
                "day_key": day_key,
                "day_label": day_label,
                "sender": sinfo["name"],
                "sender_username": sinfo.get("username"),
                "text": m.message or "",
                "raw_text": m.message or "",
                "out": bool(m.out),
                "media_html": get_media_html(m, eid),
                "sender_id": getattr(m, 'sender_id', None),
                "reactions": extract_reactions(m),
            })
        # Сохраняем в кэш
        if messages:
            cinfo = None
            try:
                cinfo = await entity_info(eid)
            except Exception:
                pass
            db_save_messages(
                eid, messages,
                chat_title=(cinfo or {}).get("title") or title,
                chat_username=(cinfo or {}).get("username"),
                chat_kind=(cinfo or {}).get("kind"),
            )
    except Exception as e:
        # Фолбэк: кэш
        print(f"[LOAD] Telegram fail, fallback to cache: {e}", flush=True)
        from_cache_only = True
        cached = db_load_messages(
            eid, before_id=max_id if max_id else (offset_id if offset_id else None),
            after_id=min_id if min_id else None,
            limit=limit, only_me=only_me, search=q,
        )
        messages = cached
        cached_chat = db_get_chat(eid) or {}
        if cached_chat.get("title"):
            title = cached_chat["title"]

    messages.sort(key=lambda x: x["id"])
    return title, messages


async def run_global_search(q, filter_type=None, limit=40):
    messages = []
    try:
        filter_obj = None
        if filter_type == "photo":
            filter_obj = InputMessagesFilterPhotos()
        elif filter_type == "doc":
            filter_obj = InputMessagesFilterDocument()
        elif filter_type == "audio":
            filter_obj = InputMessagesFilterMusic()
        elif filter_type == "url":
            filter_obj = InputMessagesFilterUrl()
        async for m in client.iter_messages(None, search=q, filter=filter_obj, limit=limit):
            chat_id = m.chat_id if m.chat else 0
            chat_title = await entity_title(chat_id) if chat_id else "Чат"
            messages.append({
                "id": m.id, "chat_id": chat_id, "chat_title": chat_title,
                "date": fmt_full_date(m.date), "sender": await sender_name(m),
                "text": m.message or "", "out": m.out,
                "media_html": get_media_html(m, chat_id),
            })
    except Exception:
        pass
    # Дополняем из локального кэша
    try:
        con = _db()
        cur = con.cursor()
        rows = cur.execute(
            "SELECT * FROM cached_messages WHERE LOWER(text) LIKE ? ORDER BY msg_id DESC LIMIT ?",
            (f"%{q.lower()}%", limit)
        ).fetchall()
        titles = {r["chat_id"]: (r["title"] or f"Чат {r['chat_id']}")
                  for r in cur.execute("SELECT chat_id, title FROM cached_chats").fetchall()}
        seen = {(m["chat_id"], m["id"]) for m in messages}
        for r in rows:
            key = (r["chat_id"], r["msg_id"])
            if key in seen:
                continue
            messages.append({
                "id": r["msg_id"], "chat_id": r["chat_id"],
                "chat_title": titles.get(r["chat_id"], f"Чат {r['chat_id']}"),
                "date": r["date"], "sender": r["sender"],
                "text": r["text"], "out": bool(r["out"]),
                "media_html": r["media_html"] or "",
            })
        con.close()
    except Exception:
        pass
    return messages


# ====================== DESTROY USER ======================
async def destroy_user_full(uid):
    result = {
        "blocked": False, "wiped": False, "dialog_deleted": False,
        "message_count_deleted": 0, "message_count_remaining": None,
        "steps": [], "errors": [],
    }

    def log(msg):
        line = f"[DESTROY {uid}] {msg}"
        print(line, flush=True)
        result["steps"].append(msg)

    log(f"═══ Начало уничтожения uid={uid} ═══")

    peer = None
    try:
        entity = await client.get_entity(uid)
        peer = await client.get_input_entity(entity)
        log(f"✓ Entity resolved: {type(entity).__name__} peer={type(peer).__name__}")
    except Exception as e:
        log(f"✗ Резолв упал: {type(e).__name__}: {e}")
        result["errors"].append(f"resolve: {e}")
        return result

    try:
        await client(BlockRequest(id=peer))
        result["blocked"] = True
        log("✓ BlockRequest OK — пользователь заблокирован")
    except Exception as e:
        log(f"✗ BlockRequest FAILED: {type(e).__name__}: {e}")
        result["errors"].append(f"block: {e}")

    try:
        await client(DeleteHistoryRequest(peer=peer, max_id=0, revoke=True))
        result["wiped"] = True
        log("✓ DeleteHistoryRequest(revoke=True) OK — вся переписка удалена у обоих")
    except Exception as e:
        log(f"✗ DeleteHistoryRequest FAILED: {type(e).__name__}: {e}")
        result["errors"].append(f"delete_history: {e}")

        try:
            deleted = 0
            rounds = 0
            while rounds < 50:
                rounds += 1
                ids = []
                async for m in client.iter_messages(peer, limit=100):
                    ids.append(m.id)
                if not ids:
                    break
                await client.delete_messages(peer, ids, revoke=True)
                deleted += len(ids)
                log(f"  ↻ fallback раунд {rounds}: удалено {len(ids)} (итого {deleted})")
                if len(ids) < 100:
                    break
            if deleted > 0:
                result["wiped"] = True
                result["message_count_deleted"] = deleted
                log(f"✓ Fallback wipe завершён: {deleted} сообщений")
            else:
                log("⚠ Fallback: сообщений не найдено (возможно, уже удалены)")
                result["wiped"] = True
        except Exception as e2:
            log(f"✗ Fallback wipe FAILED: {type(e2).__name__}: {e2}")
            result["errors"].append(f"fallback_wipe: {e2}")
            print(traceback.format_exc(), flush=True)

    try:
        await client.delete_dialog(peer, revoke=False)
        result["dialog_deleted"] = True
        log("✓ Диалог удалён из списка")
    except Exception as e:
        log(f"✗ delete_dialog FAILED: {type(e).__name__}: {e}")
        result["errors"].append(f"delete_dialog: {e}")

    try:
        cnt = 0
        async for _ in client.iter_messages(peer, limit=10):
            cnt += 1
        result["message_count_remaining"] = cnt
        log(f"▸ ПРОВЕРКА: осталось сообщений = {cnt}")
    except Exception as e:
        log(f"Проверка не удалась: {e}")

    log(f"═══ ИТОГ: blocked={result['blocked']}, wiped={result['wiped']}, "
        f"dialog_deleted={result['dialog_deleted']}, errors={len(result['errors'])} ═══")
    return result


# ====================== BIG CHAT JS ======================
CHAT_JS_TEMPLATE = r"""
const CHAT_ID = __CHAT_ID__;
const CHAT_LINK = '__CHAT_LINK__';
const CHAT_KIND = '__CHAT_KIND__';
const ONLY_ME = __ONLY_ME__;
let lastMsgId = __LAST_ID__;
const chatBox = document.getElementById('chatBox');
const msgInput = document.getElementById('msgInput');
const draftKey = 'draft_' + CHAT_ID;
let selectedFiles = [];
let replyText = '';
let replyToId = null;
let editId = null;
let selectMode = false;
const selectedIds = new Set();
const haptic = (ms)=>{ if (navigator.vibrate) try{navigator.vibrate(ms);}catch(e){} };

if (msgInput && localStorage.getItem(draftKey)) msgInput.value = localStorage.getItem(draftKey);
msgInput?.addEventListener('input', ()=>{ localStorage.setItem(draftKey, msgInput.value); autoResize(); });
function autoResize(){ if(!msgInput) return; msgInput.style.height='auto'; msgInput.style.height=Math.min(msgInput.scrollHeight,120)+'px'; }
autoResize();
if (location.hash.startsWith('#msg_')) setTimeout(highlightTarget,250);
else if (chatBox) setTimeout(()=>{ chatBox.scrollTop = chatBox.scrollHeight; }, 80);
if (window.innerWidth<=900){
  document.getElementById('sidebar')?.classList.remove('open');
  document.getElementById('sbBackdrop')?.classList.remove('active');
}
function escHtml(s){ return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function escAttr(s){ return escHtml(s).replace(/\n/g,'&#10;').replace(/'/g,'&#39;'); }

function renderFiles(){
  const box=document.getElementById('chatFiles');
  if (!box) return;
  box.innerHTML = selectedFiles.map((f,i)=>`<div class="file-chip">__ICON_FILE__<span class="file-chip-name">${escHtml(f.name)}</span><button class="file-chip-close" onclick="removeFile(${i})">__ICON_X__</button></div>`).join('');
}
function onFileSelected(el){
  if(el.files){ for(const f of el.files) selectedFiles.push(f); renderFiles(); showToast(`Добавлено файлов: ${el.files.length}`,'ok'); }
  el.value='';
}
function removeFile(i){ selectedFiles.splice(i,1); renderFiles(); }

function quoteText(text, mid){
  replyText=text; replyToId=mid||null;
  const rt = document.getElementById('chatReplyText'); if (rt) rt.innerText=text || '(медиа)';
  const r = document.getElementById('chatReply'); if (r) r.style.display='flex';
  msgInput?.focus(); autoResize(); haptic(8); showToast('Ответ на сообщение','ok');
}
function clearReply(){ replyText=''; replyToId=null; const r = document.getElementById('chatReply'); if (r) r.style.display='none'; }

function startEdit(mid, text){
  editId=mid; if(msgInput) msgInput.value=text;
  document.getElementById('editBanner')?.classList.add('active');
  const ebt = document.getElementById('editBannerText');
  if (ebt) ebt.innerText = (text||'').slice(0,60) + ((text||'').length>60?'...':'');
  msgInput?.focus(); autoResize(); haptic(8);
}
function cancelEdit(){
  editId=null; if(msgInput) msgInput.value=localStorage.getItem(draftKey)||'';
  document.getElementById('editBanner')?.classList.remove('active');
  autoResize();
}

let pendingDeleteIds=[]; let pendingDeleteOut=false;
function deleteDialog(ids){
  if (!ids || !ids.length) return;
  pendingDeleteIds=ids;
  const first=document.getElementById('msg_'+ids[0]);
  pendingDeleteOut = first && first.dataset.out==='1';
  const allBtn = document.getElementById('delBtnAll');
  if (allBtn) allBtn.style.display = pendingDeleteOut ? 'flex' : 'none';
  document.getElementById('delModal')?.classList.add('active');
  if (window.pushHistoryGuard) pushHistoryGuard();
  haptic(12);
}
function hideDelete(){ document.getElementById('delModal')?.classList.remove('active'); pendingDeleteIds=[]; if(window.popHistoryGuard) popHistoryGuard(); }
async function doDelete(scope){
  const ids=[...pendingDeleteIds]; hideDelete();
  if (!ids.length) return;
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/delete_messages',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ids:ids,scope:scope})});
    const d=await r.json();
    if(d.ok){
      ids.forEach(id=>{
        const b=document.getElementById('msg_'+id);
        if (!b) return;
        const group = b.closest('.chat-group');
        if (group && group.querySelectorAll('.msg-bubble').length===1) group.remove();
        else b.remove();
      });
      showToast(scope==='all'?'Удалено у всех':'Удалено у вас','ok');
      exitSelect();
    } else showToast('Ошибка: '+(d.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
}

let fwdIds=[]; let fwdCache=[];
function openForward(ids){
  fwdIds=ids; buildFwdList();
  document.getElementById('fwdModal')?.classList.add('active');
  if (window.pushHistoryGuard) pushHistoryGuard();
  haptic(8);
}
function hideForward(){ document.getElementById('fwdModal')?.classList.remove('active'); if(window.popHistoryGuard) popHistoryGuard(); }
async function buildFwdList(){
  const box=document.getElementById('fwdList');
  if (!box) return;
  box.innerHTML='<div style="padding:20px;text-align:center;color:var(--text-muted);">Загрузка...</div>';
  try{
    if(!fwdCache.length){ const r=await fetch('/api/dialogs'); const d=await r.json(); fwdCache=d.dialogs||[]; }
    const q=(document.getElementById('fwdSearch')?.value||'').toLowerCase();
    const items=fwdCache.filter(x=>x.title.toLowerCase().includes(q)).slice(0,30);
    box.innerHTML = items.map(x=>`<div class="modal-item" onclick="doForward(${x.id})">${x.avatar}<span class="modal-item-title">${escHtml(x.title)}</span><span class="modal-item-sub">ID ${x.id}</span></div>`).join('')
      || '<div style="padding:20px;text-align:center;color:var(--text-muted);">Ничего не найдено</div>';
  }catch(e){ box.innerHTML='<div style="padding:20px;color:var(--bad);">Ошибка загрузки</div>'; }
}
function filterFwd(){ buildFwdList(); }
async function doForward(to){
  hideForward();
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/forward',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({ids:fwdIds,to:to})});
    const d=await r.json();
    if(d.ok){ showToast('Переслано','ok'); exitSelect(); } else showToast('Ошибка: '+(d.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
}

async function togglePinMsg(mid){
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/pin_msg/'+mid,{
      method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});
    const d=await r.json();
    if(d.ok) showToast('Сообщение закреплено','ok'); else showToast('Ошибка: '+(d.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
}

async function sendReaction(mid, emoji){
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/react/'+mid,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({reaction:emoji})});
    const d=await r.json();
    if(d.ok) showToast('Реакция '+emoji,'ok'); else showToast('Недоступно: '+(d.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
}
function quickReact(el, emoji){
  const bubble=el.closest('.msg-bubble');
  if(bubble) sendReaction(parseInt(bubble.dataset.id), emoji);
}

function toggleSelectMode(on){
  selectMode=on;
  document.getElementById('selectBar')?.classList.toggle('active',on);
  document.getElementById('selectActions')?.classList.toggle('active',on);
  if(!on){
    selectedIds.clear();
    document.querySelectorAll('.msg-bubble.selected').forEach(b=>b.classList.remove('selected'));
    updateSelectCount();
  } else {
    if (window.pushHistoryGuard) pushHistoryGuard();
  }
}
function exitSelect(){ toggleSelectMode(false); if(window.popHistoryGuard) popHistoryGuard(); }
function toggleSelect(bubble){
  const id=parseInt(bubble.dataset.id);
  if(selectedIds.has(id)){ selectedIds.delete(id); bubble.classList.remove('selected'); }
  else { selectedIds.add(id); bubble.classList.add('selected'); }
  updateSelectCount(); haptic(6);
}
function updateSelectCount(){
  const el = document.getElementById('selectCount');
  if (el) el.innerText='Выбрано: '+selectedIds.size;
}
function toggleSelectById(mid){
  const b=document.getElementById('msg_'+mid);
  if(b) toggleSelect(b);
}

let ctxTarget=null;
function openCtx(bubble){
  ctxTarget=bubble; bubble.classList.add('ctx-target');
  const id=parseInt(bubble.dataset.id);
  const out=bubble.dataset.out==='1';
  const text=bubble.dataset.text||'';
  const prev = document.getElementById('ctxPreview');
  if (prev) prev.innerText = text.slice(0,80) || (bubble.querySelector('.msg-body')?.innerText.slice(0,80)||'(медиа)');
  const ce = document.getElementById('ctxEdit'); if (ce) ce.style.display=(out&&text)?'flex':'none';
  const cd = document.getElementById('ctxDeleteAll'); if (cd) cd.style.display=out?'flex':'none';
  document.getElementById('ctxMenu')?.classList.add('active');
  if(window.pushHistoryGuard) pushHistoryGuard();
  haptic(15);
}
function closeCtx(){
  document.getElementById('ctxMenu')?.classList.remove('active');
  if(ctxTarget){ ctxTarget.classList.remove('ctx-target'); ctxTarget=null; }
  if(window.popHistoryGuard) popHistoryGuard();
}
function ctxReply(){ if(ctxTarget) quoteText(ctxTarget.dataset.text||'', parseInt(ctxTarget.dataset.id)); closeCtx(); }
function ctxCopy(){ if(ctxTarget) copyToClipboard(ctxTarget.dataset.text||''); closeCtx(); }
function ctxEdit(){ if(ctxTarget) startEdit(parseInt(ctxTarget.dataset.id), ctxTarget.dataset.text||''); closeCtx(); }
function ctxForward(){ if(ctxTarget) openForward([parseInt(ctxTarget.dataset.id)]); closeCtx(); }
function ctxPin(){ if(ctxTarget) togglePinMsg(parseInt(ctxTarget.dataset.id)); closeCtx(); }
function ctxSelect(){ toggleSelectMode(true); if(ctxTarget) toggleSelect(ctxTarget); closeCtx(); }
function ctxReact(e){ if(ctxTarget) sendReaction(parseInt(ctxTarget.dataset.id), e); closeCtx(); }
function ctxDelete(){ if(ctxTarget) deleteDialog([parseInt(ctxTarget.dataset.id)]); closeCtx(); }
function ctxDeleteAll(){ if(ctxTarget) deleteDialog([parseInt(ctxTarget.dataset.id)]); closeCtx(); }

let pressTimer=null; let pressStartY=0;
chatBox?.addEventListener('touchstart',e=>{
  const bubble=e.target.closest('.msg-bubble');
  if(!bubble) return;
  pressStartY = e.touches[0].clientY;
  pressTimer=setTimeout(()=>{ if (!selectMode) openCtx(bubble); pressTimer=null; },480);
},{passive:true});
chatBox?.addEventListener('touchend',()=>{ if(pressTimer){ clearTimeout(pressTimer); pressTimer=null; } },{passive:true});
chatBox?.addEventListener('touchmove',e=>{
  if(pressTimer){
    const y = e.touches[0].clientY;
    if (Math.abs(y - pressStartY) > 12) { clearTimeout(pressTimer); pressTimer=null; }
  }
},{passive:true});
chatBox?.addEventListener('contextmenu',e=>{
  const bubble=e.target.closest('.msg-bubble');
  if(bubble){ e.preventDefault(); if(selectMode){ toggleSelect(bubble); } else openCtx(bubble); }
});
chatBox?.addEventListener('click',e=>{
  if(!selectMode) return;
  const bubble=e.target.closest('.msg-bubble');
  if(bubble){ e.preventDefault(); e.stopPropagation(); toggleSelect(bubble); }
});
document.getElementById('ctxMenu')?.addEventListener('click',e=>{
  if(e.target===document.getElementById('ctxMenu')) closeCtx();
});

let mediaRecorder=null; let audioChunks=[]; let recTimer=null; let recSeconds=0;
async function toggleVoice(){
  if(mediaRecorder && mediaRecorder.state==='recording'){ stopVoice(true); return; }
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    mediaRecorder=new MediaRecorder(stream);
    audioChunks=[];
    mediaRecorder.ondataavailable=e=>audioChunks.push(e.data);
    mediaRecorder.onstop=()=>{
      stream.getTracks().forEach(t=>t.stop());
      const blob=new Blob(audioChunks,{type:mediaRecorder.mimeType||'audio/webm'});
      if(blob.size>300) sendVoice(blob);
      mediaRecorder=null;
    };
    mediaRecorder.start();
    recSeconds=0;
    const vt = document.getElementById('voiceTimer'); if (vt) vt.innerText='0:00';
    document.getElementById('voiceBar')?.classList.add('active');
    recTimer=setInterval(()=>{
      recSeconds++;
      const m=Math.floor(recSeconds/60);
      const s=String(recSeconds%60).padStart(2,'0');
      if (vt) vt.innerText=m+':'+s;
    },1000);
    haptic(15); showToast('Запись начата','ok');
  }catch(e){ showToast('Нет доступа к микрофону','error'); }
}
function stopVoice(send){
  if(!mediaRecorder) return;
  clearInterval(recTimer);
  document.getElementById('voiceBar')?.classList.remove('active');
  if(send){ try{ mediaRecorder.stop(); }catch(e){} }
  else {
    try{ mediaRecorder.onstop=null; mediaRecorder.stop(); mediaRecorder.stream.getTracks().forEach(t=>t.stop()); }catch(e){}
    mediaRecorder=null;
  }
}
function cancelVoice(){ stopVoice(false); audioChunks=[]; showToast('Запись отменена','error'); }
async function sendVoice(blob){
  const fd=new FormData();
  fd.append('file', blob, 'voice_message.ogg');
  fd.append('voice','1');
  if(replyToId) fd.append('reply_to', replyToId);
  try{
    const res=await fetch('/api/chat/'+CHAT_ID+'/send',{method:'POST',body:fd});
    const data=await res.json();
    if(data.ok){ clearReply(); pollNewMessages(CHAT_ID); showToast('Голосовое отправлено','ok'); }
    else showToast('Ошибка: '+(data.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
}

async function sendMessage(cid){
  if(editId){
    const text=msgInput.value.trim();
    if(!text) return;
    try{
      const r=await fetch('/api/chat/'+cid+'/edit/'+editId,{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({text:text})});
      const d=await r.json();
      if(d.ok){
        const b=document.getElementById('msg_'+editId);
        if(b){
          const body=b.querySelector('.msg-body');
          if(body) body.innerHTML = escHtml(text).replace(/\n/g,'<br>');
          b.dataset.text=text;
        }
        cancelEdit();
        localStorage.setItem(draftKey,'');
        showToast('Сообщение изменено','ok');
      } else showToast('Ошибка: '+(d.error||''),'error');
    }catch(e){ showToast('Ошибка сети','error'); }
    return;
  }
  const text=msgInput.value.trim();
  if(!text && selectedFiles.length===0) return;
  const btn=document.getElementById('sendBtn'); if (btn) btn.disabled=true;
  const formData=new FormData();
  formData.append('text',text);
  if(replyToId) formData.append('reply_to', replyToId);
  if(document.getElementById('silentOpt')?.checked) formData.append('silent','1');
  const sch=document.getElementById('scheduleOpt')?.value;
  if(sch) formData.append('schedule_date',sch);
  selectedFiles.forEach(f=>formData.append('file',f));
  try{
    const res=await fetch('/api/chat/'+cid+'/send',{method:'POST',body:formData});
    const data=await res.json();
    if(data.ok){
      msgInput.value='';
      localStorage.removeItem(draftKey);
      selectedFiles=[]; renderFiles(); autoResize(); clearReply();
      setTimeout(()=>pollNewMessages(cid), 500);
      showToast('Доставлено','ok'); haptic(12);
    }
    else showToast('Ошибка: '+(data.error||''),'error');
  }catch(e){ showToast('Ошибка сети','error'); }
  finally{ if (btn) btn.disabled=false; }
}
const canQuickSend = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
msgInput?.addEventListener('keydown',e=>{
  if(e.key==='Enter' && !e.shiftKey && (e.ctrlKey || (canQuickSend && !e.altKey && !e.metaKey))){
    e.preventDefault(); sendMessage(CHAT_ID);
  }
});

const EMOJIS = ["😀","😁","😂","🤣","😊","😍","🥰","😘","😎","🤔","😅","😇","🙃","😉","😌","😜","🤪","😝","🤗","🤩","😏","😒","🙄","😬","😴","🤤","😪","🥱","😷","🤒","🤕","🥵","🥶","😵","🤯","🥳","😤","😡","🤬","😈","💀","💩","🤡","👻","👽","🤖","💋","❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","🔥","⭐","🌟","✨","⚡","💫","💥","👍","👎","👌","✌️","🤞","🤟","🤘","👏","🙌","🤝","🙏","💪","👋","🤙","✍️","🎉","🎊","🎁","🎂","🏆","🥇","🥈","🥉","🎯","🎮"];
function buildEmojiPicker(){
  const p = document.getElementById('emojiPicker'); if (!p) return;
  p.innerHTML = '<div class="emoji-grid">' + EMOJIS.map(e=>`<button class="emoji-btn" onclick="insertEmoji('${e}')">${e}</button>`).join('') + '</div>';
}
function insertEmoji(e){
  msgInput.value += e;
  localStorage.setItem(draftKey, msgInput.value);
  msgInput.focus(); autoResize();
  document.getElementById('emojiPicker')?.classList.remove('active');
}
function toggleEmoji(){
  const p = document.getElementById('emojiPicker'); if (!p) return;
  if (!p.dataset.built) { buildEmojiPicker(); p.dataset.built = '1'; }
  p.classList.toggle('active');
}
document.addEventListener('click', e=>{
  if (!e.target.closest('#emojiBtn')) document.getElementById('emojiPicker')?.classList.remove('active');
});

let firstMsgId=__FIRST_ID__;
let topDayKey='__FIRST_DAY__';
let bottomDayKey='__LAST_DAY__';
let loadingHistory=false;
let hasMoreHistory=__HAS_MORE__;
const historyBtnHtml='__ICON_UP__ Загрузить старые сообщения';
function avatarSvg(name,size){
  const colors=["#ef4444","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899","#14b8a6"];
  let h=0; for(const c of (name||'?')) h=((h*31)+c.codePointAt(0))>>>0;
  const color=colors[h%colors.length];
  const parts=(name||'?').trim().split(/\s+/);
  const initials=(parts.length>=2?(parts[0][0]||'')+(parts[1][0]||''):(parts[0]||'??').slice(0,2)).toUpperCase();
  const fs=Math.round(size*0.4);
  return `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" class="avatar"><rect width="${size}" height="${size}" rx="${Math.floor(size/2)}" fill="${color}"/><text x="50%" y="50%" dy=".35em" text-anchor="middle" fill="white" font-family="Inter, sans-serif" font-weight="600" font-size="${fs}">${escHtml(initials)}</text></svg>`;
}
function groupHeadHtml(sender,username){
  const copyVal=username?'@'+username:sender;
  const chip = username ? `<button class="username-chip" data-copy="@${escAttr(username)}" onclick="event.stopPropagation(); copyToClipboard(this.dataset.copy)">__ICON_AT__<span>@${escHtml(username)}</span></button>` : '';
  return `<span class="chat-group-name" data-copy="${escAttr(copyVal)}" onclick="copyToClipboard(this.dataset.copy)">${escHtml(sender)}</span>${chip}`;
}
function reactChips(list){
  if(!list||!list.length) return '';
  const chips=list.filter(r=>r.e).map(r=>`<span class="react-chip" onclick="quickReact(this,'${escAttr(r.e)}')">${escHtml(r.e)} ${r.c}</span>`).join('');
  return chips?`<span class="react-chips">${chips}</span>`:'';
}
function bubbleHtml(m){
  const safeTxt=escAttr(m.raw_text);
  const editBtn=(m.out&&m.raw_text)?`<button class="msg-action" data-text="${safeTxt}" onclick="startEdit(${m.id}, this.dataset.text)" title="Редактировать">__ICON_EDIT__</button>`:'';
  return `<div class="msg-bubble" id="msg_${m.id}" data-id="${m.id}" data-out="${m.out?1:0}" data-text="${safeTxt}">
<div class="msg-body">${m.html||''}${m.media_html||''}</div>
<div class="msg-meta">${reactChips(m.reactions)}<span>${escHtml(m.date||'')}</span>
<div class="msg-actions">
<button class="msg-action" data-text="${safeTxt}" onclick="copyToClipboard(this.dataset.text)" title="Копировать">__ICON_COPY__</button>
<button class="msg-action" data-text="${safeTxt}" onclick="quoteText(this.dataset.text,${m.id})" title="Ответить">__ICON_REPLY__</button>
${editBtn}
<button class="msg-action" onclick="openForward([${m.id}])" title="Переслать">__ICON_FWD__</button>
<button class="msg-action" onclick="togglePinMsg(${m.id})" title="Закрепить">__ICON_PIN__</button>
<button class="msg-action" onclick="deleteDialog([${m.id}])" title="Удалить">__ICON_TRASH__</button>
</div></div></div>`;
}
function msgKey(m){ return (m.sender||'')+'|'+(m.out?1:0)+'|'+(m.day_key||''); }
function groupHtml(items){
  const g0=items[0]; const out=!!g0.out;
  return `<div class="chat-group ${out?'out':'in'}" data-key="${escAttr(msgKey(g0))}">
<div class="chat-group-avatar">${avatarSvg(g0.sender,36)}</div>
<div class="chat-group-body"><div class="chat-group-header">${groupHeadHtml(g0.sender||'?',g0.sender_username||'')}</div>
${items.map(bubbleHtml).join('')}</div></div>`;
}
function sepHtml(dayKey,dayLabel){ return `<div class="day-separator" data-day="${escAttr(dayKey)}"><span>${escHtml(dayLabel)}</span></div>`; }
function lastGroupEl(){ if(!chatBox) return null; const all=chatBox.querySelectorAll('.chat-group'); return all.length?all[all.length-1]:null; }
function appendMessages(list){
  if (!chatBox) return;
  for(const m of list){
    if(!m||document.getElementById('msg_'+m.id)) continue;
    lastMsgId=Math.max(lastMsgId,m.id);
    if(m.day_label&&m.day_key&&m.day_key!==bottomDayKey){
      chatBox.insertAdjacentHTML('beforeend',sepHtml(m.day_key,m.day_label));
      bottomDayKey=m.day_key;
    }
    const last=lastGroupEl();
    if(last && last.dataset.key===msgKey(m) && !m.media_html){
      last.querySelector('.chat-group-body').insertAdjacentHTML('beforeend',bubbleHtml(m));
    } else {
      chatBox.insertAdjacentHTML('beforeend',groupHtml([m]));
    }
  }
}
function batchGroups(list){
  const batches=[]; let cur=null;
  for(const m of list){
    const k=msgKey(m);
    if(cur&&cur.key===k&&!m.media_html) cur.items.push(m);
    else { cur={key:k,items:[m]}; batches.push(cur); }
  }
  return batches;
}
function prependMessages(list){
  const top=document.getElementById('historyTop');
  if(!top||!list.length||!chatBox) return 0;
  const fresh=list.filter(m=>m && m.id && !document.getElementById('msg_'+m.id));
  if(!fresh.length) return 0;
  const batches=batchGroups(fresh);
  let html='';
  let prevDay=null;
  const existingDays=new Set(Array.from(chatBox.querySelectorAll('.day-separator')).map(el=>el.dataset.day||''));
  for(const b of batches){
    const d=b.items[0].day_key||'';
    const lbl=b.items[0].day_label||'';
    if(lbl && d && d!==prevDay && !existingDays.has(d)){
      html+=sepHtml(d,lbl);
      existingDays.add(d);
    }
    prevDay=d;
    html+=groupHtml(b.items);
  }
  const tmp=document.createElement('div'); tmp.innerHTML=html;
  let firstExisting=top.nextElementSibling;
  while(firstExisting && firstExisting.classList && firstExisting.classList.contains('day-separator')){
    firstExisting=firstExisting.nextElementSibling;
  }
  const lastBatch=batches[batches.length-1];
  if(firstExisting && firstExisting.classList && firstExisting.classList.contains('chat-group')
      && lastBatch && firstExisting.dataset.key===lastBatch.key){
    const body=firstExisting.querySelector('.chat-group-body');
    const header=body && body.querySelector('.chat-group-header');
    if(header){
      let ref=header;
      for(const m of lastBatch.items){
        if(document.getElementById('msg_'+m.id)) continue;
        const wrap=document.createElement('div'); wrap.innerHTML=bubbleHtml(m);
        const node=wrap.firstElementChild; if(!node) continue;
        ref.after(node); ref=node;
      }
    }
    const rendered=tmp.querySelectorAll('.chat-group');
    if(rendered.length) rendered[rendered.length-1].remove();
  }
  const frag=document.createDocumentFragment();
  while(tmp.firstChild) frag.appendChild(tmp.firstChild);
  top.after(frag);
  if(fresh[0] && fresh[0].day_key) topDayKey=fresh[0].day_key;
  return fresh.length;
}
async function loadHistory(force){
  if(loadingHistory) return;
  if(!firstMsgId){
    const first=chatBox && chatBox.querySelector('.msg-bubble[data-id]');
    if(first) firstMsgId=parseInt(first.dataset.id,10)||0;
  }
  if(!firstMsgId) return;
  if(!force && !hasMoreHistory) return;
  loadingHistory=true;
  const btn=document.getElementById('historyBtn');
  if(btn){ btn.disabled=true; btn.innerHTML='__ICON_LOADER__ Загрузка...'; }
  const prevH=chatBox ? chatBox.scrollHeight : 0;
  const prevTop = chatBox ? chatBox.scrollTop : 0;
  try{
    const only = ONLY_ME ? '&only_me=1' : '';
    const res=await fetch('/api/chat/'+CHAT_ID+'/history?before_id='+firstMsgId+only);
    const data=await res.json();
    const list=(data.messages||[]).slice().sort((a,b)=>(a.id||0)-(b.id||0));
    const added=list.length ? prependMessages(list) : 0;
    if(list.length){
      const ids=list.map(m=>m.id).filter(Boolean);
      firstMsgId=Math.min(firstMsgId, ...ids);
    }
    if(chatBox){
      const newH = chatBox.scrollHeight;
      chatBox.scrollTop = (newH - prevH) + prevTop;
    }
    if(data.error) showToast(data.error,'error');
    if(list.length===0) hasMoreHistory=false;
    else hasMoreHistory = data.has_more !== false;
    if(!hasMoreHistory){
      const top=document.getElementById('historyTop');
      if(top) top.innerHTML='<div class="history-end">Начало истории</div>';
    } else if(btn){
      btn.disabled=false; btn.innerHTML=historyBtnHtml;
    }
  }catch(e){
    if(btn){ btn.disabled=false; btn.innerHTML=historyBtnHtml; }
    showToast('Не удалось загрузить историю','error');
    hasMoreHistory=true;
  }
  loadingHistory=false;
}
let ptrStartY=0, ptrPulling=false;
const ptrIndicator=document.getElementById('ptrIndicator');
chatBox?.addEventListener('touchstart',e=>{
  if (chatBox.scrollTop <= 0) { ptrStartY = e.touches[0].clientY; ptrPulling = true; }
},{passive:true});
chatBox?.addEventListener('touchmove',e=>{
  if (!ptrPulling) return;
  const dy = e.touches[0].clientY - ptrStartY;
  if (dy > 60 && !loadingHistory) ptrIndicator?.classList.add('active');
},{passive:true});
chatBox?.addEventListener('touchend',e=>{
  if (!ptrPulling) return;
  ptrPulling = false;
  const dy = (e.changedTouches[0]?.clientY || 0) - ptrStartY;
  if (dy > 60) {
    ptrIndicator?.classList.add('spin');
    loadHistory(true).finally(()=>{
      setTimeout(()=>{
        ptrIndicator?.classList.remove('active');
        ptrIndicator?.classList.remove('spin');
      }, 300);
    });
  } else {
    ptrIndicator?.classList.remove('active');
  }
},{passive:true});

chatBox?.addEventListener('scroll',()=>{
  if(chatBox.scrollTop<180) loadHistory();
  updateFab();
});
(function setupHistoryObserver(){
  const top=document.getElementById('historyTop');
  if(!top || !chatBox || !('IntersectionObserver' in window)) return;
  const io=new IntersectionObserver((entries)=>{
    if(entries.some(e=>e.isIntersecting)) loadHistory();
  },{root:chatBox, rootMargin:'120px 0px 0px 0px', threshold:0.01});
  io.observe(top);
})();

function toggleMenu(e){ e.stopPropagation(); document.getElementById('chatMenu')?.classList.toggle('active'); }
document.addEventListener('click',e=>{
  if(!e.target.closest('.menu-wrap')) document.getElementById('chatMenu')?.classList.remove('active');
});
async function togglePin(){
  const r=await fetch('/api/chat/'+CHAT_ID+'/pin',{method:'POST'});
  const d=await r.json();
  showToast(d.pinned?'Чат закреплён':'Чат откреплён','ok');
  setTimeout(()=>location.reload(),600);
}
async function leaveChat(){
  if(!confirm('Покинуть этот чат?')) return;
  const r=await fetch('/api/chat/'+CHAT_ID+'/leave',{method:'POST'});
  const d=await r.json();
  if(d.ok) location.href='/'; else showToast('Ошибка: '+(d.error||''),'error');
}
function copyChatLink(){
  if(!CHAT_LINK){ showToast('У чата нет публичной ссылки','error'); return; }
  copyToClipboard(CHAT_LINK);
}
async function markRead(){
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/read',{method:'POST'});
    const d=await r.json();
    if(d.ok) showToast('Прочитано','ok'); else showToast('Ошибка','error');
  }catch(e){ showToast('Ошибка сети','error'); }
}

async function showMembers(){
  if(CHAT_KIND!=='group'&&CHAT_KIND!=='channel'){ showToast('Недоступно для личных чатов','error'); return; }
  document.getElementById('membersModal')?.classList.add('active');
  if(window.pushHistoryGuard) pushHistoryGuard();
  const box=document.getElementById('membersList');
  if (box) box.innerHTML='<div style="padding:20px;text-align:center;color:var(--text-muted);">Загрузка...</div>';
  try{
    const r=await fetch('/api/chat/'+CHAT_ID+'/members');
    const d=await r.json();
    const members=d.members||[];
    if (box) box.innerHTML = members.map(m=>`<div class="modal-item">${m.avatar}<span class="modal-item-title">${escHtml(m.name)}</span><span class="modal-item-sub">${m.username?'@'+escHtml(m.username):'ID '+m.id}</span></div>`).join('')
      || '<div style="padding:20px;text-align:center;color:var(--text-muted);">Пусто</div>';
  }catch(e){ if (box) box.innerHTML='<div style="padding:20px;color:var(--bad);">Ошибка</div>'; }
}
function hideMembers(){ document.getElementById('membersModal')?.classList.remove('active'); if(window.popHistoryGuard) popHistoryGuard(); }

function showExport(){ document.getElementById('exportModal')?.classList.add('active'); if(window.pushHistoryGuard) pushHistoryGuard(); }
function hideExport(){ document.getElementById('exportModal')?.classList.remove('active'); if(window.popHistoryGuard) popHistoryGuard(); }
function startExport(){
  const fmt=document.getElementById('expFormat').value;
  let lim=document.getElementById('expLimit').value;
  const withMedia=document.getElementById('expMedia').checked;
  hideExport(); showToast('Готовлю файл...','ok');
  if(withMedia){
    if(lim==='0')lim='1000';
    window.location = '/api/chat/'+CHAT_ID+'/export_zip?limit='+lim;
  } else {
    window.location = '/api/chat/'+CHAT_ID+'/export?format='+fmt+'&limit='+lim;
  }
}

let pendingNew=0;
function updateFab(){
  const fab=document.getElementById('toBottomBtn');
  if(!fab) return;
  const dist=chatBox.scrollHeight-chatBox.scrollTop-chatBox.clientHeight;
  fab.style.display=dist>400?'flex':'none';
  const c=document.getElementById('fabCount');
  if(!c) return;
  if(pendingNew>0){ c.textContent=pendingNew; c.style.display='inline'; } else c.style.display='none';
}
function goBottom(){ pendingNew=0; chatBox.scrollTop=chatBox.scrollHeight; updateFab(); }
function highlightTarget(){
  const h=location.hash;
  if(h&&h.startsWith('#msg_')){
    const el=document.getElementById(h.slice(1));
    if(el){
      el.scrollIntoView({block:'center'});
      el.classList.add('msg-highlight');
      setTimeout(()=>el.classList.remove('msg-highlight'),1700);
    }
  }
}
window.addEventListener('hashchange',highlightTarget);
let polling = false;
async function pollNewMessages(cid){
  if (polling) return;
  polling = true;
  try{
    const only = ONLY_ME ? '&only_me=1' : '';
    const res=await fetch('/api/chat/'+cid+'/messages?after_id='+lastMsgId+only);
    const data=await res.json();
    const list=data.messages||[];
    if(list.length){
      const nearBottom=chatBox.scrollHeight-chatBox.scrollTop-chatBox.clientHeight<200;
      appendMessages(list);
      if(nearBottom) chatBox.scrollTop=chatBox.scrollHeight;
      else { pendingNew+=list.length; updateFab(); }
    }
  }catch(e){}
  finally { polling = false; }
}
if (!ONLY_ME) setInterval(()=>pollNewMessages(CHAT_ID),3000);

document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    closeCtx(); hideDelete(); hideForward(); hideMembers(); hideExport();
    if(selectMode) exitSelect();
  }
});
document.addEventListener('visibilitychange',()=>{
  if (document.visibilityState === 'visible') { pollNewMessages(CHAT_ID); }
});
"""


# --- Routes ---
@app.route("/favicon.ico")
def favicon():
    return Response(_svg_icon_bytes(), mimetype="image/svg+xml")


@app.route("/")
@need_auth
def home():
    tab = request.args.get("tab") or "all"
    dialogs = run_coro(list_dialogs(filter_mode=tab), timeout=90)
    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title">Выберите чат</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="chat-scroll">
<div class="chat-empty">
<div style="font-size:60px;margin-bottom:16px;opacity:0.4;">{icon("inbox")}</div>
<h3 style="margin-bottom:8px;color:#fff;">Добро пожаловать</h3>
<p>Выберите диалог в боковой панели</p>
<p style="margin-top:12px;font-size:12px;"><a href="/my" style="color:var(--acc);">Мои сообщения</a> · <a href="/adult" style="color:#f9a8d4;">18+ поиск</a> · <a href="/cached" style="color:#93c5fd;">Кэш</a></p>
</div>
</div>"""
    return page(body, "Диалоги", active_tab=tab, dialogs=dialogs, active_bnav="home")


@app.route("/login")
def login():
    if state["phase"] in ("boot", "error", "starting_login"):
        if state["phase"] != "starting_login":
            state["phase"] = "starting_login"
            asyncio.run_coroutine_threadsafe(login_flow(), loop)
    err = f'<div class="auth-error">{icon("x")} {esc(state["error"])}</div>' if state["error"] else ""
    extra = ""
    if state["phase"] == "qr" and state.get("qr_html"):
        extra = f'''
<div style="text-align:center;">{state["qr_html"]}<div class="qr-url">{esc(state["qr_url"])}</div></div>
<div style="text-align:center;margin-top:16px;font-size:12px;color:var(--text-muted);">
Откройте Telegram → Настройки → Устройства → Подключить устройство</div>'''
    elif state["phase"] == "2fa":
        extra = f'''
<form method="post" action="/2fa">
<input type="password" name="password" placeholder="Облачный пароль (2FA)" autofocus style="width:100%;margin-bottom:12px;">
<button class="btn" style="width:100%;">{icon("check")} Подтвердить</button>
</form>'''
    elif state["phase"] == "ready":
        extra = f'<div class="auth-success">{icon("check")} Сессия запущена</div><a class="btn" href="/" style="width:100%;">{icon("inbox")} Войти в консоль</a>'
    else:
        # даже при ошибке можно открыть кэш, если он есть
        st = db_stats()
        if st["total"] > 0:
            extra += (f'<div class="auth-sub" style="color:var(--text-dim);margin-top:14px;">'
                      f'В кэше сохранено: {st["total"]} сообщений из {st["chats"]} чатов</div>')
            extra += (f'<div style="margin-top:10px;"><a class="btn" href="/cached" '
                      f'style="width:100%;background:linear-gradient(135deg,#3b82f6,#2563eb);">'
                      f'{icon("database")} Читать офлайн-кэш</a></div>')
    body = f"""
<div class="auth-wrap">
<div class="auth-card">
<div class="auth-brand"><div class="sb-brand-mark">T</div>
<div><div class="auth-title">CloudCode</div>
<div style="font-size:12px;color:var(--text-muted);font-family:var(--mono);">Telegram Web Client</div></div></div>
<div class="auth-sub">{esc(state["message"])}</div>
{err}{extra}
</div>
</div>
<script>
setInterval(async()=>{{
  try {{
    const r=await fetch('/api/status'); const d=await r.json();
    if(d.phase!=='{state["phase"]}'||(d.qr_url&&d.qr_url!=='{state.get("qr_url","")}')) location.reload();
  }} catch(e) {{}}
}},1500);
</script>"""
    return page(body, "Авторизация", with_sidebar=False, bottom_nav=False)


@app.route("/2fa", methods=["POST"])
def twofa():
    pwd = request.form.get("password") or ""
    try:
        run_coro(do_2fa(pwd), timeout=30)
    except Exception as e:
        state["error"] = str(e)
    return redirect("/login")


@app.route("/api/status")
def api_status():
    return jsonify({"phase": state["phase"], "message": state["message"], "qr_url": state.get("qr_url", "")})


@app.route("/api/dialogs")
@need_auth
def api_dialogs():
    tab = request.args.get("tab") or "all"
    dialogs = run_coro(list_dialogs(filter_mode=tab), timeout=60)
    for d in dialogs:
        d["avatar"] = avatar_svg(d["title"], 32)
    return jsonify({"dialogs": dialogs})


@app.route("/manifest.webmanifest")
def manifest():
    import base64
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192">'
           '<rect width="192" height="192" rx="42" fill="#dc2626"/>'
           '<text x="96" y="128" font-family="sans-serif" font-weight="800" font-size="112" '
           'text-anchor="middle" fill="#fff">T</text></svg>')
    data = {
        "name": "Telegram CloudCode",
        "short_name": "CloudCode",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#0a0a0c",
        "theme_color": "#0a0a0c",
        "orientation": "portrait",
        "icons": [{
            "src": "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode(),
            "sizes": "192x192 512x512",
            "type": "image/svg+xml",
            "purpose": "any maskable",
        }],
    }
    return Response(json.dumps(data), mimetype="application/manifest+json")


@app.route("/sw.js")
def sw():
    js = "self.addEventListener('install',e=>self.skipWaiting());\n" \
         "self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));\n" \
         "self.addEventListener('fetch',e=>{});\n"
    return Response(js, mimetype="application/javascript")


# ===== УНИЧТОЖЕНИЕ =====
@app.route("/api/destroy_user", methods=["POST"])
@need_auth
def api_destroy_user():
    data = request.get_json(silent=True) or {}
    uid_raw = data.get("user_id")
    if uid_raw is None:
        return jsonify({"ok": False, "error": "Не указан user_id"})
    try:
        uid = int(uid_raw)
    except (ValueError, TypeError):
        return jsonify({"ok": False, "error": "Некорректный user_id"})

    me = state.get("me") or {}
    if me.get("id") == uid:
        return jsonify({"ok": False, "error": "Нельзя уничтожить себя"})

    print(f"\n[API] /api/destroy_user uid={uid} title={data.get('title')!r}", flush=True)

    try:
        result = run_coro(destroy_user_full(uid), timeout=600)
    except Exception as e:
        print(f"[API] destroy_user_full EXCEPTION: {e}", flush=True)
        print(traceback.format_exc(), flush=True)
        return jsonify({"ok": False, "error": f"Критическая ошибка: {e}"})

    if result["wiped"]:
        state["pinned"].discard(uid)
        removed = 0
        try:
            for f in os.listdir(MEDIA_DIR):
                if f.startswith(f"{uid}_"):
                    try:
                        os.remove(os.path.join(MEDIA_DIR, f))
                        removed += 1
                    except OSError:
                        pass
        except Exception as e:
            print(f"[API] cache cleanup error: {e}", flush=True)
        print(f"[API] cache cleanup: удалено файлов = {removed}", flush=True)
    else:
        print(f"[API] wipe НЕ УДАЛСЯ → кэш не трогаем", flush=True)

    ok = bool(result["wiped"])
    if ok:
        return jsonify({"ok": True, "details": result})
    err = "; ".join(result["errors"]) or "удаление не подтверждено (сообщения остались)"
    return jsonify({"ok": False, "error": err, "details": result})


@app.route("/api/destroy_verify/<int:uid>")
@need_auth
def api_destroy_verify(uid):
    async def _check():
        info = {"uid": uid}
        try:
            resp = await client(GetBlockedRequest(offset=0, limit=200))
            blocked_ids = []
            for b in (resp.blocked or []):
                pid = getattr(b, "peer_id", None)
                if pid is not None and hasattr(pid, "user_id"):
                    blocked_ids.append(pid.user_id)
            info["is_blocked"] = uid in blocked_ids
            info["blocked_total"] = len(blocked_ids)
        except Exception as e:
            info["block_error"] = f"{type(e).__name__}: {e}"
        try:
            cnt = 0
            async for _ in client.iter_messages(uid, limit=1000):
                cnt += 1
            info["message_count"] = cnt
        except Exception as e:
            info["msg_error"] = f"{type(e).__name__}: {e}"
        try:
            in_list = False
            for d in (await client.get_dialogs(limit=300)):
                if d.id == uid:
                    in_list = True
                    break
            info["in_dialogs"] = in_list
        except Exception as e:
            info["dialog_error"] = f"{type(e).__name__}: {e}"
        return info

    try:
        res = run_coro(_check(), timeout=60)
        print(f"[VERIFY {uid}] {res}", flush=True)
        return jsonify(res)
    except Exception as e:
        return jsonify({"error": str(e)})


@app.route("/chat/<chat_id>")
@need_auth
def chat(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    q = request.args.get("q") or ""
    tab = request.args.get("tab") or "all"
    only_me = request.args.get("only_me") == "1"
    title, messages = run_coro(load_messages(chat_id, q=q or None, limit=60, only_me=only_me), timeout=120)
    dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)
    try:
        chat_info_full = run_coro(entity_info(chat_id), timeout=30) or {}
    except Exception:
        chat_info_full = {}
    chat_uname = chat_info_full.get("username")
    chat_kind = chat_info_full.get("kind", "unknown")
    can_leave = chat_kind in ("group", "channel")
    chat_link_base = ""
    if chat_uname:
        chat_link_base = f"https://t.me/{chat_uname}"
    elif str(chat_id).startswith("-100"):
        chat_link_base = f"https://t.me/c/{str(chat_id)[4:]}"
    last_id = messages[-1]["id"] if messages else 0
    first_id = messages[0]["id"] if messages else 0
    first_day = messages[0].get("day_key", "") if messages else ""
    last_day = messages[-1].get("day_key", "") if messages else ""
    has_more_initial = "true" if (messages and not q and not only_me) else "false"
    if messages:
        loader_html = f'''
<div class="history-loader" id="historyTop">
<button id="historyBtn" onclick="loadHistory(true)">{icon("chevron-up", "icon-sm")} Загрузить старые сообщения</button>
</div>'''
        chat_view = loader_html + chat_blocks_html(messages, chat_id)
    else:
        empty_hint = "У вас нет сообщений в этом чате" if only_me else "Диалог пуст (или ещё не сохранён в кэш)"
        chat_view = f'<div class="chat-empty"><div class="chat-empty-icon">{icon("inbox", "icon-lg")}</div><p>{empty_hint}</p></div>'

    only_me_toggle = (
        f'<a class="onlyme-toggle {"active" if only_me else ""}" '
        f'href="/chat/{chat_id}{"?only_me=1" if not only_me else ""}" '
        f'title="Показать только мои сообщения">'
        f'{icon("user", "icon-sm")}<span>Только мои</span></a>'
    )

    if chat_uname:
        chip = ('<button class="username-chip" data-copy="@' + esc(chat_uname) +
                '" onclick="copyToClipboard(this.dataset.copy)" title="Скопировать username">' +
                icon("at-sign") + '<span>@' + esc(chat_uname) + '</span></button>')
        header_sub = '<div class="mn-title-sub">' + chip + '<span>ID: ' + esc(str(chat_id)) + '</span></div>'
    else:
        header_sub = '<div class="mn-title-sub"><span>ID: ' + esc(str(chat_id)) + '</span></div>'

    pin_label = "Открепить чат" if chat_id in state["pinned"] else "Закрепить чат"
    menu_html = f'<a class="dropdown-item" href="/chat/{chat_id}/media">{icon("image", "icon-sm")} Медиагалерея</a>'
    menu_html += f'<button class="dropdown-item" onclick="document.getElementById(\'chatSearch\').focus()">{icon("search", "icon-sm")} Поиск в чате</button>'
    menu_html += f'<button class="dropdown-item" onclick="markRead()">{icon("check", "icon-sm")} Отметить прочитанным</button>'
    menu_html += f'<button class="dropdown-item" onclick="togglePin()">{icon("pin", "icon-sm")} {pin_label}</button>'
    menu_html += f'<a class="dropdown-item" href="/chat/{chat_id}{"?only_me=1" if not only_me else ""}">{icon("user", "icon-sm")} {"Скрыть чужие" if not only_me else "Показать все"}</a>'
    menu_html += f'<a class="dropdown-item adult" href="/adult?chat_id={chat_id}">{icon("flame", "icon-sm")} 18+ в этом чате</a>'
    if chat_kind in ("group", "channel"):
        menu_html += f'<button class="dropdown-item" onclick="showMembers()">{icon("users", "icon-sm")} Участники</button>'
    if chat_link_base:
        menu_html += f'<button class="dropdown-item" onclick="copyChatLink()">{icon("link", "icon-sm")} Скопировать ссылку</button>'
    menu_html += f'<button class="dropdown-item" onclick="showExport()">{icon("download", "icon-sm")} Скачать чат</button>'
    if chat_kind == "user":
        menu_html += '<div class="dropdown-sep"></div>'
        menu_html += f'<button class="dropdown-item danger" onclick="destroyCurrent()">{icon("bomb", "icon-sm")} УНИЧТОЖИТЬ пользователя</button>'
    if can_leave:
        menu_html += '<div class="dropdown-sep"></div>'
        menu_html += f'<button class="dropdown-item danger" onclick="leaveChat()">{icon("logout", "icon-sm")} Покинуть чат</button>'

    body_html = f"""
<div class="mn-header">
<a class="mn-menu-btn" href="/" title="Назад к чатам">{icon("arrow-left")}</a>
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title-wrap">
<div class="mn-title">{esc(title)}</div>
{header_sub}
</div>
<div class="mn-actions">
{only_me_toggle}
<form method="get" style="display:flex;gap:6px;">
<input type="hidden" name="only_me" value="{'1' if only_me else '0'}">
<input type="text" id="chatSearch" name="q" placeholder="Поиск..." value="{esc(q)}" style="width:130px;font-size:16px;padding:7px 10px;">
<button type="submit" class="btn-icon" title="Искать">{icon("search")}</button>
</form>
<div class="menu-wrap">
<button class="btn-icon" onclick="toggleMenu(event)" title="Действия">{icon("more")}</button>
<div class="dropdown" id="chatMenu">{menu_html}</div>
</div>
</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети — показан кэш</div>
<div class="chat-wrap">
<div class="ghost-banner">
<span>{icon("ghost", "icon-sm")} Режим невидимки активен</span>
<button class="btn btn-outline" style="padding:5px 12px;font-size:11.5px;" onclick="markRead()">{icon("check", "icon-sm")} Прочитать</button>
</div>
<div class="cache-banner">
{icon("database", "icon-sm")} Все сообщения автоматически сохраняются в кэш — они доступны, даже если чат будет удалён.
<a href="/cached?chat_id={chat_id}">Кэш этого чата →</a>
</div>
<div class="chat-scroll" id="chatBox">
<div class="ptr-indicator" id="ptrIndicator">{icon("chevron-down")}</div>
<div class="select-bar" id="selectBar">
<span class="select-bar-count" id="selectCount">Выбрано: 0</span>
<button class="btn btn-outline" style="padding:6px 12px;font-size:12px;" onclick="exitSelect()">{icon("x", "icon-sm")} Отмена</button>
</div>
{chat_view}
</div>
<button class="chat-fab" id="toBottomBtn" onclick="goBottom()" title="Вниз к новым">
{icon("chevron-down")}<span class="fab-count" id="fabCount" style="display:none;"></span>
</button>
<div class="chat-input">
<div class="edit-banner" id="editBanner">
<div style="flex:1;min-width:0;">
<div class="edit-banner-label">{icon("edit", "icon-sm")} Редактирование</div>
<div id="editBannerText" style="color:var(--text-dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"></div>
</div>
<button class="chat-reply-close" onclick="cancelEdit()">{icon("x", "icon-sm")}</button>
</div>
<div class="chat-reply" id="chatReply" style="display:none;">
<div class="chat-reply-body">
<div class="chat-reply-label">Ответ</div>
<div class="chat-reply-text" id="chatReplyText"></div>
</div>
<button class="chat-reply-close" onclick="clearReply()">{icon("x", "icon-sm")}</button>
</div>
<div class="voice-bar" id="voiceBar">
<span class="voice-dot"></span>
<span class="voice-timer" id="voiceTimer">0:00</span>
<button class="btn-icon" onclick="cancelVoice()" title="Отменить">{icon("trash")}</button>
<button class="btn" onclick="stopVoice(true)" style="padding:8px 14px;">{icon("send", "icon-sm")} Отправить</button>
</div>
<div class="chat-files" id="chatFiles"></div>
<div class="chat-input-row">
<textarea class="chat-input-field" id="msgInput" rows="1" placeholder="Сообщение..."></textarea>
<div class="chat-input-tools">
<label class="btn-icon" title="Прикрепить файл" style="cursor:pointer;display:flex;position:relative;overflow:hidden;">
{icon("paperclip")}
<input type="file" id="fileInput" multiple style="position:absolute;width:1px;height:1px;opacity:0;z-index:-1;" onchange="onFileSelected(this)">
</label>
<button class="btn-icon" title="Голосовое сообщение" onclick="toggleVoice()">{icon("mic")}</button>
<button class="btn-icon" id="emojiBtn" title="Emoji" onclick="toggleEmoji()" style="position:relative;">
{icon("smile")}
<div class="emoji-picker" id="emojiPicker"></div>
</button>
</div>
<button class="btn chat-input-send" id="sendBtn" onclick="sendMessage({chat_id})" title="Отправить">
{icon("send")}
</button>
</div>
<div class="chat-input-options">
<label class="opt-label"><input type="checkbox" id="silentOpt">{icon("bell-off", "icon-sm")}<span>Без звука</span></label>
<span class="opt-sep"></span>
<label class="opt-label">{icon("clock", "icon-sm")}<input type="datetime-local" id="scheduleOpt"></label>
</div>
</div>
</div>

<div class="modal-overlay" id="delModal" onclick="if(event.target===this)hideDelete()">
<div class="modal" style="width:min(380px,92vw);">
<div class="modal-header">{icon("trash", "icon-lg")}<b>Удалить сообщение?</b></div>
<div style="padding:16px;display:flex;flex-direction:column;gap:10px;">
<button class="btn btn-outline" id="delBtnMe" onclick="doDelete('me')" style="justify-content:flex-start;">{icon("user", "icon-sm")} Удалить у меня</button>
<button class="btn btn-danger" id="delBtnAll" onclick="doDelete('all')" style="justify-content:flex-start;padding:9px 16px;">{icon("users", "icon-sm")} Удалить у всех</button>
<button class="btn btn-ghost" onclick="hideDelete()">Отмена</button>
</div>
</div>
</div>

<div class="modal-overlay" id="fwdModal" onclick="if(event.target===this)hideForward()">
<div class="modal">
<div class="modal-header">{icon("forward", "icon-lg")}<b>Переслать в...</b></div>
<div style="padding:10px 12px 0;"><input id="fwdSearch" placeholder="Поиск чата..." style="width:100%;" oninput="filterFwd()"></div>
<div class="modal-body" id="fwdList"></div>
</div>
</div>

<div class="modal-overlay" id="membersModal" onclick="if(event.target===this)hideMembers()">
<div class="modal">
<div class="modal-header">{icon("users", "icon-lg")}<b>Участники</b></div>
<div class="modal-body" id="membersList"></div>
</div>
</div>

<div class="modal-overlay" id="exportModal" onclick="if(event.target===this)hideExport()">
<div class="modal" style="width:min(440px,92vw);">
<div class="modal-header">{icon("download", "icon-lg")}<b>Скачать историю чата</b></div>
<div class="exp-form">
<label>Формат
<select id="expFormat">
<option value="html">HTML — красивая страница</option>
<option value="txt">TXT — простой текст</option>
<option value="json">JSON — для обработки</option>
</select></label>
<label>Объём
<select id="expLimit">
<option value="200">Последние 200</option>
<option value="1000" selected>Последние 1000</option>
<option value="5000">Последние 5000</option>
<option value="0">Вся история</option>
</select></label>
<label class="row"><input type="checkbox" id="expMedia"><span>Вложить медиафайлы (ZIP)</span></label>
<div class="exp-hint">ZIP: до 150 файлов, до 300 МБ, файлы &gt; 50 МБ пропускаются.</div>
</div>
<div class="exp-actions">
<button class="btn" onclick="startExport()">{icon("download")} Скачать</button>
<button class="btn btn-ghost" onclick="hideExport()">Отмена</button>
</div>
</div>
</div>

<div class="select-actions" id="selectActions">
<button class="btn btn-outline" onclick="openForward([...selectedIds])">{icon("forward", "icon-sm")} Переслать</button>
<button class="btn btn-danger" onclick="deleteDialog([...selectedIds])" style="padding:9px 16px;">{icon("trash", "icon-sm")} Удалить</button>
</div>

<div class="ctx-overlay" id="ctxMenu">
<div class="ctx-sheet">
<div class="ctx-grab"></div>
<div class="ctx-preview" id="ctxPreview"></div>
<div class="ctx-reacts">
<button class="ctx-react" onclick="ctxReact('👍')">👍</button>
<button class="ctx-react" onclick="ctxReact('❤️')">❤️</button>
<button class="ctx-react" onclick="ctxReact('🔥')">🔥</button>
<button class="ctx-react" onclick="ctxReact('😂')">😂</button>
<button class="ctx-react" onclick="ctxReact('😮')">😮</button>
<button class="ctx-react" onclick="ctxReact('👎')">👎</button>
</div>
<button class="ctx-item" onclick="ctxReply()">{icon("reply")} Ответить</button>
<button class="ctx-item" onclick="ctxCopy()">{icon("copy")} Копировать текст</button>
<button class="ctx-item" id="ctxEdit" onclick="ctxEdit()">{icon("edit")} Редактировать</button>
<button class="ctx-item" onclick="ctxForward()">{icon("forward")} Переслать</button>
<button class="ctx-item" onclick="ctxPin()">{icon("pin")} Закрепить</button>
<button class="ctx-item" onclick="ctxSelect()">{icon("check")} Выбрать</button>
<div class="ctx-sep"></div>
<button class="ctx-item danger" id="ctxDeleteAll" onclick="ctxDeleteAll()" style="display:none;">{icon("users")} Удалить у всех</button>
<button class="ctx-item danger" onclick="ctxDelete()">{icon("trash")} Удалить у меня</button>
</div>
</div>
<script>
async function destroyCurrent(){{
  if ('{chat_kind}' !== 'user') {{ showToast('Только для личных чатов','error'); return; }}
  if (!confirm('УНИЧТОЖИТЬ текущего пользователя?\\n\\n• Заблокировать\\n• Удалить всю переписку у обоих\\n• Удалить диалог\\n\\nЭто НЕОБРАТИМО.')) return;
  try {{
    const r = await fetch('/api/destroy_user', {{
      method:'POST', headers:{{'Content-Type':'application/json'}},
      body: JSON.stringify({{user_id: {chat_id}, title: {json.dumps(title, ensure_ascii=False)}}})
    }});
    const d = await r.json();
    console.log('[DESTROY-CURRENT]', d);
    if (d.ok) {{ showToast('Уничтожено','ok'); setTimeout(()=>location.href='/', 700); }}
    else {{
      const det = d.details || {{}};
      const errs = (det.errors || []).join(' · ') || d.error || '';
      showToast('Ошибка: ' + errs.slice(0,120),'error');
      console.error('[DESTROY-CURRENT] fail', det);
    }}
  }} catch(e) {{ showToast('Ошибка сети','error'); }}
}}
</script>
"""
    js = CHAT_JS_TEMPLATE
    js = js.replace("__CHAT_ID__", str(chat_id))
    js = js.replace("__CHAT_LINK__", chat_link_base or "")
    js = js.replace("__CHAT_KIND__", chat_kind or "unknown")
    js = js.replace("__ONLY_ME__", "true" if only_me else "false")
    js = js.replace("__LAST_ID__", str(last_id))
    js = js.replace("__FIRST_ID__", str(first_id))
    js = js.replace("__FIRST_DAY__", first_day or "")
    js = js.replace("__LAST_DAY__", last_day or "")
    js = js.replace("__HAS_MORE__", has_more_initial)
    js = js.replace("__ICON_COPY__", icon("copy", "icon-sm"))
    js = js.replace("__ICON_REPLY__", icon("reply", "icon-sm"))
    js = js.replace("__ICON_EDIT__", icon("edit", "icon-sm"))
    js = js.replace("__ICON_FWD__", icon("forward", "icon-sm"))
    js = js.replace("__ICON_PIN__", icon("pin", "icon-sm"))
    js = js.replace("__ICON_TRASH__", icon("trash", "icon-sm"))
    js = js.replace("__ICON_X__", icon("x", "icon-sm"))
    js = js.replace("__ICON_FILE__", icon("file", "icon-sm"))
    js = js.replace("__ICON_UP__", icon("chevron-up", "icon-sm"))
    js = js.replace("__ICON_LOADER__", f'<span class="spin" style="display:inline-flex;width:14px;height:14px;">{icon("loader")}</span>')
    js = js.replace("__ICON_AT__", icon("at-sign"))

    full_body = body_html + "<script>\n" + js + "\n</script>"
    return page(full_body, title, active_chat=chat_id, active_tab=tab,
                dialogs=dialogs, bottom_nav=False)


@app.route("/api/chat/<chat_id>/messages")
@need_auth
def api_chat_messages(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    after_id = int(request.args.get("after_id") or 0)
    only_me = request.args.get("only_me") == "1"
    try:
        _, messages = run_coro(load_messages(chat_id, min_id=after_id, limit=30, only_me=only_me), timeout=60)
    except Exception:
        # Фолбэк в кэш
        messages = db_load_messages(chat_id, after_id=after_id, limit=30, only_me=only_me)
    out = [msg_json(m) for m in messages if m["id"] > after_id]
    return jsonify({"messages": out})


def msg_json(m):
    return {
        "id": m["id"], "sender": m["sender"], "sender_username": m.get("sender_username"),
        "date": m["date"], "day_key": m.get("day_key", ""), "day_label": m.get("day_label", ""),
        "raw_text": m["raw_text"], "html": parse_markdown(m["text"]),
        "media_html": m["media_html"], "out": m["out"], "reactions": m.get("reactions", []),
    }


@app.route("/api/chat/<chat_id>/history")
@need_auth
def api_chat_history(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    try:
        before_id = int(request.args.get("before_id") or 0)
    except ValueError:
        before_id = 0
    only_me = request.args.get("only_me") == "1"
    print(f"[HISTORY] chat={chat_id} before_id={before_id} only_me={only_me}", flush=True)
    if not before_id:
        return jsonify({"messages": [], "has_more": False, "error": "no before_id"})
    page_size = 40

    async def _older():
        out = []
        try:
            kwargs = {"offset_id": before_id, "limit": page_size + 1}
            if only_me:
                kwargs["from_user"] = "me"
            async for m in client.iter_messages(chat_id, **kwargs):
                if not m or not getattr(m, "id", None):
                    continue
                if m.id >= before_id:
                    continue
                if only_me and not getattr(m, "out", False):
                    continue
                day_key, day_label = fmt_day(m.date)
                sinfo = await sender_info(m)
                out.append({
                    "id": m.id,
                    "date": fmt_full_date(m.date),
                    "day_key": day_key,
                    "day_label": day_label,
                    "sender": sinfo["name"],
                    "sender_username": sinfo.get("username"),
                    "text": m.message or "",
                    "raw_text": m.message or "",
                    "out": bool(m.out),
                    "media_html": get_media_html(m, chat_id),
                    "sender_id": getattr(m, "sender_id", None),
                    "reactions": extract_reactions(m),
                })
        except Exception as e:
            print(f"[HISTORY] error: {type(e).__name__}: {e}", flush=True)
            raise
        out.sort(key=lambda x: x["id"])
        return out

    try:
        older = run_coro(_older(), timeout=120)
        if older:
            db_save_messages(chat_id, older)
    except Exception as e:
        print(f"[HISTORY] fallback to cache: {e}", flush=True)
        older = db_load_messages(chat_id, before_id=before_id, limit=page_size + 1, only_me=only_me)
    has_more = len(older) > page_size
    if has_more:
        older = older[-page_size:]
    print(f"[HISTORY] chat={chat_id} got={len(older)} has_more={has_more}", flush=True)
    return jsonify({"messages": [msg_json(m) for m in older], "has_more": has_more})


@app.route("/api/chat/<chat_id>/delete_messages", methods=["POST"])
@need_auth
def api_delete_messages(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    ids = data.get("ids") or []
    scope = data.get("scope", "me")
    if not ids:
        return jsonify({"ok": False, "error": "Не выбрано ни одного сообщения"})
    revoke = (scope == "all")
    try:
        run_coro(client.delete_messages(chat_id, ids, revoke=revoke), timeout=30)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/edit/<int:msg_id>", methods=["POST"])
@need_auth
def api_edit_message(chat_id, msg_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify({"ok": False, "error": "Пустой текст"})
    try:
        run_coro(client.edit_message(chat_id, msg_id, text), timeout=30)
        # Обновим кэш
        try:
            con = _db()
            con.execute("UPDATE cached_messages SET text=?, raw_text=? WHERE chat_id=? AND msg_id=?",
                        (text, text, chat_id, msg_id)) if False else None
            con.execute("UPDATE cached_messages SET text=? WHERE chat_id=? AND msg_id=?",
                        (text, chat_id, msg_id))
            con.commit()
            con.close()
        except Exception:
            pass
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/forward", methods=["POST"])
@need_auth
def api_forward_messages(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    ids = data.get("ids") or []
    to = data.get("to")
    if not ids or not to:
        return jsonify({"ok": False, "error": "Нет данных"})
    try:
        run_coro(client.forward_messages(to, ids, from_peer=chat_id), timeout=60)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/pin_msg/<int:msg_id>", methods=["POST"])
@need_auth
def api_pin_message(chat_id, msg_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    try:
        if data.get("unpin"):
            run_coro(client.unpin_message(chat_id, msg_id), timeout=30)
        else:
            run_coro(client.pin_message(chat_id, msg_id, notify=False), timeout=30)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/react/<int:msg_id>", methods=["POST"])
@need_auth
def api_react(chat_id, msg_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    emoji = data.get("reaction", "👍")
    try:
        if hasattr(client, "send_reaction"):
            run_coro(client.send_reaction(chat_id, msg_id, reaction=emoji), timeout=30)
            return jsonify({"ok": True})
        return jsonify({"ok": False, "error": "Версия Telethon не поддерживает реакции"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/members")
@need_auth
def api_members(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass

    async def get_members():
        out = []
        try:
            parts = await client.get_participants(chat_id, limit=100)
            for p in parts:
                name = " ".join(x for x in [getattr(p, 'first_name', None),
                                             getattr(p, 'last_name', None)] if x) \
                       or getattr(p, 'title', '') or str(p.id)
                out.append({
                    "id": p.id, "name": name,
                    "username": getattr(p, 'username', None),
                    "avatar": avatar_svg(name, 32),
                })
        except Exception:
            pass
        return out

    members = run_coro(get_members(), timeout=60)
    return jsonify({"members": members})


async def collect_export(eid, limit=None):
    rows = []
    try:
        it = client.iter_messages(eid, limit=limit) if limit else client.iter_messages(eid)
        async for m in it:
            sinfo = await sender_info(m)
            rows.append({
                "id": m.id, "date": fmt_full_date(m.date), "sender": sinfo["name"],
                "username": sinfo.get("username"), "text": m.message or "",
                "media": media_label(m),
            })
    except Exception as e:
        rows.append({"id": 0, "date": "", "sender": "Система", "username": None,
                     "text": f"Ошибка экспорта: {e}", "media": ""})
    if not rows:
        # фолбэк — из кэша
        cached = db_load_messages(eid, limit=limit or 1000)
        for m in cached:
            rows.append({"id": m["id"], "date": m["date"], "sender": m["sender"],
                         "username": m.get("sender_username"), "text": m["text"] or "",
                         "media": ""})
    rows.reverse()
    return rows


async def collect_export_media(eid, limit, media_dir):
    os.makedirs(media_dir, exist_ok=True)
    rows = []
    count, total = 0, 0
    MAX_FILES, MAX_TOTAL, MAX_ONE = 150, 300 * 1024 * 1024, 50 * 1024 * 1024
    try:
        async for m in client.iter_messages(eid, limit=limit):
            sinfo = await sender_info(m)
            row = {
                "id": m.id, "date": fmt_full_date(m.date), "sender": sinfo["name"],
                "username": sinfo.get("username"), "text": m.message or "",
                "media": media_label(m), "file": None,
            }
            doc = getattr(m, "document", None)
            size = getattr(doc, "size", 0) or 0
            if m.media and count < MAX_FILES:
                take = False
                if doc and 0 < size < MAX_ONE and total + size < MAX_TOTAL:
                    take = True
                elif getattr(m, "photo", None) and total < MAX_TOTAL:
                    take = True
                if take:
                    try:
                        ext = guess_msg_ext(m)
                        dest = os.path.join(media_dir, f"{m.id}{ext}")
                        await client.download_media(m, file=dest)
                        if os.path.exists(dest):
                            row["file"] = f"media/{m.id}{ext}"
                            count += 1
                            total += os.path.getsize(dest)
                    except Exception:
                        pass
            rows.append(row)
    except Exception as e:
        rows.append({"id": 0, "date": "", "sender": "Система", "username": None,
                     "text": f"Ошибка экспорта: {e}", "media": "", "file": None})
    rows.reverse()
    return rows


def export_txt(title, rows):
    lines = [f"Чат: {title}", f"Экспорт: {datetime.now().strftime('%d.%m.%Y %H:%M')}",
             f"Сообщений: {len(rows)}", "=" * 40, ""]
    for r in rows:
        who = r["sender"] + (f" (@{r['username']})" if r.get("username") else "")
        body = ((r["text"] or "") + (" " + r["media"] if r.get("media") else "")).strip() or "(без текста)"
        lines.append(f"[{r['date']}] {who}: {body}")
    return "\n".join(lines)


def export_json(rows):
    return json.dumps(rows, ensure_ascii=False, indent=2)


def export_html(title, rows):
    css = ("body{font-family:sans-serif;background:#141418;color:#eee;max-width:820px;margin:0 auto;padding:20px}"
           "h1{font-size:20px}.day{text-align:center;color:#888;font-size:12px;margin:18px 0 8px}"
           ".m{background:#1c1c21;border:1px solid #2a2a30;border-radius:10px;padding:8px 12px;margin-bottom:8px}"
           ".meta{font-size:11px;color:#f97316;margin-bottom:4px}.t{font-size:14px;white-space:pre-wrap}"
           ".med{color:#888;font-size:12px}a{color:#fb923c}")
    h = [f"<!doctype html><html lang='ru'><head><meta charset='utf-8'><title>{esc(title)}</title>"
         f"<style>{css}</style></head><body>"]
    h.append(f"<h1>{esc(title)}</h1><p>Сообщений: {len(rows)}</p>")
    prev_day = None
    for r in rows:
        day = r["date"].rsplit(" ", 1)[0] if " " in r["date"] else r["date"]
        if day != prev_day:
            h.append(f"<div class='day'>{esc(day or '—')}</div>")
            prev_day = day
        who = esc(r["sender"]) + (f" @{esc(r['username'])}" if r.get("username") else "")
        txt = esc(r["text"]) if r["text"] else "<i>(без текста)</i>"
        med = f" <span class='med'>{esc(r['media'])}</span>" if r.get("media") else ""
        fil = (f"<br><a href='{esc(r['file'])}'>Вложение: {esc(r['file'].split('/')[-1])}</a>"
               if r.get("file") else "")
        h.append(f"<div class='m'><div class='meta'>{who} · {esc(r['date'])}</div>"
                 f"<div class='t'>{txt}{med}{fil}</div></div>")
    h.append("</body></html>")
    return "".join(h)


def _download_headers(chat_id, title, ext):
    fname = (re.sub(r"[^\w\- ]", "_", title or "chat").strip()[:40] or "chat") + f".{ext}"
    return {"Content-Disposition": f"attachment; filename=chat_{chat_id}.{ext}; filename*=UTF-8''{quote(fname)}"}


@app.route("/api/chat/<chat_id>/export")
@need_auth
def api_export(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    fmt = (request.args.get("format") or "html").lower()
    if fmt not in ("html", "json", "txt"):
        fmt = "html"
    try:
        limit = int(request.args.get("limit") or 1000)
    except ValueError:
        limit = 1000
    if limit <= 0:
        limit = None
    title = run_coro(entity_title(chat_id), timeout=30)
    rows = run_coro(collect_export(chat_id, limit), timeout=600)
    if fmt == "json":
        data = export_json(rows).encode("utf-8"); mime, ext = "application/json", "json"
    elif fmt == "txt":
        data = export_txt(title, rows).encode("utf-8"); mime, ext = "text/plain; charset=utf-8", "txt"
    else:
        data = export_html(title, rows).encode("utf-8"); mime, ext = "text/html; charset=utf-8", "html"
    return Response(data, mimetype=mime, headers=_download_headers(chat_id, title, ext))


@app.route("/api/chat/<chat_id>/export_zip")
@need_auth
def api_export_zip(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    try:
        limit = int(request.args.get("limit") or 500)
    except ValueError:
        limit = 500
    limit = max(50, min(limit, 1000))
    title = run_coro(entity_title(chat_id), timeout=30)
    tmp = tempfile.mkdtemp(prefix="tgexp_")
    try:
        rows = run_coro(collect_export_media(chat_id, limit, os.path.join(tmp, "media")), timeout=600)
        with open(os.path.join(tmp, "chat.html"), "w", encoding="utf-8") as f:
            f.write(export_html(title, rows))
        zpath = os.path.join(tmp, "chat.zip")
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(os.path.join(tmp, "chat.html"), "chat.html")
            mdir = os.path.join(tmp, "media")
            if os.path.isdir(mdir):
                for fn in sorted(os.listdir(mdir)):
                    z.write(os.path.join(mdir, fn), f"media/{fn}")
        with open(zpath, "rb") as f:
            data = f.read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return Response(data, mimetype="application/zip", headers=_download_headers(chat_id, title, "zip"))


@app.route("/api/chat/<chat_id>/pin", methods=["POST"])
@need_auth
def api_pin(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    if chat_id in state["pinned"]:
        state["pinned"].discard(chat_id)
        pinned = False
    else:
        state["pinned"].add(chat_id)
        pinned = True
    return jsonify({"ok": True, "pinned": pinned})


@app.route("/api/chat/<chat_id>/leave", methods=["POST"])
@need_auth
def api_leave(chat_id):
    try:
        chat_id = int(chat_id)
        run_coro(client.delete_dialog(chat_id), timeout=30)
        state["pinned"].discard(chat_id)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/send", methods=["POST"])
@need_auth
def api_send_message(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    text = (request.form.get("text") or "").strip()
    silent = bool(request.form.get("silent"))
    schedule = request.form.get("schedule_date")
    voice = bool(request.form.get("voice"))
    reply_to = request.form.get("reply_to")
    try:
        reply_to = int(reply_to)
    except Exception:
        reply_to = None
    files = request.files.getlist("file")
    schedule_dt = None
    if schedule:
        try:
            schedule_dt = datetime.strptime(schedule[:16], "%Y-%m-%dT%H:%M")
        except Exception:
            pass
    try:
        saved_paths = []
        for f in files:
            if f.filename:
                safe_name = re.sub(r"[^\w.\-]", "_", f.filename)
                path = os.path.join(UPLOAD_DIR, f"{int(datetime.now().timestamp()*1000)}_{safe_name}")
                f.save(path)
                saved_paths.append(path)
        if saved_paths:
            if voice:
                p = saved_paths[0]
                try:
                    run_coro(client.send_file(
                        chat_id, p, caption=text or None, silent=silent,
                        schedule=schedule_dt, reply_to=reply_to, voice_note=True), timeout=120)
                except Exception:
                    run_coro(client.send_file(
                        chat_id, p, caption=text or None, silent=silent,
                        schedule=schedule_dt, reply_to=reply_to), timeout=120)
                for pp in saved_paths:
                    if os.path.exists(pp):
                        try: os.remove(pp)
                        except OSError: pass
            else:
                run_coro(client.send_file(
                    chat_id, saved_paths, caption=text or None, silent=silent,
                    schedule=schedule_dt, reply_to=reply_to), timeout=120)
                for p in saved_paths:
                    if os.path.exists(p):
                        try: os.remove(p)
                        except OSError: pass
        elif text:
            run_coro(client.send_message(
                chat_id, text, silent=silent, schedule=schedule_dt, reply_to=reply_to), timeout=30)
        else:
            return jsonify({"ok": False, "error": "Нет данных для отправки"})
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/delete/<int:msg_id>", methods=["POST"])
@need_auth
def api_delete_message(chat_id, msg_id):
    try:
        chat_id = int(chat_id)
        run_coro(client.delete_messages(chat_id, [msg_id], revoke=True), timeout=20)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/api/chat/<chat_id>/read", methods=["POST"])
@need_auth
def api_mark_read(chat_id):
    try:
        chat_id = int(chat_id)
        run_coro(client.send_read_acknowledge(chat_id), timeout=15)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/my")
@need_auth
def my_page():
    """Страница «Мои сообщения» — сводка по чатам + быстрый доступ."""
    tab = request.args.get("tab") or "all"
    dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)
    stats = db_stats()
    # чаты с моими сообщениями из кэша
    cached = db_list_chats()
    cached_mine = [c for c in cached if c.get("mine_count", 0) > 0]
    cards = []
    for c in cached_mine[:40]:
        cards.append(f'''
<a class="sb-item" href="/chat/{c["id"]}?only_me=1" style="border-left:3px solid var(--acc);">
{avatar_svg(c["title"], 40)}
<div class="sb-item-body">
<div class="sb-item-top">
<span class="sb-item-title">{esc(c["title"])}</span>
<span class="sb-item-time">{esc(c.get("last_seen", "")[:10])}</span>
</div>
<div class="sb-item-preview">Моих сообщений в кэше: {c["mine_count"]} / всего {c["count"]}</div>
</div>
</a>''')
    cards_html = "".join(cards) if cards else '<div class="sb-empty">Кэш пуст — откройте чаты, чтобы наполнить</div>'
    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title">{icon("user")} Мои сообщения</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="settings-wrap">
<div class="adult-hero" style="background:linear-gradient(135deg,rgba(249,115,22,0.15),rgba(194,65,12,0.05));border-color:rgba(249,115,22,0.3);">
<div class="adult-hero-icon" style="background:linear-gradient(135deg,#f97316,#c2410c);">{icon("user", "icon-lg")}</div>
<div class="adult-hero-title" style="color:var(--acc);">Только мои сообщения</div>
<div class="adult-hero-sub">Всего в кэше: <b style="color:#fff;">{stats["mine"]}</b> ваших сообщений</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Мои сообщения по чатам</div>
<div class="settings-card" style="padding:6px;">
{cards_html}
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Быстрые действия</div>
<div class="settings-card">
<a class="btn" href="/chat/{cached_mine[0]["id"]}?only_me=1" style="width:100%;margin-bottom:8px;display:{'inline-flex' if cached_mine else 'none'};">
{icon("user", "icon-sm")} Открыть последний чат (только мои)</a>
<a class="btn btn-outline" href="/adult" style="width:100%;margin-bottom:8px;">{icon("flame", "icon-sm")} Поиск 18+ среди моих</a>
<a class="btn btn-outline" href="/cached" style="width:100%;">{icon("database", "icon-sm")} Все кэшированные чаты</a>
</div>
</div>
</div>"""
    return page(body, "Мои сообщения", active_tab=tab, dialogs=dialogs, active_bnav="my")


@app.route("/adult")
@need_auth
def adult_page():
    """Страница поиска 18+ своих сообщений."""
    tab = request.args.get("tab") or "all"
    chat_id = request.args.get("chat_id")
    try:
        chat_filter = int(chat_id) if chat_id else None
    except ValueError:
        chat_filter = None
    dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)

    hits = db_search_adult(limit=400)
    if chat_filter:
        hits = [h for h in hits if h["chat_id"] == chat_filter]

    # группировка по чату
    by_chat = {}
    for h in hits:
        by_chat.setdefault(h["chat_id"], {"title": h["chat_title"], "items": []})["items"].append(h)

    blocks = []
    for cid, g in by_chat.items():
        items_html = []
        for h in g["items"]:
            txt = esc(h["text"] or "")
            for kw in h.get("matched", []):
                try:
                    txt = re.sub(f"({re.escape(kw)})", r'<mark class="kw">\1</mark>', txt, flags=re.IGNORECASE)
                except Exception:
                    pass
            kws = "".join(f'<span class="kw-chip">{esc(k)}</span>' for k in h.get("matched", []))
            items_html.append(f'''
<div class="search-result">
<div class="search-result-head">
<span class="search-result-chat">{esc(g["title"])}</span>
<span class="search-result-date">{esc(h["date"])}</span>
</div>
<div class="search-result-body">{txt}</div>
<div style="margin-top:8px;">{kws}</div>
<div style="margin-top:12px;text-align:right;">
<a href="/chat/{cid}?only_me=1#msg_{h["id"]}" class="btn btn-outline" style="padding:7px 14px;font-size:12.5px;">
{icon("arrow-left", "icon-sm")} К сообщению</a>
</div>
</div>''')
        blocks.append(f'''
<div class="settings-section">
<div class="settings-section-title">{esc(g["title"])} · {len(g["items"])} найдено</div>
{''.join(items_html)}
</div>''')

    content = "".join(blocks) if blocks else '<div style="text-align:center;padding:60px 20px;color:var(--text-muted);font-family:var(--mono);">Ничего не найдено. Открывайте чаты, чтобы кэш наполнялся.</div>'
    filter_chip = ""
    if chat_filter:
        filter_chip = (f'<div style="margin-bottom:14px;"><a href="/adult" class="btn btn-outline" '
                       f'style="padding:6px 12px;font-size:12px;">{icon("x", "icon-sm")} Сбросить фильтр чата</a></div>')

    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title" style="color:#f9a8d4;">{icon("flame")} Поиск 18+</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="search-wrap">
<div class="adult-hero">
<div class="adult-hero-icon">{icon("flame", "icon-lg")}</div>
<div class="adult-hero-title">Поиск 18+ среди моих сообщений</div>
<div class="adult-hero-sub">Поиск по ключевым словам в локальном кэше. Найдено: {len(hits)}</div>
</div>
{filter_chip}
{content}
</div>"""
    return page(body, "18+ поиск", active_tab=tab, dialogs=dialogs, active_bnav="adult")


@app.route("/cached")
@need_auth
def cached_page():
    """Список кэшированных чатов — можно читать даже если чат удалён/скрипт оффлайн."""
    tab = request.args.get("tab") or "all"
    try:
        dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=30)
    except Exception:
        dialogs = []

    focused_chat = request.args.get("chat_id")
    try:
        focused_chat = int(focused_chat) if focused_chat else None
    except ValueError:
        focused_chat = None

    chats = db_list_chats()
    stats = db_stats()

    # Префильтрация, если открыли с конкретным chat_id
    if focused_chat:
        chats = [c for c in chats if c["id"] == focused_chat]
        # если чата нет в кэше — попробуем прочитать хотя бы последние сообщения напрямую
        if not chats:
            msgs = db_load_messages(focused_chat, limit=200)
            if msgs:
                chats = [{"id": focused_chat, "title": f"Чат {focused_chat}",
                          "count": len(msgs), "mine_count": sum(1 for m in msgs if m["out"]),
                          "last_seen": "", "kind": "unknown"}]

    cards = []
    for c in chats:
        av = avatar_svg(c["title"], 36)
        meta = f'{c["count"]} сообщ · {c["mine_count"]} моих'
        if c.get("kind") == "user":
            meta += ' · личный'
        elif c.get("kind") == "group":
            meta += ' · группа'
        elif c.get("kind") == "channel":
            meta += ' · канал'
        kind_icon = {"user": "user", "group": "users", "channel": "megaphone"}.get(c.get("kind"), "database")
        cards.append(f'''
<div class="search-result" style="padding:14px;">
<div style="display:flex;gap:12px;align-items:center;">
{av}
<div style="flex:1;min-width:0;">
<div style="font-weight:600;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">{esc(c["title"])}</div>
<div style="font-size:11.5px;color:var(--text-muted);font-family:var(--mono);margin-top:2px;">{meta}</div>
</div>
{icon(kind_icon, "icon-lg")}
</div>
<div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;">
<a class="btn btn-outline" href="/chat/{c["id"]}" style="padding:7px 12px;font-size:12px;">{icon("inbox", "icon-sm")} Открыть</a>
<a class="btn btn-outline" href="/chat/{c["id"]}?only_me=1" style="padding:7px 12px;font-size:12px;">{icon("user", "icon-sm")} Только мои</a>
<a class="btn btn-outline" href="/adult?chat_id={c["id"]}" style="padding:7px 12px;font-size:12px;color:#f9a8d4;">{icon("flame", "icon-sm")} 18+</a>
</div>
</div>''')

    if not cards:
        cards_html = (f'<div style="text-align:center;padding:60px 20px;color:var(--text-muted);font-family:var(--mono);">'
                      f'Кэш пуст. Откройте чаты, чтобы наполнить локальную базу.<br><br>'
                      f'После наполнения сообщения останутся здесь, даже если чат удалить.</div>')
    else:
        cards_html = "".join(cards)

    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title" style="color:#93c5fd;">{icon("database")} Кэш сообщений</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети — показан кэш</div>
<div class="search-wrap">
<div class="adult-hero" style="background:linear-gradient(135deg,rgba(59,130,246,0.15),rgba(37,99,235,0.05));border-color:rgba(59,130,246,0.3);">
<div class="adult-hero-icon" style="background:linear-gradient(135deg,#3b82f6,#2563eb);">{icon("database", "icon-lg")}</div>
<div class="adult-hero-title" style="color:#93c5fd;">Офлайн-чтение</div>
<div class="adult-hero-sub">Всего: <b style="color:#fff;">{stats["total"]}</b> сообщений · <b style="color:#fff;">{stats["mine"]}</b> ваших · <b style="color:#fff;">{stats["chats"]}</b> чатов · {round(stats["size"]/1048576, 2)} MB</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Читаемые чаты ({len(chats)})</div>
{cards_html}
</div>
</div>"""
    return page(body, "Кэш", active_tab=tab, dialogs=dialogs, active_bnav="settings")


@app.route("/api/cache/clear", methods=["POST"])
@need_auth
def api_cache_clear():
    try:
        con = _db()
        con.execute("DELETE FROM cached_messages")
        con.execute("DELETE FROM cached_chats")
        con.commit()
        con.close()
        try:
            con = _db(); con.execute("VACUUM"); con.close()
        except Exception:
            pass
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/search")
@need_auth
def search_page():
    q = (request.args.get("q") or "").strip()
    f_type = request.args.get("filter") or "all"
    tab = request.args.get("tab") or "all"
    dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)
    messages = []
    if q or f_type != "all":
        messages = run_coro(run_global_search(q, f_type if f_type != "all" else None), timeout=120)
    blocks = []
    for m in messages:
        content = parse_markdown(m["text"])
        if q and m["text"]:
            content = re.sub(f"({re.escape(q)})", r"<mark>\1</mark>", content, flags=re.IGNORECASE)
        content += m["media_html"]
        blocks.append(f"""
<div class="search-result">
<div class="search-result-head">
<span class="search-result-chat">{esc(m["chat_title"])}</span>
<span class="search-result-date">{esc(m["date"])}</span>
</div>
<div class="search-result-sender">Отправитель: {esc(m["sender"])}</div>
<div class="search-result-body">{content}</div>
<div style="margin-top:12px;text-align:right;display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;">
<a href="/chat/{m["chat_id"]}#msg_{m["id"]}" class="btn btn-outline" style="padding:7px 14px;font-size:12.5px;">
{icon("arrow-left", "icon-sm")} К контексту</a>
<a href="/chat/{m["chat_id"]}?only_me=1" class="btn btn-outline" style="padding:7px 14px;font-size:12.5px;">
{icon("user", "icon-sm")} Только мои</a>
</div>
</div>""")
    if blocks:
        results_html = "".join(blocks)
    elif q or f_type != "all":
        results_html = '<div style="text-align:center;padding:60px 20px;color:var(--text-muted);font-family:var(--mono);">Совпадений не найдено</div>'
    else:
        results_html = (f'<div style="text-align:center;padding:60px 20px;color:var(--text-muted);">'
                        f'{icon("search", "icon-lg")}<p style="margin-top:12px;">Введите запрос для поиска</p>'
                        f'<p style="margin-top:8px;font-size:12px;"><a href="/adult" style="color:#f9a8d4;">Или перейти к поиску 18+ среди моих</a></p></div>')
    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title">{icon("search")} Глобальный поиск</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="search-wrap">
<div class="settings-card" style="margin-bottom:20px;">
<form method="get" style="display:flex;gap:10px;flex-wrap:wrap;">
<input name="q" placeholder="Поиск по всем чатам..." value="{esc(q)}" style="flex:1;min-width:200px;">
<select name="filter" style="width:auto;min-width:140px;">
<option value="all" {"selected" if f_type == "all" else ""}>Все типы</option>
<option value="photo" {"selected" if f_type == "photo" else ""}>Фото</option>
<option value="doc" {"selected" if f_type == "doc" else ""}>Документы</option>
<option value="audio" {"selected" if f_type == "audio" else ""}>Аудио</option>
<option value="url" {"selected" if f_type == "url" else ""}>Ссылки</option>
</select>
<button class="btn" type="submit">{icon("search")} Искать</button>
<a class="btn btn-outline" href="/adult" title="Поиск 18+ среди моих">{icon("flame")}</a>
</form>
<div style="margin-top:8px;font-size:11.5px;color:var(--text-muted);font-family:var(--mono);">
Поиск идёт по Telegram + локальному кэшу (даже для удалённых чатов)
</div>
</div>
{results_html}
</div>"""
    return page(body, "Поиск", active_tab=tab, dialogs=dialogs, active_bnav="search")


@app.route("/api/chat/<chat_id>/media_list")
@need_auth
def api_media_list(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    media_type = request.args.get("type") or None
    try:
        before_id = int(request.args.get("before_id") or 0) or None
    except ValueError:
        before_id = None
    items = db_load_media_messages(chat_id, media_type=media_type, limit=60, before_id=before_id)
    out = []
    for m in items:
        mh = m["media_html"]
        # extract thumbnail url from media_html
        thumb = None
        import re as _re
        src = _re.search(r'src=["\']([^"\']+)["\']', mh)
        if src:
            thumb = src.group(1)
        is_ot = "ot-card" in mh
        is_video = not is_ot and ("<video" in mh or "data-video" in mh)
        # build media url
        media_url = f"/media/{chat_id}/{m['id']}"
        out.append({
            "id": m["id"],
            "date": m["date"],
            "sender": m["sender"],
            "thumb": thumb or media_url,
            "url": media_url,
            "is_video": is_video,
            "is_ot": is_ot,
            "text": m["text"],
        })
    has_more = len(items) == 60
    return jsonify({"items": out, "has_more": has_more})


@app.route("/chat/<chat_id>/media")
@need_auth
def chat_media_page(chat_id):
    try:
        chat_id_int = int(chat_id)
    except Exception:
        chat_id_int = chat_id
    tab = request.args.get("tab") or "all"
    media_type = request.args.get("type") or "all"
    try:
        dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)
    except Exception:
        dialogs = []
    try:
        chat_info_full = run_coro(entity_info(chat_id_int), timeout=30) or {}
    except Exception:
        chat_info_full = {}
    title = chat_info_full.get("title") or f"Чат {chat_id}"
    counts = db_count_media(chat_id_int)

    def tab_cls(t):
        return "active" if media_type == t else ""

    tabs_html = f"""
<div class="media-tabs">
  <a class="media-tab {tab_cls('all')}" href="?type=all">{icon("image", "icon-sm")} Все <span class="media-tab-cnt">{counts['all']}</span></a>
  <a class="media-tab {tab_cls('photo')}" href="?type=photo">{icon("image", "icon-sm")} Фото <span class="media-tab-cnt">{counts['photo']}</span></a>
  <a class="media-tab {tab_cls('video')}" href="?type=video">{icon("video", "icon-sm")} Видео <span class="media-tab-cnt">{counts['video']}</span></a>
  <a class="media-tab {tab_cls('one_time')}" href="?type=one_time">{icon("eye", "icon-sm")} Одноразовые <span class="media-tab-cnt">{counts['one_time']}</span></a>
</div>"""

    body = f"""
<div class="mn-header">
  <a class="mn-menu-btn" href="/chat/{chat_id}" title="Назад в чат">{icon("arrow-left")}</a>
  <button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
  <div class="mn-title-wrap">
    <div class="mn-title">{icon("image", "icon-sm")} Медиа</div>
    <div class="mn-title-sub"><span>{esc(title)}</span></div>
  </div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="media-gallery-wrap">
{tabs_html}
<div class="media-grid" id="mediaGrid">
  <div class="media-grid-loading" id="mediaLoading">{icon("loader", "icon-lg")} <span>Загрузка...</span></div>
</div>
<div id="mediaLoadMoreWrap" style="display:none;text-align:center;padding:16px;">
  <button class="btn btn-outline" id="mediaLoadMoreBtn" onclick="loadMoreMedia()">{icon("chevron-down", "icon-sm")} Загрузить ещё</button>
</div>
<div class="media-empty" id="mediaEmpty" style="display:none;">
  {icon("image", "icon-lg")}
  <p>Нет медиафайлов в кэше</p>
  <p style="font-size:12px;color:var(--text-muted);">Откройте чат и прокрутите историю — медиа сохранятся автоматически</p>
</div>
</div>

<div class="media-viewer-overlay" id="mediaViewer" onclick="if(event.target===this)closeViewer()">
  <div class="media-viewer-bar">
    <button class="media-viewer-btn" onclick="closeViewer()">{icon("x")}</button>
    <div class="media-viewer-info" id="viewerInfo"></div>
    <a class="media-viewer-btn" id="viewerDlBtn" href="#" download title="Скачать">{icon("download")}</a>
    <a class="media-viewer-btn" id="viewerChatBtn" href="#" title="В чате">{icon("arrow-left")}</a>
  </div>
  <div class="media-viewer-body">
    <button class="media-viewer-nav left" id="viewerPrev" onclick="viewerNav(-1)">{icon("chevron-left")}</button>
    <div class="media-viewer-content" id="viewerContent"></div>
    <button class="media-viewer-nav right" id="viewerNext" onclick="viewerNav(1)">{icon("chevron-right")}</button>
  </div>
</div>

<script>
const CHAT_ID = {chat_id_int};
const MEDIA_TYPE = {json.dumps(media_type)};
let items = [];
let lastId = null;
let hasMore = true;
let loading = false;
let viewerIdx = 0;

// touch swipe for viewer
let vTouchX = 0;
document.getElementById('mediaViewer')?.addEventListener('touchstart', e => {{ vTouchX = e.touches[0].clientX; }}, {{passive:true}});
document.getElementById('mediaViewer')?.addEventListener('touchend', e => {{
  const dx = e.changedTouches[0].clientX - vTouchX;
  if (Math.abs(dx) > 50) viewerNav(dx < 0 ? 1 : -1);
}}, {{passive:true}});

async function fetchMedia(beforeId) {{
  loading = true;
  const u = '/api/chat/'+CHAT_ID+'/media_list?type='+MEDIA_TYPE+(beforeId?'&before_id='+beforeId:'');
  try {{
    const r = await fetch(u);
    const d = await r.json();
    return d;
  }} catch(e) {{ return {{items:[], has_more:false}}; }}
  finally {{ loading = false; }}
}}

function mediaThumbHtml(item, idx) {{
  if (item.is_ot) {{
    return `<div class="media-cell ot-cell" data-idx="${{idx}}" onclick="openViewer(${{idx}})">
      <div class="media-cell-ot-icon">{icon("eye", "icon-sm")}</div>
      <div class="media-cell-ot-lbl">Одноразовое</div>
    </div>`;
  }}
  if (item.is_video) {{
    return `<div class="media-cell video-cell" data-idx="${{idx}}" onclick="openViewer(${{idx}})">
      <div class="media-cell-play">{icon("play", "icon-sm")}</div>
      <img class="media-cell-img lazy" data-src="${{item.thumb}}" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="">
    </div>`;
  }}
  return `<div class="media-cell" data-idx="${{idx}}" onclick="openViewer(${{idx}})">
    <img class="media-cell-img lazy" data-src="${{item.thumb}}" src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="">
  </div>`;
}}

const lazyObserver = new IntersectionObserver(entries => {{
  entries.forEach(e => {{
    if (e.isIntersecting) {{
      const img = e.target;
      if (img.dataset.src) {{ img.src = img.dataset.src; img.removeAttribute('data-src'); }}
      lazyObserver.unobserve(img);
    }}
  }});
}}, {{rootMargin: '200px'}});

function renderItems(newItems, clear) {{
  const grid = document.getElementById('mediaGrid');
  const loading_el = document.getElementById('mediaLoading');
  const empty_el = document.getElementById('mediaEmpty');
  if (clear) grid.innerHTML = '';
  loading_el && loading_el.remove();
  if (newItems.length === 0 && items.length === 0) {{
    empty_el && (empty_el.style.display = 'flex');
    return;
  }}
  empty_el && (empty_el.style.display = 'none');
  const start = items.length - newItems.length;
  newItems.forEach((item, i) => {{
    const cell = document.createElement('div');
    cell.innerHTML = mediaThumbHtml(item, start + i);
    const node = cell.firstElementChild;
    grid.appendChild(node);
    node.querySelectorAll('img.lazy').forEach(img => lazyObserver.observe(img));
  }});
}}

async function loadMedia() {{
  const d = await fetchMedia(null);
  items = d.items || [];
  hasMore = d.has_more;
  lastId = items.length ? items[items.length-1].id : null;
  renderItems(items, true);
  document.getElementById('mediaLoadMoreWrap').style.display = hasMore ? 'block' : 'none';
}}

async function loadMoreMedia() {{
  if (loading || !hasMore || !lastId) return;
  const btn = document.getElementById('mediaLoadMoreBtn');
  if (btn) btn.disabled = true;
  const d = await fetchMedia(lastId);
  const newItems = d.items || [];
  hasMore = d.has_more;
  if (newItems.length) {{
    lastId = newItems[newItems.length-1].id;
    items = items.concat(newItems);
    renderItems(newItems, false);
  }}
  document.getElementById('mediaLoadMoreWrap').style.display = hasMore ? 'block' : 'none';
  if (btn) btn.disabled = false;
}}

function openViewer(idx) {{
  viewerIdx = idx;
  renderViewer();
  document.getElementById('mediaViewer').classList.add('active');
  document.body.style.overflow = 'hidden';
}}

function closeViewer() {{
  document.getElementById('mediaViewer').classList.remove('active');
  document.body.style.overflow = '';
  document.getElementById('viewerContent').innerHTML = '';
}}

function viewerNav(dir) {{
  viewerIdx = Math.max(0, Math.min(items.length - 1, viewerIdx + dir));
  renderViewer();
  if (dir > 0 && viewerIdx >= items.length - 3 && hasMore) loadMoreMedia();
}}

function renderViewer() {{
  const item = items[viewerIdx];
  if (!item) return;
  const content = document.getElementById('viewerContent');
  const info = document.getElementById('viewerInfo');
  const dlBtn = document.getElementById('viewerDlBtn');
  const chatBtn = document.getElementById('viewerChatBtn');
  info.textContent = (item.sender || '') + ' · ' + (item.date || '');
  dlBtn.href = item.url + '?dl=1';
  chatBtn.href = '/chat/' + CHAT_ID + '#msg_' + item.id;

  if (item.is_ot) {{
    content.innerHTML = `<div class="viewer-ot">
      <div class="viewer-ot-icon">{icon("eye", "icon-lg")}</div>
      <div class="viewer-ot-title">Одноразовое медиа</div>
      <button class="btn" onclick="loadOT(${{item.id}}, this)" style="margin-top:16px;">{icon("download", "icon-sm")} Загрузить и просмотреть</button>
    </div>`;
  }} else if (item.is_video) {{
    content.innerHTML = `<video src="${{item.url}}" controls playsinline style="max-width:100%;max-height:70vh;border-radius:10px;"></video>`;
  }} else {{
    content.innerHTML = `<img src="${{item.url}}" style="max-width:100%;max-height:75vh;border-radius:10px;object-fit:contain;" loading="lazy">`;
  }}
  document.getElementById('viewerPrev').style.opacity = viewerIdx > 0 ? '1' : '0.2';
  document.getElementById('viewerNext').style.opacity = viewerIdx < items.length - 1 ? '1' : '0.2';
}}

async function loadOT(msgId, btn) {{
  btn.disabled = true;
  btn.textContent = 'Загрузка...';
  try {{
    const r = await fetch('/media/' + CHAT_ID + '/' + msgId);
    if (r.ok) {{
      const content = document.getElementById('viewerContent');
      const url = '/media/' + CHAT_ID + '/' + msgId;
      const ct = r.headers.get('content-type') || '';
      if (ct.startsWith('video')) {{
        content.innerHTML = `<video src="${{url}}" controls playsinline style="max-width:100%;max-height:70vh;border-radius:10px;"></video>`;
      }} else {{
        content.innerHTML = `<img src="${{url}}" style="max-width:100%;max-height:75vh;border-radius:10px;object-fit:contain;">`;
      }}
    }} else {{
      btn.textContent = 'Ошибка';
    }}
  }} catch(e) {{ btn.textContent = 'Ошибка сети'; }}
}}

document.addEventListener('keydown', e => {{
  const v = document.getElementById('mediaViewer');
  if (!v?.classList.contains('active')) return;
  if (e.key === 'ArrowLeft') viewerNav(-1);
  if (e.key === 'ArrowRight') viewerNav(1);
  if (e.key === 'Escape') closeViewer();
}});

loadMedia();
</script>"""
    return page(body, f"Медиа — {title}", active_tab=tab, dialogs=dialogs, active_bnav="home",
                bottom_nav=False)


@app.route("/media/<chat_id>/<msg_id>")
@need_auth
def get_media(chat_id, msg_id):
    try:
        chat_id, msg_id = int(chat_id), int(msg_id)
        path = run_coro(fetch_media_file(chat_id, msg_id), timeout=120)
        if path and os.path.exists(path):
            mime_type = mimetypes.guess_type(path)[0] or "application/octet-stream"
            force_dl = bool(request.args.get("dl"))
            resp = send_file(
                path,
                mimetype=mime_type,
                as_attachment=force_dl,
            )
            if not force_dl:
                resp.headers["Content-Disposition"] = "inline"
                resp.headers["Cache-Control"] = "private, no-store, no-cache, must-revalidate"
                resp.headers["Pragma"] = "no-cache"
                resp.headers["X-Content-Type-Options"] = "nosniff"
            return resp
    except Exception:
        pass
    return "Медиафайл недоступен", 404


def _pack_input_from_ss(ss):
    if ss is None:
        return None
    if isinstance(ss, InputStickerSetShortName) or isinstance(ss, InputStickerSetID):
        return ss
    sid = getattr(ss, "id", None)
    ah = getattr(ss, "access_hash", None)
    short = getattr(ss, "short_name", None)
    if sid and ah is not None:
        return InputStickerSetID(id=sid, access_hash=ah)
    if short:
        return InputStickerSetShortName(short_name=short)
    return ss


def _new_pack_token():
    import secrets
    return secrets.token_hex(8)


async def _save_pack_doc(token, idx, doc):
    _ensure_nomedia(STICKER_DIR)
    prefix = f"{token}_{idx}_"
    try:
        for fn in os.listdir(STICKER_DIR):
            if fn.startswith(prefix):
                return os.path.join(STICKER_DIR, fn)
    except OSError:
        pass
    dest = os.path.join(STICKER_DIR, prefix)
    try:
        saved = await client.download_media(doc, file=dest)
        if saved and isinstance(saved, str) and os.path.exists(saved):
            return saved
    except Exception as e:
        print(f"[STICKER] download {token}/{idx} failed: {e}", flush=True)
    return None


async def _load_stickerset_from_msg(chat_id, msg_id):
    entity = await client.get_entity(chat_id)
    msg = await client.get_messages(entity, ids=int(msg_id))
    if not msg or not getattr(msg, "document", None):
        raise ValueError("В сообщении нет стикера")
    ss = extract_stickerset(msg.document)
    if not ss:
        raise ValueError("У стикера нет пака")
    pack = _pack_input_from_ss(ss)
    try:
        result = await client(GetStickerSetRequest(stickerset=pack, hash=0))
    except TypeError:
        result = await client(GetStickerSetRequest(stickerset=pack))
    token = _new_pack_token()
    docs = list(result.documents or [])
    PACK_SESSIONS[token] = {"docs": docs, "set": result.set}
    for doc in docs:
        STICKER_DOC_CACHE[str(doc.id)] = doc
        STICKER_DOC_CACHE[doc.id] = doc
    stickers = []
    for idx, doc in enumerate(docs):
        kind = sticker_kind_from_doc(doc) or "webp"
        stickers.append({
            "idx": idx,
            "token": token,
            "kind": kind,
            "mime": doc.mime_type or "",
            "url": f"/packmedia/{token}/{idx}",
            "emoji": "",
        })
    try:
        packs = getattr(result, "packs", None) or []
        emap = {}
        for p in packs:
            emo = getattr(p, "emoticon", "") or ""
            for did in (getattr(p, "documents", None) or []):
                emap[did] = emo
        for idx, doc in enumerate(docs):
            stickers[idx]["emoji"] = emap.get(doc.id, "")
    except Exception:
        pass
    st = result.set
    return {
        "ok": True,
        "token": token,
        "title": getattr(st, "title", "") or "Стикерпак",
        "short_name": getattr(st, "short_name", "") or "",
        "count": getattr(st, "count", None) or len(stickers),
        "official": bool(getattr(st, "official", False)),
        "stickers": stickers,
    }


async def _send_sticker_doc(chat_id, token, idx):
    sess = PACK_SESSIONS.get(token) or {}
    docs = sess.get("docs") or []
    try:
        idx = int(idx)
    except (TypeError, ValueError):
        raise RuntimeError("Неверный индекс стикера")
    if idx < 0 or idx >= len(docs):
        raise RuntimeError("Стикер не найден в паке, откройте пак заново")
    await client.send_file(chat_id, docs[idx])


@app.route("/api/stickerset")
@need_auth
def api_stickerset():
    try:
        chat_id = int(request.args.get("chat_id"))
        msg_id = int(request.args.get("msg_id"))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "Нужны chat_id и msg_id"})
    try:
        data = run_coro(_load_stickerset_from_msg(chat_id, msg_id), timeout=60)
        return jsonify(data)
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


def _sticker_response(path):
    mime = mimetypes.guess_type(path)[0]
    if path.endswith(".tgs"):
        mime = "application/x-tgsticker"
    elif path.endswith(".webm"):
        mime = "video/webm"
    elif path.endswith(".webp"):
        mime = "image/webp"
    mime = mime or "application/octet-stream"
    resp = send_file(path, mimetype=mime, as_attachment=False)
    resp.headers["Content-Disposition"] = "inline"
    resp.headers["Cache-Control"] = "private, max-age=3600"
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


@app.route("/packmedia/<token>/<int:idx>")
@need_auth
def get_pack_media(token, idx):
    sess = PACK_SESSIONS.get(token)
    if not sess:
        return "Пак истёк, откройте снова", 404
    docs = sess.get("docs") or []
    if idx < 0 or idx >= len(docs):
        return "Нет такого стикера", 404

    async def _get():
        return await _save_pack_doc(token, idx, docs[idx])

    try:
        path = run_coro(_get(), timeout=60)
        if not path or not os.path.exists(path):
            return "Стикер недоступен", 404
        return _sticker_response(path)
    except Exception as e:
        print(f"[STICKER] packmedia {token}/{idx}: {e}", flush=True)
        return "Стикер недоступен", 404


@app.route("/sticker/<doc_id>/<access_hash>")
@need_auth
def get_sticker_file(doc_id, access_hash):
    return "use /packmedia", 404


@app.route("/api/chat/<chat_id>/send_sticker", methods=["POST"])
@need_auth
def api_send_sticker(chat_id):
    try:
        chat_id = int(chat_id)
    except Exception:
        pass
    data = request.get_json(silent=True) or {}
    token = data.get("token")
    if not token:
        return jsonify({"ok": False, "error": "Откройте пак заново"})
    try:
        run_coro(_send_sticker_doc(chat_id, token, data.get("idx")), timeout=60)
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.route("/settings")
@need_auth
def settings_page():
    tab = request.args.get("tab") or "all"
    dialogs = run_coro(list_dialogs(filter_mode=tab, limit=60), timeout=60)
    try:
        media_size = sum(os.path.getsize(os.path.join(MEDIA_DIR, f))
                         for f in os.listdir(MEDIA_DIR)
                         if os.path.isfile(os.path.join(MEDIA_DIR, f)))
    except Exception:
        media_size = 0
    try:
        uploads_size = sum(os.path.getsize(os.path.join(UPLOAD_DIR, f))
                           for f in os.listdir(UPLOAD_DIR)
                           if os.path.isfile(os.path.join(UPLOAD_DIR, f)))
    except Exception:
        uploads_size = 0
    session_file = SESSION_PATH if SESSION_PATH.endswith(".session") else SESSION_PATH + ".session"
    session_size = os.path.getsize(session_file) if os.path.exists(session_file) else 0
    me = state.get("me", {}) or {}
    me_un = me.get("username")
    if me_un:
        profile_uname = ('<div class="copy-field" data-copy="@' + esc(me_un) +
                         '" onclick="copyToClipboard(this.dataset.copy)" style="color:var(--acc);'
                         'font-family:var(--mono);font-size:12.5px;">@' + esc(me_un) + '</div>')
    else:
        profile_uname = '<div style="color:var(--text-muted);font-family:var(--mono);font-size:12.5px;">—</div>'
    profile_id = ('<div class="copy-field" data-copy="' + esc(str(me.get("id", ""))) +
                  '" onclick="copyToClipboard(this.dataset.copy)" style="color:var(--text-muted);'
                  'font-family:var(--mono);font-size:11.5px;">ID: ' + esc(str(me.get("id", "-"))) + '</div>')
    stats = db_stats()
    body = f"""
<div class="mn-header">
<button class="mn-menu-btn" onclick="toggleSidebar()">{icon("menu")}</button>
<div class="mn-title">{icon("settings")} Настройки</div>
</div>
<div class="offline-banner">{icon("wifi-off", "icon-sm")} Нет подключения к сети</div>
<div class="settings-wrap">
<div class="settings-section">
<div class="settings-section-title">Профиль</div>
<div class="settings-card">
<div style="display:flex;gap:14px;align-items:center;margin-bottom:14px;">
{avatar_svg(me.get("name", "?"), 56)}
<div>
<div style="font-weight:700;font-size:16px;">{esc(me.get("name", ""))}</div>
{profile_uname}
{profile_id}
</div>
</div>
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Быстрые страницы</div>
<div class="settings-card">
<a class="btn btn-outline" href="/my" style="width:100%;margin-bottom:8px;justify-content:flex-start;">{icon("user", "icon-sm")} Мои сообщения</a>
<a class="btn btn-outline" href="/adult" style="width:100%;margin-bottom:8px;justify-content:flex-start;color:#f9a8d4;">{icon("flame", "icon-sm")} Поиск 18+ среди моих</a>
<a class="btn btn-outline" href="/cached" style="width:100%;justify-content:flex-start;color:#93c5fd;">{icon("database", "icon-sm")} Кэш ({stats["chats"]} чатов)</a>
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Локальный кэш</div>
<div class="settings-card">
<div style="font-size:12.5px;color:var(--text-dim);margin-bottom:12px;line-height:1.5;">
Все просмотренные сообщения сохраняются в SQLite. Даже если чат будет удалён или клиент отключится — вы сможете прочитать историю через раздел «Кэш».
</div>
<div class="settings-row"><span class="settings-row-label">Всего сообщений</span><span class="settings-row-value">{stats["total"]}</span></div>
<div class="settings-row"><span class="settings-row-label">Ваших сообщений</span><span class="settings-row-value">{stats["mine"]}</span></div>
<div class="settings-row"><span class="settings-row-label">Чатов</span><span class="settings-row-value">{stats["chats"]}</span></div>
<div class="settings-row"><span class="settings-row-label">Размер БД</span><span class="settings-row-value">{round(stats["size"]/1048576, 2)} MB</span></div>
<button class="btn btn-danger" style="margin-top:12px;width:100%;" onclick="clearCacheDB()">{icon("trash", "icon-sm")} Очистить базу кэша</button>
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Опасная зона</div>
<div class="settings-card" style="border-color:rgba(239,68,68,0.3);">
<div style="font-size:13px;color:#fca5a5;margin-bottom:12px;line-height:1.5;">
Уничтожение пользователя: блокировка + удаление всей переписки у обоих сторон + удаление диалога. <strong>Необратимо.</strong>
</div>
<button class="btn btn-destroy" onclick="openDestroy()" style="width:100%;">{icon("bomb")} Уничтожить пользователя</button>
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">Хранилище файлов</div>
<div class="settings-card">
<div class="settings-row"><span class="settings-row-label">Сессия</span><span class="settings-row-value">{round(session_size/1024, 2)} KB</span></div>
<div class="settings-row"><span class="settings-row-label">Кэш медиа</span><span class="settings-row-value">{round(media_size/1048576, 2)} MB</span></div>
<div class="settings-row"><span class="settings-row-label">Загрузки (temp)</span><span class="settings-row-value">{round(uploads_size/1048576, 2)} MB</span></div>
<div class="settings-row"><span class="settings-row-label">Путь сессии</span><span class="settings-row-value" style="font-size:11px;">{esc(session_file)}</span></div>
<form method="post" action="/clear_cache" style="margin-top:12px;">
<button class="btn btn-danger" type="submit">{icon("trash", "icon-sm")} Очистить файлы кэша</button>
</form>
</div>
</div>
<div class="settings-section">
<div class="settings-section-title">О приложении</div>
<div class="settings-card">
<div style="text-align:center;padding:10px;">
<div class="sb-brand-mark" style="margin:0 auto 10px;width:48px;height:48px;font-size:20px;background:linear-gradient(135deg,#dc2626,#991b1b);">T</div>
<div style="font-weight:700;font-size:16px;margin-bottom:4px;">Telegram CloudCode</div>
<div style="color:var(--text-muted);font-family:var(--mono);font-size:12px;">v3.5 Android Pro</div>
</div>
</div>
</div>
</div>
<script>
async function clearCacheDB(){{
  if(!confirm('Удалить всю локальную базу сообщений? Это освободит место, но офлайн-чтение перестанет работать.')) return;
  try {{
    const r = await fetch('/api/cache/clear', {{method:'POST'}});
    const d = await r.json();
    if (d.ok) {{ showToast('База кэша очищена','ok'); setTimeout(()=>location.reload(), 600); }}
    else showToast('Ошибка: '+(d.error||''),'error');
  }} catch(e) {{ showToast('Ошибка сети','error'); }}
}}
</script>"""
    return page(body, "Настройки", active_tab=tab, dialogs=dialogs, active_bnav="settings")


@app.route("/clear_cache", methods=["POST"])
@need_auth
def clear_cache():
    for d in (MEDIA_DIR, UPLOAD_DIR):
        try:
            for f in os.listdir(d):
                fp = os.path.join(d, f)
                try:
                    if os.path.isfile(fp):
                        os.unlink(fp)
                    elif os.path.isdir(fp):
                        shutil.rmtree(fp, ignore_errors=True)
                except OSError:
                    continue
        except Exception:
            pass
    return redirect("/settings")


def boot():
    async def _c():
        try:
            await client.connect()
            await refresh_me()
            if state["phase"] != "ready":
                state.update({"phase": "boot", "message": "Ожидание авторизации"})
        except Exception as e:
            state.update({"phase": "error", "message": "Ошибка связи", "error": str(e)})
    asyncio.run_coroutine_threadsafe(_c(), loop)


if __name__ == "__main__":
    print(f"[SYSTEM] CloudCode v3.5 (Mobile Pro / SQLite cache / only_me / adult / nomedia)")
    print(f"[SYSTEM] Session: {SESSION_PATH}.session")
    print(f"[SYSTEM] DB: {DB_PATH}")
    print(f"[SYSTEM] http://{HOST}:{PORT}")
    boot()
    app.run(host=HOST, port=PORT, debug=False, threaded=True)