package com.example.tgbotclient

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed interface CheckState {
    data object Idle : CheckState
    data object Checking : CheckState
    data class Ok(val info: BotInfo) : CheckState
    data class Failed(val message: String) : CheckState
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit, onStart: () -> Unit, theme: String, onTheme: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val status by rememberBotStatus()
    val cs = MaterialTheme.colorScheme
    var token by remember { mutableStateOf(prefs.getString("token", "").orEmpty()) }
    var showToken by remember { mutableStateOf(false) }
    var notify by remember { mutableStateOf(prefs.getBoolean("notify", true)) }
    var confirmClear by remember { mutableStateOf(false) }
    var check by remember { mutableStateOf<CheckState>(CheckState.Idle) }
    var stats by remember { mutableStateOf<StorageStats?>(null) }
    val refresh by MessageBus.changes.collectAsStateWithLifecycle()

    var mode by remember { mutableStateOf(Mode.get(context)) }
    val cloudMode = mode == Mode.CLOUD
    var confirmMode by remember { mutableStateOf<String?>(null) }

    fun applyMode(target: String) {
        prefs.edit().putString("mode", target).apply()
        mode = target
        if (target == Mode.CLOUD) {
            // Serverless owns the webhook: polling would only hit 409 Conflict
            context.stopService(Intent(context, BotPollingService::class.java))
            MessageBus.setStatus(BotStatus(BotState.STOPPED, "Облачный режим: опрос отключён"))
            if (CloudSync.isConfigured(context)) CloudSync.schedule(context.applicationContext)
        } else {
            CloudSync.cancel(context.applicationContext)
            MessageBus.setStatus(BotStatus(BotState.STOPPED))
        }
        MessageBus.notifyChanged()
    }

    val trimmed = token.trim()
    val formatOk = trimmed.isEmpty() || isTokenFormatValid(trimmed)
    val active = status.state == BotState.RUNNING || status.state == BotState.STARTING || status.state == BotState.RETRYING

    LaunchedEffect(refresh) { stats = withContext(Dispatchers.IO) { Storage.get(context).stats() } }

    // notification permission is re-checked each time the screen resumes (user may change it in system settings)
    var notifGranted by remember { mutableStateOf(true) }
    LifecycleResumeEffect(Unit) {
        notifGranted = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        onPauseOrDispose { }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        notifGranted = granted
        if (!granted) {
            // after a second refusal Android stops showing the dialog: open the app's notification settings
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            } else {
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            }
            try {
                context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                showMessage("Откройте настройки уведомлений приложения вручную")
            }
        }
    }

    fun checkToken() {
        if (trimmed.isEmpty() || !isTokenFormatValid(trimmed)) return
        check = CheckState.Checking
        scope.launch {
            check = try {
                CheckState.Ok(TelegramApi.getMe(trimmed))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CheckState.Failed(humanError(e))
            }
        }
    }

    fun start() {
        when {
            trimmed.isEmpty() -> showMessage("Укажите токен бота")
            !isTokenFormatValid(trimmed) -> showMessage("Токен выглядит неверно: формат 123456:ABC…")
            else -> {
                // update ids belong to a specific bot: a stale offset would hide a new bot's updates
                if (trimmed != prefs.getString("token", "")) {
                    prefs.edit().putLong("offset", 0L).remove("bot_name").remove("bot_username").apply()
                }
                prefs.edit().putString("token", trimmed).apply()
                MessageBus.setStatus(BotStatus(BotState.STARTING))
                try {
                    ContextCompat.startForegroundService(context, Intent(context, BotPollingService::class.java))
                    onStart()
                } catch (e: Exception) {
                    MessageBus.setStatus(BotStatus(BotState.ERROR, "Не удалось запустить сервис: ${humanError(e)}"))
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        GradientHeader {
            HeaderIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Назад", onBack)
            Spacer(Modifier.width(4.dp))
            Text("Настройки", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StaggeredSection(0) {
                SectionCard("Получение сообщений", Icons.Filled.Share) {
                    val options = listOf(Mode.LOCAL to "Локально", Mode.CLOUD to "Облако")
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        options.forEachIndexed { i, (key, label) ->
                            SegmentedButton(
                                selected = mode == key,
                                onClick = { if (mode != key) confirmMode = key },
                                shape = SegmentedButtonDefaults.itemShape(i, options.size)
                            ) { Text(label) }
                        }
                    }
                    AnimatedContent(
                        targetState = cloudMode,
                        transitionSpec = { fadeIn(tween(Motion.MEDIUM)) togetherWith fadeOut(tween(Motion.SHORT)) },
                        label = "modeInfo"
                    ) { cloud ->
                        Text(
                            if (cloud) "Сообщения принимает Telegram Serverless даже при закрытом приложении и пересылает их на ваш мост. Приложение подтягивает историю с моста: при открытии, кнопкой ⟳ и в фоне примерно раз в 15 минут."
                            else "Сообщения принимает само приложение (getUpdates), пока запущен бот. При закрытом приложении ничего не сохраняется.",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    }
                    androidx.compose.animation.AnimatedVisibility(
                        visible = cloudMode,
                        enter = expandVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) + fadeIn(),
                        exit = shrinkVertically(tween(Motion.SHORT)) + fadeOut()
                    ) {
                        CloudPanel()
                    }
                }
            }

            StaggeredSection(1) {
                SectionCard("Бот", Icons.Filled.Lock) {
                    if (!cloudMode) StatusPanel(status)

                    OutlinedTextField(
                        value = token,
                        onValueChange = { token = it.replace("\n", ""); check = CheckState.Idle },
                        label = { Text("Токен бота") },
                        placeholder = { Text("123456789:AA…") },
                        singleLine = true,
                        isError = !formatOk,
                        supportingText = {
                            Text(
                                if (!formatOk) "Формат: цифры, двоеточие и ключ из @BotFather"
                                else "Токен хранится только на этом устройстве"
                            )
                        },
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                        visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        trailingIcon = {
                            TextButton(onClick = { showToken = !showToken }) { Text(if (showToken) "Скрыть" else "Показать") }
                        },
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
                    )

                    AnimatedContent(
                        targetState = check,
                        transitionSpec = {
                            (fadeIn(tween(Motion.MEDIUM)) + slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 3 }) togetherWith
                                fadeOut(tween(Motion.SHORT))
                        },
                        label = "check"
                    ) { c ->
                        when (c) {
                            CheckState.Idle -> Spacer(Modifier.height(0.dp))
                            CheckState.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Проверяю токен…", style = MaterialTheme.typography.bodyMedium)
                            }
                            is CheckState.Ok -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, null, tint = statusColor(BotState.RUNNING))
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "${c.info.firstName}" + if (c.info.username.isNotBlank()) " · @${c.info.username}" else "",
                                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                                )
                            }
                            is CheckState.Failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warning, null, tint = cs.error)
                                Spacer(Modifier.width(10.dp))
                                Text(c.message, color = cs.error, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }

                    if (cloudMode) {
                        FilledTonalButton(
                            onClick = { checkToken() }, shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk && check != CheckState.Checking
                        ) { Text("Проверить токен") }
                        Text(
                            "В облачном режиме токен нужен только для ответов: Bot API sendMessage работает и при webhook от Serverless. Опрос getUpdates выключен.",
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                    } else Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { start() }, shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(if (active) Icons.Filled.Refresh else Icons.Filled.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (active) "Перезапустить" else "Старт")
                        }
                        OutlinedButton(
                            enabled = active, shape = RoundedCornerShape(14.dp),
                            onClick = { context.stopService(Intent(context, BotPollingService::class.java)) }
                        ) { Text("Стоп") }
                        FilledTonalButton(
                            onClick = { checkToken() }, shape = RoundedCornerShape(14.dp),
                            enabled = trimmed.isNotEmpty() && formatOk && check != CheckState.Checking
                        ) { Text("Проверить") }
                    }
                    if (!cloudMode) Text(
                        "Клиент получает сообщения через getUpdates, пока приложение работает. Если у бота включён Serverless или webhook, Telegram вернёт конфликт 409 — тогда выберите режим «Облако».",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                    )
                }
            }

            StaggeredSection(2) {
                SectionCard("Оформление", Icons.Filled.Star) {
                    val options = listOf("system" to "Авто", "light" to "Светлая", "dark" to "Тёмная")
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        options.forEachIndexed { i, (key, label) ->
                            SegmentedButton(
                                selected = theme == key,
                                onClick = { onTheme(key) },
                                shape = SegmentedButtonDefaults.itemShape(i, options.size)
                            ) { Text(label) }
                        }
                    }
                }
            }

            StaggeredSection(3) {
                SectionCard("Уведомления", Icons.Filled.Notifications) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Уведомления о сообщениях")
                            Text(
                                "Не показываются для открытого чата",
                                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                            )
                        }
                        Switch(checked = notify, onCheckedChange = { notify = it; prefs.edit().putBoolean("notify", it).apply() })
                    }
                    AnimatedVisibility(
                        visible = notify && !notifGranted,
                        enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
                    ) {
                        InfoBanner(
                            "Android запрещает приложению показывать уведомления",
                            isError = true, actionLabel = "Разрешить",
                            onAction = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            }
                        )
                    }
                }
            }

            StaggeredSection(4) {
                SectionCard("Данные", Icons.Filled.Delete) {
                    Text(
                        stats?.let { "На устройстве: чатов ${it.chats}, сообщений ${it.messages}" } ?: "Подсчёт…",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(
                        onClick = { confirmClear = true }, shape = RoundedCornerShape(14.dp),
                        enabled = (stats?.chats ?: 0) > 0,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)
                    ) { Text("Очистить историю") }
                }
            }

            StaggeredSection(5) {
                SectionCard("О приложении", Icons.Filled.Info) {
                    val version = remember {
                        try {
                            context.packageManager.getPackageInfo(context.packageName, 0).versionName
                        } catch (_: Exception) { null }
                    }
                    Text("TG Bot Client Pro ${version.orEmpty()}", style = MaterialTheme.typography.bodyMedium)
                    TextButton(
                        onClick = {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/BotFather")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            } catch (_: Exception) {
                                showMessage("Нет приложения для открытия ссылки")
                            }
                        },
                        contentPadding = PaddingValues(0.dp)
                    ) { Text("Открыть @BotFather") }
                }
            }
            Spacer(Modifier.windowInsetsBottomHeight(WindowInsets.navigationBars))
        }
    }

    confirmMode?.let { target ->
        AlertDialog(
            onDismissRequest = { confirmMode = null },
            icon = { Icon(Icons.Filled.Share, null) },
            title = { Text(if (target == Mode.CLOUD) "Перейти в облачный режим?" else "Вернуться к локальному режиму?") },
            text = {
                Text(
                    if (target == Mode.CLOUD)
                        "Локальный опрос будет остановлен: при включённом Serverless Telegram сам доставляет сообщения в облако, а getUpdates вернул бы ошибку 409.\n\nВ облаке окажутся только сообщения, пришедшие после включения Serverless. Более ранние, не полученные приложением, Telegram не отдаст. История на устройстве сохранится."
                    else
                        "Фоновая синхронизация с мостом будет выключена. Чтобы локальный опрос работал, отключите Serverless у бота в @BotFather — иначе Telegram вернёт 409. История на устройстве сохранится."
                )
            },
            confirmButton = {
                TextButton(onClick = { confirmMode = null; applyMode(target) }) { Text("Переключить") }
            },
            dismissButton = { TextButton(onClick = { confirmMode = null }) { Text("Отмена") } }
        )
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            icon = { Icon(Icons.Filled.Delete, null) },
            title = { Text("Очистить историю?") },
            text = { Text("Все чаты, сообщения и черновики будут удалены с этого устройства. В Telegram ничего не изменится.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmClear = false
                    scope.launch {
                        withContext(Dispatchers.IO) { Storage.get(context).clearAll() }
                        CloudSync.resetCursor(context) // cloud mode: history can be downloaded again
                        val editor = prefs.edit()
                        prefs.all.keys.filter { it.startsWith("draft_") }.forEach { editor.remove(it) }
                        editor.apply()
                        MessageBus.notifyChanged()
                        showMessage("История очищена")
                    }
                }) { Text("Очистить", color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun StatusPanel(status: BotStatus) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(
        when (status.state) {
            BotState.ERROR -> cs.errorContainer
            BotState.RUNNING -> statusColor(BotState.RUNNING).copy(alpha = 0.14f)
            else -> cs.surfaceVariant
        },
        tween(Motion.MEDIUM), label = "statusBg"
    )
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusDot(status.state)
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f)) {
            AnimatedStatusText(
                "Бот " + statusText(status),
                cs.onSurface, MaterialTheme.typography.titleSmall
            )
            AnimatedVisibility(
                visible = status.message.isNotBlank() && status.state != BotState.RUNNING,
                enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
            ) {
                Text(status.message, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
    }
}

/** Cards slide up one after another the first time the screen opens. */
@Composable
private fun StaggeredSection(index: Int, content: @Composable () -> Unit) {
    val state = remember { MutableTransitionState(false).apply { targetState = true } }
    androidx.compose.animation.AnimatedVisibility(
        visibleState = state,
        enter = fadeIn(tween(Motion.MEDIUM, delayMillis = 60 + index * 50)) +
            slideInVertically(tween(Motion.LONG, delayMillis = 60 + index * 50, easing = Motion.EmphasizedDecelerate)) { it / 4 }
    ) { content() }
}

private sealed interface BridgeCheck {
    data object Idle : BridgeCheck
    data object Checking : BridgeCheck
    data class Ok(val status: BridgeStatus) : BridgeCheck
    data class Failed(val message: String) : BridgeCheck
}

/** Bridge address + app key. Both stay on this device only (SharedPreferences, app-private). */
@Composable
private fun CloudPanel() {
    val context = LocalContext.current
    val prefs = remember { Prefs.of(context) }
    val scope = rememberCoroutineScope()
    val showMessage = LocalShowMessage.current
    val cs = MaterialTheme.colorScheme
    val cloud by CloudSync.state.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf(prefs.getString("bridge_url", "").orEmpty()) }
    var key by remember { mutableStateOf(prefs.getString("bridge_key", "").orEmpty()) }
    var showKey by remember { mutableStateOf(false) }
    var check by remember { mutableStateOf<BridgeCheck>(BridgeCheck.Idle) }

    val urlTrim = url.trim().trimEnd('/')
    val urlOk = urlTrim.isEmpty() || (urlTrim.startsWith("https://") && urlTrim.length > 10 && !urlTrim.contains(' '))
    val keyTrim = key.trim()
    val keyOk = keyTrim.isEmpty() || keyTrim.startsWith("app_")
    val ready = urlTrim.isNotEmpty() && urlOk && keyTrim.isNotEmpty() && keyOk

    fun save() {
        val old = prefs.getString("bridge_url", "").orEmpty()
        val edit = prefs.edit().putString("bridge_url", urlTrim).putString("bridge_key", keyTrim)
        if (old.trimEnd('/') != urlTrim) edit.putLong("sync_cursor", 0L) // another bridge = another history
        edit.apply()
        CloudSync.schedule(context.applicationContext)
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = url, onValueChange = { url = it.replace("\n", ""); check = BridgeCheck.Idle },
            label = { Text("Адрес моста") }, placeholder = { Text("https://bridge.example.com") },
            singleLine = true, isError = !urlOk,
            supportingText = { Text(if (!urlOk) "Только https://" else "Ваш сервер из папки bridge, за HTTPS") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Next),
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = key, onValueChange = { key = it.replace("\n", ""); check = BridgeCheck.Idle },
            label = { Text("Ключ приложения") }, placeholder = { Text("app_…") },
            singleLine = true, isError = !keyOk,
            supportingText = { Text(if (!keyOk) "Ключ начинается с app_" else "Выдаёт команда «npm run init» на мосту") },
            textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            trailingIcon = { TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Скрыть" else "Показать") } },
            shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )

        AnimatedContent(
            targetState = check,
            transitionSpec = {
                (fadeIn(tween(Motion.MEDIUM)) + slideInVertically(tween(Motion.MEDIUM, easing = Motion.EmphasizedDecelerate)) { it / 3 }) togetherWith
                    fadeOut(tween(Motion.SHORT))
            },
            label = "bridgeCheck"
        ) { c ->
            when (c) {
                BridgeCheck.Idle -> Spacer(Modifier.height(0.dp))
                BridgeCheck.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("Связываюсь с мостом…", style = MaterialTheme.typography.bodyMedium)
                }
                is BridgeCheck.Ok -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (c.status.paired) Icons.Filled.CheckCircle else Icons.Filled.Warning, null,
                        tint = if (c.status.paired) statusColor(BotState.RUNNING) else cs.error
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        if (c.status.paired) "Мост на связи · чатов ${c.status.chats}, сообщений ${c.status.messages}"
                        else "Мост работает, но Serverless ещё не привязан: отправьте боту /pair КОД",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                is BridgeCheck.Failed -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Warning, null, tint = cs.error)
                    Spacer(Modifier.width(10.dp))
                    Text(c.message, color = cs.error, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = ready && check != BridgeCheck.Checking && !cloud.syncing,
                shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f),
                onClick = {
                    save()
                    check = BridgeCheck.Checking
                    scope.launch {
                        check = try {
                            BridgeCheck.Ok(CloudSync.status(context.applicationContext))
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            BridgeCheck.Failed(CloudSync.humanBridgeError(e))
                        }
                        if ((check as? BridgeCheck.Ok)?.status?.paired == true) {
                            val n = CloudSync.sync(context.applicationContext)
                            CloudSync.state.value.error?.let { showMessage(it) } ?: showMessage("Синхронизировано, новых: $n")
                        }
                    }
                }
            ) {
                if (cloud.syncing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                else Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("Сохранить и проверить")
            }
        }
        AnimatedVisibility(
            visible = cloud.error != null && check !is BridgeCheck.Failed,
            enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()
        ) {
            InfoBanner("Последняя синхронизация: ${cloud.error.orEmpty()}", isError = true)
        }
    }
}
