package com.example.tgbotclient

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Receiving mode: local long-polling (getUpdates) or Telegram Serverless + bridge. */
object Mode {
    const val LOCAL = "local"
    const val CLOUD = "cloud"
    fun get(context: Context): String = Prefs.of(context).getString("mode", LOCAL) ?: LOCAL
    fun isCloud(context: Context) = get(context) == CLOUD
}

class BridgeException(message: String, val code: Int) : IOException(message)

data class CloudState(
    val syncing: Boolean = false,
    val lastSync: Long = 0L,
    val error: String? = null,
    val lastNew: Int = 0
)

data class BridgeStatus(val paired: Boolean, val chats: Int, val messages: Int)

/**
 * Pulls history from the owner's bridge (which receives it from Telegram Serverless).
 * Cursor-based, idempotent: re-running a sync never duplicates messages.
 */
object CloudSync {
    private val JSON = "application/json".toMediaType()
    private val lock = Mutex()
    private val _state = MutableStateFlow(CloudState())
    val state: StateFlow<CloudState> = _state.asStateFlow()

    private const val PAGE = 200
    private const val MAX_PAGES = 25
    private const val WORK_NAME = "cloud_sync"

    fun bridgeUrl(context: Context) = Prefs.of(context).getString("bridge_url", "").orEmpty().trim().trimEnd('/')
    private fun appKey(context: Context) = Prefs.of(context).getString("bridge_key", "").orEmpty().trim()

    fun isConfigured(context: Context) = bridgeUrl(context).startsWith("https://") && appKey(context).isNotEmpty()

    private fun request(context: Context, path: String, body: JSONObject? = null): JSONObject {
        val url = bridgeUrl(context)
        if (!url.startsWith("https://")) throw BridgeException("Адрес моста должен начинаться с https://", 0)
        val b = Request.Builder().url(url + path).header("Authorization", "Bearer ${appKey(context)}")
        if (body != null) b.post(body.toString().toRequestBody(JSON))
        TelegramApi.client.newCall(b.build()).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            val json = try { JSONObject(raw.ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
            if (!resp.isSuccessful || !json.optBoolean("ok")) {
                val msg = when (resp.code) {
                    401 -> "Мост отклонил ключ приложения"
                    429 -> "Слишком много неудачных попыток, подождите 10 минут"
                    404 -> "По этому адресу нет моста"
                    else -> "Мост ответил HTTP ${resp.code}"
                }
                throw BridgeException(msg, resp.code)
            }
            return json
        }
    }

    suspend fun status(context: Context): BridgeStatus = withContext(Dispatchers.IO) {
        val j = request(context, "/v1/status")
        BridgeStatus(j.optBoolean("paired"), j.optInt("chats"), j.optInt("messages"))
    }

    /** Records a message the app sent via Bot API so the cloud history contains outgoing messages too. */
    suspend fun recordOutgoing(context: Context, chatId: Long, messageId: Long, text: String, replyTo: Long?, time: Long) {
        val item = JSONObject().put("chat_id", chatId).put("message_id", messageId).put("text", text)
            .put("date", time).put("from_name", "Бот").apply { if (replyTo != null) put("reply_to", replyTo) }
        withContext(Dispatchers.IO) {
            try {
                request(context, "/v1/outgoing", item)
            } catch (e: Exception) {
                enqueueOutgoing(context, item) // retried on the next sync
            }
        }
    }

    private fun enqueueOutgoing(context: Context, item: JSONObject) = synchronized(this) {
        val prefs = Prefs.of(context)
        val arr = JSONArray(prefs.getString("pending_outgoing", "[]"))
        if (arr.length() < 500) arr.put(item)
        prefs.edit().putString("pending_outgoing", arr.toString()).apply()
    }

    private fun flushOutgoing(context: Context) {
        val prefs = Prefs.of(context)
        val arr = synchronized(this) { JSONArray(prefs.getString("pending_outgoing", "[]")) }
        if (arr.length() == 0) return
        val left = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            try {
                request(context, "/v1/outgoing", item)
            } catch (e: BridgeException) {
                if (e.code != 400) left.put(item) // 400 = malformed, drop it
            } catch (_: Exception) {
                left.put(item)
            }
        }
        synchronized(this) { prefs.edit().putString("pending_outgoing", left.toString()).apply() }
    }

    /**
     * Downloads all changes since the saved cursor. Returns the number of new incoming messages.
     * [notify] shows notifications for them (background worker).
     */
    suspend fun sync(context: Context, notify: Boolean = false): Int = lock.withLock {
        if (!Mode.isCloud(context) || !isConfigured(context)) return 0
        _state.value = _state.value.copy(syncing = true)
        withContext(Dispatchers.IO) {
            val prefs = Prefs.of(context)
            val storage = Storage.get(context)
            var newIncoming = 0
            try {
                flushOutgoing(context)
                var cursor = prefs.getLong("sync_cursor", 0L)
                val notifyQueue = mutableListOf<TgMessage>()
                for (page in 0 until MAX_PAGES) {
                    val j = request(context, "/v1/sync?since=$cursor&limit=$PAGE")
                    val chats = HashMap<Long, Pair<String, String>>()
                    j.optJSONArray("chats")?.let { a ->
                        for (i in 0 until a.length()) {
                            val c = a.getJSONObject(i)
                            chats[c.getLong("id")] = c.optString("title") to c.optString("type", "private")
                        }
                    }
                    val msgs = j.optJSONArray("messages") ?: JSONArray()
                    for (i in 0 until msgs.length()) {
                        val m = msgs.getJSONObject(i)
                        val chatId = m.getLong("chat_id")
                        val msg = TgMessage(
                            id = m.getLong("message_id"),
                            chatId = chatId,
                            fromName = m.optString("from_name"),
                            text = m.optString("text"),
                            time = m.getLong("date"),
                            isBot = m.optInt("is_bot") == 1,
                            replyTo = if (m.isNull("reply_to")) null else m.getLong("reply_to"),
                            mediaType = if (m.isNull("media_type")) null else m.getString("media_type")
                        )
                        val isNew = !storage.messageExists(chatId, msg.id)
                        val countIt = isNew && !msg.isBot && MessageBus.openChatId != chatId
                        val (title, type) = chats[chatId] ?: (null to null)
                        storage.saveMessage(msg, title?.ifBlank { null }, type, countUnread = countIt)
                        if (countIt) {
                            newIncoming++
                            notifyQueue.add(msg)
                        }
                    }
                    cursor = j.optLong("next", cursor)
                    prefs.edit().putLong("sync_cursor", cursor).apply() // progress survives a crash mid-sync
                    if (!j.optBoolean("has_more")) break
                }
                if (notify) {
                    // one notification per chat with the newest message
                    notifyQueue.groupBy { it.chatId }.forEach { (chatId, list) ->
                        val last = list.last()
                        val text = if (list.size > 1) "${last.text}  (+${list.size - 1})" else last.text
                        Notifier.showMessage(context, last.fromName, text, chatId)
                    }
                }
                _state.value = CloudState(syncing = false, lastSync = System.currentTimeMillis(), error = null, lastNew = newIncoming)
            } catch (e: Exception) {
                _state.value = _state.value.copy(syncing = false, error = humanBridgeError(e))
            }
            if (newIncoming > 0) MessageBus.notifyChanged()
            newIncoming
        }
    }

    fun humanBridgeError(e: Throwable): String = when (e) {
        is BridgeException -> e.message.orEmpty()
        else -> humanError(e)
    }

    /** Resets the cursor so the whole bridge history is downloaded again (dedup keeps it safe). */
    fun resetCursor(context: Context) {
        Prefs.of(context).edit().putLong("sync_cursor", 0L).apply()
    }

    fun schedule(context: Context) {
        val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}

/** Background sync while the app is closed (Android runs it about every 15 minutes, when online). */
class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!Mode.isCloud(applicationContext)) return Result.success()
        CloudSync.sync(applicationContext, notify = true)
        return if (CloudSync.state.value.error == null) Result.success() else Result.retry()
    }
}
