package com.example.tgbotclient

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.*
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BotPollingService : Service() {

    companion object {
        /** Kept for compatibility; the UI observes [MessageBus.status]. */
        @Volatile var running = false

        const val CHANNEL_MESSAGES = "bot_channel"   // same id as before: user settings survive the update
        const val CHANNEL_SERVICE = "bot_service"
        private const val SERVICE_NOTIFICATION_ID = 1
        private const val POLL_TIMEOUT_SEC = 25
    }

    private var job: Job? = null
    @Volatile private var call: Call? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    // read timeout must be longer than the long-poll timeout
    private val client: OkHttpClient = TelegramApi.client.newBuilder()
        .readTimeout(POLL_TIMEOUT_SEC + 15L, TimeUnit.SECONDS)
        .build()
    private lateinit var storage: Storage

    override fun onCreate() {
        super.onCreate()
        storage = Storage.get(this)
        createChannels()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.getStringExtra("action") == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (Mode.isCloud(this)) {
            // Telegram Serverless owns the webhook; getUpdates would only get 409 Conflict
            MessageBus.setStatus(BotStatus(BotState.STOPPED, "Облачный режим: опрос отключён"))
            stopSelf()
            return START_NOT_STICKY
        }
        if (!goForeground()) return START_NOT_STICKY
        running = true
        startPolling()
        return START_STICKY
    }

    private fun createChannels() {
        Notifier.ensureChannel(this)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_SERVICE, "Работа бота в фоне", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                }
            )
        }
    }

    private fun serviceNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_SERVICE)
        .setContentTitle(getString(R.string.app_name))
        .setContentText(text)
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .setContentIntent(
            PendingIntent.getActivity(
                this, 0,
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .addAction(
            0, "Остановить",
            PendingIntent.getService(
                this, 1,
                Intent(this, BotPollingService::class.java).putExtra("action", "stop"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        )
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .build()

    /** Returns false if Android refused to start a foreground service (e.g. sticky restart from background). */
    private fun goForeground(): Boolean {
        try {
            ServiceCompat.startForeground(
                this, SERVICE_NOTIFICATION_ID, serviceNotification("Подключение…"),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
            )
        } catch (e: Exception) {
            MessageBus.setStatus(BotStatus(BotState.ERROR, "Android не разрешил фоновую работу. Откройте приложение и нажмите «Старт»."))
            stopSelf()
            return false
        }
        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "tgbot:polling").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        return true
    }

    private fun updateServiceNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(SERVICE_NOTIFICATION_ID, serviceNotification(text))
    }

    private fun status(state: BotState, message: String = "") {
        MessageBus.setStatus(BotStatus(state, message))
        if (state != BotState.STOPPED) {
            updateServiceNotification(
                when (state) {
                    BotState.RUNNING -> "Бот на связи"
                    BotState.STARTING -> "Подключение…"
                    else -> message.ifBlank { "Переподключение…" }
                }
            )
        }
    }

    private fun fatal(message: String) {
        status(BotState.ERROR, message)
        stopSelf()
    }

    private fun startPolling() {
        job?.cancel()
        call?.cancel() // otherwise the old long-poll lives up to 25s and Telegram answers 409
        job = scope.launch {
            val prefs = Prefs.of(this@BotPollingService)
            val token = prefs.getString("token", "").orEmpty().trim()
            if (token.isEmpty()) {
                fatal("Укажите токен бота в настройках")
                return@launch
            }
            status(BotState.STARTING)
            var offset = prefs.getLong("offset", 0L)

            try {
                val me = TelegramApi.getMe(token)
                prefs.edit().putString("bot_name", me.firstName).putString("bot_username", me.username).apply()
            } catch (e: TelegramException) {
                if (e.code == 401 || e.code == 404) {
                    fatal("Неверный токен бота")
                    return@launch
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // no network yet: the loop below keeps retrying
            }

            var failures = 0
            while (isActive) {
                try {
                    val url = "https://api.telegram.org/bot$token/getUpdates".toHttpUrl().newBuilder()
                        .addQueryParameter("offset", offset.toString())
                        .addQueryParameter("timeout", POLL_TIMEOUT_SEC.toString())
                        .addQueryParameter("allowed_updates", """["message","edited_message","callback_query"]""")
                        .build()
                    val c = client.newCall(Request.Builder().url(url).build())
                    call = c
                    val (code, body) = c.execute().use { it.code to it.body?.string().orEmpty() }

                    if (code == 401 || code == 404) {
                        fatal("Неверный токен бота")
                        return@launch
                    }
                    val json = JSONObject(body.ifBlank { "{}" })
                    if (!json.optBoolean("ok")) {
                        val err = TelegramException(
                            json.optString("description", "HTTP $code"),
                            json.optInt("error_code", code),
                            json.optJSONObject("parameters")?.optInt("retry_after", 0)?.takeIf { it > 0 }
                        )
                        failures++
                        status(BotState.RETRYING, humanError(err))
                        // 409 / 429 / 5xx: without a pause this was a tight request loop
                        delay(((err.retryAfter ?: 0) * 1000L).coerceAtLeast(backoff(failures)))
                        continue
                    }
                    if (failures > 0 || MessageBus.status.value.state != BotState.RUNNING) status(BotState.RUNNING)
                    failures = 0
                    val results = json.getJSONArray("result")
                    for (i in 0 until results.length()) {
                        val update = results.getJSONObject(i)
                        offset = update.getLong("update_id") + 1
                        try {
                            handleUpdate(update, token)
                        } catch (_: Exception) {
                            // one bad update must not block the queue
                        }
                    }
                    if (results.length() > 0) {
                        prefs.edit().putLong("offset", offset).apply()
                        MessageBus.notifyChanged()
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (!isActive) break
                    failures++
                    status(BotState.RETRYING, humanError(e))
                    delay(backoff(failures))
                }
            }
        }
    }

    /** 2s, 4s, 8s … up to 30s. */
    private fun backoff(failures: Int): Long = (2000L shl (failures - 1).coerceIn(0, 4)).coerceAtMost(30_000L)

    private fun chatTitle(chat: JSONObject): String =
        chat.optString("title").ifBlank {
            listOf(chat.optString("first_name"), chat.optString("last_name"))
                .filter { it.isNotBlank() }.joinToString(" ")
        }.ifBlank { chat.optString("username") }.ifBlank { "Чат ${chat.optLong("id")}" }

    private fun handleUpdate(update: JSONObject, token: String) {
        val message = update.optJSONObject("message") ?: update.optJSONObject("edited_message")

        if (message != null) {
            val chat = message.getJSONObject("chat")
            val chatId = chat.getLong("id")
            val fromName = message.optJSONObject("from")?.optString("first_name").orEmpty().ifBlank { chatTitle(chat) }
            val media = mediaType(message)
            val text = if (message.has("text")) {
                message.getString("text")
            } else {
                val label = mediaLabel(message)
                val caption = message.optString("caption")
                if (caption.isBlank()) label else "$label $caption"
            }
            val msgId = message.getLong("message_id")
            val time = message.getLong("date") * 1000
            val replyTo = message.optJSONObject("reply_to_message")?.getLong("message_id")
            val edited = update.has("edited_message")

            val tgMsg = TgMessage(msgId, chatId, fromName, text, time, false, replyTo, media)
            val visible = MessageBus.openChatId == chatId
            storage.saveMessage(tgMsg, chatTitle(chat), chat.optString("type", "private"), countUnread = !visible && !edited)
            if (!visible) showNotification(fromName, if (edited) "✎ $text" else text, chatId)
            return
        }

        val cb = update.optJSONObject("callback_query")
        if (cb != null) {
            val data = cb.optString("data")
            val from = cb.optJSONObject("from")?.optString("first_name") ?: "?"
            val msg = cb.optJSONObject("message")
            if (msg != null) {
                val chat = msg.getJSONObject("chat")
                val chatId = chat.getLong("id")
                val text = "[Кнопка] $from нажал: $data"
                val now = System.currentTimeMillis()
                val tgMsg = TgMessage(now, chatId, from, text, now, false)
                val visible = MessageBus.openChatId == chatId
                storage.saveMessage(tgMsg, chatTitle(chat), chat.optString("type", "private"), countUnread = !visible)
                if (!visible) showNotification(from, text, chatId)
            }
            // answer the callback so the button stops showing a spinner
            try {
                val answer = "https://api.telegram.org/bot$token/answerCallbackQuery".toHttpUrl().newBuilder()
                    .addQueryParameter("callback_query_id", cb.getString("id"))
                    .build()
                client.newCall(Request.Builder().url(answer).build()).execute().close()
            } catch (_: Exception) {
            }
        }
    }

    private fun mediaType(message: JSONObject): String? =
        listOf("photo", "document", "voice", "video", "sticker", "location", "contact", "audio", "animation", "video_note")
            .firstOrNull { message.has(it) }

    private fun mediaLabel(message: JSONObject): String = when {
        message.has("photo") -> "[Фото]"
        message.has("document") -> "[Документ: ${message.getJSONObject("document").optString("file_name")}]"
        message.has("voice") -> "[Голосовое]"
        message.has("video_note") -> "[Видеосообщение]"
        message.has("video") -> "[Видео]"
        message.has("animation") -> "[GIF]"
        message.has("audio") -> "[Аудио]"
        message.has("sticker") -> "[Стикер ${message.getJSONObject("sticker").optString("emoji")}]".replace(" ]", "]")
        message.has("location") -> "[Геолокация]"
        message.has("contact") -> "[Контакт]"
        else -> "[Сообщение]"
    }

    private fun showNotification(from: String, text: String, chatId: Long) =
        Notifier.showMessage(this, from, text, chatId)

    /** Android 15+: dataSync foreground services are limited to ~6 hours per day. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        MessageBus.setStatus(
            BotStatus(BotState.ERROR, "Android остановил фоновую работу по лимиту времени. Запустите бота снова позже.")
        )
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        job?.cancel()
        call?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        scope.cancel()
        if (MessageBus.status.value.state != BotState.ERROR) MessageBus.setStatus(BotStatus(BotState.STOPPED))
        super.onDestroy()
    }
}
