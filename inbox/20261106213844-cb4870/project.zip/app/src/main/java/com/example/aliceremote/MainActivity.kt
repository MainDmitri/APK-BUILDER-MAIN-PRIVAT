package com.example.aliceremote

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val bluetoothManager by lazy { getSystemService(BluetoothManager::class.java) }
    private val bluetoothAdapter: BluetoothAdapter? by lazy { bluetoothManager.adapter }

    private val requestPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* UI checks hasPermissions */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AliceRemoteApp(
                activity = this,
                bluetoothAdapter = bluetoothAdapter,
                onRequestPermissions = {
                    val perms = mutableListOf(
                        Manifest.permission.BLUETOOTH_SCAN,
                        Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                        perms.add(Manifest.permission.BLUETOOTH)
                        perms.add(Manifest.permission.BLUETOOTH_ADMIN)
                    }
                    requestPermissions.launch(perms.toTypedArray())
                },
                hasPermissions = {
                    val scan = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    val connect = ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                    val loc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                    scan && connect && loc
                }
            )
        }
    }
}

@Composable
fun AliceRemoteApp(
    activity: ComponentActivity,
    bluetoothAdapter: BluetoothAdapter?,
    onRequestPermissions: () -> Unit,
    hasPermissions: () -> Boolean
) {
    var devices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var status by remember { mutableStateOf("Готов") }
    var isDiscovering by remember { mutableStateOf(false) }
    var connectedName by remember { mutableStateOf<String?>(null) }
    var log by remember { mutableStateOf("") }

    val audioManager = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    val receiver = remember {
        object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        }
                        device?.let { d ->
                            if (devices.none { it.address == d.address }) {
                                devices = devices + d
                                status = "Найдено: ${devices.size}"
                                log += "Found: ${d.name ?: "?"} (${d.address})\n"
                            }
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        isDiscovering = false
                        status = "Сканирование завершено (${devices.size})"
                        log += "Discovery finished\n"
                    }
                    BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                        val state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)
                        if (state == BluetoothDevice.BOND_BONDED) {
                            status = "Сопряжено"
                            log += "Bonded\n"
                        }
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        activity.registerReceiver(receiver, filter)
        onDispose {
            try { activity.unregisterReceiver(receiver) } catch (_: Exception) {}
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF7B1FA2),
            secondary = Color(0xFFCE93D8),
            background = Color(0xFF1A1A2E)
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                Modifier.fillMaxSize().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Алиса Пульт BT", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFFCE93D8))
                Spacer(Modifier.height(8.dp))
                Text(status, color = Color.White)
                if (connectedName != null) {
                    Text("Подключено: $connectedName", color = Color(0xFF81C784))
                }
                Spacer(Modifier.height(16.dp))

                if (!hasPermissions()) {
                    Button(onClick = onRequestPermissions) { Text("Разрешения Bluetooth") }
                } else if (bluetoothAdapter == null) {
                    Text("Bluetooth не поддерживается", color = Color.Red)
                } else {
                    Button(onClick = {
                        if (!bluetoothAdapter.isEnabled) {
                            status = "Включите Bluetooth"
                            return@Button
                        }
                        devices = emptyList()
                        isDiscovering = true
                        status = "Сканирование..."
                        log += "Start discovery\n"
                        if (bluetoothAdapter.isDiscovering) bluetoothAdapter.cancelDiscovery()
                        bluetoothAdapter.startDiscovery()
                    }, enabled = !isDiscovering) {
                        Text(if (isDiscovering) "Сканирую..." else "Сканировать")
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Также показываю уже сопряжённые:", color = Color.Gray, fontSize = 12.sp)
                    Button(onClick = {
                        val bonded = bluetoothAdapter.bondedDevices.toList()
                        devices = bonded
                        status = "Сопряжённые: ${bonded.size}"
                    }) { Text("Показать сопряжённые") }

                    LazyColumn(Modifier.height(160.dp).fillMaxWidth()) {
                        items(devices) { device ->
                            Button(
                                onClick = {
                                    status = "Сопряжение / подключение ${device.name ?: device.address}"
                                    if (device.bondState != BluetoothDevice.BOND_BONDED) {
                                        device.createBond()
                                    }
                                    connectedName = device.name ?: device.address
                                    log += "Selected: ${device.name}\n"
                                    // After pairing, system will connect A2DP when media plays
                                },
                                Modifier.fillMaxWidth().padding(2.dp)
                            ) {
                                Text("${device.name ?: "Unknown"} (${device.address})")
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("Управление медиа (после подключения как колонка):", color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { sendMediaKey(audioManager, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }) { Text("⏮") }
                        Button(onClick = { sendMediaKey(audioManager, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }) { Text("⏯") }
                        Button(onClick = { sendMediaKey(audioManager, KeyEvent.KEYCODE_MEDIA_NEXT) }) { Text("⏭") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0) }) { Text("Vol+") }
                        Button(onClick = { audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0) }) { Text("Vol-") }
                    }

                    Spacer(Modifier.height(12.dp))
                    Text("Лог:", color = Color.Gray, fontSize = 12.sp)
                    Text(log.takeLast(500), color = Color.LightGray, fontSize = 10.sp)
                }
            }
        }
    }
}

fun sendMediaKey(audioManager: AudioManager, keyCode: Int) {
    val eventDown = KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
    val eventUp = KeyEvent(KeyEvent.ACTION_UP, keyCode)
    audioManager.dispatchMediaKeyEvent(eventDown)
    audioManager.dispatchMediaKeyEvent(eventUp)
}
