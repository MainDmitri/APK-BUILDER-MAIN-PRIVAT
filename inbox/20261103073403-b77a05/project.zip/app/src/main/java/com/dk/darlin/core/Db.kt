package com.dk.darlin.core

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Note(val id: Long, val text: String, val created: Long)
data class Reminder(val id: Long, val text: String, val at: Long, val done: Boolean)
data class HistoryItem(val id: Long, val role: String, val text: String, val created: Long)

class Db private constructor(c: Context) : SQLiteOpenHelper(c.applicationContext, "darlin.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, created INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, at INTEGER NOT NULL, done INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT NOT NULL, text TEXT NOT NULL, created INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addNote(text: String): Long = writableDatabase.insert("notes", null, ContentValues().apply {
        put("text", text); put("created", System.currentTimeMillis())
    })

    fun notes(query: String? = null): List<Note> {
        val out = ArrayList<Note>()
        val c = if (query.isNullOrBlank())
            readableDatabase.rawQuery("SELECT id,text,created FROM notes ORDER BY id DESC LIMIT 200", null)
        else readableDatabase.rawQuery("SELECT id,text,created FROM notes WHERE text LIKE ? ORDER BY id DESC LIMIT 200", arrayOf("%$query%"))
        c.use { while (it.moveToNext()) out.add(Note(it.getLong(0), it.getString(1), it.getLong(2))) }
        return out
    }

    fun deleteNote(id: Long) = writableDatabase.delete("notes", "id=?", arrayOf(id.toString())) > 0

    fun addReminder(text: String, at: Long): Long = writableDatabase.insert("reminders", null, ContentValues().apply {
        put("text", text); put("at", at); put("done", 0)
    })

    fun reminder(id: Long): Reminder? = readableDatabase.rawQuery("SELECT id,text,at,done FROM reminders WHERE id=?", arrayOf(id.toString())).use {
        if (it.moveToFirst()) Reminder(it.getLong(0), it.getString(1), it.getLong(2), it.getInt(3) != 0) else null
    }

    fun reminders(activeOnly: Boolean = true): List<Reminder> {
        val out = ArrayList<Reminder>()
        val sql = "SELECT id,text,at,done FROM reminders " + (if (activeOnly) "WHERE done=0 " else "") + "ORDER BY at ASC LIMIT 200"
        readableDatabase.rawQuery(sql, null).use {
            while (it.moveToNext()) out.add(Reminder(it.getLong(0), it.getString(1), it.getLong(2), it.getInt(3) != 0))
        }
        return out
    }

    fun markReminderDone(id: Long) {
        writableDatabase.update("reminders", ContentValues().apply { put("done", 1) }, "id=?", arrayOf(id.toString()))
    }

    fun deleteReminder(id: Long) = writableDatabase.delete("reminders", "id=?", arrayOf(id.toString())) > 0

    fun addHistory(role: String, text: String) {
        writableDatabase.insert("history", null, ContentValues().apply {
            put("role", role); put("text", text); put("created", System.currentTimeMillis())
        })
    }

    fun history(limit: Int = 200): List<HistoryItem> {
        val out = ArrayList<HistoryItem>()
        readableDatabase.rawQuery("SELECT id,role,text,created FROM history ORDER BY id DESC LIMIT $limit", null).use {
            while (it.moveToNext()) out.add(HistoryItem(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3)))
        }
        return out.reversed()
    }

    fun clearHistory() { writableDatabase.delete("history", null, null) }

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) { inst ?: Db(c).also { inst = it } }
    }
}
