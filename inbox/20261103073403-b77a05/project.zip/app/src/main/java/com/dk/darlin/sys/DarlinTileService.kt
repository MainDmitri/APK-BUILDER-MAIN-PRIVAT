package com.dk.darlin.sys

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.quicksettings.TileService
import com.dk.darlin.AssistActivity
import com.dk.darlin.voice.DarlinInteractionService

/** Плитка в шторке быстрых настроек: «Дарлин». */
class DarlinTileService : TileService() {
    @SuppressLint("StartActivityAndCollapseDeprecated")
    override fun onClick() {
        val svc = DarlinInteractionService.instance
        if (svc != null) {
            svc.showSession(Bundle(), 0)
            return
        }
        val i = Intent(this, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
