package com.dk.darlin.core

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import kotlinx.coroutines.CoroutineExceptionHandler
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Журнал сбоев: пишет ошибки в файл (показывается при следующем запуске с кнопкой «Копировать»),
 * не даёт ошибкам в обработчиках кнопок «ронять» приложение.
 */
object CrashLog {
    private const val TAG = "Darlin"
    private lateinit var app: Context
    private val main = Handler(Looper.getMainLooper())

    private fun file(c: Context) = File(c.applicationContext.filesDir, "crash_log.txt")

    fun install(context: Context) {
        app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { write(app, e, "FATAL в потоке ${t.name}") } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
        // Страховка главного потока: исключения из обработчиков нажатий/диалогов/анимаций
        // записываем и показываем тостом, а не закрываем приложение.
        // Ошибки запуска экранов и самого приложения пробрасываем дальше — продолжать после них нельзя.
        if (Build.FINGERPRINT == "robolectric") return // в модульных тестах цикл не нужен
        main.post {
            while (true) {
                try {
                    Looper.loop()
                } catch (e: Throwable) {
                    if (isLifecycleFatal(e)) throw e
                    report(app, e, "Ошибка на главном потоке")
                }
            }
        }
    }

    private fun isLifecycleFatal(e: Throwable): Boolean {
        val trace = Log.getStackTraceString(e)
        return trace.contains("performLaunchActivity") || trace.contains("handleBindApplication") ||
            trace.contains("handleCreateService") || trace.contains("performResumeActivity") && trace.contains("SuperNotCalledException") ||
            e is StackOverflowError && trace.contains("ActivityThread.handle")
    }

    fun write(c: Context, e: Throwable, where: String) {
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val pi = try { c.packageManager.getPackageInfo(c.packageName, 0) } catch (_: Exception) { null }
        @Suppress("DEPRECATION")
        val head = "=== ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())} · $where\n" +
            "Дарлин ${pi?.versionName} (${pi?.versionCode}) · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n"
        val f = file(c)
        val old = if (f.exists()) f.readText().takeLast(40_000) else ""
        f.writeText(old + head + sw.toString().take(12_000) + "\n")
        Log.e(TAG, where, e)
    }

    /** Нефатальная ошибка: запись в журнал + короткий тост. */
    fun report(c: Context, e: Throwable, where: String) {
        try { write(c, e, where) } catch (_: Throwable) {}
        val msg = "Ошибка: " + (e.message ?: e.javaClass.simpleName).take(140)
        val show = { try { Toast.makeText(c.applicationContext, msg, Toast.LENGTH_LONG).show() } catch (_: Throwable) {} }
        if (Looper.myLooper() == Looper.getMainLooper()) show() else main.post(show)
    }

    fun read(c: Context): String? = file(c).takeIf { it.exists() && it.length() > 0 }?.readText()
    fun clear(c: Context) { file(c).delete() }

    /** Флаг «журнал ещё не показан пользователю». */
    fun hasUnseen(c: Context) = file(c).exists() && file(c).lastModified() > Prefs.sp(c).getLong("crash_seen", 0)
    fun markSeen(c: Context) = Prefs.sp(c).edit().putLong("crash_seen", System.currentTimeMillis()).apply()

    fun coroutineHandler(c: Context, where: String) = CoroutineExceptionHandler { _, e -> report(c, e, where) }
    val globalHandler = CoroutineExceptionHandler { _, e -> if (::app.isInitialized) report(app, e, "Фоновая задача") else Log.e(TAG, "bg", e) }

    inline fun guard(c: Context, where: String, block: () -> Unit) {
        try { block() } catch (e: Throwable) { report(c, e, where) }
    }
}

/** Безопасный обработчик нажатия: исключение → запись в журнал и тост, без вылета. */
fun View.safeClick(block: (View) -> Unit) = setOnClickListener { v -> CrashLog.guard(v.context, "Нажатие: ${v.javaClass.simpleName} ${v.contentDescription ?: (v as? android.widget.TextView)?.text ?: ""}") { block(v) } }

fun View.safeLongClick(block: (View) -> Boolean) = setOnLongClickListener { v ->
    var r = false
    CrashLog.guard(v.context, "Долгое нажатие") { r = block(v) }
    r
}
