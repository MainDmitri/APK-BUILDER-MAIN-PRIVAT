package com.dk.darlin.voice

import android.os.Bundle
import android.service.voice.VoiceInteractionService

/** Главная служба цифрового помощника. Живёт, пока Дарлин выбрана помощником по умолчанию. */
class DarlinInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        instance = this
    }

    override fun onShutdown() {
        if (instance === this) instance = null
        super.onShutdown()
    }

    override fun onLaunchVoiceAssistFromKeyguard() {
        showSession(Bundle(), 0)
    }

    companion object {
        @Volatile var instance: DarlinInteractionService? = null
    }
}
