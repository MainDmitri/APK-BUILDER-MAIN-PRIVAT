package com.dk.darlin.voice

import android.app.assist.AssistContent
import android.app.assist.AssistStructure
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.core.view.WindowCompat
import com.dk.darlin.MainActivity
import com.dk.darlin.R
import com.dk.darlin.core.ScreenContext
import com.dk.darlin.ui.AssistantPanel
import android.view.ContextThemeWrapper

class DarlinSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = DarlinSession(this)
}

/** Сессия, которая показывается по долгому нажатию кнопки питания / жесту из угла. */
class DarlinSession(context: Context) : VoiceInteractionSession(context) {
    private var panel: AssistantPanel? = null
    private var screenText: String? = null
    private var screenPkg: String? = null
    private var webUri: String? = null
    private var shot: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        val w = window.window ?: return
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        WindowCompat.setDecorFitsSystemWindows(w, false)
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
                w.attributes = w.attributes.also { it.blurBehindRadius = 40 }
            } catch (_: Exception) {}
        }
    }

    override fun onCreateContentView(): View {
        val themed = ContextThemeWrapper(context, R.style.Theme_App)
        val p = AssistantPanel(themed, AssistantPanel.Mode.OVERLAY, object : AssistantPanel.Host {
            override fun close() { safeHide() }
            override fun launch(intent: Intent): Boolean = try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (intent.component?.packageName == context.packageName && android.os.Build.VERSION.SDK_INT >= 26) startAssistantActivity(intent)
                else context.startActivity(intent)
                true
            } catch (e: Exception) { false }
            override fun openApp() {
                launch(Intent(context, MainActivity::class.java)); safeHide()
            }
        })
        panel = p
        return p.root
    }

    /** hide() бросает IllegalStateException, если сессия уже закрыта системой — не роняем приложение. */
    private fun safeHide() { try { hide() } catch (_: Throwable) {} }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        panel?.onShown(ScreenContext(screenText, screenPkg, shot, webUri))
    }

    @Deprecated("Deprecated in Java")
    override fun onHandleAssist(data: Bundle?, structure: AssistStructure?, content: AssistContent?) {
        screenPkg = structure?.activityComponent?.packageName
        webUri = content?.webUri?.toString()
        screenText = structure?.let { extractText(it) }
        publish()
    }

    override fun onHandleScreenshot(screenshot: Bitmap?) {
        shot = screenshot
        publish()
    }

    private fun publish() {
        panel?.setScreenContext(ScreenContext(screenText, screenPkg, shot, webUri))
    }

    override fun onHide() {
        super.onHide()
        panel?.onHidden()
        screenText = null; screenPkg = null; shot = null; webUri = null
    }

    override fun onDestroy() {
        panel?.destroy()
        panel = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        safeHide()
    }

    private fun extractText(s: AssistStructure): String {
        val sb = StringBuilder()
        fun walk(n: AssistStructure.ViewNode, depth: Int) {
            if (depth > 80 || sb.length > 12000) return
            if (n.visibility != View.VISIBLE) return
            val t = n.text?.toString()?.trim()
            val d = n.contentDescription?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n')
            else if (!d.isNullOrEmpty()) sb.append('[').append(d).append("]\n")
            for (i in 0 until n.childCount) walk(n.getChildAt(i), depth + 1)
        }
        for (i in 0 until s.windowNodeCount) walk(s.getWindowNodeAt(i).rootViewNode, 0)
        return sb.toString()
    }
}
