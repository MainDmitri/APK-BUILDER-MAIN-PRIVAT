package com.dk.darlin.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Живой «шар» ассистента: переливается, реагирует на громкость голоса и состояние. */
class OrbView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state: State = State.IDLE
        set(v) { field = v; invalidate() }

    private var target = 0f
    private var level = 0f
    private val start = System.nanoTime()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * resources.displayMetrics.density }
    private val path = Path()

    private val colors = intArrayOf(Color.parseColor("#00E5FF"), Color.parseColor("#7C4DFF"), Color.parseColor("#FF4081"), Color.parseColor("#448AFF"))

    fun setLevel(v: Float) { target = v.coerceIn(0f, 1f) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = (System.nanoTime() - start) / 1e9f
        level += (target - level) * 0.25f
        if (state != State.LISTENING) target *= 0.9f
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f * 0.62f
        val speed = when (state) { State.THINKING -> 2.6f; State.LISTENING -> 1.2f; State.SPEAKING -> 1.6f; else -> 0.5f }
        val pulse = when (state) {
            State.SPEAKING -> 0.08f * sin(t * 9f) + 0.06f * sin(t * 5.3f)
            State.LISTENING -> 0.28f * level
            State.THINKING -> 0.05f * sin(t * 4f)
            else -> 0.04f * sin(t * 1.6f)
        }
        val r = base * (1f + pulse)

        // Мягкое свечение
        paint.shader = RadialGradient(cx, cy, r * 1.6f, intArrayOf(Color.argb(90, 124, 77, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 1.6f, paint)

        // Переливающиеся «капли»
        for (i in colors.indices) {
            val a = t * speed * (0.6f + i * 0.17f) + i * (PI.toFloat() / 2f)
            val off = r * 0.32f
            val bx = cx + cos(a) * off
            val by = cy + sin(a * 1.3f) * off
            val br = r * (0.78f + 0.08f * sin(t * 2f + i))
            val c = colors[i]
            paint.shader = RadialGradient(bx, by, br, intArrayOf(Color.argb(210, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(0, Color.red(c), Color.green(c), Color.blue(c))), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(bx, by, br, paint)
        }
        // Блик
        paint.shader = RadialGradient(cx - r * 0.3f, cy - r * 0.35f, r * 0.6f, intArrayOf(Color.argb(120, 255, 255, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx - r * 0.3f, cy - r * 0.35f, r * 0.6f, paint)
        paint.shader = null

        // Волна вокруг шара
        if (state == State.LISTENING || state == State.SPEAKING) {
            val amp = r * (if (state == State.LISTENING) 0.05f + 0.22f * level else 0.07f)
            path.reset()
            val n = 120
            for (k in 0..n) {
                val th = (k.toFloat() / n) * 2f * PI.toFloat()
                val rr = r * 1.18f + amp * sin(th * 6f + t * 6f) * sin(th * 3f - t * 2.3f)
                val x = cx + cos(th) * rr
                val y = cy + sin(th) * rr
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            ring.shader = RadialGradient(cx, cy, r * 1.4f, intArrayOf(Color.parseColor("#8000E5FF"), Color.parseColor("#C0FF4081")), null, Shader.TileMode.CLAMP)
            canvas.drawPath(path, ring)
        } else if (state == State.THINKING) {
            ring.shader = null
            ring.color = Color.argb(160, 255, 255, 255)
            val sweep = 70f + 40f * sin(t * 3f)
            canvas.drawArc(cx - r * 1.2f, cy - r * 1.2f, cx + r * 1.2f, cy + r * 1.2f, (t * 300f) % 360f, sweep, false, ring)
        }
        if (isShown) postInvalidateOnAnimation()
    }
}
