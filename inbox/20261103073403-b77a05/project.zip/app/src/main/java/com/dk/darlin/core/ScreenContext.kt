package com.dk.darlin.core

import android.graphics.Bitmap

/** То, что было на экране в момент вызова ассистента. */
class ScreenContext(val text: String?, val packageName: String?, val screenshot: Bitmap?, val webUri: String? = null) {
    fun isEmpty() = text.isNullOrBlank() && screenshot == null
}
