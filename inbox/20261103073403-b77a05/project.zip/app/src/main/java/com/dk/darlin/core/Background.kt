package com.dk.darlin.core

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.tts.Speaker
import com.dk.darlin.voice.DarlinInteractionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob

/**
 * Задачи, которые переживают закрытие панели: когда Дарлин управляет другим приложением,
 * панель сворачивается, а работа продолжается здесь.
 */
object Background {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + CrashLog.globalHandler)
    @Volatile var current: Job? = null
    /** Ответ, который нужно озвучить при следующем показе панели (если задача закончилась вопросом). */
    @Volatile var pendingReply: String? = null

    private var speaker: Speaker? = null
    fun speaker(ctx: Context): Speaker = speaker ?: Speaker(ctx.applicationContext).also { speaker = it }

    /** Показ индикатора «Дарлин работает…» с кнопкой «Стоп» поверх других приложений. */
    fun showWorking(ctx: Context, text: String = "Дарлин выполняет задачу…") {
        DarlinAccessibilityService.instance?.showCard(text, null, null, "Стоп") { current?.cancel() }
    }

    fun hideWorking() { DarlinAccessibilityService.instance?.hideCard() }

    /** Доставляет ответ, когда панель уже скрыта. */
    fun deliver(ctx: Context, reply: String, speak: Boolean) {
        hideWorking()
        val app = ctx.applicationContext
        val svc = DarlinInteractionService.instance
        if (reply.trim().endsWith("?") && svc != null) {
            // Нужен ответ пользователя — снова открываем панель, она озвучит вопрос и начнёт слушать
            pendingReply = reply
            try { svc.showSession(Bundle(), 0); return } catch (_: Exception) { pendingReply = null }
        }
        Toast.makeText(app, reply.take(300), Toast.LENGTH_LONG).show()
        if (speak) speaker(app).speak(reply, null) {}
    }
}
