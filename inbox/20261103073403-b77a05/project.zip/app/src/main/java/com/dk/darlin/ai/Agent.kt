package com.dk.darlin.ai

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import com.dk.darlin.core.Prefs
import com.dk.darlin.core.ScreenContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Память текущего диалога (живёт, пока жив процесс; сбрасывается через 10 минут тишины). */
object Conversation {
    val messages = ArrayList<JSONObject>()
    var lastTime = 0L

    fun touch() {
        val now = System.currentTimeMillis()
        if (now - lastTime > 10 * 60_000) messages.clear()
        lastTime = now
    }

    fun reset() { messages.clear(); lastTime = 0 }

    fun trim() {
        while (messages.size > 30) {
            messages.removeAt(0)
            // начинаем историю с сообщения пользователя, чтобы не рвать пары tool_calls/tool
            while (messages.isNotEmpty() && messages[0].optString("role") != "user") messages.removeAt(0)
        }
    }
}

/** «Мозг» ассистента: LLM с вызовом функций + локальные команды без интернета. */
class Agent(private val ctx: Context, val tools: ToolExecutor) {
    private val llm = LlmClient(ctx)
    private val local = LocalBrain(tools)

    private val screenWords = Regex("(?i)экран|скрин|на картинк|что это|что тут|что здесь|прочитай|переведи|объясни это|кто это|на фото|сообщени")

    private fun systemPrompt(screen: ScreenContext?): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val name = Prefs.str(ctx, Prefs.USER_NAME)
        val sb = StringBuilder()
        sb.append("Ты — Дарлин, личный голосовой помощник в Android-телефоне пользователя (вместо Google Ассистента). Ты девушка: тёплая, заботливая, весёлая и очень толковая. ")
        sb.append("О себе всегда говори в женском роде (сделала, открыла, нашла, поставила, рада, готова). ")
        sb.append("Говори по-русски, если пользователь не попросил иначе. Ответы озвучиваются вслух, поэтому отвечай кратко и естественно: обычно 1–3 предложения, без таблиц, markdown и эмодзи; длинно — только если просят подробно. ")
        sb.append("Для действий на телефоне ВСЕГДА вызывай функции, не выдумывай результат и не говори, что не можешь, пока не попробовала. ")
        sb.append("Для свежих фактов, новостей, погоды, курсов валют используй web_search.\n")
        sb.append("ФАЙЛЫ: пути относительно /storage/emulated/0 (Download, Documents, DCIM…). Если просят создать файл с кодом, текстом или игрой — сама напиши ПОЛНОЕ рабочее содержимое " +
            "(например, для игры «динозаврик» на Python — полноценный код на pygame с прыжком, препятствиями и счётом, с комментариями по запуску) и вызови write_file с этим содержимым целиком. В ответе кратко скажи, что и куда записала, код вслух не зачитывай.\n")
        sb.append("СООБЩЕНИЯ: «напиши Максу в WhatsApp привет» → send_message(app=whatsapp, contact=имя в именительном падеже, text). Потом спроси «Отправить?» и вызови confirm_send только после явного «да/отправь»; при «нет» — cancel_send. " +
            "Для SMS — send_message(app=sms).\n")
        sb.append("УПРАВЛЕНИЕ ЛЮБЫМ ПРИЛОЖЕНИЕМ (Telegram, браузер, настройки и т.д.): open_app(and_look=true) или ui_snapshot → получишь дерево элементов [N]; " +
            "действуй ui_click/ui_type/ui_scroll/ui_back по номерам; после каждого действия приходит новое дерево — проверяй результат и делай следующий шаг, пока задача не выполнена. " +
            "Если элемента не видно — прокрути или поищи через поиск приложения. Перед необратимыми действиями (отправка сообщения, оплата, удаление, звонок) спроси подтверждение. " +
            "Опасные действия выполняй только по явной просьбе. После действия коротко подтверди, что сделано.\n")
        sb.append("Сейчас: $now. Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}. ")
        sb.append("Внутренняя память: /storage/emulated/0.\n")
        if (name.isNotBlank()) sb.append("Пользователя зовут $name.\n")
        val custom = Prefs.str(ctx, Prefs.CUSTOM_PROMPT)
        if (custom.isNotBlank()) sb.append("Пожелания пользователя: $custom\n")
        if (screen != null && Prefs.bool(ctx, Prefs.SCREEN_TEXT, true)) {
            screen.packageName?.let { sb.append("Ассистент вызван поверх приложения: $it.\n") }
            screen.webUri?.let { sb.append("Открытая страница: $it\n") }
            if (!screen.text.isNullOrBlank()) {
                sb.append("Текст, видимый на экране в момент вызова (используй, если вопрос о «экране», «этом», «тут»):\n<<<\n")
                sb.append(screen.text.take(5000)).append("\n>>>\n")
            }
        }
        return sb.toString()
    }

    private fun imagePart(bmp: Bitmap): JSONObject {
        val scale = minOf(1f, 1280f / maxOf(bmp.width, bmp.height))
        val b = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        val bos = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 75, bos)
        val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        return JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
    }

    /**
     * Отвечает на реплику пользователя.
     * @param onAction вызывается (в главном потоке) с подписью каждого выполняемого действия.
     */
    suspend fun respond(userText: String, screen: ScreenContext?, onAction: (String) -> Unit): String {
        tools.screen = screen
        tools.launchedSomething = false
        tools.uiTask = false
        tools.keepAlive = false
        tools.keepOpen = UiAutomation.pending != null
        Conversation.touch()

        if (!Prefs.hasBrain(ctx)) {
            local.handle(userText, onAction)?.let { return it }
            return "Я пока работаю в базовом режиме: умею открывать приложения, звонить, ставить будильники, таймеры, напоминания, заметки, фонарик и громкость. " +
                "Чтобы я отвечала на любые вопросы и работала с файлами и экраном, добавьте ключ ИИ в разделе «Параметры» — например, бесплатный ключ Google Gemini."
        }

        val userMsg = JSONObject().put("role", "user").put("content", userText)
        Conversation.messages.add(userMsg)
        Conversation.trim()
        val startIdx = Conversation.messages.indexOf(userMsg)

        val wantsImage = screen?.screenshot != null && Prefs.bool(ctx, Prefs.SCREENSHOT, false) && screenWords.containsMatchIn(userText)

        return try {
            withContext(Dispatchers.IO) {
                var guard = 0
                while (true) {
                    val msgs = JSONArray()
                    msgs.put(JSONObject().put("role", "system").put("content", systemPrompt(screen)))
                    val toolIdx = Conversation.messages.withIndex().filter { it.value.optString("role") == "tool" }.map { it.index }
                    val keepFull = toolIdx.takeLast(2).toSet()
                    for ((idx, m) in Conversation.messages.withIndex()) {
                        if (m.optString("role") == "tool" && idx !in keepFull) {
                            val c = m.optString("content")
                            if (c.length > 1500 && c.contains("Экран")) {
                                msgs.put(JSONObject(m.toString()).put("content", c.take(500) + "\n…(старое дерево экрана сокращено)"))
                                continue
                            }
                        }
                        if (m === userMsg && wantsImage) {
                            val parts = JSONArray().put(JSONObject().put("type", "text").put("text", userText)).put(imagePart(screen!!.screenshot!!))
                            msgs.put(JSONObject().put("role", "user").put("content", parts))
                        } else msgs.put(m)
                    }
                    val maxRounds = if (tools.uiTask) 15 else 8
                    val reply = llm.chat(msgs, if (guard < maxRounds) ToolSpecs.all else null)
                    val calls = reply.optJSONArray("tool_calls")
                    if (calls != null && calls.length() > 0) {
                        val assistant = JSONObject().put("role", "assistant").put("content", reply.optString("content", "").let { if (it == "null") "" else it })
                        assistant.put("tool_calls", calls)
                        Conversation.messages.add(assistant)
                        for (i in 0 until calls.length()) {
                            val call = calls.getJSONObject(i)
                            val fn = call.getJSONObject("function")
                            val name = fn.getString("name")
                            val args = try { JSONObject(fn.optString("arguments").ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
                            withContext(Dispatchers.Main) { onAction(tools.label(name, args)) }
                            val result = tools.run(name, args)
                            Conversation.messages.add(
                                JSONObject().put("role", "tool").put("tool_call_id", call.optString("id", "call_$i"))
                                    .put("name", name).put("content", result.take(12000))
                            )
                        }
                        guard++
                        continue
                    }
                    val text = reply.optString("content", "").let { if (it == "null") "" else it }.trim()
                    val answer = text.ifBlank { "Готово." }
                    Conversation.messages.add(JSONObject().put("role", "assistant").put("content", answer))
                    return@withContext answer
                }
                @Suppress("UNREACHABLE_CODE")
                ""
            }
        } catch (e: Exception) {
            // Без сети/ошибка API — пробуем выполнить команду локально
            if (startIdx >= 0) while (Conversation.messages.size > startIdx) Conversation.messages.removeAt(Conversation.messages.size - 1)
            local.handle(userText, onAction) ?: ("Не получилось связаться с ИИ: " + (e.message ?: "ошибка сети") +
                ". Проверьте интернет и ключ в «Параметрах».")
        }
    }
}
