package com.dk.darlin.ui

import com.dk.darlin.core.safeClick
import com.dk.darlin.core.safeLongClick
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.ImageButton
import android.widget.TextView

object Ui {
    const val BG = 0xFF0B0D17.toInt()
    const val SURFACE = 0xFF151A2C.toInt()
    const val SURFACE2 = 0x1FFFFFFF
    const val TEXT = 0xFFEDEFFF.toInt()
    const val TEXT2 = 0xFF9AA3C7.toInt()
    const val ACCENT = 0xFF7C4DFF.toInt()
    const val ACCENT2 = 0xFF00E5FF.toInt()
    const val PINK = 0xFFFF4081.toInt()
    const val OK = 0xFF00E676.toInt()
    const val WARN = 0xFFFFB74D.toInt()

    fun dp(c: Context, v: Float): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.resources.displayMetrics).toInt()
    fun dp(c: Context, v: Int): Int = dp(c, v.toFloat())

    fun round(c: Context, color: Int, radiusDp: Float, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(c, radiusDp).toFloat()
        if (stroke != 0) setStroke(dp(c, 1), stroke)
    }

    fun gradient(c: Context, colors: IntArray, radiusDp: Float, orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR) =
        GradientDrawable(orientation, colors).apply { cornerRadius = dp(c, radiusDp).toFloat() }

    fun ripple(bg: android.graphics.drawable.Drawable?, mask: android.graphics.drawable.Drawable? = null) =
        RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, mask ?: bg ?: GradientDrawable().apply { setColor(Color.WHITE) })

    fun text(c: Context, s: CharSequence, sp: Float = 15f, color: Int = TEXT, bold: Boolean = false): TextView = TextView(c).apply {
        text = s; setTextSize(TypedValue.COMPLEX_UNIT_SP, sp); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setLineSpacing(0f, 1.15f)
    }

    fun iconButton(c: Context, icon: Int, sizeDp: Int = 40, bg: android.graphics.drawable.Drawable? = null, tint: Int = TEXT): ImageButton =
        ImageButton(c).apply {
            setImageResource(icon)
            imageTintList = ColorStateList.valueOf(tint)
            background = ripple(bg ?: GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) },
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) })
            val p = dp(c, 8); setPadding(p, p, p, p)
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            layoutParams = android.widget.LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        }

    fun chip(c: Context, s: String, onClick: () -> Unit): TextView = text(c, s, 13.5f, TEXT).apply {
        background = ripple(round(c, 0x1AFFFFFF, 18f, 0x22FFFFFF))
        setPadding(dp(c, 14), dp(c, 8), dp(c, 14), dp(c, 8))
        gravity = Gravity.CENTER
        safeClick { onClick() }
    }

    fun fadeIn(v: View) {
        v.alpha = 0f; v.translationY = dp(v.context, 12).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(260).start()
    }
}
