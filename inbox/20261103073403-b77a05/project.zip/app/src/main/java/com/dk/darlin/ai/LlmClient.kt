package com.dk.darlin.ai

import android.content.Context
import com.dk.darlin.core.Prefs
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Клиент любого OpenAI-совместимого API (/chat/completions, /models). */
class LlmClient(private val ctx: Context) {

    private fun open(path: String, method: String): HttpURLConnection {
        val url = URL(Prefs.baseUrl(ctx) + path)
        val c = url.openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 180_000
        c.setRequestProperty("Authorization", "Bearer " + Prefs.apiKey(ctx))
        c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        c.setRequestProperty("Accept", "application/json")
        if (Prefs.providerId(ctx) == "openrouter") {
            c.setRequestProperty("HTTP-Referer", "https://github.com/darlin-assistant")
            c.setRequestProperty("X-Title", "Darlin Assistant")
        }
        return c
    }

    private fun readResponse(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                val j = JSONObject(body)
                val e = j.opt("error")
                when (e) {
                    is JSONObject -> e.optString("message", body)
                    is JSONArray -> e.optJSONObject(0)?.optJSONObject("error")?.optString("message") ?: body
                    is String -> e
                    else -> body
                }
            } catch (_: Exception) { body }
            throw IOException("HTTP $code: ${msg.take(400)}")
        }
        return body
    }

    /** Возвращает объект message первого варианта ответа. */
    fun chat(messages: JSONArray, tools: JSONArray?): JSONObject {
        val req = JSONObject()
        req.put("model", Prefs.model(ctx))
        req.put("messages", messages)
        if (tools != null && tools.length() > 0) {
            req.put("tools", tools)
            req.put("tool_choice", "auto")
        }
        req.put("temperature", 0.6)
        val c = open("/chat/completions", "POST")
        c.doOutput = true
        c.outputStream.use { it.write(req.toString().toByteArray(Charsets.UTF_8)) }
        val body = readResponse(c)
        val j = JSONObject(body)
        val choices = j.optJSONArray("choices") ?: throw IOException("Пустой ответ модели: ${body.take(300)}")
        return choices.getJSONObject(0).getJSONObject("message")
    }

    fun listModels(): List<String> {
        val c = open("/models", "GET")
        val j = JSONObject(readResponse(c))
        val arr = j.optJSONArray("data") ?: JSONArray()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optString("id") ?: continue
            out.add(id.removePrefix("models/"))
        }
        return out.sorted()
    }
}
