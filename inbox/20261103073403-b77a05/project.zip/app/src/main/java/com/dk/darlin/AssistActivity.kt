package com.dk.darlin

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.dk.darlin.core.ScreenContext
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.ui.AssistantPanel

/**
 * Запасной способ вызова (ACTION_ASSIST / VOICE_COMMAND, плитка, ярлык):
 * та же нижняя панель поверх текущего экрана.
 */
class AssistActivity : AppCompatActivity() {
    private lateinit var panel: AssistantPanel
    private var screen: ScreenContext? = null

    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) panel.listen()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Снимаем текст экрана до того, как наше окно станет активным
        screen = DarlinAccessibilityService.instance?.let { ScreenContext(it.screenText(), null, null) }
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        panel = AssistantPanel(this, AssistantPanel.Mode.OVERLAY, object : AssistantPanel.Host {
            override fun close() { finish() }
            override fun launch(intent: Intent): Boolean = try { startActivity(intent); true } catch (e: Exception) { false }
            override fun openApp() { startActivity(Intent(this@AssistActivity, MainActivity::class.java)); finish() }
        })
        setContentView(panel.root)
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })
    }

    override fun onResume() {
        super.onResume()
        panel.onShown(screen)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onPause() {
        panel.onHidden()
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) finish()
    }

    override fun onDestroy() {
        panel.destroy()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(0, android.R.anim.fade_out)
    }
}
