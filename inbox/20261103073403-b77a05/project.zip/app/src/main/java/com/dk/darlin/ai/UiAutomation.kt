package com.dk.darlin.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.dk.darlin.core.Background
import com.dk.darlin.sys.DarlinAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Управление другими приложениями через службу спец. возможностей:
 * отправка сообщений в WhatsApp с подтверждением и универсальный цикл
 * «посмотреть экран → нажать/ввести → посмотреть снова» для любых приложений.
 */
class UiAutomation(private val exec: ToolExecutor) {
    private val ctx get() = exec.appContext

    data class PendingSend(val pkg: String, val app: String, val who: String, val number: String, val text: String, val chatUri: Uri)

    companion object {
        /** Подготовленное, но ещё не отправленное сообщение (живёт между сессиями панели). */
        @Volatile var pending: PendingSend? = null
        private val WA = listOf("com.whatsapp", "com.whatsapp.w4b")
        private val SEND_LABELS = arrayOf("Отправить", "Send", "Надіслати", "Senden", "Enviar", "Envoyer")
    }

    private fun svc() = DarlinAccessibilityService.instance
    private fun noService() = "Служба специальных возможностей «Дарлин» выключена, поэтому я не могу нажимать на экране. " +
        "Включите её: приложение Дарлин → «Настройка» → «Управление экраном»."

    private fun installed(pkg: String) = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }

    private suspend fun <T> main(block: suspend () -> T): T = withContext(Dispatchers.Main) { block() }

    private suspend fun look(): String = main { svc()?.snapshot() ?: noService() }

    /** Ждём, пока экран «успокоится», и возвращаем свежее дерево элементов. */
    private suspend fun settle(prefix: String, ms: Long = 900): String {
        delay(ms)
        return prefix + "\n\nЭкран после действия:\n" + look()
    }

    private suspend fun waitFor(timeoutMs: Long, cond: (DarlinAccessibilityService) -> Boolean): Boolean {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            val s = svc() ?: return false
            if (main { try { cond(s) } catch (_: Exception) { false } }) return true
            delay(300)
        }
        return false
    }

    // ---------- Универсальные действия ----------
    suspend fun afterLaunch(result: String): String {
        val s = svc() ?: return "$result\n(${noService()})"
        exec.minimize()
        waitFor(5000) { it.foregroundPackage() != null && it.foregroundPackage() != ctx.packageName && !it.foregroundPackage()!!.contains("launcher") }
        delay(900)
        return "$result\n\nЭкран:\n" + main { s.snapshot() }
    }

    suspend fun snapshotTool(): String {
        if (svc() == null) return noService()
        exec.uiTask = true
        exec.minimize()
        delay(350)
        return look()
    }

    suspend fun click(index: Int?, text: String, long: Boolean): String {
        val s = svc() ?: return noService()
        exec.uiTask = true
        exec.minimize()
        delay(250)
        val ok = main {
            when {
                index != null -> s.clickIndex(index, long)
                text.isNotBlank() -> s.clickText(text) || run {
                    // нет кликабельного элемента — тапаем по координатам найденного текста
                    val q = text.lowercase()
                    val n = s.roots().firstNotNullOfOrNull { r ->
                        s.find(r, { it.isVisibleToUser && ((it.text?.toString()?.lowercase()?.contains(q) == true) || (it.contentDescription?.toString()?.lowercase()?.contains(q) == true)) })
                    }
                    if (n == null) false else { val rc = android.graphics.Rect(); n.getBoundsInScreen(rc); s.tap(rc.exactCenterX(), rc.exactCenterY()) }
                }
                else -> false
            }
        }
        val what = if (index != null) "элемент [$index]" else "«$text»"
        return settle(if (ok) "Нажала $what" else "Не получилось нажать $what — элемент не найден. Сверься с новым деревом.")
    }

    suspend fun type(index: Int?, text: String, enter: Boolean): String {
        val s = svc() ?: return noService()
        exec.uiTask = true
        exec.minimize()
        delay(200)
        val ok = main {
            val r = s.setText(index, text)
            if (r && enter && Build.VERSION.SDK_INT >= 30) {
                val n = (if (index != null) s.node(index) else null)
                    ?: s.roots().firstNotNullOfOrNull { it.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }
                n?.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            }
            r
        }
        return settle(if (ok) "Ввела текст «${text.take(60)}»" else "Не нашла поле ввода — сначала нажми на нужное поле.")
    }

    suspend fun scroll(index: Int?, direction: String): String {
        val s = svc() ?: return noService()
        exec.uiTask = true
        exec.minimize()
        val forward = direction != "up"
        val ok = main { s.scrollIndex(index, forward) || s.swipe(forward) }
        return settle(if (ok) "Прокрутила ${if (forward) "вниз" else "вверх"}" else "Прокрутить не получилось", 700)
    }

    suspend fun back(): String {
        val s = svc() ?: return noService()
        exec.uiTask = true
        exec.minimize()
        main { s.global("back") }
        return settle("Нажала «Назад»", 700)
    }

    suspend fun waitTool(sec: Int): String {
        delay(sec.coerceIn(1, 10) * 1000L)
        return "Подождала.\n\nЭкран:\n" + look()
    }

    // ---------- Сообщения ----------
    private fun normalizePhone(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.length == 11 && d.startsWith("8")) d = "7" + d.substring(1)
        if (d.length == 10 && d.startsWith("9")) d = "7$d"
        return d
    }

    private fun suggestContacts(name: String): String {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return ""
        val stem = name.trim().take(3)
        if (stem.isEmpty()) return ""
        val out = LinkedHashSet<String>()
        ctx.contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$stem%"), null
        )?.use { while (it.moveToNext() && out.size < 8) out.add(it.getString(0)) }
        return if (out.isEmpty()) "" else " Похожие контакты: ${out.joinToString(", ")}."
    }

    suspend fun sendMessage(appRaw: String, contact: String, text: String): String {
        val app = appRaw.lowercase().let {
            when {
                it.contains("busin") || it.contains("бизнес") -> "whatsapp_business"
                it.contains("whats") || it.contains("вотс") || it.contains("ватс") || it.contains("вацап") || it.isBlank() -> "whatsapp"
                it.contains("sms") || it.contains("смс") || it.contains("сообщени") -> "sms"
                it.contains("teleg") || it.contains("телег") -> "telegram"
                else -> it
            }
        }
        if (app == "sms") return exec.run("send_sms", JSONObject().put("target", contact).put("text", text))
        if (app != "whatsapp" && app != "whatsapp_business") {
            return "Для «$appRaw» нет прямой ссылки на чат. Сделай это по шагам: open_app с and_look=true, затем найди чат через поиск (ui_click/ui_type), " +
                "введи текст в поле сообщения и ПЕРЕД нажатием кнопки отправки спроси пользователя подтверждение."
        }
        val pkg = (if (app == "whatsapp_business") WA.reversed() else WA).firstOrNull { installed(it) }
            ?: return "WhatsApp не установлен на телефоне."
        val (who, number) = exec.lookupNumber(contact)
            ?: return if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                "Нет доступа к контактам — выдайте разрешение в приложении Дарлин → «Настройка»."
            else "Контакт «$contact» не найден.${suggestContacts(contact)} Уточни у пользователя, кому писать."
        val phone = normalizePhone(number)
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=" + Uri.encode(text))
        val intent = Intent(Intent.ACTION_VIEW, uri).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!exec.start(intent)) return "Не удалось открыть WhatsApp."
        val s = svc()
        if (s == null) {
            pending = null
            return "Открыла чат WhatsApp с $who ($number), текст «$text» уже в поле. Служба спец. возможностей выключена, " +
                "поэтому нажать «Отправить» пользователь должен сам — скажи ему об этом."
        }
        val p = PendingSend(pkg, "WhatsApp", who, number, text, uri)
        pending = p
        exec.keepOpen = true
        waitFor(8000) { it.findById("$pkg:id/entry") != null || it.findById("$pkg:id/send") != null }
        main {
            s.showCard("Отправить $who: «${text.take(60)}»?", "Отправить", {
                Background.current = Background.scope.launch {
                    val r = confirmSend()
                    Background.deliver(ctx, r, speak = true)
                }
            }, "Отмена") { pending = null }
        }
        return "Открыла чат WhatsApp с $who ($number), текст «$text» вставлен, но ещё НЕ отправлен. " +
            "Коротко спроси пользователя: «Отправить $who сообщение «$text»?» и вызови confirm_send только после явного «да». " +
            "Пользователь также может нажать «Отправить» на карточке вверху экрана."
    }

    suspend fun cancelSend(): String {
        pending = null
        exec.keepOpen = false
        main { svc()?.hideCard() }
        return "Отправка отменена, текст остался в поле чата."
    }

    suspend fun confirmSend(): String {
        val p = pending ?: return "Нет подготовленного сообщения. Сначала вызови send_message."
        val s = svc() ?: return noService()
        exec.keepOpen = false
        exec.minimize()
        main { s.hideCard() }
        delay(400)
        // Убеждаемся, что открыт нужный чат
        if (main { s.foregroundPackage() } != p.pkg) {
            exec.start(Intent(Intent.ACTION_VIEW, p.chatUri).setPackage(p.pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            waitFor(8000) { it.foregroundPackage() == p.pkg }
        }
        var clicked = false
        for (attempt in 0 until 12) {
            clicked = main {
                val node = s.findById("${p.pkg}:id/send") ?: s.findByDescription(*SEND_LABELS)
                if (node == null) false
                else if (s.click(node)) true
                else { val r = android.graphics.Rect(); node.getBoundsInScreen(r); s.tap(r.exactCenterX(), r.exactCenterY()) }
            }
            if (clicked) break
            delay(500)
        }
        if (!clicked) {
            Background.hideWorking()
            return "Не нашла кнопку «Отправить» в WhatsApp — чат открыт, текст в поле. Попроси пользователя нажать её."
        }
        delay(1000)
        val stillThere = main {
            val e = s.findById("${p.pkg}:id/entry")
            e != null && e.text?.toString()?.trim() == p.text.trim()
        }
        pending = null
        Background.hideWorking()
        return if (stillThere) "Нажала «Отправить», но текст всё ещё в поле — возможно, нет сети. Проверьте чат."
        else "Сообщение «${p.text}» отправлено ${p.who} в ${p.app}."
    }
}
