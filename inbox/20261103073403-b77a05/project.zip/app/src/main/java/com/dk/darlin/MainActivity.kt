package com.dk.darlin

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.dk.darlin.core.CrashLog
import com.dk.darlin.core.Prefs
import com.dk.darlin.ui.AssistantPanel
import com.dk.darlin.ui.SettingsPage
import com.dk.darlin.ui.SetupPage
import com.dk.darlin.ui.Ui
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private lateinit var chat: AssistantPanel
    private lateinit var setup: SetupPage
    private lateinit var settings: SettingsPage
    private lateinit var container: FrameLayout
    private lateinit var nav: BottomNavigationView
    private var current = R.id.nav_chat

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { setup.refresh() }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (!setup.isAssistant()) setup.openAssistantSettingsDirect()
        setup.refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        container = FrameLayout(this)
        root.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        nav = BottomNavigationView(this)
        nav.inflateMenu(R.menu.main_nav)
        nav.setBackgroundColor(0xFF10131F.toInt())
        root.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val imeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, if (imeVisible) ime.bottom else 0)
            nav.visibility = if (imeVisible) View.GONE else View.VISIBLE
            nav.setPadding(0, 0, 0, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        chat = AssistantPanel(this, AssistantPanel.Mode.FULL, object : AssistantPanel.Host {
            override fun close() {}
            override fun launch(intent: Intent): Boolean = try { startActivity(intent); true } catch (e: Exception) { false }
            override fun openApp() { select(R.id.nav_setup) }
            override fun minimize() { moveTaskToBack(true) }
        })
        setup = SetupPage(this, { permLauncher.launch(it) }, { roleLauncher.launch(it) })
        settings = SettingsPage(this) { chat.refresh() }

        // ВАЖНО: слушатель только показывает страницу. Раньше select() внутри слушателя снова
        // выставлял nav.selectedItemId → слушатель вызывался рекурсивно → StackOverflowError (вылет на любой вкладке).
        nav.setOnItemSelectedListener { item ->
            try { show(item.itemId) } catch (e: Throwable) { CrashLog.report(this, e, "Переключение вкладки") }
            true
        }
        val start = when {
            intent?.getStringExtra("page") == "settings" -> R.id.nav_settings
            !Prefs.bool(this, Prefs.ONBOARDED, false) && !setup.allDone() -> R.id.nav_setup
            else -> R.id.nav_chat
        }
        Prefs.setBool(this, Prefs.ONBOARDED, true)
        nav.selectedItemId = start
        show(start)
        showCrashLogIfAny()
    }

    /** Программное переключение вкладки (из кода, не из слушателя). */
    private fun select(id: Int) {
        if (nav.selectedItemId != id) nav.selectedItemId = id // вызовет слушатель → show()
        else show(id)
    }

    private fun show(id: Int) {
        if (selecting) return
        selecting = true
        try { showInner(id) } finally { selecting = false }
    }
    private var selecting = false

    private fun showInner(id: Int) {
        current = id
        container.removeAllViews()
        val v = when (id) {
            R.id.nav_setup -> setup.view.also { setup.refresh() }
            R.id.nav_settings -> settings.view.also { settings.bind() }
            else -> chat.root
        }
        (v.parent as? ViewGroup)?.removeView(v)
        container.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun showCrashLogIfAny() {
        if (!CrashLog.hasUnseen(this)) return
        val text = CrashLog.read(this) ?: return
        CrashLog.markSeen(this)
        val tv = android.widget.TextView(this).apply {
            this.text = text.takeLast(6000); textSize = 11f; setTextIsSelectable(true)
            typeface = android.graphics.Typeface.MONOSPACE
            val p = Ui.dp(this@MainActivity, 16); setPadding(p, p / 2, p, 0)
        }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Дарлин в прошлый раз завершилась с ошибкой")
            .setView(android.widget.ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Копировать") { _, _ ->
                CrashLog.guard(this, "Копирование журнала") {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Журнал Дарлин", text))
                    android.widget.Toast.makeText(this, "Журнал скопирован", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
            .setNeutralButton("Очистить") { _, _ -> CrashLog.clear(this) }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        chat.onShown(null)
        if (current == R.id.nav_setup) setup.refresh()
    }

    override fun onPause() {
        chat.onHidden()
        super.onPause()
    }

    override fun onDestroy() {
        chat.destroy()
        settings.destroy()
        super.onDestroy()
    }
}
