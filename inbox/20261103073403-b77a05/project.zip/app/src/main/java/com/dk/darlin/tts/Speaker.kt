package com.dk.darlin.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.dk.darlin.core.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Озвучка ответов: по умолчанию нейроголоса Microsoft Edge,
 * при любой ошибке/без интернета — системный TextToSpeech.
 */
class Speaker(context: Context) {
    private val ctx = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main + com.dk.darlin.core.CrashLog.globalHandler)
    private var job: Job? = null
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val pendingTts = ArrayList<Pair<String, () -> Unit>>()
    @Volatile private var systemDone: (() -> Unit)? = null

    var isSpeaking = false
        private set

    /** Говорит текст; onDone вызывается в главном потоке (и при остановке). */
    fun speak(text: String, voiceOverride: String? = null, onDone: () -> Unit = {}) {
        stop()
        val clean = cleanForSpeech(text)
        if (clean.isBlank()) { onDone(); return }
        isSpeaking = true
        val finish: () -> Unit = {
            if (isSpeaking) { isSpeaking = false; onDone() }
        }
        if (Prefs.voiceEngine(ctx) == "system" && voiceOverride == null) {
            speakSystem(clean, finish); return
        }
        val voice = voiceOverride ?: Prefs.edgeVoice(ctx)
        val rate = Prefs.rate(ctx)
        val pitch = Prefs.pitch(ctx)
        val chunks = splitChunks(clean)
        job = scope.launch {
            val files = Channel<File?>(2)
            val producer = launch(Dispatchers.IO) {
                for ((i, c) in chunks.withIndex()) {
                    try {
                        val bytes = EdgeTts.synthesize(c, voice, rate, pitch)
                        val f = File(ctx.cacheDir, "tts_${System.nanoTime()}_$i.mp3")
                        f.writeBytes(bytes)
                        files.send(f)
                    } catch (e: Exception) {
                        files.send(null) // сигнал: дальше системным голосом
                        withContext(Dispatchers.Main) { lastError = e.message }
                        files.close()
                        return@launch
                    }
                }
                files.close()
            }
            var index = 0
            for (f in files) {
                if (f == null) {
                    producer.cancel()
                    val rest = chunks.drop(index).joinToString(" ")
                    speakSystem(rest, finish)
                    return@launch
                }
                playFile(f)
                f.delete()
                index++
            }
            finish()
        }
    }

    var lastError: String? = null
        private set

    private suspend fun playFile(f: File) = suspendCancellableCoroutine<Unit> { cont ->
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                it.release(); if (player === it) player = null
                if (cont.isActive) cont.resume(Unit)
            }
            mp.setOnErrorListener { p, _, _ ->
                p.release(); if (player === p) player = null
                if (cont.isActive) cont.resume(Unit)
                true
            }
            mp.prepare()
            mp.start()
            cont.invokeOnCancellation {
                main.post { try { mp.stop(); mp.release() } catch (_: Exception) {} }
            }
        } catch (e: Exception) {
            if (cont.isActive) cont.resume(Unit)
        }
    }

    private fun speakSystem(text: String, onDone: () -> Unit) {
        val t = tts
        if (t == null) {
            pendingTts.add(text to onDone)
            tts = TextToSpeech(ctx) { status ->
                main.post {
                    ttsReady = status == TextToSpeech.SUCCESS
                    if (ttsReady) {
                        tts?.language = Locale("ru", "RU")
                        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                if (utteranceId == "last") main.post { systemDone?.invoke(); systemDone = null }
                            }
                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                main.post { systemDone?.invoke(); systemDone = null }
                            }
                        })
                    }
                    val list = ArrayList(pendingTts); pendingTts.clear()
                    for ((tx, cb) in list) if (ttsReady) speakSystemNow(tx, cb) else cb()
                }
            }
            return
        }
        if (!ttsReady) { pendingTts.add(text to onDone); return }
        speakSystemNow(text, onDone)
    }

    private fun speakSystemNow(text: String, onDone: () -> Unit) {
        val t = tts ?: return onDone()
        systemDone = onDone
        t.setSpeechRate(1f + Prefs.rate(ctx) / 100f)
        t.setPitch(1f + Prefs.pitch(ctx) / 100f)
        val parts = splitChunks(text, 3500)
        parts.forEachIndexed { i, p ->
            t.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(),
                if (i == parts.lastIndex) "last" else "p$i")
        }
    }

    fun stop() {
        job?.cancel(); job = null
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        tts?.stop()
        pendingTts.clear()
        systemDone = null
        isSpeaking = false
    }

    fun shutdown() {
        stop()
        tts?.shutdown(); tts = null
        scope.cancel()
    }

    companion object {
        fun cleanForSpeech(s: String): String = s
            .replace(Regex("```[\\s\\S]*?```"), " (код на экране) ")
            .replace(Regex("\\[([^\\]]+)]\\([^)]+\\)"), "$1")
            .replace(Regex("https?://\\S+"), " ссылка ")
            .replace(Regex("[*_#`>|]+"), "")
            .replace(Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE), "")
            .replace(Regex("\\s+"), " ")
            .trim()

        fun splitChunks(s: String, max: Int = 400): List<String> {
            val out = ArrayList<String>()
            val sentences = s.split(Regex("(?<=[.!?…])\\s+"))
            val sb = StringBuilder()
            for (sent in sentences) {
                var x = sent
                while (x.length > max) {
                    if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                    val cut = x.lastIndexOf(' ', max).let { if (it < max / 2) max else it }
                    out.add(x.substring(0, cut)); x = x.substring(cut).trim()
                }
                // Первый кусок короткий — чтобы звук начинался быстрее.
                val limit = if (out.isEmpty()) 160 else max
                if (sb.length + x.length + 1 > limit && sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(x)
            }
            if (sb.isNotBlank()) out.add(sb.toString())
            return out.filter { it.isNotBlank() }
        }
    }
}
