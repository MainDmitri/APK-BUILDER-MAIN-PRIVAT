package com.dk.darlin.ai

import org.json.JSONArray
import org.json.JSONObject

/** Описания функций (tools) для модели в формате OpenAI. */
object ToolSpecs {
    private class P(val name: String, val type: String, val desc: String, val required: Boolean = true, val enum: List<String>? = null)

    private fun fn(name: String, desc: String, vararg params: P): JSONObject {
        val props = JSONObject()
        val req = JSONArray()
        for (p in params) {
            val o = JSONObject().put("type", p.type).put("description", p.desc)
            if (p.enum != null) o.put("enum", JSONArray(p.enum))
            props.put(p.name, o)
            if (p.required) req.put(p.name)
        }
        val schema = JSONObject().put("type", "object").put("properties", props)
        if (req.length() > 0) schema.put("required", req)
        return JSONObject().put("type", "function").put(
            "function", JSONObject().put("name", name).put("description", desc).put("parameters", schema)
        )
    }

    private fun s(n: String, d: String, req: Boolean = true, enum: List<String>? = null) = P(n, "string", d, req, enum)
    private fun i(n: String, d: String, req: Boolean = true) = P(n, "integer", d, req)
    private fun b(n: String, d: String, req: Boolean = true) = P(n, "boolean", d, req)

    val all: JSONArray by lazy {
        JSONArray(
            listOf(
                fn("open_app", "Открыть установленное приложение по названию (например «Телеграм», «YouTube», «Камера»).", s("name", "Название приложения"),
                    b("and_look", "true, если дальше нужно действовать внутри приложения: панель свернётся и вернётся дерево элементов экрана", false)),
                fn("send_message", "Написать сообщение контакту в мессенджере. Для WhatsApp открывает чат с контактом и вставляет текст (ещё НЕ отправляет). " +
                    "После этого обязательно спроси у пользователя подтверждение и только потом вызови confirm_send.",
                    s("app", "whatsapp, whatsapp_business, sms или другое приложение"), s("contact", "Имя контакта (как в телефонной книге) или номер"), s("text", "Текст сообщения")),
                fn("confirm_send", "Отправить подготовленное send_message сообщение (нажимает кнопку «Отправить»). Только после явного согласия пользователя!"),
                fn("cancel_send", "Отменить подготовленную отправку сообщения."),
                fn("ui_snapshot", "Посмотреть текущий экран другого приложения: пронумерованный список элементов [N] с текстом, id и свойствами (click/edit/scroll). " +
                    "Панель ассистента сворачивается. Нужна служба спец. возможностей."),
                fn("ui_click", "Нажать на элемент экрана по номеру [N] из последнего дерева (предпочтительно) или по видимому тексту. Возвращает новое дерево.",
                    i("index", "Номер элемента из дерева", false), s("text", "Текст/описание элемента, если номер неизвестен", false), b("long", "Долгое нажатие", false)),
                fn("ui_type", "Ввести текст в поле ввода (по номеру из дерева или в активное поле). Возвращает новое дерево.",
                    s("text", "Текст"), i("index", "Номер поля из дерева", false), b("press_enter", "Нажать Enter/поиск после ввода", false)),
                fn("ui_scroll", "Прокрутить список/экран. Возвращает новое дерево.", s("direction", "Направление", true, listOf("down", "up")), i("index", "Номер прокручиваемого элемента", false)),
                fn("ui_back", "Нажать системную кнопку «Назад». Возвращает новое дерево."),
                fn("ui_wait", "Подождать загрузку экрана и вернуть новое дерево.", i("seconds", "1–10 секунд", false)),
                fn("list_apps", "Список установленных приложений (названия).", s("filter", "Необязательный фильтр по названию", false)),
                fn("call_phone", "Позвонить по номеру или контакту из телефонной книги.", s("target", "Номер телефона или имя контакта")),
                fn("send_sms", "Открыть окно отправки SMS с готовым текстом (пользователь нажмёт «Отправить»).", s("target", "Номер или имя контакта"), s("text", "Текст сообщения")),
                fn("find_contact", "Найти контакт и его номера телефонов.", s("name", "Имя или часть имени")),
                fn("read_sms", "Прочитать последние входящие SMS.", i("count", "Сколько сообщений (до 20)", false), s("from", "Фильтр по отправителю", false)),
                fn("send_email", "Открыть письмо в почтовом приложении.", s("to", "Адрес"), s("subject", "Тема", false), s("body", "Текст", false)),
                fn("share_text", "Поделиться текстом или отправить его в мессенджер.", s("text", "Текст"), s("app", "Куда: telegram, whatsapp, vk или пусто для выбора", false)),
                fn("set_alarm", "Поставить будильник.", i("hour", "Час 0-23"), i("minute", "Минуты 0-59"), s("label", "Подпись", false)),
                fn("set_timer", "Запустить таймер.", i("seconds", "Длительность в секундах"), s("label", "Подпись", false)),
                fn("show_alarms", "Показать список будильников."),
                fn("add_calendar_event", "Создать событие в календаре (откроется окно подтверждения).",
                    s("title", "Название"), s("start", "Начало в формате yyyy-MM-dd HH:mm"), s("end", "Конец yyyy-MM-dd HH:mm", false),
                    s("location", "Место", false), s("description", "Описание", false), b("all_day", "Весь день", false)),
                fn("list_calendar_events", "События календаря на ближайшие дни.", i("days", "Сколько дней вперёд (по умолчанию 1)", false)),
                fn("set_reminder", "Поставить напоминание с уведомлением. Укажи либо in_minutes, либо datetime.",
                    s("text", "О чём напомнить"), i("in_minutes", "Через сколько минут", false), s("datetime", "Когда: yyyy-MM-dd HH:mm", false)),
                fn("list_reminders", "Список активных напоминаний."),
                fn("cancel_reminder", "Удалить напоминание по id.", i("id", "id напоминания")),
                fn("add_note", "Сохранить заметку.", s("text", "Текст заметки")),
                fn("list_notes", "Показать заметки (можно с поиском).", s("query", "Поиск", false)),
                fn("delete_note", "Удалить заметку по id.", i("id", "id заметки")),
                fn("flashlight", "Включить или выключить фонарик.", b("on", "true — включить, false — выключить")),
                fn("set_volume", "Изменить громкость.", s("stream", "Поток", false, listOf("media", "ring", "alarm", "notification", "call")),
                    i("percent", "Уровень 0-100", false), s("direction", "up, down, mute, unmute", false, listOf("up", "down", "mute", "unmute"))),
                fn("media_control", "Управление воспроизведением музыки/видео.", s("action", "Действие", true, listOf("play", "pause", "toggle", "next", "previous"))),
                fn("play_music", "Найти и включить музыку/исполнителя/трек.", s("query", "Что включить")),
                fn("open_settings", "Открыть раздел настроек телефона.", s("page", "Раздел", true,
                    listOf("wifi", "bluetooth", "internet", "mobile_data", "airplane", "display", "sound", "volume_panel", "battery", "apps", "location",
                        "accessibility", "notifications", "storage", "about", "nfc", "date", "language", "security", "assistant", "dnd", "default_apps", "main"))),
                fn("web_search", "Поиск в интернете: возвращает заголовки, ссылки и фрагменты результатов, чтобы ответить пользователю.", s("query", "Запрос")),
                fn("fetch_url", "Загрузить веб-страницу и вернуть её текст.", s("url", "Адрес https://…")),
                fn("open_url", "Открыть ссылку или поисковый запрос в браузере.", s("url_or_query", "Ссылка или запрос")),
                fn("navigate", "Построить маршрут или показать место на карте.", s("destination", "Куда"),
                    s("mode", "Способ", false, listOf("drive", "walk", "transit", "bike", "show"))),
                fn("device_info", "Сведения об устройстве: заряд батареи, память, накопитель, сеть, модель, версия Android."),
                fn("clipboard_get", "Прочитать буфер обмена."),
                fn("clipboard_set", "Скопировать текст в буфер обмена.", s("text", "Текст")),
                fn("get_screen_text", "Получить текст, который сейчас виден на экране."),
                fn("global_action", "Системное действие (нужна служба специальных возможностей).", s("action", "Действие", true,
                    listOf("back", "home", "recents", "notifications", "quick_settings", "screenshot", "lock_screen", "power_dialog", "split_screen"))),
                fn("click_on_text", "Нажать на экране на элемент с указанным текстом (нужна служба спец. возможностей).", s("text", "Текст на кнопке/элементе")),
                fn("type_text", "Ввести текст в активное поле ввода на экране (нужна служба спец. возможностей).", s("text", "Текст")),
                fn("scroll_screen", "Прокрутить экран.", s("direction", "Направление", true, listOf("down", "up"))),
                fn("list_files", "Список файлов и папок. Пути относительно внутренней памяти (/storage/emulated/0) или абсолютные.", s("path", "Папка, например Download или DCIM/Camera", false)),
                fn("search_files", "Найти файлы по части имени.", s("name", "Часть имени или расширение, например .pdf"), s("path", "Где искать (по умолчанию вся память)", false)),
                fn("search_in_files", "Найти текст внутри текстовых файлов.", s("text", "Что искать"), s("path", "Где искать", false)),
                fn("read_file", "Прочитать текстовый файл (txt, md, json, csv, код, docx, html…).", s("path", "Путь к файлу"), i("max_chars", "Ограничение символов", false)),
                fn("write_file", "Создать или перезаписать текстовый файл (или дописать в конец).", s("path", "Путь"), s("content", "Содержимое"), b("append", "Дописать в конец", false)),
                fn("make_dir", "Создать папку.", s("path", "Путь")),
                fn("copy_file", "Скопировать файл.", s("from", "Откуда"), s("to", "Куда (файл или папка)")),
                fn("move_file", "Переместить или переименовать файл/папку.", s("from", "Откуда"), s("to", "Куда")),
                fn("delete_file", "Удалить файл или пустую папку. Только по прямой просьбе пользователя!", s("path", "Путь")),
                fn("open_file", "Открыть файл в подходящем приложении.", s("path", "Путь")),
                fn("file_info", "Размер, дата изменения и тип файла.", s("path", "Путь"))
            )
        )
    }
}
