package com.dk.darlin.voice

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Обязательная для цифрового помощника служба распознавания.
 * Когда Дарлин выбрана помощником, Android может сделать её распознавателем по умолчанию,
 * поэтому она не «глушит» голосовой ввод, а пересылает его системному распознавателю (Google и т.п.).
 */
class DarlinRecognitionService : RecognitionService() {
    private var delegate: SpeechRecognizer? = null

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        val cb = listener ?: return
        delegate?.destroy()
        val comp = VoiceInput.findRecognizer(this)
        if (comp == null) { try { cb.error(SpeechRecognizer.ERROR_CLIENT) } catch (_: Exception) {}; return }
        val sr = SpeechRecognizer.createSpeechRecognizer(this, comp)
        delegate = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = safe { cb.readyForSpeech(params ?: Bundle()) }
            override fun onBeginningOfSpeech() = safe { cb.beginningOfSpeech() }
            override fun onRmsChanged(rmsdB: Float) = safe { cb.rmsChanged(rmsdB) }
            override fun onBufferReceived(buffer: ByteArray?) = safe { if (buffer != null) cb.bufferReceived(buffer) }
            override fun onEndOfSpeech() = safe { cb.endOfSpeech() }
            override fun onError(error: Int) = safe { cb.error(error) }
            override fun onResults(results: Bundle?) = safe { cb.results(results ?: Bundle()) }
            override fun onPartialResults(partialResults: Bundle?) = safe { cb.partialResults(partialResults ?: Bundle()) }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        sr.startListening(recognizerIntent ?: Intent())
    }

    private inline fun safe(block: () -> Unit) { try { block() } catch (_: Exception) {} }

    override fun onStopListening(listener: Callback?) { delegate?.stopListening() }

    override fun onCancel(listener: Callback?) { delegate?.cancel() }

    override fun onDestroy() { delegate?.destroy(); delegate = null; super.onDestroy() }
}
