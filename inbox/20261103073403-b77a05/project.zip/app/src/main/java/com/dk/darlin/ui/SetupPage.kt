package com.dk.darlin.ui

import com.dk.darlin.core.safeClick
import com.dk.darlin.core.safeLongClick
import android.Manifest
import android.app.AlarmManager
import android.app.StatusBarManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.service.voice.VoiceInteractionService
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.dk.darlin.AssistActivity
import com.dk.darlin.R
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.sys.DarlinTileService
import com.dk.darlin.voice.DarlinInteractionService
import com.google.android.material.button.MaterialButton

/** Экран «Настройка»: пошаговая выдача разрешений и выбор Дарлин цифровым помощником. */
class SetupPage(
    private val act: AppCompatActivity,
    private val requestPerms: (Array<String>) -> Unit,
    private val requestRole: (Intent) -> Unit
) {
    val view = ScrollView(act)
    private val col = LinearLayout(act)
    private val refreshers = ArrayList<() -> Unit>()
    private fun d(v: Int) = Ui.dp(act, v)

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(8), d(16), d(24))
        view.addView(col)
        view.isVerticalScrollBarEnabled = false

        col.addView(Ui.text(act, "Настройка Дарлин", 26f, Ui.TEXT, true))
        col.addView(Ui.text(act, "Пройдите шаги ниже — и Дарлин заменит Google Ассистента: будет вызываться долгим нажатием кнопки питания, свайпом из угла экрана или удержанием кнопки «Домой».", 14.5f, Ui.TEXT2).apply {
            setPadding(0, d(6), 0, d(14))
        })

        step("1. Микрофон", "Чтобы слышать ваши команды.", { granted(Manifest.permission.RECORD_AUDIO) }, "Разрешить") {
            requestPerms(arrayOf(Manifest.permission.RECORD_AUDIO))
        }

        step(
            "2. Сделать Дарлин цифровым помощником",
            "Откроется системный выбор. Выберите «Дарлин» в пункте «Цифровой помощник» (или «Помощник и голосовой ввод»). " +
                "Затем нажмите на шестерёнку рядом и включите «Анализировать текст на экране» и «Использовать скриншот» — так Дарлин поймёт, что у вас на экране.",
            { isAssistant() }, "Выбрать"
        ) { openAssistantSettings() }

        info(
            "Вызов кнопкой питания",
            "Android 12+ (Pixel и большинство телефонов): Настройки → Система → Жесты → «Нажатие и удержание кнопки питания» → «Цифровой помощник».\n" +
                "Samsung: Настройки → Дополнительные функции → Боковая клавиша → «Нажатие и удержание» → «Активация цифрового помощника».\n" +
                "Xiaomi/HyperOS: Настройки → Расширенные настройки → Кнопки и жесты → «Запуск Ассистента» → удержание кнопки питания.\n" +
                "Также работает свайп из нижнего угла экрана и удержание кнопки «Домой» (если включена 3-кнопочная навигация).",
            "Открыть жесты"
        ) { open(Intent("android.settings.GESTURE_SETTINGS"), Intent(Settings.ACTION_SETTINGS)) }

        step("3. Доступ ко всем файлам", "Чтобы Дарлин могла искать, читать и создавать ваши файлы по команде.", { filesAccess() }, "Разрешить") {
            if (Build.VERSION.SDK_INT >= 30) {
                open(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName)),
                    Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                )
            } else requestPerms(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }

        step("4. Контакты и звонки", "«Позвони маме», «Найди номер Ивана».", {
            granted(Manifest.permission.READ_CONTACTS) && granted(Manifest.permission.CALL_PHONE)
        }, "Разрешить") { requestPerms(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)) }

        step("5. SMS и календарь", "Прочитать последние SMS, рассказать о планах на день.", {
            granted(Manifest.permission.READ_SMS) && granted(Manifest.permission.READ_CALENDAR)
        }, "Разрешить") { requestPerms(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.READ_CALENDAR)) }

        step("6. Уведомления и точные напоминания", "Чтобы напоминания приходили вовремя.", {
            (Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS)) && exactAlarms()
        }, "Разрешить") {
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) requestPerms(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
            else if (Build.VERSION.SDK_INT >= 31 && !exactAlarms()) open(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + act.packageName)))
        }

        step(
            "7. Управление экраном (для WhatsApp и других приложений)",
            "Служба специальных возможностей позволяет Дарлин по вашей команде читать экран, нажимать кнопки, вводить текст и прокручивать — " +
                "так она отправляет сообщения в WhatsApp (после вашего «да») и выполняет задачи в любых приложениях. " +
                "Дарлин использует её только когда вы просите, ничего не собирает и не отправляет сама; во время работы вверху экрана видна карточка с кнопкой «Стоп». " +
                "Текст экрана уходит выбранному вами ИИ-сервису только вместе с вашим вопросом.\n" +
                "Android 13+: если переключатель серый — откройте «О приложении» Дарлин → ⋮ → «Разрешить ограниченные настройки».",
            { DarlinAccessibilityService.instance != null }, "Включить"
        ) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        val extra = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        extra.addView(button("О приложении") {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName)))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = d(8) })
        if (Build.VERSION.SDK_INT >= 33) {
            extra.addView(button("Плитка в шторку") { addTile() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        col.addView(extra, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(4) })

        col.addView(MaterialButton(act).apply {
            text = "Проверить ассистента"
            textSize = 16f
            safeClick { testAssistant() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(56)).apply { topMargin = d(14) })
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(act, p) == PackageManager.PERMISSION_GRANTED

    private fun filesAccess() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)

    private fun exactAlarms() = Build.VERSION.SDK_INT < 31 || (act.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()

    fun isAssistant(): Boolean {
        if (VoiceInteractionService.isActiveService(act, ComponentName(act, DarlinInteractionService::class.java))) return true
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = act.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT) && rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)) return true
        }
        return false
    }

    fun openAssistantSettings() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = act.getSystemService(RoleManager::class.java)
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_ASSISTANT) && !rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
                try { requestRole(rm.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)); return } catch (_: Exception) {}
            }
        }
        openAssistantSettingsDirect()
    }

    fun openAssistantSettingsDirect() {
        open(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS), Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        Toast.makeText(act, "Выберите «Дарлин» в пункте «Цифровой помощник»", Toast.LENGTH_LONG).show()
    }

    private fun addTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            val sbm = act.getSystemService(StatusBarManager::class.java)
            sbm?.requestAddTileService(
                ComponentName(act, DarlinTileService::class.java), "Дарлин",
                Icon.createWithResource(act, R.drawable.ic_darlin_small), act.mainExecutor
            ) { }
        }
    }

    private fun testAssistant() {
        val svc = DarlinInteractionService.instance
        if (svc != null) svc.showSession(Bundle(), 0)
        else act.startActivity(Intent(act, AssistActivity::class.java))
    }

    private fun open(vararg intents: Intent) {
        for (i in intents) {
            try { act.startActivity(i); return } catch (_: Exception) {}
        }
        Toast.makeText(act, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
    }

    private fun button(label: String, onClick: () -> Unit) = MaterialButton(act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
        text = label; safeClick { onClick() }
    }

    private fun card(): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.round(act, Ui.SURFACE, 20f, 0x1AFFFFFF)
        setPadding(d(16), d(14), d(16), d(14))
        col.addView(this, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = d(10) })
    }

    private fun step(title: String, desc: String, check: () -> Boolean, action: String, onClick: () -> Unit) {
        val c = card()
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.text(act, title, 16.5f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val badge = Ui.text(act, "", 12.5f, Ui.TEXT, true).apply { setPadding(d(10), d(4), d(10), d(4)) }
        head.addView(badge)
        c.addView(head)
        c.addView(Ui.text(act, desc, 14f, Ui.TEXT2).apply { setPadding(0, d(6), 0, d(8)) })
        val btn = MaterialButton(act).apply { text = action; safeClick { onClick() } }
        c.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val refresh = {
            val ok = try { check() } catch (_: Exception) { false }
            setBadge(badge, ok)
            btn.text = if (ok) "Открыть снова" else action
            btn.alpha = if (ok) 0.6f else 1f
        }
        refreshers.add(refresh)
        refresh()
    }

    private fun info(title: String, desc: String, action: String, onClick: () -> Unit) {
        val c = card()
        c.addView(Ui.text(act, "💡 $title", 16f, Ui.TEXT, true))
        c.addView(Ui.text(act, desc, 13.5f, Ui.TEXT2).apply { setPadding(0, d(6), 0, d(8)) })
        c.addView(button(action, onClick), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun setBadge(b: TextView, ok: Boolean) {
        b.text = if (ok) "✓ Готово" else "Нужно"
        b.setTextColor(if (ok) Ui.OK else Ui.WARN)
        b.background = Ui.round(act, if (ok) 0x2200E676 else 0x22FFB74D, 12f)
    }

    fun refresh() { refreshers.forEach { it() } }

    fun allDone(): Boolean = granted(Manifest.permission.RECORD_AUDIO) && isAssistant()

    @Suppress("unused")
    private fun spacer() = View(act)
}
