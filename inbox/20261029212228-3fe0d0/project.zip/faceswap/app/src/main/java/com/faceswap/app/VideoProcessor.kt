package com.faceswap.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.util.Log
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext

/**
 * Пайплайн обработки видео:
 *  1. FFmpeg: извлечь аудио
 *  2. FFmpeg: разбить видео на кадры PNG
 *  3. Для каждого кадра: детекция → эмбеддинг → замена лица
 *  4. FFmpeg: собрать кадры обратно в видео
 *  5. FFmpeg: смёрджить аудио
 *
 * Ограничение: видео до ~2 минут (лимит ОЗУ и времени).
 */
class VideoProcessor(private val context: Context) {

    private val TAG = "VideoProcessor"

    data class ProcessResult(val outputFile: File)

    /**
     * @param videoFile  — входное видео
     * @param sourceFace — фото донора (оригинальный bitmap)
     * @param onProgress — (0..100) прогресс обработки
     */
    suspend fun process(
        videoFile: File,
        sourceFace: Bitmap,
        onProgress: (Int, String) -> Unit
    ): ProcessResult = withContext(Dispatchers.IO) {

        val workDir = File(context.cacheDir, "faceswap_${System.currentTimeMillis()}")
        workDir.mkdirs()

        val framesDir  = File(workDir, "frames").also { it.mkdirs() }
        val outDir     = File(workDir, "out_frames").also { it.mkdirs() }
        val audioFile  = File(workDir, "audio.aac")
        val outputFile = File(context.getExternalFilesDir(null), "faceswap_result.mp4")

        // --- 0. Получить FPS и разрешение --------------------------------
        onProgress(2, "Анализ видео…")
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(videoFile.absolutePath)
        // METADATA_KEY_VIDEO_FRAME_COUNT + длительность надёжнее CAPTURE_FRAMERATE для обычных видео
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            ?.toLongOrNull() ?: 0L
        val frameCount = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)
            ?.toLongOrNull() ?: 0L
        val fps = if (durationMs > 0 && frameCount > 0)
            (frameCount * 1000f / durationMs).coerceIn(1f, 60f)
        else
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)
                ?.toFloatOrNull()?.coerceIn(1f, 60f) ?: 25f
        val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            ?.toIntOrNull() ?: 1280
        val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            ?.toIntOrNull() ?: 720
        retriever.release()
        Log.d(TAG, "Видео: ${width}x${height} @ $fps fps")

        // --- 1. Извлечь аудио --------------------------------------------
        onProgress(4, "Извлечение аудио…")
        ffmpeg("-y -i \"${videoFile.absolutePath}\" -vn -acodec copy \"${audioFile.absolutePath}\"")

        // --- 2. Извлечь кадры --------------------------------------------
        onProgress(6, "Извлечение кадров…")
        val fpsCapped = fps.coerceAtMost(30f)  // ограничиваем 30 fps для скорости
        ffmpeg(
            "-y -i \"${videoFile.absolutePath}\" " +
            "-vf \"fps=$fpsCapped,scale=${width}:${height}\" " +
            "-qscale:v 2 " +
            "\"${framesDir.absolutePath}/frame_%06d.jpg\""
        )

        val frameFiles = framesDir.listFiles { f -> f.extension == "jpg" }
            ?.sortedBy { it.name } ?: emptyList()

        if (frameFiles.isEmpty()) throw RuntimeException("Кадры не извлечены — проверь видеофайл")
        Log.d(TAG, "Извлечено кадров: ${frameFiles.size}")

        // --- 3. Загрузить AI модели --------------------------------------
        onProgress(10, "Загрузка AI моделей…")
        val modelsDir = ModelManager.modelsDir(context)
        val detector  = FaceDetector(File(modelsDir, "det_10g.onnx").absolutePath)
        val embedder  = FaceEmbedder(File(modelsDir, "w600k_r50.onnx").absolutePath)
        val swapper   = FaceSwapper(File(modelsDir, "inswapper_128.onnx").absolutePath)

        // --- 4. Эмбеддинг донора ----------------------------------------
        onProgress(12, "Анализ лица донора…")
        // detectOrCenter: если детектор не нашёл — берём центр фото как fallback
        val sourceFaces = detector.detectOrCenter(sourceFace)
        val sourceEmbedding = embedder.embed(sourceFace, sourceFaces.first().landmarks)
        Log.d(TAG, "Эмбеддинг донора получен (norm=${sourceEmbedding.sumOf { (it * it).toDouble() }})")

        // --- 5. Обработка кадров ----------------------------------------
        val progressBase = 14
        val progressRange = 75  // 14..89

        for ((idx, frameFile) in frameFiles.withIndex()) {
            if (!coroutineContext.isActive) break

            val pct = progressBase + (idx * progressRange / frameFiles.size)
            if (idx % 5 == 0) {
                onProgress(pct, "Кадр ${idx + 1} / ${frameFiles.size}")
            }

            val frame = BitmapFactory.decodeFile(frameFile.absolutePath)
                ?: continue

            val processedFrame = try {
                val faces = detector.detect(frame)
                if (faces.isNotEmpty()) {
                    swapper.swapFace(frame, faces.first(), sourceEmbedding, embedder)
                } else {
                    frame  // лиц нет — кадр без изменений
                }
            } catch (e: Exception) {
                Log.w(TAG, "Ошибка кадра ${frameFile.name}: ${e.message}")
                frame
            }

            // Сохраняем с гарантированной последовательной нумерацией для FFmpeg
            val outFrame = File(outDir, "frame_%06d.png".format(idx + 1))
            FileOutputStream(outFrame).use { out ->
                processedFrame.compress(Bitmap.CompressFormat.PNG, 100, out)
            }

            if (processedFrame !== frame) processedFrame.recycle()
            frame.recycle()
        }

        detector.close(); embedder.close(); swapper.close()

        // --- 6. Собрать видео -------------------------------------------
        onProgress(90, "Сборка видео…")
        val hasAudio = audioFile.exists() && audioFile.length() > 0

        if (hasAudio) {
            val tmpVideo = File(workDir, "tmp_video.mp4")
            ffmpeg(
                "-y -framerate $fpsCapped " +
                "-i \"${outDir.absolutePath}/frame_%06d.png\" " +
                "-c:v libx264 -pix_fmt yuv420p -crf 18 " +
                "\"${tmpVideo.absolutePath}\""
            )
            ffmpeg(
                "-y -i \"${tmpVideo.absolutePath}\" -i \"${audioFile.absolutePath}\" " +
                "-c:v copy -c:a aac -shortest " +
                "\"${outputFile.absolutePath}\""
            )
            tmpVideo.delete()
        } else {
            ffmpeg(
                "-y -framerate $fpsCapped " +
                "-i \"${outDir.absolutePath}/frame_%06d.png\" " +
                "-c:v libx264 -pix_fmt yuv420p -crf 18 " +
                "\"${outputFile.absolutePath}\""
            )
        }

        onProgress(98, "Очистка…")
        workDir.deleteRecursively()

        onProgress(100, "Готово!")
        ProcessResult(outputFile)
    }

    private fun ffmpeg(cmd: String) {
        Log.d(TAG, "FFmpeg: $cmd")
        val session = FFmpegKit.execute(cmd)
        if (!ReturnCode.isSuccess(session.returnCode)) {
            val log = session.allLogsAsString
            Log.e(TAG, "FFmpeg fail: $log")
            throw RuntimeException("FFmpeg ошибка: ${session.returnCode}")
        }
    }
}
