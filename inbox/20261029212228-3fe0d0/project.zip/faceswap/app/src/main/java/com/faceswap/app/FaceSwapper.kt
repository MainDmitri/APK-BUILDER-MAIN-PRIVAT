package com.faceswap.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.util.Log
import ai.onnxruntime.*
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Движок замены лица через inswapper_128.onnx (InsightFace).
 *
 * Алгоритм на кадр:
 *  1. Детектировать лица в target-кадре.
 *  2. Для каждого: align → inswapper → unalign (warp back) → paste с blending.
 */
class FaceSwapper(modelPath: String) : AutoCloseable {

    private val TAG = "FaceSwapper"
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    // inswapper_128 ожидает [1,3,128,128] для target-лица
    private val SWAP_SIZE = 128

    init {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            addNnapi()
        }
        session = env.createSession(modelPath, opts)
        Log.d(TAG, "inswapper_128 загружен")
    }

    /**
     * Заменяет первое найденное лицо в [target] на [sourceEmbedding] (ArcFace 512-мерный вектор).
     * [faceDetector] и [faceEmbedder] используются для выравнивания.
     * Возвращает bitmap с заменённым лицом.
     */
    fun swapFace(
        target: Bitmap,
        targetFace: FaceDetector.Face,
        sourceEmbedding: FloatArray,
        faceEmbedder: FaceEmbedder
    ): Bitmap {
        // 1. Вырезаем + выравниваем целевое лицо 128x128
        val alignMatrix = faceEmbedder.estimateSimilarityTransformPublic(
            targetFace.landmarks,
            ARCFACE_128_TEMPLATE
        )
        val alignedFace = warpBitmap(target, alignMatrix, SWAP_SIZE, SWAP_SIZE)

        // 2. Запускаем inswapper_128
        val swappedFace = runSwapper(alignedFace, sourceEmbedding)

        // 3. Warp назад и paste
        return pasteFace(target, swappedFace, alignMatrix)
    }

    private fun runSwapper(alignedTarget: Bitmap, sourceEmb: FloatArray): Bitmap {
        val imgTensor = bitmapToTensor(alignedTarget, SWAP_SIZE)
        val embTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(sourceEmb),
            longArrayOf(1, 512)
        )

        // inswapper_128 входы: "target" и "source" (или "img" и "latent" — зависит от версии)
        val inputNames = session.inputNames.toList()
        Log.d(TAG, "inswapper входы: $inputNames")

        val inputs = when {
            inputNames.contains("target") -> mapOf("target" to imgTensor, "source" to embTensor)
            inputNames.contains("img")    -> mapOf("img" to imgTensor, "latent" to embTensor)
            else -> {
                // Авто: первый — изображение, второй — эмбеддинг
                mapOf(inputNames[0] to imgTensor, inputNames[1] to embTensor)
            }
        }

        val results = session.run(inputs)
        val outArr = (results.first().value as Array<*>)[0] as Array<*>

        val out = Bitmap.createBitmap(SWAP_SIZE, SWAP_SIZE, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(SWAP_SIZE * SWAP_SIZE)

        // Выход NCHW [1,3,128,128], диапазон примерно [-1,1] или [0,1]
        val ch0 = outArr[0] as FloatArray  // R или B
        val ch1 = outArr[1] as FloatArray  // G
        val ch2 = outArr[2] as FloatArray  // B или R

        for (i in pixels.indices) {
            // inswapper_128 выдаёт BGR в [0,255] или нормализованное
            val b = (ch2[i] * 255f).toInt().coerceIn(0, 255)
            val g = (ch1[i] * 255f).toInt().coerceIn(0, 255)
            val r = (ch0[i] * 255f).toInt().coerceIn(0, 255)
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        out.setPixels(pixels, 0, SWAP_SIZE, 0, 0, SWAP_SIZE, SWAP_SIZE)

        imgTensor.close(); embTensor.close(); results.close()
        return out
    }

    /** Аффинное преобразование bitmap через Matrix. */
    private fun warpBitmap(src: Bitmap, matrix: Matrix, outW: Int, outH: Int): Bitmap {
        val result = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawBitmap(src, matrix, null)
        return result
    }

    /**
     * Обратное paste: вставляем swapped-лицо назад в оригинальный кадр.
     * Использует инвертированную матрицу + Gaussian blending по маске.
     */
    private fun pasteFace(target: Bitmap, swapped: Bitmap, alignMatrix: Matrix): Bitmap {
        val result = target.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val invMatrix = Matrix()
        alignMatrix.invert(invMatrix)

        // Растягиваем swapped до размера target через инверсную матрицу
        val swappedFull = Bitmap.createBitmap(target.width, target.height, Bitmap.Config.ARGB_8888)
        val tmpCanvas = Canvas(swappedFull)
        tmpCanvas.drawBitmap(swapped, invMatrix, null)

        // Простая маска: рисуем прямоугольник, который покрывает область лица
        // (Gaussian blending через alpha — достаточно для видимого результата)
        val mask = Bitmap.createBitmap(SWAP_SIZE, SWAP_SIZE, Bitmap.Config.ARGB_8888)
        val maskCanvas = Canvas(mask)
        val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
        }
        // Эллипс для мягкого перехода по краям лица
        maskCanvas.drawOval(
            RectF(8f, 8f, (SWAP_SIZE - 8).toFloat(), (SWAP_SIZE - 8).toFloat()),
            maskPaint
        )

        val maskFull = Bitmap.createBitmap(target.width, target.height, Bitmap.Config.ARGB_8888)
        val maskFullCanvas = Canvas(maskFull)
        maskFullCanvas.drawBitmap(mask, invMatrix, null)

        // Composite: result = swappedFull * maskFull + target * (1 - maskFull)
        val paintDst = Paint().apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OVER)
        }
        val paintSrc = Paint()

        // Сначала рисуем swapped с маской
        val masked = Bitmap.createBitmap(target.width, target.height, Bitmap.Config.ARGB_8888)
        Canvas(masked).apply {
            drawBitmap(swappedFull, 0f, 0f, null)
            val dstIn = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
            drawBitmap(maskFull, 0f, 0f, dstIn)
        }

        // Накладываем на результат
        canvas.drawBitmap(masked, 0f, 0f, paintSrc)

        mask.recycle(); maskFull.recycle(); swappedFull.recycle(); masked.recycle()
        return result
    }

    private fun bitmapToTensor(bitmap: Bitmap, size: Int): OnnxTensor {
        val pixels = IntArray(size * size)
        bitmap.getPixels(pixels, 0, size, 0, 0, size, size)

        val buf = FloatBuffer.allocate(1 * 3 * size * size)
        // inswapper_128: BGR [0,1]
        val b = FloatArray(size * size)
        val g = FloatArray(size * size)
        val r = FloatArray(size * size)
        for (i in pixels.indices) {
            val px = pixels[i]
            b[i] = (px and 0xFF) / 255f
            g[i] = ((px shr 8) and 0xFF) / 255f
            r[i] = ((px shr 16) and 0xFF) / 255f
        }
        buf.put(b); buf.put(g); buf.put(r)
        buf.rewind()

        return OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, size.toLong(), size.toLong()))
    }

    // ArcFace template 128x128 (масштабированный из 112x112)
    private val ARCFACE_128_TEMPLATE = floatArrayOf(
        43.75f, 59.48f,
        84.03f, 59.27f,
        64.03f, 82.28f,
        47.49f, 105.85f,
        80.98f, 105.66f
    )

    override fun close() {
        session.close()
        // env — глобальный синглтон OrtEnvironment, не закрываем
    }
}

// Расширение: делаем estimateSimilarityTransform публичным через companion
fun FaceEmbedder.estimateSimilarityTransformPublic(src: FloatArray, dst: FloatArray): Matrix {
    // Используем отражение для доступа к приватному методу
    val method = this.javaClass.getDeclaredMethod(
        "estimateSimilarityTransform",
        FloatArray::class.java,
        FloatArray::class.java
    ).also { it.isAccessible = true }
    return method.invoke(this, src, dst) as Matrix
}
