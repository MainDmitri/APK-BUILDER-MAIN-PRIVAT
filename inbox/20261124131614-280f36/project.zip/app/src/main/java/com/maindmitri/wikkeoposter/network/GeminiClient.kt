package com.maindmitri.wikkeoposter.network

import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

data class GeminiResult(
    val success: Boolean,
    val postHtml: String,
    val error: String = ""
)

object GeminiClient {

    private const val TELEGRAM_CAPTION_LIMIT = 1024

    private fun buildSystemPrompt(styleHint: String): String = buildString {
        appendLine("Ты — копирайтер для Telegram-канала с товарами с оптового рынка Wikkeo / Китай.")
        appendLine("Напиши привлекательный, структурированный пост на русском языке по данным товара.")
        appendLine("Правила:")
        appendLine("1. Используй только Telegram HTML-теги <b>...</b> и <i>...</i>. Никакого Markdown (** или #).")
        appendLine("2. Структура: цепляющий заголовок с 1 эмодзи в <b>...</b>, затем 1-2 коротких предложения о пользе/фишке товара, затем 3-4 кратких пункта с маркером • (только реальные факты из исходных данных).")
        appendLine("3. Длина текста строго до 620 символов, чтобы ниже поместились цена и контакт (общий лимит Telegram — 1024 символа).")
        appendLine("4. Цену и контакты НЕ пиши — приложение добавит их автоматически внизу поста.")
        if (styleHint.isNotBlank()) {
            appendLine("Пожелания по стилю: $styleHint")
        }
    }

    suspend fun testConnection(apiKey: String, model: String): Pair<Boolean, String> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) return@withContext false to "Укажи API-ключ Gemini"
            val cleanModel = model.trim().ifEmpty { "gemini-2.5-flash" }
            val result = callGeminiRaw(
                apiKey = apiKey.trim(),
                model = cleanModel,
                systemPrompt = "Ответь одним словом: OK",
                userPrompt = "Проверка связи"
            )
            if (result.first) true to "Gemini ($cleanModel) отвечает нормально!"
            else false to result.second
        }

    suspend fun generateTelegramPost(product: Product, settings: AppSettings): GeminiResult =
        withContext(Dispatchers.IO) {
            if (settings.geminiApiKey.isBlank()) {
                val fallback = assembleTelegramPost(buildFallbackBody(product), product, settings)
                return@withContext GeminiResult(
                    success = true,
                    postHtml = fallback,
                    error = "Ключ Gemini не задан — использован шаблон"
                )
            }

            val specsBlock = product.specs.entries.take(10)
                .joinToString("\n") { "- ${it.key}: ${it.value}" }
                .ifBlank { "не указаны" }

            val userPrompt = buildString {
                appendLine("Название: ${product.title}")
                appendLine("Категория: ${product.category.ifBlank { "не указана" }}")
                appendLine("Продавец: ${product.seller.ifBlank { "не указан" }}")
                appendLine("Исходное описание:")
                appendLine(product.rawDescription.take(1500).ifBlank { "отсутствует" })
                appendLine()
                appendLine("Характеристики:")
                appendLine(specsBlock)
            }

            val (ok, textOrError) = callGeminiRaw(
                apiKey = settings.geminiApiKey.trim(),
                model = settings.geminiModel.trim().ifEmpty { "gemini-2.5-flash" },
                systemPrompt = buildSystemPrompt(settings.customStyleHint),
                userPrompt = userPrompt
            )

            if (ok) {
                val post = assembleTelegramPost(textOrError, product, settings)
                GeminiResult(success = true, postHtml = post)
            } else {
                val fallback = assembleTelegramPost(buildFallbackBody(product), product, settings)
                GeminiResult(success = false, postHtml = fallback, error = textOrError)
            }
        }

    private fun callGeminiRaw(
        apiKey: String,
        model: String,
        systemPrompt: String,
        userPrompt: String
    ): Pair<Boolean, String> {
        var conn: HttpURLConnection? = null
        return try {
            val encodedKey = URLEncoder.encode(apiKey, "UTF-8")
            val endpoint =
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$encodedKey"
            val payload = JSONObject().apply {
                put(
                    "system_instruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt))
                    )
                )
                put(
                    "contents",
                    JSONArray().put(
                        JSONObject()
                            .put("role", "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", userPrompt)))
                    )
                )
                put(
                    "generationConfig",
                    JSONObject()
                        .put("temperature", 0.7)
                        .put("maxOutputTokens", 600)
                )
            }

            conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20_000
                readTimeout = 45_000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            }
            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.readText().orEmpty()

            if (code !in 200..299) {
                val errMsg = runCatching {
                    JSONObject(body).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty().ifBlank { "HTTP $code" }
                return false to "Ошибка Gemini: $errMsg"
            }

            val root = JSONObject(body)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return false to "Gemini вернул пустой ответ"
            }
            val parts = candidates.getJSONObject(0)
                .optJSONObject("content")
                ?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    sb.append(parts.getJSONObject(i).optString("text", ""))
                }
            }
            val text = sb.toString().trim()
            if (text.isBlank()) false to "Пустой текст в ответе Gemini" else true to text
        } catch (e: Exception) {
            false to "Сетевая ошибка Gemini: ${e.message ?: "неизвестно"}"
        } finally {
            conn?.disconnect()
        }
    }

    fun formatRub(amount: Number?): String {
        if (amount == null) return "по запросу"
        val rounded = amount.toDouble().roundToInt()
        val s = rounded.toString()
        val grouped = s.reversed().chunked(3).joinToString(" ").reversed()
        return "$grouped ₽"
    }

    fun escapeHtml(text: String): String =
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")

    fun sanitizeTelegramHtml(raw: String): String {
        var text = raw.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>")
        val allowed = setOf("b", "i", "u", "s", "code")
        text = text.replace(Regex("</?([a-zA-Z0-9]+)(?:\\s+[^>]*)?>")) { m ->
            val tag = m.groupValues[1].lowercase()
            if (tag in allowed) {
                val closing = m.value.startsWith("</")
                if (closing) "</$tag>" else "<$tag>"
            } else {
                ""
            }
        }
        for (tag in allowed) {
            val opens = Regex("<$tag>").findAll(text).count()
            val closes = Regex("</$tag>").findAll(text).count()
            if (opens > closes) {
                text += "</$tag>".repeat(opens - closes)
            } else if (closes > opens) {
                var diff = closes - opens
                while (diff > 0) {
                    text = text.replaceFirst("</$tag>", "")
                    diff--
                }
            }
        }
        return text.trim()
    }

    fun buildFallbackBody(product: Product): String = buildString {
        appendLine("🔥 <b>${escapeHtml(product.title)}</b>")
        if (product.rawDescription.isNotBlank()) {
            appendLine()
            val clean = product.rawDescription.replace(Regex("\\s+"), " ").trim()
            val clipped = if (clean.length > 340) clean.take(337).substringBeforeLast(" ") + "..." else clean
            appendLine(escapeHtml(clipped))
        }
        if (product.specs.isNotEmpty()) {
            appendLine()
            product.specs.entries.take(5).forEach { (k, v) ->
                appendLine("• <b>${escapeHtml(k)}:</b> ${escapeHtml(v)}")
            }
        }
    }.trim()

    fun assembleTelegramPost(bodyHtml: String, product: Product, settings: AppSettings): String {
        val priceNum: Number? = product.finalPrice ?: product.wholesalePrice
        val footerLines = mutableListOf<String>()
        footerLines.add("💰 <b>Цена:</b> ${formatRub(priceNum)}")
        if (product.minOrder.isNotBlank()) {
            footerLines.add("📦 <b>Условия:</b> ${escapeHtml(product.minOrder)}")
        }
        if (settings.orderContact.isNotBlank()) {
            footerLines.add("📩 <b>Для заказа:</b> ${escapeHtml(settings.orderContact)}")
        }
        if (settings.includeSourceLink && product.url.isNotBlank()) {
            footerLines.add("🔗 <a href=\"${escapeHtml(product.url)}\">Карточка товара</a>")
        }

        val footer = footerLines.joinToString("\n")
        var cleanBody = sanitizeTelegramHtml(bodyHtml)
        val maxBodyLen = (TELEGRAM_CAPTION_LIMIT - footer.length - 4).coerceAtLeast(80)
        if (cleanBody.length > maxBodyLen) {
            val plain = cleanBody.replace(Regex("<[^>]+>"), "")
            val clipped = plain.take((maxBodyLen - 3).coerceAtLeast(50)).substringBeforeLast(" ") + "..."
            cleanBody = escapeHtml(clipped)
        }
        return "$cleanBody\n\n$footer".trim()
    }
}
