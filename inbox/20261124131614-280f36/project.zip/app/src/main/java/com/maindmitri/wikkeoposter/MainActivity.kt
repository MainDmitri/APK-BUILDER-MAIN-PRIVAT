package com.maindmitri.wikkeoposter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.SettingsRepository
import com.maindmitri.wikkeoposter.ui.ProductsScreen
import com.maindmitri.wikkeoposter.ui.SettingsScreen
import com.maindmitri.wikkeoposter.ui.WikkeoBrowserScreen
import com.maindmitri.wikkeoposter.ui.WikkeoPosterTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WikkeoPosterTheme {
                WikkeoPosterApp()
            }
        }
    }
}

@Composable
private fun WikkeoPosterApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settingsRepo = remember { SettingsRepository(context) }
    val dbHelper = remember { ProductDbHelper(context) }

    var settings by remember { mutableStateOf(settingsRepo.load()) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var currentTab by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    fun reloadProducts() {
        scope.launch {
            products = withContext(Dispatchers.IO) { dbHelper.getAll() }
        }
    }

    fun notify(message: String) {
        scope.launch {
            snackbarHostState.currentSnackbarData?.dismiss()
            snackbarHostState.showSnackbar(message)
        }
    }

    LaunchedEffect(Unit) {
        reloadProducts()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = currentTab == 0,
                    onClick = { currentTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Wikkeo") },
                    label = { Text("Wikkeo") }
                )
                NavigationBarItem(
                    selected = currentTab == 1,
                    onClick = {
                        currentTab = 1
                        reloadProducts()
                    },
                    icon = { Icon(Icons.AutoMirrored.Filled.List, contentDescription = "Товары") },
                    label = { Text("Товары (${products.size})") }
                )
                NavigationBarItem(
                    selected = currentTab == 2,
                    onClick = { currentTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Настройки") },
                    label = { Text("Настройки") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                0 -> WikkeoBrowserScreen(
                    settings = settings,
                    dbHelper = dbHelper,
                    onProductsChanged = ::reloadProducts,
                    onNotify = ::notify
                )
                1 -> ProductsScreen(
                    products = products,
                    settings = settings,
                    dbHelper = dbHelper,
                    onProductsChanged = ::reloadProducts,
                    onNotify = ::notify
                )
                else -> SettingsScreen(
                    settings = settings,
                    onSave = { updated ->
                        settings = updated
                        settingsRepo.save(updated)
                    },
                    onNotify = ::notify
                )
            }
        }
    }
}
