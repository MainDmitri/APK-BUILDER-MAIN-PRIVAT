package com.maindmitri.wikkeoposter.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.network.GeminiClient
import com.maindmitri.wikkeoposter.network.TelegramClient
import kotlinx.coroutines.launch

private val GEMINI_MODELS = listOf(
    "gemini-2.5-flash",
    "gemini-2.5-pro",
    "gemini-2.0-flash"
)

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSave: (AppSettings) -> Unit,
    onNotify: (String) -> Unit
) {
    val scope = rememberCoroutineScope()

    var geminiKey by remember(settings) { mutableStateOf(settings.geminiApiKey) }
    var geminiModel by remember(settings) { mutableStateOf(settings.geminiModel) }
    var styleHint by remember(settings) { mutableStateOf(settings.customStyleHint) }

    var tgToken by remember(settings) { mutableStateOf(settings.telegramBotToken) }
    var tgChannel by remember(settings) { mutableStateOf(settings.telegramChannelId) }
    var orderContact by remember(settings) { mutableStateOf(settings.orderContact) }
    var includeLink by remember(settings) { mutableStateOf(settings.includeSourceLink) }
    var autoPublish by remember(settings) { mutableStateOf(settings.autoPublish) }

    var markupPercent by remember(settings) { mutableStateOf(settings.markupPercent.toInt().toString()) }
    var markupFixed by remember(settings) { mutableStateOf(settings.markupFixed.toString()) }
    var roundTo by remember(settings) { mutableStateOf(settings.roundTo.toString()) }
    var batchLimit by remember(settings) { mutableStateOf(settings.maxProductsPerBatch.toString()) }
    var maxPhotos by remember(settings) { mutableStateOf(settings.maxPhotosPerPost.toString()) }

    var testingGemini by remember { mutableStateOf(false) }
    var testingTelegram by remember { mutableStateOf(false) }

    fun collectSettings(): AppSettings = AppSettings(
        geminiApiKey = geminiKey.trim(),
        geminiModel = geminiModel.trim().ifEmpty { "gemini-2.5-flash" },
        customStyleHint = styleHint.trim(),
        telegramBotToken = tgToken.trim(),
        telegramChannelId = tgChannel.trim(),
        orderContact = orderContact.trim(),
        includeSourceLink = includeLink,
        autoPublish = autoPublish,
        markupPercent = markupPercent.toDoubleOrNull() ?: 0.0,
        markupFixed = markupFixed.toIntOrNull() ?: 0,
        roundTo = (roundTo.toIntOrNull() ?: 10).coerceAtLeast(1),
        maxProductsPerBatch = (batchLimit.toIntOrNull() ?: 5).coerceIn(1, 30),
        maxPhotosPerPost = (maxPhotos.toIntOrNull() ?: 8).coerceIn(1, 10)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Gemini API section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Google Gemini API",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = geminiKey,
                    onValueChange = { geminiKey = it },
                    label = { Text("Gemini API Key") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GEMINI_MODELS.forEach { m ->
                        FilterChip(
                            selected = geminiModel == m,
                            onClick = { geminiModel = m },
                            label = { Text(m.removePrefix("gemini-")) }
                        )
                    }
                }
                OutlinedTextField(
                    value = geminiModel,
                    onValueChange = { geminiModel = it },
                    label = { Text("Модель Gemini") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = styleHint,
                    onValueChange = { styleHint = it },
                    label = { Text("Стиль описаний для постов") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            testingGemini = true
                            val (_, msg) = GeminiClient.testConnection(geminiKey, geminiModel)
                            onNotify(msg)
                            testingGemini = false
                        }
                    },
                    enabled = !testingGemini,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (testingGemini) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Проверить Gemini API")
                    }
                }
            }
        }

        // Telegram section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Telegram-канал",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                OutlinedTextField(
                    value = tgToken,
                    onValueChange = { tgToken = it },
                    label = { Text("Bot Token (от @BotFather)") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tgChannel,
                    onValueChange = { tgChannel = it },
                    label = { Text("Канал (@username или -100...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = orderContact,
                    onValueChange = { orderContact = it },
                    label = { Text("Контакт для заказа (напр. @MainDmitri)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Автопубликация при автосборе", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Если выкл. — товары сохраняются в «Черновики»",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = autoPublish, onCheckedChange = { autoPublish = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Добавлять ссылку на Wikkeo в пост", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = includeLink, onCheckedChange = { includeLink = it })
                }
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            testingTelegram = true
                            val (_, msg) = TelegramClient.testConnection(tgToken, tgChannel)
                            onNotify(msg)
                            testingTelegram = false
                        }
                    },
                    enabled = !testingTelegram,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (testingTelegram) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Проверить бота и канал")
                    }
                }
            }
        }

        // Pricing & Limits section
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Цены и лимиты сбора",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = markupPercent,
                        onValueChange = { markupPercent = it.filter { ch -> ch.isDigit() || ch == '-' } },
                        label = { Text("Наценка %") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = markupFixed,
                        onValueChange = { markupFixed = it.filter { ch -> ch.isDigit() || ch == '-' } },
                        label = { Text("+ фикс ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = roundTo,
                        onValueChange = { roundTo = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Округл. ₽") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = batchLimit,
                        onValueChange = { batchLimit = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Товаров за автосбор") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = maxPhotos,
                        onValueChange = { maxPhotos = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Макс. фото (до 10)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Button(
            onClick = {
                val updated = collectSettings()
                onSave(updated)
                onNotify("Настройки сохранены!")
            },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Icon(Icons.Default.Check, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Сохранить настройки")
        }

        Spacer(Modifier.height(16.dp))
    }
}
