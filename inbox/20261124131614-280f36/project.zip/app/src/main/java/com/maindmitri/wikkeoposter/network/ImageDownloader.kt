package com.maindmitri.wikkeoposter.network

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ImageDownloader {

    private const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36"

    suspend fun downloadProductImages(
        imageUrls: List<String>,
        refererUrl: String,
        targetDir: File,
        maxPhotos: Int
    ): List<String> = withContext(Dispatchers.IO) {
        if (!targetDir.exists()) targetDir.mkdirs()
        val saved = mutableListOf<String>()

        for (rawUrl in imageUrls) {
            if (saved.size >= maxPhotos) break
            val bytes = fetchBytes(rawUrl, refererUrl) ?: continue
            if (bytes.size < 4096) continue

            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: continue
            try {
                if (bitmap.width < 200 || bitmap.height < 200) continue
                val index = saved.size + 1
                val outFile = File(targetDir, "photo_%02d.jpg".format(index))
                FileOutputStream(outFile).use { fos ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
                }
                saved.add(outFile.absolutePath)
            } finally {
                bitmap.recycle()
            }
        }
        saved
    }

    private fun fetchBytes(rawUrl: String, referer: String): ByteArray? {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL(rawUrl)
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 20_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT)
                setRequestProperty("Referer", referer)
                setRequestProperty("Accept", "image/webp,image/apng,image/*,*/*;q=0.8")
            }
            if (conn.responseCode in 200..299) {
                conn.inputStream.use { it.readBytes() }
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
