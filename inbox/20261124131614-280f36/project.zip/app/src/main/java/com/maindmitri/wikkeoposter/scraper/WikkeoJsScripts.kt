package com.maindmitri.wikkeoposter.scraper

import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.security.MessageDigest

object WikkeoJsScripts {

    const val EXTRACT_CATALOG_LINKS_JS: String = """
        (function() {
            const seen = new Set();
            const out = [];
            document.querySelectorAll("a[href*='/item/']").forEach(function(a) {
                try {
                    const u = new URL(a.getAttribute('href'), window.location.origin);
                    const clean = u.origin + u.pathname;
                    if (clean.indexOf('/item/') !== -1 && !seen.has(clean)) {
                        seen.add(clean);
                        out.push(clean);
                    }
                } catch (e) {}
            });
            return JSON.stringify(out);
        })();
    """

    const val EXTRACT_PRODUCT_JS: String = """
        (function() {
            function norm(s) {
                return (s || '').replace(/\u00a0/g, ' ').replace(/\s+/g, ' ').trim();
            }
            function parseRub(txt) {
                if (!txt) return null;
                var c = txt.replace(/\u00a0/g, ' ').replace(/\u202f/g, ' ');
                var m = c.match(/(\d[\d\s]{0,12}(?:[.,]\d{1,2})?)\s*(?:₽|руб\.?|RUB)/i)
                     || c.match(/(\d[\d\s]{0,12}(?:[.,]\d{1,2})?)/);
                if (!m) return null;
                var v = parseFloat(m[1].replace(/\s+/g, '').replace(',', '.'));
                return (isFinite(v) && v > 0) ? v : null;
            }

            var url = window.location.href.split('#')[0].split('?')[0];
            var h1 = document.querySelector('h1');
            var ogTitle = document.querySelector("meta[property='og:title']");
            var title = norm(h1 ? h1.innerText : '') || norm(ogTitle ? ogTitle.content : '') || norm(document.title) || 'Товар с Wikkeo';

            var ldPrice = null;
            var ldDesc = '';
            var ldImages = [];
            document.querySelectorAll("script[type='application/ld+json']").forEach(function(sc) {
                try {
                    var parsed = JSON.parse(sc.textContent || '');
                    var arr = Array.isArray(parsed) ? parsed : [parsed];
                    arr.forEach(function(obj) {
                        if (obj && obj['@type'] === 'Product') {
                            if (obj.description && !ldDesc) ldDesc = String(obj.description).trim();
                            if (typeof obj.image === 'string') ldImages.push(obj.image);
                            else if (Array.isArray(obj.image)) obj.image.forEach(function(i) { if (typeof i === 'string') ldImages.push(i); });
                            if (obj.offers) {
                                var p = obj.offers.price || obj.offers.lowPrice;
                                if (p != null) {
                                    var pv = parseFloat(String(p).replace(',', '.'));
                                    if (isFinite(pv) && pv > 0) ldPrice = pv;
                                }
                            }
                        }
                    });
                } catch (e) {}
            });

            var price = ldPrice;
            if (price == null) {
                var priceEls = document.querySelectorAll("[class*='price'], [class*='Price'], [data-testid*='price']");
                for (var i = 0; i < priceEls.length; i++) {
                    var el = priceEls[i];
                    var cls = (el.className || '').toString().toLowerCase();
                    var tag = (el.tagName || '').toLowerCase();
                    if (tag === 'del' || tag === 's' || cls.indexOf('old') !== -1 || cls.indexOf('cross') !== -1 || cls.indexOf('strike') !== -1) continue;
                    var t = norm(el.innerText);
                    if (t.indexOf('₽') !== -1 && t.length < 40) {
                        var pv2 = parseRub(t);
                        if (pv2 != null) { price = pv2; break; }
                    }
                }
            }
            if (price == null) {
                price = parseRub(document.body ? document.body.innerText : '');
            }

            var bodyText = document.body ? document.body.innerText : '';
            var minMatch = bodyText.match(/(?:мин\.?\s*заказ[^\n]{0,30}|от\s+\d+\s*(?:шт|уп|кор|пар|K|К|₽|руб))/i);
            var minOrder = minMatch ? norm(minMatch[0]) : '';

            var storeLink = document.querySelector("a[href*='/store/']");
            var seller = storeLink ? norm(storeLink.innerText) : '';

            var catLinks = document.querySelectorAll("a[href*='/category/']");
            var category = '';
            if (catLinks.length > 0) {
                category = norm(catLinks[catLinks.length - 1].innerText);
            }

            var rawDescription = ldDesc;
            if (!rawDescription) {
                var descEls = document.querySelectorAll("[class*='description'], [class*='Description'], [itemprop='description'], article");
                var best = '';
                descEls.forEach(function(el) {
                    var txt = (el.innerText || '').trim();
                    if (txt.length > best.length && txt.indexOf('Wikkeo.com - это оптовый маркетплейс') === -1) {
                        best = txt;
                    }
                });
                rawDescription = best;
            }
            if (!rawDescription) {
                var metaDesc = document.querySelector("meta[name='description']");
                if (metaDesc && metaDesc.content && metaDesc.content.indexOf('Wikkeo.com - это оптовый маркетплейс') === -1) {
                    rawDescription = metaDesc.content.trim();
                }
            }

            var specs = {};
            document.querySelectorAll("tr, [class*='spec'], [class*='char'], [class*='attribute']").forEach(function(row) {
                var kids = Array.from(row.children || []);
                if (kids.length === 2) {
                    var k = norm(kids[0].innerText).replace(/:$/, '');
                    var v = norm(kids[1].innerText);
                    if (k.length > 1 && k.length <= 50 && v.length > 0 && v.length <= 120 && !specs[k]) {
                        specs[k] = v;
                    }
                }
            });

            var badParts = ['default-shop-avatar', 'avatar', 'logo', 'favicon', 'icon', 'banner', 'promotion', 'badge', 'placeholder', 'no-photo', 'nophoto', 'sprite', '.svg', 'data:image'];
            var images = [];
            var seenImg = new Set();
            function addImg(src) {
                if (!src) return;
                try {
                    var full = new URL(src, window.location.href).href;
                    var low = full.toLowerCase();
                    if (!(low.startsWith('http://') || low.startsWith('https://'))) return;
                    for (var b = 0; b < badParts.length; b++) {
                        if (low.indexOf(badParts[b]) !== -1) return;
                    }
                    if (!seenImg.has(full)) {
                        seenImg.add(full);
                        images.push(full);
                    }
                } catch (e) {}
            }

            Array.from(document.images || []).forEach(function(im) {
                if (im.naturalWidth >= 200 && im.naturalHeight >= 200) {
                    addImg(im.currentSrc || im.src);
                }
            });
            ldImages.forEach(addImg);
            var ogImg = document.querySelector("meta[property='og:image']");
            if (ogImg && ogImg.content) addImg(ogImg.content);
            document.querySelectorAll('img').forEach(function(im) {
                addImg(im.getAttribute('data-src') || im.getAttribute('data-original') || im.getAttribute('src'));
            });

            return JSON.stringify({
                url: url,
                title: title,
                price: price,
                minOrder: minOrder,
                seller: seller,
                category: category,
                rawDescription: rawDescription,
                specs: specs,
                images: images
            });
        })();
    """

    fun decodeJsStringResult(rawResult: String?): String? {
        if (rawResult.isNullOrBlank() || rawResult == "null") return null
        return runCatching {
            val tokener = JSONTokener(rawResult)
            val value = tokener.nextValue()
            value?.toString()
        }.getOrNull()
    }

    fun parseCatalogLinks(rawJsResult: String?): List<String> {
        val jsonStr = decodeJsStringResult(rawJsResult) ?: return emptyList()
        val result = mutableListOf<String>()
        runCatching {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val u = arr.optString(i, "")
                if (u.contains("/item/")) result.add(ProductDbHelper.cleanUrl(u))
            }
        }
        return result.distinct()
    }

    fun parseExtractedProduct(rawJsResult: String?): Product? {
        val jsonStr = decodeJsStringResult(rawJsResult) ?: return null
        return runCatching {
            val obj = JSONObject(jsonStr)
            val url = ProductDbHelper.cleanUrl(obj.optString("url", ""))
            if (url.isBlank()) return null

            val specs = linkedMapOf<String, String>()
            val specsObj = obj.optJSONObject("specs")
            if (specsObj != null) {
                val keys = specsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    specs[k] = specsObj.optString(k, "")
                }
            }

            val imgs = mutableListOf<String>()
            val imgArr = obj.optJSONArray("images")
            if (imgArr != null) {
                for (i in 0 until imgArr.length()) {
                    val s = imgArr.optString(i, "")
                    if (s.isNotBlank()) imgs.add(s)
                }
            }

            val priceVal = if (obj.isNull("price")) null else obj.optDouble("price", -1.0).takeIf { it > 0.0 }

            Product(
                id = extractProductId(url),
                url = url,
                title = obj.optString("title", "Товар с Wikkeo").ifBlank { "Товар с Wikkeo" },
                rawDescription = obj.optString("rawDescription", ""),
                specs = specs,
                wholesalePrice = priceVal,
                minOrder = obj.optString("minOrder", ""),
                seller = obj.optString("seller", ""),
                category = obj.optString("category", ""),
                imageUrls = imgs
            )
        }.getOrNull()
    }

    fun extractProductId(url: String): String {
        val match = Regex("wvp-\\d+", RegexOption.IGNORE_CASE).find(url)
        if (match != null) return match.value.lowercase()
        val tail = url.trimEnd('/').substringAfterLast('/')
        if (tail.isNotBlank() && tail.length <= 48) {
            return tail.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        }
        val md = MessageDigest.getInstance("SHA-1").digest(url.toByteArray(Charsets.UTF_8))
        return md.take(8).joinToString("") { "%02x".format(it) }
    }
}
