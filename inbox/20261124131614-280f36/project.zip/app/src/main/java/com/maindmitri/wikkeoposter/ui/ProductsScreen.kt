package com.maindmitri.wikkeoposter.ui

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.maindmitri.wikkeoposter.data.AppSettings
import com.maindmitri.wikkeoposter.data.Product
import com.maindmitri.wikkeoposter.data.ProductDbHelper
import com.maindmitri.wikkeoposter.data.ProductStatus
import com.maindmitri.wikkeoposter.network.GeminiClient
import com.maindmitri.wikkeoposter.network.TelegramClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ProductsScreen(
    products: List<Product>,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    var selectedFilter by remember { mutableStateOf<ProductStatus?>(null) }
    var editingProductId by remember { mutableStateOf<String?>(null) }

    val editingProduct = products.firstOrNull { it.id == editingProductId }

    if (editingProduct != null) {
        ProductDetailEditor(
            product = editingProduct,
            settings = settings,
            dbHelper = dbHelper,
            onBack = { editingProductId = null },
            onProductsChanged = onProductsChanged,
            onNotify = onNotify
        )
        return
    }

    val filtered = remember(products, selectedFilter) {
        if (selectedFilter == null) products else products.filter { it.status == selectedFilter }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedFilter == null,
                onClick = { selectedFilter = null },
                label = { Text("Все (${products.size})") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.DRAFT,
                onClick = { selectedFilter = ProductStatus.DRAFT },
                label = { Text("Черновики") }
            )
            FilterChip(
                selected = selectedFilter == ProductStatus.PUBLISHED,
                onClick = { selectedFilter = ProductStatus.PUBLISHED },
                label = { Text("В канале") }
            )
        }

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.ShoppingCart,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Пока нет сохранённых товаров",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Открой вкладку Wikkeo, выбери товар или нажми «Автосбор» на странице каталога.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    ProductListCard(
                        product = item,
                        onClick = { editingProductId = item.id }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProductListCard(
    product: Product,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            LocalThumbImage(
                path = product.localImages.firstOrNull(),
                modifier = Modifier
                    .size(76.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                val wholesaleStr = GeminiClient.formatRub(product.wholesalePrice)
                val finalStr = GeminiClient.formatRub(product.finalPrice ?: product.wholesalePrice)
                Text(
                    text = "Опт: $wholesaleStr → Пост: $finalStr",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusBadge(product.status)
                    Text(
                        text = "Фото: ${product.localImages.size}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusBadge(status: ProductStatus) {
    val bg = when (status) {
        ProductStatus.PUBLISHED -> Color(0xFF2E7D32)
        ProductStatus.DRAFT -> Color(0xFF1565C0)
        ProductStatus.ERROR -> Color(0xFFC62828)
    }
    Surface(
        color = bg.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = status.labelRu,
            color = bg,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun LocalThumbImage(path: String?, modifier: Modifier = Modifier) {
    var bitmap by remember(path) { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(path) {
        bitmap = withContext(Dispatchers.IO) {
            if (path.isNullOrBlank()) return@withContext null
            val f = File(path)
            if (!f.exists()) return@withContext null
            val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapFactory.decodeFile(f.absolutePath, opts)?.asImageBitmap()
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(
            modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.ShoppingCart,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProductDetailEditor(
    product: Product,
    settings: AppSettings,
    dbHelper: ProductDbHelper,
    onBack: () -> Unit,
    onProductsChanged: () -> Unit,
    onNotify: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var postText by remember(product.id, product.generatedPost) { mutableStateOf(product.generatedPost) }
    var priceText by remember(product.id, product.finalPrice) {
        mutableStateOf((product.finalPrice ?: product.wholesalePrice?.toInt())?.toString() ?: "")
    }
    var localImages by remember(product.id, product.localImages) { mutableStateOf(product.localImages) }
    var busy by remember { mutableStateOf(false) }

    BackHandler(enabled = !busy) { onBack() }

    fun currentEditedProduct(): Product = product.copy(
        finalPrice = priceText.toIntOrNull(),
        generatedPost = postText,
        localImages = localImages
    )

    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Text(
                    text = product.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                }
            },
            actions = {
                IconButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.delete(product.id) }
                            onProductsChanged()
                            onNotify("Товар удалён")
                            onBack()
                        }
                    },
                    enabled = !busy
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Удалить")
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Photos gallery
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Сохранённые фото (${localImages.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                StatusBadge(product.status)
            }

            if (localImages.isEmpty()) {
                Text(
                    text = "Фотографии не скачаны — пост уйдёт текстом.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(localImages, key = { it }) { imgPath ->
                        Box(modifier = Modifier.size(110.dp)) {
                            LocalThumbImage(
                                path = imgPath,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            IconButton(
                                onClick = {
                                    localImages = localImages.filterNot { it == imgPath }
                                    scope.launch(Dispatchers.IO) {
                                        runCatching { File(imgPath).delete() }
                                        dbHelper.upsert(currentEditedProduct())
                                        withContext(Dispatchers.Main) { onProductsChanged() }
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(26.dp)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Убрать фото",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            if (product.lastError.isNotBlank()) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Text(
                        text = product.lastError,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Price row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Цена в посте (₽)") },
                    supportingText = {
                        Text("Опт на Wikkeo: ${GeminiClient.formatRub(product.wholesalePrice)}")
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            // Telegram Post HTML Editor
            OutlinedTextField(
                value = postText,
                onValueChange = { postText = it },
                label = { Text("Текст поста (Telegram HTML)") },
                supportingText = {
                    val color = if (postText.length > 1024) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                    Text("${postText.length} / 1024 символов", color = color)
                },
                minLines = 7,
                maxLines = 14,
                modifier = Modifier.fillMaxWidth()
            )

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = {
                        scope.launch {
                            busy = true
                            val edited = currentEditedProduct()
                            val res = GeminiClient.generateTelegramPost(edited, settings)
                            postText = res.postHtml
                            val updated = edited.copy(
                                generatedPost = res.postHtml,
                                lastError = if (res.success) "" else res.error
                            )
                            withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                            onProductsChanged()
                            onNotify(if (res.success) "Описание обновлено через Gemini" else res.error)
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Gemini")
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            withContext(Dispatchers.IO) { dbHelper.upsert(currentEditedProduct()) }
                            onProductsChanged()
                            onNotify("Изменения сохранены")
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Сохранить")
                }
            }

            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        val edited = currentEditedProduct()
                        withContext(Dispatchers.IO) { dbHelper.upsert(edited) }
                        val tgRes = TelegramClient.publishProduct(edited, settings)
                        val updated = if (tgRes.success) {
                            edited.copy(
                                status = ProductStatus.PUBLISHED,
                                telegramMessageId = tgRes.messageId,
                                publishedAt = System.currentTimeMillis(),
                                lastError = ""
                            )
                        } else {
                            edited.copy(
                                status = ProductStatus.ERROR,
                                lastError = tgRes.error
                            )
                        }
                        withContext(Dispatchers.IO) { dbHelper.upsert(updated) }
                        onProductsChanged()
                        onNotify(
                            if (tgRes.success) "Опубликовано в Telegram-канал!"
                            else "Ошибка Telegram: ${tgRes.error}"
                        )
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Опубликовать в Telegram-канал")
                }
            }
        }
    }
}
