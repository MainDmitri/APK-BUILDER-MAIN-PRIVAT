package com.maindmitri.wikkeoposter.data

import android.content.Context
import kotlin.math.max
import kotlin.math.roundToInt

data class AppSettings(
    val geminiApiKey: String = "",
    val geminiModel: String = "gemini-2.5-flash",
    val customStyleHint: String = "Живой, продающий стиль без воды, акцент на выгоду и характеристики.",
    val telegramBotToken: String = "",
    val telegramChannelId: String = "",
    val orderContact: String = "",
    val includeSourceLink: Boolean = false,
    val autoPublish: Boolean = false,
    val markupPercent: Double = 20.0,
    val markupFixed: Int = 0,
    val roundTo: Int = 10,
    val maxProductsPerBatch: Int = 5,
    val maxPhotosPerPost: Int = 8
) {
    fun calculateFinalPrice(wholesalePrice: Double?): Int? {
        if (wholesalePrice == null || wholesalePrice <= 0.0) return null
        var price = wholesalePrice * (1.0 + markupPercent / 100.0) + markupFixed
        if (roundTo > 1) {
            price = (price / roundTo).roundToInt() * roundTo.toDouble()
        }
        return max(1, price.roundToInt())
    }
}

class SettingsRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(
        "wikkeo_poster_prefs",
        Context.MODE_PRIVATE
    )

    fun load(): AppSettings = AppSettings(
        geminiApiKey = prefs.getString("gemini_api_key", "") ?: "",
        geminiModel = prefs.getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash",
        customStyleHint = prefs.getString(
            "custom_style_hint",
            "Живой, продающий стиль без воды, акцент на выгоду и характеристики."
        ) ?: "",
        telegramBotToken = prefs.getString("telegram_bot_token", "") ?: "",
        telegramChannelId = prefs.getString("telegram_channel_id", "") ?: "",
        orderContact = prefs.getString("order_contact", "") ?: "",
        includeSourceLink = prefs.getBoolean("include_source_link", false),
        autoPublish = prefs.getBoolean("auto_publish", false),
        markupPercent = prefs.getFloat("markup_percent", 20f).toDouble(),
        markupFixed = prefs.getInt("markup_fixed", 0),
        roundTo = prefs.getInt("round_to", 10).coerceAtLeast(1),
        maxProductsPerBatch = prefs.getInt("max_products_per_batch", 5).coerceIn(1, 30),
        maxPhotosPerPost = prefs.getInt("max_photos_per_post", 8).coerceIn(1, 10)
    )

    fun save(settings: AppSettings) {
        prefs.edit()
            .putString("gemini_api_key", settings.geminiApiKey.trim())
            .putString("gemini_model", settings.geminiModel.trim().ifEmpty { "gemini-2.5-flash" })
            .putString("custom_style_hint", settings.customStyleHint.trim())
            .putString("telegram_bot_token", settings.telegramBotToken.trim())
            .putString("telegram_channel_id", settings.telegramChannelId.trim())
            .putString("order_contact", settings.orderContact.trim())
            .putBoolean("include_source_link", settings.includeSourceLink)
            .putBoolean("auto_publish", settings.autoPublish)
            .putFloat("markup_percent", settings.markupPercent.toFloat())
            .putInt("markup_fixed", settings.markupFixed)
            .putInt("round_to", settings.roundTo.coerceAtLeast(1))
            .putInt("max_products_per_batch", settings.maxProductsPerBatch.coerceIn(1, 30))
            .putInt("max_photos_per_post", settings.maxPhotosPerPost.coerceIn(1, 10))
            .apply()
    }
}
