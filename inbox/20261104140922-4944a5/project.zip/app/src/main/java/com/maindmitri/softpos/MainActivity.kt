package com.maindmitri.softpos

import android.graphics.Bitmap
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class Screen { KEYPAD, SETTINGS, PAYING, DONE }

private val Brand = Color(0xFF2563EB)
private val BrandDark = Color(0xFF1E3A8A)
private val Ok = Color(0xFF16A34A)
private val Ink = Color(0xFF0F172A)
private val Muted = Color(0xFF64748B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MaterialTheme { App() } }
    }
}

private fun fmt(kopeks: Long): String {
    val grouped = "%,d".format(kopeks / 100).replace(',', ' ')
    return "%s,%02d".format(grouped, kopeks % 100)
}

private fun apiValue(kopeks: Long): String = "%d.%02d".format(kopeks / 100, kopeks % 100)

@Composable
private fun App() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val scope = rememberCoroutineScope()

    var screen by remember { mutableStateOf(if (store.configured) Screen.KEYPAD else Screen.SETTINGS) }
    var kopeks by remember { mutableLongStateOf(0L) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var paymentId by remember { mutableStateOf<String?>(null) }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var paidKopeks by remember { mutableLongStateOf(0L) }

    LaunchedEffect(paymentId) {
        val id = paymentId ?: return@LaunchedEffect
        while (true) {
            delay(2500)
            val s = runCatching {
                withContext(Dispatchers.IO) { YooKassa.status(store.shopId, store.secretKey, id) }
            }.getOrNull() ?: continue
            when (s) {
                "succeeded", "waiting_for_capture" -> { paidKopeks = kopeks; screen = Screen.DONE; break }
                "canceled" -> { error = "Платёж отменён"; paymentId = null; screen = Screen.KEYPAD; break }
            }
        }
    }

    fun pay() {
        if (kopeks <= 0L || busy) return
        scope.launch {
            busy = true; error = null
            try {
                val created = withContext(Dispatchers.IO) {
                    YooKassa.createPayment(store.shopId, store.secretKey, apiValue(kopeks), "Оплата на кассе")
                }
                val data = created.qrData ?: created.confirmationUrl
                    ?: throw RuntimeException("Магазин не вернул QR. Проверьте, что СБП подключён в ЮKassa.")
                qr = withContext(Dispatchers.Default) { QrGen.bitmap(data, 720) }
                paymentId = created.id
                screen = Screen.PAYING
            } catch (e: Exception) {
                error = e.message ?: "Ошибка сети"
            }
            busy = false
        }
    }

    val bg = Brush.verticalGradient(listOf(Color(0xFFF8FAFF), Color(0xFFEEF2FF)))
    Box(Modifier.fillMaxSize().background(bg)) {
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal = 20.dp)) {
            Header(
                subtitle = when (screen) {
                    Screen.SETTINGS -> "Настройки"
                    Screen.PAYING -> "Приём оплаты"
                    Screen.DONE -> "Платёж принят"
                    Screen.KEYPAD -> "Касса · СБП"
                },
                showGear = screen == Screen.KEYPAD,
                onGear = { screen = Screen.SETTINGS }
            )

            AnimatedVisibility(
                visible = error != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2))
                ) {
                    Text(
                        error ?: "",
                        Modifier.padding(14.dp),
                        color = Color(0xFFB91C1C),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(Modifier.height(12.dp))
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = screen,
                    transitionSpec = {
                        (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 6 })
                            .togetherWith(fadeOut(tween(180)) + slideOutHorizontally(tween(180)) { -it / 6 })
                    },
                    label = "screen"
                ) { s ->
                    when (s) {
                        Screen.SETTINGS -> SettingsScreen(store) {
                            error = null
                            if (store.configured) screen = Screen.KEYPAD
                            else error = "Заполните shopId и секретный ключ"
                        }
                        Screen.KEYPAD -> KeypadScreen(
                            kopeks = kopeks,
                            busy = busy,
                            onDigit = { d -> if (kopeks < 9_999_999_99L) kopeks = kopeks * 10 + d },
                            onBackspace = { kopeks /= 10 },
                            onClear = { kopeks = 0 },
                            onPay = { pay() }
                        )
                        Screen.PAYING -> PayingScreen(
                            kopeks = kopeks,
                            qr = qr,
                            onCancel = { paymentId = null; qr = null; screen = Screen.KEYPAD }
                        )
                        Screen.DONE -> DoneScreen(paidKopeks) {
                            kopeks = 0; paymentId = null; qr = null; screen = Screen.KEYPAD
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(subtitle: String, showGear: Boolean, onGear: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
                .background(Brush.verticalGradient(listOf(Brand, BrandDark))),
            contentAlignment = Alignment.Center
        ) { Text("M", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("MainDmitri POS", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(subtitle, fontSize = 13.sp, color = Muted)
        }
        if (showGear) {
            FilledTonalIconButton(onClick = onGear) { Text("⚙", fontSize = 18.sp) }
        }
    }
}

@Composable
private fun SettingsScreen(store: Store, onSave: () -> Unit) {
    var shop by remember { mutableStateOf(store.shopId) }
    var key by remember { mutableStateOf(store.secretKey) }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text(
            "Реквизиты из личного кабинета ЮKassa → Интеграция → Ключи API.",
            fontSize = 14.sp, color = Muted
        )
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = shop, onValueChange = { shop = it },
            label = { Text("shopId") }, singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = key, onValueChange = { key = it },
            label = { Text("Секретный ключ (live_… / test_…)") }, singleLine = true,
            shape = RoundedCornerShape(14.dp),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(22.dp))
        GradientButton("Сохранить", listOf(Brand, BrandDark), Modifier.fillMaxWidth()) {
            store.shopId = shop; store.secretKey = key; onSave()
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Ключ хранится только на этом устройстве. Не устанавливайте этот APK на чужие телефоны: " +
                "секретный ключ можно извлечь из приложения. Для публичного релиза ключ должен лежать на вашем сервере.",
            fontSize = 12.sp, color = Color(0xFF94A3B8)
        )
    }
}

@Composable
private fun KeypadScreen(
    kopeks: Long, busy: Boolean,
    onDigit: (Long) -> Unit, onBackspace: () -> Unit, onClear: () -> Unit, onPay: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Card(
            Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Сумма к оплате", fontSize = 13.sp, color = Muted, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                AnimatedContent(
                    targetState = kopeks,
                    transitionSpec = {
                        if (targetState > initialState)
                            (slideInVertically { it / 3 } + fadeIn()).togetherWith(slideOutVertically { -it / 3 } + fadeOut())
                        else
                            (slideInVertically { -it / 3 } + fadeIn()).togetherWith(slideOutVertically { it / 3 } + fadeOut())
                    },
                    label = "amount"
                ) { k ->
                    Text("${fmt(k)} ₽", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Ink)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("C", "0", "⌫")
        )
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { label ->
                    Key(label, Modifier.weight(1f)) {
                        when (label) {
                            "C" -> onClear()
                            "⌫" -> onBackspace()
                            else -> onDigit(label.toLong())
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        Spacer(Modifier.weight(1f))
        GradientButton(
            text = if (busy) "" else "Принять оплату (СБП)",
            colors = if (kopeks > 0) listOf(Ok, Color(0xFF15803D)) else listOf(Color(0xFFCBD5E1), Color(0xFFCBD5E1)),
            modifier = Modifier.fillMaxWidth(),
            enabled = kopeks > 0 && !busy,
            loading = busy,
            onClick = onPay
        )
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun Key(label: String, modifier: Modifier, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessHigh),
        label = "keyScale"
    )
    val tint = if (label == "C" || label == "⌫") Color(0xFFF1F5F9) else Color.White
    Surface(
        modifier = modifier.height(66.dp).scale(scale).clip(RoundedCornerShape(16.dp)),
        color = tint,
        interactionSource = interaction,
        onClick = onClick,
        shadowElevation = 1.dp
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                label,
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (label == "C" || label == "⌫") Muted else Ink
            )
        }
    }
}

@Composable
private fun PayingScreen(kopeks: Long, qr: Bitmap?, onCancel: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("${fmt(kopeks)} ₽", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink)
        Spacer(Modifier.height(6.dp))
        Text(
            "Покупатель сканирует QR банковским приложением",
            fontSize = 14.sp, color = Muted, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            if (qr != null) {
                Image(qr.asImageBitmap(), "СБП QR", Modifier.padding(18.dp).size(260.dp))
            } else {
                Box(Modifier.padding(18.dp).size(260.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Brand)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        PulsingWait()
        Spacer(Modifier.weight(1f))
        OutlinedButton(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Отменить", fontSize = 16.sp, color = Ink) }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun PulsingWait() {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "alpha"
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).alpha(a).clip(RoundedCornerShape(5.dp)).background(Brand))
        Spacer(Modifier.width(10.dp))
        Text("Ожидание оплаты…", fontSize = 16.sp, color = Ink, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DoneScreen(kopeks: Long, onNew: () -> Unit) {
    var show by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { show = true }
    val scale by animateFloatAsState(
        targetValue = if (show) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "check"
    )
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(104.dp).scale(scale).clip(RoundedCornerShape(52.dp))
                .background(Brush.verticalGradient(listOf(Ok, Color(0xFF15803D)))),
            contentAlignment = Alignment.Center
        ) { Text("✓", fontSize = 60.sp, color = Color.White, fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(22.dp))
        Text("Оплачено", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Ok)
        Spacer(Modifier.height(6.dp))
        Text("${fmt(kopeks)} ₽", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink)
        Spacer(Modifier.weight(1f))
        GradientButton("Новый платёж", listOf(Brand, BrandDark), Modifier.fillMaxWidth(), onClick = onNew)
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun GradientButton(
    text: String,
    colors: List<Color>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && enabled) 0.97f else 1f, label = "btn")
    Surface(
        modifier = modifier.height(58.dp).scale(scale).clip(RoundedCornerShape(16.dp)),
        color = Color.Transparent,
        enabled = enabled,
        interactionSource = interaction,
        onClick = onClick,
        shadowElevation = if (enabled) 3.dp else 0.dp
    ) {
        Box(
            Modifier.fillMaxSize().background(Brush.horizontalGradient(colors)),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }
    }
}
