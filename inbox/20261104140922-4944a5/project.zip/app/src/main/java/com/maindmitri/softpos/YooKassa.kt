package com.maindmitri.softpos

import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Клиент ЮKassa API v3. Серверный REST, поэтому вызывается нативно (без WebView/CORS).
 * Basic-авторизация: username = shopId, password = secretKey.
 */
object YooKassa {
    private const val BASE = "https://api.yookassa.ru/v3"

    data class Created(
        val id: String,
        val status: String,
        val qrData: String?,
        val confirmationUrl: String?
    )

    private fun auth(shopId: String, secretKey: String): String {
        val raw = "$shopId:$secretKey".toByteArray(Charsets.UTF_8)
        return "Basic " + Base64.encodeToString(raw, Base64.NO_WRAP)
    }

    private fun readBody(conn: HttpURLConnection): Pair<Int, String> {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        return code to text
    }

    /** Создаёт платёж с подтверждением по СБП-QR (confirmation.type = "qr"). */
    fun createPayment(shopId: String, secretKey: String, value: String, description: String): Created {
        val conn = (URL("$BASE/payments").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Authorization", auth(shopId, secretKey))
            setRequestProperty("Idempotence-Key", UUID.randomUUID().toString())
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            val body = JSONObject().apply {
                put("amount", JSONObject().apply {
                    put("value", value)
                    put("currency", "RUB")
                })
                put("capture", true)
                put("confirmation", JSONObject().apply { put("type", "qr") })
                put("description", description)
            }.toString()

            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val (code, text) = readBody(conn)
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).optString("description") }.getOrNull()
                throw RuntimeException(if (msg.isNullOrBlank()) "HTTP $code" else msg)
            }
            val json = JSONObject(text)
            val conf = json.optJSONObject("confirmation")
            return Created(
                id = json.getString("id"),
                status = json.getString("status"),
                qrData = conf?.optString("confirmation_data")?.ifBlank { null },
                confirmationUrl = conf?.optString("confirmation_url")?.ifBlank { null }
            )
        } finally {
            conn.disconnect()
        }
    }

    /** Возвращает статус платежа: pending | waiting_for_capture | succeeded | canceled. */
    fun status(shopId: String, secretKey: String, id: String): String {
        val conn = (URL("$BASE/payments/$id").openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Authorization", auth(shopId, secretKey))
        }
        try {
            val (code, text) = readBody(conn)
            if (code !in 200..299) throw RuntimeException("HTTP $code")
            return JSONObject(text).getString("status")
        } finally {
            conn.disconnect()
        }
    }
}
