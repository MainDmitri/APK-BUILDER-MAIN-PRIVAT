package com.maindmitri.softpos

import android.content.Context

/** Хранит реквизиты магазина ЮKassa в SharedPreferences. */
class Store(context: Context) {
    private val sp = context.getSharedPreferences("softpos", Context.MODE_PRIVATE)

    var shopId: String
        get() = sp.getString("shopId", "") ?: ""
        set(v) { sp.edit().putString("shopId", v.trim()).apply() }

    var secretKey: String
        get() = sp.getString("secretKey", "") ?: ""
        set(v) { sp.edit().putString("secretKey", v.trim()).apply() }

    val configured: Boolean get() = shopId.isNotBlank() && secretKey.isNotBlank()
}
