package com.faceswap.app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    // UI
    private lateinit var tvModelStatus: TextView
    private lateinit var pbModelDownload: ProgressBar
    private lateinit var vStatusDot: View
    private lateinit var ivSourceFace: ImageView
    private lateinit var ivVideoThumb: ImageView
    private lateinit var tvVideoInfo: TextView
    private lateinit var btnSelectSource: MaterialButton
    private lateinit var btnSelectVideo: MaterialButton
    private lateinit var btnProcess: MaterialButton
    private lateinit var layoutProgress: View
    private lateinit var pbProcess: ProgressBar
    private lateinit var tvProgressStatus: TextView
    private lateinit var tvProgressPercent: TextView
    private lateinit var layoutResult: View
    private lateinit var btnSave: MaterialButton
    private lateinit var btnShare: MaterialButton

    // Данные
    private var sourceBitmap: Bitmap? = null
    private var videoFile: File? = null
    private var resultFile: File? = null
    private var modelsReady = false

    // --- Пикеры файлов ---

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        loadSourceImage(uri)
    }

    private val pickVideoLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        loadVideo(uri)
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms.values.all { it }) {
            checkAndDownloadModels()
        } else {
            tvModelStatus.text = "Разрешения не выданы"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupListeners()
        requestPermissionsAndInit()
    }

    private fun bindViews() {
        tvModelStatus    = findViewById(R.id.tvModelStatus)
        pbModelDownload  = findViewById(R.id.pbModelDownload)
        vStatusDot       = findViewById(R.id.vStatusDot)
        ivSourceFace     = findViewById(R.id.ivSourceFace)
        ivVideoThumb     = findViewById(R.id.ivVideoThumb)
        tvVideoInfo      = findViewById(R.id.tvVideoInfo)
        btnSelectSource  = findViewById(R.id.btnSelectSource)
        btnSelectVideo   = findViewById(R.id.btnSelectVideo)
        btnProcess       = findViewById(R.id.btnProcess)
        layoutProgress   = findViewById(R.id.layoutProgress)
        pbProcess        = findViewById(R.id.pbProcess)
        tvProgressStatus = findViewById(R.id.tvProgressStatus)
        tvProgressPercent= findViewById(R.id.tvProgressPercent)
        layoutResult     = findViewById(R.id.layoutResult)
        btnSave          = findViewById(R.id.btnSave)
        btnShare         = findViewById(R.id.btnShare)
    }

    private fun setupListeners() {
        btnSelectSource.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        btnSelectVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }
        btnProcess.setOnClickListener {
            startProcessing()
        }
        btnSave.setOnClickListener {
            saveToGallery()
        }
        btnShare.setOnClickListener {
            shareResult()
        }
    }

    private fun requestPermissionsAndInit() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (needed.isEmpty()) {
            checkAndDownloadModels()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun checkAndDownloadModels() {
        if (ModelManager.areModelsReady(this)) {
            modelsReady = true
            tvModelStatus.text = getString(R.string.models_ready)
            vStatusDot.setBackgroundResource(R.drawable.bg_dot_success)
            updateProcessButton()
            return
        }

        tvModelStatus.text = "Загрузка AI моделей (~700 МБ)…"
        pbModelDownload.visibility = View.VISIBLE
        pbModelDownload.progress = 0

        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ModelManager.downloadModels(this@MainActivity) { name, pct ->
                        runOnUiThread {
                            tvModelStatus.text = "Загрузка $name ($pct%)"
                            pbModelDownload.progress = pct
                        }
                    }
                }
                modelsReady = true
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = getString(R.string.models_ready)
                vStatusDot.setBackgroundResource(R.drawable.bg_dot_success)
                updateProcessButton()
            } catch (e: ModelManager.ManualDownloadRequired) {
                // Все зеркала недоступны — показываем инструкцию
                Log.e(TAG, "Все зеркала недоступны")
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = "⚠ Сеть недоступна — нужна ручная установка"
                showManualDownloadDialog(e.instructions)
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка загрузки моделей", e)
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = "Ошибка: ${e.message}\nНажмите «Проверить» после устранения"
                // Кнопка повтора
                btnProcess.text = "Проверить модели"
                btnProcess.isEnabled = true
                btnProcess.setOnClickListener {
                    btnProcess.text = getString(R.string.process)
                    btnProcess.isEnabled = false
                    btnProcess.setOnClickListener { startProcessing() }
                    checkAndDownloadModels()
                }
            }
        }
    }

    private fun showManualDownloadDialog(instructions: String) {
        runOnUiThread {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Ручная установка моделей")
                .setMessage(instructions)
                .setPositiveButton("Проверить модели") { _, _ ->
                    checkAndDownloadModels()
                }
                .setNeutralButton("Копировать инструкцию") { _, _ ->
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                        as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("Инструкция", instructions)
                    )
                    Toast.makeText(this, "Скопировано в буфер обмена", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Закрыть", null)
                .show()
        }
    }

    private fun loadSourceImage(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Шаг 1: читаем угол EXIF до декодирования bitmap
                val degrees: Float = try {
                    contentResolver.openInputStream(uri)?.use { s ->
                        val exif = ExifInterface(s)
                        when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90  -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (e: Exception) {
                    Log.w(TAG, "EXIF read failed: ${e.message}")
                    0f
                }

                // Шаг 2: декодируем bitmap (отдельный stream)
                val raw: Bitmap? = contentResolver.openInputStream(uri)?.use { s ->
                    BitmapFactory.decodeStream(s)
                }
                if (raw == null) {
                    Log.e(TAG, "decodeStream вернул null для $uri")
                    withContext(Dispatchers.Main) {
                        Toast.makeText(this@MainActivity, "Не удалось декодировать фото", Toast.LENGTH_LONG).show()
                    }
                    return@launch
                }

                // Шаг 3: поворачиваем если нужно — исходник НЕ рециклируем
                val final: Bitmap = if (degrees != 0f) {
                    val m = Matrix().apply { postRotate(degrees) }
                    Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                    // raw остаётся живым — GC соберёт
                } else raw

                withContext(Dispatchers.Main) {
                    sourceBitmap = final
                    ivSourceFace.setImageBitmap(final)
                    updateProcessButton()
                }
            } catch (e: Exception) {
                Log.e(TAG, "loadSourceImage failed", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Ошибка фото: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun loadVideo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Копируем видео в cache (нужен путь для FFmpeg)
                val tmpFile = File(cacheDir, "input_video_${System.currentTimeMillis()}.mp4")
                contentResolver.openInputStream(uri)?.use { inp ->
                    FileOutputStream(tmpFile).use { out ->
                        inp.copyTo(out)
                    }
                }

                // Получаем превью
                val thumb = ThumbnailUtils.createVideoThumbnail(
                    tmpFile.absolutePath,
                    android.provider.MediaStore.Images.Thumbnails.MINI_KIND
                )

                val sizeMb = tmpFile.length() / 1_048_576
                val info = "${sizeMb} МБ"

                withContext(Dispatchers.Main) {
                    videoFile = tmpFile
                    thumb?.let { ivVideoThumb.setImageBitmap(it) }
                    tvVideoInfo.text = info
                    updateProcessButton()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Ошибка загрузки видео", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun updateProcessButton() {
        btnProcess.isEnabled = modelsReady && sourceBitmap != null && videoFile != null
    }

    private fun startProcessing() {
        val src = sourceBitmap ?: return
        val vid = videoFile ?: return

        btnProcess.isEnabled = false
        btnSelectSource.isEnabled = false
        btnSelectVideo.isEnabled = false
        layoutResult.visibility = View.GONE
        layoutProgress.visibility = View.VISIBLE
        pbProcess.progress = 0
        tvProgressPercent.text = "0%"
        tvProgressStatus.text = "Инициализация…"

        val processor = VideoProcessor(this)

        lifecycleScope.launch {
            try {
                val result = processor.process(vid, src) { pct, status ->
                    runOnUiThread {
                        pbProcess.progress = pct
                        tvProgressStatus.text = status
                        tvProgressPercent.text = "$pct%"
                    }
                }
                resultFile = result.outputFile
                withContext(Dispatchers.Main) {
                    layoutProgress.visibility = View.GONE
                    layoutResult.visibility = View.VISIBLE
                    Toast.makeText(this@MainActivity, "Готово!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка обработки", e)
                withContext(Dispatchers.Main) {
                    layoutProgress.visibility = View.GONE
                    Toast.makeText(
                        this@MainActivity,
                        "Ошибка: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    btnProcess.isEnabled = true
                    btnSelectSource.isEnabled = true
                    btnSelectVideo.isEnabled = true
                }
            }
        }
    }

    private fun saveToGallery() {
        val f = resultFile ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/FaceSwapAI")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let { dest ->
                    contentResolver.openOutputStream(dest)?.use { out ->
                        f.inputStream().use { inp -> inp.copyTo(out) }
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Сохранено в галерею", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Ошибка сохранения: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun shareResult() {
        val f = resultFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Поделиться видео"))
    }
}
