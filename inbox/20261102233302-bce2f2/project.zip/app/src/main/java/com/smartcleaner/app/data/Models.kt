package com.smartcleaner.app.data

/** Описание одного файла, найденного при сканировании. */
data class FileInfo(
    val path: String,
    val name: String,
    val size: Long,
    val lastModified: Long,
    val width: Int = 0,
    val height: Int = 0,
    val textLength: Int = 0
) {
    val extension: String
        get() = name.substringAfterLast('.', "").lowercase()

    val parentPath: String
        get() = path.substringBeforeLast('/', "")
}

enum class JunkCategory(val title: String, val description: String) {
    EMPTY_FOLDER("Пустые папки", "Папки без файлов внутри"),
    EMPTY_FILE("Пустые файлы", "Файлы размером 0 байт"),
    TEMP("Временные и журналы", "Файлы .tmp, .temp, .log, .bak, .old, недокачанные загрузки"),
    THUMBNAILS("Кэш миниатюр", "Папки .thumbnails — система создаст их заново"),
    APK("APK-установщики", "Установочные файлы в «Загрузках»"),
    LARGE_OLD("Большие старые файлы", "Только рекомендация: проверьте перед удалением")
}

data class JunkItem(
    val file: FileInfo,
    val category: JunkCategory,
    val isDirectory: Boolean = false,
    val note: String = "",
    /** Отмечать ли элемент для удаления по умолчанию. */
    val defaultSelected: Boolean = true,
    /** Вердикт ИИ: true — мусор, false — важно, null — не проверялось. */
    val aiJunk: Boolean? = null,
    val aiReason: String = ""
)

enum class GroupType(val title: String) {
    EXACT("Точные дубликаты"),
    SIMILAR_IMAGE("Похожие изображения"),
    SIMILAR_TEXT("Похожие тексты"),
    VERSIONS("Версии одного файла")
}

data class FileGroup(
    val id: Long,
    val type: GroupType,
    val files: List<FileInfo>,
    val keeperIndex: Int,
    val keeperReasons: List<String>,
    val scores: List<Int>,
    val similarityNote: String = "",
    val aiReason: String = "",
    val aiChosen: Boolean = false,
    /** Пути файлов, отмеченных для удаления. Основной файл здесь никогда не бывает. */
    val selected: Set<String> = emptySet()
) {
    val keeper: FileInfo get() = files[keeperIndex]

    val selectedBytes: Long
        get() = files.filter { it.path in selected && it.path != keeper.path }.sumOf { it.size }

    val reclaimableBytes: Long
        get() = files.filterIndexed { i, _ -> i != keeperIndex }.sumOf { it.size }
}

data class ScanResult(
    val finishedAt: Long,
    val filesScanned: Int,
    val junk: List<JunkItem>,
    val groups: List<FileGroup>
) {
    val duplicateGroups: List<FileGroup> get() = groups.filter { it.type == GroupType.EXACT }
    val similarGroups: List<FileGroup> get() = groups.filter { it.type != GroupType.EXACT }
}

data class ScanProgress(
    val phase: String = "",
    val filesFound: Int = 0,
    val current: String = "",
    /** 0..1 или отрицательное значение, если прогресс неопределённый. */
    val fraction: Float = -1f
)

data class TrashEntry(
    val id: Long,
    val originalPath: String,
    val trashPath: String,
    val size: Long,
    val deletedAt: Long,
    val isDirectory: Boolean
) {
    val name: String get() = originalPath.substringAfterLast('/')
}

data class LastScanSummary(
    val time: Long,
    val filesScanned: Int,
    val junkCount: Int,
    val junkBytes: Long,
    val duplicateGroups: Int,
    val duplicateBytes: Long,
    val similarGroups: Int,
    val similarBytes: Long
)
