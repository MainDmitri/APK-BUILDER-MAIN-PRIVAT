package com.smartcleaner.app.ui

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes Б"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(Locale.forLanguageTag("ru"), "%.1f КБ", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.forLanguageTag("ru"), "%.1f МБ", mb)
    val gb = mb / 1024.0
    return String.format(Locale.forLanguageTag("ru"), "%.2f ГБ", gb)
}

fun formatDate(ms: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.forLanguageTag("ru")).format(Date(ms))

fun maskKey(key: String): String =
    if (key.length <= 8) "•".repeat(key.length) else key.take(4) + "•".repeat(8) + key.takeLast(4)
