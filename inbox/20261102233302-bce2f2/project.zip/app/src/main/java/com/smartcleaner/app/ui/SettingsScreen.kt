package com.smartcleaner.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    var showKey by remember { mutableStateOf(false) }
    var showConsent by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            AppTopBar(title = "Настройки", onBack = {
                vm.saveSettings(showMessage = false)
                vm.back()
            })
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------- ИИ ----------
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("ИИ Google Gemini", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Использовать ИИ", modifier = Modifier.weight(1f))
                        Switch(
                            checked = vm.aiEnabled,
                            onCheckedChange = { on ->
                                if (on && !vm.aiConsent) {
                                    showConsent = true
                                } else {
                                    vm.aiEnabled = on
                                    vm.saveSettings(showMessage = false)
                                }
                            }
                        )
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Row(Modifier.padding(10.dp)) {
                            Icon(Icons.Filled.Warning, contentDescription = null)
                            Text(
                                "Когда ИИ включён, имена файлов, папки, даты, короткие фрагменты текстов и уменьшенные копии изображений " +
                                    "отправляются в Google (Gemini API) только по вашей команде. Без ИИ всё работает локально.",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                    OutlinedTextField(
                        value = vm.apiKey,
                        onValueChange = { vm.apiKey = it.trim() },
                        label = { Text("Ключ Gemini API") },
                        placeholder = { Text("Вставьте ключ из Google AI Studio") },
                        singleLine = true,
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { showKey = !showKey }) {
                                Icon(Icons.Filled.Lock, contentDescription = if (showKey) "Скрыть ключ" else "Показать ключ")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (vm.settings.apiKey.isNotEmpty()) {
                        Text("Сохранён ключ: ${maskKey(vm.settings.apiKey)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))
                                )
                            } catch (e: Exception) {
                                vm.message = "Откройте aistudio.google.com/app/apikey в браузере"
                            }
                        }) { Text("Получить ключ") }
                        TextButton(onClick = { vm.clearApiKey() }) { Text("Удалить ключ") }
                    }
                    OutlinedTextField(
                        value = vm.model,
                        onValueChange = { vm.model = it.trim() },
                        label = { Text("Модель") },
                        supportingText = { Text("По умолчанию gemini-2.5-flash") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Отправлять уменьшенные фото (для выбора лучшего снимка)", modifier = Modifier.weight(1f))
                        Switch(checked = vm.aiSendImages, onCheckedChange = { vm.aiSendImages = it })
                    }
                    if (vm.aiConsent) {
                        TextButton(onClick = {
                            vm.aiConsent = false
                            vm.aiEnabled = false
                            vm.saveSettings(showMessage = false)
                        }) { Text("Отозвать согласие на отправку данных") }
                    }
                }
            }

            // ---------- Пороги ----------
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Чувствительность поиска", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Похожие изображения: расстояние ≤ ${vm.imageThreshold} из 64 бит")
                    Slider(
                        value = vm.imageThreshold.toFloat(),
                        onValueChange = { vm.imageThreshold = it.roundToInt() },
                        valueRange = 0f..16f,
                        steps = 15
                    )
                    Text("Меньше — строже (только почти одинаковые снимки).", style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider()
                    Text("Похожие тексты: сходство ≥ ${vm.textThreshold}%")
                    Slider(
                        value = vm.textThreshold.toFloat(),
                        onValueChange = { vm.textThreshold = it.roundToInt() },
                        valueRange = 50f..99f
                    )
                    HorizontalDivider()
                    NumberField("Большой файл, от (МБ)", vm.largeFileMb) { vm.largeFileMb = it }
                    NumberField("Старый файл, не изменялся (дней)", vm.oldFileDays) { vm.oldFileDays = it }
                    NumberField("Хранить в корзине (дней)", vm.trashDays) { vm.trashDays = it }
                }
            }

            // ---------- Исключения ----------
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Исключённые папки", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "По одной папке на строку, например: DCIM/Camera или /storage/emulated/0/Documents/Работа. " +
                            "Android/data и Android/obb пропускаются всегда.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = vm.excludedFolders,
                        onValueChange = { vm.excludedFolders = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        placeholder = { Text("Telegram\nDocuments/Важное") }
                    )
                }
            }

            Button(onClick = { vm.saveSettings() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Отправка данных в Google") },
            text = {
                Text(
                    "Для работы ИИ приложение отправит в Google Gemini API метаданные файлов (имя, папка, размер, дата), " +
                        "фрагменты текстов до 1200 символов и уменьшенные копии изображений (если разрешено). " +
                        "Данные отправляются только когда вы нажимаете кнопки ИИ. Используется ваш личный ключ API. " +
                        "Ничего не удаляется без вашего подтверждения."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.aiConsent = true
                    vm.aiEnabled = true
                    vm.saveSettings(showMessage = false)
                    showConsent = false
                }) { Text("Согласен") }
            },
            dismissButton = { TextButton(onClick = { showConsent = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(6)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
}
