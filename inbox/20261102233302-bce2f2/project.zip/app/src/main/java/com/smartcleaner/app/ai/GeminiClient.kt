package com.smartcleaner.app.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.GroupType
import com.smartcleaner.app.data.JunkItem
import com.smartcleaner.app.scan.Hashing
import com.smartcleaner.app.scan.Scanner
import com.smartcleaner.app.scan.TextSimilarity
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GeminiException(message: String) : Exception(message)

/**
 * Клиент Google Gemini (REST generateContent) на HttpURLConnection + org.json.
 * Ключ передаётся только в заголовке x-goog-api-key.
 */
class GeminiClient(
    private val apiKey: String,
    private val model: String,
    private val sendImages: Boolean
) {

    data class KeepDecision(val keepIndex: Int, val reason: String)
    data class JunkVerdict(val index: Int, val junk: Boolean, val reason: String)

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT)

    /** Спрашивает, какой файл группы самый актуальный и полный. */
    fun chooseKeeper(group: FileGroup): KeepDecision {
        val parts = JSONArray()
        val sb = StringBuilder()
        sb.append("Ты помощник приложения-очистителя памяти Android. Перед тобой группа файлов, которые являются ")
        sb.append(
            when (group.type) {
                GroupType.EXACT -> "точными копиями друг друга"
                GroupType.SIMILAR_IMAGE -> "визуально похожими изображениями"
                GroupType.SIMILAR_TEXT -> "похожими по содержанию текстами"
                GroupType.VERSIONS -> "вероятными версиями одного документа"
            }
        )
        sb.append(". Нужно выбрать ОДИН файл, который стоит оставить: самый актуальный, полный и качественный. ")
        sb.append("Учитывай дату изменения, полноту содержания, разрешение, папку и имя файла (копии вида «(1)», «copy» хуже). ")
        sb.append("Ответь строго JSON-объектом {\"keepIndex\": <номер файла>, \"reason\": \"<кратко по-русски, до 200 символов>\"}.\n\n")
        sb.append("Файлы:\n")
        var imagesAdded = 0
        group.files.forEachIndexed { i, f ->
            sb.append("#").append(i).append(": имя=\"").append(f.name).append("\"")
            sb.append(", папка=\"").append(f.parentPath.takeLast(120)).append("\"")
            sb.append(", размер=").append(f.size).append(" байт")
            sb.append(", изменён=").append(dateFormat.format(Date(f.lastModified)))
            if (f.width > 0) sb.append(", разрешение=").append(f.width).append("x").append(f.height)
            if (f.textLength > 0) sb.append(", длина_текста=").append(f.textLength)
            sb.append("\n")
            val ext = f.extension
            if (ext in Scanner.TEXT_EXT || ext in setOf("txt", "md", "csv")) {
                val excerpt = TextSimilarity.readText(File(f.path), 1200)
                if (!excerpt.isNullOrBlank()) {
                    sb.append("Начало файла #").append(i).append(":\n<<<\n").append(excerpt).append("\n>>>\n")
                }
            }
        }
        parts.put(JSONObject().put("text", sb.toString()))
        if (sendImages) {
            group.files.forEachIndexed { i, f ->
                if (imagesAdded < 4 && f.extension in Scanner.IMAGE_EXT) {
                    val b64 = downscaledJpegBase64(File(f.path), 384)
                    if (b64 != null) {
                        parts.put(JSONObject().put("text", "Изображение файла #$i:"))
                        parts.put(
                            JSONObject().put(
                                "inline_data",
                                JSONObject().put("mime_type", "image/jpeg").put("data", b64)
                            )
                        )
                        imagesAdded++
                    }
                }
            }
        }
        val text = generate(parts)
        val obj = parseJsonObject(text)
        val idx = obj.optInt("keepIndex", -1)
        if (idx !in group.files.indices) throw GeminiException("ИИ вернул некорректный номер файла")
        val reason = obj.optString("reason", "").ifBlank { "Выбран ИИ" }
        return KeepDecision(idx, reason.take(300))
    }

    /** Классифицирует сомнительные файлы: мусор или важное. */
    fun classify(items: List<JunkItem>): List<JunkVerdict> {
        val sb = StringBuilder()
        sb.append("Ты помощник приложения-очистителя памяти Android. Для каждого файла реши, является ли он мусором, ")
        sb.append("который можно безопасно удалить (junk=true), или его стоит сохранить (junk=false). ")
        sb.append("Будь осторожен: личные документы, фото, резервные копии чатов и ключи считаются важными. ")
        sb.append("Ответь строго JSON-массивом объектов {\"index\": <номер>, \"junk\": true|false, \"reason\": \"<кратко по-русски>\"}.\n\n")
        items.forEachIndexed { i, it ->
            val f = it.file
            sb.append("#").append(i).append(": путь=\"").append(f.path.takeLast(160)).append("\"")
            sb.append(", размер=").append(f.size).append(" байт")
            sb.append(", изменён=").append(dateFormat.format(Date(f.lastModified)))
            sb.append(", категория=\"").append(it.category.title).append("\"")
            if (it.note.isNotBlank()) sb.append(", заметка=\"").append(it.note).append("\"")
            sb.append("\n")
        }
        val parts = JSONArray().put(JSONObject().put("text", sb.toString()))
        val text = generate(parts)
        val arr = parseJsonArray(text)
        val result = ArrayList<JunkVerdict>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val idx = o.optInt("index", -1)
            if (idx !in items.indices) continue
            result.add(JunkVerdict(idx, o.optBoolean("junk", false), o.optString("reason", "").take(300)))
        }
        return result
    }

    private fun generate(parts: JSONArray): String {
        if (apiKey.isBlank()) throw GeminiException("Не указан ключ Gemini API (Настройки)")
        val safeModel = URLEncoder.encode(model.trim().removePrefix("models/"), "UTF-8")
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$safeModel:generateContent")
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("responseMimeType", "application/json")
            )
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey.trim())
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val response = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val apiMsg = runCatching {
                    JSONObject(response).optJSONObject("error")?.optString("message")
                }.getOrNull().orEmpty()
                throw GeminiException(
                    when (code) {
                        400 -> "Неверный запрос или ключ: ${apiMsg.take(160)}"
                        401, 403 -> "Ключ API отклонён (проверьте ключ в Настройках)"
                        404 -> "Модель «$model» не найдена"
                        429 -> "Превышена квота Gemini. Попробуйте позже"
                        in 500..599 -> "Сервер Gemini временно недоступен ($code)"
                        else -> "Ошибка Gemini $code: ${apiMsg.take(160)}"
                    }
                )
            }
            return extractText(response)
        } catch (e: GeminiException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw GeminiException("Превышено время ожидания ответа Gemini")
        } catch (e: UnknownHostException) {
            throw GeminiException("Нет подключения к интернету")
        } catch (e: Exception) {
            throw GeminiException("Сбой связи с Gemini: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn.disconnect()
        }
    }

    private fun extractText(response: String): String {
        val root = try {
            JSONObject(response)
        } catch (e: Exception) {
            throw GeminiException("Некорректный ответ Gemini")
        }
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            throw GeminiException(if (block.isNotEmpty()) "Запрос заблокирован фильтром: $block" else "Пустой ответ Gemini")
        }
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: throw GeminiException("Пустой ответ Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.optJSONObject(i) ?: continue
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text", ""))
        }
        if (sb.isBlank()) throw GeminiException("Пустой ответ Gemini")
        return sb.toString()
    }

    private fun stripFences(text: String): String {
        var t = text.trim()
        if (t.startsWith("```")) {
            t = t.substringAfter('\n', t).substringBeforeLast("```").trim()
        }
        return t
    }

    private fun parseJsonObject(text: String): JSONObject {
        val t = stripFences(text)
        return try {
            JSONObject(t)
        } catch (e: Exception) {
            val start = t.indexOf('{')
            val end = t.lastIndexOf('}')
            if (start >= 0 && end > start) {
                try {
                    JSONObject(t.substring(start, end + 1))
                } catch (e2: Exception) {
                    throw GeminiException("ИИ вернул ответ не в формате JSON")
                }
            } else {
                throw GeminiException("ИИ вернул ответ не в формате JSON")
            }
        }
    }

    private fun parseJsonArray(text: String): JSONArray {
        val t = stripFences(text)
        return try {
            JSONArray(t)
        } catch (e: Exception) {
            val start = t.indexOf('[')
            val end = t.lastIndexOf(']')
            if (start >= 0 && end > start) {
                try {
                    JSONArray(t.substring(start, end + 1))
                } catch (e2: Exception) {
                    throw GeminiException("ИИ вернул ответ не в формате JSON")
                }
            } else {
                // Иногда модель оборачивает массив в объект.
                val obj = runCatching { JSONObject(t) }.getOrNull()
                val keys = obj?.keys()
                if (obj != null && keys != null) {
                    while (keys.hasNext()) {
                        val arr = obj.optJSONArray(keys.next())
                        if (arr != null) return arr
                    }
                }
                throw GeminiException("ИИ вернул ответ не в формате JSON")
            }
        }
    }

    private fun downscaledJpegBase64(file: File, maxSide: Int): String? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            null
        } else {
            val opts = BitmapFactory.Options().apply {
                inSampleSize = Hashing.sampleSizeFor(bounds.outWidth, bounds.outHeight, maxSide)
            }
            val bmp = BitmapFactory.decodeFile(file.absolutePath, opts)
            if (bmp == null) {
                null
            } else {
                val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
                val scaled = if (scale < 1f) {
                    Bitmap.createScaledBitmap(
                        bmp,
                        (bmp.width * scale).toInt().coerceAtLeast(1),
                        (bmp.height * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    bmp
                }
                val out = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 70, out)
                if (scaled !== bmp) scaled.recycle()
                bmp.recycle()
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
        }
    } catch (e: Throwable) {
        null
    }
}
