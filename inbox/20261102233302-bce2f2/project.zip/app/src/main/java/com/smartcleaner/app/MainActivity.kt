package com.smartcleaner.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.smartcleaner.app.ui.MainViewModel
import com.smartcleaner.app.ui.SmartCleanerApp
import com.smartcleaner.app.ui.SmartCleanerTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        viewModel.refreshPermission()
        setContent {
            SmartCleanerTheme {
                SmartCleanerApp(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Пользователь мог выдать доступ ко всем файлам в системных настройках.
        viewModel.refreshPermission()
    }
}
