package com.smartcleaner.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen(vm: MainViewModel) {
    val context = LocalContext.current

    val manageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        vm.refreshPermission()
    }
    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        vm.refreshPermission()
        if (result.values.any { !it }) vm.message = "Без доступа к памяти очистка невозможна"
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val intent = Intent(
                Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            try {
                manageLauncher.launch(intent)
            } catch (e: Exception) {
                try {
                    manageLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: Exception) {
                    vm.message = "Откройте настройки и разрешите доступ ко всем файлам вручную"
                }
            }
        } else {
            legacyLauncher.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    Scaffold(
        topBar = {
            AppTopBar(title = "Умный Cleaner", actions = {
                IconButton(onClick = { vm.navigate(Screen.Trash) }) {
                    Icon(Icons.Filled.Delete, contentDescription = "Корзина")
                }
                IconButton(onClick = { vm.navigate(Screen.Settings) }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Настройки")
                }
            })
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            StorageCard(vm)

            if (!vm.hasPermission) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Нужен доступ к файлам", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                                "Чтобы найти мусор и дубликаты во всей памяти, разрешите «Доступ ко всем файлам» на следующем экране."
                            else
                                "Разрешите приложению доступ к памяти устройства."
                        )
                        Button(onClick = { requestAccess() }) { Text("Предоставить доступ") }
                    }
                }
            }

            if (vm.scanning) {
                ScanProgressCard(vm)
            } else {
                Button(
                    onClick = { vm.startScan() },
                    enabled = vm.hasPermission,
                    modifier = Modifier.fillMaxWidth().height(56.dp)
                ) {
                    Icon(Icons.Filled.Search, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Сканировать память")
                }
            }

            if (vm.hasResults && !vm.scanning) {
                OutlinedButton(onClick = { vm.navigate(Screen.Results) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Открыть результаты")
                }
            }

            SummaryCard(vm)

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Как это работает", fontWeight = FontWeight.Bold)
                    Text("• Мусор: пустые папки и файлы, временные файлы, журналы, кэш миниатюр, ненужные APK.")
                    Text("• Дубликаты: сравнение размера, быстрого и полного хэша SHA-256.")
                    Text("• Похожие: перцептивный хэш фото, сходство текстов и версии одного документа.")
                    Text("• Для каждой группы оставляется самый актуальный файл — с объяснением выбора.")
                    Text("• Удалённое сначала попадает в корзину приложения и может быть восстановлено.")
                    Text(
                        if (vm.aiAvailable) "• ИИ Google Gemini включён и помогает выбирать файлы."
                        else "• ИИ Google Gemini можно включить в Настройках (нужен ваш ключ API).",
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun StorageCard(vm: MainViewModel) {
    val total = vm.storageTotal
    val used = (total - vm.storageFree).coerceAtLeast(0L)
    val fraction = if (total > 0) used.toFloat() / total else 0f
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Память устройства", fontWeight = FontWeight.Bold)
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier.fillMaxWidth().height(10.dp)
            )
            Text("Занято ${formatSize(used)} из ${formatSize(total)} • свободно ${formatSize(vm.storageFree)}")
            if (vm.trashSize > 0) {
                Text(
                    "В корзине приложения: ${formatSize(vm.trashSize)}",
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

@Composable
private fun ScanProgressCard(vm: MainViewModel) {
    val p = vm.progress
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 3.dp)
                Spacer(Modifier.width(12.dp))
                Text(p.phase.ifEmpty { "Сканирование" }, fontWeight = FontWeight.Bold)
            }
            if (p.fraction >= 0f) {
                LinearProgressIndicator(progress = { p.fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            Text("Найдено файлов: ${p.filesFound}")
            if (p.current.isNotEmpty()) {
                Text(
                    p.current,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            OutlinedButton(onClick = { vm.cancelScan() }) { Text("Остановить") }
        }
    }
}

@Composable
private fun SummaryCard(vm: MainViewModel) {
    val s = vm.summary ?: return
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Последнее сканирование", fontWeight = FontWeight.Bold)
            Text(formatDate(s.time) + " • проверено файлов: ${s.filesScanned}", style = MaterialTheme.typography.bodySmall)
            Text("Мусор: ${s.junkCount} (${formatSize(s.junkBytes)})")
            Text("Группы дубликатов: ${s.duplicateGroups} (можно освободить ${formatSize(s.duplicateBytes)})")
            Text("Похожие и версии: ${s.similarGroups} (до ${formatSize(s.similarBytes)})")
            if (!vm.hasResults) {
                Text(
                    "Запустите сканирование, чтобы увидеть подробности.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
