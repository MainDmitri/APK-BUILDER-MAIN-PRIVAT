package com.smartcleaner.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.TrashEntry

@Composable
fun TrashScreen(vm: MainViewModel) {
    LaunchedEffect(Unit) { vm.refreshTrash() }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmEntry by remember { mutableStateOf<TrashEntry?>(null) }

    Scaffold(
        topBar = { AppTopBar(title = "Корзина", onBack = { vm.back() }) },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("В корзине: ${vm.trashEntries.size} • ${formatSize(vm.trashSize)}", fontWeight = FontWeight.Bold)
                        Text(
                            "Файлы хранятся ${vm.settings.trashDays} дн., затем удаляются навсегда автоматически. Срок меняется в Настройках.",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Button(
                            onClick = { confirmEmpty = true },
                            enabled = vm.trashEntries.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) { Text("Очистить корзину навсегда") }
                    }
                }
            }
            if (vm.trashEntries.isEmpty()) {
                item { EmptyState("Корзина пуста") }
            }
            items(vm.trashEntries, key = { it.id }) { e ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        FileThumbnail(e.trashPath, if (e.isDirectory) "DIR" else e.name.substringAfterLast('.', ""), 48.dp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                e.originalPath.substringBeforeLast('/'),
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text("${formatSize(e.size)} • удалён ${formatDate(e.deletedAt)}", style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { vm.restore(e) }) { Text("Восстановить") }
                                OutlinedButton(onClick = { confirmEntry = e }) { Text("Удалить") }
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.size(24.dp)) }
        }
    }

    if (confirmEmpty) {
        ConfirmDialog(
            title = "Очистить корзину?",
            text = "Все ${vm.trashEntries.size} файлов (${formatSize(vm.trashSize)}) будут удалены без возможности восстановления.",
            confirmText = "Удалить навсегда",
            onConfirm = { vm.emptyTrash() },
            onDismiss = { confirmEmpty = false }
        )
    }
    confirmEntry?.let { e ->
        ConfirmDialog(
            title = "Удалить навсегда?",
            text = "«${e.name}» будет удалён без возможности восстановления.",
            confirmText = "Удалить",
            onConfirm = { vm.deleteForever(e) },
            onDismiss = { confirmEntry = null }
        )
    }
}
