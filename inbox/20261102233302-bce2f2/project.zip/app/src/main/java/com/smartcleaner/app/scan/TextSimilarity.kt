package com.smartcleaner.app.scan

import java.io.File
import java.io.InputStreamReader
import java.nio.charset.Charset

/**
 * Сходство текстов: нормализация → словесные шинглы по 3 слова → MinHash-сигнатура.
 * Доля совпавших позиций сигнатуры оценивает коэффициент Жаккара.
 */
object TextSimilarity {

    const val SIGNATURE_SIZE = 96
    private const val MAX_CHARS = 300_000
    private const val PRIME = 2_147_483_647L // 2^31 - 1

    private val coefA = LongArray(SIGNATURE_SIZE)
    private val coefB = LongArray(SIGNATURE_SIZE)

    init {
        val rnd = java.util.Random(0x5EED_C1EAL)
        for (i in 0 until SIGNATURE_SIZE) {
            coefA[i] = 1L + (rnd.nextLong() ushr 1) % (PRIME - 1)
            coefB[i] = (rnd.nextLong() ushr 1) % PRIME
        }
    }

    data class TextFingerprint(val signature: IntArray, val normalizedLength: Int, val excerpt: String)

    fun readText(file: File, maxChars: Int = MAX_CHARS): String? = try {
        InputStreamReader(file.inputStream(), Charset.forName("UTF-8")).use { reader ->
            val buf = CharArray(8192)
            val sb = StringBuilder()
            while (sb.length < maxChars) {
                val n = reader.read(buf, 0, minOf(buf.size, maxChars - sb.length))
                if (n < 0) break
                sb.append(buf, 0, n)
            }
            sb.toString()
        }
    } catch (e: Exception) {
        null
    }

    fun normalize(text: String): String {
        val sb = StringBuilder(text.length)
        var lastSpace = true
        for (ch in text) {
            if (ch.isLetterOrDigit()) {
                sb.append(ch.lowercaseChar())
                lastSpace = false
            } else if (!lastSpace) {
                sb.append(' ')
                lastSpace = true
            }
        }
        return sb.toString().trim()
    }

    fun fingerprint(file: File): TextFingerprint? {
        val raw = readText(file) ?: return null
        // Бинарные файлы с текстовым расширением отбрасываем.
        val sampleLen = minOf(raw.length, 4000)
        if (sampleLen > 0) {
            var bad = 0
            for (i in 0 until sampleLen) {
                val c = raw[i]
                if (c == '\uFFFD' || (c < ' ' && c != '\n' && c != '\r' && c != '\t')) bad++
            }
            if (bad * 10 > sampleLen) return null
        }
        val norm = normalize(raw)
        if (norm.length < 20) return null
        val words = norm.split(' ')
        val shingles = HashSet<Int>()
        if (words.size < 3) {
            shingles.add(norm.hashCode())
        } else {
            for (i in 0..words.size - 3) {
                shingles.add((words[i] + " " + words[i + 1] + " " + words[i + 2]).hashCode())
            }
        }
        val sig = IntArray(SIGNATURE_SIZE) { Int.MAX_VALUE }
        for (s in shingles) {
            val x = (s.toLong() and 0xFFFFFFFFL)
            for (i in 0 until SIGNATURE_SIZE) {
                val h = ((coefA[i] * (x % PRIME) + coefB[i]) % PRIME).toInt()
                if (h < sig[i]) sig[i] = h
            }
        }
        val excerpt = raw.take(1500)
        return TextFingerprint(sig, norm.length, excerpt)
    }

    fun similarity(a: IntArray, b: IntArray): Double {
        var same = 0
        for (i in a.indices) if (a[i] == b[i]) same++
        return same.toDouble() / a.size
    }

    /** Ключи LSH-корзин: 24 полосы по 4 строки. Пары, совпавшие хотя бы в одной полосе, — кандидаты. */
    fun bandKeys(sig: IntArray): List<Long> {
        val rows = 4
        val bands = SIGNATURE_SIZE / rows
        val keys = ArrayList<Long>(bands)
        for (b in 0 until bands) {
            var h = 1125899906842597L
            for (r in 0 until rows) h = 31L * h + sig[b * rows + r]
            keys.add(h * 131L + b)
        }
        return keys
    }
}
