package com.smartcleaner.app.scan

object NameUtils {

    private val copyMarkers = listOf(
        Regex("""\s*\(\d{1,3}\)$"""),
        Regex("""\s*\[\d{1,3}\]$"""),
        Regex("""[\s_\-.]+(копия|copy|kopie|kopia)(\s*\(?\d{0,3}\)?)?$""", RegexOption.IGNORE_CASE),
        Regex("""^(копия|copy of)[\s_\-.]+""", RegexOption.IGNORE_CASE),
        Regex("""[\s_\-.]+v(er(sion)?)?[\s_\-.]?\d{1,3}$""", RegexOption.IGNORE_CASE),
        Regex("""[\s_\-.]+(версия|ред(акция)?)[\s_\-.]?\d{1,3}$""", RegexOption.IGNORE_CASE),
        Regex("""[\s_\-.]+(final|финал|финальная|финальный|new|новый|новая|old|старый|старая|draft|черновик|edited|rev\d{0,3})$""", RegexOption.IGNORE_CASE)
    )

    private val dirtyMarkers = listOf(
        Regex("""\(\d{1,3}\)"""),
        Regex("""\[\d{1,3}\]"""),
        Regex("""(копия|copy|kopie|kopia)""", RegexOption.IGNORE_CASE),
        Regex("""(^|[\s_\-.])(old|старый|старая|draft|черновик|tmp|temp)($|[\s_\-.])""", RegexOption.IGNORE_CASE)
    )

    /** Базовое имя без расширения и маркеров версий/копий: «Отчёт (1)», «Отчёт_v2», «Отчёт - копия» → «отчёт». */
    fun baseName(fileName: String): String {
        var base = fileName.substringBeforeLast('.', fileName)
        var changed = true
        var guard = 0
        while (changed && guard < 6) {
            changed = false
            guard++
            for (re in copyMarkers) {
                val next = re.replace(base, "").trim()
                if (next != base && next.isNotEmpty()) {
                    base = next
                    changed = true
                }
            }
        }
        return base.lowercase().replace(Regex("""[\s_\-.]+"""), " ").trim()
    }

    fun hasVersionMarker(fileName: String): Boolean {
        val base = fileName.substringBeforeLast('.', fileName)
        return baseName(fileName) != base.lowercase().replace(Regex("""[\s_\-.]+"""), " ").trim()
    }

    fun isDirtyName(fileName: String): Boolean {
        val base = fileName.substringBeforeLast('.', fileName)
        return dirtyMarkers.any { it.containsMatchIn(base) }
    }
}
