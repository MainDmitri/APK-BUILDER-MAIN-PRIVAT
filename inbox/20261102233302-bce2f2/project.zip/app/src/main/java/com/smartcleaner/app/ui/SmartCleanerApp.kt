package com.smartcleaner.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SmartCleanerApp(vm: MainViewModel) {
    val snackbar = remember { SnackbarHostState() }
    val msg = vm.message
    LaunchedEffect(msg) {
        if (msg != null) {
            snackbar.showSnackbar(msg)
            vm.message = null
        }
    }

    BackHandler(enabled = vm.backStack.size > 1) { vm.back() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Каждый экран сам учитывает системные отступы (Scaffold + TopAppBar, edge-to-edge).
        when (val screen = vm.currentScreen) {
            Screen.Home -> HomeScreen(vm)
            Screen.Results -> ResultsScreen(vm)
            is Screen.GroupDetail -> GroupDetailScreen(vm, screen.groupId)
            Screen.Trash -> TrashScreen(vm)
            Screen.Settings -> SettingsScreen(vm)
        }
        SnackbarHost(
            hostState = snackbar,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(bottom = 72.dp)
        )
    }
}
