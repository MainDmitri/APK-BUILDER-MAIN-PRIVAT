package com.smartcleaner.app.scan

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.security.MessageDigest

object Hashing {

    private const val CHUNK = 64 * 1024

    private fun hex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            val v = b.toInt() and 0xFF
            sb.append(HEX[v ushr 4]).append(HEX[v and 0x0F])
        }
        return sb.toString()
    }

    private val HEX = "0123456789abcdef".toCharArray()

    /** Быстрый хэш: размер + первые 64 КБ + последние 64 КБ. */
    fun partialHash(file: File): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        RandomAccessFile(file, "r").use { raf ->
            val len = raf.length()
            md.update(len.toString().toByteArray())
            val buf = ByteArray(CHUNK)
            val first = raf.read(buf, 0, minOf(CHUNK.toLong(), len).toInt())
            if (first > 0) md.update(buf, 0, first)
            if (len > CHUNK * 2L) {
                raf.seek(len - CHUNK)
                val last = raf.read(buf, 0, CHUNK)
                if (last > 0) md.update(buf, 0, last)
            } else if (len > CHUNK) {
                raf.seek(CHUNK.toLong())
                val rest = raf.read(buf, 0, (len - CHUNK).toInt())
                if (rest > 0) md.update(buf, 0, rest)
            }
        }
        hex(md.digest())
    } catch (e: Exception) {
        null
    }

    /** Полный SHA-256 содержимого. [isCancelled] позволяет прервать хэширование больших файлов. */
    fun fullHash(file: File, isCancelled: () -> Boolean): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { input ->
            val buf = ByteArray(256 * 1024)
            while (true) {
                if (isCancelled()) return null
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        hex(md.digest())
    } catch (e: Exception) {
        null
    }

    data class ImageHash(val hash: Long, val width: Int, val height: Int)

    /**
     * Перцептивный хэш dHash (64 бита): изображение уменьшается до 9×8 в оттенках серого,
     * каждый бит — сравнение яркости соседних пикселей.
     */
    fun dHash(file: File): ImageHash? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0) return null
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleSizeFor(w, h, 64)
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            val decoded = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
            val small = Bitmap.createScaledBitmap(decoded, 9, 8, true)
            if (small !== decoded) decoded.recycle()
            val gray = IntArray(72)
            for (y in 0 until 8) {
                for (x in 0 until 9) {
                    val p = small.getPixel(x, y)
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    gray[y * 9 + x] = (r * 299 + g * 587 + b * 114) / 1000
                }
            }
            small.recycle()
            var hash = 0L
            var bit = 0
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    if (gray[y * 9 + x] > gray[y * 9 + x + 1]) hash = hash or (1L shl bit)
                    bit++
                }
            }
            ImageHash(hash, w, h)
        } catch (e: Throwable) {
            null
        }
    }

    fun hamming(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    fun sampleSizeFor(width: Int, height: Int, target: Int): Int {
        var sample = 1
        while (width / (sample * 2) >= target && height / (sample * 2) >= target) sample *= 2
        return sample
    }
}
