package com.smartcleaner.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.JunkCategory
import com.smartcleaner.app.data.JunkItem

@Composable
fun ResultsScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf<MainViewModel.PendingDeletion?>(null) }
    val tab = vm.selectedTab
    val pending = vm.pendingFor(tab)

    Scaffold(
        topBar = { AppTopBar(title = "Результаты", onBack = { vm.back() }) },
        bottomBar = {
            Surface(tonalElevation = 6.dp, shadowElevation = 6.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Выбрано: ${pending.count}", fontWeight = FontWeight.Bold)
                        Text("Освободится ${formatSize(pending.bytes)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(
                        onClick = { confirm = pending },
                        enabled = pending.count > 0 && !vm.deleting
                    ) {
                        if (vm.deleting) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Text("Удалить")
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = tab.ordinal) {
                ResultTab.entries.forEach { t ->
                    val count = when (t) {
                        ResultTab.JUNK -> vm.junk.size
                        else -> vm.groupsFor(t).size
                    }
                    Tab(
                        selected = t == tab,
                        onClick = { vm.selectedTab = t },
                        text = { Text("${t.title} ($count)", maxLines = 1) }
                    )
                }
            }
            if (vm.aiBusy) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                if (vm.aiStatus.isNotEmpty()) {
                    Text(vm.aiStatus, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
            when (tab) {
                ResultTab.JUNK -> JunkTab(vm)
                ResultTab.DUPLICATES -> GroupsTab(vm, vm.groupsFor(ResultTab.DUPLICATES), showAi = false)
                ResultTab.SIMILAR -> GroupsTab(vm, vm.groupsFor(ResultTab.SIMILAR), showAi = true)
            }
        }
    }

    confirm?.let { p ->
        ConfirmDialog(
            title = "Переместить в корзину?",
            text = "Будет перемещено файлов: ${p.count} (${formatSize(p.bytes)}).\n" +
                "Основные (оставляемые) файлы не затрагиваются. Файлы можно восстановить из корзины " +
                "в течение ${vm.settings.trashDays} дн.",
            confirmText = "Удалить",
            onConfirm = { vm.delete(p) },
            onDismiss = { confirm = null }
        )
    }
}

@Composable
private fun JunkTab(vm: MainViewModel) {
    val expanded = remember { mutableStateMapOf<JunkCategory, Boolean>() }
    val byCategory = vm.junk.groupBy { it.category }
    if (vm.junk.isEmpty()) {
        EmptyState("Мусор не найден — отлично!")
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        "Безопасные категории отмечены автоматически. Большие старые файлы и неустановленные APK — только рекомендации.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedButton(onClick = { vm.aiClassifyJunk() }, enabled = !vm.aiBusy) {
                        Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Проверить сомнительные с ИИ")
                    }
                }
            }
        }
        JunkCategory.entries.forEach { cat ->
            val items = byCategory[cat] ?: return@forEach
            val isExpanded = expanded[cat] == true
            val selectedCount = items.count { vm.junkSelected[vm.keyOf(it)] == true }
            item(key = "cat_" + cat.name) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { expanded[cat] = !isExpanded }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = selectedCount == items.size,
                            onCheckedChange = { vm.setCategorySelected(cat, it) }
                        )
                        Column(Modifier.weight(1f)) {
                            Text(cat.title, fontWeight = FontWeight.Bold)
                            Text(
                                "${items.size} шт. • ${formatSize(items.sumOf { it.file.size })} • выбрано $selectedCount",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(cat.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(
                            if (isExpanded) Icons.Filled.KeyboardArrowDown else Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = if (isExpanded) "Свернуть" else "Развернуть"
                        )
                    }
                }
            }
            if (isExpanded) {
                items(items.take(500), key = { "j_" + vm.keyOf(it) }) { item ->
                    JunkRow(vm, item)
                }
                if (items.size > 500) {
                    item(key = "more_" + cat.name) {
                        Text(
                            "Показаны первые 500 из ${items.size}. Отметка категории применяется ко всем.",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.size(24.dp)) }
    }
}

@Composable
private fun JunkRow(vm: MainViewModel, item: JunkItem) {
    val checked = vm.junkSelected[vm.keyOf(item)] == true
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { vm.toggleJunk(item) }
            .padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = checked, onCheckedChange = { vm.toggleJunk(item) })
        FileThumbnail(item.file.path, if (item.isDirectory) "DIR" else item.file.extension, 40.dp)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(item.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(
                item.file.parentPath,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                (if (item.isDirectory) "" else formatSize(item.file.size) + " • ") + item.note,
                style = MaterialTheme.typography.bodySmall
            )
            if (item.aiJunk != null) {
                Text(
                    (if (item.aiJunk) "ИИ: мусор — " else "ИИ: важно — ") + item.aiReason,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.aiJunk) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
    HorizontalDivider()
}

@Composable
private fun GroupsTab(vm: MainViewModel, groups: List<FileGroup>, showAi: Boolean) {
    if (groups.isEmpty()) {
        EmptyState(if (showAi) "Похожих файлов не найдено" else "Дубликатов не найдено")
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "В каждой группе оставляется отмеченный ★ файл. Остальные отмечены для удаления — проверьте перед подтверждением.",
                    style = MaterialTheme.typography.bodySmall
                )
                if (showAi) {
                    OutlinedButton(onClick = { vm.aiChooseAllSimilar() }, enabled = !vm.aiBusy) {
                        Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("ИИ: выбрать лучшие версии")
                    }
                }
            }
        }
        items(groups, key = { "g_" + it.id }) { g -> GroupCard(vm, g) }
        item { Spacer(Modifier.size(24.dp)) }
    }
}

@Composable
private fun GroupCard(vm: MainViewModel, g: FileGroup) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { vm.navigate(Screen.GroupDetail(g.id)) }
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            FileThumbnail(g.keeper.path, g.keeper.extension, 56.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(g.type.title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(g.keeper.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                }
                Text(
                    "${g.files.size} файла(ов) • к удалению ${g.selected.size} • ${formatSize(g.selectedBytes)}",
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    if (g.aiReason.isNotEmpty()) g.aiReason else g.keeperReasons.firstOrNull().orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Подробнее")
        }
    }
}

@Composable
fun EmptyState(text: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(48.dp))
        Spacer(Modifier.size(12.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
}
