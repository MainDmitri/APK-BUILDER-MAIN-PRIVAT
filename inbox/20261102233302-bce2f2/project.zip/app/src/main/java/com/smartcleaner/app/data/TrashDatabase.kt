package com.smartcleaner.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Журнал корзины: откуда удалён файл и где лежит его копия. */
class TrashDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "trash.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE trash (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "original_path TEXT NOT NULL, " +
                "trash_path TEXT NOT NULL, " +
                "size INTEGER NOT NULL, " +
                "deleted_at INTEGER NOT NULL, " +
                "is_dir INTEGER NOT NULL DEFAULT 0)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS trash")
        onCreate(db)
    }

    fun insert(originalPath: String, trashPath: String, size: Long, deletedAt: Long, isDir: Boolean): Long {
        val values = ContentValues().apply {
            put("original_path", originalPath)
            put("trash_path", trashPath)
            put("size", size)
            put("deleted_at", deletedAt)
            put("is_dir", if (isDir) 1 else 0)
        }
        return writableDatabase.insert("trash", null, values)
    }

    fun delete(id: Long) {
        writableDatabase.delete("trash", "id = ?", arrayOf(id.toString()))
    }

    fun all(): List<TrashEntry> {
        val result = ArrayList<TrashEntry>()
        readableDatabase.query(
            "trash",
            arrayOf("id", "original_path", "trash_path", "size", "deleted_at", "is_dir"),
            null, null, null, null, "deleted_at DESC"
        ).use { c ->
            while (c.moveToNext()) {
                result.add(
                    TrashEntry(
                        id = c.getLong(0),
                        originalPath = c.getString(1),
                        trashPath = c.getString(2),
                        size = c.getLong(3),
                        deletedAt = c.getLong(4),
                        isDirectory = c.getInt(5) == 1
                    )
                )
            }
        }
        return result
    }
}
