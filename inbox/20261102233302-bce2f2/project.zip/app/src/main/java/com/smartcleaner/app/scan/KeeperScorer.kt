package com.smartcleaner.app.scan

import com.smartcleaner.app.data.FileInfo
import com.smartcleaner.app.data.GroupType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Прозрачная оценка «самого актуального» файла в группе.
 * Каждый критерий добавляет или вычитает баллы, итог и причины показываются пользователю.
 */
object KeeperScorer {

    data class Verdict(val keeperIndex: Int, val scores: List<Int>, val reasons: List<String>)

    private val junkFolderMarkers = listOf(
        "/cache/", "/.cache/", "/caches/", "/temp/", "/tmp/", "/.tmp/", "/.trash", "/trash/",
        "/sent/", "/whatsapp images/sent", "/whatsapp video/sent", "/whatsapp documents/sent",
        "/.thumbnails/", "/thumbnails/", "/.statuses/", "/backup/", "/backups/", "/old/", "/архив/"
    )

    private val goodFolderMarkers = listOf(
        "/dcim/camera/", "/documents/", "/pictures/", "/dcim/", "/music/", "/movies/", "/screenshots/"
    )

    private fun dateText(ms: Long): String =
        SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.forLanguageTag("ru")).format(Date(ms))

    fun evaluate(files: List<FileInfo>, type: GroupType): Verdict {
        if (files.isEmpty()) return Verdict(0, emptyList(), emptyList())
        val minTime = files.minOf { it.lastModified }
        val maxTime = files.maxOf { it.lastModified }
        val maxPixels = files.maxOf { it.width.toLong() * it.height.toLong() }
        val maxText = files.maxOf { it.textLength }
        val maxSize = files.maxOf { it.size }
        val minSize = files.minOf { it.size }
        val minDepth = files.minOf { depth(it.path) }

        val details = files.map { f ->
            val parts = ArrayList<Pair<Int, String>>()
            // 1. Свежесть: до 40 баллов (у точных копий содержимое одинаково, поэтому дата весит меньше — до 10).
            val recencyWeight = if (type == GroupType.EXACT) 10.0 else 40.0
            if (maxTime > minTime) {
                val pts = ((f.lastModified - minTime).toDouble() / (maxTime - minTime) * recencyWeight).toInt()
                if (pts > 0) parts.add(pts to (if (f.lastModified == maxTime) "Самый новый (${dateText(f.lastModified)})" else "Изменён ${dateText(f.lastModified)}"))
            }
            // 2. Полнота содержимого.
            when {
                type == GroupType.SIMILAR_IMAGE && maxPixels > 0 -> {
                    val px = f.width.toLong() * f.height.toLong()
                    val pts = (px.toDouble() / maxPixels * 30.0).toInt()
                    if (px == maxPixels) parts.add(pts to "Наибольшее разрешение ${f.width}×${f.height}")
                    else parts.add(pts to "Разрешение ${f.width}×${f.height}")
                }
                (type == GroupType.SIMILAR_TEXT || f.textLength > 0) && maxText > 0 -> {
                    val pts = (f.textLength.toDouble() / maxText * 25.0).toInt()
                    if (f.textLength == maxText) parts.add(pts to "Самый полный текст")
                    else parts.add(pts to "Текст короче")
                }
                maxSize > minSize && maxSize > 0 -> {
                    val pts = (f.size.toDouble() / maxSize * 20.0).toInt()
                    if (f.size == maxSize) parts.add(pts to "Самый объёмный по содержимому")
                    else parts.add(pts to "Меньше по объёму")
                }
            }
            // 3. Расположение.
            val lowerPath = f.path.lowercase(Locale.ROOT) + "/"
            if (junkFolderMarkers.any { lowerPath.contains(it) }) {
                parts.add(-40 to "Лежит во временной/служебной папке")
            } else if (goodFolderMarkers.any { lowerPath.contains(it) }) {
                parts.add(15 to "Лежит в основной папке (${f.parentPath.substringAfterLast('/')})")
            } else {
                parts.add(5 to "Не во временной папке")
            }
            // 4. Имя файла.
            if (NameUtils.isDirtyName(f.name)) {
                parts.add(-15 to "Имя похоже на копию («(1)», «copy», «копия»)")
            } else {
                parts.add(10 to "Чистое имя файла")
            }
            // 5. Небольшой бонус за неглубокое расположение.
            if (depth(f.path) == minDepth) parts.add(2 to "Ближе к корню памяти")
            parts
        }
        val scores = details.map { d -> d.sumOf { it.first } }
        var best = 0
        for (i in files.indices) {
            val better = scores[i] > scores[best] ||
                (scores[i] == scores[best] && files[i].lastModified > files[best].lastModified) ||
                (scores[i] == scores[best] && files[i].lastModified == files[best].lastModified && files[i].path.length < files[best].path.length)
            if (better) best = i
        }
        val reasons = details[best]
            .filter { it.first > 0 }
            .sortedByDescending { it.first }
            .map { "${it.second} (+${it.first})" }
            .ifEmpty { listOf("Все файлы равноценны — выбран первый") }
        return Verdict(best, scores, reasons)
    }

    private fun depth(path: String): Int = path.count { it == '/' }
}
