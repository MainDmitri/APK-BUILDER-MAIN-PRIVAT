package com.smartcleaner.app.ui

import android.app.Application
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartcleaner.app.ai.GeminiClient
import com.smartcleaner.app.ai.GeminiException
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.GroupType
import com.smartcleaner.app.data.JunkCategory
import com.smartcleaner.app.data.JunkItem
import com.smartcleaner.app.data.LastScanSummary
import com.smartcleaner.app.data.ScanProgress
import com.smartcleaner.app.data.SettingsRepository
import com.smartcleaner.app.data.TrashEntry
import com.smartcleaner.app.data.TrashManager
import com.smartcleaner.app.scan.ScanConfig
import com.smartcleaner.app.scan.Scanner
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class Screen {
    data object Home : Screen()
    data object Results : Screen()
    data class GroupDetail(val groupId: Long) : Screen()
    data object Trash : Screen()
    data object Settings : Screen()
}

enum class ResultTab(val title: String) { JUNK("Мусор"), DUPLICATES("Дубликаты"), SIMILAR("Похожие") }

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val settings = SettingsRepository(app)
    private val trash = TrashManager(app)

    // ---------- Навигация ----------
    val backStack = mutableStateListOf<Screen>(Screen.Home)
    val currentScreen: Screen get() = backStack.last()

    fun navigate(screen: Screen) {
        backStack.add(screen)
    }

    fun back(): Boolean {
        if (backStack.size <= 1) return false
        backStack.removeAt(backStack.lastIndex)
        return true
    }

    // ---------- Состояние ----------
    var hasPermission by mutableStateOf(false)
        private set
    var storageTotal by mutableStateOf(0L)
        private set
    var storageFree by mutableStateOf(0L)
        private set
    var scanning by mutableStateOf(false)
        private set
    var progress by mutableStateOf(ScanProgress())
        private set
    var summary by mutableStateOf<LastScanSummary?>(null)
        private set
    var hasResults by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
    var aiBusy by mutableStateOf(false)
        private set
    var aiStatus by mutableStateOf("")
        private set
    var deleting by mutableStateOf(false)
        private set
    var selectedTab by mutableStateOf(ResultTab.JUNK)

    val junk = mutableStateListOf<JunkItem>()
    val junkSelected = mutableStateMapOf<String, Boolean>()
    val groups = mutableStateListOf<FileGroup>()
    val trashEntries = mutableStateListOf<TrashEntry>()
    var trashSize by mutableStateOf(0L)
        private set

    // Поля настроек для UI
    var apiKey by mutableStateOf(settings.apiKey)
    var model by mutableStateOf(settings.model)
    var aiEnabled by mutableStateOf(settings.aiEnabled)
    var aiSendImages by mutableStateOf(settings.aiSendImages)
    var aiConsent by mutableStateOf(settings.aiConsent)
    var imageThreshold by mutableStateOf(settings.imageThreshold)
    var textThreshold by mutableStateOf(settings.textThresholdPercent)
    var largeFileMb by mutableStateOf(settings.largeFileMb.toString())
    var oldFileDays by mutableStateOf(settings.oldFileDays.toString())
    var trashDays by mutableStateOf(settings.trashDays.toString())
    var excludedFolders by mutableStateOf(settings.excludedFolders)

    private var scanJob: Job? = null

    init {
        summary = settings.loadSummary()
        refreshStorage()
        viewModelScope.launch(Dispatchers.IO) {
            val purged = trash.purgeOlderThan(settings.trashDays)
            withContext(Dispatchers.Main) {
                if (purged > 0) message = "Автоочистка корзины: удалено навсегда $purged"
                refreshTrash()
            }
        }
    }

    val aiAvailable: Boolean get() = aiEnabled && aiConsent && apiKey.isNotBlank()

    fun refreshPermission() {
        hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            val ctx = getApplication<Application>()
            ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        refreshStorage()
    }

    fun refreshStorage() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            storageTotal = stat.totalBytes
            storageFree = stat.availableBytes
        } catch (e: Exception) {
            storageTotal = 0L
            storageFree = 0L
        }
    }

    // ---------- Сканирование ----------
    fun startScan() {
        if (scanning) return
        if (!hasPermission) {
            message = "Сначала предоставьте доступ к файлам"
            return
        }
        saveSettings(showMessage = false)
        scanning = true
        progress = ScanProgress("Подготовка", 0, "", -1f)
        val root = Environment.getExternalStorageDirectory()
        val config = ScanConfig(
            root = root,
            excluded = settings.excludedList(root.absolutePath),
            trashDir = trash.trashDir,
            largeFileBytes = settings.largeFileMb.toLong() * 1024L * 1024L,
            oldFileMs = settings.oldFileDays.toLong() * 86_400_000L,
            imageThreshold = settings.imageThreshold,
            textThreshold = settings.textThresholdPercent / 100.0
        )
        scanJob = viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    Scanner(getApplication(), config).scan { p ->
                        viewModelScope.launch(Dispatchers.Main) { if (scanning) progress = p }
                    }
                }
                junk.clear()
                junk.addAll(result.junk)
                junkSelected.clear()
                result.junk.forEach { junkSelected[keyOf(it)] = it.defaultSelected }
                groups.clear()
                groups.addAll(result.groups)
                hasResults = true
                val s = LastScanSummary(
                    time = result.finishedAt,
                    filesScanned = result.filesScanned,
                    junkCount = result.junk.size,
                    junkBytes = result.junk.sumOf { it.file.size },
                    duplicateGroups = result.duplicateGroups.size,
                    duplicateBytes = result.duplicateGroups.sumOf { it.reclaimableBytes },
                    similarGroups = result.similarGroups.size,
                    similarBytes = result.similarGroups.sumOf { it.reclaimableBytes }
                )
                settings.saveSummary(s)
                summary = s
                selectedTab = ResultTab.JUNK
                if (currentScreen == Screen.Home) navigate(Screen.Results)
            } catch (e: CancellationException) {
                message = "Сканирование остановлено"
                throw e
            } catch (e: Exception) {
                message = "Ошибка сканирования: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                scanning = false
                refreshStorage()
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        scanJob = null
        scanning = false
    }

    // ---------- Выбор ----------
    fun keyOf(item: JunkItem): String = item.category.name + "|" + item.file.path

    fun toggleJunk(item: JunkItem) {
        val k = keyOf(item)
        junkSelected[k] = !(junkSelected[k] ?: false)
    }

    fun setCategorySelected(category: JunkCategory, selected: Boolean) {
        junk.filter { it.category == category }.forEach { junkSelected[keyOf(it)] = selected }
    }

    fun groupById(id: Long): FileGroup? = groups.firstOrNull { it.id == id }

    private fun updateGroup(id: Long, transform: (FileGroup) -> FileGroup) {
        val i = groups.indexOfFirst { it.id == id }
        if (i >= 0) groups[i] = transform(groups[i])
    }

    fun toggleGroupFile(groupId: Long, path: String) {
        updateGroup(groupId) { g ->
            if (path == g.keeper.path) g
            else g.copy(selected = if (path in g.selected) g.selected - path else g.selected + path)
        }
    }

    fun setKeeper(groupId: Long, index: Int, aiReason: String = "", byAi: Boolean = false) {
        updateGroup(groupId) { g ->
            if (index !in g.files.indices) return@updateGroup g
            val newKeeper = g.files[index].path
            val reasons = if (byAi) g.keeperReasons else listOf("Выбран вами вручную")
            g.copy(
                keeperIndex = index,
                keeperReasons = reasons,
                aiReason = aiReason,
                aiChosen = byAi,
                selected = g.files.map { it.path }.filter { it != newKeeper }.toSet()
            )
        }
    }

    fun setAllInGroup(groupId: Long, selected: Boolean) {
        updateGroup(groupId) { g ->
            g.copy(selected = if (selected) g.files.map { it.path }.filter { it != g.keeper.path }.toSet() else emptySet())
        }
    }

    fun groupsFor(tab: ResultTab): List<FileGroup> = when (tab) {
        ResultTab.DUPLICATES -> groups.filter { it.type == GroupType.EXACT }
        ResultTab.SIMILAR -> groups.filter { it.type != GroupType.EXACT }
        ResultTab.JUNK -> emptyList()
    }

    data class PendingDeletion(val paths: List<String>, val bytes: Long, val count: Int, val fromGroups: Boolean)

    fun pendingFor(tab: ResultTab): PendingDeletion {
        return if (tab == ResultTab.JUNK) {
            val items = junk.filter { junkSelected[keyOf(it)] == true }.distinctBy { it.file.path }
            PendingDeletion(items.map { it.file.path }, items.sumOf { it.file.size }, items.size, false)
        } else {
            val keepers = groups.map { it.keeper.path }.toSet()
            val map = LinkedHashMap<String, Long>()
            for (g in groupsFor(tab)) {
                for (f in g.files) if (f.path in g.selected && f.path !in keepers) map[f.path] = f.size
            }
            PendingDeletion(map.keys.toList(), map.values.sum(), map.size, true)
        }
    }

    fun pendingForGroup(groupId: Long): PendingDeletion {
        val g = groupById(groupId) ?: return PendingDeletion(emptyList(), 0, 0, true)
        val keepers = groups.map { it.keeper.path }.toSet()
        val files = g.files.filter { it.path in g.selected && it.path !in keepers }
        return PendingDeletion(files.map { it.path }, files.sumOf { it.size }, files.size, true)
    }

    /** Перемещает выбранные файлы в корзину. Вызывается только после подтверждения пользователя. */
    fun delete(pending: PendingDeletion) {
        if (deleting || pending.paths.isEmpty()) return
        deleting = true
        val protectedPaths: Set<String> = if (pending.fromGroups) groups.map { it.keeper.path }.toSet() else emptySet()
        viewModelScope.launch {
            try {
                val report = withContext(Dispatchers.IO) { trash.moveToTrash(pending.paths, protectedPaths) }
                val gone = withContext(Dispatchers.IO) {
                    pending.paths.filter { !java.io.File(it).exists() }.toSet()
                }
                removeFromResults(gone)
                refreshTrash()
                refreshStorage()
                message = buildString {
                    append("В корзину: ${report.moved} (${formatSize(report.bytes)})")
                    if (report.failed > 0) append(". Не удалось: ${report.failed}")
                }
            } catch (e: Exception) {
                message = "Ошибка удаления: ${e.message}"
            } finally {
                deleting = false
            }
        }
    }

    private fun removeFromResults(gone: Set<String>) {
        if (gone.isEmpty()) return
        val keptJunk = junk.filter { it.file.path !in gone }
        junk.clear()
        junk.addAll(keptJunk)
        junkSelected.keys.toList().forEach { k -> if (k.substringAfter('|') in gone) junkSelected.remove(k) }
        val updated = groups.mapNotNull { g ->
            val remaining = g.files.filter { it.path !in gone }
            when {
                remaining.size == g.files.size -> g
                remaining.size < 2 -> null
                else -> {
                    val keeperPath = g.keeper.path
                    val idx = remaining.indexOfFirst { it.path == keeperPath }
                    if (idx >= 0) {
                        g.copy(files = remaining, keeperIndex = idx, scores = emptyList(), selected = g.selected.filter { p -> remaining.any { it.path == p } }.toSet())
                    } else {
                        val v = com.smartcleaner.app.scan.KeeperScorer.evaluate(remaining, g.type)
                        g.copy(
                            files = remaining, keeperIndex = v.keeperIndex, keeperReasons = v.reasons, scores = v.scores,
                            aiReason = "", aiChosen = false,
                            selected = remaining.map { it.path }.filter { it != remaining[v.keeperIndex].path }.toSet()
                        )
                    }
                }
            }
        }
        groups.clear()
        groups.addAll(updated)
        if (currentScreen is Screen.GroupDetail && groupById((currentScreen as Screen.GroupDetail).groupId) == null) back()
        summary?.let { s ->
            val dup = groups.filter { it.type == GroupType.EXACT }
            val sim = groups.filter { it.type != GroupType.EXACT }
            val ns = s.copy(
                junkCount = junk.size,
                junkBytes = junk.sumOf { it.file.size },
                duplicateGroups = dup.size,
                duplicateBytes = dup.sumOf { it.reclaimableBytes },
                similarGroups = sim.size,
                similarBytes = sim.sumOf { it.reclaimableBytes }
            )
            summary = ns
            settings.saveSummary(ns)
        }
    }

    // ---------- ИИ ----------
    private fun client(): GeminiClient = GeminiClient(settings.apiKey, settings.model, settings.aiSendImages)

    fun aiChooseKeeper(groupId: Long) {
        if (!checkAi()) return
        val g = groupById(groupId) ?: return
        aiBusy = true
        aiStatus = "ИИ анализирует группу…"
        viewModelScope.launch {
            try {
                val d = withContext(Dispatchers.IO) { client().chooseKeeper(g) }
                setKeeper(groupId, d.keepIndex, "ИИ: ${d.reason}", byAi = true)
                message = "ИИ выбрал: ${g.files[d.keepIndex].name}"
            } catch (e: GeminiException) {
                message = "ИИ недоступен: ${e.message}. Оставлен локальный выбор"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "ИИ недоступен: ${e.message}. Оставлен локальный выбор"
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    fun aiChooseAllSimilar() {
        if (!checkAi()) return
        val targets = groups.filter { it.type != GroupType.EXACT && !it.aiChosen }.take(20)
        if (targets.isEmpty()) {
            message = "Нет групп для проверки ИИ"
            return
        }
        aiBusy = true
        viewModelScope.launch {
            var ok = 0
            var lastError: String? = null
            for ((i, g) in targets.withIndex()) {
                aiStatus = "ИИ проверяет группы: ${i + 1} из ${targets.size}"
                try {
                    val d = withContext(Dispatchers.IO) { client().chooseKeeper(g) }
                    setKeeper(g.id, d.keepIndex, "ИИ: ${d.reason}", byAi = true)
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastError = e.message
                    if (e.message?.contains("квот") == true || e.message?.contains("Ключ") == true) break
                }
            }
            aiBusy = false
            aiStatus = ""
            message = if (lastError == null) "ИИ проверил групп: $ok"
            else "ИИ проверил групп: $ok. Ошибка: $lastError — для остальных оставлен локальный выбор"
        }
    }

    fun aiClassifyJunk() {
        if (!checkAi()) return
        val uncertain = junk.filter {
            it.aiJunk == null && (!it.defaultSelected || it.category == JunkCategory.TEMP || it.category == JunkCategory.APK)
        }.take(40)
        if (uncertain.isEmpty()) {
            message = "Нет сомнительных файлов для проверки"
            return
        }
        aiBusy = true
        aiStatus = "ИИ классифицирует ${uncertain.size} файлов…"
        viewModelScope.launch {
            try {
                val verdicts = withContext(Dispatchers.IO) { client().classify(uncertain) }
                for (v in verdicts) {
                    val item = uncertain[v.index]
                    val idx = junk.indexOfFirst { keyOf(it) == keyOf(item) }
                    if (idx >= 0) {
                        junk[idx] = junk[idx].copy(aiJunk = v.junk, aiReason = v.reason)
                        junkSelected[keyOf(item)] = v.junk
                    }
                }
                message = "ИИ оценил файлов: ${verdicts.size}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "ИИ недоступен: ${e.message}. Используются локальные правила"
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    private fun checkAi(): Boolean {
        if (aiBusy) return false
        if (!aiEnabled) {
            message = "ИИ выключен. Включите его в Настройках"
            return false
        }
        if (!aiConsent) {
            message = "Подтвердите согласие на отправку данных в Google в Настройках"
            return false
        }
        if (apiKey.isBlank()) {
            message = "Укажите ключ Gemini API в Настройках"
            return false
        }
        return true
    }

    // ---------- Корзина ----------
    fun refreshTrash() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { trash.entries() }
            trashEntries.clear()
            trashEntries.addAll(list)
            trashSize = list.sumOf { it.size }
        }
    }

    fun restore(entry: TrashEntry) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { trash.restore(entry) }
            message = r.fold({ "Восстановлено: $it" }, { "Ошибка: ${it.message}" })
            refreshTrash()
            refreshStorage()
        }
    }

    fun deleteForever(entry: TrashEntry) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { trash.deletePermanently(entry) }
            message = if (ok) "Удалено навсегда: ${entry.name}" else "Не удалось удалить ${entry.name}"
            refreshTrash()
            refreshStorage()
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { trash.emptyAll() }
            message = "Корзина очищена: $n"
            refreshTrash()
            refreshStorage()
        }
    }

    // ---------- Настройки ----------
    fun saveSettings(showMessage: Boolean = true) {
        settings.apiKey = apiKey
        settings.model = model
        settings.aiEnabled = aiEnabled
        settings.aiSendImages = aiSendImages
        settings.aiConsent = aiConsent
        settings.imageThreshold = imageThreshold
        settings.textThresholdPercent = textThreshold
        largeFileMb.trim().toIntOrNull()?.let { settings.largeFileMb = it }
        oldFileDays.trim().toIntOrNull()?.let { settings.oldFileDays = it }
        trashDays.trim().toIntOrNull()?.let { settings.trashDays = it }
        settings.excludedFolders = excludedFolders
        // Нормализуем отображаемые значения.
        model = settings.model
        apiKey = settings.apiKey
        largeFileMb = settings.largeFileMb.toString()
        oldFileDays = settings.oldFileDays.toString()
        trashDays = settings.trashDays.toString()
        if (showMessage) message = "Настройки сохранены"
    }

    fun clearApiKey() {
        apiKey = ""
        settings.apiKey = ""
        message = "Ключ удалён"
    }
}
