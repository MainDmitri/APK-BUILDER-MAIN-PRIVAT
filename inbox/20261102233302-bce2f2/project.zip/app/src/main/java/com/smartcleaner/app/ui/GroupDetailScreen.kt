package com.smartcleaner.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.FileInfo

@Composable
fun GroupDetailScreen(vm: MainViewModel, groupId: Long) {
    val group = vm.groupById(groupId)
    var confirm by remember { mutableStateOf<MainViewModel.PendingDeletion?>(null) }

    if (group == null) {
        Scaffold(topBar = { AppTopBar(title = "Группа", onBack = { vm.back() }) }) { padding ->
            Column(Modifier.padding(padding)) { EmptyState("Группа уже очищена") }
        }
        return
    }
    val pending = vm.pendingForGroup(groupId)

    Scaffold(
        topBar = { AppTopBar(title = group.type.title, onBack = { vm.back() }) },
        bottomBar = {
            Surface(tonalElevation = 6.dp, shadowElevation = 6.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("К удалению: ${pending.count}", fontWeight = FontWeight.Bold)
                        Text("Освободится ${formatSize(pending.bytes)}", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = { confirm = pending }, enabled = pending.count > 0 && !vm.deleting) {
                        Text("Удалить")
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { ReasonCard(vm, group) }
            itemsIndexed(group.files, key = { _, f -> f.path }) { index, f ->
                FileCard(
                    file = f,
                    isKeeper = index == group.keeperIndex,
                    checked = f.path in group.selected,
                    score = group.scores.getOrNull(index),
                    onToggle = { vm.toggleGroupFile(groupId, f.path) },
                    onMakeKeeper = { vm.setKeeper(groupId, index) }
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { vm.setAllInGroup(groupId, true) }) { Text("Отметить все копии") }
                    TextButton(onClick = { vm.setAllInGroup(groupId, false) }) { Text("Снять отметки") }
                }
            }
            item { Spacer(Modifier.size(24.dp)) }
        }
    }

    confirm?.let { p ->
        ConfirmDialog(
            title = "Переместить в корзину?",
            text = "Файлов: ${p.count} (${formatSize(p.bytes)}). Основной файл «${group.keeper.name}» останется на месте.",
            confirmText = "Удалить",
            onConfirm = { vm.delete(p) },
            onDismiss = { confirm = null }
        )
    }
}

@Composable
private fun ReasonCard(vm: MainViewModel, group: FileGroup) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Почему оставляем «${group.keeper.name}»", fontWeight = FontWeight.Bold)
            if (group.aiReason.isNotEmpty()) {
                Text(group.aiReason, color = MaterialTheme.colorScheme.tertiary, fontWeight = FontWeight.Medium)
            }
            group.keeperReasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            if (group.similarityNote.isNotEmpty()) {
                Text(group.similarityNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (vm.aiBusy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = { vm.aiChooseKeeper(group.id) }, enabled = !vm.aiBusy) {
                Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (vm.aiAvailable) "Спросить ИИ Gemini" else "ИИ (настройте в Настройках)")
            }
        }
    }
}

@Composable
private fun FileCard(
    file: FileInfo,
    isKeeper: Boolean,
    checked: Boolean,
    score: Int?,
    onToggle: () -> Unit,
    onMakeKeeper: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isKeeper) { onToggle() },
        border = if (isKeeper) BorderStroke(2.dp, MaterialTheme.colorScheme.secondary) else null
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked && !isKeeper, onCheckedChange = { onToggle() }, enabled = !isKeeper)
            FileThumbnail(file.path, file.extension, 88.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (isKeeper) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Star, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Оставить (основной)", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                    }
                }
                Text(file.name, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(file.parentPath, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("${formatSize(file.size)} • ${formatDate(file.lastModified)}", style = MaterialTheme.typography.bodySmall)
                if (file.width > 0) Text("${file.width}×${file.height} px", style = MaterialTheme.typography.bodySmall)
                if (score != null) Text("Оценка актуальности: $score", style = MaterialTheme.typography.bodySmall)
                if (!isKeeper) {
                    TextButton(onClick = onMakeKeeper, contentPadding = PaddingValues(0.dp)) { Text("Сделать основным") }
                }
            }
        }
    }
}
