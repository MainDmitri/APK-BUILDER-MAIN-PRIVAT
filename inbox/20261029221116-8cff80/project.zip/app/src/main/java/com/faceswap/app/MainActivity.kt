package com.faceswap.app

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"

    // UI
    private lateinit var tvModelStatus: TextView
    private lateinit var pbModelDownload: ProgressBar
    private lateinit var vStatusDot: View
    private lateinit var ivSourceFace: ImageView
    private lateinit var ivSourcePlaceholder: ImageView
    private lateinit var ivVideoThumb: ImageView
    private lateinit var ivVideoPlaceholder: ImageView
    private lateinit var tvVideoInfo: TextView
    private lateinit var btnSelectSource: MaterialButton
    private lateinit var btnSelectVideo: MaterialButton
    private lateinit var btnProcess: MaterialButton
    private lateinit var layoutProgress: View
    private lateinit var pbProcess: ProgressBar
    private lateinit var tvProgressStatus: TextView
    private lateinit var tvProgressPercent: TextView
    private lateinit var layoutResult: View
    private lateinit var btnSave: MaterialButton
    private lateinit var btnShare: MaterialButton

    // Данные
    private var sourceBitmap: Bitmap? = null
    private var selectedFaceIndex: Int = 0   // выбранное лицо на фото донора
    private var videoFile: File? = null
    private var resultFile: File? = null
    private var modelsReady = false

    // --- Пикеры файлов ---

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        loadSourceImage(uri)
    }

    private val pickVideoLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri ?: return@registerForActivityResult
        loadVideo(uri)
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms.values.all { it }) {
            checkAndDownloadModels()
        } else {
            tvModelStatus.text = "Разрешения не выданы"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupListeners()
        requestPermissionsAndInit()
    }

    private fun bindViews() {
        tvModelStatus       = findViewById(R.id.tvModelStatus)
        pbModelDownload     = findViewById(R.id.pbModelDownload)
        vStatusDot          = findViewById(R.id.vStatusDot)
        ivSourceFace        = findViewById(R.id.ivSourceFace)
        ivSourcePlaceholder = findViewById(R.id.ivSourcePlaceholder)
        ivVideoThumb        = findViewById(R.id.ivVideoThumb)
        ivVideoPlaceholder  = findViewById(R.id.ivVideoPlaceholder)
        tvVideoInfo         = findViewById(R.id.tvVideoInfo)
        btnSelectSource     = findViewById(R.id.btnSelectSource)
        btnSelectVideo      = findViewById(R.id.btnSelectVideo)
        btnProcess          = findViewById(R.id.btnProcess)
        layoutProgress      = findViewById(R.id.layoutProgress)
        pbProcess           = findViewById(R.id.pbProcess)
        tvProgressStatus    = findViewById(R.id.tvProgressStatus)
        tvProgressPercent   = findViewById(R.id.tvProgressPercent)
        layoutResult        = findViewById(R.id.layoutResult)
        btnSave             = findViewById(R.id.btnSave)
        btnShare            = findViewById(R.id.btnShare)
    }

    private fun setupListeners() {
        btnSelectSource.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }
        btnSelectVideo.setOnClickListener {
            pickVideoLauncher.launch("video/*")
        }
        btnProcess.setOnClickListener {
            startProcessing()
        }
        btnSave.setOnClickListener {
            saveToGallery()
        }
        btnShare.setOnClickListener {
            shareResult()
        }
    }

    private fun requestPermissionsAndInit() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_MEDIA_VIDEO)
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                needed.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        if (needed.isEmpty()) {
            checkAndDownloadModels()
        } else {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun checkAndDownloadModels() {
        if (ModelManager.areModelsReady(this)) {
            modelsReady = true
            tvModelStatus.text = getString(R.string.models_ready)
            vStatusDot.setBackgroundResource(R.drawable.bg_dot_success)
            updateProcessButton()
            return
        }

        tvModelStatus.text = "Загрузка AI моделей (~700 МБ)…"
        pbModelDownload.visibility = View.VISIBLE
        pbModelDownload.progress = 0

        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    ModelManager.downloadModels(this@MainActivity) { name, pct ->
                        runOnUiThread {
                            tvModelStatus.text = "Загрузка $name ($pct%)"
                            pbModelDownload.progress = pct
                        }
                    }
                }
                modelsReady = true
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = getString(R.string.models_ready)
                vStatusDot.setBackgroundResource(R.drawable.bg_dot_success)
                updateProcessButton()
            } catch (e: ModelManager.ManualDownloadRequired) {
                Log.e(TAG, "Все зеркала недоступны")
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = "⚠ Сеть недоступна — нужна ручная установка"
                showManualDownloadDialog(e.instructions)
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка загрузки моделей", e)
                pbModelDownload.visibility = View.GONE
                tvModelStatus.text = "Ошибка: ${e.message}"
                btnProcess.text = "Повторить"
                btnProcess.isEnabled = true
                btnProcess.setOnClickListener {
                    btnProcess.text = getString(R.string.process)
                    btnProcess.isEnabled = false
                    btnProcess.setOnClickListener { startProcessing() }
                    checkAndDownloadModels()
                }
            }
        }
    }

    private fun showManualDownloadDialog(instructions: String) {
        runOnUiThread {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Ручная установка моделей")
                .setMessage(instructions)
                .setPositiveButton("Проверить модели") { _, _ ->
                    checkAndDownloadModels()
                }
                .setNeutralButton("Копировать инструкцию") { _, _ ->
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE)
                        as android.content.ClipboardManager
                    clipboard.setPrimaryClip(
                        android.content.ClipData.newPlainText("Инструкция", instructions)
                    )
                    Toast.makeText(this, "Скопировано в буфер обмена", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Закрыть", null)
                .show()
        }
    }

    /**
     * Загружает фото донора с правильным EXIF-поворотом и downsampling.
     *
     * Два прохода по стриму:
     *  1. BitmapFactory.Options(inJustDecodeBounds=true) → узнаём реальный размер
     *  2. Вычисляем inSampleSize чтобы не грузить 20МП в память целиком
     *  3. Отдельный стрим → читаем EXIF угол
     *  4. Ещё один стрим → decode с inSampleSize
     */
    private fun loadSourceImage(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Шаг 1: узнаём реальный размер без декодирования
                val rawW: Int
                val rawH: Int
                contentResolver.openInputStream(uri)?.use { s ->
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeStream(s, null, opts)
                    rawW = opts.outWidth
                    rawH = opts.outHeight
                } ?: run {
                    showToast("Не удалось открыть файл фото")
                    return@launch
                }

                if (rawW <= 0 || rawH <= 0) {
                    showToast("Файл не является изображением")
                    return@launch
                }

                // Шаг 2: inSampleSize — грузим не более 1024px по длинной стороне
                val targetSize = 1024
                var sample = 1
                var w = rawW; var h = rawH
                while (w / 2 >= targetSize || h / 2 >= targetSize) {
                    sample *= 2; w /= 2; h /= 2
                }

                // Шаг 3: EXIF угол (отдельный стрим)
                val degrees: Float = try {
                    contentResolver.openInputStream(uri)?.use { s ->
                        val exif = ExifInterface(s)
                        when (exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )) {
                            ExifInterface.ORIENTATION_ROTATE_90  -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (e: Exception) {
                    Log.w(TAG, "EXIF read failed: ${e.message}")
                    0f
                }

                // Шаг 4: decode с inSampleSize
                val raw: Bitmap? = contentResolver.openInputStream(uri)?.use { s ->
                    BitmapFactory.decodeStream(s, null,
                        BitmapFactory.Options().apply { inSampleSize = sample })
                }

                if (raw == null) {
                    Log.e(TAG, "decodeStream вернул null для $uri")
                    showToast("Не удалось декодировать изображение")
                    return@launch
                }

                // Шаг 5: поворот если нужно
                val final: Bitmap = if (degrees != 0f) {
                    val m = Matrix().apply { postRotate(degrees) }
                    Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                    // raw не рециклируем — GC справится
                } else raw

                // Детектируем лица на фото донора
                val detectedFaces: List<FaceDetector.Face> = try {
                    if (ModelManager.areModelsReady(this@MainActivity)) {
                        val modelsDir = ModelManager.modelsDir(this@MainActivity)
                        val detector = FaceDetector(File(modelsDir, "det_10g.onnx").absolutePath)
                        val faces = detector.detectOrCenter(final)
                        detector.close()
                        faces
                    } else emptyList()
                } catch (e: Exception) {
                    Log.w(TAG, "Детектор при загрузке фото: ${e.message}")
                    emptyList()
                }

                withContext(Dispatchers.Main) {
                    sourceBitmap = final
                    selectedFaceIndex = 0
                    // Показываем фото, скрываем заглушку
                    ivSourceFace.setImageBitmap(final)
                    ivSourceFace.visibility = View.VISIBLE
                    ivSourcePlaceholder.visibility = View.GONE
                    updateProcessButton()
                    Log.d(TAG, "Фото донора загружено: ${final.width}x${final.height}, лиц: ${detectedFaces.size}")

                    // Если лиц больше одного — предлагаем выбрать
                    if (detectedFaces.size > 1) {
                        showFacePickerDialog(final, detectedFaces)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "loadSourceImage failed", e)
                showToast("Ошибка загрузки фото: ${e.message}")
            }
        }
    }

    private fun loadVideo(uri: Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // Копируем в cache (FFmpeg нужен реальный путь)
                val tmpFile = File(cacheDir, "input_video_${System.currentTimeMillis()}.mp4")
                contentResolver.openInputStream(uri)?.use { inp ->
                    FileOutputStream(tmpFile).use { out -> inp.copyTo(out) }
                }

                val thumb = ThumbnailUtils.createVideoThumbnail(
                    tmpFile.absolutePath,
                    MediaStore.Images.Thumbnails.MINI_KIND
                )

                val sizeMb = tmpFile.length() / 1_048_576
                val info = "${sizeMb} МБ"

                withContext(Dispatchers.Main) {
                    videoFile = tmpFile
                    if (thumb != null) {
                        ivVideoThumb.setImageBitmap(thumb)
                        ivVideoThumb.visibility = View.VISIBLE
                        ivVideoPlaceholder.visibility = View.GONE
                    }
                    tvVideoInfo.text = info
                    updateProcessButton()
                }
            } catch (e: Exception) {
                showToast("Ошибка загрузки видео: ${e.message}")
            }
        }
    }

    private fun updateProcessButton() {
        btnProcess.isEnabled = modelsReady && sourceBitmap != null && videoFile != null
    }

    /**
     * Диалог выбора лица донора когда на фото найдено несколько лиц.
     * Показывает горизонтальный ряд кадрированных лиц — пользователь тапает нужное.
     */
    private fun showFacePickerDialog(bitmap: Bitmap, faces: List<FaceDetector.Face>) {
        val thumbSize = 120.dpToPx()

        // Кадрируем каждое лицо с небольшим отступом
        val thumbs = faces.mapIndexed { idx, face ->
            val padding = (face.bbox.width() * 0.25f).coerceAtLeast(8f)
            val left   = (face.bbox.left   - padding).coerceAtLeast(0f)
            val top    = (face.bbox.top    - padding).coerceAtLeast(0f)
            val right  = (face.bbox.right  + padding).coerceAtMost(bitmap.width.toFloat())
            val bottom = (face.bbox.bottom + padding).coerceAtMost(bitmap.height.toFloat())
            val w = (right - left).toInt().coerceAtLeast(1)
            val h = (bottom - top).toInt().coerceAtLeast(1)
            val crop = Bitmap.createBitmap(bitmap, left.toInt(), top.toInt(), w, h)
            val scaled = Bitmap.createScaledBitmap(crop, thumbSize, thumbSize, true)
            if (scaled !== crop) crop.recycle()
            scaled
        }

        val scrollView = HorizontalScrollView(this).apply {
            val row = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(16.dpToPx(), 16.dpToPx(), 16.dpToPx(), 16.dpToPx())

                thumbs.forEachIndexed { idx, thumb ->
                    val iv = ImageView(context).apply {
                        setImageBitmap(thumb)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        layoutParams = LinearLayout.LayoutParams(thumbSize, thumbSize).apply {
                            marginEnd = 12.dpToPx()
                        }
                        // Рамка для первого (по умолчанию выбранного)
                        if (idx == 0) setBackgroundResource(android.R.drawable.picture_frame)
                    }
                    addView(iv)
                }
            }
            addView(row)
        }

        var chosen = 0

        AlertDialog.Builder(this)
            .setTitle("Выберите лицо донора")
            .setMessage("На фото найдено ${faces.size} лица — выберите нужное")
            .setView(scrollView)
            .setPositiveButton("Готово") { _, _ ->
                selectedFaceIndex = chosen
                Log.d(TAG, "Выбрано лицо донора #$chosen")
            }
            .setNegativeButton("Отмена", null)
            .show()

        // Устанавливаем клик после show() чтобы иметь доступ к дочерним view
        val row = (scrollView.getChildAt(0) as? LinearLayout) ?: return
        for (i in 0 until row.childCount) {
            val iv = row.getChildAt(i) as? ImageView ?: continue
            iv.setOnClickListener {
                // Снимаем рамку с предыдущего, ставим на выбранный
                (row.getChildAt(chosen) as? ImageView)?.background = null
                chosen = i
                iv.setBackgroundResource(android.R.drawable.picture_frame)
            }
        }
    }

    private fun Int.dpToPx(): Int =
        (this * resources.displayMetrics.density + 0.5f).toInt()

    private fun startProcessing() {
        val src = sourceBitmap ?: return
        val vid = videoFile ?: return

        btnProcess.isEnabled = false
        btnSelectSource.isEnabled = false
        btnSelectVideo.isEnabled = false
        layoutResult.visibility = View.GONE
        layoutProgress.visibility = View.VISIBLE
        pbProcess.progress = 0
        tvProgressPercent.text = "0%"
        tvProgressStatus.text = "Инициализация…"

        val processor = VideoProcessor(this)

        lifecycleScope.launch {
            try {
                val result = processor.process(vid, src, selectedFaceIndex) { pct, status ->
                    runOnUiThread {
                        pbProcess.progress = pct
                        tvProgressStatus.text = status
                        tvProgressPercent.text = "$pct%"
                    }
                }
                resultFile = result.outputFile
                withContext(Dispatchers.Main) {
                    layoutProgress.visibility = View.GONE
                    layoutResult.visibility = View.VISIBLE
                    Toast.makeText(this@MainActivity, "Готово!", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Ошибка обработки", e)
                withContext(Dispatchers.Main) {
                    layoutProgress.visibility = View.GONE
                    Toast.makeText(this@MainActivity, "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
                    btnProcess.isEnabled = true
                    btnSelectSource.isEnabled = true
                    btnSelectVideo.isEnabled = true
                }
            }
        }
    }

    private fun saveToGallery() {
        val f = resultFile ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "faceswap_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/FaceSwapAI")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                uri?.let { dest ->
                    contentResolver.openOutputStream(dest)?.use { out ->
                        f.inputStream().use { inp -> inp.copyTo(out) }
                    }
                }
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "Сохранено в галерею", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                showToast("Ошибка сохранения: ${e.message}")
            }
        }
    }

    private fun shareResult() {
        val f = resultFile ?: return
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Поделиться видео"))
    }

    private suspend fun showToast(msg: String) {
        withContext(Dispatchers.Main) {
            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
        }
    }
}
