package com.smartcleaner.app.data

/** Описание одного файла, найденного при сканировании. */
data class FileInfo(
    val path: String,
    val name: String,
    val size: Long,
    val lastModified: Long,
    val width: Int = 0,
    val height: Int = 0,
    val textLength: Int = 0,
    /** content://-адрес документа, если файл найден через системный доступ (SAF) к Android/data или obb. */
    val uri: String? = null
) {
    val extension: String
        get() = name.substringAfterLast('.', "").lowercase()

    val parentPath: String
        get() = path.substringBeforeLast('/', "")

    val isSaf: Boolean get() = uri != null
}

/** Тип содержимого — для анализатора памяти и браузера категорий. */
enum class FileCategory(val title: String, val colorHex: Long) {
    IMAGES("Фото и картинки", 0xFF42A5F5),
    VIDEO("Видео", 0xFFEF5350),
    AUDIO("Аудио", 0xFFAB47BC),
    DOCUMENTS("Документы", 0xFFFFA726),
    ARCHIVES("Архивы", 0xFF8D6E63),
    APK("APK", 0xFF66BB6A),
    OTHER("Другое", 0xFF78909C);

    companion object {
        private val images = setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif", "tif", "tiff", "dng", "raw", "svg")
        private val video = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "m4v", "wmv", "flv", "ts", "mpg", "mpeg")
        private val audio = setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "amr", "wma", "mid", "midi", "3ga")
        private val docs = setOf(
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf", "txt", "md", "csv",
            "json", "xml", "html", "htm", "epub", "fb2", "djvu", "mobi"
        )
        private val archives = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "zst", "obb")

        fun of(extension: String): FileCategory = when (extension.lowercase()) {
            in images -> IMAGES
            in video -> VIDEO
            in audio -> AUDIO
            in docs -> DOCUMENTS
            in archives -> ARCHIVES
            "apk", "apks", "xapk" -> APK
            else -> OTHER
        }
    }
}

enum class JunkCategory(val title: String, val description: String, val safe: Boolean) {
    EMPTY_FOLDER("Пустые папки", "Папки без файлов внутри", true),
    EMPTY_FILE("Пустые файлы", "Файлы размером 0 байт", true),
    TEMP("Временные и журналы", "Файлы .tmp, .temp, .log, .bak, .old, недокачанные загрузки", true),
    THUMBNAILS("Кэш миниатюр", "Папки .thumbnails — система создаст их заново", true),
    APP_CACHE("Кэш приложений", "Файлы в Android/data/<приложение>/cache — приложения создадут их заново", true),
    APK("APK-установщики", "Установочные файлы в «Загрузках»", false),
    LARGE_OLD("Большие старые файлы", "Только рекомендация: проверьте перед удалением", false)
}

data class JunkItem(
    val file: FileInfo,
    val category: JunkCategory,
    val isDirectory: Boolean = false,
    val note: String = "",
    /** Отмечать ли элемент для удаления по умолчанию. */
    val defaultSelected: Boolean = true,
    /** Вердикт ИИ: true — мусор, false — важно, null — не проверялось. */
    val aiJunk: Boolean? = null,
    val aiReason: String = ""
)

enum class GroupType(val title: String) {
    EXACT("Точные дубликаты"),
    SIMILAR_IMAGE("Похожие изображения"),
    SIMILAR_TEXT("Похожие тексты"),
    VERSIONS("Версии одного файла")
}

data class FileGroup(
    val id: Long,
    val type: GroupType,
    val files: List<FileInfo>,
    val keeperIndex: Int,
    val keeperReasons: List<String>,
    val scores: List<Int>,
    val similarityNote: String = "",
    val aiReason: String = "",
    val aiChosen: Boolean = false,
    val aiExplanation: String = "",
    /** Пути файлов, отмеченных для удаления. Основной файл здесь никогда не бывает. */
    val selected: Set<String> = emptySet()
) {
    val keeper: FileInfo get() = files[keeperIndex]

    val selectedBytes: Long
        get() = files.filter { it.path in selected && it.path != keeper.path }.sumOf { it.size }

    val reclaimableBytes: Long
        get() = files.filterIndexed { i, _ -> i != keeperIndex }.sumOf { it.size }
}

/** Папка, которую не удалось прочитать, и причина. */
data class InaccessibleFolder(val path: String, val reason: String)

data class VolumeInfo(val path: String, val title: String, val removable: Boolean, val primary: Boolean)

data class ScanResult(
    val finishedAt: Long,
    val filesScanned: Int,
    val foldersScanned: Int,
    val volumes: List<VolumeInfo>,
    val inaccessible: List<InaccessibleFolder>,
    val allFiles: List<FileInfo>,
    val junk: List<JunkItem>,
    val groups: List<FileGroup>
) {
    val duplicateGroups: List<FileGroup> get() = groups.filter { it.type == GroupType.EXACT }
    val similarGroups: List<FileGroup> get() = groups.filter { it.type != GroupType.EXACT }
}

data class ScanProgress(
    val phase: String = "",
    val filesFound: Int = 0,
    val foldersScanned: Int = 0,
    val junkFound: Int = 0,
    val junkBytes: Long = 0L,
    val volume: String = "",
    val current: String = "",
    /** 0..1 или отрицательное значение, если прогресс неопределённый. */
    val fraction: Float = -1f
)

data class TrashEntry(
    val id: Long,
    val originalPath: String,
    val trashPath: String,
    val size: Long,
    val deletedAt: Long,
    val isDirectory: Boolean
) {
    val name: String get() = originalPath.substringAfterLast('/')
}

data class HistoryEntry(
    val id: Long,
    val time: Long,
    val files: Int,
    val bytes: Long,
    val source: String
)

data class LastScanSummary(
    val time: Long,
    val filesScanned: Int,
    val junkCount: Int,
    val junkBytes: Long,
    val duplicateGroups: Int,
    val duplicateBytes: Long,
    val similarGroups: Int,
    val similarBytes: Long,
    val foldersScanned: Int = 0,
    val inaccessibleCount: Int = 0
)

enum class PhotoIssueKind(val title: String) { BLURRY("Размытое"), DARK("Тёмное") }

data class PhotoIssue(val file: FileInfo, val kinds: Set<PhotoIssueKind>, val sharpness: Double, val brightness: Double)

data class AppCacheInfo(
    val packageName: String,
    val label: String,
    val cacheBytes: Long,
    val dataBytes: Long,
    val appBytes: Long,
    val isSystem: Boolean = false
)
