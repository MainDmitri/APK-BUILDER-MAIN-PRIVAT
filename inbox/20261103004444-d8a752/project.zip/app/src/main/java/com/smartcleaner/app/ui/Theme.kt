package com.smartcleaner.app.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Фирменные цвета: индиго → фиолетовый → бирюзовый.
val Indigo = Color(0xFF3D5AFE)
val Violet = Color(0xFF7C4DFF)
val Teal = Color(0xFF00BFA5)
val Coral = Color(0xFFFF5370)
val Amber = Color(0xFFFFB300)
val Mint = Color(0xFF00C853)

private val LightColors = lightColorScheme(
    primary = Color(0xFF3D5AFE),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE1FF),
    onPrimaryContainer = Color(0xFF001257),
    secondary = Color(0xFF7C4DFF),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEADDFF),
    onSecondaryContainer = Color(0xFF21005D),
    tertiary = Color(0xFF00A88F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFB8F5E8),
    onTertiaryContainer = Color(0xFF00201A),
    error = Color(0xFFD32F45),
    onError = Color.White,
    errorContainer = Color(0xFFFFDADC),
    onErrorContainer = Color(0xFF410009),
    background = Color(0xFFF5F6FB),
    onBackground = Color(0xFF1A1B23),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1A1B23),
    surfaceVariant = Color(0xFFE6E8F2),
    onSurfaceVariant = Color(0xFF454857),
    surfaceContainer = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFF0F1F8),
    surfaceContainerLow = Color(0xFFFAFAFE),
    outline = Color(0xFF767889),
    outlineVariant = Color(0xFFC6C8D6)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8C9EFF),
    onPrimary = Color(0xFF001A7A),
    primaryContainer = Color(0xFF2338C8),
    onPrimaryContainer = Color(0xFFDDE1FF),
    secondary = Color(0xFFB69DFF),
    onSecondary = Color(0xFF34137F),
    secondaryContainer = Color(0xFF4F2BB0),
    onSecondaryContainer = Color(0xFFEADDFF),
    tertiary = Color(0xFF4DE8C8),
    onTertiary = Color(0xFF00382E),
    tertiaryContainer = Color(0xFF005144),
    onTertiaryContainer = Color(0xFFB8F5E8),
    error = Color(0xFFFFB3B8),
    onError = Color(0xFF680016),
    errorContainer = Color(0xFF8F1129),
    onErrorContainer = Color(0xFFFFDADC),
    background = Color(0xFF0E1120),
    onBackground = Color(0xFFE3E4F0),
    surface = Color(0xFF151829),
    onSurface = Color(0xFFE3E4F0),
    surfaceVariant = Color(0xFF262A3F),
    onSurfaceVariant = Color(0xFFC4C6D8),
    surfaceContainer = Color(0xFF1A1E31),
    surfaceContainerHigh = Color(0xFF22263B),
    surfaceContainerLow = Color(0xFF131627),
    outline = Color(0xFF8E90A2),
    outlineVariant = Color(0xFF454857)
)

/** Набор градиентов приложения. */
data class AppGradients(
    val hero: Brush,
    val accent: Brush,
    val success: Brush,
    val danger: Brush,
    val isDark: Boolean
)

val LocalGradients = staticCompositionLocalOf {
    AppGradients(
        hero = Brush.linearGradient(listOf(Indigo, Violet)),
        accent = Brush.linearGradient(listOf(Violet, Teal)),
        success = Brush.linearGradient(listOf(Teal, Mint)),
        danger = Brush.linearGradient(listOf(Coral, Violet)),
        isDark = false
    )
}

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private val AppTypography = Typography().let { t ->
    t.copy(
        headlineLarge = t.headlineLarge.copy(fontWeight = FontWeight.ExtraBold),
        headlineMedium = t.headlineMedium.copy(fontWeight = FontWeight.Bold),
        headlineSmall = t.headlineSmall.copy(fontWeight = FontWeight.Bold),
        titleLarge = t.titleLarge.copy(fontWeight = FontWeight.Bold),
        titleMedium = t.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp)
    )
}

/** Вычисляет, тёмная ли тема для режима (0 — системная, 1 — светлая, 2 — тёмная). */
@Composable
fun isDarkFor(themeMode: Int): Boolean = when (themeMode) {
    1 -> false
    2 -> true
    else -> isSystemInDarkTheme()
}

@Composable
fun SmartCleanerTheme(themeMode: Int = 0, dynamicColor: Boolean = false, content: @Composable () -> Unit) {
    val dark = isDarkFor(themeMode)
    val context = LocalContext.current
    val scheme: ColorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        dark -> DarkColors
        else -> LightColors
    }
    val gradients = if (dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        AppGradients(
            hero = Brush.linearGradient(listOf(scheme.primary, scheme.tertiary)),
            accent = Brush.linearGradient(listOf(scheme.secondary, scheme.tertiary)),
            success = Brush.linearGradient(listOf(Teal, Mint)),
            danger = Brush.linearGradient(listOf(Coral, scheme.secondary)),
            isDark = dark
        )
    } else if (dark) {
        AppGradients(
            hero = Brush.linearGradient(listOf(Color(0xFF2B3BD1), Color(0xFF5B2DC9), Color(0xFF00897B))),
            accent = Brush.linearGradient(listOf(Color(0xFF5B2DC9), Color(0xFF00897B))),
            success = Brush.linearGradient(listOf(Color(0xFF00897B), Color(0xFF2E7D32))),
            danger = Brush.linearGradient(listOf(Color(0xFFC62848), Color(0xFF5B2DC9))),
            isDark = true
        )
    } else {
        AppGradients(
            hero = Brush.linearGradient(listOf(Indigo, Violet, Color(0xFF00B8D4))),
            accent = Brush.linearGradient(listOf(Violet, Teal)),
            success = Brush.linearGradient(listOf(Teal, Mint)),
            danger = Brush.linearGradient(listOf(Coral, Violet)),
            isDark = false
        )
    }
    CompositionLocalProvider(LocalGradients provides gradients) {
        MaterialTheme(colorScheme = scheme, typography = AppTypography, shapes = AppShapes, content = content)
    }
}
