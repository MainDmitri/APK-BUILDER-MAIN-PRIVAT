package com.smartcleaner.app.scan

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import android.provider.Settings
import com.smartcleaner.app.data.AppCacheInfo

/** Размер кэша каждого приложения через StorageStatsManager (нужен доступ к статистике использования). */
object AppCacheStats {

    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

    @Suppress("DEPRECATION")
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun usageAccessIntent(context: Context): Intent {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) intent.data = Uri.parse("package:${context.packageName}")
        return intent
    }

    fun appSettingsIntent(packageName: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Текущий размер кэша одного приложения (для повторного замера после очистки). */
    fun cacheOf(context: Context, packageName: String): Long? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return null
        return try {
            val ssm = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
            ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, packageName, Process.myUserHandle()).cacheBytes
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    fun load(context: Context, isCancelled: () -> Boolean): List<AppCacheInfo> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return emptyList()
        val ssm = context.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val pm = context.packageManager
        val apps: List<ApplicationInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        } else {
            pm.getInstalledApplications(0)
        }
        val user = Process.myUserHandle()
        val result = ArrayList<AppCacheInfo>()
        for (app in apps) {
            if (isCancelled()) break
            try {
                val stats = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, app.packageName, user)
                if (stats.cacheBytes <= 0L) continue
                result.add(
                    AppCacheInfo(
                        packageName = app.packageName,
                        label = pm.getApplicationLabel(app).toString(),
                        cacheBytes = stats.cacheBytes,
                        dataBytes = stats.dataBytes,
                        appBytes = stats.appBytes,
                        isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                            (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                    )
                )
            } catch (e: Exception) {
                // Пакет мог быть удалён или недоступен — пропускаем.
            }
        }
        return result.sortedByDescending { it.cacheBytes }
    }
}
