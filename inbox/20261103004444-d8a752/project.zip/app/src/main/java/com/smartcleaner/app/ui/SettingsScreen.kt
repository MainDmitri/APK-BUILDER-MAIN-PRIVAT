package com.smartcleaner.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.smartcleaner.app.autoclean.AutoCleaner
import com.smartcleaner.app.scan.AppCacheStats
import com.smartcleaner.app.scan.StorageAccess
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    var showKey by remember { mutableStateOf(false) }
    var showConsent by remember { mutableStateOf(false) }
    var pendingReminder by remember { mutableStateOf(0) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.updateReminder(pendingReminder)
        else vm.message = "Без разрешения на уведомления напоминания не придут. Разрешите их в настройках приложения."
    }
    fun setReminder(days: Int) {
        if (days > 0 && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingReminder = days
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            vm.updateReminder(days)
        }
    }

    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState())) {
        GradientHeader("Настройки", subtitle = "Умный Cleaner 1.1 · Android ${Build.VERSION.RELEASE}")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            Section("Внешний вид") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Как в системе", "Светлая", "Тёмная").forEachIndexed { i, t ->
                        FilterChip(selected = vm.themeMode == i, onClick = { vm.updateTheme(i) }, label = { Text(t) })
                    }
                }
                if (Build.VERSION.SDK_INT >= 31) {
                    SwitchRow("Цвета обоев (Material You)", vm.dynamicColor) { vm.updateDynamicColor(it) }
                }
            }

            Section("Напоминания") {
                Text("Напоминать о сканировании", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    for (d in listOf(0, 3, 7, 14, 30)) {
                        FilterChip(selected = vm.reminderDays == d, onClick = { setReminder(d) }, label = { Text(if (d == 0) "Выкл." else "$d дн.") })
                    }
                }
            }

            Section("Доступы") {
                val allFiles = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else vm.hasPermission
                StatusRow("Доступ ко всем файлам", allFiles)
                StatusRow("Статистика использования (кэш приложений)", vm.usageAccess)
                if (!vm.usageAccess && AppCacheStats.supported()) {
                    OutlinedButton(onClick = { openSafely(context, AppCacheStats.usageAccessIntent(context)) { vm.message = it } }) { Text("Выдать доступ к статистике") }
                }
                StatusRow("Служба автоочистки кэша", vm.accessibilityEnabled)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { openSafely(context, AutoCleaner.accessibilitySettingsIntent()) { vm.message = it } }) { Text("Спец. возможности") }
                    TextButton(onClick = { openSafely(context, AutoCleaner.ownDetailsIntent(context)) { vm.message = it } }) { Text("О приложении") }
                }
                if (StorageAccess.safSupported()) {
                    HorizontalDivider()
                    Text("Доступ к Android/data и obb (Android 11–12L): ${if (vm.safGrants.isEmpty()) "не выдан" else vm.safGrants.size.toString() + " папк."}")
                    if (vm.safGrants.isNotEmpty()) TextButton(onClick = { vm.revokeSafGrants() }) { Text("Отозвать доступ") }
                }
            }

            Section("Автоочистка кэша") {
                Text("Выбирать по умолчанию приложения с кэшем больше ${vm.autoCacheMinMb} МБ")
                Slider(
                    value = vm.autoCacheMinMb.toFloat().coerceIn(0f, 200f),
                    onValueChange = { vm.updateAutoCacheMin(it.roundToInt()) },
                    valueRange = 0f..200f
                )
                Text(
                    "Служба нажимает только «Хранилище и кэш» и «Очистить кэш» в системных настройках. «Очистить данные», «Удалить», «Остановить» заблокированы в коде.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Section("Чувствительность") {
                Text("Похожие изображения: расстояние ≤ ${vm.imageThreshold} из 64 бит")
                Slider(value = vm.imageThreshold.toFloat(), onValueChange = { vm.imageThreshold = it.roundToInt() }, valueRange = 0f..16f, steps = 15)
                Text("Похожие тексты: сходство ≥ ${vm.textThreshold}%")
                Slider(value = vm.textThreshold.toFloat(), onValueChange = { vm.textThreshold = it.roundToInt() }, valueRange = 50f..99f)
                Text("Размытые фото: резкость < ${vm.blurThreshold}")
                Slider(value = vm.blurThreshold.toFloat(), onValueChange = { vm.blurThreshold = it.roundToInt() }, valueRange = 10f..300f)
                Text("Больше — строже: больше фото считаются размытыми.", style = MaterialTheme.typography.bodySmall)
                HorizontalDivider()
                NumberField("Большой файл, от (МБ)", vm.largeFileMb) { vm.largeFileMb = it }
                NumberField("Старый файл, не изменялся (дней)", vm.oldFileDays) { vm.oldFileDays = it }
                NumberField("Медиа мессенджеров старше (дней)", vm.messengerDays) { vm.messengerDays = it }
                NumberField("Хранить в корзине (дней)", vm.trashDays) { vm.trashDays = it }
            }

            Section("Исключённые папки") {
                Text(
                    "Сканируются все тома (внутренняя память, SD, USB), включая скрытые папки. Исключить можно по одной папке на строку, " +
                        "например: DCIM/Camera или /storage/XXXX-XXXX/Backup. Корзина приложения пропускается всегда.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = vm.excludedFolders, onValueChange = { vm.excludedFolders = it },
                    modifier = Modifier.fillMaxWidth().height(130.dp),
                    placeholder = { Text("Telegram\nDocuments/Важное") }
                )
            }

            Section("ИИ Google Gemini") {
                SwitchRow("Использовать ИИ", vm.aiEnabled) { on ->
                    if (on && !vm.aiConsent) showConsent = true
                    else {
                        vm.aiEnabled = on
                        vm.saveSettings(showMessage = false)
                    }
                }
                Text(
                    "Когда ИИ включён, имена файлов, папки, даты, короткие фрагменты текстов и (если разрешено) уменьшенные фото отправляются в Google только по вашей команде. Без ИИ всё работает локально.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error
                )
                OutlinedTextField(
                    value = vm.apiKey, onValueChange = { vm.apiKey = it.trim() },
                    label = { Text("Ключ Gemini API") }, placeholder = { Text("Вставьте ключ из Google AI Studio") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) { Icon(Icons.Filled.Lock, contentDescription = if (showKey) "Скрыть ключ" else "Показать ключ") }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                if (vm.settings.apiKey.isNotEmpty()) Text("Сохранён ключ: ${maskKey(vm.settings.apiKey)}", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey")))
                        } catch (e: Exception) {
                            vm.message = "Откройте aistudio.google.com/app/apikey в браузере"
                        }
                    }) { Text("Получить ключ") }
                    TextButton(onClick = { vm.clearApiKey() }) { Text("Удалить ключ") }
                }
                OutlinedTextField(
                    value = vm.model, onValueChange = { vm.model = it.trim() }, label = { Text("Модель") },
                    supportingText = { Text("По умолчанию gemini-2.5-flash") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                SwitchRow("Отправлять уменьшенные фото", vm.aiSendImages) { vm.aiSendImages = it }
                if (vm.aiConsent) {
                    TextButton(onClick = {
                        vm.aiConsent = false
                        vm.aiEnabled = false
                        vm.saveSettings(showMessage = false)
                    }) { Text("Отозвать согласие на отправку данных") }
                }
            }

            Section("Ещё") {
                TextButton(onClick = { vm.refreshHistory(); vm.navigate(Screen.History) }) { Text("История очисток") }
                TextButton(onClick = { vm.navigate(Screen.Inaccessible) }) { Text("Какие папки недоступны и почему") }
            }

            Button(onClick = { vm.saveSettings() }, modifier = Modifier.fillMaxWidth()) { Text("Сохранить") }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Отправка данных в Google") },
            text = {
                Text(
                    "Для работы ИИ приложение отправит в Google Gemini API метаданные файлов (имя, папка, размер, дата), " +
                        "фрагменты текстов до 1200 символов и уменьшенные копии изображений (если разрешено). " +
                        "Данные отправляются только когда вы нажимаете кнопки ИИ. Используется ваш личный ключ API. " +
                        "Ничего не удаляется без вашего подтверждения."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.aiConsent = true
                    vm.aiEnabled = true
                    vm.saveSettings(showMessage = false)
                    showConsent = false
                }) { Text("Согласен") }
            },
            dismissButton = { TextButton(onClick = { showConsent = false }) { Text("Отмена") } }
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    SectionCard {
        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    }
}

@Composable
private fun SwitchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun StatusRow(text: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
        Text(if (ok) "✓ есть" else "нет", color = if (ok) Teal else MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(6)) },
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
}
