package com.smartcleaner.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.scan.StorageAccess

@Composable
fun HomeScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val legacyLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshPermission()
    }
    val requestPermission: () -> Unit = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                context.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                )
            } catch (e: Exception) {
                context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyLauncher.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
        }
    }
    val safLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        vm.onSafGranted(r.data?.data)
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        GradientHeader(title = "Умный Cleaner", subtitle = "Чистая память без потерь") {
            Crossfade(targetState = vm.scanning, label = "hero") { scanning ->
                if (scanning) ScanPanel(vm) else GaugePanel(vm)
            }
        }

        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            AnimatedVisibility(!vm.hasPermission, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                SectionCard(containerColor = MaterialTheme.colorScheme.errorContainer) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Lock, MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Нужен доступ к файлам", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
                                    "Разрешите «Доступ ко всем файлам», чтобы найти мусор во всех папках."
                                else "Разрешите чтение и запись памяти.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    GradientButton("Выдать доступ", onClick = requestPermission, modifier = Modifier.fillMaxWidth())
                }
            }

            if (!vm.scanning) {
                GradientButton(
                    text = if (vm.hasResults) "Сканировать заново" else "Начать сканирование",
                    onClick = { if (vm.hasPermission) vm.startScan() else requestPermission() },
                    icon = Icons.Filled.Search,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (vm.hasResults && !vm.scanning) {
                val safe = vm.oneTapItems()
                SectionCard(onClick = { vm.navigate(Screen.OneTap) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Star, Teal)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Очистка в одно касание", style = MaterialTheme.typography.titleMedium)
                            Text(
                                if (safe.isEmpty()) "Безопасного мусора не осталось"
                                else "${safe.size} безопасных файлов · ${formatSize(safe.sumOf { it.file.size })}",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            vm.summary?.let { s ->
                SectionCard(onClick = if (vm.hasResults) ({ vm.selectTab(Screen.Results) }) else null) {
                    Text("Последнее сканирование", style = MaterialTheme.typography.titleMedium)
                    Text(formatDate(s.time), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatPill(formatSize(s.junkBytes), "мусор", Modifier.weight(1f), light = false)
                        StatPill(formatSize(s.duplicateBytes), "дубликаты", Modifier.weight(1f), light = false)
                        StatPill(formatSize(s.similarBytes), "похожие", Modifier.weight(1f), light = false)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Файлов: ${s.filesScanned} · папок: ${s.foldersScanned} · без доступа: ${s.inaccessibleCount}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!vm.hasResults) {
                        Text("Результаты не сохраняются между запусками — запустите сканирование снова.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                SectionCard(onClick = { vm.navigate(Screen.AppCaches) }, containerColor = MaterialTheme.colorScheme.primaryContainer) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Build, MaterialTheme.colorScheme.primary, size = 52.dp)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Кэш приложений", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                when {
                                    !vm.usageAccess -> "Узнайте, сколько места занимает кэш каждого приложения"
                                    vm.appCacheTotal > 0 -> "${formatSize(vm.appCacheTotal)} можно освободить"
                                    else -> "Размеры и очистка кэша"
                                },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    GradientButton(
                        text = if (vm.accessibilityEnabled) "Очистить кэш автоматически" else "Открыть и очистить",
                        onClick = { vm.navigate(Screen.AppCaches) },
                        modifier = Modifier.fillMaxWidth(),
                        brush = LocalGradients.current.success
                    )
                }
            }

            if (vm.volumeStats.isNotEmpty()) {
                SectionCard {
                    Text("Хранилища", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    for (v in vm.volumeStats) {
                        val used = (v.total - v.free).coerceAtLeast(0)
                        val f = if (v.total > 0) used.toFloat() / v.total else 0f
                        Text(
                            v.info.title + if (v.info.removable) " (съёмный)" else "",
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)
                        )
                        LinearProgressIndicator(
                            progress = { f },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            strokeCap = StrokeCap.Round
                        )
                        Text(
                            "Занято ${formatSize(used)} из ${formatSize(v.total)} · ${v.info.path}",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            AndroidDataCard(vm, onGrant = { sub -> safLauncher.launch(StorageAccess.openTreeIntent(sub)) })
            Spacer(Modifier.height(8.dp))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GaugePanel(vm: MainViewModel) {
    val total = vm.storageTotal
    val used = (total - vm.storageFree).coerceAtLeast(0)
    val usedFraction = if (total > 0) used.toFloat() / total else 0f
    val stats = vm.categoryStats
    val segments = if (total > 0) stats.filter { it.bytes > 0 }.map { GaugeSegment(it.bytes.toFloat() / total, categoryColor(it.category)) } else emptyList()
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        StorageGauge(usedFraction = usedFraction, segments = segments, modifier = Modifier.size(220.dp).padding(8.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(usedFraction * 100).toInt()}%", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                Text("занято", color = Color.White.copy(alpha = 0.85f))
                Text("${formatSize(used)} из ${formatSize(total)}", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
        if (segments.isNotEmpty()) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (s in stats.filter { it.bytes > 0 }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(categoryColor(s.category)))
                        Spacer(Modifier.width(4.dp))
                        Text("${shortTitle(s.category)} ${formatSize(s.bytes)}", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        } else {
            Text("Запустите сканирование, чтобы увидеть, чем занята память", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatPill(formatSize(vm.storageFree), "свободно", Modifier.weight(1f))
            StatPill(vm.summary?.let { formatSize(it.junkBytes + it.duplicateBytes) } ?: "—", "можно освободить", Modifier.weight(1f))
            StatPill(formatSize(vm.trashSize), "в корзине", Modifier.weight(1f))
        }
    }
}

fun shortTitle(c: FileCategory): String = when (c) {
    FileCategory.IMAGES -> "Фото"
    FileCategory.VIDEO -> "Видео"
    FileCategory.AUDIO -> "Аудио"
    FileCategory.DOCUMENTS -> "Документы"
    FileCategory.ARCHIVES -> "Архивы"
    FileCategory.APK -> "APK"
    FileCategory.OTHER -> "Другое"
}

/** Анимированная панель сканирования: вращающиеся дуги, пульсация и живые счётчики. */
@Composable
private fun ScanPanel(vm: MainViewModel) {
    val p = vm.progress
    val t = rememberInfiniteTransition(label = "scan")
    val rotation by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "rot")
    val rotation2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "rot2")
    val pulse by t.animateFloat(0.9f, 1.08f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "pulse")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(220.dp).padding(8.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().rotate(rotation)) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, Color.White, Color.Transparent)),
                    startAngle = 0f, sweepAngle = 300f, useCenter = false,
                    style = Stroke(14.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            Canvas(Modifier.fillMaxSize().padding(26.dp).rotate(rotation2)) {
                drawArc(
                    color = Teal, startAngle = 0f, sweepAngle = 110f, useCenter = false,
                    style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    color = Color.White.copy(alpha = 0.5f), startAngle = 180f, sweepAngle = 70f, useCenter = false,
                    style = Stroke(6.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            Box(
                Modifier.size(110.dp).scale(pulse).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (p.fraction >= 0f) "${(p.fraction * 100).toInt()}%" else p.filesFound.toString(),
                        color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Text(if (p.fraction >= 0f) "анализ" else "файлов", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                }
            }
        }
        Text(p.phase, color = Color.White, style = MaterialTheme.typography.titleMedium)
        if (p.volume.isNotBlank()) Text(p.volume, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
        Text(
            p.current.takeLast(56).ifBlank { " " }, color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(10.dp))
        if (p.fraction >= 0f) {
            LinearProgressIndicator(
                progress = { p.fraction }, color = Color.White, trackColor = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
            )
        } else {
            LinearProgressIndicator(
                color = Color.White, trackColor = Color.White.copy(alpha = 0.25f),
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            StatPill(p.filesFound.toString(), "файлов", Modifier.weight(1f))
            StatPill(p.foldersScanned.toString(), "папок", Modifier.weight(1f))
            StatPill("${p.junkFound}", "мусор", Modifier.weight(1f))
            StatPill(formatSize(p.junkBytes), "объём", Modifier.weight(1f))
        }
        TextButton(onClick = { vm.cancelScan() }) { Text("Остановить", color = Color.White) }
    }
}

/** Честная карточка про Android/data и Android/obb для текущей версии Android. */
@Composable
private fun AndroidDataCard(vm: MainViewModel, onGrant: (String) -> Unit) {
    val sdk = Build.VERSION.SDK_INT
    if (sdk < Build.VERSION_CODES.R) return
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(if (StorageAccess.androidDataBlocked()) Icons.Filled.Warning else Icons.Filled.Info, Amber)
            Spacer(Modifier.width(12.dp))
            Text("Папки Android/data и Android/obb", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        if (StorageAccess.safSupported()) {
            Text(
                "На Android 11–12 система не даёт читать эти папки напрямую даже с «Доступом ко всем файлам». " +
                    "Можно один раз выдать системный доступ: откроется выбор папки — нажмите «Использовать эту папку». " +
                    "После этого сканер найдёт кэш приложений внутри.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onGrant("data") }, enabled = !vm.hasSafFor("data")) {
                    Text(if (vm.hasSafFor("data")) "data ✓" else "Доступ к data")
                }
                OutlinedButton(onClick = { onGrant("obb") }, enabled = !vm.hasSafFor("obb")) {
                    Text(if (vm.hasSafFor("obb")) "obb ✓" else "Доступ к obb")
                }
            }
            Text(
                "Файлы, удаляемые через системный доступ, не попадают в корзину — приложение предупредит об этом.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Text(
                "С Android 13 эти папки полностью закрыты для сторонних приложений — так устроена защита Android, " +
                    "обойти её без root нельзя. Зато можно узнать размер кэша каждого приложения и очистить его в системных настройках.",
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.navigate(Screen.AppCaches) }) {
                Icon(Icons.Filled.Build, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Кэш приложений")
            }
        }
        if (vm.hasResults && vm.inaccessible.isNotEmpty()) {
            TextButton(onClick = { vm.navigate(Screen.Inaccessible) }) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Недоступные папки: ${vm.inaccessible.size}")
            }
        }
    }
}
