package com.smartcleaner.app.ui

import android.app.Application
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartcleaner.app.ai.GeminiClient
import com.smartcleaner.app.autoclean.AutoCleaner
import com.smartcleaner.app.data.AppCacheInfo
import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.FileInfo
import com.smartcleaner.app.data.GroupType
import com.smartcleaner.app.data.HistoryEntry
import com.smartcleaner.app.data.InaccessibleFolder
import com.smartcleaner.app.data.JunkCategory
import com.smartcleaner.app.data.JunkItem
import com.smartcleaner.app.data.LastScanSummary
import com.smartcleaner.app.data.PhotoIssue
import com.smartcleaner.app.data.PhotoIssueKind
import com.smartcleaner.app.data.ScanProgress
import com.smartcleaner.app.data.SettingsRepository
import com.smartcleaner.app.data.TrashEntry
import com.smartcleaner.app.data.TrashManager
import com.smartcleaner.app.data.VolumeInfo
import com.smartcleaner.app.reminder.ReminderScheduler
import com.smartcleaner.app.scan.AppCacheStats
import com.smartcleaner.app.scan.KeeperScorer
import com.smartcleaner.app.scan.PhotoQuality
import com.smartcleaner.app.scan.ScanConfig
import com.smartcleaner.app.scan.Scanner
import com.smartcleaner.app.scan.StorageAccess
import com.smartcleaner.app.scan.StorageAnalyzer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed class Screen {
    // Корневые вкладки нижней навигации
    data object Home : Screen()
    data object Results : Screen()
    data object Tools : Screen()
    data object Trash : Screen()
    data object Settings : Screen()

    // Вложенные экраны
    data class GroupDetail(val groupId: Long) : Screen()
    data class Analyzer(val path: String?) : Screen()
    data object LargestFiles : Screen()
    data class Category(val category: FileCategory) : Screen()
    data object Photos : Screen()
    data object Screenshots : Screen()
    data object Messengers : Screen()
    data object OneTap : Screen()
    data object History : Screen()
    data object AppCaches : Screen()
    data object Inaccessible : Screen()
    data class Success(val bytes: Long, val files: Int, val failed: Int) : Screen()

    val isRoot: Boolean get() = this in rootTabs

    companion object {
        val rootTabs: List<Screen> by lazy { listOf(Home, Results, Tools, Trash, Settings) }
    }
}

enum class ResultTab(val title: String) { JUNK("Мусор"), DUPLICATES("Дубликаты"), SIMILAR("Похожие") }

enum class CategorySort(val title: String) { SIZE("По размеру"), DATE_NEW("Сначала новые"), DATE_OLD("Сначала старые"), NAME("По имени") }

data class VolumeStat(val info: VolumeInfo, val total: Long, val free: Long)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val settings = SettingsRepository(app)
    private val trash = TrashManager(app)

    // ---------- Навигация ----------
    val backStack = mutableStateListOf<Screen>(Screen.Home)
    val currentScreen: Screen get() = backStack.last()
    val currentTab: Screen get() = backStack.first()

    fun navigate(screen: Screen) {
        if (screen.isRoot) selectTab(screen) else backStack.add(screen)
    }

    fun selectTab(tab: Screen) {
        backStack.clear()
        backStack.add(tab)
        if (tab == Screen.Trash) refreshTrash()
    }

    fun back(): Boolean {
        if (backStack.size <= 1) {
            if (currentScreen != Screen.Home) {
                selectTab(Screen.Home)
                return true
            }
            return false
        }
        backStack.removeAt(backStack.lastIndex)
        return true
    }

    // ---------- Общее состояние ----------
    var hasPermission by mutableStateOf(false)
        private set
    var storageTotal by mutableStateOf(0L)
        private set
    var storageFree by mutableStateOf(0L)
        private set
    var volumeStats by mutableStateOf<List<VolumeStat>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set
    var progress by mutableStateOf(ScanProgress())
        private set
    var summary by mutableStateOf<LastScanSummary?>(null)
        private set
    var hasResults by mutableStateOf(false)
        private set
    var message by mutableStateOf<String?>(null)
    var aiBusy by mutableStateOf(false)
        private set
    var aiStatus by mutableStateOf("")
        private set
    var deleting by mutableStateOf(false)
        private set
    var selectedTab by mutableStateOf(ResultTab.JUNK)

    val junk = mutableStateListOf<JunkItem>()
    val junkSelected = mutableStateMapOf<String, Boolean>()
    val groups = mutableStateListOf<FileGroup>()
    val trashEntries = mutableStateListOf<TrashEntry>()
    var trashSize by mutableStateOf(0L)
        private set

    var allFiles by mutableStateOf<List<FileInfo>>(emptyList())
        private set
    var scannedVolumes by mutableStateOf<List<VolumeInfo>>(emptyList())
        private set
    var inaccessible by mutableStateOf<List<InaccessibleFolder>>(emptyList())
        private set
    var categoryStats by mutableStateOf<List<StorageAnalyzer.CategoryStat>>(emptyList())
        private set
    private var folderIndexCache: StorageAnalyzer.FolderIndex? = null
    var folderIndex by mutableStateOf<StorageAnalyzer.FolderIndex?>(null)
        private set

    // Выбор в списках инструментов (категории, скриншоты, мессенджеры, фото)
    val listSelection = mutableStateMapOf<String, Boolean>()
    val aiVerdicts = mutableStateMapOf<String, Pair<Boolean, String>>()
    var categorySort by mutableStateOf(CategorySort.SIZE)
    var categoryFilter by mutableStateOf("")

    // Фото
    val photoIssues = mutableStateListOf<PhotoIssue>()
    var photoScanning by mutableStateOf(false)
        private set
    var photoProgress by mutableStateOf(0f)
        private set
    var photoChecked by mutableStateOf(false)
        private set
    private var photoJob: Job? = null

    // Кэш приложений
    val appCaches = mutableStateListOf<AppCacheInfo>()
    var appCacheLoading by mutableStateOf(false)
        private set
    var usageAccess by mutableStateOf(false)
        private set
    var appCacheTotal by mutableStateOf(0L)
        private set

    // Автоочистка кэша через службу спец. возможностей
    var accessibilityEnabled by mutableStateOf(false)
        private set
    var autoState by mutableStateOf(AutoCleaner.state.value)
        private set
    val autoSelection = mutableStateMapOf<String, Boolean>()
    var autoCacheMinMb by mutableStateOf(settings.autoCacheMinMb)
        private set

    // ИИ-итог сканирования
    var aiSummary by mutableStateOf<GeminiClient.AiSummary?>(null)
        private set
    var aiSummaryError by mutableStateOf<String?>(null)
        private set

    // История
    val history = mutableStateListOf<HistoryEntry>()

    // SAF
    var safGrants by mutableStateOf<List<String>>(emptyList())
        private set

    // ---------- Поля настроек ----------
    var apiKey by mutableStateOf(settings.apiKey)
    var model by mutableStateOf(settings.model)
    var aiEnabled by mutableStateOf(settings.aiEnabled)
    var aiSendImages by mutableStateOf(settings.aiSendImages)
    var aiConsent by mutableStateOf(settings.aiConsent)
    var imageThreshold by mutableStateOf(settings.imageThreshold)
    var textThreshold by mutableStateOf(settings.textThresholdPercent)
    var largeFileMb by mutableStateOf(settings.largeFileMb.toString())
    var oldFileDays by mutableStateOf(settings.oldFileDays.toString())
    var trashDays by mutableStateOf(settings.trashDays.toString())
    var excludedFolders by mutableStateOf(settings.excludedFolders)
    var blurThreshold by mutableStateOf(settings.blurThreshold)
    var messengerDays by mutableStateOf(settings.messengerDays.toString())
    var themeMode by mutableStateOf(settings.themeMode)
        private set
    var dynamicColor by mutableStateOf(settings.dynamicColor)
        private set
    var reminderDays by mutableStateOf(settings.reminderDays)
        private set
    var showOnboarding by mutableStateOf(!settings.onboardingDone)
        private set

    private var scanJob: Job? = null

    init {
        viewModelScope.launch { AutoCleaner.state.collect { autoState = it } }
        summary = settings.loadSummary()
        refreshStorage()
        refreshSafGrants()
        viewModelScope.launch(Dispatchers.IO) {
            val purged = trash.purgeOlderThan(settings.trashDays)
            withContext(Dispatchers.Main) {
                if (purged > 0) message = "Автоочистка корзины: удалено навсегда $purged"
                refreshTrash()
                refreshHistory()
            }
        }
    }

    val aiAvailable: Boolean get() = aiEnabled && aiConsent && apiKey.isNotBlank()

    fun finishOnboarding() {
        settings.onboardingDone = true
        showOnboarding = false
    }

    fun refreshPermission() {
        val ctx = getApplication<Application>()
        hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ctx.checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
                ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        accessibilityEnabled = AutoCleaner.isServiceEnabled(ctx)
        val hadAccess = usageAccess
        usageAccess = AppCacheStats.supported() && AppCacheStats.hasUsageAccess(ctx)
        // После возврата из системных настроек обновляем размеры кэша (пользователь мог его очистить).
        if (usageAccess && (hadAccess || appCaches.isEmpty())) loadAppCaches(force = true)
        refreshSafGrants()
        refreshStorage()
    }

    fun refreshStorage() {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            storageTotal = stat.totalBytes
            storageFree = stat.availableBytes
        } catch (e: Exception) {
            storageTotal = 0L
            storageFree = 0L
        }
        volumeStats = try {
            StorageAccess.volumes(getApplication()).mapNotNull { v ->
                try {
                    val s = StatFs(v.path)
                    VolumeStat(v, s.totalBytes, s.availableBytes)
                } catch (e: Exception) {
                    null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ---------- SAF ----------
    fun refreshSafGrants() {
        val valid = StorageAccess.validGrants(getApplication(), settings.safTreeUris)
        safGrants = valid.map { it.toString() }
        if (valid.size != settings.safTreeUris.size) settings.safTreeUris = valid.map { it.toString() }.toSet()
    }

    fun onSafGranted(uri: Uri?) {
        if (uri == null) {
            message = "Доступ не выдан"
            return
        }
        if (StorageAccess.persistGrant(getApplication(), uri)) {
            settings.safTreeUris = settings.safTreeUris + uri.toString()
            refreshSafGrants()
            message = "Доступ к ${StorageAccess.treeLabel(uri)} получен. Запустите сканирование"
        } else {
            message = "Выберите именно папку Android/data или Android/obb и нажмите «Использовать эту папку»"
        }
    }

    fun revokeSafGrants() {
        val ctx = getApplication<Application>()
        for (u in settings.safTreeUris) {
            try {
                ctx.contentResolver.releasePersistableUriPermission(
                    Uri.parse(u),
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (e: Exception) {
                // уже отозвано
            }
        }
        settings.safTreeUris = emptySet()
        refreshSafGrants()
        message = "Системный доступ к Android/data и obb отозван"
    }

    fun hasSafFor(sub: String): Boolean = safGrants.any { StorageAccess.treeLabel(Uri.parse(it)).startsWith("Android/$sub") }

    // ---------- Сканирование ----------
    fun startScan() {
        if (scanning) return
        if (!hasPermission) {
            message = "Сначала предоставьте доступ к файлам"
            return
        }
        saveSettings(showMessage = false)
        scanning = true
        selectTab(Screen.Home)
        progress = ScanProgress("Подготовка")
        val ctx = getApplication<Application>()
        val primary = Environment.getExternalStorageDirectory().absolutePath
        val volumes = StorageAccess.volumes(ctx).ifEmpty { listOf(VolumeInfo(primary, "Внутренняя память", false, true)) }
        val config = ScanConfig(
            volumes = volumes,
            primaryRoot = primary,
            safTrees = if (StorageAccess.safSupported()) StorageAccess.validGrants(ctx, settings.safTreeUris) else emptyList(),
            excluded = settings.excludedList(primary),
            trashDir = trash.trashDir,
            largeFileBytes = settings.largeFileMb.toLong() * 1024L * 1024L,
            oldFileMs = settings.oldFileDays.toLong() * 86_400_000L,
            imageThreshold = settings.imageThreshold,
            textThreshold = settings.textThresholdPercent / 100.0
        )
        scanJob = viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    Scanner(ctx, config).scan { p ->
                        viewModelScope.launch(Dispatchers.Main) { if (scanning) progress = p }
                    }
                }
                junk.clear()
                junk.addAll(result.junk)
                junkSelected.clear()
                result.junk.forEach { junkSelected[keyOf(it)] = it.defaultSelected }
                groups.clear()
                groups.addAll(result.groups)
                allFiles = result.allFiles
                scannedVolumes = result.volumes
                inaccessible = result.inaccessible
                folderIndexCache = null
                folderIndex = null
                photoIssues.clear()
                photoChecked = false
                aiSummary = null
                aiSummaryError = null
                categoryStats = withContext(Dispatchers.Default) { StorageAnalyzer.breakdown(result.allFiles) }
                hasResults = true
                val s = LastScanSummary(
                    time = result.finishedAt,
                    filesScanned = result.filesScanned,
                    junkCount = result.junk.size,
                    junkBytes = result.junk.sumOf { it.file.size },
                    duplicateGroups = result.duplicateGroups.size,
                    duplicateBytes = result.duplicateGroups.sumOf { it.reclaimableBytes },
                    similarGroups = result.similarGroups.size,
                    similarBytes = result.similarGroups.sumOf { it.reclaimableBytes },
                    foldersScanned = result.foldersScanned,
                    inaccessibleCount = result.inaccessible.size
                )
                settings.saveSummary(s)
                summary = s
                selectedTab = ResultTab.JUNK
                selectTab(Screen.Results)
            } catch (e: CancellationException) {
                message = "Сканирование остановлено"
                throw e
            } catch (e: Exception) {
                message = "Ошибка сканирования: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                scanning = false
                refreshStorage()
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        scanJob = null
        scanning = false
    }

    // ---------- Выбор в результатах ----------
    fun keyOf(item: JunkItem): String = item.category.name + "|" + item.file.path

    fun toggleJunk(item: JunkItem) {
        val k = keyOf(item)
        junkSelected[k] = !(junkSelected[k] ?: false)
    }

    fun setCategorySelected(category: JunkCategory, selected: Boolean) {
        junk.filter { it.category == category }.forEach { junkSelected[keyOf(it)] = selected }
    }

    fun groupById(id: Long): FileGroup? = groups.firstOrNull { it.id == id }

    private fun updateGroup(id: Long, transform: (FileGroup) -> FileGroup) {
        val i = groups.indexOfFirst { it.id == id }
        if (i >= 0) groups[i] = transform(groups[i])
    }

    fun toggleGroupFile(groupId: Long, path: String) {
        updateGroup(groupId) { g ->
            if (path == g.keeper.path) g
            else g.copy(selected = if (path in g.selected) g.selected - path else g.selected + path)
        }
    }

    fun setKeeper(groupId: Long, index: Int, aiReason: String = "", byAi: Boolean = false) {
        updateGroup(groupId) { g ->
            if (index !in g.files.indices) return@updateGroup g
            val newKeeper = g.files[index].path
            val reasons = if (byAi) g.keeperReasons else listOf("Выбран вами вручную")
            g.copy(
                keeperIndex = index,
                keeperReasons = reasons,
                aiReason = aiReason,
                aiChosen = byAi,
                selected = g.files.map { it.path }.filter { it != newKeeper }.toSet()
            )
        }
    }

    fun setAllInGroup(groupId: Long, selected: Boolean) {
        updateGroup(groupId) { g ->
            g.copy(selected = if (selected) g.files.map { it.path }.filter { it != g.keeper.path }.toSet() else emptySet())
        }
    }

    fun groupsFor(tab: ResultTab): List<FileGroup> = when (tab) {
        ResultTab.DUPLICATES -> groups.filter { it.type == GroupType.EXACT }
        ResultTab.SIMILAR -> groups.filter { it.type != GroupType.EXACT }
        ResultTab.JUNK -> emptyList()
    }

    data class PendingDeletion(
        val paths: List<String>,
        val bytes: Long,
        val count: Int,
        val fromGroups: Boolean,
        val source: String,
        /** Сколько файлов будет удалено сразу (через системный доступ), минуя корзину. */
        val permanentCount: Int = 0
    )

    private val keeperPaths: Set<String> get() = groups.map { it.keeper.path }.toSet()

    private fun safUriOf(path: String): String? =
        junk.firstOrNull { it.file.path == path }?.file?.uri ?: allFiles.firstOrNull { it.path == path }?.uri

    private fun pendingOf(files: List<FileInfo>, fromGroups: Boolean, source: String): PendingDeletion {
        val unique = files.distinctBy { it.path }.filter { !fromGroups || it.path !in keeperPaths }
        return PendingDeletion(unique.map { it.path }, unique.sumOf { it.size }, unique.size, fromGroups, source, unique.count { it.isSaf })
    }

    fun pendingFor(tab: ResultTab): PendingDeletion {
        return if (tab == ResultTab.JUNK) {
            val items = junk.filter { junkSelected[keyOf(it)] == true }
            pendingOf(items.map { it.file }, false, "Мусор")
        } else {
            val files = groupsFor(tab).flatMap { g -> g.files.filter { it.path in g.selected } }
            pendingOf(files, true, if (tab == ResultTab.DUPLICATES) "Дубликаты" else "Похожие файлы")
        }
    }

    fun pendingForGroup(groupId: Long): PendingDeletion {
        val g = groupById(groupId) ?: return PendingDeletion(emptyList(), 0, 0, true, "Группа")
        return pendingOf(g.files.filter { it.path in g.selected }, true, g.type.title)
    }

    /** Безопасная очистка в одно касание: только категории, которые система или приложения создадут заново. */
    fun oneTapItems(): List<JunkItem> =
        junk.filter { it.category.safe || (it.category == JunkCategory.APK && it.defaultSelected && it.note.startsWith("Уже установлено")) }
            .distinctBy { it.file.path }

    fun pendingOneTap(): PendingDeletion = pendingOf(oneTapItems().map { it.file }, false, "Очистка в одно касание")

    fun pendingForList(files: List<FileInfo>, source: String): PendingDeletion =
        pendingOf(files.filter { listSelection[it.path] == true }, true, source)

    /**
     * Удаление выбранного. Вызывается только после подтверждения пользователя.
     * Обычные файлы — в корзину; файлы из системного доступа (SAF) — удаляются сразу (у них нет корзины).
     * Основные файлы групп защищены всегда.
     */
    fun delete(pending: PendingDeletion) {
        if (deleting || pending.paths.isEmpty()) return
        deleting = true
        val protectedPaths: Set<String> = keeperPaths
        val safMap = pending.paths.mapNotNull { p -> safUriOf(p)?.let { p to it } }.toMap()
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            try {
                val regular = pending.paths.filter { it !in safMap }
                val report = withContext(Dispatchers.IO) { trash.moveToTrash(regular, protectedPaths) }
                var safDeleted = 0
                var safBytes = 0L
                val safGone = HashSet<String>()
                withContext(Dispatchers.IO) {
                    for ((path, uri) in safMap) {
                        if (path in protectedPaths) continue
                        val size = allFiles.firstOrNull { it.path == path }?.size
                            ?: junk.firstOrNull { it.file.path == path }?.file?.size ?: 0L
                        if (StorageAccess.deleteDocument(ctx, uri)) {
                            safDeleted++
                            safBytes += size
                            safGone.add(path)
                        }
                    }
                }
                val gone = withContext(Dispatchers.IO) { regular.filter { !File(it).exists() }.toSet() } + safGone
                removeFromResults(gone)
                val totalFiles = report.moved + safDeleted
                val totalBytes = report.bytes + safBytes
                val failed = report.failed + (safMap.size - safDeleted)
                if (totalFiles > 0) {
                    withContext(Dispatchers.IO) { trash.addHistory(totalFiles, totalBytes, pending.source) }
                    refreshHistory()
                }
                refreshTrash()
                refreshStorage()
                listSelection.clear()
                if (totalFiles > 0) {
                    navigate(Screen.Success(totalBytes, totalFiles, failed))
                } else {
                    message = "Ничего не удалено" + if (failed > 0) ". Ошибок: $failed" else ""
                }
            } catch (e: Exception) {
                message = "Ошибка удаления: ${e.message}"
            } finally {
                deleting = false
            }
        }
    }

    private fun removeFromResults(gone: Set<String>) {
        if (gone.isEmpty()) return
        val keptJunk = junk.filter { it.file.path !in gone }
        junk.clear()
        junk.addAll(keptJunk)
        junkSelected.keys.toList().forEach { k -> if (k.substringAfter('|') in gone) junkSelected.remove(k) }
        allFiles = allFiles.filter { it.path !in gone }
        categoryStats = StorageAnalyzer.breakdown(allFiles)
        folderIndexCache = null
        folderIndex = null
        val keptIssues = photoIssues.filter { it.file.path !in gone }
        photoIssues.clear()
        photoIssues.addAll(keptIssues)
        val updated = groups.mapNotNull { g ->
            val remaining = g.files.filter { it.path !in gone }
            when {
                remaining.size == g.files.size -> g
                remaining.size < 2 -> null
                else -> {
                    val keeperPath = g.keeper.path
                    val idx = remaining.indexOfFirst { it.path == keeperPath }
                    if (idx >= 0) {
                        g.copy(files = remaining, keeperIndex = idx, scores = emptyList(), selected = g.selected.filter { p -> remaining.any { it.path == p } }.toSet())
                    } else {
                        val v = KeeperScorer.evaluate(remaining, g.type)
                        g.copy(
                            files = remaining, keeperIndex = v.keeperIndex, keeperReasons = v.reasons, scores = v.scores,
                            aiReason = "", aiChosen = false,
                            selected = remaining.map { it.path }.filter { it != remaining[v.keeperIndex].path }.toSet()
                        )
                    }
                }
            }
        }
        groups.clear()
        groups.addAll(updated)
        // Убираем экраны групп, которых больше нет.
        backStack.removeAll { it is Screen.GroupDetail && groupById(it.groupId) == null }
        if (backStack.isEmpty()) backStack.add(Screen.Results)
        summary?.let { s ->
            val dup = groups.filter { it.type == GroupType.EXACT }
            val sim = groups.filter { it.type != GroupType.EXACT }
            val ns = s.copy(
                junkCount = junk.size,
                junkBytes = junk.sumOf { it.file.size },
                duplicateGroups = dup.size,
                duplicateBytes = dup.sumOf { it.reclaimableBytes },
                similarGroups = sim.size,
                similarBytes = sim.sumOf { it.reclaimableBytes }
            )
            summary = ns
            settings.saveSummary(ns)
        }
    }

    // ---------- Анализатор памяти и категории ----------
    fun ensureFolderIndex() {
        if (folderIndexCache != null) {
            folderIndex = folderIndexCache
            return
        }
        val files = allFiles
        val roots = scannedVolumes.map { it.path }
        viewModelScope.launch {
            val idx = withContext(Dispatchers.Default) { StorageAnalyzer.buildIndex(files, roots) }
            folderIndexCache = idx
            folderIndex = idx
        }
    }

    fun largestFiles(): List<FileInfo> = StorageAnalyzer.largestFiles(allFiles, 150)

    fun filesOf(category: FileCategory): List<FileInfo> {
        val q = categoryFilter.trim().lowercase()
        val base = allFiles.filter { FileCategory.of(it.extension) == category && (q.isEmpty() || it.name.lowercase().contains(q)) }
        return when (categorySort) {
            CategorySort.SIZE -> base.sortedByDescending { it.size }
            CategorySort.DATE_NEW -> base.sortedByDescending { it.lastModified }
            CategorySort.DATE_OLD -> base.sortedBy { it.lastModified }
            CategorySort.NAME -> base.sortedBy { it.name.lowercase() }
        }
    }

    fun screenshots(): List<FileInfo> = StorageAnalyzer.screenshots(allFiles)

    fun messengerMedia(): List<FileInfo> =
        StorageAnalyzer.oldMessengerMedia(allFiles, settings.messengerDays.toLong() * 86_400_000L)

    fun startList() {
        listSelection.clear()
        categoryFilter = ""
    }

    fun toggleListItem(path: String) {
        listSelection[path] = !(listSelection[path] ?: false)
    }

    fun setListSelection(files: List<FileInfo>, selected: Boolean) {
        files.forEach { listSelection[it.path] = selected }
    }

    // ---------- Качество фото ----------
    fun analyzePhotos() {
        if (photoScanning) return
        val images = allFiles.filter {
            !it.isSaf && FileCategory.of(it.extension) == FileCategory.IMAGES &&
                it.extension != "svg" && it.extension != "gif" && it.size in 10_000L..60_000_000L
        }.sortedByDescending { it.lastModified }.take(4000)
        if (images.isEmpty()) {
            message = "Нет фото для анализа — сначала выполните сканирование"
            return
        }
        photoScanning = true
        photoProgress = 0f
        photoIssues.clear()
        val blur = settings.blurThreshold.toDouble()
        photoJob = viewModelScope.launch {
            try {
                withContext(Dispatchers.Default) {
                    for ((i, f) in images.withIndex()) {
                        ensureActive()
                        val q = PhotoQuality.analyze(File(f.path)) ?: continue
                        val kinds = HashSet<PhotoIssueKind>()
                        if (q.sharpness < blur) kinds.add(PhotoIssueKind.BLURRY)
                        if (q.brightness < DARK_THRESHOLD) kinds.add(PhotoIssueKind.DARK)
                        if (kinds.isNotEmpty()) {
                            val issue = PhotoIssue(f, kinds, q.sharpness, q.brightness)
                            withContext(Dispatchers.Main) { photoIssues.add(issue) }
                        }
                        if (i % 10 == 0) withContext(Dispatchers.Main) { photoProgress = i.toFloat() / images.size }
                    }
                }
                photoChecked = true
            } catch (e: CancellationException) {
                throw e
            } finally {
                photoScanning = false
                photoProgress = 1f
            }
        }
    }

    fun cancelPhotos() {
        photoJob?.cancel()
        photoScanning = false
    }

    // ---------- Кэш приложений (Android 8+) ----------
    fun loadAppCaches(force: Boolean = false) {
        val ctx = getApplication<Application>()
        usageAccess = AppCacheStats.supported() && AppCacheStats.hasUsageAccess(ctx)
        if (!usageAccess || appCacheLoading) return
        if (!force && appCaches.isNotEmpty()) return
        appCacheLoading = true
        viewModelScope.launch {
            try {
                val list = withContext(Dispatchers.IO) {
                    val job = coroutineContext
                    AppCacheStats.load(ctx) { !job.isActive }
                }
                appCaches.clear()
                appCaches.addAll(list)
                appCacheTotal = list.filter { !it.isSystem }.sumOf { it.cacheBytes }
                applyDefaultAutoSelection(onlyNew = true)
            } catch (e: Exception) {
                message = "Не удалось получить размеры кэша: ${e.message}"
            } finally {
                appCacheLoading = false
            }
        }
    }

    // ---------- Автоочистка кэша ----------
    private fun applyDefaultAutoSelection(onlyNew: Boolean) {
        val own = getApplication<Application>().packageName
        val min = autoCacheMinMb.toLong() * 1024L * 1024L
        for (a in appCaches) {
            if (onlyNew && autoSelection.containsKey(a.packageName)) continue
            autoSelection[a.packageName] = a.packageName != own && !a.isSystem && a.cacheBytes > min
        }
    }

    fun updateAutoCacheMin(mb: Int) {
        settings.autoCacheMinMb = mb
        autoCacheMinMb = settings.autoCacheMinMb
        applyDefaultAutoSelection(onlyNew = false)
    }

    fun toggleAutoApp(pkg: String) {
        if (pkg == getApplication<Application>().packageName) return
        autoSelection[pkg] = !(autoSelection[pkg] ?: false)
    }

    fun setAllAuto(selected: Boolean, visible: List<AppCacheInfo>) {
        val own = getApplication<Application>().packageName
        visible.forEach { if (it.packageName != own) autoSelection[it.packageName] = selected }
    }

    fun autoSelectedApps(): List<AppCacheInfo> {
        val own = getApplication<Application>().packageName
        return appCaches.filter { autoSelection[it.packageName] == true && it.packageName != own }
    }

    fun startAutoClean() {
        val ctx = getApplication<Application>()
        accessibilityEnabled = AutoCleaner.isServiceEnabled(ctx)
        if (!accessibilityEnabled) {
            message = "Сначала включите службу «Умный Cleaner — автоочистка кэша» в спец. возможностях"
            return
        }
        if (com.smartcleaner.app.autoclean.CacheCleanerService.instance == null) {
            message = "Служба включена, но ещё не запущена системой. Выключите и снова включите её в спец. возможностях"
            return
        }
        val apps = autoSelectedApps()
        if (apps.isEmpty()) {
            message = "Выберите хотя бы одно приложение"
            return
        }
        AutoCleaner.start(ctx, apps) { final ->
            viewModelScope.launch {
                if (final.clearedCount > 0) {
                    withContext(Dispatchers.IO) { trash.addHistory(final.clearedCount, final.freedBytes, "Автоочистка кэша") }
                    refreshHistory()
                }
                loadAppCaches(force = true)
                refreshStorage()
            }
        }
    }

    fun cancelAutoClean() = AutoCleaner.cancel()

    fun dismissAutoReport() = AutoCleaner.reset()

    // ---------- ИИ ----------
    private fun client(): GeminiClient = GeminiClient(settings.apiKey, settings.model, settings.aiSendImages)

    private fun aiError(e: Exception, fallback: String): String = "ИИ недоступен: ${e.message ?: "ошибка"}. $fallback"

    fun aiChooseKeeper(groupId: Long) {
        if (!checkAi()) return
        val g = groupById(groupId) ?: return
        aiBusy = true
        aiStatus = "ИИ анализирует группу…"
        viewModelScope.launch {
            try {
                val d = withContext(Dispatchers.IO) { client().chooseKeeper(g) }
                setKeeper(groupId, d.keepIndex, "ИИ: ${d.reason}", byAi = true)
                message = "ИИ выбрал: ${g.files[d.keepIndex].name}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = aiError(e, "Оставлен локальный выбор")
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    fun aiExplainGroup(groupId: Long) {
        if (!checkAi()) return
        val g = groupById(groupId) ?: return
        aiBusy = true
        aiStatus = "ИИ готовит объяснение…"
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) { client().explainGroup(g) }
                updateGroup(groupId) { it.copy(aiExplanation = text) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                updateGroup(groupId) { it.copy(aiExplanation = localExplanation(it)) }
                message = aiError(e, "Показано локальное объяснение")
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    /** Объяснение без ИИ — на основе правил сканера. */
    fun localExplanation(g: FileGroup): String = buildString {
        append(
            when (g.type) {
                GroupType.EXACT -> "Файлы совпадают байт в байт (одинаковый SHA-256), поэтому копии не содержат ничего нового."
                GroupType.SIMILAR_IMAGE -> "Изображения почти одинаковы по перцептивному хэшу — это серия снимков или пересохранённые копии."
                GroupType.SIMILAR_TEXT -> "Тексты совпадают по большей части фраз — вероятно, это черновики одного документа."
                GroupType.VERSIONS -> "Имена файлов отличаются только пометками версии или копии."
            }
        )
        append(" Предлагается оставить «").append(g.keeper.name).append("»: ")
        append(g.keeperReasons.joinToString(", ").ifBlank { "лучшая оценка" }).append(".")
        append(" Всё удалённое сначала попадает в корзину, откуда его можно восстановить.")
    }

    fun aiChooseAllSimilar() {
        if (!checkAi()) return
        val targets = groups.filter { it.type != GroupType.EXACT && !it.aiChosen }.take(20)
        if (targets.isEmpty()) {
            message = "Нет групп для проверки ИИ"
            return
        }
        aiBusy = true
        viewModelScope.launch {
            var ok = 0
            var lastError: String? = null
            for ((i, g) in targets.withIndex()) {
                aiStatus = "ИИ проверяет группы: ${i + 1} из ${targets.size}"
                try {
                    val d = withContext(Dispatchers.IO) { client().chooseKeeper(g) }
                    setKeeper(g.id, d.keepIndex, "ИИ: ${d.reason}", byAi = true)
                    ok++
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    lastError = e.message
                    if (e.message?.contains("квот") == true || e.message?.contains("Ключ") == true) break
                }
            }
            aiBusy = false
            aiStatus = ""
            message = if (lastError == null) "ИИ проверил групп: $ok"
            else "ИИ проверил групп: $ok. Ошибка: $lastError — для остальных оставлен локальный выбор"
        }
    }

    fun aiClassifyJunk() {
        if (!checkAi()) return
        val uncertain = junk.filter {
            it.aiJunk == null && (!it.defaultSelected || it.category == JunkCategory.TEMP || it.category == JunkCategory.APK)
        }.take(40)
        if (uncertain.isEmpty()) {
            message = "Нет сомнительных файлов для проверки"
            return
        }
        aiBusy = true
        aiStatus = "ИИ классифицирует ${uncertain.size} файлов…"
        viewModelScope.launch {
            try {
                val verdicts = withContext(Dispatchers.IO) { client().classify(uncertain) }
                for (v in verdicts) {
                    val item = uncertain[v.index]
                    val idx = junk.indexOfFirst { keyOf(it) == keyOf(item) }
                    if (idx >= 0) {
                        junk[idx] = junk[idx].copy(aiJunk = v.junk, aiReason = v.reason)
                        junkSelected[keyOf(item)] = v.junk
                    }
                }
                message = "ИИ оценил файлов: ${verdicts.size}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = aiError(e, "Используются локальные правила")
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    /** Пакетная проверка списка предложений (скриншоты, мессенджеры, фото). Только подсказки — ничего не удаляет. */
    fun aiReviewList(files: List<FileInfo>, category: String) {
        if (!checkAi()) return
        val targets = files.filter { it.path !in aiVerdicts }.take(40)
        if (targets.isEmpty()) {
            message = "Все файлы уже проверены ИИ"
            return
        }
        aiBusy = true
        aiStatus = "ИИ проверяет ${targets.size} файлов…"
        viewModelScope.launch {
            try {
                val verdicts = withContext(Dispatchers.IO) {
                    client().review(targets.map { GeminiClient.AiCandidate(it, category, "") })
                }
                for (v in verdicts) {
                    val f = targets[v.index]
                    aiVerdicts[f.path] = v.junk to v.reason
                    listSelection[f.path] = v.junk
                }
                message = "ИИ оценил файлов: ${verdicts.size}. Отметки обновлены — проверьте перед удалением"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = aiError(e, "Отметки не изменены")
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    fun aiSummarize() {
        if (!checkAi()) return
        val s = summary ?: return
        val stats = buildString {
            append("Проверено файлов: ${s.filesScanned}, папок: ${s.foldersScanned}, недоступных папок: ${s.inaccessibleCount}\n")
            append("Свободно: ${formatSize(storageFree)} из ${formatSize(storageTotal)}\n")
            append("Мусор: ${s.junkCount} шт., ${formatSize(s.junkBytes)}\n")
            junk.groupBy { it.category }.forEach { (c, list) ->
                append(" - ${c.title}: ${list.size} шт., ${formatSize(list.sumOf { it.file.size })}\n")
            }
            append("Дубликаты: ${s.duplicateGroups} групп, можно освободить ${formatSize(s.duplicateBytes)}\n")
            append("Похожие файлы: ${s.similarGroups} групп, ${formatSize(s.similarBytes)}\n")
            append("По типам:\n")
            categoryStats.filter { it.count > 0 }.forEach { append(" - ${it.category.title}: ${it.count} шт., ${formatSize(it.bytes)}\n") }
            val messengers = messengerMedia()
            if (messengers.isNotEmpty()) append("Старые медиа мессенджеров: ${messengers.size} шт., ${formatSize(messengers.sumOf { it.size })}\n")
            val shots = screenshots()
            if (shots.isNotEmpty()) append("Скриншоты: ${shots.size} шт., ${formatSize(shots.sumOf { it.size })}\n")
        }
        aiBusy = true
        aiStatus = "ИИ готовит итог…"
        aiSummaryError = null
        viewModelScope.launch {
            try {
                aiSummary = withContext(Dispatchers.IO) { client().summarize(stats) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                aiSummaryError = e.message ?: "ошибка"
                aiSummary = localSummary()
            } finally {
                aiBusy = false
                aiStatus = ""
            }
        }
    }

    fun showLocalSummary() {
        aiSummaryError = null
        aiSummary = localSummary()
    }

    /** Итог без ИИ (запасной вариант). */
    fun localSummary(): GeminiClient.AiSummary {
        val s = summary ?: return GeminiClient.AiSummary("Сканирование ещё не выполнялось.", emptyList())
        val tips = ArrayList<String>()
        val safe = oneTapItems()
        if (safe.isNotEmpty()) tips.add("Очистка в одно касание освободит ${formatSize(safe.sumOf { it.file.size })} без риска.")
        if (s.duplicateBytes > 0) tips.add("Удалите точные копии — это ещё ${formatSize(s.duplicateBytes)}.")
        val m = messengerMedia()
        if (m.isNotEmpty()) tips.add("Старые медиа мессенджеров занимают ${formatSize(m.sumOf { it.size })} — просмотрите их.")
        categoryStats.maxByOrNull { it.bytes }?.takeIf { it.bytes > 0 }?.let {
            tips.add("Больше всего места занимают «${it.category.title}» — ${formatSize(it.bytes)}. Загляните в анализатор.")
        }
        if (s.inaccessibleCount > 0) tips.add("Часть папок недоступна системе — проверьте кэш приложений в «Инструментах».")
        return GeminiClient.AiSummary(
            "Найдено ${formatSize(s.junkBytes + s.duplicateBytes + s.similarBytes)} потенциально лишних данных в ${s.filesScanned} файлах.",
            tips
        )
    }

    private fun checkAi(): Boolean {
        if (aiBusy) return false
        if (!aiEnabled) {
            message = "ИИ выключен. Включите его в Настройках"
            return false
        }
        if (!aiConsent) {
            message = "Подтвердите согласие на отправку данных в Google в Настройках"
            return false
        }
        if (apiKey.isBlank()) {
            message = "Укажите ключ Gemini API в Настройках"
            return false
        }
        return true
    }

    // ---------- Корзина ----------
    fun refreshTrash() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { trash.entries() }
            trashEntries.clear()
            trashEntries.addAll(list)
            trashSize = list.sumOf { it.size }
        }
    }

    fun restore(entry: TrashEntry) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { trash.restore(entry) }
            message = r.fold({ "Восстановлено: $it" }, { "Ошибка: ${it.message}" })
            refreshTrash()
            refreshStorage()
        }
    }

    fun deleteForever(entry: TrashEntry) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) { trash.deletePermanently(entry) }
            message = if (ok) "Удалено навсегда: ${entry.name}" else "Не удалось удалить ${entry.name}"
            refreshTrash()
            refreshStorage()
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            val n = withContext(Dispatchers.IO) { trash.emptyAll() }
            message = "Корзина очищена: $n"
            refreshTrash()
            refreshStorage()
        }
    }

    // ---------- История ----------
    fun refreshHistory() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { trash.history() }
            history.clear()
            history.addAll(list)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { trash.clearHistory() }
            refreshHistory()
            message = "История очищена"
        }
    }

    // ---------- Настройки ----------
    fun updateTheme(mode: Int) {
        settings.themeMode = mode
        themeMode = settings.themeMode
    }

    fun updateDynamicColor(enabled: Boolean) {
        settings.dynamicColor = enabled
        dynamicColor = enabled
    }

    fun updateReminder(days: Int) {
        settings.reminderDays = days
        reminderDays = settings.reminderDays
        val ctx = getApplication<Application>()
        ReminderScheduler.ensureChannel(ctx)
        ReminderScheduler.schedule(ctx, reminderDays)
        message = if (reminderDays > 0) "Напоминание: раз в $reminderDays дн." else "Напоминания выключены"
    }

    fun saveSettings(showMessage: Boolean = true) {
        settings.apiKey = apiKey
        settings.model = model
        settings.aiEnabled = aiEnabled
        settings.aiSendImages = aiSendImages
        settings.aiConsent = aiConsent
        settings.imageThreshold = imageThreshold
        settings.textThresholdPercent = textThreshold
        settings.blurThreshold = blurThreshold
        largeFileMb.trim().toIntOrNull()?.let { settings.largeFileMb = it }
        oldFileDays.trim().toIntOrNull()?.let { settings.oldFileDays = it }
        trashDays.trim().toIntOrNull()?.let { settings.trashDays = it }
        messengerDays.trim().toIntOrNull()?.let { settings.messengerDays = it }
        settings.excludedFolders = excludedFolders
        model = settings.model
        apiKey = settings.apiKey
        largeFileMb = settings.largeFileMb.toString()
        oldFileDays = settings.oldFileDays.toString()
        trashDays = settings.trashDays.toString()
        messengerDays = settings.messengerDays.toString()
        if (showMessage) message = "Настройки сохранены"
    }

    fun clearApiKey() {
        apiKey = ""
        settings.apiKey = ""
        message = "Ключ удалён"
    }

    companion object {
        const val DARK_THRESHOLD = 35.0
    }
}
