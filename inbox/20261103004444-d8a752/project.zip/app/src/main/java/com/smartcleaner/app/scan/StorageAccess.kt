package com.smartcleaner.app.scan

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.storage.StorageManager
import android.provider.DocumentsContract
import com.smartcleaner.app.data.VolumeInfo
import java.io.File

/**
 * Доступ к хранилищам: все тома (внутренняя память, SD-карты, USB OTG) и системный доступ (SAF)
 * к Android/data и Android/obb на Android 11–12.
 */
object StorageAccess {

    const val EXTERNAL_AUTHORITY = "com.android.externalstorage.documents"

    /** Все смонтированные тома общего хранилища. */
    fun volumes(context: Context): List<VolumeInfo> {
        val result = LinkedHashMap<String, VolumeInfo>()
        val sm = context.getSystemService(Context.STORAGE_SERVICE) as StorageManager

        fun add(dir: File?, title: String, removable: Boolean, primary: Boolean) {
            if (dir == null || !dir.exists()) return
            val canonical = try {
                dir.canonicalPath
            } catch (e: Exception) {
                dir.absolutePath
            }
            if (!result.containsKey(canonical)) {
                result[canonical] = VolumeInfo(dir.absolutePath.trimEnd('/'), title, removable, primary)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            for (v in sm.storageVolumes) {
                if (v.state != Environment.MEDIA_MOUNTED && v.state != Environment.MEDIA_MOUNTED_READ_ONLY) continue
                add(v.directory, v.getDescription(context) ?: "Хранилище", v.isRemovable, v.isPrimary)
            }
        }
        // Запасной путь (Android 7–10 и на случай пустого списка): корни из getExternalFilesDirs.
        add(Environment.getExternalStorageDirectory(), "Внутренняя память", removable = false, primary = true)
        val dirs = context.getExternalFilesDirs(null)
        for (d in dirs) {
            if (d == null) continue
            val path = d.absolutePath
            val idx = path.indexOf("/Android/data/")
            if (idx <= 0) continue
            val root = File(path.substring(0, idx))
            val isPrimary = root.absolutePath == Environment.getExternalStorageDirectory().absolutePath
            val volume = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) sm.getStorageVolume(root) else null
            add(
                root,
                volume?.getDescription(context) ?: if (isPrimary) "Внутренняя память" else "Карта памяти / USB",
                removable = volume?.isRemovable ?: !isPrimary,
                primary = isPrimary
            )
        }
        return result.values.toList()
    }

    /** Нужен ли SAF для Android/data и obb: Android 11 и 12 (API 30–32). */
    fun safSupported(): Boolean = Build.VERSION.SDK_INT in Build.VERSION_CODES.R..Build.VERSION_CODES.S_V2

    /** Android 13+ полностью закрывает Android/data и obb для сторонних приложений. */
    fun androidDataBlocked(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    fun initialUri(sub: String): Uri =
        DocumentsContract.buildDocumentUri(EXTERNAL_AUTHORITY, "primary:Android/$sub")

    fun openTreeIntent(sub: String): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra(DocumentsContract.EXTRA_INITIAL_URI, initialUri(sub))
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
            )
        }

    /** Принимает выданный пользователем URI. Возвращает true, если это действительно Android/data или obb. */
    fun persistGrant(context: Context, uri: Uri): Boolean {
        val docId = try {
            DocumentsContract.getTreeDocumentId(uri)
        } catch (e: Exception) {
            return false
        }
        if (!docId.startsWith("primary:Android/data") && !docId.startsWith("primary:Android/obb")) return false
        return try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            true
        } catch (e: SecurityException) {
            false
        }
    }

    /** Только действующие (не отозванные) разрешения. */
    fun validGrants(context: Context, stored: Set<String>): List<Uri> {
        val persisted = context.contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }
            .map { it.uri.toString() }
            .toSet()
        return stored.filter { it in persisted }.map { Uri.parse(it) }
    }

    fun treeLabel(uri: Uri): String = try {
        DocumentsContract.getTreeDocumentId(uri).removePrefix("primary:")
    } catch (e: Exception) {
        uri.toString()
    }

    data class DocEntry(
        val uri: String,
        val path: String,
        val name: String,
        val isDirectory: Boolean,
        val size: Long,
        val lastModified: Long,
        val childCount: Int
    )

    /**
     * Обход дерева документов SAF. [onEntry] вызывается для каждого файла и папки.
     * Отображаемый путь строится как у обычного файла: /storage/emulated/0/Android/data/…
     */
    fun walkTree(
        context: Context,
        treeUri: Uri,
        primaryRoot: String,
        isCancelled: () -> Boolean,
        onEntry: (DocEntry) -> Unit
    ) {
        val resolver = context.contentResolver
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val stack = ArrayDeque<String>()
        stack.addLast(rootId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        val visited = HashSet<String>()
        while (stack.isNotEmpty()) {
            if (isCancelled()) return
            val parentId = stack.removeLast()
            if (!visited.add(parentId)) continue
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId)
            val children = ArrayList<DocEntry>()
            try {
                resolver.query(childrenUri, projection, null, null, null)?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: id.substringAfterLast('/')
                        val mime = c.getString(2) ?: ""
                        val size = if (c.isNull(3)) 0L else c.getLong(3)
                        val modified = if (c.isNull(4)) 0L else c.getLong(4)
                        val isDir = mime == DocumentsContract.Document.MIME_TYPE_DIR
                        children.add(
                            DocEntry(
                                uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id).toString(),
                                path = docIdToPath(id, primaryRoot),
                                name = name,
                                isDirectory = isDir,
                                size = if (isDir) 0L else size,
                                lastModified = modified,
                                childCount = -1
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                continue
            }
            for (child in children) {
                if (child.isDirectory) {
                    val childId = DocumentsContract.getDocumentId(Uri.parse(child.uri))
                    stack.addLast(childId)
                    onEntry(child)
                } else {
                    onEntry(child)
                }
            }
        }
    }

    fun docIdToPath(docId: String, primaryRoot: String): String {
        val volume = docId.substringBefore(':')
        val rel = docId.substringAfter(':', "")
        val root = if (volume == "primary") primaryRoot else "/storage/$volume"
        return if (rel.isEmpty()) root else "$root/$rel"
    }

    fun deleteDocument(context: Context, uri: String): Boolean = try {
        DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uri))
    } catch (e: Exception) {
        false
    }
}
