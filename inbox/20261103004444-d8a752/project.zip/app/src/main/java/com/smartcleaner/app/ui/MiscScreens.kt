package com.smartcleaner.app.ui

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartcleaner.app.data.JunkCategory

/** Очистка в одно касание: предпросмотр безопасных категорий и одно подтверждение. */
@Composable
fun OneTapScreen(vm: MainViewModel) {
    val items = vm.oneTapItems()
    val pending = vm.pendingOneTap()
    var confirm by remember { mutableStateOf(false) }
    val byCat = items.groupBy { it.category }
    Column(Modifier.fillMaxSize()) {
        GradientHeader("В одно касание", subtitle = "Только то, что система и приложения создадут заново", onBack = { vm.back() }) {
            Text(formatSize(pending.bytes), color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
            Text("${pending.count} элементов будет перемещено в корзину", color = Color.White.copy(alpha = 0.85f))
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(12.dp)) {
            if (items.isEmpty()) item { EmptyState(Icons.Filled.CheckCircle, "Всё чисто", "Безопасного мусора не найдено") }
            items(byCat.entries.toList(), key = { it.key.name }) { (cat, list) ->
                SectionCard(modifier = Modifier.padding(vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Check, Teal)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(cat.title, fontWeight = FontWeight.SemiBold)
                            Text(cat.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatSize(list.sumOf { it.file.size }), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text("${list.size} шт.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    for (it in list.take(3)) {
                        Text("• " + it.file.name, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 56.dp))
                    }
                    if (list.size > 3) Text("и ещё ${list.size - 3}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 56.dp))
                }
            }
            item {
                Text(
                    "Дубликаты, похожие файлы, крупные и старые файлы здесь не удаляются — их нужно проверить вручную. " +
                        "${if (byCat.containsKey(JunkCategory.APK)) "APK — только уже установленные. " else ""}Всё можно восстановить из корзины.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(8.dp)
                )
            }
        }
        DeleteBar(pending.count, pending.bytes, enabled = pending.count > 0 && !vm.deleting, label = "Очистить") { confirm = true }
    }
    if (confirm) {
        ConfirmDialog("Очистить безопасный мусор?", deletionText(pending), "Очистить", onConfirm = { confirm = false; vm.delete(pending) }, onDismiss = { confirm = false })
    }
}

@Composable
fun HistoryScreen(vm: MainViewModel) {
    LaunchedEffect(Unit) { vm.refreshHistory() }
    var confirm by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        GradientHeader("История очисток", subtitle = "Всего освобождено", onBack = { vm.back() }, actions = {
            if (vm.history.isNotEmpty()) TextButton(onClick = { confirm = true }) { Text("Очистить", color = Color.White) }
        }) {
            Text(formatSize(vm.history.sumOf { it.bytes }), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("${vm.history.size} очисток · ${vm.history.sumOf { it.files }} файлов", color = Color.White.copy(alpha = 0.85f))
        }
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            if (vm.history.isEmpty()) item { EmptyState(Icons.Filled.DateRange, "Пока пусто", "Здесь появятся ваши очистки") }
            items(vm.history, key = { it.id }) { h ->
                SectionCard(modifier = Modifier.padding(vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(if (h.source.contains("кэш", true)) Icons.Filled.Build else Icons.Filled.Star, Violet)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.source, fontWeight = FontWeight.SemiBold)
                            Text(formatDate(h.time), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(formatSize(h.bytes), fontWeight = FontWeight.Bold, color = Teal)
                            Text(if (h.source.contains("кэш", true)) "${h.files} прил." else "${h.files} файлов", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
    if (confirm) ConfirmDialog("Очистить историю?", "Записи об очистках будут удалены. Файлы это не затронет.", "Очистить", { confirm = false; vm.clearHistory() }, { confirm = false })
}

/** Экран успеха с анимацией. */
@Composable
fun SuccessScreen(vm: MainViewModel, s: Screen.Success) {
    val scale = remember { Animatable(0.3f) }
    LaunchedEffect(Unit) { scale.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
    var target by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { target = s.bytes.toFloat() }
    val counted by animateFloatAsState(target, tween(1200), label = "count")
    Box(Modifier.fillMaxSize().background(LocalGradients.current.success)) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(140.dp).scale(scale.value).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(90.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text("Готово!", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
            Text("Освобождено", color = Color.White.copy(alpha = 0.85f))
            Text(formatSize(counted.toLong()), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
            Text("Файлов: ${s.files}", color = Color.White)
            if (s.failed > 0) Text("Не удалось: ${s.failed}", color = Color.White)
            Spacer(Modifier.height(12.dp))
            Text(
                "Файлы в корзине ещё ${vm.trashDays} дн. — их можно восстановить.",
                color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            OutlinedButton(onClick = { vm.back() }) { Text("Продолжить", color = Color.White) }
            TextButton(onClick = { vm.selectTab(Screen.Trash) }) { Text("Открыть корзину", color = Color.White) }
        }
    }
}

/** Что не удалось просканировать и почему — с пояснением по версиям Android. */
@Composable
fun InaccessibleScreen(vm: MainViewModel) {
    val sdk = Build.VERSION.SDK_INT
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader("Недоступные папки", subtitle = "Android ${Build.VERSION.RELEASE} (API $sdk)", onBack = { vm.back() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionCard {
                Text("Почему так", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                val text = when {
                    sdk >= 33 -> "На Android 13 и новее папки Android/data и Android/obb полностью закрыты системой даже для приложений с доступом ко всем файлам. " +
                        "Их содержимое — это кэш и данные других приложений. Очистить кэш можно на экране «Кэш приложений» (вручную или автоматически)."
                    sdk >= 30 -> "На Android 11–12L папки Android/data и Android/obb закрыты для обычного доступа, но их можно открыть один раз через системный выбор папки (кнопка на главной). " +
                        "Файлы оттуда удаляются сразу, без корзины."
                    sdk == 29 -> "На Android 10 доступно всё общее хранилище (режим совместимости)."
                    else -> "На Android 9 и ниже доступно всё общее хранилище. На SD-карте удаление на 7–10 иногда запрещено системой."
                }
                Text(text, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Внутренние данные приложений (/data) и системные разделы недоступны всегда (нужен root).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp)
                )
                if (sdk >= 26) {
                    OutlinedButton(onClick = { vm.navigate(Screen.AppCaches) }, modifier = Modifier.padding(top = 8.dp)) { Text("Кэш приложений") }
                }
            }
            if (vm.inaccessible.isEmpty()) {
                EmptyState(Icons.Filled.CheckCircle, "Всё просканировано", "Недоступных папок не встретилось")
            }
            for (f in vm.inaccessible) {
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Lock, Coral)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.path, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(f.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            Spacer(Modifier.fillMaxWidth().height(12.dp))
        }
    }
}
