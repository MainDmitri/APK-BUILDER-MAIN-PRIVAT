package com.smartcleaner.app.autoclean

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay

/**
 * Служба спец. возможностей для автоочистки кэша. Работает ТОЛЬКО пока пользователь сам запустил
 * автоочистку, только в окнах системных настроек, и нажимает только «Хранилище/Память» и «Очистить кэш».
 */
class CacheCleanerService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        AutoCleaner.cancel()
        super.onDestroy()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        AutoCleaner.cancel()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Состояние опрашивается активно из [cleanCurrentApp]; события не обрабатываются.
    }

    override fun onInterrupt() {}

    /** Кнопка «Громкость вниз» во время автоочистки — экстренная отмена. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (AutoCleaner.isRunning && event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN) {
            AutoCleaner.cancel()
            return true
        }
        return false
    }

    private fun settingsRoot(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: return null
        return if (pkg in ALLOWED_PACKAGES) root else null
    }

    private fun textOf(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()

    private fun collect(root: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (depth > 40) return
        out.add(root)
        for (i in 0 until root.childCount) {
            val c = root.getChild(i) ?: continue
            collect(c, out, depth + 1)
        }
    }

    private fun allNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> =
        ArrayList<AccessibilityNodeInfo>().also { collect(root, it) }

    /** Нажимает узел или ближайшего кликабельного предка, если его текст проходит проверку. */
    private fun safeClick(node: AccessibilityNodeInfo, check: (String) -> Boolean): Boolean {
        var n: AccessibilityNodeInfo? = node
        var hops = 0
        while (n != null && hops < 5) {
            if (n.isClickable) {
                // Ещё раз проверяем все тексты внутри нажимаемого элемента: ни одного запрещённого.
                val texts = allNodes(n).map { textOf(it) }.filter { it.isNotEmpty() }
                if (texts.any { ClickGuard.isForbidden(it) && !check(it) }) return false
                if (texts.none { check(it) }) return false
                if (!n.isEnabled) return false
                return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            n = n.parent
            hops++
        }
        return false
    }

    private fun scrollForward(root: AccessibilityNodeInfo): Boolean =
        allNodes(root).firstOrNull { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true

    private fun pageMentions(root: AccessibilityNodeInfo, label: String): Boolean =
        label.isBlank() || allNodes(root).any { textOf(it).equals(label, ignoreCase = true) }

    /**
     * Шаги для одного приложения (карточка приложения уже открыта).
     * Возвращает итог. Всё время проверяет отмену и тайм-аут.
     */
    suspend fun cleanCurrentApp(label: String, timeoutMs: Long, onStep: (String) -> Unit): AutoCleanOutcome {
        val deadline = System.currentTimeMillis() + timeoutMs
        var phase = 0 // 0 — карточка приложения, 1 — страница хранилища, 2 — ждём диалог/результат
        var scrolls = 0
        var clickedAt = 0L
        onStep("Открываю карточку приложения")
        while (System.currentTimeMillis() < deadline) {
            if (!AutoCleaner.isRunning) return AutoCleanOutcome.CANCELLED
            delay(STEP_DELAY)
            val root = settingsRoot() ?: continue
            val nodes = allNodes(root)
            val pkg = root.packageName?.toString() ?: ""

            // На любом этапе: если видна кнопка «Очистить кэш» — это наша цель.
            val clearBtn = nodes.firstOrNull { n ->
                val t = textOf(n)
                ClickGuard.isClearCache(t) || (n.viewIdResourceName in CLEAR_CACHE_IDS && ClickGuard.isClearCache(t))
            }
            if (phase < 2 && clearBtn != null) {
                if (!pageMentions(root, label) && phase == 0) continue
                val target = generateSequence(clearBtn) { it.parent }.take(5).firstOrNull { it.isClickable } ?: clearBtn
                if (!target.isEnabled) return AutoCleanOutcome.ALREADY_EMPTY
                onStep("Нажимаю «Очистить кэш»")
                if (safeClick(clearBtn) { ClickGuard.isClearCache(it) }) {
                    phase = 2
                    clickedAt = System.currentTimeMillis()
                    continue
                }
            }
            when (phase) {
                0 -> {
                    // Убеждаемся, что открыта карточка нужного приложения.
                    if (!pageMentions(root, label)) continue
                    val storage = nodes.firstOrNull { ClickGuard.isStorageEntry(textOf(it)) }
                    if (storage != null) {
                        onStep("Открываю «Хранилище и кэш»")
                        if (safeClick(storage) { ClickGuard.isStorageEntry(it) }) {
                            phase = 1
                            scrolls = 0
                            continue
                        }
                    }
                    // MIUI/HyperOS: кнопка «Очистить» внизу открывает меню выбора (сама ничего не удаляет).
                    if (pkg == MIUI_PACKAGE) {
                        val opener = nodes.firstOrNull { ClickGuard.isMiuiOpener(textOf(it)) }
                        if (opener != null && safeClick(opener) { ClickGuard.isMiuiOpener(it) }) {
                            phase = 1
                            continue
                        }
                    }
                    if (scrolls < MAX_SCROLLS && scrollForward(root)) scrolls++
                }
                1 -> {
                    if (scrolls < MAX_SCROLLS && scrollForward(root)) scrolls++
                }
                2 -> {
                    // Возможный диалог подтверждения — только если он про кэш.
                    val dialogText = nodes.map { textOf(it) }.filter { it.isNotEmpty() }.joinToString(" ")
                    val confirm = nodes.firstOrNull { n -> n.isClickable && ClickGuard.isSafeConfirm(textOf(n), dialogText) }
                    if (confirm != null && nodes.size < 40) {
                        onStep("Подтверждаю очистку кэша")
                        confirm.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                        delay(STEP_DELAY)
                        return AutoCleanOutcome.CLEARED
                    }
                    if (System.currentTimeMillis() - clickedAt > 900) return AutoCleanOutcome.CLEARED
                }
            }
        }
        return when (phase) {
            2 -> AutoCleanOutcome.CLEARED
            0 -> AutoCleanOutcome.NOT_FOUND
            else -> AutoCleanOutcome.TIMEOUT
        }
    }

    fun goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    companion object {
        @Volatile
        var instance: CacheCleanerService? = null
            private set

        const val MIUI_PACKAGE = "com.miui.securitycenter"
        val ALLOWED_PACKAGES = setOf("com.android.settings", MIUI_PACKAGE, "com.samsung.android.settings", "com.coloros.settings", "com.oplus.settings")
        val CLEAR_CACHE_IDS = setOf(
            "com.android.settings:id/button2", "com.android.settings:id/clear_cache_button",
            "com.android.settings:id/clear_cache", "com.miui.securitycenter:id/clear_cache"
        )
        private const val STEP_DELAY = 350L
        private const val MAX_SCROLLS = 6
    }
}
