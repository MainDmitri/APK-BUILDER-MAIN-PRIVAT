package com.smartcleaner.app.reminder

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.smartcleaner.app.R

/** Периодическое напоминание через AlarmManager (неточный повтор — бережёт батарею). */
object ReminderScheduler {

    const val ACTION_REMIND = "com.smartcleaner.app.action.REMIND"
    const val CHANNEL_ID = "cleanup_reminders"

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).setAction(ACTION_REMIND)
        return PendingIntent.getBroadcast(
            context, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, days: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)
        am.cancel(pi)
        if (days <= 0) return
        val interval = days * AlarmManager.INTERVAL_DAY
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + interval, interval, pi)
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(
                    NotificationChannel(
                        CHANNEL_ID, context.getString(R.string.reminder_channel), NotificationManager.IMPORTANCE_DEFAULT
                    )
                )
            }
        }
    }
}
