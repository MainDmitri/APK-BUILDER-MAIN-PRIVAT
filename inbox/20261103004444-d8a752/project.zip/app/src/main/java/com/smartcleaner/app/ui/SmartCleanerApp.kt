package com.smartcleaner.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

private data class TabItem(val screen: Screen, val title: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem(Screen.Home, "Главная", Icons.Filled.Home),
    TabItem(Screen.Results, "Результаты", Icons.Filled.CheckCircle),
    TabItem(Screen.Tools, "Инструменты", Icons.Filled.Build),
    TabItem(Screen.Trash, "Корзина", Icons.Filled.Delete),
    TabItem(Screen.Settings, "Настройки", Icons.Filled.Settings)
)

@Composable
fun SmartCleanerApp(vm: MainViewModel) {
    val snackbar = remember { SnackbarHostState() }
    val msg = vm.message
    LaunchedEffect(msg) {
        if (msg != null) {
            snackbar.showSnackbar(msg)
            vm.message = null
        }
    }

    if (vm.showOnboarding) {
        OnboardingScreen(onDone = { vm.finishOnboarding() })
        return
    }

    BackHandler(enabled = vm.backStack.size > 1 || vm.currentScreen != Screen.Home) {
        if (vm.currentScreen == Screen.Settings) vm.saveSettings(showMessage = false)
        vm.back()
    }

    val screen = vm.currentScreen
    val showBar = screen.isRoot
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Box(
            Modifier
                .weight(1f)
                .then(if (showBar) Modifier else Modifier.navigationBarsPadding())
        ) {
            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    val forward = !targetState.isRoot && initialState.isRoot ||
                        (!targetState.isRoot && !initialState.isRoot)
                    if (targetState.isRoot && initialState.isRoot) {
                        fadeIn() togetherWith fadeOut()
                    } else if (forward) {
                        (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 6 } + fadeOut())
                    } else {
                        (slideInHorizontally { -it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { it / 6 } + fadeOut())
                    }
                },
                label = "screen"
            ) { s ->
                ScreenContent(vm, s)
            }
            SnackbarHost(snackbar, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp))
        }
        AnimatedVisibility(
            visible = showBar,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
                for (t in tabs) {
                    NavigationBarItem(
                        selected = vm.currentTab == t.screen,
                        onClick = {
                            if (vm.currentScreen == Screen.Settings) vm.saveSettings(showMessage = false)
                            vm.selectTab(t.screen)
                        },
                        icon = {
                            val badge = when (t.screen) {
                                Screen.Results -> if (vm.hasResults) (vm.junk.size + vm.groups.size) else 0
                                Screen.Trash -> vm.trashEntries.size
                                else -> 0
                            }
                            if (badge > 0) {
                                BadgedBox(badge = { Badge { Text(if (badge > 99) "99+" else badge.toString()) } }) {
                                    Icon(t.icon, contentDescription = t.title)
                                }
                            } else {
                                Icon(t.icon, contentDescription = t.title)
                            }
                        },
                        label = { Text(t.title, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(vm: MainViewModel, s: Screen) {
    when (s) {
        Screen.Home -> HomeScreen(vm)
        Screen.Results -> ResultsScreen(vm)
        Screen.Tools -> ToolsScreen(vm)
        Screen.Trash -> TrashScreen(vm)
        Screen.Settings -> SettingsScreen(vm)
        is Screen.GroupDetail -> GroupDetailScreen(vm, s.groupId)
        is Screen.Analyzer -> AnalyzerScreen(vm, s.path)
        Screen.LargestFiles -> LargestFilesScreen(vm)
        is Screen.Category -> CategoryScreen(vm, s.category)
        Screen.Photos -> PhotosScreen(vm)
        Screen.Screenshots -> ScreenshotsScreen(vm)
        Screen.Messengers -> MessengersScreen(vm)
        Screen.OneTap -> OneTapScreen(vm)
        Screen.History -> HistoryScreen(vm)
        Screen.AppCaches -> AppCachesScreen(vm)
        Screen.Inaccessible -> InaccessibleScreen(vm)
        is Screen.Success -> SuccessScreen(vm, s)
    }
}
