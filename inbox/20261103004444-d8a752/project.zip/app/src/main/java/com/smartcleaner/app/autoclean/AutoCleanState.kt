package com.smartcleaner.app.autoclean

enum class AutoCleanOutcome(val title: String) {
    CLEARED("Очищено"),
    ALREADY_EMPTY("Кэш уже пуст"),
    NOT_FOUND("Кнопка не найдена"),
    TIMEOUT("Истекло время"),
    SKIPPED("Пропущено"),
    CANCELLED("Отменено")
}

data class AutoCleanResult(
    val packageName: String,
    val label: String,
    val outcome: AutoCleanOutcome,
    val before: Long,
    val after: Long
) {
    val freed: Long get() = (before - after).coerceAtLeast(0)
}

data class AutoCleanState(
    val running: Boolean = false,
    val finished: Boolean = false,
    val total: Int = 0,
    val index: Int = 0,
    val currentLabel: String = "",
    val step: String = "",
    val results: List<AutoCleanResult> = emptyList()
) {
    val clearedCount: Int get() = results.count { it.outcome == AutoCleanOutcome.CLEARED || it.outcome == AutoCleanOutcome.ALREADY_EMPTY }
    val freedBytes: Long get() = results.sumOf { it.freed }
}
