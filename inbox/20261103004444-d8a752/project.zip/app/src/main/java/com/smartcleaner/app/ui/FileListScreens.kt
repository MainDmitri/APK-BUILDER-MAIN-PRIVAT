package com.smartcleaner.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.data.FileInfo
import com.smartcleaner.app.scan.StorageAnalyzer
import com.smartcleaner.app.util.FileActions

/**
 * Общий экран выбора файлов: шапка, панель «выбрать все», список или сетка, ИИ-проверка и удаление с подтверждением.
 * Ничего не выбрано по умолчанию — пользователь отмечает сам (или по подсказке ИИ).
 */
@Composable
fun FileSelectionScreen(
    vm: MainViewModel,
    title: String,
    subtitle: String,
    files: List<FileInfo>,
    source: String,
    grid: Boolean = false,
    aiCategory: String? = null,
    badgeFor: (FileInfo) -> String? = { null },
    emptyTitle: String = "Ничего не найдено",
    emptyText: String = "Подходящих файлов нет — отлично!",
    top: @Composable ColumnScope.() -> Unit = {}
) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf<MainViewModel.PendingDeletion?>(null) }
    val pending = vm.pendingForList(files, source)
    Column(Modifier.fillMaxSize()) {
        GradientHeader(title, subtitle = subtitle, onBack = { vm.back() }, actions = {
            if (aiCategory != null && files.isNotEmpty()) {
                IconButton(onClick = { vm.aiReviewList(files, aiCategory) }, enabled = !vm.aiBusy) {
                    Icon(Icons.Filled.Face, contentDescription = "Проверить с ИИ", tint = androidx.compose.ui.graphics.Color.White)
                }
            }
        }) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatPill(files.size.toString(), "файлов", Modifier.weight(1f))
                StatPill(formatSize(files.sumOf { it.size }), "всего", Modifier.weight(1f))
                StatPill(formatSize(pending.bytes), "выбрано", Modifier.weight(1f))
            }
        }
        AiStatusBar(vm.aiStatus)
        Column(Modifier.padding(horizontal = 16.dp)) { top() }
        if (files.isEmpty()) {
            Box(Modifier.weight(1f)) { EmptyState(Icons.Filled.CheckCircle, emptyTitle, emptyText) }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { vm.setListSelection(files, true) }) { Text("Выбрать все") }
                TextButton(onClick = { vm.setListSelection(files, false) }) { Text("Снять") }
                Spacer(Modifier.weight(1f))
                if (aiCategory != null) {
                    TextButton(onClick = { vm.aiReviewList(files, aiCategory) }, enabled = !vm.aiBusy) { Text("Проверить с ИИ") }
                }
            }
            if (grid) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(110.dp),
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(files, key = { it.path }) { f ->
                        val verdict = vm.aiVerdicts[f.path]
                        ImageTile(
                            f, selected = vm.listSelection[f.path] == true, onClick = { vm.toggleListItem(f.path) },
                            badge = verdict?.let { if (it.first) "ИИ: удалить" else "ИИ: оставить" } ?: badgeFor(f)
                        )
                    }
                    item(span = { GridItemSpan(maxLineSpan) }) { Spacer(Modifier.padding(8.dp)) }
                }
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
                    items(files, key = { it.path }) { f ->
                        FileRow(
                            f, checked = vm.listSelection[f.path] == true, onToggle = { vm.toggleListItem(f.path) },
                            extra = vm.aiVerdicts[f.path]?.let { (junk, reason) -> (if (junk) "ИИ: можно удалить" else "ИИ: лучше оставить") + if (reason.isNotBlank()) " — $reason" else "" }
                                ?: badgeFor(f),
                            onShare = { FileActions.share(context, f)?.let { vm.message = it } },
                            onOpen = { FileActions.open(context, f)?.let { vm.message = it } }
                        )
                    }
                }
            }
        }
        DeleteBar(pending.count, pending.bytes, enabled = pending.count > 0 && !vm.deleting) { confirm = pending }
    }
    confirm?.let { p ->
        ConfirmDialog("Удалить выбранное?", deletionText(p), "Удалить", onConfirm = { confirm = null; vm.delete(p) }, onDismiss = { confirm = null })
    }
}

@Composable
fun FileRow(
    f: FileInfo,
    checked: Boolean,
    onToggle: () -> Unit,
    extra: String? = null,
    onShare: (() -> Unit)? = null,
    onOpen: (() -> Unit)? = null
) {
    SectionCard(modifier = Modifier.padding(vertical = 4.dp), onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { onToggle() })
            FileThumbnail(f, size = 48.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${formatSize(f.size)} · ${formatDate(f.lastModified)}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary
                )
                Text(
                    f.parentPath.takeLast(56), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (!extra.isNullOrBlank()) Text(extra, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
            if (onShare != null) IconButton(onClick = onShare) { Icon(Icons.Filled.Share, contentDescription = "Поделиться") }
        }
    }
}

@Composable
fun LargestFilesScreen(vm: MainViewModel) {
    val files = remember(vm.allFiles) { vm.largestFiles() }
    FileSelectionScreen(vm, "Крупные файлы", "Топ-150 по размеру на всех томах", files, "Крупные файлы", aiCategory = "крупный файл")
}

@Composable
fun ScreenshotsScreen(vm: MainViewModel) {
    val files = remember(vm.allFiles) { vm.screenshots() }
    FileSelectionScreen(
        vm, "Скриншоты", "От старых к новым — часто их можно удалить", files, "Скриншоты",
        grid = true, aiCategory = "скриншот", badgeFor = { daysAgo(it.lastModified) }
    )
}

@Composable
fun MessengersScreen(vm: MainViewModel) {
    val files = remember(vm.allFiles, vm.messengerDays) { vm.messengerMedia() }
    FileSelectionScreen(
        vm, "Медиа мессенджеров", "Файлы старше ${vm.messengerDays} дн. из WhatsApp, Telegram, Viber", files, "Медиа мессенджеров",
        aiCategory = "медиа из мессенджера", badgeFor = { StorageAnalyzer.messengerApp(it.path) },
        emptyText = "Старых медиа мессенджеров не найдено. Порог возраста — в настройках."
    ) {
        Text(
            "Это только подсказки: файлы удаляются из памяти телефона, но остаются в чатах в облаке (Telegram) или пропадут (WhatsApp без резервной копии).",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 6.dp)
        )
    }
}

@Composable
fun CategoryScreen(vm: MainViewModel, category: FileCategory) {
    val files = remember(vm.allFiles, vm.categorySort, vm.categoryFilter, category) { vm.filesOf(category) }
    FileSelectionScreen(
        vm, category.title, "Сортировка, поиск и множественный выбор", files, category.title,
        grid = category == FileCategory.IMAGES, aiCategory = category.title.lowercase()
    ) {
        OutlinedTextField(
            value = vm.categoryFilter, onValueChange = { vm.categoryFilter = it },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            placeholder = { Text("Поиск по имени") }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState())) {
            for (s in CategorySort.entries) {
                FilterChip(selected = vm.categorySort == s, onClick = { vm.categorySort = s }, label = { Text(s.title, maxLines = 1) })
            }
        }
    }
}

fun daysAgo(ms: Long): String {
    val d = ((System.currentTimeMillis() - ms) / 86_400_000L).coerceAtLeast(0)
    return when {
        d == 0L -> "сегодня"
        d < 30 -> "$d дн."
        d < 365 -> "${d / 30} мес."
        else -> "${d / 365} г."
    }
}
