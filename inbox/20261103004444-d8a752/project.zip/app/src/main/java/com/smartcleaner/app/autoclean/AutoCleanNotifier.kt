package com.smartcleaner.app.autoclean

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.smartcleaner.app.R
import com.smartcleaner.app.reminder.ReminderReceiver
import com.smartcleaner.app.reminder.ReminderScheduler

/** Уведомление с прогрессом автоочистки и кнопкой «Отменить». */
object AutoCleanNotifier {
    private const val ID = 2002
    const val ACTION_CANCEL = "com.smartcleaner.app.action.CANCEL_AUTOCLEAN"

    fun show(context: Context, index: Int, total: Int, label: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ReminderScheduler.ensureChannel(context)
        val cancel = PendingIntent.getBroadcast(
            context, 3, Intent(context, ReminderReceiver::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Автоочистка кэша: $index из $total")
            .setContentText(if (label.isBlank()) "Подготовка…" else label)
            .setProgress(total, index, total == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Отменить", cancel)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(ID, n)
        } catch (e: SecurityException) {
            // нет разрешения
        }
    }

    fun cancel(context: Context) {
        NotificationManagerCompat.from(context).cancel(ID)
    }
}
