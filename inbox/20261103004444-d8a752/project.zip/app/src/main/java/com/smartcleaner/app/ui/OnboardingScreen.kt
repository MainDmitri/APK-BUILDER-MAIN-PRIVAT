package com.smartcleaner.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private data class OnboardingPage(val icon: ImageVector, val title: String, val text: String)

private val pages = listOf(
    OnboardingPage(
        Icons.Filled.CheckCircle, "Найдём весь лишний мусор",
        "Сканируем все тома памяти — внутреннюю, SD-карту и USB, включая скрытые папки. Пустые файлы, кэш, временные файлы и миниатюры — в одно касание."
    ),
    OnboardingPage(
        Icons.Filled.Star, "Оставим лучшее",
        "Дубликаты, похожие фото и версии документов группируются, а приложение выбирает самый актуальный файл. По желанию — с помощью ИИ Google Gemini."
    ),
    OnboardingPage(
        Icons.Filled.Lock, "Ничего не пропадёт",
        "Без вашего подтверждения ничего не удаляется. Всё сначала попадает в корзину, откуда файл можно восстановить. ИИ работает только с вашим ключом и по вашей команде."
    )
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()
    val g = LocalGradients.current
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 0.92f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "scale"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(g.hero)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDone) { Text("Пропустить", color = Color.White) }
            }
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { index ->
                val p = pages[index]
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        Modifier
                            .size(170.dp)
                            .scale(scale)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier.size(120.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) { Icon(p.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(64.dp)) }
                    }
                    Spacer(Modifier.height(40.dp))
                    Text(p.title, style = MaterialTheme.typography.headlineSmall, color = Color.White, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    Text(p.text, style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.88f), textAlign = TextAlign.Center)
                }
            }
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pages.size) { i ->
                    val selected = pager.currentPage == i
                    val w by animateDpAsState(if (selected) 26.dp else 8.dp, label = "dot")
                    val c by animateColorAsState(if (selected) Color.White else Color.White.copy(alpha = 0.4f), label = "dotc")
                    Box(Modifier.padding(4.dp).height(8.dp).width(w).clip(CircleShape).background(c))
                }
            }
            val last = pager.currentPage == pages.lastIndex
            GradientButton(
                text = if (last) "Начать" else "Далее",
                onClick = {
                    if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                },
                brush = g.accent,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)
            )
        }
    }
}
