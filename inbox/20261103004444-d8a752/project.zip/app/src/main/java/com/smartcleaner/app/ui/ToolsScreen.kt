package com.smartcleaner.app.ui

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.FileCategory

@Composable
fun ToolsScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        GradientHeader("Инструменты", subtitle = "Анализ памяти и умные подсказки")
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // На Android 13+ кэш приложений — главный путь очистки, поэтому эта плитка первой и крупной.
            val cacheSub = when {
                !vm.usageAccess -> "Нужен доступ к статистике · автоочистка в одно касание"
                vm.appCacheTotal > 0 -> "${formatSize(vm.appCacheTotal)} кэша · автоочистка всех приложений"
                else -> "Размеры кэша и автоочистка"
            }
            SectionCard(onClick = { vm.navigate(Screen.AppCaches) }, containerColor = MaterialTheme.colorScheme.primaryContainer) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBubble(Icons.Filled.Build, MaterialTheme.colorScheme.primary, size = 52.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Кэш приложений", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(cacheSub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        if (Build.VERSION.SDK_INT >= 33) {
                            Text("Рекомендуется для Android ${Build.VERSION.RELEASE}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
                }
            }
            val needScan = !vm.hasResults
            if (needScan) {
                Text(
                    "Инструменты ниже работают по результатам сканирования — запустите его на главной.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            ToolRow(Icons.Filled.Star, Teal, "Очистка в одно касание", "Только безопасный мусор, с предпросмотром", !needScan) { vm.navigate(Screen.OneTap) }
            ToolRow(Icons.AutoMirrored.Filled.List, Indigo, "Анализатор памяти", "Самые большие папки с переходом внутрь", !needScan) { vm.navigate(Screen.Analyzer(null)) }
            ToolRow(Icons.Filled.Warning, Coral, "Крупные файлы", "Топ-150 по размеру", !needScan) { vm.startList(); vm.navigate(Screen.LargestFiles) }
            ToolRow(Icons.Filled.Face, Violet, "Размытые и тёмные фото", "Оценка резкости (Лаплассиан) и яркости", !needScan) { vm.startList(); vm.navigate(Screen.Photos) }
            ToolRow(Icons.Filled.DateRange, Amber, "Скриншоты", "Все снимки экрана, от старых к новым", !needScan) { vm.startList(); vm.navigate(Screen.Screenshots) }
            ToolRow(Icons.Filled.Email, Mint, "Медиа мессенджеров", "Старые файлы WhatsApp, Telegram, Viber", !needScan) { vm.startList(); vm.navigate(Screen.Messengers) }

            Text("Категории", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
            val stats = vm.categoryStats.associateBy { it.category }
            for (row in FileCategory.entries.filter { it != FileCategory.OTHER }.chunked(2)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (c in row) {
                        val st = stats[c]
                        SectionCard(
                            modifier = Modifier.weight(1f),
                            onClick = if (needScan) null else ({ vm.startList(); vm.navigate(Screen.Category(c)) })
                        ) {
                            CategoryBadge(c)
                            Spacer(Modifier.height(8.dp))
                            Text(c.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (st == null) "—" else "${st.count} · ${formatSize(st.bytes)}",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            ToolRow(Icons.Filled.DateRange, MaterialTheme.colorScheme.secondary, "История очисток", "Сколько и когда освобождено", true) { vm.refreshHistory(); vm.navigate(Screen.History) }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ToolRow(icon: ImageVector, color: Color, title: String, subtitle: String, enabled: Boolean, onClick: () -> Unit) {
    SectionCard(onClick = if (enabled) onClick else null) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconBubble(icon, if (enabled) color else Color.Gray)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (enabled) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
        }
    }
}
