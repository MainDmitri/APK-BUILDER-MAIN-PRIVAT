package com.smartcleaner.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.PhotoIssueKind

@Composable
fun PhotosScreen(vm: MainViewModel) {
    var filter by rememberSaveable { mutableStateOf(-1) } // -1 все, иначе ordinal PhotoIssueKind
    val issues = vm.photoIssues.toList()
    val shown = remember(issues.size, filter) {
        issues.filter { filter < 0 || PhotoIssueKind.entries[filter] in it.kinds }.sortedBy { it.sharpness }
    }
    val byPath = issues.associateBy { it.file.path }
    FileSelectionScreen(
        vm, "Размытые и тёмные фото", "Анализ резкости (дисперсия Лапласиана) и яркости",
        shown.map { it.file }, "Неудачные фото", grid = true, aiCategory = "размытое или тёмное фото",
        badgeFor = { f -> byPath[f.path]?.kinds?.joinToString(", ") { it.title } },
        emptyTitle = if (vm.photoChecked) "Неудачных фото не найдено" else "Фото ещё не проверены",
        emptyText = if (vm.photoChecked) "Все фото достаточно резкие и светлые" else "Нажмите «Проверить фото» — анализ идёт на устройстве, без интернета"
    ) {
        if (vm.photoScanning) {
            Text("Проверяю фото… найдено ${issues.size}", modifier = Modifier.padding(top = 8.dp))
            LinearProgressIndicator(progress = { vm.photoProgress }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            OutlinedButton(onClick = { vm.cancelPhotos() }) { Text("Остановить проверку") }
        } else {
            Button(onClick = { vm.analyzePhotos() }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text(if (vm.photoChecked) "Проверить снова" else "Проверить фото")
            }
        }
        if (issues.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                FilterChip(selected = filter < 0, onClick = { filter = -1 }, label = { Text("Все ${issues.size}") })
                for (k in PhotoIssueKind.entries) {
                    FilterChip(selected = filter == k.ordinal, onClick = { filter = k.ordinal }, label = { Text("${k.title} ${issues.count { k in it.kinds }}") })
                }
            }
        }
        Text(
            "Порог резкости — в настройках (сейчас ${vm.blurThreshold}). Ничего не отмечается автоматически.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
}
