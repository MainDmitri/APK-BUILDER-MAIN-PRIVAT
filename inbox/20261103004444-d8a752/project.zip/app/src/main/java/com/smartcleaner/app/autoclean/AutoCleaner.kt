package com.smartcleaner.app.autoclean

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.smartcleaner.app.MainActivity
import com.smartcleaner.app.data.AppCacheInfo
import com.smartcleaner.app.scan.AppCacheStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Последовательная автоочистка кэша выбранных приложений через [CacheCleanerService]. */
object AutoCleaner {

    private val _state = MutableStateFlow(AutoCleanState())
    val state: StateFlow<AutoCleanState> = _state

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    @Volatile
    var isRunning: Boolean = false
        private set

    private const val PER_APP_TIMEOUT_MS = 12_000L

    fun isServiceEnabled(context: Context): Boolean {
        if (CacheCleanerService.instance != null) return true
        val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(context, CacheCleanerService::class.java)
        return enabled.split(':').any {
            ComponentName.unflattenFromString(it)?.let { c -> c == me } ?: false
        }
    }

    fun accessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun ownDetailsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun start(context: Context, apps: List<AppCacheInfo>, onFinished: (AutoCleanState) -> Unit) {
        val service = CacheCleanerService.instance
        if (isRunning || service == null || apps.isEmpty()) return
        val appContext = context.applicationContext
        val targets = apps.filter { it.packageName != appContext.packageName }
        isRunning = true
        _state.value = AutoCleanState(running = true, total = targets.size)
        AutoCleanNotifier.show(appContext, 0, targets.size, "")
        job = scope.launch {
            val results = ArrayList<AutoCleanResult>()
            for ((i, app) in targets.withIndex()) {
                if (!isRunning) {
                    results.add(AutoCleanResult(app.packageName, app.label, AutoCleanOutcome.CANCELLED, app.cacheBytes, app.cacheBytes))
                    continue
                }
                _state.value = _state.value.copy(index = i + 1, currentLabel = app.label, step = "Открываю настройки", results = results.toList())
                AutoCleanNotifier.show(appContext, i + 1, targets.size, app.label)
                val svc = CacheCleanerService.instance
                val outcome = if (svc == null) {
                    AutoCleanOutcome.SKIPPED
                } else {
                    try {
                        svc.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                        )
                        svc.cleanCurrentApp(app.label, PER_APP_TIMEOUT_MS) { step ->
                            _state.value = _state.value.copy(step = step)
                        }
                    } catch (e: Exception) {
                        AutoCleanOutcome.SKIPPED
                    }
                }
                delay(400)
                val after = withContext(Dispatchers.IO) { AppCacheStats.cacheOf(appContext, app.packageName) ?: app.cacheBytes }
                val finalOutcome = if (outcome == AutoCleanOutcome.TIMEOUT && after < app.cacheBytes / 2) AutoCleanOutcome.CLEARED else outcome
                results.add(AutoCleanResult(app.packageName, app.label, finalOutcome, app.cacheBytes, after))
                if (outcome == AutoCleanOutcome.CANCELLED) isRunning = false
            }
            CacheCleanerService.instance?.goBack()
            delay(300)
            val final = AutoCleanState(running = false, finished = true, total = targets.size, index = targets.size, results = results)
            _state.value = final
            isRunning = false
            AutoCleanNotifier.cancel(appContext)
            // Возвращаем пользователя в приложение с отчётом.
            try {
                val launcher = CacheCleanerService.instance ?: appContext
                launcher.startActivity(
                    Intent(appContext, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (e: Exception) {
                // не критично
            }
            onFinished(final)
        }
    }

    fun cancel() {
        if (!isRunning) return
        isRunning = false
        _state.value = _state.value.copy(step = "Отмена…")
    }

    fun reset() {
        if (!isRunning) _state.value = AutoCleanState()
    }
}
