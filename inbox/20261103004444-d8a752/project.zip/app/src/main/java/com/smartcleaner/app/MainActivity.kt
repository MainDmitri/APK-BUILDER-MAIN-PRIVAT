package com.smartcleaner.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import com.smartcleaner.app.ui.MainViewModel
import com.smartcleaner.app.ui.SmartCleanerApp
import com.smartcleaner.app.ui.SmartCleanerTheme
import com.smartcleaner.app.ui.isDarkFor

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        viewModel.refreshPermission()
        setContent {
            val dark = isDarkFor(viewModel.themeMode)
            // Edge-to-edge (обязателен на Android 15+): цвет иконок системных панелей под выбранную тему.
            DisposableEffect(dark) {
                enableEdgeToEdge(
                    statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT) { dark },
                    navigationBarStyle = SystemBarStyle.auto(LIGHT_SCRIM, DARK_SCRIM) { dark }
                )
                onDispose {}
            }
            SmartCleanerTheme(themeMode = viewModel.themeMode, dynamicColor = viewModel.dynamicColor) {
                SmartCleanerApp(viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Пользователь мог выдать доступ ко всем файлам, к статистике или включить службу в настройках.
        viewModel.refreshPermission()
    }

    companion object {
        private val LIGHT_SCRIM = Color.argb(0xe6, 0xFF, 0xFF, 0xFF)
        private val DARK_SCRIM = Color.argb(0x80, 0x1b, 0x1b, 0x1b)
    }
}
