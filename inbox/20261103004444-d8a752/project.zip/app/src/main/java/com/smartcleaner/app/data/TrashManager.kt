package com.smartcleaner.app.data

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Безопасное удаление: файлы сначала переносятся в собственную папку корзины приложения
 * и могут быть восстановлены по исходному пути.
 */
class TrashManager(context: Context) {

    private val appContext = context.applicationContext
    private val db = TrashDatabase(appContext)
    private var counter = 0

    val trashDir: File by lazy {
        val external = appContext.getExternalFilesDir(null)
        val base = if (external != null) File(external, "trash") else File(appContext.filesDir, "trash")
        if (!base.exists()) base.mkdirs()
        val noMedia = File(base, ".nomedia")
        if (!noMedia.exists()) runCatching { noMedia.createNewFile() }
        base
    }

    data class MoveReport(val moved: Int, val failed: Int, val bytes: Long, val errors: List<String>)

    @Synchronized
    fun moveToTrash(paths: Collection<String>, protectedPaths: Set<String>): MoveReport {
        var moved = 0
        var failed = 0
        var bytes = 0L
        val errors = ArrayList<String>()
        // Сначала файлы, затем папки от самых глубоких — чтобы пустые папки удалялись корректно.
        val ordered = paths.distinct().sortedWith(
            compareBy<String> { File(it).isDirectory }.thenByDescending { it.count { ch -> ch == '/' } }
        )
        for (path in ordered) {
            if (path in protectedPaths) continue
            val src = File(path)
            if (!src.exists()) continue
            if (src.absolutePath.startsWith(trashDir.absolutePath)) continue
            val isDir = src.isDirectory
            if (isDir && (src.list()?.isNotEmpty() == true)) {
                failed++
                errors.add("Папка не пуста: ${src.name}")
                continue
            }
            val size = if (isDir) 0L else src.length()
            val target = File(trashDir, "${System.currentTimeMillis()}_${counter++}_${src.name}")
            val ok = if (isDir) {
                target.mkdirs() && src.delete()
            } else {
                moveFile(src, target)
            }
            if (ok) {
                db.insert(src.absolutePath, target.absolutePath, size, System.currentTimeMillis(), isDir)
                moved++
                bytes += size
            } else {
                failed++
                errors.add("Не удалось переместить: ${src.name}")
            }
        }
        return MoveReport(moved, failed, bytes, errors)
    }

    fun entries(): List<TrashEntry> = db.all()

    fun addHistory(files: Int, bytes: Long, source: String) = db.addHistory(files, bytes, source)

    fun history(): List<HistoryEntry> = db.history()

    fun clearHistory() = db.clearHistory()

    fun totalSize(): Long = db.all().sumOf { it.size }

    /** Восстанавливает файл. Если по исходному пути уже есть файл, добавляет суффикс. */
    @Synchronized
    fun restore(entry: TrashEntry): Result<String> {
        val original = File(entry.originalPath)
        val parent = original.parentFile
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            return Result.failure(IllegalStateException("Не удалось создать папку ${parent.absolutePath}"))
        }
        if (entry.isDirectory) {
            val ok = original.exists() || original.mkdirs()
            File(entry.trashPath).delete()
            db.delete(entry.id)
            return if (ok) Result.success(original.absolutePath)
            else Result.failure(IllegalStateException("Не удалось восстановить папку"))
        }
        val src = File(entry.trashPath)
        if (!src.exists()) {
            db.delete(entry.id)
            return Result.failure(IllegalStateException("Файл в корзине не найден"))
        }
        var target = original
        if (target.exists()) {
            val base = original.nameWithoutExtension
            val ext = original.extension
            var i = 1
            do {
                val name = if (ext.isEmpty()) "$base (восстановлено $i)" else "$base (восстановлено $i).$ext"
                target = File(parent, name)
                i++
            } while (target.exists())
        }
        return if (moveFile(src, target)) {
            db.delete(entry.id)
            Result.success(target.absolutePath)
        } else {
            Result.failure(IllegalStateException("Не удалось восстановить ${original.name}"))
        }
    }

    @Synchronized
    fun deletePermanently(entry: TrashEntry): Boolean {
        val f = File(entry.trashPath)
        val ok = !f.exists() || f.deleteRecursively()
        if (ok) db.delete(entry.id)
        return ok
    }

    @Synchronized
    fun emptyAll(): Int {
        var count = 0
        for (e in db.all()) if (deletePermanently(e)) count++
        // Убираем возможные осиротевшие файлы.
        trashDir.listFiles()?.forEach { if (it.name != ".nomedia") it.deleteRecursively() }
        return count
    }

    /** Окончательно удаляет записи старше [days] дней. */
    @Synchronized
    fun purgeOlderThan(days: Int): Int {
        val limit = System.currentTimeMillis() - days.toLong() * 24L * 60L * 60L * 1000L
        var count = 0
        for (e in db.all()) {
            if (e.deletedAt < limit && deletePermanently(e)) count++
        }
        return count
    }

    private fun moveFile(src: File, dst: File): Boolean {
        dst.parentFile?.let { if (!it.exists()) it.mkdirs() }
        val lastModified = src.lastModified()
        if (src.renameTo(dst)) return true
        // Разные разделы/точки монтирования: копируем и удаляем исходник.
        return try {
            FileInputStream(src).use { input ->
                FileOutputStream(dst).use { output -> input.copyTo(output, 256 * 1024) }
            }
            if (dst.length() != src.length()) {
                dst.delete()
                false
            } else {
                dst.setLastModified(lastModified)
                if (src.delete()) {
                    true
                } else {
                    dst.delete()
                    false
                }
            }
        } catch (e: Exception) {
            dst.delete()
            false
        }
    }
}
