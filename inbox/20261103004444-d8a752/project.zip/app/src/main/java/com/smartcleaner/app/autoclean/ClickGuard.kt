package com.smartcleaner.app.autoclean

import java.util.Locale

/**
 * Белый список нажатий для службы автоочистки кэша. Чистая логика без Android — покрыта unit-тестами.
 * Служба нажимает ТОЛЬКО на пункт «Хранилище/Память» и кнопку «Очистить кэш».
 * Всё, что похоже на «Очистить данные / хранилище», «Удалить», «Остановить», «Сбросить», — запрещено.
 */
object ClickGuard {

    private fun norm(s: String?): String =
        (s ?: "").lowercase(Locale.ROOT).replace('ё', 'е').replace('\u00a0', ' ').replace(Regex("\\s+"), " ").trim()

    private val cacheWords = listOf("кэш", "кеш", "cache")
    private val dataWords = listOf("данн", "data", "storage", "хранилищ", "всё", "все", "all")
    private val dangerVerbs = listOf(
        "удал", "delete", "uninstall", "остановить", "force stop", "stop", "сброс", "reset", "отключ", "disable",
        "format", "формат", "erase", "стереть"
    )
    private val clearVerbs = listOf("очист", "clear", "wipe")

    /** Тексты пункта, ведущего на страницу хранилища приложения. */
    private val storageEntries = listOf(
        "хранилище и кэш", "хранилище и кеш", "хранилище", "память", "использование памяти", "накопитель",
        "storage & cache", "storage and cache", "storage", "storage usage", "memory"
    )

    fun isForbidden(text: String?): Boolean {
        val t = norm(text)
        if (t.isEmpty()) return false
        if (dangerVerbs.any { t.contains(it) }) return true
        val hasClear = clearVerbs.any { t.contains(it) }
        val hasCache = cacheWords.any { t.contains(it) }
        // «Очистить данные», «Clear storage», «Очистить всё» — запрещено.
        if (hasClear && !hasCache) return true
        if (hasClear && dataWords.any { t.contains(it) } && !onlyCacheMention(t)) return true
        return false
    }

    /** «Очистить кэш» не должно содержать упоминания данных; «хранилище и кэш» в кнопке — тоже подозрительно. */
    private fun onlyCacheMention(t: String): Boolean =
        !t.contains("данн") && !t.contains("data") && !t.contains("storage") && !t.contains("хранилищ") &&
            !Regex("(^|\\s)(все|всё|all)(\\s|$)").containsMatchIn(t)

    /** Кнопка «Очистить кэш». */
    fun isClearCache(text: String?): Boolean {
        val t = norm(text)
        if (t.isEmpty() || t.length > 40) return false
        if (isForbidden(t)) return false
        return clearVerbs.any { t.contains(it) } && cacheWords.any { t.contains(it) }
    }

    /** Пункт «Хранилище и кэш» / «Память» / «Storage». Не должен содержать глаголов очистки/удаления. */
    fun isStorageEntry(text: String?): Boolean {
        val t = norm(text)
        if (t.isEmpty() || t.length > 40) return false
        if (clearVerbs.any { t.contains(it) } || dangerVerbs.any { t.contains(it) }) return false
        return storageEntries.any { t == it }
    }

    /** Кнопка подтверждения в диалоге — допускается только если сам диалог говорит именно о кэше. */
    fun isSafeConfirm(buttonText: String?, dialogText: String): Boolean {
        val b = norm(buttonText)
        val d = norm(dialogText)
        val okWords = setOf("ок", "ok", "да", "yes", "очистить кэш", "очистить кеш", "clear cache")
        if (b !in okWords) return false
        if (!cacheWords.any { d.contains(it) }) return false
        if (d.contains("данн") || d.contains(" data") || d.startsWith("data")) return false
        return true
    }

    /** Открывающая кнопка MIUI/HyperOS («Очистить» внизу карточки) — показывает лишь меню выбора. */
    fun isMiuiOpener(text: String?): Boolean = norm(text) == "очистить"
}
