package com.smartcleaner.app.scan

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * Оценка качества фото: резкость — дисперсия Лапласиана по уменьшенной серой копии,
 * яркость — средняя яркость пикселей (0..255).
 */
object PhotoQuality {

    data class Quality(val sharpness: Double, val brightness: Double)

    /** Дисперсия отклика ядра Лапласиана [0 1 0; 1 -4 1; 0 1 0]. Чем меньше — тем более размыто. */
    fun laplacianVariance(gray: IntArray, width: Int, height: Int): Double {
        if (width < 3 || height < 3 || gray.size < width * height) return 0.0
        var sum = 0.0
        var sumSq = 0.0
        var n = 0
        for (y in 1 until height - 1) {
            val row = y * width
            for (x in 1 until width - 1) {
                val i = row + x
                val v = (gray[i - width] + gray[i + width] + gray[i - 1] + gray[i + 1] - 4 * gray[i]).toDouble()
                sum += v
                sumSq += v * v
                n++
            }
        }
        if (n == 0) return 0.0
        val mean = sum / n
        return sumSq / n - mean * mean
    }

    fun meanBrightness(gray: IntArray): Double {
        if (gray.isEmpty()) return 0.0
        var s = 0L
        for (g in gray) s += g
        return s.toDouble() / gray.size
    }

    fun toGray(pixels: IntArray): IntArray = IntArray(pixels.size) { i ->
        val p = pixels[i]
        val r = (p shr 16) and 0xFF
        val g = (p shr 8) and 0xFF
        val b = p and 0xFF
        (r * 299 + g * 587 + b * 114) / 1000
    }

    fun analyze(file: File, targetSide: Int = 320): Quality? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            val opts = BitmapFactory.Options().apply {
                inSampleSize = Hashing.sampleSizeFor(bounds.outWidth, bounds.outHeight, targetSide)
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decoded = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return null
            val scale = targetSide.toFloat() / maxOf(decoded.width, decoded.height)
            val bmp = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    decoded,
                    (decoded.width * scale).toInt().coerceAtLeast(3),
                    (decoded.height * scale).toInt().coerceAtLeast(3),
                    true
                )
            } else {
                decoded
            }
            val w = bmp.width
            val h = bmp.height
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            if (bmp !== decoded) bmp.recycle()
            decoded.recycle()
            val gray = toGray(pixels)
            Quality(laplacianVariance(gray, w, h), meanBrightness(gray))
        } catch (e: Throwable) {
            null
        }
    }
}
