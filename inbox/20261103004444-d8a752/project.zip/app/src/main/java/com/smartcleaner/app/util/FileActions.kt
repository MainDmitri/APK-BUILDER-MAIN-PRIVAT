package com.smartcleaner.app.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.smartcleaner.app.data.FileInfo
import java.io.File

/** Открыть или поделиться файлом через FileProvider (или напрямую по content://, если файл из SAF). */
object FileActions {

    private fun mime(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase()) ?: "*/*"

    private fun uriFor(context: Context, file: FileInfo): Uri =
        file.uri?.let { Uri.parse(it) }
            ?: FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(file.path))

    /** Возвращает текст ошибки или null при успехе. */
    fun open(context: Context, file: FileInfo): String? = try {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(context, file), mime(file.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        null
    } catch (e: ActivityNotFoundException) {
        "Нет приложения для открытия этого файла"
    } catch (e: Exception) {
        "Не удалось открыть файл: ${e.message ?: "ошибка"}"
    }

    fun share(context: Context, file: FileInfo): String? = try {
        val send = Intent(Intent.ACTION_SEND)
            .setType(mime(file.name))
            .putExtra(Intent.EXTRA_STREAM, uriFor(context, file))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "Поделиться файлом").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    } catch (e: Exception) {
        "Не удалось поделиться: ${e.message ?: "ошибка"}"
    }
}
