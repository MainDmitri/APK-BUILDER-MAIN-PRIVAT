package com.smartcleaner.app.ui

import android.net.Uri
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.data.FileInfo
import java.io.File

fun categoryColor(c: FileCategory): Color = Color(c.colorHex)

fun categoryIcon(c: FileCategory): ImageVector = when (c) {
    FileCategory.IMAGES -> Icons.Filled.Face
    FileCategory.VIDEO -> Icons.Filled.PlayArrow
    FileCategory.AUDIO -> Icons.Filled.Notifications
    FileCategory.DOCUMENTS -> Icons.Filled.Create
    FileCategory.ARCHIVES -> Icons.Filled.Lock
    FileCategory.APK -> Icons.Filled.Build
    FileCategory.OTHER -> Icons.Filled.MoreVert
}

/** Шапка экрана с фирменным градиентом. Отступ под статус-бар учитывается внутри. */
@Composable
fun GradientHeader(
    title: String,
    subtitle: String? = null,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit = {}
) {
    val g = LocalGradients.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(g.hero)
            .statusBarsPadding()
            .padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад", tint = Color.White)
                }
            } else {
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                Text(
                    title, color = Color.White, style = MaterialTheme.typography.titleLarge,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (subtitle != null) {
                    Text(
                        subtitle, color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodySmall,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            actions()
        }
        Column(Modifier.padding(horizontal = 8.dp)) { content() }
    }
}

/** Карточка-секция с мягкой тенью. */
@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color = MaterialTheme.colorScheme.surface,
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = CardDefaults.cardColors(containerColor = containerColor)
    val elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    if (onClick != null) {
        Card(onClick = onClick, modifier = modifier.fillMaxWidth(), colors = colors, elevation = elevation) {
            Column(Modifier.padding(16.dp), content = content)
        }
    } else {
        Card(modifier = modifier.fillMaxWidth(), colors = colors, elevation = elevation) {
            Column(Modifier.padding(16.dp), content = content)
        }
    }
}

/** Кнопка с градиентной заливкой. */
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    brush: Brush = LocalGradients.current.hero,
    enabled: Boolean = true,
    icon: ImageVector? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.height(54.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, disabledContainerColor = Color.Transparent),
        contentPadding = androidx.compose.foundation.layout.PaddingValues()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(if (enabled) brush else Brush.linearGradient(listOf(Color.Gray, Color.Gray)), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(icon, contentDescription = null, tint = Color.White)
                    Spacer(Modifier.width(8.dp))
                }
                Text(text, color = Color.White, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

/** Значок категории в цветном круге. */
@Composable
fun CategoryBadge(category: FileCategory, size: Dp = 40.dp) {
    val color = categoryColor(category)
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(categoryIcon(category), contentDescription = null, tint = color, modifier = Modifier.size(size * 0.55f))
    }
}

/** Иконка-плашка в круге с произвольным цветом. */
@Composable
fun IconBubble(icon: ImageVector, color: Color, size: Dp = 44.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(14.dp))
            .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(size * 0.55f))
    }
}

/** Миниатюра файла: изображения через Coil (асинхронно, с кэшем), иначе — значок категории. */
@Composable
fun FileThumbnail(file: FileInfo, size: Dp = 56.dp, corner: Dp = 12.dp) {
    val category = FileCategory.of(file.extension)
    val shape = RoundedCornerShape(corner)
    if (category == FileCategory.IMAGES) {
        val context = LocalContext.current
        val px = with(androidx.compose.ui.platform.LocalDensity.current) { size.roundToPx() }.coerceAtLeast(64)
        val request = remember(file.path, px) {
            ImageRequest.Builder(context)
                .data(file.uri?.let { Uri.parse(it) } ?: File(file.path))
                .size(px)
                .crossfade(true)
                .build()
        }
        Box(Modifier.size(size).clip(shape).background(categoryColor(category).copy(alpha = 0.12f))) {
            AsyncImage(
                model = request,
                contentDescription = file.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Box(
            modifier = Modifier.size(size).clip(shape).background(categoryColor(category).copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(categoryIcon(category), contentDescription = null, tint = categoryColor(category), modifier = Modifier.size(size * 0.36f))
                Text(
                    file.extension.uppercase().take(4).ifEmpty { "ФАЙЛ" },
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, color = categoryColor(category)
                )
            }
        }
    }
}

/** Плитка изображения для сетки с отметкой выбора. */
@Composable
fun ImageTile(
    file: FileInfo,
    selected: Boolean,
    onClick: () -> Unit,
    badge: String? = null,
    badgeColor: Color = MaterialTheme.colorScheme.primary
) {
    val border = if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.error) else BorderStroke(0.dp, Color.Transparent)
    Box(
        modifier = Modifier
            .padding(3.dp)
            .clip(RoundedCornerShape(14.dp))
            .border(border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
    ) {
        FileThumbnail(file, size = 112.dp, corner = 14.dp)
        Checkbox(
            checked = selected, onCheckedChange = { onClick() },
            modifier = Modifier.align(Alignment.TopEnd)
        )
        if (badge != null) {
            Surface(
                color = badgeColor, shape = RoundedCornerShape(topEnd = 10.dp),
                modifier = Modifier.align(Alignment.BottomStart)
            ) {
                Text(badge, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
        Surface(
            color = Color.Black.copy(alpha = 0.55f), shape = RoundedCornerShape(topStart = 10.dp),
            modifier = Modifier.align(Alignment.BottomEnd)
        ) {
            Text(formatSize(file.size), color = Color.White, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
        }
    }
}

/** Сегмент кольцевой диаграммы. */
data class GaugeSegment(val fraction: Float, val color: Color)

/**
 * Анимированное кольцо заполнения памяти с цветными сегментами по категориям.
 * Сумма долей сегментов ≤ 1; оставшаяся «занятая» часть рисуется цветом [restColor].
 */
@Composable
fun StorageGauge(
    usedFraction: Float,
    segments: List<GaugeSegment>,
    modifier: Modifier = Modifier,
    trackColor: Color = Color.White.copy(alpha = 0.18f),
    restColor: Color = Color.White.copy(alpha = 0.55f),
    strokeWidth: Dp = 18.dp,
    center: @Composable () -> Unit = {}
) {
    val anim = remember { Animatable(0f) }
    LaunchedEffect(usedFraction, segments) {
        anim.snapTo(0f)
        anim.animateTo(1f, tween(durationMillis = 1300, easing = FastOutSlowInEasing))
    }
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val sw = strokeWidth.toPx()
            val arcSize = Size(size.minDimension - sw, size.minDimension - sw)
            val topLeft = Offset((size.width - arcSize.width) / 2f, (size.height - arcSize.height) / 2f)
            val startAngle = 135f
            val sweepTotal = 270f
            drawArc(trackColor, startAngle, sweepTotal, false, topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
            val progress = anim.value
            val used = usedFraction.coerceIn(0f, 1f) * sweepTotal * progress
            drawArc(restColor, startAngle, used, false, topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Round))
            var angle = startAngle
            for (s in segments) {
                val sweep = (s.fraction.coerceIn(0f, 1f) * sweepTotal * progress).coerceAtMost(startAngle + used - angle)
                if (sweep <= 0.5f) continue
                drawArc(s.color, angle, sweep, false, topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Butt))
                angle += sweep
            }
        }
        center()
    }
}

/** Небольшой показатель «значение + подпись». */
@Composable
fun StatPill(value: String, label: String, modifier: Modifier = Modifier, light: Boolean = true) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (light) Color.White.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = if (light) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
        Text(label, color = if (light) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, maxLines = 1)
    }
}

/** Пустое состояние экрана. */
@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(84.dp).clip(CircleShape).background(LocalGradients.current.accent),
            contentAlignment = Alignment.Center
        ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp)) }
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        action?.invoke()
    }
}

/** Полоса статуса ИИ. */
@Composable
fun AiStatusBar(status: String) {
    if (status.isBlank()) return
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
        LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 4.dp).clip(RoundedCornerShape(4.dp)))
    }
}

/** Нижняя панель действия «Удалить выбранное». */
@Composable
fun DeleteBar(count: Int, bytes: Long, enabled: Boolean, label: String = "В корзину", onClick: () -> Unit) {
    Surface(tonalElevation = 6.dp, shadowElevation = 8.dp, color = MaterialTheme.colorScheme.surface) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Выбрано: $count", fontWeight = FontWeight.SemiBold)
                Text(formatSize(bytes), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            }
            GradientButton(
                text = label, onClick = onClick, enabled = enabled && count > 0,
                brush = LocalGradients.current.danger, modifier = Modifier.width(170.dp)
            )
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    text: String,
    confirmText: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = {
            TextButton(onClick = {
                onConfirm()
                onDismiss()
            }) { Text(confirmText) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

/** Текст подтверждения удаления: честно сообщает, что уйдёт в корзину, а что удалится сразу. */
fun deletionText(p: MainViewModel.PendingDeletion): String = buildString {
    append("Будет удалено файлов: ${p.count} (${formatSize(p.bytes)}).\n")
    val toTrash = p.count - p.permanentCount
    if (toTrash > 0) append("$toTrash — в корзину приложения, их можно восстановить.\n")
    if (p.permanentCount > 0) {
        append("${p.permanentCount} из Android/data или obb (системный доступ) — удалятся СРАЗУ, без корзины.\n")
    }
    if (p.fromGroups) append("Основные (сохраняемые) файлы групп защищены и не удаляются.")
}
