package com.smartcleaner.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.scan.StorageAnalyzer
import com.smartcleaner.app.util.FileActions

@Composable
fun AnalyzerScreen(vm: MainViewModel, path: String?) {
    LaunchedEffect(Unit) { vm.ensureFolderIndex() }
    val idx = vm.folderIndex
    val context = LocalContext.current
    val title = path?.substringAfterLast('/')?.ifBlank { "/" } ?: "Анализатор памяти"
    Column(Modifier.fillMaxSize()) {
        val total = when {
            idx == null -> 0L
            path == null -> idx.roots.sumOf { idx.sizes[it] ?: 0L }
            else -> idx.sizes[path] ?: 0L
        }
        GradientHeader(title, subtitle = path ?: "Тома и самые тяжёлые папки", onBack = { vm.back() }) {
            Text(formatSize(total), style = MaterialTheme.typography.headlineMedium, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
        }
        if (idx == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            return@Column
        }
        val folders: List<StorageAnalyzer.FolderNode> =
            if (path == null) idx.roots.map { r -> idx.node(r).let { n -> n.copy(name = vm.scannedVolumes.firstOrNull { it.path.trimEnd('/') == r }?.title ?: n.name) } }
            else idx.children(path)
        val files = if (path == null) emptyList() else idx.files(path).take(200)
        val max = (folders.maxOfOrNull { it.bytes } ?: 1L).coerceAtLeast(files.maxOfOrNull { it.size } ?: 1L).coerceAtLeast(1L)
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            if (folders.isEmpty() && files.isEmpty()) {
                item { EmptyState(Icons.Filled.Home, "Папка пуста", "Здесь нет файлов из последнего сканирования") }
            }
            items(folders, key = { "d:" + it.path }) { n ->
                SizeBarRow(n.name, "${n.files} файлов", n.bytes, max, isFolder = true) { vm.navigate(Screen.Analyzer(n.path)) }
            }
            items(files, key = { "f:" + it.path }) { f ->
                SizeBarRow(f.name, formatDate(f.lastModified), f.size, max, isFolder = false) {
                    FileActions.open(context, f)?.let { vm.message = it }
                }
            }
        }
    }
}

@Composable
private fun SizeBarRow(name: String, sub: String, bytes: Long, max: Long, isFolder: Boolean, onClick: () -> Unit) {
    val frac by animateFloatAsState((bytes.toFloat() / max).coerceIn(0.02f, 1f), tween(600), label = "bar")
    SectionCard(modifier = Modifier.padding(vertical = 4.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((if (isFolder) "📁 " else "📄 ") + name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${formatSize(bytes)} · $sub", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(LocalGradients.current.accent))
                }
            }
            if (isFolder) {
                Spacer(Modifier.width(8.dp))
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null)
            }
        }
    }
}
