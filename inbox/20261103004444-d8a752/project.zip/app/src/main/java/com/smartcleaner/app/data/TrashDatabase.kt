package com.smartcleaner.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** База приложения: журнал корзины и история очисток. */
class TrashDatabase(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "trash.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE trash (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "original_path TEXT NOT NULL, " +
                "trash_path TEXT NOT NULL, " +
                "size INTEGER NOT NULL, " +
                "deleted_at INTEGER NOT NULL, " +
                "is_dir INTEGER NOT NULL DEFAULT 0)"
        )
        createHistory(db)
    }

    private fun createHistory(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS history (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "time INTEGER NOT NULL, " +
                "files INTEGER NOT NULL, " +
                "bytes INTEGER NOT NULL, " +
                "source TEXT NOT NULL)"
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Версия 1 → 2: добавлена история, журнал корзины сохраняется.
        if (oldVersion < 2) createHistory(db)
    }

    fun insert(originalPath: String, trashPath: String, size: Long, deletedAt: Long, isDir: Boolean): Long {
        val values = ContentValues().apply {
            put("original_path", originalPath)
            put("trash_path", trashPath)
            put("size", size)
            put("deleted_at", deletedAt)
            put("is_dir", if (isDir) 1 else 0)
        }
        return writableDatabase.insert("trash", null, values)
    }

    fun delete(id: Long) {
        writableDatabase.delete("trash", "id = ?", arrayOf(id.toString()))
    }

    fun all(): List<TrashEntry> {
        val result = ArrayList<TrashEntry>()
        readableDatabase.query(
            "trash",
            arrayOf("id", "original_path", "trash_path", "size", "deleted_at", "is_dir"),
            null, null, null, null, "deleted_at DESC"
        ).use { c ->
            while (c.moveToNext()) {
                result.add(
                    TrashEntry(
                        id = c.getLong(0),
                        originalPath = c.getString(1),
                        trashPath = c.getString(2),
                        size = c.getLong(3),
                        deletedAt = c.getLong(4),
                        isDirectory = c.getInt(5) == 1
                    )
                )
            }
        }
        return result
    }

    fun addHistory(files: Int, bytes: Long, source: String) {
        val values = ContentValues().apply {
            put("time", System.currentTimeMillis())
            put("files", files)
            put("bytes", bytes)
            put("source", source)
        }
        writableDatabase.insert("history", null, values)
    }

    fun history(): List<HistoryEntry> {
        val result = ArrayList<HistoryEntry>()
        readableDatabase.query(
            "history", arrayOf("id", "time", "files", "bytes", "source"),
            null, null, null, null, "time DESC"
        ).use { c ->
            while (c.moveToNext()) {
                result.add(HistoryEntry(c.getLong(0), c.getLong(1), c.getInt(2), c.getLong(3), c.getString(4)))
            }
        }
        return result
    }

    fun clearHistory() {
        writableDatabase.delete("history", null, null)
    }
}
