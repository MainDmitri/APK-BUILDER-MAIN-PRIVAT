package com.smartcleaner.app.reminder

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.smartcleaner.app.MainActivity
import com.smartcleaner.app.R
import com.smartcleaner.app.data.SettingsRepository

/** Показывает напоминание и восстанавливает расписание после перезагрузки. */
class ReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val settings = SettingsRepository(context)
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> ReminderScheduler.schedule(context, settings.reminderDays)
            ReminderScheduler.ACTION_REMIND -> if (settings.reminderDays > 0) notify(context)
            com.smartcleaner.app.autoclean.AutoCleanNotifier.ACTION_CANCEL -> com.smartcleaner.app.autoclean.AutoCleaner.cancel()
        }
    }

    private fun notify(context: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        ReminderScheduler.ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Пора навести порядок")
            .setContentText("Проверьте память: мусор, дубликаты и старые файлы мессенджеров.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(2001, n)
        } catch (e: SecurityException) {
            // Разрешение отозвано — молча пропускаем.
        }
    }
}
