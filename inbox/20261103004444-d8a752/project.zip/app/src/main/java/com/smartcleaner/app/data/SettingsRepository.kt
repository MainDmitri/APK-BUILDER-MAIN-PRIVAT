package com.smartcleaner.app.data

import android.content.Context
import android.content.SharedPreferences

/** Все настройки приложения хранятся в SharedPreferences. Ключ API никогда не попадает в исходники. */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("smart_cleaner_settings", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString(KEY_API, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API, value.trim()).apply()

    var model: String
        get() = (prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL).ifBlank { DEFAULT_MODEL }
        set(value) = prefs.edit().putString(KEY_MODEL, value.trim().ifBlank { DEFAULT_MODEL }).apply()

    var aiEnabled: Boolean
        get() = prefs.getBoolean(KEY_AI_ENABLED, false)
        set(value) = prefs.edit().putBoolean(KEY_AI_ENABLED, value).apply()

    var aiSendImages: Boolean
        get() = prefs.getBoolean(KEY_AI_IMAGES, true)
        set(value) = prefs.edit().putBoolean(KEY_AI_IMAGES, value).apply()

    var aiConsent: Boolean
        get() = prefs.getBoolean(KEY_AI_CONSENT, false)
        set(value) = prefs.edit().putBoolean(KEY_AI_CONSENT, value).apply()

    /** Максимальное расстояние Хэмминга между dHash, при котором изображения считаются похожими. */
    var imageThreshold: Int
        get() = prefs.getInt(KEY_IMG_THRESHOLD, 6)
        set(value) = prefs.edit().putInt(KEY_IMG_THRESHOLD, value.coerceIn(0, 20)).apply()

    /** Минимальное сходство Жаккара (в процентах) для похожих текстов. */
    var textThresholdPercent: Int
        get() = prefs.getInt(KEY_TEXT_THRESHOLD, 80)
        set(value) = prefs.edit().putInt(KEY_TEXT_THRESHOLD, value.coerceIn(40, 99)).apply()

    var largeFileMb: Int
        get() = prefs.getInt(KEY_LARGE_MB, 100)
        set(value) = prefs.edit().putInt(KEY_LARGE_MB, value.coerceIn(1, 100_000)).apply()

    var oldFileDays: Int
        get() = prefs.getInt(KEY_OLD_DAYS, 180)
        set(value) = prefs.edit().putInt(KEY_OLD_DAYS, value.coerceIn(1, 10_000)).apply()

    var trashDays: Int
        get() = prefs.getInt(KEY_TRASH_DAYS, 30)
        set(value) = prefs.edit().putInt(KEY_TRASH_DAYS, value.coerceIn(1, 3650)).apply()

    /** Порог резкости (дисперсия Лапласиана): ниже — фото считается размытым. */
    var blurThreshold: Int
        get() = prefs.getInt(KEY_BLUR, 60)
        set(value) = prefs.edit().putInt(KEY_BLUR, value.coerceIn(5, 500)).apply()

    /** Возраст медиа из мессенджеров (дней), после которого оно предлагается к удалению. */
    var messengerDays: Int
        get() = prefs.getInt(KEY_MESSENGER_DAYS, 90)
        set(value) = prefs.edit().putInt(KEY_MESSENGER_DAYS, value.coerceIn(1, 10_000)).apply()

    /** Порог (МБ): приложения с кэшем больше него выбираются для автоочистки по умолчанию. */
    var autoCacheMinMb: Int
        get() = prefs.getInt("auto_cache_min_mb", 10)
        set(value) = prefs.edit().putInt("auto_cache_min_mb", value.coerceIn(0, 10_000)).apply()

    /** 0 — как в системе, 1 — светлая, 2 — тёмная. */
    var themeMode: Int
        get() = prefs.getInt(KEY_THEME, 0)
        set(value) = prefs.edit().putInt(KEY_THEME, value.coerceIn(0, 2)).apply()

    var dynamicColor: Boolean
        get() = prefs.getBoolean(KEY_DYNAMIC, false)
        set(value) = prefs.edit().putBoolean(KEY_DYNAMIC, value).apply()

    var onboardingDone: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING, value).apply()

    /** Интервал напоминания в днях, 0 — выключено. */
    var reminderDays: Int
        get() = prefs.getInt(KEY_REMINDER, 0)
        set(value) = prefs.edit().putInt(KEY_REMINDER, value.coerceIn(0, 60)).apply()

    /** URI, выданные через системный выбор папки (SAF) для Android/data и Android/obb. */
    var safTreeUris: Set<String>
        get() = prefs.getStringSet(KEY_SAF, emptySet())?.toSet() ?: emptySet()
        set(value) = prefs.edit().putStringSet(KEY_SAF, value).apply()

    /** Исключённые папки: по одной на строку, абсолютный путь или путь относительно корня памяти. */
    var excludedFolders: String
        get() = prefs.getString(KEY_EXCLUDED, "") ?: ""
        set(value) = prefs.edit().putString(KEY_EXCLUDED, value).apply()

    fun excludedList(storageRoot: String): List<String> =
        excludedFolders.lines()
            .map { it.trim().trimEnd('/') }
            .filter { it.isNotEmpty() }
            .map { if (it.startsWith("/")) it else "$storageRoot/$it" }

    fun saveSummary(s: LastScanSummary) {
        prefs.edit()
            .putLong("sum_time", s.time)
            .putInt("sum_files", s.filesScanned)
            .putInt("sum_junk_count", s.junkCount)
            .putLong("sum_junk_bytes", s.junkBytes)
            .putInt("sum_dup_groups", s.duplicateGroups)
            .putLong("sum_dup_bytes", s.duplicateBytes)
            .putInt("sum_sim_groups", s.similarGroups)
            .putLong("sum_sim_bytes", s.similarBytes)
            .putInt("sum_folders", s.foldersScanned)
            .putInt("sum_inaccessible", s.inaccessibleCount)
            .apply()
    }

    fun loadSummary(): LastScanSummary? {
        val time = prefs.getLong("sum_time", 0L)
        if (time == 0L) return null
        return LastScanSummary(
            time = time,
            filesScanned = prefs.getInt("sum_files", 0),
            junkCount = prefs.getInt("sum_junk_count", 0),
            junkBytes = prefs.getLong("sum_junk_bytes", 0L),
            duplicateGroups = prefs.getInt("sum_dup_groups", 0),
            duplicateBytes = prefs.getLong("sum_dup_bytes", 0L),
            similarGroups = prefs.getInt("sum_sim_groups", 0),
            similarBytes = prefs.getLong("sum_sim_bytes", 0L),
            foldersScanned = prefs.getInt("sum_folders", 0),
            inaccessibleCount = prefs.getInt("sum_inaccessible", 0)
        )
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
        private const val KEY_API = "gemini_api_key"
        private const val KEY_MODEL = "gemini_model"
        private const val KEY_AI_ENABLED = "ai_enabled"
        private const val KEY_AI_IMAGES = "ai_send_images"
        private const val KEY_AI_CONSENT = "ai_consent"
        private const val KEY_IMG_THRESHOLD = "img_threshold"
        private const val KEY_TEXT_THRESHOLD = "text_threshold"
        private const val KEY_LARGE_MB = "large_mb"
        private const val KEY_OLD_DAYS = "old_days"
        private const val KEY_TRASH_DAYS = "trash_days"
        private const val KEY_EXCLUDED = "excluded_folders"
        private const val KEY_BLUR = "blur_threshold"
        private const val KEY_MESSENGER_DAYS = "messenger_days"
        private const val KEY_THEME = "theme_mode"
        private const val KEY_DYNAMIC = "dynamic_color"
        private const val KEY_ONBOARDING = "onboarding_done"
        private const val KEY_REMINDER = "reminder_days"
        private const val KEY_SAF = "saf_tree_uris"
    }
}
