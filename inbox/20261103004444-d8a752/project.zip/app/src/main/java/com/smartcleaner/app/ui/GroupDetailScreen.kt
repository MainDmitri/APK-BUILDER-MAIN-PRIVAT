package com.smartcleaner.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.FileInfo
import com.smartcleaner.app.util.FileActions

@Composable
fun GroupDetailScreen(vm: MainViewModel, groupId: Long) {
    val g = vm.groupById(groupId)
    if (g == null) {
        Column(Modifier.fillMaxSize()) {
            GradientHeader("Группа", onBack = { vm.back() })
            EmptyState(Icons.Filled.CheckCircle, "Группа обработана", "Файлов в группе больше нет.")
        }
        return
    }
    val context = LocalContext.current
    var confirm by remember { mutableStateOf<MainViewModel.PendingDeletion?>(null) }
    var localExplain by remember { mutableStateOf(false) }
    val pending = vm.pendingForGroup(groupId)
    val isImages = g.files.all { FileCategory.of(it.extension) == FileCategory.IMAGES }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                GradientHeader(
                    title = g.type.title,
                    subtitle = "${g.files.size} файла · можно освободить ${formatSize(g.reclaimableBytes)}",
                    onBack = { vm.back() }
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { vm.setAllInGroup(groupId, true) }) { Text("Выбрать копии", color = Color.White) }
                        TextButton(onClick = { vm.setAllInGroup(groupId, false) }) { Text("Снять выбор", color = Color.White) }
                    }
                }
            }
            item { AiStatusBar(vm.aiStatus) }
            item {
                SectionCard(modifier = Modifier.padding(16.dp).animateContentSize()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconBubble(Icons.Filled.Info, Violet)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Почему это одна группа?", fontWeight = FontWeight.SemiBold)
                            if (g.similarityNote.isNotBlank()) Text(g.similarityNote, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    val explanation = g.aiExplanation.ifBlank { if (localExplain) vm.localExplanation(g) else "" }
                    AnimatedVisibility(explanation.isNotBlank(), enter = expandVertically() + fadeIn()) {
                        Text(explanation, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                        OutlinedButton(
                            onClick = { if (vm.aiAvailable) vm.aiExplainGroup(groupId) else localExplain = true },
                            enabled = !vm.aiBusy
                        ) { Text(if (vm.aiAvailable) "Спросить ИИ" else "Объяснить") }
                        OutlinedButton(onClick = { vm.aiChooseKeeper(groupId) }, enabled = !vm.aiBusy && vm.aiAvailable) {
                            Icon(Icons.Filled.Star, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("ИИ: лучший")
                        }
                    }
                    if (g.aiReason.isNotBlank()) {
                        Text(g.aiReason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            if (isImages) {
                item {
                    Text("Сетка снимков · нажмите, чтобы отметить", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(horizontal = 16.dp))
                }
                items(g.files.chunked(3)) { row ->
                    Row(Modifier.padding(horizontal = 13.dp)) {
                        for (f in row) {
                            val keeper = f.path == g.keeper.path
                            ImageTile(
                                file = f,
                                selected = f.path in g.selected,
                                onClick = { if (!keeper) vm.toggleGroupFile(groupId, f.path) },
                                badge = if (keeper) "ОСТАВИТЬ" else null,
                                badgeColor = Teal
                            )
                        }
                    }
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
            items(g.files, key = { it.path }) { f ->
                GroupFileCard(
                    vm = vm, g = g, f = f,
                    onOpen = { FileActions.open(context, f)?.let { vm.message = it } },
                    onShare = { FileActions.share(context, f)?.let { vm.message = it } }
                )
            }
        }
        DeleteBar(pending.count, pending.bytes, enabled = !vm.deleting) { confirm = pending }
    }
    confirm?.let { p ->
        ConfirmDialog("Удалить копии?", deletionText(p), "Удалить", onConfirm = { vm.delete(p) }, onDismiss = { confirm = null })
    }
}

@Composable
private fun GroupFileCard(vm: MainViewModel, g: FileGroup, f: FileInfo, onOpen: () -> Unit, onShare: () -> Unit) {
    val index = g.files.indexOf(f)
    val keeper = f.path == g.keeper.path
    val border by animateColorAsState(if (keeper) Teal else Color.Transparent, label = "border")
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        border = BorderStroke(2.dp, border),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        onClick = onOpen
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!keeper) {
                    Checkbox(checked = f.path in g.selected, onCheckedChange = { vm.toggleGroupFile(g.id, f.path) })
                } else {
                    Icon(Icons.Filled.CheckCircle, contentDescription = "Основной", tint = Teal, modifier = Modifier.padding(12.dp))
                }
                FileThumbnail(f, size = 64.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(f.parentPath, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "${formatSize(f.size)} · ${formatDate(f.lastModified)}" + if (f.width > 0) " · ${f.width}×${f.height}" else "",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (g.scores.size == g.files.size && index >= 0) {
                        Text("Оценка: ${g.scores[index]}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                IconButton(onClick = onShare) { Icon(Icons.Filled.Share, contentDescription = "Поделиться") }
            }
            if (keeper) {
                Text("Будет сохранён: " + g.keeperReasons.joinToString(", "), style = MaterialTheme.typography.bodySmall, color = Teal)
            } else {
                TextButton(onClick = { vm.setKeeper(g.id, index) }) { Text("Оставить этот файл") }
            }
        }
    }
}
