package com.smartcleaner.app.scan

import com.smartcleaner.app.data.FileCategory
import com.smartcleaner.app.data.FileInfo
import java.util.Locale

/** Анализ памяти по результатам сканирования: категории, папки, крупные файлы, подсказки. */
object StorageAnalyzer {

    data class CategoryStat(val category: FileCategory, val bytes: Long, val count: Int)

    data class FolderNode(val path: String, val name: String, val bytes: Long, val files: Int)

    class FolderIndex(
        val sizes: Map<String, Long>,
        val counts: Map<String, Int>,
        val subfolders: Map<String, List<String>>,
        val filesIn: Map<String, List<FileInfo>>,
        val roots: List<String>
    ) {
        fun children(path: String): List<FolderNode> =
            (subfolders[path] ?: emptyList()).map {
                FolderNode(it, it.substringAfterLast('/'), sizes[it] ?: 0L, counts[it] ?: 0)
            }.sortedByDescending { it.bytes }

        fun files(path: String): List<FileInfo> = (filesIn[path] ?: emptyList()).sortedByDescending { it.size }

        fun node(path: String): FolderNode = FolderNode(path, path.substringAfterLast('/'), sizes[path] ?: 0L, counts[path] ?: 0)
    }

    fun breakdown(files: List<FileInfo>): List<CategoryStat> {
        val bytes = LongArray(FileCategory.entries.size)
        val counts = IntArray(FileCategory.entries.size)
        for (f in files) {
            val c = FileCategory.of(f.extension).ordinal
            bytes[c] += f.size
            counts[c]++
        }
        return FileCategory.entries.map { CategoryStat(it, bytes[it.ordinal], counts[it.ordinal]) }
    }

    fun largestFiles(files: List<FileInfo>, limit: Int = 100): List<FileInfo> =
        files.sortedByDescending { it.size }.take(limit)

    /** Строит дерево папок с суммарными размерами от корней томов. */
    fun buildIndex(files: List<FileInfo>, volumeRoots: List<String>): FolderIndex {
        val sizes = HashMap<String, Long>()
        val counts = HashMap<String, Int>()
        val sub = HashMap<String, MutableSet<String>>()
        val filesIn = HashMap<String, MutableList<FileInfo>>()
        val roots = volumeRoots.map { it.trimEnd('/') }
        for (f in files) {
            val root = roots.firstOrNull { f.path.startsWith("$it/") } ?: continue
            val parent = f.parentPath
            filesIn.getOrPut(parent) { ArrayList() }.add(f)
            var dir = parent
            var child: String? = null
            while (true) {
                sizes[dir] = (sizes[dir] ?: 0L) + f.size
                counts[dir] = (counts[dir] ?: 0) + 1
                if (child != null) sub.getOrPut(dir) { HashSet() }.add(child)
                if (dir == root || dir.length <= root.length) break
                child = dir
                dir = dir.substringBeforeLast('/', root)
            }
        }
        return FolderIndex(sizes, counts, sub.mapValues { it.value.toList() }, filesIn, roots)
    }

    fun screenshots(files: List<FileInfo>): List<FileInfo> =
        files.filter {
            val p = it.path.lowercase(Locale.ROOT)
            (p.contains("/screenshots/") || p.contains("/screenshot/") || p.contains("/скриншоты/")) &&
                FileCategory.of(it.extension) == FileCategory.IMAGES
        }.sortedBy { it.lastModified }

    private val messengerMarkers = listOf(
        "/whatsapp/media/", "/android/media/com.whatsapp/", "/android/media/com.whatsapp.w4b/",
        "/telegram/", "/android/media/org.telegram.messenger/", "/viber/media/", "/android/media/com.viber.voip/"
    )

    fun messengerApp(path: String): String? {
        val p = path.lowercase(Locale.ROOT)
        return when {
            p.contains("whatsapp") -> "WhatsApp"
            p.contains("telegram") -> "Telegram"
            p.contains("viber") -> "Viber"
            else -> null
        }
    }

    fun oldMessengerMedia(files: List<FileInfo>, olderThanMs: Long, now: Long = System.currentTimeMillis()): List<FileInfo> =
        files.filter { f ->
            val p = f.path.lowercase(Locale.ROOT)
            messengerMarkers.any { p.contains(it) } &&
                now - f.lastModified >= olderThanMs &&
                f.name != ".nomedia" &&
                FileCategory.of(f.extension).let { it == FileCategory.IMAGES || it == FileCategory.VIDEO || it == FileCategory.AUDIO || it == FileCategory.DOCUMENTS }
        }.sortedByDescending { it.size }
}
