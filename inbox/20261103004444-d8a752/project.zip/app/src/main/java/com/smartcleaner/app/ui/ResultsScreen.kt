package com.smartcleaner.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.JunkCategory
import com.smartcleaner.app.data.JunkItem

@Composable
fun ResultsScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf<MainViewModel.PendingDeletion?>(null) }
    if (!vm.hasResults) {
        Column(Modifier.fillMaxSize()) {
            GradientHeader(title = "Результаты", subtitle = "Здесь появятся находки сканирования")
            EmptyState(
                Icons.Filled.Search, "Пока пусто", "Запустите сканирование на главной — найдём мусор, дубликаты и похожие файлы.",
                action = { GradientButton("Сканировать", onClick = { vm.startScan() }, modifier = Modifier.fillMaxWidth()) }
            )
        }
        return
    }
    val tab = vm.selectedTab
    val pending = vm.pendingFor(tab)
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                GradientHeader(
                    title = "Результаты",
                    subtitle = vm.summary?.let { "Файлов ${it.filesScanned} · папок ${it.foldersScanned} · ${formatDate(it.time)}" }
                ) {
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        for (t in ResultTab.entries) {
                            val bytes = when (t) {
                                ResultTab.JUNK -> vm.junk.distinctBy { it.file.path }.sumOf { it.file.size }
                                ResultTab.DUPLICATES -> vm.groupsFor(t).sumOf { it.reclaimableBytes }
                                ResultTab.SIMILAR -> vm.groupsFor(t).sumOf { it.reclaimableBytes }
                            }
                            val selected = t == tab
                            Column(
                                Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (selected) Color.White else Color.White.copy(alpha = 0.16f))
                                    .clickable { vm.selectedTab = t }
                                    .padding(vertical = 10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(t.title, color = if (selected) MaterialTheme.colorScheme.primary else Color.White, fontWeight = FontWeight.Bold)
                                Text(formatSize(bytes), color = if (selected) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
            item { AiStatusBar(vm.aiStatus) }
            item { ScanOverviewCard(vm) }
            item { AiSummaryCard(vm) }
            item {
                Crossfade(targetState = tab, label = "tab") { t ->
                    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        when (t) {
                            ResultTab.JUNK -> JunkSection(vm)
                            else -> GroupsSection(vm, t)
                        }
                    }
                }
            }
        }
        DeleteBar(pending.count, pending.bytes, enabled = !vm.deleting) { confirm = pending }
    }
    confirm?.let { p ->
        ConfirmDialog(
            title = "Удалить выбранное?",
            text = deletionText(p),
            confirmText = "Удалить",
            onConfirm = { vm.delete(p) },
            onDismiss = { confirm = null }
        )
    }
}

@Composable
private fun ScanOverviewCard(vm: MainViewModel) {
    val s = vm.summary ?: return
    SectionCard(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        onClick = if (vm.inaccessible.isNotEmpty()) ({ vm.navigate(Screen.Inaccessible) }) else null
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(if (s.inaccessibleCount > 0) Icons.Filled.Warning else Icons.Filled.CheckCircle, if (s.inaccessibleCount > 0) Amber else Teal)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Просканировано папок: ${s.foldersScanned}", fontWeight = FontWeight.SemiBold)
                Text(
                    "Томов: ${vm.scannedVolumes.size} (${vm.scannedVolumes.joinToString { it.title }}) · без доступа: ${s.inaccessibleCount}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (vm.inaccessible.isNotEmpty()) Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Подробнее")
        }
    }
}

@Composable
private fun AiSummaryCard(vm: MainViewModel) {
    SectionCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp).animateContentSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Filled.Star, Violet)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Итог и рекомендации", fontWeight = FontWeight.SemiBold)
                Text(
                    if (vm.aiAvailable) "ИИ Gemini проанализирует статистику (без имён файлов)" else "Локальные советы · ИИ можно включить в Настройках",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        val summary = vm.aiSummary
        AnimatedVisibility(summary != null, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            if (summary != null) {
                Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    vm.aiSummaryError?.let {
                        Text("ИИ недоступен ($it) — показаны локальные советы", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    Text(summary.summary, style = MaterialTheme.typography.bodyMedium)
                    for (tip in summary.tips) {
                        Row {
                            Text("•  ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(tip, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
            if (!vm.aiAvailable) {
                TextButton(onClick = { vm.showLocalSummary() }) { Text("Показать советы") }
            } else {
                TextButton(onClick = { vm.aiSummarize() }, enabled = !vm.aiBusy) { Text(if (summary == null) "Спросить ИИ" else "Обновить") }
            }
        }
    }
}

@Composable
private fun JunkSection(vm: MainViewModel) {
    if (vm.junk.isEmpty()) {
        EmptyState(Icons.Filled.CheckCircle, "Мусора нет", "Отличная работа — память чистая.")
        return
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Найденный мусор", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        TextButton(onClick = { vm.aiClassifyJunk() }, enabled = !vm.aiBusy) { Text("ИИ: проверить") }
    }
    val expanded = remember { mutableStateMapOf<JunkCategory, Boolean>() }
    for (cat in JunkCategory.entries) {
        val items = vm.junk.filter { it.category == cat }
        if (items.isEmpty()) continue
        val isOpen = expanded[cat] ?: false
        val selectedCount = items.count { vm.junkSelected[vm.keyOf(it)] == true }
        val arrow by animateFloatAsState(if (isOpen) 180f else 0f, label = "arrow")
        SectionCard(modifier = Modifier.animateContentSize()) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { expanded[cat] = !isOpen }) {
                Checkbox(
                    checked = selectedCount == items.size,
                    onCheckedChange = { vm.setCategorySelected(cat, it) }
                )
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(cat.title, fontWeight = FontWeight.SemiBold)
                        if (cat.safe) {
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "безопасно", color = Teal, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(Teal.copy(alpha = 0.15f)).padding(horizontal = 6.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        "${items.size} шт. · ${formatSize(items.sumOf { it.file.size })} · выбрано $selectedCount",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = if (isOpen) "Свернуть" else "Развернуть", modifier = Modifier.rotate(arrow))
            }
            Text(cat.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            AnimatedVisibility(isOpen) {
                Column {
                    for (item in items.take(300)) JunkRow(vm, item)
                    if (items.size > 300) Text("…и ещё ${items.size - 300}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun JunkRow(vm: MainViewModel, item: JunkItem) {
    val checked = vm.junkSelected[vm.keyOf(item)] == true
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable { vm.toggleJunk(item) }.padding(vertical = 6.dp)
    ) {
        Checkbox(checked = checked, onCheckedChange = { vm.toggleJunk(item) })
        FileThumbnail(item.file, size = 44.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(item.file.name.ifBlank { item.file.path }, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
            Text(item.file.parentPath, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (item.note.isNotBlank()) Text(item.note, style = MaterialTheme.typography.bodySmall)
            if (item.aiJunk != null) {
                Text(
                    (if (item.aiJunk) "ИИ: мусор — " else "ИИ: сохранить — ") + item.aiReason,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.aiJunk) MaterialTheme.colorScheme.error else Teal
                )
            }
            if (item.file.isSaf) Text("Удалится сразу (системный доступ)", style = MaterialTheme.typography.bodySmall, color = Amber)
        }
        Text(formatSize(item.file.size), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GroupsSection(vm: MainViewModel, tab: ResultTab) {
    val list = vm.groupsFor(tab)
    if (list.isEmpty()) {
        EmptyState(
            Icons.Filled.CheckCircle,
            if (tab == ResultTab.DUPLICATES) "Дубликатов нет" else "Похожих файлов нет",
            "Ничего не нужно удалять."
        )
        return
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Групп: ${list.size}", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
        if (tab == ResultTab.SIMILAR) {
            TextButton(onClick = { vm.aiChooseAllSimilar() }, enabled = !vm.aiBusy) { Text("ИИ: выбрать лучшие") }
        }
    }
    for (g in list.take(400)) GroupCard(vm, g)
    if (list.size > 400) Text("…и ещё ${list.size - 400} групп", style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun GroupCard(vm: MainViewModel, g: FileGroup) {
    SectionCard(onClick = { vm.navigate(Screen.GroupDetail(g.id)) }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(g.type.title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
            if (g.aiChosen) {
                AssistChip(onClick = {}, label = { Text("ИИ", fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Filled.Star, null, Modifier.size(14.dp)) })
            }
            Text("−${formatSize(g.selectedBytes)}", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (f in g.files.take(4)) {
                Box {
                    FileThumbnail(f, size = 62.dp)
                    if (f.path == g.keeper.path) {
                        Box(
                            Modifier.align(Alignment.TopStart).padding(3.dp).size(18.dp).clip(RoundedCornerShape(9.dp)).background(Teal),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.CheckCircle, contentDescription = "Оставить", tint = Color.White, modifier = Modifier.size(14.dp)) }
                    } else if (f.path in g.selected) {
                        Box(
                            Modifier.align(Alignment.TopStart).padding(3.dp).size(18.dp).clip(RoundedCornerShape(9.dp)).background(MaterialTheme.colorScheme.error),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Delete, contentDescription = "Удалить", tint = Color.White, modifier = Modifier.size(12.dp)) }
                    }
                }
            }
            if (g.files.size > 4) {
                Box(
                    Modifier.size(62.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) { Text("+${g.files.size - 4}", fontWeight = FontWeight.Bold) }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = Teal, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(4.dp))
            Text(
                "Оставить: ${g.keeper.name}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f)
            )
            Text("${g.files.size} файла", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (g.similarityNote.isNotBlank()) {
            Text(g.similarityNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
