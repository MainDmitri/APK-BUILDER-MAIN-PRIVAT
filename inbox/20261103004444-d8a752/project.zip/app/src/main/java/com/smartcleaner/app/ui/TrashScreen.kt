package com.smartcleaner.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smartcleaner.app.data.TrashEntry

@Composable
fun TrashScreen(vm: MainViewModel) {
    LaunchedEffect(Unit) { vm.refreshTrash() }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf<TrashEntry?>(null) }
    Column(Modifier.fillMaxSize()) {
        GradientHeader("Корзина", subtitle = "Хранится ${vm.trashDays} дн., затем удаляется", actions = {
            if (vm.trashEntries.isNotEmpty()) TextButton(onClick = { confirmEmpty = true }) { Text("Очистить", color = Color.White) }
        }) {
            Text(formatSize(vm.trashSize), color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("${vm.trashEntries.size} элементов · смахните вправо — восстановить, влево — удалить", color = Color.White.copy(alpha = 0.85f))
        }
        LazyColumn(contentPadding = PaddingValues(12.dp)) {
            if (vm.trashEntries.isEmpty()) item { EmptyState(Icons.Filled.Delete, "Корзина пуста", "Удалённые файлы появятся здесь, их можно восстановить") }
            items(vm.trashEntries, key = { it.id }) { e ->
                TrashRow(e, onRestore = { vm.restore(e) }, onDelete = { confirmDelete = e })
            }
        }
    }
    if (confirmEmpty) {
        ConfirmDialog("Очистить корзину?", "Все ${vm.trashEntries.size} элементов (${formatSize(vm.trashSize)}) будут удалены навсегда.", "Удалить навсегда",
            { confirmEmpty = false; vm.emptyTrash() }, { confirmEmpty = false })
    }
    confirmDelete?.let { e ->
        ConfirmDialog("Удалить навсегда?", "${e.name} (${formatSize(e.size)}) нельзя будет восстановить.", "Удалить",
            { confirmDelete = null; vm.deleteForever(e) }, { confirmDelete = null })
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrashRow(e: TrashEntry, onRestore: () -> Unit, onDelete: () -> Unit) {
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        when (v) {
            SwipeToDismissBoxValue.StartToEnd -> { onRestore(); true }
            SwipeToDismissBoxValue.EndToStart -> { onDelete(); false } // удаление только после подтверждения
            else -> false
        }
    })
    SwipeToDismissBox(
        state = state,
        modifier = Modifier.padding(vertical = 4.dp),
        backgroundContent = {
            val dir = state.dismissDirection
            val color by animateColorAsState(
                when (dir) {
                    SwipeToDismissBoxValue.StartToEnd -> Teal
                    SwipeToDismissBoxValue.EndToStart -> MaterialTheme.colorScheme.error
                    else -> Color.Transparent
                }, label = "swipe"
            )
            Box(
                Modifier.fillMaxSize().clip(RoundedCornerShape(20.dp)).background(color).padding(horizontal = 20.dp),
                contentAlignment = if (dir == SwipeToDismissBoxValue.StartToEnd) Alignment.CenterStart else Alignment.CenterEnd
            ) {
                if (dir == SwipeToDismissBoxValue.StartToEnd) Icon(Icons.Filled.Refresh, contentDescription = "Восстановить", tint = Color.White)
                else if (dir == SwipeToDismissBoxValue.EndToStart) Icon(Icons.Filled.Delete, contentDescription = "Удалить", tint = Color.White)
            }
        }
    ) {
        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBubble(Icons.Filled.Delete, Coral)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${formatSize(e.size)} · удалён ${formatDate(e.deletedAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    Text(e.originalPath.substringBeforeLast('/').takeLast(56), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                    androidx.compose.material3.IconButton(onClick = onRestore) { Icon(Icons.Filled.Refresh, contentDescription = "Восстановить") }
                    androidx.compose.material3.IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = "Удалить навсегда") }
                }
            }
        }
    }
}
