package com.smartcleaner.app.ui

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.smartcleaner.app.autoclean.AutoCleanOutcome
import com.smartcleaner.app.autoclean.AutoCleaner
import com.smartcleaner.app.data.AppCacheInfo
import com.smartcleaner.app.scan.AppCacheStats

/**
 * Кэш приложений. Главный путь на Android 13–16: Android/data закрыт, поэтому размеры кэша берутся
 * из StorageStatsManager (нужен «Доступ к истории использования»), а очистка — в системной карточке приложения.
 */
@Composable
fun AppCachesScreen(vm: MainViewModel) {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var showSystem by remember { mutableStateOf(false) }
    LaunchedEffect(vm.usageAccess) { if (vm.usageAccess && vm.appCaches.isEmpty()) vm.loadAppCaches() }

    val filtered = vm.appCaches.filter {
        (showSystem || !it.isSystem) &&
            (query.isBlank() || it.label.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true))
    }
    val total = filtered.sumOf { it.cacheBytes }
    val max = filtered.maxOfOrNull { it.cacheBytes } ?: 1L

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            GradientHeader(
                title = "Кэш приложений",
                subtitle = if (Build.VERSION.SDK_INT >= 33) "Android ${Build.VERSION.RELEASE}: Android/data закрыт системой — очищаем через настройки" else "Размер кэша каждого приложения",
                onBack = { vm.back() },
                actions = {
                    if (vm.usageAccess) {
                        IconButton(onClick = { vm.loadAppCaches(force = true) }, enabled = !vm.appCacheLoading) {
                            Icon(Icons.Filled.Refresh, contentDescription = "Обновить", tint = Color.White)
                        }
                    }
                }
            ) {
                if (vm.usageAccess) {
                    val animatedTotal by animateFloatAsState(total.toFloat(), tween(900), label = "total")
                    Text(formatSize(animatedTotal.toLong()), color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                    Text("кэша в ${filtered.size} приложениях", color = Color.White.copy(alpha = 0.85f))
                }
            }
        }
        if (!AppCacheStats.supported()) {
            item { EmptyState(Icons.Filled.Lock, "Недоступно", "Статистика кэша приложений появилась в Android 8.") }
            return@LazyColumn
        }
        if (!vm.usageAccess) {
            item { UsageAccessCard(onGrant = { openSafely(context, AppCacheStats.usageAccessIntent(context)) { vm.message = it } }) }
            return@LazyColumn
        }
        item { AutoCleanCard(vm, filtered) }
        item {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    placeholder = { Text("Поиск приложения") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    FilterChip(selected = !showSystem, onClick = { showSystem = false }, label = { Text("Установленные") })
                    FilterChip(selected = showSystem, onClick = { showSystem = true }, label = { Text("Все, вкл. системные") })
                }
                Text(
                    "Ручной режим: «Вручную» — откроется карточка приложения. Там выберите «Хранилище и кэш» → «Очистить кэш». " +
                        "Данные и аккаунты приложения не пострадают.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
        if (vm.appCacheLoading && vm.appCaches.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(10.dp))
                        Text("Считаем кэш приложений…")
                    }
                }
            }
        } else if (filtered.isEmpty()) {
            item { EmptyState(Icons.Filled.Build, "Кэша нет", "Приложения с кэшем не найдены.") }
        }
        items(filtered, key = { it.packageName }) { app ->
            AppCacheRow(
                app, max,
                checked = vm.autoSelection[app.packageName] == true,
                selectable = app.packageName != context.packageName,
                onToggle = { vm.toggleAutoApp(app.packageName) }
            ) { openSafely(context, AppCacheStats.appSettingsIntent(app.packageName)) { vm.message = it } }
        }
    }
}

internal fun openSafely(context: android.content.Context, intent: android.content.Intent, onError: (String) -> Unit) {
    try {
        context.startActivity(intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        onError("Не удалось открыть настройки: ${e.message ?: "ошибка"}")
    }
}

@Composable
private fun UsageAccessCard(onGrant: () -> Unit) {
    SectionCard(modifier = Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Filled.Lock, Violet)
            Spacer(Modifier.width(12.dp))
            Text("Нужен доступ к статистике", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(10.dp))
        val steps = listOf(
            "Нажмите кнопку ниже — откроются системные настройки «Доступ к истории использования».",
            "Найдите «Умный Cleaner» и включите переключатель «Разрешить отслеживание».",
            "Вернитесь назад — список приложений с размером кэша появится автоматически."
        )
        steps.forEachIndexed { i, s ->
            Row(Modifier.padding(vertical = 4.dp)) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(LocalGradients.current.hero), contentAlignment = Alignment.Center) {
                    Text("${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp))
                Text(s, style = MaterialTheme.typography.bodyMedium)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Приложение читает только размеры (приложение, данные, кэш). История использования никуда не отправляется.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        GradientButton("Открыть настройки доступа", onClick = onGrant, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun AppCacheRow(
    app: AppCacheInfo,
    max: Long,
    checked: Boolean,
    selectable: Boolean,
    onToggle: () -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    val icon: Drawable? = remember(app.packageName) {
        try {
            context.packageManager.getApplicationIcon(app.packageName)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
    }
    val fraction by animateFloatAsState((app.cacheBytes.toFloat() / max.coerceAtLeast(1)).coerceIn(0f, 1f), tween(700), label = "bar")
    SectionCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (selectable) Checkbox(checked = checked, onCheckedChange = { onToggle() })
            Crossfade(icon != null, label = "icon") { has ->
                if (has) {
                    AsyncImage(model = icon, contentDescription = null, contentScale = ContentScale.Fit, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)))
                } else {
                    IconBubble(Icons.Filled.Build, MaterialTheme.colorScheme.primary)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(app.label, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "Кэш ${formatSize(app.cacheBytes)} · данные ${formatSize(app.dataBytes)} · приложение ${formatSize(app.appBytes)}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2
                )
            }
            FilledTonalButton(onClick = onClear, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Вручную") }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(Modifier.fillMaxWidth(fraction).height(6.dp).clip(RoundedCornerShape(3.dp)).background(LocalGradients.current.accent))
        }
    }
}

/** Автоочистка кэша: онбординг разрешения, выбор, прогресс и итоговый отчёт. */
@Composable
private fun AutoCleanCard(vm: MainViewModel, visible: List<AppCacheInfo>) {
    val context = LocalContext.current
    val st = vm.autoState
    SectionCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBubble(Icons.Filled.Build, Teal)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Автоочистка кэша", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Приложение само откроет настройки каждого выбранного приложения и нажмёт «Очистить кэш»",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        when {
            st.running -> {
                Text("Очищаю ${st.index} из ${st.total}: ${st.currentLabel}", fontWeight = FontWeight.SemiBold)
                Text(st.step, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { if (st.total > 0) st.index.toFloat() / st.total else 0f },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                )
                Text(
                    "Отмена: кнопка в уведомлении или «Громкость вниз».",
                    style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
                )
                OutlinedButton(onClick = { vm.cancelAutoClean() }, modifier = Modifier.padding(top = 6.dp)) { Text("Отменить") }
            }
            st.finished -> {
                Text(
                    "Готово: очищено ${st.clearedCount} из ${st.total} · освобождено ${formatSize(st.freedBytes)}",
                    fontWeight = FontWeight.Bold, color = Teal
                )
                Spacer(Modifier.height(6.dp))
                for (r in st.results) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                        Text(r.label, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                        Text(
                            r.outcome.title + if (r.freed > 0) " · −${formatSize(r.freed)}" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = when (r.outcome) {
                                AutoCleanOutcome.CLEARED, AutoCleanOutcome.ALREADY_EMPTY -> Teal
                                AutoCleanOutcome.CANCELLED -> MaterialTheme.colorScheme.onSurfaceVariant
                                else -> MaterialTheme.colorScheme.error
                            }
                        )
                    }
                }
                if (st.results.any { it.outcome == AutoCleanOutcome.NOT_FOUND || it.outcome == AutoCleanOutcome.TIMEOUT || it.outcome == AutoCleanOutcome.SKIPPED }) {
                    Text(
                        "Для пропущенных приложений используйте кнопку «Вручную» — оболочка телефона могла назвать пункты иначе.",
                        style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
                    )
                }
                TextButton(onClick = { vm.dismissAutoReport() }) { Text("Закрыть отчёт") }
            }
            !vm.accessibilityEnabled -> AccessibilityOnboarding(
                onOpenAccessibility = { openSafely(context, AutoCleaner.accessibilitySettingsIntent()) { vm.message = it } },
                onOpenOwnDetails = { openSafely(context, AutoCleaner.ownDetailsIntent(context)) { vm.message = it } }
            )
            else -> {
                Text("Выбирать по умолчанию приложения с кэшем больше:", style = MaterialTheme.typography.bodySmall)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                    for (mb in listOf(1, 10, 50, 100)) {
                        FilterChip(selected = vm.autoCacheMinMb == mb, onClick = { vm.updateAutoCacheMin(mb) }, label = { Text("$mb МБ") })
                    }
                }
                val selected = vm.autoSelectedApps()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Выбрано: ${selected.size} · ~${formatSize(selected.sumOf { it.cacheBytes })}",
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = { vm.setAllAuto(true, visible) }) { Text("Все") }
                    TextButton(onClick = { vm.setAllAuto(false, visible) }) { Text("Никого") }
                }
                GradientButton(
                    text = "Очистить кэш автоматически",
                    onClick = { vm.startAutoClean() },
                    enabled = selected.isNotEmpty(),
                    brush = LocalGradients.current.success,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Нажимается только «Хранилище и кэш» и «Очистить кэш». «Очистить данные» служба не нажимает никогда. " +
                        "Не трогайте экран, пока идёт очистка (~3–5 с на приложение).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun AccessibilityOnboarding(onOpenAccessibility: () -> Unit, onOpenOwnDetails: () -> Unit) {
    Text(
        "Android не позволяет приложениям очищать чужой кэш напрямую. Поэтому используется служба спец. возможностей: " +
            "она нажимает за вас две кнопки в системных настройках и больше ничего не делает.",
        style = MaterialTheme.typography.bodyMedium
    )
    Spacer(Modifier.height(8.dp))
    val steps = listOf(
        "Нажмите «Открыть спец. возможности» → «Установленные приложения» (или «Скачанные службы») → «Умный Cleaner — автоочистка кэша» → включите.",
        "Если переключатель серый и написано «Ограниченная настройка» (Android 13+ для приложений не из магазина): нажмите «Сведения о приложении» ниже → меню ⋮ в правом верхнем углу → «Разрешить ограниченные настройки» → подтвердите.",
        "Вернитесь к шагу 1 и включите службу. Затем вернитесь сюда."
    )
    steps.forEachIndexed { i, s ->
        Row(Modifier.padding(vertical = 4.dp)) {
            Box(Modifier.size(24.dp).clip(CircleShape).background(LocalGradients.current.hero), contentAlignment = Alignment.Center) {
                Text("${i + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text(s, style = MaterialTheme.typography.bodySmall)
        }
    }
    Spacer(Modifier.height(8.dp))
    GradientButton("Открыть спец. возможности", onClick = onOpenAccessibility, modifier = Modifier.fillMaxWidth())
    OutlinedButton(onClick = onOpenOwnDetails, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text("Сведения о приложении (ограниченные настройки)")
    }
}
