package com.smartcleaner.app.scan

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.provider.DocumentsContract
import com.smartcleaner.app.data.FileGroup
import com.smartcleaner.app.data.InaccessibleFolder
import com.smartcleaner.app.data.VolumeInfo
import com.smartcleaner.app.data.FileInfo
import com.smartcleaner.app.data.GroupType
import com.smartcleaner.app.data.JunkCategory
import com.smartcleaner.app.data.JunkItem
import com.smartcleaner.app.data.ScanProgress
import com.smartcleaner.app.data.ScanResult
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import java.io.File
import java.util.Locale
import kotlin.math.abs

data class ScanConfig(
    val volumes: List<VolumeInfo>,
    val primaryRoot: String,
    val safTrees: List<Uri>,
    val excluded: List<String>,
    val trashDir: File?,
    val largeFileBytes: Long,
    val oldFileMs: Long,
    val imageThreshold: Int,
    val textThreshold: Double
)

/** Многоэтапный сканер всех томов памяти. Все этапы проверяют отмену корутины. */
class Scanner(private val context: Context, private val config: ScanConfig) {

    private var groupId = 1L
    private var lastProgressAt = 0L
    private val ownPackage = context.packageName

    private val skipPrefixes: List<String> = buildList {
        config.trashDir?.let { add(it.absolutePath.trimEnd('/')) }
        addAll(config.excluded)
    }

    private val standardRootFolders = setOf(
        "dcim", "download", "downloads", "pictures", "music", "movies", "documents", "alarms",
        "ringtones", "notifications", "podcasts", "audiobooks", "recordings", "android"
    )

    private fun shouldSkip(path: String): Boolean =
        skipPrefixes.any { path == it || path.startsWith("$it/") }

    private fun report(onProgress: (ScanProgress) -> Unit, p: ScanProgress, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (force || now - lastProgressAt > 100) {
            lastProgressAt = now
            onProgress(p)
        }
    }

    // Счётчики живого прогресса.
    private val files = ArrayList<FileInfo>()
    private val junk = ArrayList<JunkItem>()
    private val junkPaths = HashSet<String>()
    private var junkBytes = 0L
    private var folders = 0
    private val inaccessible = ArrayList<InaccessibleFolder>()
    private var inaccessibleTotal = 0
    private val now = System.currentTimeMillis()

    private fun addInaccessible(path: String, reason: String) {
        inaccessibleTotal++
        if (inaccessible.size < 300) inaccessible.add(InaccessibleFolder(path, reason))
    }

    private fun addJunk(item: JunkItem) {
        junk.add(item)
        if (item.category != JunkCategory.LARGE_OLD) {
            junkPaths.add(item.file.path)
        }
        junkBytes += item.file.size
    }

    /** Классификация файла как мусора — выполняется прямо при обходе, чтобы счётчик рос «вживую». */
    private fun classify(f: FileInfo, pm: PackageManager) {
        val lowerPath = f.path.lowercase(Locale.ROOT)
        val lowerName = f.name.lowercase(Locale.ROOT)
        val ext = f.extension
        when {
            isAppCache(lowerPath) -> addJunk(JunkItem(f, JunkCategory.APP_CACHE, note = "Кэш: ${appPackageOf(f.path)}"))
            lowerPath.contains("/.thumbnails/") -> addJunk(JunkItem(f, JunkCategory.THUMBNAILS, note = "Кэш миниатюр галереи"))
            f.size == 0L && lowerName != ".nomedia" && !lowerPath.contains("/android/") ->
                addJunk(JunkItem(f, JunkCategory.EMPTY_FILE, note = "0 байт"))
            isTempFile(lowerName, ext) -> addJunk(JunkItem(f, JunkCategory.TEMP, note = tempNote(lowerName, ext)))
            ext == "apk" && (lowerPath.contains("/download/") || lowerPath.contains("/downloads/")) && !f.isSaf ->
                addJunk(apkItem(pm, f))
        }
        if (f.size >= config.largeFileBytes && now - f.lastModified >= config.oldFileMs && f.path !in junkPaths &&
            !lowerPath.contains("/android/data/") && !lowerPath.contains("/android/obb/")
        ) {
            val days = (now - f.lastModified) / 86_400_000L
            addJunk(JunkItem(f, JunkCategory.LARGE_OLD, note = "Не изменялся $days дн. — проверьте вручную", defaultSelected = false))
        }
    }

    private fun isAppCache(lowerPath: String): Boolean {
        val idx = lowerPath.indexOf("/android/data/")
        if (idx < 0) return false
        val rest = lowerPath.substring(idx + "/android/data/".length)
        val pkg = rest.substringBefore('/')
        if (pkg.isEmpty() || pkg == ownPackage) return false
        val after = rest.substringAfter('/', "")
        return after.startsWith("cache/") || after.startsWith("files/cache/") || after.startsWith("code_cache/")
    }

    private fun appPackageOf(path: String): String =
        path.substringAfter("/Android/data/", "").substringBefore('/').ifEmpty { "приложение" }

    private fun isRestrictedAppDir(path: String): Boolean {
        for (v in config.volumes) {
            if (path == "${v.path}/Android/data" || path == "${v.path}/Android/obb") return true
        }
        return false
    }

    private fun restrictedReason(): String = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU ->
            "Android 13+ закрывает папку для сторонних приложений"
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.R ->
            "Android 11–12: нужен системный доступ к папке (кнопка на главном экране)"
        else -> "Нет доступа"
    }

    suspend fun scan(onProgress: (ScanProgress) -> Unit): ScanResult {
        val pm = context.packageManager
        val visited = HashSet<String>()
        val safCovered = config.safTrees.map {
            StorageAccess.docIdToPath(DocumentsContractCompat.treeId(it), config.primaryRoot)
        }.toSet()

        // ---------- 1. Обход всех томов (вместе с классификацией мусора) ----------
        for (volume in config.volumes) {
            val stack = ArrayDeque<File>()
            stack.addLast(File(volume.path))
            while (stack.isNotEmpty()) {
                currentCoroutineContext().ensureActive()
                val dir = stack.removeLast()
                val dirPath = dir.absolutePath.trimEnd('/')
                if (shouldSkip(dirPath)) continue
                if (dirPath in safCovered) continue // эту папку обойдём через SAF
                // Защита от петель символических ссылок.
                val canonical = try {
                    dir.canonicalPath
                } catch (e: Exception) {
                    dirPath
                }
                if (!visited.add(canonical)) continue
                if (canonical != dirPath && shouldSkip(canonical)) continue
                val children = try {
                    dir.listFiles()
                } catch (e: SecurityException) {
                    null
                }
                folders++
                val restricted = isRestrictedAppDir(dirPath)
                if (children == null) {
                    addInaccessible(dirPath, if (restricted) restrictedReason() else "Система не разрешает чтение")
                    continue
                }
                if (restricted && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
                    children.all { it.name == ownPackage }
                ) {
                    // Видна только своя папка — значит, система скрывает содержимое.
                    addInaccessible(dirPath, restrictedReason())
                }
                if (children.isEmpty() && dirPath != volume.path && isRemovableEmptyDir(dirPath, volume.path)) {
                    addJunk(
                        JunkItem(
                            FileInfo(dirPath, dir.name, 0L, dir.lastModified()),
                            JunkCategory.EMPTY_FOLDER, isDirectory = true, note = "Пустая папка"
                        )
                    )
                }
                for (c in children) {
                    if (c.isDirectory) {
                        stack.addLast(c)
                    } else if (c.isFile) {
                        val f = FileInfo(c.absolutePath, c.name, c.length(), c.lastModified())
                        files.add(f)
                        classify(f, pm)
                    }
                }
                report(
                    onProgress,
                    ScanProgress("Поиск файлов", files.size, folders, junk.size, junkBytes, volume.title, dirPath, -1f)
                )
            }
        }

        // ---------- 1b. Android/data и obb через системный доступ (Android 11–12) ----------
        for (tree in config.safTrees) {
            currentCoroutineContext().ensureActive()
            val label = "Android/" + StorageAccess.treeLabel(tree).substringAfter("Android/")
            val ctx = currentCoroutineContext()
            try {
                StorageAccess.walkTree(context, tree, config.primaryRoot, { !ctx.isActive }) { e ->
                    if (e.isDirectory) {
                        // Пустые папки внутри Android/ не трогаем: приложения могут ожидать их наличия.
                        folders++
                    } else {
                        val f = FileInfo(e.path, e.name, e.size, e.lastModified, uri = e.uri)
                        files.add(f)
                        classify(f, pm)
                    }
                    report(
                        onProgress,
                        ScanProgress("Системные папки приложений", files.size, folders, junk.size, junkBytes, label, e.path, -1f)
                    )
                }
            } catch (e: Exception) {
                addInaccessible(label, "Разрешение отозвано: ${e.message ?: "ошибка"}")
            }
        }
        currentCoroutineContext().ensureActive()
        report(onProgress, ScanProgress("Анализ дубликатов", files.size, folders, junk.size, junkBytes, "", "", 0f), force = true)

        // ---------- 3. Точные дубликаты ----------
        val groups = ArrayList<FileGroup>()
        val candidates = files.filter {
            it.size > 0 && !it.isSaf && it.path !in junkPaths && it.name != ".nomedia" &&
                !it.path.contains("/Android/data/") && !it.path.contains("/Android/obb/")
        }
        val bySize = candidates.groupBy { it.size }.filterValues { it.size > 1 }
        val toHash = bySize.values.sumOf { it.size }.coerceAtLeast(1)
        var hashed = 0
        val nonKeeperExact = HashSet<String>()
        for ((_, sameSize) in bySize) {
            currentCoroutineContext().ensureActive()
            val byPartial = HashMap<String, MutableList<FileInfo>>()
            for (f in sameSize) {
                hashed++
                report(onProgress, ScanProgress("Поиск точных дубликатов", files.size, folders, junk.size, junkBytes, "", f.path, hashed.toFloat() / toHash))
                val h = Hashing.partialHash(File(f.path)) ?: continue
                byPartial.getOrPut(h) { ArrayList() }.add(f)
            }
            for ((_, samePartial) in byPartial) {
                if (samePartial.size < 2) continue
                val byFull = HashMap<String, MutableList<FileInfo>>()
                for (f in samePartial) {
                    val ctx = currentCoroutineContext()
                    val h = Hashing.fullHash(File(f.path)) { !ctx.isActive } ?: continue
                    byFull.getOrPut(h) { ArrayList() }.add(f)
                }
                currentCoroutineContext().ensureActive()
                for ((_, same) in byFull) {
                    if (same.size < 2) continue
                    val g = buildGroup(GroupType.EXACT, same, "Содержимое совпадает побайтно (SHA-256)")
                    groups.add(g)
                    same.forEach { if (it.path != g.keeper.path) nonKeeperExact.add(it.path) }
                }
            }
        }

        val pool = candidates.filter { it.path !in nonKeeperExact }

        // ---------- 4. Похожие изображения ----------
        val images = pool.filter { it.extension in IMAGE_EXT && it.size >= 8 * 1024 }
            .sortedByDescending { it.lastModified }
            .take(MAX_IMAGES)
        val imgInfos = ArrayList<FileInfo>()
        val imgHashes = ArrayList<Long>()
        for ((i, f) in images.withIndex()) {
            currentCoroutineContext().ensureActive()
            report(onProgress, ScanProgress("Сравнение изображений", files.size, folders, junk.size, junkBytes, "", f.path, i.toFloat() / images.size.coerceAtLeast(1)))
            val h = Hashing.dHash(File(f.path)) ?: continue
            val bits = java.lang.Long.bitCount(h.hash)
            if (bits < 4 || bits > 60) continue // однотонные картинки дают ложные совпадения
            imgInfos.add(f.copy(width = h.width, height = h.height))
            imgHashes.add(h.hash)
        }
        val imgUf = UnionFind(imgInfos.size)
        for (i in imgInfos.indices) {
            if (i % 100 == 0) currentCoroutineContext().ensureActive()
            val ai = imgInfos[i]
            val ari = ai.width.toDouble() / ai.height.coerceAtLeast(1)
            for (j in i + 1 until imgInfos.size) {
                if (Hashing.hamming(imgHashes[i], imgHashes[j]) <= config.imageThreshold) {
                    val aj = imgInfos[j]
                    val arj = aj.width.toDouble() / aj.height.coerceAtLeast(1)
                    if (abs(ari - arj) / maxOf(ari, arj) < 0.08) imgUf.union(i, j)
                }
            }
        }
        for (component in imgUf.components()) {
            if (component.size < 2) continue
            val members = component.map { imgInfos[it] }
            val maxDist = component.maxOf { a -> component.maxOf { b -> Hashing.hamming(imgHashes[a], imgHashes[b]) } }
            val percent = ((64 - maxDist) * 100) / 64
            groups.add(buildGroup(GroupType.SIMILAR_IMAGE, members, "Визуальное сходство не ниже $percent% (dHash, расстояние ≤ $maxDist)"))
        }

        // ---------- 5. Похожие тексты ----------
        val texts = pool.filter { it.extension in TEXT_EXT && it.size in 40L..(5L * 1024 * 1024) }
            .sortedByDescending { it.lastModified }
            .take(MAX_TEXTS)
        val txtInfos = ArrayList<FileInfo>()
        val sigs = ArrayList<IntArray>()
        val textLengthByPath = HashMap<String, Int>()
        for ((i, f) in texts.withIndex()) {
            currentCoroutineContext().ensureActive()
            report(onProgress, ScanProgress("Сравнение текстов", files.size, folders, junk.size, junkBytes, "", f.path, i.toFloat() / texts.size.coerceAtLeast(1)))
            val fp = TextSimilarity.fingerprint(File(f.path)) ?: continue
            txtInfos.add(f.copy(textLength = fp.normalizedLength))
            sigs.add(fp.signature)
            textLengthByPath[f.path] = fp.normalizedLength
        }
        val buckets = HashMap<Long, MutableList<Int>>()
        for (i in sigs.indices) {
            for (k in TextSimilarity.bandKeys(sigs[i])) buckets.getOrPut(k) { ArrayList() }.add(i)
        }
        val txtUf = UnionFind(txtInfos.size)
        val checked = HashSet<Long>()
        val pairSim = HashMap<Long, Double>()
        for ((_, members) in buckets) {
            if (members.size < 2 || members.size > 200) continue
            currentCoroutineContext().ensureActive()
            for (a in members.indices) for (b in a + 1 until members.size) {
                val i = minOf(members[a], members[b])
                val j = maxOf(members[a], members[b])
                val key = i.toLong() * 1_000_003L + j
                if (!checked.add(key)) continue
                val sim = TextSimilarity.similarity(sigs[i], sigs[j])
                if (sim >= config.textThreshold) {
                    txtUf.union(i, j)
                    pairSim[key] = sim
                }
            }
        }
        val textGroupOf = HashMap<String, Int>()
        for ((ci, component) in txtUf.components().withIndex()) {
            if (component.size < 2) continue
            val members = component.map { txtInfos[it] }
            members.forEach { textGroupOf[it.path] = ci }
            var minSim = 1.0
            for (a in component) for (b in component) if (a < b) {
                val s = pairSim[a.toLong() * 1_000_003L + b] ?: TextSimilarity.similarity(sigs[a], sigs[b])
                if (s < minSim) minSim = s
            }
            groups.add(buildGroup(GroupType.SIMILAR_TEXT, members, "Текст совпадает примерно на ${(minSim * 100).toInt()}% (MinHash/Жаккар)"))
        }

        // ---------- 6. Версии одного файла ----------
        report(onProgress, ScanProgress("Поиск версий файлов", files.size, folders, junk.size, junkBytes, "", "", 0.95f), force = true)
        val byBase = HashMap<String, MutableList<FileInfo>>()
        for (f in pool) {
            val ext = f.extension
            if (ext.isEmpty() || ext in IMAGE_EXT || ext in MEDIA_EXT) continue
            val base = NameUtils.baseName(f.name)
            if (base.length < 2) continue
            byBase.getOrPut("$base|$ext") { ArrayList() }.add(f)
        }
        for ((_, members) in byBase) {
            if (members.size < 2 || members.size > 30) continue
            if (members.none { NameUtils.hasVersionMarker(it.name) }) continue
            val tg = members.map { textGroupOf[it.path] }
            if (tg.all { it != null && it == tg[0] }) continue // уже есть в похожих текстах
            val enriched = members.map { m -> textLengthByPath[m.path]?.let { m.copy(textLength = it) } ?: m }
            groups.add(buildGroup(GroupType.VERSIONS, enriched, "Одинаковое базовое имя «${NameUtils.baseName(members[0].name)}»"))
        }

        report(onProgress, ScanProgress("Готово", files.size, folders, junk.size, junkBytes, "", "", 1f), force = true)
        if (inaccessibleTotal > inaccessible.size) {
            inaccessible.add(InaccessibleFolder("…", "и ещё ${inaccessibleTotal - inaccessible.size} папок без доступа"))
        }
        return ScanResult(
            finishedAt = System.currentTimeMillis(),
            filesScanned = files.size,
            foldersScanned = folders,
            volumes = config.volumes,
            inaccessible = inaccessible,
            allFiles = files,
            junk = junk,
            groups = groups.sortedByDescending { it.reclaimableBytes }
        )
    }

    private fun buildGroup(type: GroupType, members: List<FileInfo>, note: String): FileGroup {
        val sorted = members.sortedByDescending { it.lastModified }
        val v = KeeperScorer.evaluate(sorted, type)
        val keeperPath = sorted[v.keeperIndex].path
        return FileGroup(
            id = groupId++,
            type = type,
            files = sorted,
            keeperIndex = v.keeperIndex,
            keeperReasons = v.reasons,
            scores = v.scores,
            similarityNote = note,
            selected = sorted.map { it.path }.filter { it != keeperPath }.toSet()
        )
    }

    private fun isRemovableEmptyDir(path: String, volumeRoot: String): Boolean {
        val rel = path.removePrefix("$volumeRoot/")
        if (rel.startsWith("Android/") || rel == "Android") return false
        if (!rel.contains('/') && rel.lowercase(Locale.ROOT) in standardRootFolders) return false
        return true
    }

    private fun isTempFile(lowerName: String, ext: String): Boolean =
        ext in TEMP_EXT ||
            lowerName.endsWith("~") ||
            lowerName.startsWith("~$") ||
            lowerName == "thumbs.db" ||
            lowerName == ".ds_store" ||
            lowerName == "desktop.ini"

    private fun tempNote(lowerName: String, ext: String): String = when {
        ext == "log" -> "Журнал (лог)"
        ext == "bak" || ext == "old" || lowerName.endsWith("~") -> "Резервная копия"
        ext == "crdownload" || ext == "part" || ext == "partial" -> "Недокачанный файл"
        lowerName.startsWith("~$") -> "Файл блокировки Office"
        else -> "Временный файл"
    }

    @Suppress("DEPRECATION")
    private fun apkItem(pm: PackageManager, f: FileInfo): JunkItem {
        val archive: PackageInfo? = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageArchiveInfo(f.path, PackageManager.PackageInfoFlags.of(0L))
            } else {
                pm.getPackageArchiveInfo(f.path, 0)
            }
        } catch (e: Exception) {
            null
        }
        if (archive == null) {
            return JunkItem(f, JunkCategory.APK, note = "Повреждённый или неполный APK", defaultSelected = true)
        }
        val pkg = archive.packageName
        val apkVersion = versionCodeOf(archive)
        val installed: PackageInfo? = try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(0L))
            } else {
                pm.getPackageInfo(pkg, 0)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            null
        } catch (e: Exception) {
            null
        }
        return when {
            installed == null -> JunkItem(
                f, JunkCategory.APK,
                note = "Не установлено: $pkg (версия ${archive.versionName ?: apkVersion})",
                defaultSelected = false
            )
            versionCodeOf(installed) >= apkVersion -> JunkItem(
                f, JunkCategory.APK,
                note = "Уже установлено: $pkg (установлена ${installed.versionName ?: versionCodeOf(installed)})",
                defaultSelected = true
            )
            else -> JunkItem(
                f, JunkCategory.APK,
                note = "Установлена более старая версия: $pkg",
                defaultSelected = false
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(p: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else p.versionCode.toLong()

    private class UnionFind(n: Int) {
        private val parent = IntArray(n) { it }
        private val rank = IntArray(n)

        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) {
                val next = parent[c]
                parent[c] = r
                c = next
            }
            return r
        }

        fun union(a: Int, b: Int) {
            val ra = find(a)
            val rb = find(b)
            if (ra == rb) return
            when {
                rank[ra] < rank[rb] -> parent[ra] = rb
                rank[ra] > rank[rb] -> parent[rb] = ra
                else -> {
                    parent[rb] = ra
                    rank[ra]++
                }
            }
        }

        fun components(): List<List<Int>> {
            val map = HashMap<Int, MutableList<Int>>()
            for (i in parent.indices) map.getOrPut(find(i)) { ArrayList() }.add(i)
            return map.values.toList()
        }
    }

    private object DocumentsContractCompat {
        fun treeId(uri: Uri): String = try {
            DocumentsContract.getTreeDocumentId(uri)
        } catch (e: Exception) {
            ""
        }
    }

    companion object {
        private const val MAX_IMAGES = 6000
        private const val MAX_TEXTS = 4000
        val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif")
        val TEXT_EXT = setOf("txt", "md", "csv", "json", "xml", "html", "htm", "log")
        val MEDIA_EXT = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "amr")
        val TEMP_EXT = setOf("tmp", "temp", "bak", "old", "log", "crdownload", "part", "partial", "chk", "dmp")
    }
}
