import 'dart:async';
import 'dart:convert';
import 'dart:isolate';
import 'package:flutter/foundation.dart';
import 'package:handy_tdlib_next/handy_tdlib_next.dart' as td;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/message.dart';
import 'sqlite_cache.dart';
import 'session_installer.dart';

/// Статус авторизации TDLib
enum TdAuthState {
  initial,
  waitingPhoneNumber,
  waitingCode,
  waitingPassword,
  ready,
  error,
  closed,
}

/// Главный сервис — обёртка над TDLib.
/// Использует TdPlugin (низкоуровневый FFI API) + изолят для receive-цикла.
class TdService extends ChangeNotifier {
  static TdService? _instance;
  static TdService get instance => _instance ??= TdService._();
  TdService._();

  // TDLib client id (int, не объект)
  int? _clientId;
  bool _initialized = false;

  // Изолят для receive-цикла
  Isolate? _receiveIsolate;
  ReceivePort? _fromIsolate;

  // extra-счётчик для корреляции запросов
  int _extraCounter = 0;
  int get _nextExtra => ++_extraCounter;
  final Map<int, Completer<td.TdObject?>> _pending = {};

  TdAuthState _authState = TdAuthState.initial;
  TdAuthState get authState => _authState;

  String _errorMessage = '';
  String get errorMessage => _errorMessage;

  int _myUserId = 0;
  int get myUserId => _myUserId;

  final List<TgDialog> _cachedChats = [];
  List<TgDialog> get cachedChats => List.unmodifiable(_cachedChats);

  final Map<int, td.Chat> _tdChats = {};
  final Map<int, td.User> _tdUsers = {};

  final _chatUpdates = StreamController<List<TgDialog>>.broadcast();
  Stream<List<TgDialog>> get chatStream => _chatUpdates.stream;

  final _newMessages = StreamController<TgMessage>.broadcast();
  Stream<TgMessage> get newMessageStream => _newMessages.stream;

  final _authStateStream = StreamController<TdAuthState>.broadcast();
  Stream<TdAuthState> get authStream => _authStateStream.stream;

  // ─── Инициализация ─────────────────────────────────────────

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;
    await _loadSqliteCache();
    await _startTdLib();
  }

  // ─── SQLite кэш ───────────────────────────────────────────

  Future<void> _loadSqliteCache() async {
    try {
      final db = await SqliteCache.open();
      final chats = await db.loadChats();
      _cachedChats
        ..clear()
        ..addAll(chats);
      notifyListeners();
      debugPrint('[TdService] SQLite: ${chats.length} chats loaded');
    } catch (e) {
      debugPrint('[TdService] SQLite error: $e');
    }
  }

  // ─── TDLib: запуск ────────────────────────────────────────

  Future<void> _startTdLib() async {
    try {
      await td.TdPlugin.initialize();

      _clientId = td.TdPlugin.instance.tdCreateClientId();

      // Запускаем receive-изолят
      _fromIsolate = ReceivePort();
      _receiveIsolate = await Isolate.spawn(
        _receiveLoop,
        _ReceiveLoopArgs(
          sendPort: _fromIsolate!.sendPort,
          clientId: _clientId!,
        ),
      );

      // Слушаем сообщения из изолята
      _fromIsolate!.listen(_onIsolateMessage);

      // Параметры TDLib
      final docsDir = await getApplicationDocumentsDirectory();
      final tdDir = '${docsDir.path}/tdlib_data';

      // Читаем API credentials
      final accountJson = await SessionInstaller.accountsJson;
      final accountData = jsonDecode(accountJson) as Map<String, dynamic>;
      final accounts = accountData['accounts'] as List? ?? [];
      final account = accounts.isNotEmpty
          ? accounts.first as Map<String, dynamic>
          : <String, dynamic>{};

      const apiId = 21099690;
      const apiHash = '9c1130843fda5f6516d7c8197ec26281';
      final deviceModel = account['device_model'] as String? ?? 'Android';
      final systemVersion =
          account['system_version'] as String? ?? 'Android 10';
      final appVersion = account['app_version'] as String? ?? '1.0';
      final langCode = account['lang_code'] as String? ?? 'ru';

      await _send(td.SetTdlibParameters(
        useTestDc: false,
        databaseDirectory: tdDir,
        filesDirectory: '${docsDir.path}/tdlib_files',
        databaseEncryptionKey: '',
        useFileDatabase: true,
        useChatInfoDatabase: true,
        useMessageDatabase: true,
        useSecretChats: false,
        apiId: apiId,
        apiHash: apiHash,
        systemLanguageCode: langCode,
        deviceModel: deviceModel,
        systemVersion: systemVersion,
        applicationVersion: appVersion,
      ));
    } catch (e) {
      debugPrint('[TdService] TDLib init error: $e');
      _setAuthState(TdAuthState.error);
      _errorMessage = e.toString();
    }
  }

  // ─── Изолят receive-цикл ──────────────────────────────────

  static void _receiveLoop(_ReceiveLoopArgs args) {
    final plugin = td.TdPlugin.instance;
    while (true) {
      final raw = plugin.tdReceive(2.0);
      if (raw != null) {
        try {
          final obj = td.convertJsonToObject(raw);
          if (obj != null) {
            args.sendPort.send(obj);
          }
        } catch (_) {}
      }
    }
  }

  void _onIsolateMessage(dynamic message) {
    if (message is! td.TdObject) return;
    final obj = message;

    // Ответ на запрос (extra != null) — резолвим Completer
    final extra = obj.extra;
    if (extra != null && extra is int && _pending.containsKey(extra)) {
      _pending.remove(extra)?.complete(obj);
      return;
    }

    // Апдейт
    _onUpdate(obj);
  }

  // ─── Отправка запроса с ожиданием ответа ─────────────────

  Future<td.TdObject?> _send(td.TdFunction func) async {
    if (_clientId == null) return null;
    final extra = _nextExtra;
    final completer = Completer<td.TdObject?>();
    _pending[extra] = completer;

    td.TdPlugin.instance.tdSend(
      _clientId!,
      jsonEncode(func.toJson(extra)),
    );

    // Таймаут 30 секунд
    return completer.future.timeout(
      const Duration(seconds: 30),
      onTimeout: () {
        _pending.remove(extra);
        return null;
      },
    );
  }

  // ─── Обработка апдейтов ───────────────────────────────────

  void _onUpdate(td.TdObject update) {
    if (update is td.UpdateAuthorizationState) {
      _handleAuthState(update.authorizationState);
    } else if (update is td.UpdateNewChat) {
      _tdChats[update.chat.id] = update.chat;
      _refreshChatList();
    } else if (update is td.UpdateChatLastMessage) {
      if (_tdChats.containsKey(update.chatId)) {
        _refreshChatList();
      }
    } else if (update is td.UpdateNewMessage) {
      final msg = _tdMessageToTg(update.message);
      if (msg != null) {
        _newMessages.add(msg);
        _refreshChatList();
      }
    } else if (update is td.UpdateUser) {
      _tdUsers[update.user.id] = update.user;
    } else if (update is td.UpdateChatReadInbox) {
      _refreshChatList();
    }
  }

  void _handleAuthState(td.AuthorizationState state) {
    if (state is td.AuthorizationStateWaitTdlibParameters) {
      // Уже отправлено выше
    } else if (state is td.AuthorizationStateWaitPhoneNumber) {
      _setAuthState(TdAuthState.waitingPhoneNumber);
    } else if (state is td.AuthorizationStateWaitCode) {
      _setAuthState(TdAuthState.waitingCode);
    } else if (state is td.AuthorizationStateWaitPassword) {
      _setAuthState(TdAuthState.waitingPassword);
    } else if (state is td.AuthorizationStateReady) {
      _setAuthState(TdAuthState.ready);
      _onAuthorized();
    } else if (state is td.AuthorizationStateClosed) {
      _setAuthState(TdAuthState.closed);
    }
  }

  void _setAuthState(TdAuthState state) {
    _authState = state;
    _authStateStream.add(state);
    notifyListeners();
  }

  Future<void> _onAuthorized() async {
    debugPrint('[TdService] Authorized! Loading chats...');
    try {
      await _send(td.LoadChats(
        chatList: td.ChatListMain(),
        limit: 50,
      ));
      final me = await _send(td.GetMe()) as td.User?;
      if (me != null) _myUserId = me.id;
    } catch (e) {
      debugPrint('[TdService] _onAuthorized error: $e');
    }
  }

  // ─── Auth actions ──────────────────────────────────────────

  Future<void> sendPhoneNumber(String phone) async {
    await _send(td.SetAuthenticationPhoneNumber(
      phoneNumber: phone,
      settings: td.PhoneNumberAuthenticationSettings(
        allowFlashCall: false,
        allowMissedCall: false,
        isCurrentPhoneNumber: false,
        hasUnknownPhoneNumber: false,
        allowSmsRetrieverApi: false,
        authenticationTokens: [],
      ),
    ));
  }

  Future<void> sendCode(String code) async {
    await _send(td.CheckAuthenticationCode(code: code));
  }

  Future<void> sendPassword(String password) async {
    await _send(td.CheckAuthenticationPassword(password: password));
  }

  // ─── Данные ────────────────────────────────────────────────

  List<TgDialog> get dialogs {
    if (_tdChats.isNotEmpty && _authState == TdAuthState.ready) {
      return _tdChatsToDialogs();
    }
    return _cachedChats;
  }

  List<TgDialog> _tdChatsToDialogs() {
    final list = _tdChats.values.toList()
      ..sort((a, b) {
        final at = a.lastMessage?.date ?? 0;
        final bt = b.lastMessage?.date ?? 0;
        return bt.compareTo(at);
      });

    return list.map((chat) {
      final lastMsg = chat.lastMessage;
      String lastText = '';
      if (lastMsg?.content is td.MessageText) {
        lastText = (lastMsg!.content as td.MessageText).text.text;
      } else if (lastMsg != null) {
        lastText = _contentTypeLabel(lastMsg.content);
      }

      final kind = _chatKind(chat.type);
      return TgDialog(
        chatId: chat.id,
        title: chat.title,
        username: null,
        kind: kind,
        lastSeen: lastMsg != null
            ? DateTime.fromMillisecondsSinceEpoch(lastMsg.date * 1000)
                .toIso8601String()
            : '',
        lastMessage: lastText,
        unreadCount: chat.unreadCount,
      );
    }).toList();
  }

  String _chatKind(td.ChatType type) {
    if (type is td.ChatTypePrivate) return 'private';
    if (type is td.ChatTypeBasicGroup) return 'group';
    if (type is td.ChatTypeSupergroup) {
      return type.isChannel ? 'channel' : 'group';
    }
    return 'private';
  }

  String _contentTypeLabel(td.MessageContent content) {
    if (content is td.MessagePhoto) return '🖼 Фото';
    if (content is td.MessageVideo) return '🎬 Видео';
    if (content is td.MessageAudio) return '🎵 Аудио';
    if (content is td.MessageDocument) return '📄 Файл';
    if (content is td.MessageSticker) return '😊 Стикер';
    if (content is td.MessageVoiceNote) return '🎤 Голосовое';
    if (content is td.MessageVideoNote) return '📹 Видеосообщение';
    if (content is td.MessageAnimation) return '🎭 GIF';
    return '📎 Медиа';
  }

  void _refreshChatList() {
    _chatUpdates.add(dialogs);
    notifyListeners();
  }

  TgMessage? _tdMessageToTg(td.Message msg) {
    String text = '';
    if (msg.content is td.MessageText) {
      text = (msg.content as td.MessageText).text.text;
    }
    final sender = msg.senderId;
    int senderId = 0;
    if (sender is td.MessageSenderUser) senderId = sender.userId;
    final user = _tdUsers[senderId];
    // username — объект Usernames, берём первый активный
    final username = user?.usernames?.activeUsernames.firstOrNull ?? '';
    return TgMessage(
      chatId: msg.chatId,
      msgId: msg.id,
      date: _formatDate(msg.date),
      sender: user?.firstName ?? '',
      senderUsername: username,
      text: text,
      out: msg.isOutgoing,
      mediaHtml: '',
      dayKey: '',
      dayLabel: '',
      hasMedia: msg.content is! td.MessageText,
    );
  }

  String _formatDate(int unixSec) {
    final dt = DateTime.fromMillisecondsSinceEpoch(unixSec * 1000);
    final d = dt.day.toString().padLeft(2, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final y = dt.year.toString().substring(2);
    final h = dt.hour.toString().padLeft(2, '0');
    final min = dt.minute.toString().padLeft(2, '0');
    return '$d.$m.$y $h:$min';
  }

  // ─── История чата ─────────────────────────────────────────

  Future<List<TgMessage>> getHistory(int chatId,
      {int fromMessageId = 0, int limit = 50}) async {
    if (_authState == TdAuthState.ready && _clientId != null) {
      try {
        final result = await _send(td.GetChatHistory(
          chatId: chatId,
          fromMessageId: fromMessageId,
          offset: 0,
          limit: limit,
          onlyLocal: false,
        )) as td.Messages?;

        if (result != null && result.messages.isNotEmpty) {
          return result.messages
              .map(_tdMessageToTg)
              .whereType<TgMessage>()
              .toList();
        }
      } catch (e) {
        debugPrint('[TdService] getHistory error: $e');
      }
    }

    // Fallback — SQLite
    final db = await SqliteCache.open();
    return db.loadMessages(chatId, limit: limit);
  }

  Future<List<TgMessage>> getCachedMessages(int chatId,
      {int limit = 50, int? beforeId}) async {
    final db = await SqliteCache.open();
    return db.loadMessages(chatId, limit: limit, beforeId: beforeId);
  }

  // ─── Отправка/редактирование ──────────────────────────────

  Future<bool> sendMessage(int chatId, String text,
      {int? replyToMsgId}) async {
    if (_clientId == null || _authState != TdAuthState.ready) return false;
    try {
      await _send(td.SendMessage(
        chatId: chatId,
        messageThreadId: 0,
        replyTo: replyToMsgId != null
            ? td.InputMessageReplyToMessage(
                messageId: replyToMsgId,
                quote: null,
              )
            : null,
        options: td.MessageSendOptions(
          disableNotification: false,
          fromBackground: false,
          protectContent: false,
          updateOrderOfInstalledStickerSets: false,
          schedulingState: null,
          effectId: 0,
          sendingId: 0,
          onlyPreview: false,
        ),
        replyMarkup: null,
        inputMessageContent: td.InputMessageText(
          text: td.FormattedText(text: text, entities: []),
          linkPreviewOptions: td.LinkPreviewOptions(
            isDisabled: true,
            url: '',
            forceLargeMedia: false,
            forceSmallMedia: false,
            showAboveText: false,
          ),
          clearDraft: true,
        ),
      ));
      return true;
    } catch (e) {
      debugPrint('[TdService] sendMessage error: $e');
      return false;
    }
  }

  Future<bool> deleteMessage(int chatId, int messageId) async {
    if (_clientId == null || _authState != TdAuthState.ready) return false;
    try {
      await _send(td.DeleteMessages(
        chatId: chatId,
        messageIds: [messageId],
        revoke: true,
      ));
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> editMessage(int chatId, int messageId, String newText) async {
    if (_clientId == null || _authState != TdAuthState.ready) return false;
    try {
      await _send(td.EditMessageText(
        chatId: chatId,
        messageId: messageId,
        replyMarkup: null,
        inputMessageContent: td.InputMessageText(
          text: td.FormattedText(text: newText, entities: []),
          linkPreviewOptions: td.LinkPreviewOptions(
            isDisabled: true,
            url: '',
            forceLargeMedia: false,
            forceSmallMedia: false,
            showAboveText: false,
          ),
          clearDraft: false,
        ),
      ));
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> markRead(int chatId, int lastReadMessageId) async {
    if (_clientId == null) return;
    try {
      await _send(td.ViewMessages(
        chatId: chatId,
        messageIds: [lastReadMessageId],
        source: null,
        forceRead: true,
      ));
    } catch (_) {}
  }

  // ─── Медиа ────────────────────────────────────────────────

  /// Скачать медиафайл по (chatId, msgId), вернуть локальный путь
  Future<String?> downloadFile(int chatId, int msgId) async {
    if (_clientId == null) return null;
    try {
      final msg = await _send(td.GetMessage(
        chatId: chatId,
        messageId: msgId,
      )) as td.Message?;
      if (msg == null) return null;

      final fileId = _extractFileId(msg.content);
      if (fileId == null) return null;

      return downloadFileById(fileId);
    } catch (e) {
      debugPrint('[TdService] downloadFile error: $e');
      return null;
    }
  }

  /// Скачать файл по TDLib fileId
  Future<String?> downloadFileById(int fileId) async {
    if (_clientId == null) return null;
    try {
      final file = await _send(td.DownloadFile(
        fileId: fileId,
        priority: 1,
        offset: 0,
        limit: 0,
        synchronous: true,
      )) as td.File?;
      final path = file?.local.path;
      return (path == null || path.isEmpty) ? null : path;
    } catch (_) {
      return null;
    }
  }

  int? _extractFileId(td.MessageContent content) {
    if (content is td.MessagePhoto) {
      final sizes = content.photo.sizes;
      return sizes.isNotEmpty ? sizes.last.photo.id : null;
    }
    if (content is td.MessageVideo) return content.video.video.id;
    if (content is td.MessageDocument) return content.document.document.id;
    if (content is td.MessageAudio) return content.audio.audio.id;
    if (content is td.MessageVoiceNote) return content.voiceNote.voice.id;
    if (content is td.MessageVideoNote) return content.videoNote.video.id;
    if (content is td.MessageSticker) return content.sticker.sticker.id;
    if (content is td.MessageAnimation) return content.animation.animation.id;
    return null;
  }

  @override
  void dispose() {
    _receiveIsolate?.kill(priority: Isolate.immediate);
    _fromIsolate?.close();
    _chatUpdates.close();
    _newMessages.close();
    _authStateStream.close();
    super.dispose();
  }
}

/// Аргументы для receive-изолята
class _ReceiveLoopArgs {
  final SendPort sendPort;
  final int clientId;
  const _ReceiveLoopArgs({required this.sendPort, required this.clientId});
}
