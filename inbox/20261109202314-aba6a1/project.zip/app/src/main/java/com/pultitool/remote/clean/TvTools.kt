package com.pultitool.remote.clean

/** Приложение на телевизоре для менеджера приложений. */
data class TvApp(val pkg: String, val system: Boolean, val disabled: Boolean, val title: String?)

/**
 * Дополнительные ADB-инструменты «Пульт Тул»: менеджер приложений, перезагрузка,
 * снимок экрана, оболочка. Все имена пакетов проверяются, прежде чем попасть в shell.
 */
class TvTools(private val session: TvSession) {
    private val adb get() = session.adb

    fun apps(): List<TvApp> {
        val third = TvInfo.parsePackages(adb.shell("pm list packages -3"))
        val disabled = TvInfo.parsePackages(adb.shell("pm list packages -d"))
        val all = (third + disabled).filter { TvStore.SAFE_PKG.matches(it) }.distinct()
        return all.map { p ->
            TvApp(p, system = p !in third, disabled = p in disabled, title = session.db.entry(p)?.title)
        }.sortedWith(compareBy({ !it.disabled }, { it.system }, { it.pkg }))
    }

    private fun check(pkg: String) {
        require(TvStore.SAFE_PKG.matches(pkg)) { "Странное имя пакета: $pkg" }
    }

    /** Защищённые системой пакеты (HDMI, пульт, установщик…) и штатные лаунчеры не отключаем */
    fun canDisable(app: TvApp): Boolean =
        !Protect.isProtected(app.pkg) && session.db.entry(app.pkg)?.let { it.action != "keep" && !it.launcher } != false

    fun disable(app: TvApp) {
        check(app.pkg)
        val out = session.out
        if (!canDisable(app)) {
            out.warn("${app.pkg}: этот пакет под защитой — его отключение может сломать телевизор.")
            return
        }
        val r = adb.shell("pm disable-user --user 0 ${app.pkg}")
        if (Regex("disabled-user|new state: disabled", RegexOption.IGNORE_CASE).containsMatchIn(r)) {
            session.store.record(app.pkg)
            out.ok("Отключено: ${app.pkg} (вернуть — «Включить» или «Откат»)")
        } else out.warn("${app.pkg}: ${TvSession.shortError(r)}")
    }

    fun enable(app: TvApp) {
        check(app.pkg)
        val r = adb.shell("pm enable ${app.pkg}")
        if (r.contains("enabled", true)) session.out.ok("Включено: ${app.pkg}") else session.out.warn("${app.pkg}: ${TvSession.shortError(r)}")
    }

    fun forceStop(app: TvApp) {
        check(app.pkg)
        adb.shell("am force-stop ${app.pkg}")
        session.out.ok("Остановлено: ${app.pkg}")
    }

    /** Только кэш: pm clear --cache-only есть с Android 14; на старых — общая очистка кэша системой */
    fun clearCache(app: TvApp) {
        check(app.pkg)
        val r = if (session.info.sdk >= 34) adb.shell("pm clear --cache-only ${app.pkg}") else ""
        if (r.contains("Success")) {
            session.out.ok("Кэш очищен: ${app.pkg}")
        } else {
            session.out.info("На этой версии Android нельзя очистить кэш одного приложения — прошу систему очистить кэш всех (данные не трогаются)…")
            session.trimCaches()
        }
    }

    fun launch(app: TvApp) {
        check(app.pkg)
        val r = adb.shell("monkey -p ${app.pkg} -c android.intent.category.LEANBACK_LAUNCHER 1 2>&1")
        if (r.contains("No activities found", true)) adb.shell("monkey -p ${app.pkg} -c android.intent.category.LAUNCHER 1 2>&1")
        session.out.ok("Запускаю ${app.pkg} на телевизоре")
    }

    /** Удаляем только сторонние приложения — системные никогда */
    fun uninstall(app: TvApp) {
        check(app.pkg)
        if (app.system) {
            session.out.warn("Системные приложения не удаляются — только отключаются.")
            return
        }
        val r = adb.shell("pm uninstall ${app.pkg}")
        if (r.contains("Success")) session.out.ok("Удалено: ${app.pkg}") else session.out.warn("${app.pkg}: ${TvSession.shortError(r)}")
    }

    fun reboot() {
        session.out.info("Перезагружаю телевизор — связь пропадёт, подключитесь снова через минуту.")
        runCatching { adb.shell("reboot") }
    }

    /** Мягкий перезапуск: перезапускает оболочку Android без выключения железа; не везде разрешён */
    fun softRestart(): Boolean {
        val r = runCatching { adb.shell("am restart") }.getOrDefault("")
        return if (r.contains("Exception", true) || r.contains("Error", true) || r.contains("Unknown", true)) {
            session.out.warn("Прошивка не разрешает мягкий перезапуск: ${TvSession.shortError(r)}")
            false
        } else {
            session.out.ok("Оболочка Android перезапускается…")
            true
        }
    }

    fun key(code: String) {
        require(Regex("^KEYCODE_[A-Z0-9_]+$").matches(code))
        adb.shell("input keyevent $code")
    }

    /** PNG снимок экрана телевизора */
    fun screenshot(): ByteArray {
        var bytes = adb.shellBytes("screencap -p")
        if (!isPng(bytes)) {
            // Старые прошивки без exec: — через файл
            adb.shell("screencap -p /data/local/tmp/pultitool-shot.png")
            bytes = adb.shellBytes("cat /data/local/tmp/pultitool-shot.png")
            adb.shell("rm -f /data/local/tmp/pultitool-shot.png")
        }
        if (!isPng(bytes)) throw java.io.IOException("Телевизор не отдал снимок экрана (защищённое содержимое или запрет прошивки)")
        return bytes
    }

    private fun isPng(b: ByteArray) = b.size > 8 && b[0] == 0x89.toByte() && b[1] == 'P'.code.toByte() && b[2] == 'N'.code.toByte()
}
