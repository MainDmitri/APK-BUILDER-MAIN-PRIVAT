package com.pultitool.remote.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AdbViewModel
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.util.Banner
import com.pultitool.remote.util.BannerKind
import com.pultitool.remote.util.Events
import kotlinx.coroutines.delay
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

private data class NavItem(val screen: Screen, val title: String, val glyph: Glyph)

private val navItems = listOf(
    NavItem(Screen.HOME, "Главная", Glyph.DASH),
    NavItem(Screen.DEVICES, "Устройства", Glyph.TV),
    NavItem(Screen.REMOTE, "Пульт", Glyph.GRID),
    NavItem(Screen.ADB, "Чистка", Glyph.BROOM),
    NavItem(Screen.TOOLS, "Сеть", Glyph.SHIELD),
    NavItem(Screen.SETTINGS, "Настройки", Glyph.MENU)
)

@Composable
fun PultApp(vm: AppViewModel, tools: NetToolsViewModel, adb: AdbViewModel) {
    val settings by vm.settings.collectAsState()
    val screen by vm.screen.collectAsState()
    val accent = Accents.getOrElse(settings.accent) { Accents[0] }

    PultTheme(accent, settings.amoled) {
        AppBackground {
            if (screen == Screen.GESTURE) {
                GestureRemoteScreen(vm)
            } else Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AnimatedContent(
                        targetState = screen,
                        transitionSpec = { (fadeIn(tween(260)) + scaleIn(tween(260), initialScale = 0.97f)) togetherWith fadeOut(tween(160)) },
                        label = "screen"
                    ) { s ->
                        when (s) {
                            Screen.HOME -> HomeScreen(vm, tools)
                            Screen.DEVICES -> DevicesScreen(vm)
                            Screen.SCAN -> ScanScreen(vm)
                            Screen.REMOTE -> RemoteScreen(vm)
                            Screen.GESTURE -> Box(Modifier.fillMaxSize())
                            Screen.TOOLS -> ToolsScreen(vm)
                            Screen.AUDIT -> AuditScreen(vm)
                            Screen.PING -> PingScreen(vm, tools)
                            Screen.PORTS -> PortsScreen(vm, tools)
                            Screen.RANGE -> RangePortsScreen(vm, tools)
                            Screen.TRACE -> TraceScreen(vm, tools)
                            Screen.DNS -> DnsScreen(vm, tools)
                            Screen.PUBLIC_IP -> PublicIpScreen(vm, tools)
                            Screen.SUBNET -> SubnetScreen(vm)
                            Screen.SPEED -> SpeedScreen(vm, tools)
                            Screen.HTTP -> HttpScreen(vm, tools)
                            Screen.MAP -> NetMapScreen(vm, tools)
                            Screen.MONITOR -> MonitorScreen(vm, tools)
                            Screen.ADB -> CleanTab(vm, adb)
                            Screen.ACHIEVEMENTS -> AchievementsScreen(vm)
                            Screen.SETTINGS -> SettingsScreen(vm)
                        }
                    }
                    BannerHost(Modifier.align(Alignment.TopCenter))
                }
                BottomBar(screen) { vm.navigate(it) }
            }
        }
    }

    BackHandler(enabled = screen != Screen.HOME && screen != Screen.GESTURE) {
        if (screen == Screen.SCAN) vm.stopScan()
        if (screen == Screen.ADB && adb.back()) return@BackHandler
        vm.back()
    }
}

/** Всплывающие баннеры: новые устройства в сети, достижения. */
@Composable
private fun BannerHost(modifier: Modifier) {
    var current by remember { mutableStateOf<Banner?>(null) }
    LaunchedEffect(Unit) {
        Events.banners.collect { b ->
            current = b
            delay(3800)
            if (current?.id == b.id) current = null
        }
    }
    AnimatedVisibility(
        visible = current != null,
        enter = slideInVertically { -it } + fadeIn(),
        exit = slideOutVertically { -it } + fadeOut(),
        modifier = modifier.padding(12.dp)
    ) {
        val b = current ?: return@AnimatedVisibility
        val color = when (b.kind) {
            BannerKind.ACHIEVEMENT -> Pal.yellow
            BannerKind.WARNING -> Color(0xFFFF8A3D)
            BannerKind.SUCCESS -> Pal.green
            BannerKind.INFO -> LocalAccent.current.b
        }
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                .background(Color(0xF0151225))
                .border(1.dp, color.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                .clickable { current = null }
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatusDot(color, 12.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(b.title, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(b.text, color = Pal.text, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun BottomBar(current: Screen, onSelect: (Screen) -> Unit) {
    val accent = LocalAccent.current
    val sel = when (current) {
        Screen.SCAN -> Screen.DEVICES
        Screen.HOME, Screen.DEVICES, Screen.REMOTE, Screen.SETTINGS, Screen.ADB -> current
        Screen.ACHIEVEMENTS -> Screen.HOME
        else -> Screen.TOOLS
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .glass(RoundedCornerShape(26.dp), strong = true)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceAround
    ) {
        navItems.forEach { item ->
            val active = item.screen == sel
            val a by animateFloatAsState(if (active) 1f else 0.55f, label = "nav")
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .then(if (active) Modifier.background(accent.a.copy(alpha = 0.22f)) else Modifier)
                    .clickable(remember { MutableInteractionSource() }, null) { onSelect(item.screen) }
                    .padding(vertical = 8.dp)
                    .alpha(a),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                GlyphIcon(item.glyph, tint = if (active) accent.b else Pal.text, size = 22.dp)
                Spacer(Modifier.height(3.dp))
                Text(item.title, color = Pal.text, fontSize = 10.sp, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

@Composable
fun EmptyState(glyph: Glyph, title: String, text: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(96.dp).glass(RoundedCornerShape(48.dp)), contentAlignment = Alignment.Center) {
            GlyphIcon(glyph, tint = LocalAccent.current.b, size = 44.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text(title, color = Pal.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(text, color = Pal.textDim, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) { Spacer(Modifier.height(18.dp)); action() }
    }
}
