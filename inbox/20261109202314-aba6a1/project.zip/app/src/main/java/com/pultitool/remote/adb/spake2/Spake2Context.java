package com.pultitool.remote.adb.spake2;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.security.auth.Destroyable;

/**
 * SPAKE2 на Ed25519, совместимый с BoringSSL (crypto/curve25519/spake25519.c) — тем, что использует
 * adbd при «Подключении по коду» в Android 11+. Собственная реализация «Пульт Тул» на BigInteger
 * (лицензия проекта), без нативного кода. Включает «password scalar hack» BoringSSL (по умолчанию).
 *
 * Вычисления не в постоянном времени: допустимо для разового сопряжения в домашней сети,
 * пароль одноразовый и действует, пока на ТВ открыто окно с кодом.
 */
public final class Spake2Context implements Destroyable {
    public static final int MAX_MSG_SIZE = 32;
    public static final int MAX_KEY_SIZE = 64;

    // ─── Ed25519 ───────────────────────────────────────────────────────
    static final BigInteger P = BigInteger.ONE.shiftLeft(255).subtract(BigInteger.valueOf(19));
    static final BigInteger L = BigInteger.ONE.shiftLeft(252).add(new BigInteger("27742317777372353535851937790883648493"));
    static final BigInteger D = BigInteger.valueOf(-121665).mod(P)
            .multiply(BigInteger.valueOf(121666).modInverse(P)).mod(P);
    static final BigInteger SQRT_M1 = BigInteger.valueOf(2).modPow(P.subtract(BigInteger.ONE).shiftRight(2), P);
    static final Point BASE = new Point(
            new BigInteger("15112221349535400772501151409588531511454012693041857206046113283949847762202"),
            new BigInteger("46316835694926478169428394003475163141307993866256225615783033603165251855960"));
    static final Point ZERO = new Point(BigInteger.ZERO, BigInteger.ONE);
    static final Point M = Point.decode(sha256("edwards25519 point generation seed (M)"));
    static final Point N = Point.decode(sha256("edwards25519 point generation seed (N)"));

    /** Точка в аффинных координатах. Формулы сложения полные (d — не квадрат). */
    static final class Point {
        final BigInteger x, y;

        Point(BigInteger x, BigInteger y) {
            this.x = x;
            this.y = y;
        }

        Point add(Point o) {
            BigInteger dxy = D.multiply(x).multiply(o.x).mod(P).multiply(y).multiply(o.y).mod(P);
            BigInteger x3 = x.multiply(o.y).add(o.x.multiply(y)).multiply(BigInteger.ONE.add(dxy).modInverse(P)).mod(P);
            BigInteger y3 = y.multiply(o.y).add(x.multiply(o.x)).multiply(BigInteger.ONE.subtract(dxy).mod(P).modInverse(P)).mod(P);
            return new Point(x3, y3);
        }

        Point negate() {
            return new Point(P.subtract(x).mod(P), y);
        }

        /** k·P для неотрицательного целого k — точное умножение без приведения по модулю порядка */
        Point mul(BigInteger k) {
            Point r = ZERO;
            for (int i = k.bitLength() - 1; i >= 0; i--) {
                r = r.add(r);
                if (k.testBit(i)) r = r.add(this);
            }
            return r;
        }

        byte[] encode() {
            byte[] out = toLe(y, 32);
            if (x.testBit(0)) out[31] |= (byte) 0x80;
            return out;
        }

        /** Распаковка как x25519_ge_frombytes_vartime; null — точка не на кривой */
        static Point decode(byte[] s) {
            if (s.length != 32) return null;
            byte[] b = s.clone();
            boolean sign = (b[31] & 0x80) != 0;
            b[31] &= 0x7f;
            BigInteger y = fromLe(b).mod(P);
            BigInteger yy = y.multiply(y).mod(P);
            BigInteger u = yy.subtract(BigInteger.ONE).mod(P);
            BigInteger v = D.multiply(yy).add(BigInteger.ONE).mod(P);
            BigInteger uv = u.multiply(v.modInverse(P)).mod(P);
            BigInteger x = uv.modPow(P.add(BigInteger.valueOf(3)).shiftRight(3), P);
            BigInteger xx = x.multiply(x).mod(P);
            if (!xx.equals(uv)) {
                if (!xx.equals(P.subtract(uv).mod(P))) return null;
                x = x.multiply(SQRT_M1).mod(P);
            }
            if (x.testBit(0) != sign) x = P.subtract(x).mod(P);
            return new Point(x, y);
        }
    }

    // ─── Состояние ─────────────────────────────────────────────────────
    private final Spake2Role myRole;
    private final byte[] myName;
    private final byte[] theirName;
    private final SecureRandom random;
    private BigInteger privateKey;
    private BigInteger passwordScalar;
    private byte[] passwordHash;
    private byte[] myMsg;
    private boolean disablePasswordScalarHack;
    private int state; // 0 — начало, 1 — сообщение создано, 2 — ключ получен
    private boolean destroyed;

    public Spake2Context(Spake2Role myRole, byte[] myName, byte[] theirName) {
        this(myRole, myName, theirName, new SecureRandom());
    }

    Spake2Context(Spake2Role myRole, byte[] myName, byte[] theirName, SecureRandom random) {
        this.myRole = myRole;
        this.myName = myName.clone();
        this.theirName = theirName.clone();
        this.random = random;
    }

    public boolean isDisablePasswordScalarHack() {
        return disablePasswordScalarHack;
    }

    public void setDisablePasswordScalarHack(boolean disable) {
        this.disablePasswordScalarHack = disable;
    }

    public Spake2Role getMyRole() {
        return myRole;
    }

    public byte[] getMyMsg() {
        return myMsg == null ? new byte[MAX_MSG_SIZE] : myMsg.clone();
    }

    public byte[] generateMessage(byte[] password) {
        if (state != 0 || destroyed) throw new IllegalStateException("Invalid state");
        byte[] tmp = new byte[64];
        random.nextBytes(tmp);
        return generateMessage(password, tmp);
    }

    /** privateTmp — 64 случайных байта (отдельный метод — для проверки по эталону BoringSSL) */
    byte[] generateMessage(byte[] password, byte[] privateTmp) {
        // x25519_sc_reduce, затем ×8 (кофактор)
        privateKey = fromLe(privateTmp).mod(L).shiftLeft(3);
        Point pub = BASE.mul(privateKey);

        passwordHash = hash("SHA-512", password);
        BigInteger ps = fromLe(passwordHash).mod(L);
        if (!disablePasswordScalarHack) {
            // Добавляем l, 2l, 4l по младшим битам — скаляр становится кратным 8, как в BoringSSL
            BigInteger order = L;
            for (int bit = 0; bit < 3; bit++) {
                if (ps.testBit(bit)) ps = ps.add(order);
                order = order.shiftLeft(1);
            }
        }
        passwordScalar = ps;
        Point mask = (myRole == Spake2Role.Alice ? M : N).mul(passwordScalar);
        myMsg = pub.add(mask).encode();
        state = 1;
        return myMsg.clone();
    }

    public byte[] processMessage(byte[] theirMsg) {
        if (state != 1 || destroyed) throw new IllegalStateException("Invalid state");
        if (theirMsg == null || theirMsg.length != 32) throw new IllegalArgumentException("Invalid message length");
        Point qStar = Point.decode(theirMsg);
        if (qStar == null) throw new IllegalArgumentException("Point received from peer was not on the curve.");
        Point peersMask = (myRole == Spake2Role.Alice ? N : M).mul(passwordScalar);
        Point qExt = qStar.add(peersMask.negate());
        byte[] dh = qExt.mul(privateKey).encode();

        MessageDigest sha;
        try {
            sha = MessageDigest.getInstance("SHA-512");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
        if (myRole == Spake2Role.Alice) {
            update(sha, myName);
            update(sha, theirName);
            update(sha, myMsg);
            update(sha, theirMsg);
        } else {
            update(sha, theirName);
            update(sha, myName);
            update(sha, theirMsg);
            update(sha, myMsg);
        }
        update(sha, dh);
        update(sha, passwordHash);
        state = 2;
        return sha.digest();
    }

    @Override
    public boolean isDestroyed() {
        return destroyed;
    }

    @Override
    public void destroy() {
        destroyed = true;
        privateKey = null;
        passwordScalar = null;
        if (passwordHash != null) Arrays.fill(passwordHash, (byte) 0);
    }

    // ─── Вспомогательное ───────────────────────────────────────────────
    private static void update(MessageDigest sha, byte[] data) {
        long len = data.length;
        byte[] le = new byte[8];
        for (int i = 0; i < 8; i++) {
            le[i] = (byte) (len & 0xff);
            len >>>= 8;
        }
        sha.update(le);
        sha.update(data);
    }

    private static byte[] hash(String alg, byte[] data) {
        try {
            return MessageDigest.getInstance(alg).digest(data);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static byte[] sha256(String s) {
        return hash("SHA-256", s.getBytes(StandardCharsets.UTF_8));
    }

    static BigInteger fromLe(byte[] le) {
        byte[] be = new byte[le.length + 1];
        for (int i = 0; i < le.length; i++) be[le.length - i] = le[i];
        return new BigInteger(be);
    }

    static byte[] toLe(BigInteger v, int len) {
        byte[] be = v.toByteArray();
        byte[] out = new byte[len];
        for (int i = 0; i < len && i < be.length; i++) out[i] = be[be.length - 1 - i];
        return out;
    }
}
