package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s by vm.settings.collectAsState()
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Header("Настройки", "Пульт Тул 2.0.0")

        SectionTitle("Оформление", Modifier.padding(horizontal = 20.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text("Цвет акцента", color = Pal.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Accents.forEachIndexed { i, a ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(42.dp).clip(CircleShape).background(a.brush)
                                .then(if (i == s.accent) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                                .clickable { vm.updateSettings(s.copy(accent = i)); vm.haptic(12) },
                            contentAlignment = Alignment.Center
                        ) { if (i == s.accent) Icon(Icons.Filled.Check, null, tint = Color.White) }
                        Text(a.name, color = Pal.textDim, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            SettingToggle("AMOLED-тема", "Чистый чёрный фон — экономит заряд на OLED-экранах", s.amoled) { vm.updateSettings(s.copy(amoled = it)) }
        }

        SectionTitle("Управление", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp), padding = 6.dp) {
            SettingToggle("Вибрация при нажатии", "Тактильный отклик кнопок", s.vibration) { vm.updateSettings(s.copy(vibration = it)) }
            SettingToggle("Кнопки громкости телефона", "Управляют громкостью телевизора на экране пульта", s.volumeKeys) { vm.updateSettings(s.copy(volumeKeys = it)) }
            SettingToggle("Не гасить экран", "Экран телефона не выключается, пока открыт пульт", s.keepScreenOn) { vm.updateSettings(s.copy(keepScreenOn = it)) }
            SettingToggle("Автоподключение", "При запуске подключаться к последнему телевизору", s.autoConnect) { vm.updateSettings(s.copy(autoConnect = it)) }
            SettingToggle("Встряхнуть — без звука", "Резко встряхните телефон дважды, чтобы выключить/включить звук ТВ", s.shakeMute) { vm.updateSettings(s.copy(shakeMute = it)) }
        }

        SectionTitle("Сопряжение", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text("Для Android TV / Google TV приложение создаёт собственный сертификат. Сброс потребует заново ввести код с экрана ТВ.",
                color = Pal.textDim, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            GhostButton("Сбросить сертификат Android TV", Modifier.fillMaxWidth()) { confirmReset = true }
        }

        SectionTitle("Как подключиться", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            HelpLine("Google TV / Android TV", "Код из 6 символов появится на экране ТВ — введите его в приложении.")
            HelpLine("Samsung", "Подтвердите запрос «Разрешить» на экране телевизора.")
            HelpLine("LG webOS", "Примите запрос на подключение на экране ТВ.")
            HelpLine("Roku", "Сопряжение не требуется. Включите «Управление мобильными приложениями».")
            HelpLine("Philips", "Работает с JointSpace API; для Android-моделей выберите Android TV.")
            HelpLine("Sony Bravia", "Включите «Предварительный общий ключ» (PSK) в настройках сети ТВ и введите его.")
            HelpLine("Ссылки и YouTube", "Кнопка 🔗 на пульте или «Поделиться» → «Пульт Тул» из YouTube/браузера отправит ссылку на ТВ.")
            HelpLine("Жестовый пульт", "Кнопка ✋: свайпы — стрелки, касание — OK, двойное — Назад, удержание — Домой, два пальца — громкость.")
            HelpLine("Диапазон портов", "В «Инструменты» → «Диапазон»: сканируйте свою /24 на порты 8000/37777 (или свой список) и сохраните IP:port в TXT.")
            HelpLine("Чистка ТВ (ADB)", "Вкладка «Чистка»: включите на ТВ отладку, найдите его в сети или подключите по коду (Android 11+), затем чистка, YouTube, лаунчер, DNS и откат.")
        }

        SectionTitle("О приложении", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        AboutCard()
    }
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("Сбросить сертификат?") },
        text = { Text("Все Android TV нужно будет подключить заново по коду.") },
        confirmButton = { TextButton(onClick = { vm.resetCertificate(); confirmReset = false }) { Text("Сбросить", color = Pal.red) } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } }
    )
}

@Composable
private fun SettingToggle(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val accent = LocalAccent.current
    Row(Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 10.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.text, fontSize = 15.sp)
            Text(sub, color = Pal.textDim, fontSize = 12.sp)
        }
        Switch(value, onChange, colors = SwitchDefaults.colors(checkedTrackColor = accent.a, checkedThumbColor = Color.White))
    }
}

@Composable
private fun HelpLine(title: String, text: String) {
    Column(Modifier.padding(vertical = 5.dp)) {
        Text(title, color = Pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(text, color = Pal.textDim, fontSize = 12.sp)
    }
}

@Composable
private fun AboutCard() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var showLicenses by remember { mutableStateOf(false) }
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: ""
    }
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Text("Пульт Тул $version", color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Пульт для ТВ, сетевые инструменты и ADB-чистка Android TV.", color = Pal.textDim, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Раздел «Чистка» основан на ЧистыйТВ (by-sonic, MIT). ADB: libadb-android (MuntashirAkon, Apache-2.0; части BSD-3-Clause). " +
                "SPAKE2 — собственная реализация. BouncyCastle, Conscrypt, OkHttp, AndroidX.",
            color = Pal.textDim, fontSize = 12.sp
        )
        Spacer(Modifier.height(10.dp))
        GhostButton("Лицензии", Modifier.fillMaxWidth()) { showLicenses = true }
    }
    if (showLicenses) {
        val text = remember {
            val names = listOf("NOTICE.txt", "MIT-ChistyTV.txt", "Apache-2.0.txt", "BSD-3-Clause.txt")
            names.joinToString("\n\n════════ ") { n ->
                n + "\n" + runCatching { ctx.assets.open("licenses/$n").use { it.readBytes().toString(Charsets.UTF_8) } }.getOrDefault("")
            }
        }
        AlertDialog(
            onDismissRequest = { showLicenses = false },
            title = { Text("Лицензии") },
            text = {
                androidx.compose.foundation.layout.Box(Modifier.height(420.dp).verticalScroll(rememberScrollState())) {
                    Text(text, fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showLicenses = false }) { Text("Закрыть") } }
        )
    }
}
