package com.pultitool.remote

import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pultitool.remote.adb.AdbDiscovery
import com.pultitool.remote.adb.AdbKeys
import com.pultitool.remote.adb.FoundTv
import com.pultitool.remote.adb.TvConnection
import com.pultitool.remote.clean.ApkCache
import com.pultitool.remote.clean.Db
import com.pultitool.remote.clean.HttpNet
import com.pultitool.remote.clean.Line
import com.pultitool.remote.clean.Output
import com.pultitool.remote.clean.PackageEntry
import com.pultitool.remote.clean.Tone
import com.pultitool.remote.clean.TvApp
import com.pultitool.remote.clean.TvInfo
import com.pultitool.remote.clean.TvReport
import com.pultitool.remote.clean.TvSession
import com.pultitool.remote.clean.TvTools
import com.pultitool.remote.util.Achievements
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Экраны раздела «Чистка». */
enum class AdbScreen(val title: String) {
    START("Чистка ТВ"),
    PAIR("Подключение по коду"),
    CONNECTING("Подключение"),
    HOME("Чистка ТВ"),
    CLEAN("Чистка"),
    YOUTUBE("YouTube без рекламы"),
    LAUNCHER("Лаунчер"),
    DNS("Блокировка рекламы DNS"),
    RESTORE("Откат"),
    REPORT("Отчёт о ТВ"),
    SHELL("Оболочка ADB"),
    APPS("Приложения ТВ"),
    INSTALL("Установить APK"),
    SYSTEM("Питание и снимок экрана"),
    GUIDE("Как включить ADB"),
}

/**
 * Раздел «Чистка»: ADB по сети с телефона (порт 5555 и беспроводная отладка Android 11+),
 * чистка рекламы и слежки, YouTube, лаунчер, DNS, откат, отчёт и ADB-инструменты.
 * Логика чистки перенесена из ЧистогоТВ (MIT).
 */
class AdbViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication()
    private val prefs = app.getSharedPreferences("pulti_adb", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val net = HttpNet()
    val discovery = AdbDiscovery(app)

    // ─── Навигация ──────────────────────────────────────────────────────

    var screen by mutableStateOf(AdbScreen.START)
        private set
    private val stack = ArrayDeque<AdbScreen>()

    fun go(to: AdbScreen) {
        if (to == screen) return
        stack.addLast(screen)
        screen = to
        if (to !in setOf(AdbScreen.CONNECTING, AdbScreen.PAIR, AdbScreen.GUIDE)) resetOperation()
    }

    /** false — внутри раздела уходить некуда */
    fun back(): Boolean {
        if (busy) return true
        if (screen == AdbScreen.CONNECTING) cancelConnect()
        if (screen == AdbScreen.HOME || screen == AdbScreen.START) return false
        val prev = stack.removeLastOrNull()
        screen = when {
            prev == null -> if (session != null) AdbScreen.HOME else AdbScreen.START
            prev == AdbScreen.CONNECTING -> AdbScreen.START
            else -> prev
        }
        return true
    }

    private fun goRoot(to: AdbScreen) {
        stack.clear()
        screen = to
    }

    // ─── База пакетов ───────────────────────────────────────────────────

    private val db: Db by lazy {
        Db.parse(ctx.assets.open("packages.json").use { it.readBytes().toString(Charsets.UTF_8) })
    }

    // ─── Вход в раздел: быстрое переподключение без поиска ─────────────

    /** Идёт проверка/переподключение к последнему телевизору */
    var quickTrying by mutableStateOf(false)
        private set
    /** Последний ТВ не ответил при быстром переподключении */
    var lastUnreachable by mutableStateOf(false)
        private set
    private var entered = false

    val lastTv: Triple<String, String, Boolean>?
        get() {
            val a = prefs.getString("last_address", null) ?: return null
            return Triple(a, prefs.getString("last_name", null) ?: a, prefs.getBoolean("last_tls", false))
        }

    /**
     * Вызывается при каждом открытии вкладки. Уже подключены — сразу действия (с тихой проверкой связи).
     * Нет соединения, но есть последний ТВ — пробуем быстро подключиться к нему. Поиск — только по кнопке
     * (или автоматически, если телевизоров ещё не было).
     */
    fun onEnterTab() {
        val c = connection
        if (session != null && c != null) {
            if (screen == AdbScreen.START || screen == AdbScreen.CONNECTING) goRoot(AdbScreen.HOME)
            viewModelScope.launch {
                val alive = withContext(Dispatchers.IO) { runCatching { c.shell("echo ok").contains("ok") }.getOrDefault(false) }
                if (!alive && !busy) quickReconnect()
            }
            return
        }
        if (quickTrying || screen == AdbScreen.CONNECTING) return
        if (lastTv != null) quickReconnect()
        else if (!entered && !scanning && found.isEmpty()) startScan()
        entered = true
    }

    fun quickReconnect() {
        val (address, _, tls) = lastTv ?: return
        val (host, port) = parseAddress(address) ?: return
        quickTrying = true
        lastUnreachable = false
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                val bound = discovery.bindToHome()
                try {
                    if (!reachable(host, port)) throw IOException("не отвечает")
                    val c = TvConnection(keys, deviceName)
                    // Телевизор уже доверяет ключу — окна подтверждения не будет, ждём недолго
                    c.setConfirmTimeout(12)
                    if (!c.connect(host, port, tls)) throw IOException("телевизор не ответил")
                    c.setConfirmTimeout(TvConnection.CONFIRM_SECONDS)
                    Result.success(c to newSession(c))
                } catch (e: Throwable) {
                    Result.failure(e)
                } finally {
                    if (bound) discovery.unbind()
                }
            }
            quickTrying = false
            result.onSuccess { (c, s) -> onConnected(c, s, "$host:$port", tls) }
                .onFailure {
                    lastUnreachable = true
                    if (screen != AdbScreen.START) goRoot(AdbScreen.START)
                }
        }
    }

    private fun reachable(host: String, port: Int): Boolean = try {
        val net = discovery.homeNetwork()
        val s = net?.socketFactory?.createSocket() ?: Socket()
        s.use { it.connect(InetSocketAddress(host, port), 1500) }
        true
    } catch (_: Exception) {
        false
    }

    // ─── Поиск телевизора ───────────────────────────────────────────────

    var scanning by mutableStateOf(false)
        private set
    val found = mutableStateListOf<FoundTv>()
    var scannedNets by mutableStateOf<List<String>>(emptyList())
        private set
    var vpnActive by mutableStateOf(false)
        private set
    private var scanJob: Job? = null
    private var stopMdns: (() -> Unit)? = null

    fun startScan() {
        vpnActive = discovery.vpnActive()
        found.clear()
        scanJob?.cancel()
        stopMdns?.invoke()
        stopMdns = discovery.discoverWireless { tv -> main.post { addFound(tv) } }
        scanning = true
        scanJob = viewModelScope.launch {
            scannedNets = discovery.scanNetworkDebug { tv -> main.post { addFound(tv) } }
            scanning = false
        }
    }

    private fun addFound(tv: FoundTv) {
        if (found.none { it.host == tv.host && it.kind == tv.kind }) found += tv
    }

    fun stopScan() {
        scanJob?.cancel()
        scanning = false
        stopMdns?.invoke()
        stopMdns = null
    }

    /** «Сменить» / «Найти другой»: отключиться и искать заново */
    fun changeTv() {
        disconnect()
        startScan()
    }

    // ─── Подключение ────────────────────────────────────────────────────

    private val keysDir get() = File(ctx.filesDir, "adb")
    private var loadedKeys: AdbKeys? = null
    private val keys: AdbKeys get() = loadedKeys ?: AdbKeys(keysDir).also { loadedKeys = it }

    /** Новый ключ: телевизоры снова спросят «Разрешить отладку?» */
    fun resetAdbKey() {
        disconnect()
        loadedKeys = null
        AdbKeys.reset(keysDir)
    }

    private var connection: TvConnection? = null
    var session by mutableStateOf<TvSession?>(null)
        private set
    var info by mutableStateOf<TvInfo?>(null)
        private set
    var connectedAddress by mutableStateOf<String?>(null)
        private set
    var connectTarget by mutableStateOf("")
        private set
    var connectError by mutableStateOf<String?>(null)
        private set
    var pairError by mutableStateOf<String?>(null)
        private set
    var pairing by mutableStateOf(false)
        private set
    private var connectJob: Job? = null
    private var connectTls = false

    /** Имя телефона в окне «Разрешить отладку?» на телевизоре */
    private val deviceName get() = "Пульт Тул · ${Build.MANUFACTURER} ${Build.MODEL}".trim()

    private fun newSession(c: TvConnection) =
        TvSession(c, db, File(ctx.filesDir, "tv"), ApkCache(File(ctx.cacheDir, "apk"), net), net)

    fun connect(address: String, tls: Boolean = false) {
        val (host, port) = parseAddress(address) ?: run {
            connectError = "Не понял адрес. Пример: 192.168.1.50 или 192.168.1.50:5555"
            return
        }
        stopScan()
        connectTarget = "$host:$port"
        connectTls = tls
        go(AdbScreen.CONNECTING)
        startConnect(host, port, tls)
    }

    fun retryConnect() {
        val (host, port) = parseAddress(connectTarget) ?: return
        startConnect(host, port, connectTls)
    }

    private fun startConnect(host: String, port: Int, tls: Boolean) {
        connectError = null
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                // VPN на телефоне не должен мешать: соединение с телевизором открываем в домашней сети
                val bound = discovery.bindToHome()
                try {
                    val c = TvConnection(keys, deviceName)
                    if (!c.connect(host, port, tls)) throw IOException("телевизор не ответил")
                    Result.success(c to newSession(c))
                } catch (e: Throwable) {
                    Result.failure(e)
                } finally {
                    if (bound) discovery.unbind()
                }
            }
            result.onSuccess { (c, s) -> onConnected(c, s, "$host:$port", tls) }
                .onFailure { e ->
                    if (screen != AdbScreen.CONNECTING) return@onFailure
                    connectError = explain(e, host, port)
                }
        }
    }

    private fun onConnected(c: TvConnection, s: TvSession, address: String, tls: Boolean) {
        if (connection !== c) connection?.close()
        connection = c
        session = s
        info = s.info
        connectedAddress = address
        lastUnreachable = false
        prefs.edit().putString("last_address", address).putString("last_name", s.info.title).putBoolean("last_tls", tls).apply()
        Achievements.unlock("adb_link")
        goRoot(AdbScreen.HOME)
    }

    fun cancelConnect() {
        connectJob?.cancel()
        connectJob = null
    }

    private fun explain(e: Throwable, host: String, port: Int): String {
        val m = e.message.orEmpty()
        return when {
            e is io.github.muntashirakon.adb.AdbPairingRequiredException ->
                "Телевизор просит подключение по коду: «Для разработчиков» → «Беспроводная отладка» → «Подключить по коду»."
            m.contains("ECONNREFUSED", true) || m.contains("refused", true) ->
                "$host:$port не принимает подключение. Проверьте, что на ТВ включена «Отладка по сети» (или «Отладка по USB») и телевизор не перезагружался."
            m.contains("timed out", true) || m.contains("timeout", true) || e is InterruptedException ->
                "Телевизор не ответил. Если на экране ТВ было окно «Разрешить отладку?» — подтвердите его (отметьте «Всегда») и нажмите «Ещё раз»."
            m.contains("EHOSTUNREACH", true) || m.contains("ENETUNREACH", true) || m.contains("No route", true) ->
                "Телевизор недоступен. Телефон и ТВ должны быть в одной Wi-Fi сети" + if (discovery.vpnActive()) "; VPN на телефоне может закрывать доступ к домашней сети." else "."
            m.contains("TLSv1.3", true) ->
                "Этот телефон не поддерживает TLS 1.3, нужный для подключения по коду. Используйте «Отладку по сети» (порт 5555)."
            else -> "Не подключился к $host:$port: ${m.ifBlank { e.javaClass.simpleName }}"
        }
    }

    /** Подключение по коду (Android 11+): пара, затем TLS-подключение к порту беспроводной отладки */
    fun pairAndConnect(pairAddress: String, code: String, connectAddress: String) {
        val pair = parseAddress(pairAddress, defaultPort = null)
        if (pair == null) {
            pairError = "Нужен адрес с портом из окна с кодом, например 192.168.1.50:37123"
            return
        }
        val digits = code.filter { it.isDigit() }
        if (!Regex("^\\d{6}$").matches(digits)) {
            pairError = "Код — это 6 цифр с экрана телевизора"
            return
        }
        pairError = null
        pairing = true
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val bound = discovery.bindToHome()
                try {
                    TvConnection(keys, deviceName).use { it.pair(pair.first, pair.second, digits) }
                } catch (e: Throwable) {
                    pairError = "Не удалось: ${e.message ?: e.javaClass.simpleName}"
                    false
                } finally {
                    if (bound) discovery.unbind()
                }
            }
            pairing = false
            if (!ok) {
                if (pairError == null) pairError = "Телевизор отклонил код. Проверьте цифры — код меняется при каждом открытии окна."
                return@launch
            }
            // Порт подключения — с главного экрана «Беспроводной отладки», он отличается от порта окна с кодом
            val target = connectAddress.ifBlank {
                found.firstOrNull { it.kind == FoundTv.Kind.WIRELESS_DEBUG && it.host == pair.first }?.address.orEmpty()
            }
            if (target.isBlank()) {
                pairError = "Пара создана. Теперь введите IP и порт с главного экрана «Беспроводной отладки» (там другой порт) и нажмите «Подключиться»."
                return@launch
            }
            connect(target, tls = true)
        }
    }

    fun disconnect() {
        session = null
        info = null
        connectedAddress = null
        connection?.close()
        connection = null
        goRoot(AdbScreen.START)
    }

    fun forgetLast() {
        prefs.edit().remove("last_address").remove("last_name").remove("last_tls").apply()
        lastUnreachable = false
    }

    private fun parseAddress(s: String, defaultPort: Int? = AdbDiscovery.ADB_PORT): Pair<String, Int>? {
        val t = s.trim()
        val m = Regex("^([A-Za-z0-9.\\-]+)(?::(\\d{1,5}))?$").find(t) ?: return null
        val port = m.groupValues[2].toIntOrNull() ?: defaultPort ?: return null
        if (port !in 1..65535) return null
        return m.groupValues[1] to port
    }

    // ─── Операции над телевизором ───────────────────────────────────────

    var busy by mutableStateOf(false)
        private set
    val log = mutableStateListOf<Line>()
    private val problems = java.util.concurrent.CopyOnWriteArrayList<String>()

    var lostConnection by mutableStateOf(false)
        private set
    var cleanResult by mutableStateOf<TvSession.CleanResult?>(null)
        private set
    var restoreResult by mutableStateOf<TvSession.RestoreResult?>(null)
        private set
    var dnsResult by mutableStateOf<TvSession.DnsResult?>(null)
        private set
    var dnsEnabled by mutableStateOf<Boolean?>(null)
        private set
    var homeResult by mutableStateOf<TvSession.HomeResult?>(null)
        private set
    var hardResult by mutableStateOf<TvSession.HardResult?>(null)
        private set
    var happResult by mutableStateOf<TvSession.HappResult?>(null)
        private set
    var journal by mutableStateOf<List<String>>(emptyList())
        private set
    var tvReport by mutableStateOf<TvReport?>(null)
        private set

    /** Новый главный экран: LTvLauncher или «Свой лаунчер» из файла */
    var newHomePkg by mutableStateOf(TvSession.LAUNCHER_PACKAGE)
        private set
    var newHomeLabel by mutableStateOf("LTvLauncher")
        private set

    private fun resetOperation() {
        log.clear()
        cleanResult = null
        restoreResult = null
        dnsResult = null
        homeResult = null
        hardResult = null
        happResult = null
    }

    private fun op(clearLog: Boolean = true, block: TvSession.() -> Unit) {
        val s = session ?: return
        if (busy) return
        busy = true
        if (clearLog) log.clear()
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                s.out = Output { line ->
                    if (line.tone == Tone.WARN || line.tone == Tone.FAIL) problems += line.text
                    main.post { log += line }
                }
                try {
                    s.block()
                } catch (e: Throwable) {
                    val lost = e is IOException && !(connection?.connected ?: false)
                    val text = if (lost) "Связь с телевизором потеряна" else "Ошибка: ${e.message ?: e.javaClass.simpleName}"
                    problems += text
                    main.post {
                        log += Line(Tone.FAIL, text)
                        if (lost) lostConnection = true
                    }
                }
            }
            info = s.info
            busy = false
        }
    }

    fun reconnectAfterLoss() {
        lostConnection = false
        val address = connectedAddress ?: prefs.getString("last_address", null) ?: return
        connect(address, prefs.getBoolean("last_tls", false))
    }

    // Чистка: рекомендованное отмечено, «на выбор» (Кинопоиск, Алиса…) — нет
    val selection = mutableStateMapOf<String, Boolean>()
    var plan by mutableStateOf<List<PackageEntry>>(emptyList())
        private set

    fun openClean() {
        val s = session ?: return
        plan = s.plan()
        selection.clear()
        plan.forEach { selection[it.id] = it.action == "disable" }
        go(AdbScreen.CLEAN)
    }

    fun runClean() {
        val chosen = plan.filter { selection[it.id] == true }
        op {
            cleanResult = clean(chosen)
            if (cleanResult?.disable?.done?.isNotEmpty() == true) main.post { Achievements.unlock("cleaner") }
        }
    }

    fun openRestore() {
        go(AdbScreen.RESTORE)
        op { journal = store.recorded() + removedHome() }
    }

    fun runRestore() = op { restoreResult = restore(); journal = store.recorded() + removedHome() }

    fun openDns() {
        go(AdbScreen.DNS)
        op { dnsEnabled = dnsState().enabled }
    }

    fun enableDns() = op { dnsResult = enableDns(); dnsEnabled = dnsState().enabled }

    fun disableDns() = op { disableDns(); dnsEnabled = dnsState().enabled }

    fun installSmartTube() = op(clearLog = false) { installSmartTube() }

    fun installHapp() = op(clearLog = false) { installHapp() }

    fun sendSubscription(url: String) = op(clearLog = false) { happResult = sendHappSubscription(url.trim()) }

    fun openReport() {
        tvReport = null
        go(AdbScreen.REPORT)
        op { tvReport = report("Пульт Тул ${appVersion()}", problems.toList()) }
    }

    private fun appVersion(): String = runCatching {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
    }.getOrNull() ?: ""

    // ─── Лаунчер ────────────────────────────────────────────────────────

    fun makeLtvHome() = op {
        newHomePkg = TvSession.LAUNCHER_PACKAGE
        newHomeLabel = "LTvLauncher"
        if (!launcherInstalled && !installLauncher()) return@op
        homeResult = makeLauncherHome()
    }

    fun checkHomeAgain() = op(clearLog = false) {
        if (homeOpensLauncher(newHomePkg)) {
            out.ok("Готово: «Домой» открывает $newHomeLabel.")
            homeResult = TvSession.HomeResult.OPENS
        } else {
            out.warn("Пока открывается штатный главный экран.")
        }
    }

    fun disableStock() = op(clearLog = false) { hardResult = disableStockLauncher(newHomePkg) }

    val stockLaunchers: List<PackageEntry> get() = session?.stockLaunchers().orEmpty()

    val platformNames: List<String> get() = session?.platforms?.map { it.name }.orEmpty()

    // ─── Установка APK из файлов телефона ───────────────────────────────

    var pickedApk by mutableStateOf<String?>(null)
        private set

    /** Копируем выбранный файл к себе, проверяем, что это APK, и ставим через push + pm install -r */
    fun installFromUri(uri: Uri, asLauncher: Boolean) {
        val s = session ?: return
        if (busy) return
        if (asLauncher) { homeResult = null; hardResult = null }
        op {
            out.info("Читаю файл с телефона…")
            val dir = File(ctx.cacheDir, "picked").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, "picked.apk")
            ctx.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
                ?: throw IOException("Не удалось открыть выбранный файл")
            val pkgInfo = readApk(file)
            if (pkgInfo == null) {
                out.fail("Это не APK-файл (или файл повреждён).")
                file.delete()
                return@op
            }
            val (pkg, label) = pkgInfo
            main.post { pickedApk = "$label ($pkg)" }
            out.info("Файл: $label — $pkg, ${file.length() / 1024} КБ")
            val ok = installApk(file, label)
            file.delete()
            refresh()
            if (!ok) return@op
            main.post { Achievements.unlock("installer") }
            if (asLauncher) {
                newHomePkg = pkg
                newHomeLabel = label
                out.info("Назначаю $label главным экраном…")
                homeResult = makeLauncherHome(pkg, label)
            }
        }
        if (s.info.sdk in 1..20) log += Line(Tone.WARN, "Очень старый Android на ТВ — установка может не пройти.")
    }

    private fun readApk(file: File): Pair<String, String>? {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val pi = (if (Build.VERSION.SDK_INT >= 33) pm.getPackageArchiveInfo(file.path, PackageManager.PackageInfoFlags.of(0))
        else pm.getPackageArchiveInfo(file.path, 0)) ?: return null
        val ai = pi.applicationInfo
        val label = if (ai != null) {
            ai.sourceDir = file.path
            ai.publicSourceDir = file.path
            runCatching { pm.getApplicationLabel(ai).toString() }.getOrNull()
        } else null
        return pi.packageName to (label?.takeIf { it.isNotBlank() } ?: pi.packageName)
    }

    // ─── Менеджер приложений ────────────────────────────────────────────

    val apps = mutableStateListOf<TvApp>()
    var appsLoading by mutableStateOf(false)
        private set

    private val tools: TvTools? get() = session?.let { TvTools(it) }

    fun openApps() {
        go(AdbScreen.APPS)
        loadApps()
    }

    fun loadApps() {
        val t = tools ?: return
        appsLoading = true
        op(clearLog = false) {
            val list = t.apps()
            main.post { apps.clear(); apps.addAll(list); appsLoading = false }
        }
        if (!busy) appsLoading = false
    }

    fun canDisable(app: TvApp): Boolean = tools?.canDisable(app) ?: false

    fun appAction(app: TvApp, action: String) {
        val t = tools ?: return
        op(clearLog = false) {
            when (action) {
                "disable" -> t.disable(app)
                "enable" -> t.enable(app)
                "stop" -> t.forceStop(app)
                "cache" -> t.clearCache(app)
                "launch" -> t.launch(app)
                "uninstall" -> t.uninstall(app)
            }
            val list = t.apps()
            main.post { apps.clear(); apps.addAll(list) }
        }
    }

    // ─── Питание и снимок экрана ────────────────────────────────────────

    var screenshot by mutableStateOf<File?>(null)
        private set

    fun reboot() {
        val t = tools ?: return
        op { t.reboot() }
        main.postDelayed({ if (!busy) disconnect() }, 1500)
    }

    fun softRestart() {
        val t = tools ?: return
        op { t.softRestart() }
    }

    fun tvKey(code: String) {
        val t = tools ?: return
        op(clearLog = false) { t.key(code); out.ok("Отправлено: $code") }
    }

    fun takeScreenshot() {
        val t = tools ?: return
        op {
            out.info("Снимаю экран телевизора…")
            val bytes = t.screenshot()
            val dir = File(ctx.cacheDir, "shots").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(Date())
            val f = File(dir, "tv-$stamp.png")
            f.writeBytes(bytes)
            out.ok("Готово: ${bytes.size / 1024} КБ")
            main.post { screenshot = f; Achievements.unlock("photographer") }
        }
    }

    // ─── Оболочка ADB ───────────────────────────────────────────────────

    data class ShellEntry(val command: String, val output: String)

    val shellHistory = mutableStateListOf<ShellEntry>()

    fun runShell(command: String) {
        val cmd = command.trim()
        if (cmd.isEmpty()) return
        val s = session ?: return
        if (busy) return
        busy = true
        viewModelScope.launch {
            val out = withContext(Dispatchers.IO) {
                runCatching { s.adb.shell(cmd) }.getOrElse { "Ошибка: ${it.message ?: it.javaClass.simpleName}" }
            }
            shellHistory.add(0, ShellEntry(cmd, out.ifBlank { "(нет вывода)" }.let { if (it.length > 60_000) it.take(60_000) + "\n…обрезано" else it }))
            while (shellHistory.size > 20) shellHistory.removeAt(shellHistory.lastIndex)
            busy = false
        }
    }

    override fun onCleared() {
        stopScan()
        connection?.close()
    }

    companion object {
        val SHELL_PRESETS = listOf(
            "Отключённые пакеты" to "pm list packages -d",
            "Сторонние приложения" to "pm list packages -3",
            "Свойства (getprop)" to "getprop",
            "Wi-Fi (dumpsys wifi)" to "dumpsys wifi | head -n 60",
            "Память /data" to "df -h /data",
            "Разрешение экрана" to "wm size; wm density",
            "Текущий экран" to "dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity'",
            "Аптайм" to "uptime",
        )
    }
}
