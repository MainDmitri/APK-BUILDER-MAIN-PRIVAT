package com.pultitool.remote.clean

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/*
 * Ядро чистки телевизора. Перенесено из проекта ЧистыйТВ (MIT, github.com/by-sonic/chistytv)
 * и адаптировано для «Пульт Тул»: база пакетов читается стандартным org.json.
 */

/** Соединение с телевизором по ADB. */
interface Adb {
    /** Команда в shell телевизора; stdout и stderr вместе, без пробелов по краям */
    fun shell(command: String): String

    /** Двоичный вывод команды (screencap -p) */
    fun shellBytes(command: String): ByteArray

    /** Передать файл на телевизор; при ошибке — исключение */
    fun push(source: File, remotePath: String)
}

enum class Tone { INFO, OK, WARN, FAIL, HINT }

data class Line(val tone: Tone, val text: String)

/** Куда ядро пишет ход работы — на экране это живой журнал. */
fun interface Output {
    fun line(line: Line)

    fun info(text: String) = line(Line(Tone.INFO, text))
    fun ok(text: String) = line(Line(Tone.OK, text))
    fun warn(text: String) = line(Line(Tone.WARN, text))
    fun fail(text: String) = line(Line(Tone.FAIL, text))
    fun hint(text: String) = line(Line(Tone.HINT, text))

    companion object {
        val None = Output { }
    }
}

/**
 * Защита от ошибок в базе: такие пакеты не трогаем никогда — HDMI/тюнер, пульт, клавиатура,
 * установщик, настройки, заводские меню, Wi-Fi, WebView, лаунчер CVTE.
 */
object Protect {
    val patterns = listOf(
        "^android$", "^com\\.android\\.systemui$", "^com\\.android\\.settings$", "^com\\.android\\.tv\\.settings$",
        "packageinstaller", "inputmethod", "keyboard", "leanbackime", "\\.ime$", "tvinput", "tvcenter", "tv\\.service",
        "bluetooth", "remote", "factory", "fac$", "\\.hkcfac", "^com\\.android\\.vending$", "^com\\.google\\.android\\.gms$",
        "^com\\.google\\.android\\.gsf$", "setupwraith", "setupwizard", "provision", "networkstack", "wifi", "webview",
        "^com\\.cvte\\.tv\\.launcher", "hdmi", "tuner",
    )

    private val regexes = patterns.map { Regex(it, RegexOption.IGNORE_CASE) }

    fun isProtected(pkg: String): Boolean = regexes.any { it.containsMatchIn(pkg) }
}

data class Platform(
    val id: String,
    val name: String,
    val detectPackages: List<String> = emptyList(),
    val detectManufacturer: String? = null,
)

data class PackageEntry(
    val id: String,
    val platform: String = "any",
    val group: String = "",
    /** disable — отключаем в рекомендуемой чистке, ask — только если отметят, keep — не трогаем никогда */
    val action: String = "ask",
    val title: String = "",
    val note: String = "",
    val launcher: Boolean = false,
    val requires: List<String> = emptyList(),
) {
    val label: String get() = if (note.isNotBlank()) "$title — $note" else title
}

/** База пакетов (assets/packages.json — та же, что у ЧистогоТВ). */
data class Db(
    val version: Int = 0,
    val updated: String = "",
    val platforms: List<Platform> = emptyList(),
    val packages: List<PackageEntry> = emptyList(),
) {
    fun entry(id: String): PackageEntry? = packages.firstOrNull { it.id == id }

    companion object {
        private fun JSONArray?.strings(): List<String> =
            if (this == null) emptyList() else (0 until length()).map { getString(it) }

        fun parse(text: String): Db {
            val o = JSONObject(text.removePrefix("\uFEFF"))
            val pl = o.optJSONArray("platforms") ?: JSONArray()
            val pk = o.optJSONArray("packages") ?: JSONArray()
            return Db(
                version = o.optInt("version", 0),
                updated = o.optString("updated", ""),
                platforms = (0 until pl.length()).map { i ->
                    val p = pl.getJSONObject(i)
                    Platform(
                        id = p.getString("id"),
                        name = p.optString("name", p.getString("id")),
                        detectPackages = p.optJSONArray("detect_packages").strings(),
                        detectManufacturer = if (p.has("detect_manufacturer") && !p.isNull("detect_manufacturer")) p.getString("detect_manufacturer") else null,
                    )
                },
                packages = (0 until pk.length()).map { i ->
                    val p = pk.getJSONObject(i)
                    PackageEntry(
                        id = p.getString("id"),
                        platform = p.optString("platform", "any"),
                        group = p.optString("group", ""),
                        action = p.optString("action", "ask"),
                        title = p.optString("title", p.getString("id")),
                        note = p.optString("note", ""),
                        launcher = p.optBoolean("launcher", false),
                        requires = p.optJSONArray("requires").strings(),
                    )
                },
            )
        }
    }
}

/** Сведения о телевизоре: getprop и списки пакетов. */
data class TvInfo(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val android: String,
    val sdk: Int,
    val abi: String,
    val abiList: String,
    val installed: Set<String>,
    val disabled: Set<String>,
) {
    /** Имя папки с бэкапами и журналом: «Xiaomi-MiTV-MSSP0» */
    val key: String get() = "$manufacturer-$model".replace(Regex("[^\\p{L}\\p{N}_\\-]+"), "_").trim('_').ifEmpty { "tv" }

    val title: String get() = listOf(manufacturer, model).filter { it.isNotBlank() && !it.equals("unknown", ignoreCase = true) }
        .joinToString(" ").ifEmpty { "Телевизор" }

    companion object {
        val PROPS = listOf(
            "ro.product.manufacturer", "ro.product.brand", "ro.product.model", "ro.build.version.release",
            "ro.build.version.sdk", "ro.product.cpu.abi", "ro.product.cpu.abilist",
        )

        fun read(adb: Adb): TvInfo {
            val p = PROPS.associateWith { adb.shell("getprop $it").trim() }
            return TvInfo(
                manufacturer = p.getValue("ro.product.manufacturer"),
                brand = p.getValue("ro.product.brand"),
                model = p.getValue("ro.product.model"),
                android = p.getValue("ro.build.version.release"),
                sdk = p.getValue("ro.build.version.sdk").toIntOrNull() ?: 0,
                abi = p.getValue("ro.product.cpu.abi"),
                abiList = p.getValue("ro.product.cpu.abilist").ifBlank { p.getValue("ro.product.cpu.abi") },
                installed = parsePackages(adb.shell("pm list packages")),
                disabled = parsePackages(adb.shell("pm list packages -d")),
            )
        }

        /** «package:com.foo» по строке; сообщения об ошибках с пробелами пропускаем */
        fun parsePackages(out: String): Set<String> = out.lineSequence()
            .map { it.trim().removePrefix("package:").trim() }
            .filter { it.isNotEmpty() && !it.contains(' ') && !it.contains(':') }
            .toCollection(LinkedHashSet())
    }
}

class Planner(private val db: Db) {
    fun platforms(info: TvInfo): List<Platform> = db.platforms.filter { pl ->
        pl.detectPackages.any { it in info.installed } ||
            pl.detectManufacturer?.let { re ->
                val r = Regex(re, RegexOption.IGNORE_CASE)
                r.containsMatchIn(info.manufacturer) || r.containsMatchIn(info.brand)
            } == true
    }

    /** Что из базы стоит на этом ТВ, ещё не отключено, не keep, не лаунчер и не под защитой */
    fun plan(info: TvInfo): List<PackageEntry> {
        val ids = setOf("any") + platforms(info).map { it.id }
        return db.packages.filter { e ->
            e.id in info.installed && e.platform in ids && e.action != "keep" && !e.launcher &&
                e.id !in info.disabled && !Protect.isProtected(e.id)
        }
    }

    /**
     * Штатный лаунчер и его парные пакеты: на Google TV 14 без setupwraith система уходит
     * в цикл перезагрузок, поэтому отключаются только все вместе и только в отдельном сценарии.
     */
    fun stockLaunchers(info: TvInfo): List<PackageEntry> {
        val stock = mutableListOf<PackageEntry>()
        for (e in db.packages.filter { it.launcher && it.id in info.installed && it.id !in info.disabled }) {
            stock += e
            for (req in e.requires) {
                if (req.isBlank() || req !in info.installed || req in info.disabled) continue
                stock += db.entry(req) ?: PackageEntry(id = req, title = req)
            }
        }
        return stock.distinctBy { it.id }
    }
}
