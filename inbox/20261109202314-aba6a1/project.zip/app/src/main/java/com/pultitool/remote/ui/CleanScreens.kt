package com.pultitool.remote.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.pultitool.remote.AdbScreen
import com.pultitool.remote.AdbViewModel
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.adb.FoundTv
import com.pultitool.remote.clean.Line
import com.pultitool.remote.clean.PackageEntry
import com.pultitool.remote.clean.Tone
import com.pultitool.remote.clean.TvApp
import com.pultitool.remote.clean.TvSession
import com.pultitool.remote.util.FileExport
import java.io.File

private val APK_TYPES = arrayOf("application/vnd.android.package-archive", "application/octet-stream", "*/*")

/** Вкладка «Чистка»: ADB-чистка и инструменты для СВОЕГО Android TV. */
@Composable
fun CleanTab(vm: AppViewModel, adb: AdbViewModel) {
    LaunchedEffect(Unit) { adb.onEnterTab() }
    when (adb.screen) {
        AdbScreen.START -> AdbStartScreen(adb)
        AdbScreen.PAIR -> AdbPairScreen(adb)
        AdbScreen.CONNECTING -> AdbConnectingScreen(adb)
        AdbScreen.HOME -> AdbHomeScreen(adb)
        AdbScreen.CLEAN -> CleanPlanScreen(adb)
        AdbScreen.YOUTUBE -> YouTubeScreen(adb)
        AdbScreen.LAUNCHER -> LauncherScreen(adb)
        AdbScreen.DNS -> AdbDnsScreen(adb)
        AdbScreen.RESTORE -> RestoreScreen(adb)
        AdbScreen.REPORT -> ReportScreen(adb)
        AdbScreen.SHELL -> AdbShellScreen(adb)
        AdbScreen.APPS -> TvAppsScreen(adb)
        AdbScreen.INSTALL -> InstallApkScreen(adb)
        AdbScreen.SYSTEM -> TvSystemScreen(adb)
        AdbScreen.GUIDE -> AdbGuideScreen(adb)
    }
}

// ─── Общие элементы ─────────────────────────────────────────────────────

@Composable
private fun Disclaimer() {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Pal.yellow.copy(alpha = 0.10f))
            .border(1.dp, Pal.yellow.copy(alpha = 0.35f), RoundedCornerShape(18.dp)).padding(12.dp)
    ) {
        Text(
            "⚠ Только для вашего собственного телевизора. Приложения отключаются (pm disable-user), а не удаляются, " +
                "перед изменениями сохраняется бэкап, и всё можно вернуть через «Откат».",
            color = Pal.text, fontSize = 12.sp, lineHeight = 16.sp
        )
    }
}

@Composable
private fun LogView(lines: List<Line>) {
    if (lines.isEmpty()) return
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0x66000000)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        lines.forEach { l ->
            val (mark, color) = when (l.tone) {
                Tone.OK -> "✓" to Pal.green
                Tone.WARN -> "!" to Pal.yellow
                Tone.FAIL -> "✗" to Pal.red
                Tone.HINT -> "→" to LocalAccent.current.b
                Tone.INFO -> "•" to Pal.textDim
            }
            Row {
                Text(mark, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(16.dp))
                Text(l.text, color = if (l.tone == Tone.INFO) Pal.textDim else Pal.text, fontSize = 13.sp, lineHeight = 17.sp)
            }
        }
    }
}

@Composable
private fun BusyRow(busy: Boolean, text: String = "Выполняю…") {
    if (!busy) return
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(Modifier.size(18.dp), color = LocalAccent.current.b, strokeWidth = 2.dp)
        Spacer(Modifier.width(10.dp))
        Text(text, color = Pal.textDim, fontSize = 13.sp)
    }
}

@Composable
private fun LostBanner(adb: AdbViewModel) {
    if (!adb.lostConnection) return
    GlassCard {
        Text("Связь с телевизором потеряна", color = Pal.red, fontWeight = FontWeight.Bold)
        Text("Телевизор мог уснуть или перезагрузиться.", color = Pal.textDim, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        GradientButton("Переподключиться", Modifier.fillMaxWidth()) { adb.reconnectAfterLoss() }
    }
}

@Composable
private fun Body(text: String) = Text(text, color = Pal.textDim, fontSize = 13.sp, lineHeight = 18.sp)

@Composable
private fun SmallChip(text: String, color: Color = LocalAccent.current.b, enabled: Boolean = true, onClick: () -> Unit) {
    Text(
        text,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = if (enabled) 0.18f else 0.06f))
            .border(1.dp, color.copy(alpha = if (enabled) 0.5f else 0.15f), RoundedCornerShape(50))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp),
        color = if (enabled) color else Pal.textDim, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
    )
}

@Composable
private fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = { onDismiss(); onConfirm() }) { Text(confirm, color = Pal.red) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
        containerColor = Color(0xFF1B1730), titleContentColor = Pal.text, textContentColor = Pal.textDim
    )
}

private fun shareText(ctx: Context, subject: String, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, subject))
}

// ─── Подключение ───────────────────────────────────────────────────────

@Composable
private fun AdbStartScreen(adb: AdbViewModel) {
    var ip by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header("Чистка ТВ", "ADB по сети: чистка, YouTube, лаунчер")
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Disclaimer()
            val last = adb.lastTv
            if (adb.quickTrying && last != null) {
                GlassCard {
                    BusyRow(true, "Подключаюсь к ${last.second} (${last.first})…")
                }
            } else if (last != null) {
                GlassCard {
                    Text("Последний телевизор", color = Pal.textDim, fontSize = 12.sp)
                    Text(last.second, color = Pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(last.first + if (adb.lastUnreachable) " — не отвечает" else "", color = if (adb.lastUnreachable) Pal.yellow else Pal.textDim, fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GradientButton("Подключиться", Modifier.weight(1f), glyph = Glyph.LINK) { adb.connect(last.first, last.third) }
                        GhostButton("Забыть") { adb.forgetLast() }
                    }
                }
            }

            SectionTitle("Телевизоры в сети")
            if (adb.scanning) BusyRow(true, "Ищу: порт 5555 в вашей подсети и беспроводную отладку (mDNS)…")
            if (adb.vpnActive) Text("На телефоне включён VPN — если ТВ не находится, отключите его на время.", color = Pal.yellow, fontSize = 12.sp)
            adb.found.forEach { tv -> FoundTvRow(tv) { 
                when (tv.kind) {
                    FoundTv.Kind.NETWORK_DEBUG -> adb.connect(tv.address)
                    FoundTv.Kind.WIRELESS_DEBUG -> adb.connect(tv.address, tls = true)
                    FoundTv.Kind.PAIRING -> adb.go(AdbScreen.PAIR)
                }
            } }
            if (!adb.scanning && adb.found.isEmpty()) {
                Body(if (adb.scannedNets.isEmpty()) "Поиск ещё не запускался." else "В ${adb.scannedNets.joinToString()} телевизоров с ADB не нашлось. Включите отладку на ТВ (см. «Как включить ADB») или введите IP вручную.")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GradientButton(if (adb.scanning) "Ищу…" else "Найти телевизор", Modifier.weight(1f), glyph = Glyph.RADAR, enabled = !adb.scanning) { adb.startScan() }
                if (adb.scanning) GhostButton("Стоп") { adb.stopScan() }
            }

            SectionTitle("Вручную")
            ToolField(ip, { ip = it }, "IP телевизора (например 192.168.1.50 или :5555)", onGo = { adb.connect(ip) })
            GradientButton("Подключиться", Modifier.fillMaxWidth(), enabled = ip.isNotBlank()) { adb.connect(ip) }
            GhostButton("Подключить по коду (Android 11+)", Modifier.fillMaxWidth()) { adb.go(AdbScreen.PAIR) }
            GhostButton("Как включить ADB на телевизоре", Modifier.fillMaxWidth()) { adb.go(AdbScreen.GUIDE) }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun FoundTvRow(tv: FoundTv, onClick: () -> Unit) {
    val (kind, color) = when (tv.kind) {
        FoundTv.Kind.NETWORK_DEBUG -> "Отладка по сети" to Pal.green
        FoundTv.Kind.WIRELESS_DEBUG -> "Беспроводная отладка" to LocalAccent.current.b
        FoundTv.Kind.PAIRING -> "Ждёт код сопряжения" to Pal.yellow
    }
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GlyphIcon(Glyph.TV, tint = color, size = 26.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(tv.name.ifBlank { tv.host }, color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(tv.address, color = Pal.textDim, fontSize = 12.sp)
        }
        Chip(kind, color)
    }
}

@Composable
private fun AdbPairScreen(adb: AdbViewModel) {
    val pairFound = adb.found.firstOrNull { it.kind == FoundTv.Kind.PAIRING }
    val connFound = adb.found.firstOrNull { it.kind == FoundTv.Kind.WIRELESS_DEBUG }
    var pairAddr by remember { mutableStateOf(pairFound?.address ?: "") }
    var code by remember { mutableStateOf("") }
    var connAddr by remember { mutableStateOf(connFound?.address ?: "") }
    LaunchedEffect(pairFound, connFound) {
        if (pairAddr.isBlank() && pairFound != null) pairAddr = pairFound.address
        if (connAddr.isBlank() && connFound != null) connAddr = connFound.address
    }
    ToolScaffold("Подключение по коду", "Беспроводная отладка Android 11+", onBack = { adb.back() }) {
        GlassCard {
            Body(
                "1. На ТВ: «Для разработчиков» → «Беспроводная отладка» → включить.\n" +
                    "2. Там же «Подключить по коду» — на экране появятся IP:порт и 6 цифр.\n" +
                    "3. Введите их ниже. Порт для подключения — с главного экрана «Беспроводной отладки», он другой."
            )
        }
        if (!adb.scanning && adb.found.isEmpty()) GhostButton("Найти окно сопряжения автоматически", Modifier.fillMaxWidth()) { adb.startScan() }
        if (adb.scanning) BusyRow(true, "Слушаю mDNS…")
        ToolField(pairAddr, { pairAddr = it }, "IP:порт из окна с кодом")
        ToolField(code, { code = it.filter { c -> c.isDigit() }.take(6) }, "Код из 6 цифр", keyboard = KeyboardType.Number)
        ToolField(connAddr, { connAddr = it }, "IP:порт беспроводной отладки (необязательно)")
        ErrorText(adb.pairError)
        BusyRow(adb.pairing, "Сопряжение…")
        GradientButton("Сопрячь и подключиться", Modifier.fillMaxWidth(), glyph = Glyph.LINK, enabled = !adb.pairing) {
            adb.pairAndConnect(pairAddr, code, connAddr)
        }
        if (connAddr.isNotBlank()) GhostButton("Уже сопряжено — просто подключиться", Modifier.fillMaxWidth()) { adb.connect(connAddr, tls = true) }
    }
}

@Composable
private fun AdbConnectingScreen(adb: AdbViewModel) {
    ToolScaffold("Подключение", adb.connectTarget, onBack = { adb.back() }) {
        GlassCard {
            if (adb.connectError == null) {
                BusyRow(true, "Подключаюсь к ${adb.connectTarget}…")
                Spacer(Modifier.height(12.dp))
                Body("Если телевизор видит телефон впервые, на его экране появится окно «Разрешить отладку по USB?». Отметьте «Всегда разрешать с этого компьютера» и нажмите «ОК» — пультом ТВ.")
            } else {
                Text("Не получилось", color = Pal.red, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(6.dp))
                Text(adb.connectError ?: "", color = Pal.text, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradientButton("Ещё раз", Modifier.weight(1f)) { adb.retryConnect() }
                    GhostButton("Назад") { adb.back() }
                }
            }
        }
        GhostButton("Как включить ADB на телевизоре", Modifier.fillMaxWidth()) { adb.go(AdbScreen.GUIDE) }
    }
}

// ─── Главный экран раздела ─────────────────────────────────────────────

private data class AdbAction(val glyph: Glyph, val title: String, val text: String, val colors: List<Color>, val onClick: () -> Unit)

@Composable
private fun AdbHomeScreen(adb: AdbViewModel) {
    val info = adb.info
    Column(Modifier.fillMaxSize()) {
        Header("Чистка ТВ", "Подключено по ADB")
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(if (adb.lostConnection) Pal.red else Pal.green, 12.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(info?.title ?: "Телевизор", color = Pal.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                        Text(adb.connectedAddress.orEmpty() + (info?.let { " · Android ${it.android}" } ?: ""), color = Pal.textDim, fontSize = 13.sp)
                    }
                }
                val pl = adb.platformNames
                if (pl.isNotEmpty()) { Spacer(Modifier.height(6.dp)); Text("Платформа: ${pl.joinToString()}", color = Pal.textDim, fontSize = 12.sp) }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallChip("Сменить") { adb.disconnect() }
                    SmallChip("Найти другой") { adb.changeTv() }
                }
            }
            LostBanner(adb)
            Disclaimer()

            val actions = listOf(
                AdbAction(Glyph.BROOM, "Чистка", "Отключить рекламу, слежку и мусор", listOf(Color(0xFF00C6FF), Color(0xFF0072FF))) { adb.openClean() },
                AdbAction(Glyph.PLAY, "YouTube", "SmartTube без рекламы + Happ", listOf(Color(0xFFFF3B5C), Color(0xFFFF8A3D))) { adb.go(AdbScreen.YOUTUBE) },
                AdbAction(Glyph.HOME, "Лаунчер", "LTvLauncher или свой лаунчер", listOf(Color(0xFF8E2DE2), Color(0xFF4A00E0))) { adb.go(AdbScreen.LAUNCHER) },
                AdbAction(Glyph.SHIELD, "DNS", "AdGuard DNS на телевизоре", listOf(Color(0xFF11998E), Color(0xFF38EF7D))) { adb.openDns() },
                AdbAction(Glyph.BACK, "Откат", "Вернуть всё как было", listOf(Color(0xFFFFB300), Color(0xFFFF6F00))) { adb.openRestore() },
                AdbAction(Glyph.INFO, "Отчёт", "Модель, сборка, пакеты", listOf(Color(0xFF606C88), Color(0xFF3F4C6B))) { adb.openReport() },
                AdbAction(Glyph.APPS, "Приложения", "Включить, отключить, стоп, кэш", listOf(Color(0xFFDA22FF), Color(0xFF9733EE))) { adb.openApps() },
                AdbAction(Glyph.DOWNLOAD, "Установить APK", "Файл с телефона на ТВ", listOf(Color(0xFF1FA2FF), Color(0xFF12D8FA))) { adb.go(AdbScreen.INSTALL) },
                AdbAction(Glyph.POWER, "Питание и снимок", "Перезагрузка, скриншот ТВ", listOf(Color(0xFFED213A), Color(0xFF93291E))) { adb.go(AdbScreen.SYSTEM) },
                AdbAction(Glyph.CODE, "Оболочка ADB", "Свои команды и пресеты", listOf(Color(0xFF232526), Color(0xFF414345))) { adb.go(AdbScreen.SHELL) },
            )
            actions.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { a -> ActionTile(a, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            GhostButton("Как включить ADB на телевизоре", Modifier.fillMaxWidth()) { adb.go(AdbScreen.GUIDE) }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ActionTile(a: AdbAction, modifier: Modifier) {
    Column(
        modifier.height(128.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(a.colors.map { it.copy(alpha = 0.30f) }))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(22.dp))
            .clickable(onClick = a.onClick).padding(14.dp)
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(a.colors)), contentAlignment = Alignment.Center) {
            GlyphIcon(a.glyph, tint = Color.White, size = 22.dp)
        }
        Spacer(Modifier.height(8.dp))
        Text(a.title, color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
        Text(a.text, color = Pal.textDim, fontSize = 11.sp, lineHeight = 14.sp, maxLines = 2)
    }
}

// ─── Чистка ────────────────────────────────────────────────────────────

@Composable
private fun CleanPlanScreen(adb: AdbViewModel) {
    val plan = adb.plan
    val recommended = plan.filter { it.action == "disable" }
    val optional = plan.filter { it.action != "disable" }
    val chosen = plan.count { adb.selection[it.id] == true }
    ToolScaffold("Чистка", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        if (plan.isEmpty()) {
            GlassCard { Body("Известного мусора на этом телевизоре не нашёл — или он уже отключён. Рекламные ряды главного экрана убирает «Лаунчер».") }
        } else if (adb.cleanResult == null) {
            Body("Перед отключением сохраняется бэкап списка пакетов и настроек, а журнал пишется и на телефон, и на сам телевизор — «Откат» вернёт всё обратно.")
            if (recommended.isNotEmpty()) {
                SectionTitle("Рекомендуется отключить (${recommended.size})")
                recommended.forEach { PackageRow(it, adb) }
            }
            if (optional.isNotEmpty()) {
                SectionTitle("На ваш выбор (${optional.size})")
                Body("Эти приложения кому-то нужны (Кинопоиск, Алиса, магазины…). Отметьте только то, чем не пользуетесь.")
                optional.forEach { PackageRow(it, adb) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallChip("Только рекомендуемые") { plan.forEach { adb.selection[it.id] = it.action == "disable" } }
                SmallChip("Снять всё") { plan.forEach { adb.selection[it.id] = false } }
            }
            GradientButton("Отключить выбранное ($chosen)", Modifier.fillMaxWidth(), glyph = Glyph.BROOM, enabled = chosen > 0 && !adb.busy) { adb.runClean() }
        }
        BusyRow(adb.busy)
        LogView(adb.log)
        if (adb.cleanResult != null && !adb.busy) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GhostButton("Перезагрузить ТВ") { adb.reboot() }
                GhostButton("Лаунчер") { adb.go(AdbScreen.LAUNCHER) }
            }
        }
    }
}

@Composable
private fun PackageRow(e: PackageEntry, adb: AdbViewModel) {
    val checked = adb.selection[e.id] == true
    Row(
        Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).clickable { adb.selection[e.id] = !checked }.padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked, { adb.selection[e.id] = it }, colors = CheckboxDefaults.colors(checkedColor = LocalAccent.current.a))
        Column(Modifier.weight(1f).padding(vertical = 6.dp)) {
            Text(e.title.ifBlank { e.id }, color = Pal.text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            if (e.note.isNotBlank()) Text(e.note, color = Pal.textDim, fontSize = 12.sp, lineHeight = 15.sp)
            Text(e.id, color = Pal.textDim.copy(alpha = 0.6f), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

// ─── YouTube ───────────────────────────────────────────────────────────

@Composable
private fun YouTubeScreen(adb: AdbViewModel) {
    val s = adb.session
    var sub by remember { mutableStateOf("") }
    ToolScaffold("YouTube без рекламы", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        GlassCard {
            Text("SmartTube", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Body("Свободный клиент YouTube для ТВ без рекламы. Скачивается с официальных релизов GitHub (yuliskov/SmartTube) под процессор телевизора, подпись издателя проверяется перед установкой.")
            Spacer(Modifier.height(6.dp))
            val st = s?.smartTubeInstalled.orEmpty()
            Text(if (st.isEmpty()) "Не установлен" else "Установлен: ${st.joinToString()}", color = if (st.isEmpty()) Pal.textDim else Pal.green, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            GradientButton(if (s?.smartTubeCurrent == true) "Обновить SmartTube" else "Установить SmartTube", Modifier.fillMaxWidth(), glyph = Glyph.DOWNLOAD, enabled = !adb.busy) { adb.installSmartTube() }
        }
        GlassCard {
            Text("Happ (VPN-клиент)", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Body("Нужен, если YouTube у вас открывается только через VPN. Скачивается с официального GitHub (Happ-proxy/happ-android). Подписку вы берёте у своего провайдера VPN.")
            Spacer(Modifier.height(6.dp))
            Text(if (s?.happInstalled == true) "Установлен" else "Не установлен", color = if (s?.happInstalled == true) Pal.green else Pal.textDim, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            GhostButton(if (s?.happInstalled == true) "Переустановить Happ" else "Установить Happ", Modifier.fillMaxWidth()) { if (!adb.busy) adb.installHapp() }
            if (s?.happInstalled == true) {
                Spacer(Modifier.height(10.dp))
                ToolField(sub, { sub = it.trim() }, "Ссылка подписки (необязательно)")
                Spacer(Modifier.height(8.dp))
                GhostButton("Отправить подписку в Happ на ТВ", Modifier.fillMaxWidth()) { if (!adb.busy && sub.isNotBlank()) adb.sendSubscription(sub) }
            }
        }
        BusyRow(adb.busy, "Скачиваю и устанавливаю…")
        LogView(adb.log)
    }
}

// ─── Лаунчер ───────────────────────────────────────────────────────────

@Composable
private fun LauncherScreen(adb: AdbViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) adb.installFromUri(uri, asLauncher = true) }
    var confirmStock by remember { mutableStateOf(false) }
    ToolScaffold("Лаунчер", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Body("Рекламные ряды главного экрана рисует штатный лаунчер. Новый главный экран ставится рядом и назначается на кнопку «Домой»; штатный остаётся на месте.")
        GlassCard {
            Text("LTvLauncher", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Body("Лёгкий лаунчер без рекламы, с официального GitHub (leanbitlab-org/LtvLauncher), подпись проверяется.")
            Spacer(Modifier.height(10.dp))
            GradientButton("Поставить LTvLauncher", Modifier.fillMaxWidth(), glyph = Glyph.HOME, enabled = !adb.busy) { adb.makeLtvHome() }
        }
        GlassCard {
            Text("Свой лаунчер", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Body("Выберите APK лаунчера из файлов телефона: приложение установит его на ТВ, назначит главным экраном и проверит кнопкой «Домой».")
            adb.pickedApk?.let { Text("Файл: $it", color = Pal.textDim, fontSize = 12.sp) }
            Spacer(Modifier.height(10.dp))
            GhostButton("Выбрать APK лаунчера", Modifier.fillMaxWidth()) { if (!adb.busy) picker.launch(APK_TYPES) }
        }
        BusyRow(adb.busy)
        LogView(adb.log)

        when (adb.homeResult) {
            TvSession.HomeResult.STUBBORN -> GhostButton("Проверить кнопку «Домой» ещё раз", Modifier.fillMaxWidth()) { adb.checkHomeAgain() }
            TvSession.HomeResult.OPENS -> {
                val stock = adb.stockLaunchers
                if (stock.isNotEmpty() && adb.hardResult == null) {
                    GlassCard {
                        Text("Отключить штатный лаунчер?", color = Pal.yellow, fontWeight = FontWeight.Bold)
                        Body("Необязательно. Делается только если «${adb.newHomeLabel}» уже открывается по «Домой». Отключаются вместе: ${stock.joinToString { it.id }}. Если сохранённая сеть Wi-Fi принадлежит одному из них — отменю. Вернуть можно через «Откат».")
                        Spacer(Modifier.height(8.dp))
                        GhostButton("Отключить штатный лаунчер", Modifier.fillMaxWidth()) { confirmStock = true }
                    }
                }
            }
            else -> {}
        }
    }
    if (confirmStock) ConfirmDialog(
        "Отключить штатный лаунчер?",
        "Новый главный экран: ${adb.newHomeLabel}. Перед отключением проверю кнопку «Домой» и Wi-Fi; если что-то пойдёт не так — сразу верну штатный.",
        "Отключить", onConfirm = { adb.disableStock() }, onDismiss = { confirmStock = false }
    )
}

// ─── DNS, откат, отчёт ─────────────────────────────────────────────────

@Composable
private fun AdbDnsScreen(adb: AdbViewModel) {
    ToolScaffold("Блокировка рекламы DNS", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Body("Частный DNS (DNS-over-TLS) с AdGuard DNS режет рекламу и трекеры во всех приложениях телевизора. Нужен Android 9+. Если провайдер блокирует порт 853 и интернет пропадёт — настройка сразу откатится.")
        GlassCard {
            Text(
                when (adb.dnsEnabled) { true -> "AdGuard DNS включён"; false -> "AdGuard DNS выключен"; null -> "Проверяю…" },
                color = if (adb.dnsEnabled == true) Pal.green else Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
            Spacer(Modifier.height(10.dp))
            if (adb.dnsEnabled == true) GhostButton("Выключить и вернуть как было", Modifier.fillMaxWidth()) { if (!adb.busy) adb.disableDns() }
            else GradientButton("Включить AdGuard DNS", Modifier.fillMaxWidth(), glyph = Glyph.SHIELD, enabled = !adb.busy && adb.dnsEnabled != null) { adb.enableDns() }
        }
        BusyRow(adb.busy)
        LogView(adb.log)
    }
}

@Composable
private fun RestoreScreen(adb: AdbViewModel) {
    var confirm by remember { mutableStateOf(false) }
    ToolScaffold("Откат", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Body("Включает обратно всё, что отключалось через «Пульт Тул» (журнал на телефоне и на ТВ в /data/local/tmp/chistytv), и штатный главный экран, если он был убран.")
        if (adb.journal.isNotEmpty()) {
            SectionTitle("В журнале (${adb.journal.size})")
            MonoBox(adb.journal.joinToString("\n"))
            GradientButton("Включить всё обратно", Modifier.fillMaxWidth(), glyph = Glyph.BACK, enabled = !adb.busy) { confirm = true }
        } else if (!adb.busy) {
            GlassCard { Body("Журнал пуст — возвращать нечего.") }
        }
        BusyRow(adb.busy)
        LogView(adb.log)
    }
    if (confirm) ConfirmDialog("Вернуть как было?", "Будут включены ${adb.journal.size} пакетов.", "Вернуть", onConfirm = { adb.runRestore() }, onDismiss = { confirm = false })
}

@Composable
private fun ReportScreen(adb: AdbViewModel) {
    val ctx = LocalContext.current
    val r = adb.tvReport
    ToolScaffold("Отчёт о ТВ", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Body("Модель, сборка, платформа и системные пакеты — для поиска проблем. Без IP, MAC, серийного номера и списка ваших приложений.")
        BusyRow(adb.busy, "Собираю отчёт…")
        if (r != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GradientButton("Поделиться", Modifier.weight(1f)) { shareText(ctx, r.title, r.text) }
                GhostButton("Копировать") { copyText(ctx, r.text) }
            }
            MonoBox(r.text)
        }
        LogView(adb.log.filter { it.tone == Tone.FAIL })
    }
}

// ─── Оболочка ADB ──────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdbShellScreen(adb: AdbViewModel) {
    val ctx = LocalContext.current
    var cmd by remember { mutableStateOf("") }
    ToolScaffold("Оболочка ADB", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Text("Команды выполняются на телевизоре с правами shell. Не запускайте то, в чём не уверены.", color = Pal.yellow, fontSize = 12.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            AdbViewModel.SHELL_PRESETS.forEach { (title, c) -> SmallChip(title, enabled = !adb.busy) { cmd = c; adb.runShell(c) } }
        }
        ToolField(cmd, { cmd = it }, "Команда, например: pm list packages -d", onGo = { adb.runShell(cmd) })
        GradientButton("Выполнить", Modifier.fillMaxWidth(), glyph = Glyph.CODE, enabled = !adb.busy && cmd.isNotBlank()) { adb.runShell(cmd) }
        BusyRow(adb.busy)
        adb.shellHistory.forEach { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$ ${e.command}", color = LocalAccent.current.b, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.weight(1f))
                SmallChip("Копировать") { copyText(ctx, e.output) }
            }
            MonoBox(e.output)
        }
    }
}

// ─── Приложения ТВ ─────────────────────────────────────────────────────

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TvAppsScreen(adb: AdbViewModel) {
    var filter by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf<Pair<TvApp, String>?>(null) }
    val list = adb.apps.filter {
        when (filter) { 1 -> !it.system; 2 -> it.disabled; else -> true }
    }.filter { query.isBlank() || it.pkg.contains(query, true) || (it.title?.contains(query, true) == true) }
    ToolScaffold("Приложения ТВ", "${adb.apps.size} в списке", onBack = { adb.back() }, trailing = {
        PadButton(size = 42.dp, onClick = { adb.loadApps() }) { GlyphIcon(Glyph.RADAR, tint = Pal.text, size = 20.dp) }
    }) {
        LostBanner(adb)
        Body("Сторонние приложения и всё отключённое. Системные пакеты под защитой (HDMI, тюнер, пульт, клавиатура, установщик, настройки, лаунчер) отключить нельзя.")
        SegmentRow(listOf("Все", "Сторонние", "Отключённые"), filter) { filter = it }
        ToolField(query, { query = it }, "Поиск по пакету")
        BusyRow(adb.busy)
        LogView(adb.log.takeLast(3))
        if (list.isEmpty() && !adb.busy) Body("Пусто.")
        list.forEach { app ->
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(app.title ?: app.pkg.substringAfterLast('.'), color = Pal.text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text(app.pkg, color = Pal.textDim, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    if (app.disabled) Chip("отключено", Pal.yellow) else if (app.system) Chip("системное", Pal.textDim)
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (app.disabled) SmallChip("Включить", Pal.green, !adb.busy) { adb.appAction(app, "enable") }
                    else {
                        SmallChip("Открыть", enabled = !adb.busy) { adb.appAction(app, "launch") }
                        SmallChip("Стоп", enabled = !adb.busy) { adb.appAction(app, "stop") }
                        SmallChip("Кэш", enabled = !adb.busy) { adb.appAction(app, "cache") }
                        SmallChip("Отключить", Pal.yellow, !adb.busy && adb.canDisable(app)) { confirm = app to "disable" }
                    }
                    if (!app.system) SmallChip("Удалить", Pal.red, !adb.busy) { confirm = app to "uninstall" }
                }
            }
        }
    }
    confirm?.let { (app, action) ->
        ConfirmDialog(
            if (action == "uninstall") "Удалить приложение?" else "Отключить приложение?",
            if (action == "uninstall") "${app.pkg} будет удалено с телевизора вместе с данными." else "${app.pkg} исчезнет с телевизора, пока его не включат обратно (здесь или в «Откат»).",
            if (action == "uninstall") "Удалить" else "Отключить",
            onConfirm = { adb.appAction(app, action) }, onDismiss = { confirm = null }
        )
    }
}

// ─── Установка APK ─────────────────────────────────────────────────────

@Composable
private fun InstallApkScreen(adb: AdbViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) adb.installFromUri(uri, asLauncher = false) }
    ToolScaffold("Установить APK", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        Body("Выберите APK-файл в памяти телефона — он будет передан на телевизор (adb push) и установлен (pm install -r). Обновление поверх уже установленного приложения сохраняет его данные.")
        GradientButton("Выбрать APK на телефоне", Modifier.fillMaxWidth(), glyph = Glyph.DOWNLOAD, enabled = !adb.busy) { picker.launch(APK_TYPES) }
        adb.pickedApk?.let { Text("Последний файл: $it", color = Pal.textDim, fontSize = 12.sp) }
        BusyRow(adb.busy, "Передаю и устанавливаю…")
        LogView(adb.log)
        Text("Ставьте APK только из источников, которым доверяете.", color = Pal.textDim, fontSize = 12.sp)
    }
}

// ─── Питание и снимок экрана ───────────────────────────────────────────

@Composable
private fun TvSystemScreen(adb: AdbViewModel) {
    val ctx = LocalContext.current
    var confirmReboot by remember { mutableStateOf(false) }
    val shot = adb.screenshot
    val bitmap = remember(shot) { shot?.let { runCatching { BitmapFactory.decodeFile(it.path) }.getOrNull() } }
    ToolScaffold("Питание и снимок", adb.info?.title, onBack = { adb.back() }) {
        LostBanner(adb)
        SectionTitle("Снимок экрана ТВ")
        GradientButton("Сделать снимок экрана", Modifier.fillMaxWidth(), glyph = Glyph.EYE, enabled = !adb.busy) { adb.takeScreenshot() }
        if (bitmap != null && shot != null) {
            Image(bitmap.asImageBitmap(), "Снимок экрана телевизора", Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)), contentScale = ContentScale.FillWidth)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GradientButton("Сохранить", Modifier.weight(1f)) {
                    val r = runCatching { FileExport.saveImage(ctx, shot.name, shot.readBytes()) }
                    android.widget.Toast.makeText(ctx, r.fold({ "Сохранено: $it" }, { "Не удалось: ${it.message}" }), android.widget.Toast.LENGTH_LONG).show()
                }
                GhostButton("Поделиться") { shareFile(ctx, shot, "image/png") }
            }
        }
        SectionTitle("Кнопки")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SmallChip("Домой", enabled = !adb.busy) { adb.tvKey("KEYCODE_HOME") }
            SmallChip("Назад", enabled = !adb.busy) { adb.tvKey("KEYCODE_BACK") }
            SmallChip("Сон", enabled = !adb.busy) { adb.tvKey("KEYCODE_SLEEP") }
            SmallChip("Разбудить", enabled = !adb.busy) { adb.tvKey("KEYCODE_WAKEUP") }
        }
        SectionTitle("Питание")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton("Перезагрузить ТВ", Modifier.weight(1f)) { if (!adb.busy) confirmReboot = true }
            GhostButton("Мягкий перезапуск", Modifier.weight(1f)) { if (!adb.busy) adb.softRestart() }
        }
        Body("Мягкий перезапуск перезапускает оболочку Android без выключения — работает не на всех прошивках. Беспроводная отладка Android 11+ после перезагрузки выключается.")
        BusyRow(adb.busy)
        LogView(adb.log)
    }
    if (confirmReboot) ConfirmDialog("Перезагрузить телевизор?", "Связь по ADB прервётся, подключитесь снова через минуту.", "Перезагрузить",
        onConfirm = { adb.reboot() }, onDismiss = { confirmReboot = false })
}

private fun shareFile(ctx: Context, file: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
    val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, "Поделиться"))
}

// ─── Как включить ADB ──────────────────────────────────────────────────

@Composable
private fun AdbGuideScreen(adb: AdbViewModel) {
    ToolScaffold("Как включить ADB", "Один раз на телевизоре", onBack = { adb.back() }) {
        GuideCard("Android TV / Google TV", listOf(
            "Настройки → Система → Об устройстве (иногда «Настройки устройства → Об устройстве»).",
            "7 раз нажмите на «Сборка» (на части Xiaomi — на «Версия ядра»), пока не появится «Вы стали разработчиком».",
            "Назад → «Для разработчиков» → включите «Отладка по USB» и, если есть, «Отладка по сети».",
            "Подключитесь из «Пульт Тул» и подтвердите на ТВ окно «Разрешить отладку?» с галочкой «Всегда».",
        ))
        GuideCard("Android 11+ без «Отладки по сети»", listOf(
            "«Для разработчиков» → «Беспроводная отладка» → включить.",
            "«Подключить по коду» → в приложении выберите «Подключить по коду» и введите IP:порт и 6 цифр.",
            "Порт подключения показан на главном экране беспроводной отладки и меняется после перезагрузки.",
        ))
        GuideCard("Яндекс ТВ (платы CVTE)", listOf(
            "Сначала обычный путь через «Об устройстве → Сборка ×7».",
            "Если пунктов отладки нет — сервисное меню платы: на родном пульте коротко зажмите «Меню», затем быстро ← ↑ ← ↑ и «Назад»; там включите только пункт ADB.",
            "В сервисном меню больше ничего не трогайте — пункты панели, подсветки и заводского режима могут испортить изображение.",
            "Иногда окно «Разрешить отладку?» появляется только после перезагрузки ТВ из розетки.",
        ))
        GuideCard("Салют ТВ / SberBox", listOf(
            "Включите ADB для устройства в Sber Studio (раздел «Мои устройства») под тем же Сбер ID, затем перезагрузите ТВ.",
        ))
        GuideCard("Если не подключается", listOf(
            "unauthorized — подтвердите окно на ТВ; нет окна — выключите и включите отладку и перезагрузите ТВ.",
            "connection refused — отладка выключена, ТВ перезагрузился или неверный порт.",
            "таймаут — телефон и ТВ в разных сетях (гостевой Wi-Fi, изоляция клиентов) или мешает VPN на телефоне.",
            "Samsung (Tizen), LG (webOS) и VIDAA — не Android: чистка с ними не работает, но обычный пульт работает.",
        ))
        Body("Когда закончите, отладку на ТВ лучше выключить. На Mi Box при включённой отладке может не работать USB-порт.")
    }
}

@Composable
private fun GuideCard(title: String, steps: List<String>) {
    GlassCard {
        Text(title, color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(6.dp))
        steps.forEachIndexed { i, s ->
            Row(Modifier.padding(vertical = 3.dp)) {
                Text("${i + 1}.", color = LocalAccent.current.b, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.width(22.dp))
                Text(s, color = Pal.text, fontSize = 13.sp, lineHeight = 18.sp)
            }
        }
    }
}
