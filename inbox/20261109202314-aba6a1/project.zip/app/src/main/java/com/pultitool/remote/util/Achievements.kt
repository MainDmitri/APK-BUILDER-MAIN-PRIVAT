package com.pultitool.remote.util

import android.content.Context
import com.pultitool.remote.data.Store
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Achievement(val id: String, val title: String, val description: String, val emoji: String)

/** Достижения хранятся в SharedPreferences (id → время получения). */
object Achievements {
    val all = listOf(
        Achievement("first_connect", "Первый контакт", "Подключиться к телевизору", "📺"),
        Achievement("presses_100", "Разогрев", "Нажать 100 кнопок пульта", "👆"),
        Achievement("presses_1000", "Мастер пульта", "Нажать 1000 кнопок пульта", "🏆"),
        Achievement("collector", "Коллекционер", "Сохранить 3 устройства", "🗂"),
        Achievement("tv_scan", "Охотник за ТВ", "Выполнить поиск телевизоров", "📡"),
        Achievement("typist", "Клавиатурный ниндзя", "Отправить текст на ТВ", "⌨️"),
        Achievement("streamer", "Кинозал", "Открыть ссылку или YouTube на ТВ", "🎬"),
        Achievement("shaker", "Тише!", "Выключить звук встряхиванием", "🤳"),
        Achievement("gesture", "Без кнопок", "Использовать жестовый пульт", "✋"),
        Achievement("auditor", "Аудитор", "Провести аудит своей сети", "🛡"),
        Achievement("fortress", "Крепость", "Получить оценку безопасности 90+", "🏰"),
        Achievement("pinger", "Пинг-понг", "Отправить 100 пингов", "🏓"),
        Achievement("tracer", "Следопыт", "Выполнить трассировку маршрута", "🧭"),
        Achievement("porter", "Привратник", "Проверить порты устройства", "🚪"),
        Achievement("ranger", "Сетевой разведчик", "Просканировать диапазон IP на открытые порты", "📡"),
        Achievement("dns", "Знаток имён", "Выполнить DNS-запрос", "🔤"),
        Achievement("globe", "Где я?", "Узнать внешний IP и геолокацию", "🌍"),
        Achievement("subnet", "Сетевой математик", "Посчитать подсеть", "🧮"),
        Achievement("speed", "Замер скорости", "Пройти тест скорости", "⚡"),
        Achievement("rocket", "Ракета", "Скорость загрузки выше 100 Мбит/с", "🚀"),
        Achievement("inspector", "Инспектор", "Отправить HTTP-запрос", "🔍"),
        Achievement("mapper", "Картограф", "Построить карту сети из 5+ устройств", "🗺"),
        Achievement("guardian", "Страж сети", "Включить монитор новых устройств", "👁"),
        Achievement("exporter", "Архивариус", "Сохранить отчёт аудита в файл", "💾"),
        Achievement("night_owl", "Ночная сова", "Пользоваться приложением с 0 до 5 утра", "🦉"),
        Achievement("adb_link", "Отладчик", "Подключиться к телевизору по ADB", "🔌"),
        Achievement("cleaner", "Чистюля", "Провести чистку телевизора", "🧹"),
        Achievement("photographer", "Фотограф", "Сделать снимок экрана телевизора", "📸"),
        Achievement("installer", "Установщик", "Установить APK на телевизор", "📦")
    )

    private var store: Store? = null
    private var appContext: Context? = null
    private val _unlocked = MutableStateFlow<Map<String, Long>>(emptyMap())
    val unlocked: StateFlow<Map<String, Long>> = _unlocked

    fun init(context: Context) {
        if (store != null) return
        appContext = context.applicationContext
        store = Store(context.applicationContext).also { _unlocked.value = it.achievements }
    }

    @Synchronized
    fun unlock(id: String) {
        val s = store ?: return
        if (_unlocked.value.containsKey(id)) return
        val a = all.firstOrNull { it.id == id } ?: return
        val map = _unlocked.value + (id to System.currentTimeMillis())
        _unlocked.value = map
        s.achievements = map
        Events.banner("Достижение получено ${a.emoji}", "${a.title} — ${a.description}", BannerKind.ACHIEVEMENT)
        appContext?.let { Haptics.pattern(it, longArrayOf(0, 30, 60, 30)) }
    }

    /** Увеличивает счётчик и выдаёт достижение при достижении порога. */
    fun count(name: String, thresholds: List<Pair<Long, String>>, delta: Long = 1) {
        val s = store ?: return
        val v = s.addCounter(name, delta)
        thresholds.forEach { (t, id) -> if (v >= t) unlock(id) }
    }
}
