package com.pultitool.remote.clean

/**
 * Отчёт о телевизоре: модель, сборка и системные пакеты.
 * Ни IP, ни MAC, ни серийного номера, ни сторонних приложений — им можно делиться.
 */
class TvReport(val title: String, val text: String) {
    companion object {
        private const val MAX_LINE = 200

        /** В сообщениях об ошибках бывают адреса, ссылки и MAC: в отчёт они не идут */
        fun scrub(line: String): String {
            val t = line
                .replace(Regex("https?://\\S+"), "<ссылка>")
                .replace(Regex("\\b\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?\\b"), "<ip>")
                .replace(Regex("\\b[0-9A-Fa-f]{2}(:[0-9A-Fa-f]{2}){5}\\b"), "<mac>")
                .replace(Regex("(?i)serial\\S*\\s*[:=]\\s*\\S+"), "serial=<скрыт>")
            return if (t.length > MAX_LINE) t.take(MAX_LINE) + "…" else t
        }
    }
}
