package com.pultitool.remote.adb.spake2;

/** Роль в SPAKE2: телефон при сопряжении ADB — Alice (клиент), телевизор — Bob. */
public enum Spake2Role {
    Alice,
    Bob
}
