package com.pultitool.remote.util

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Сохранение текстового файла в общую папку «Загрузки». */
object FileExport {
    /** На Android 9 и ниже нужен WRITE_EXTERNAL_STORAGE. */
    val needsLegacyPermission: Boolean get() = Build.VERSION.SDK_INT < 29

    /** Возвращает путь, понятный пользователю, или бросает исключение. */
    fun saveToDownloads(context: Context, fileName: String, mime: String, content: String): String {
        val bytes = content.toByteArray(Charsets.UTF_8)
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PultTool")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore отказал в создании файла")
            resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Не удалось открыть файл")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Загрузки/PultTool/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "PultTool")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Нет доступа к папке Загрузки")
            val f = File(dir, fileName)
            f.writeBytes(bytes)
            f.absolutePath
        }
    }

    /** Картинка в «Изображения/PultTool» (галерея). */
    fun saveImage(context: Context, fileName: String, bytes: ByteArray, mime: String = "image/png"): String {
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PultTool")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("MediaStore отказал в создании файла")
            resolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw IllegalStateException("Не удалось открыть файл")
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "Изображения/PultTool/$fileName"
        } else {
            @Suppress("DEPRECATION")
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "PultTool")
            if (!dir.exists() && !dir.mkdirs()) throw IllegalStateException("Нет доступа к папке Изображения")
            val f = File(dir, fileName)
            f.writeBytes(bytes)
            f.absolutePath
        }
    }
}
