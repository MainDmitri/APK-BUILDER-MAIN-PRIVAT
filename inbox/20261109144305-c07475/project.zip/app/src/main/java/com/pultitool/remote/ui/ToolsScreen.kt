package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.data.Protocol
import com.pultitool.remote.net.NetUtil

@Composable
fun ToolsScreen(vm: AppViewModel) {
    val devices by vm.devices.collectAsState()
    Button(onClick = { vm.navigate(Screen.ADB) }, modifier = Modifier.padding(vertical = 8.dp)) { Text("ADB Инструменты (Android TV)") }
    val presses by vm.presses.collectAsState()
    var net by remember { mutableStateOf(vm.localNet()) }
    var mac by remember { mutableStateOf(devices.firstOrNull { it.mac.isNotBlank() }?.mac ?: "") }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Header("Сеть и безопасность", "Пентест-инструменты для вашей сети")

        ToolGrid(vm)
        Spacer(Modifier.height(8.dp))

        ToolCard(Glyph.SHIELD, "Аудит безопасности сети",
            "Найти все устройства вашей сети: камеры, регистраторы, роутеры, веб-панели. Проверить, защищены ли они паролем.",
            listOf(Color(0xFFFF3B5C), Color(0xFFFF9100))) { vm.navigate(Screen.AUDIT) }

        ToolCard(Glyph.RADAR, "Поиск телевизоров", "SSDP, mDNS и проверка портов Google TV, Samsung, LG, Roku, Philips, Sony",
            listOf(LocalAccent.current.a, LocalAccent.current.b)) { vm.startScan() }

        SectionTitle("Wake-on-LAN", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text("Включение телевизора или компьютера по сети «магическим пакетом». На ТВ должна быть включена опция «Включение по сети».",
                color = Pal.textDim, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(mac, { mac = it }, label = { Text("MAC-адрес, например AA:BB:CC:DD:EE:FF") }, singleLine = true,
                isError = mac.isNotBlank() && NetUtil.normalizeMac(mac) == null, modifier = Modifier.fillMaxWidth())
            val withMac = devices.filter { it.mac.isNotBlank() }
            if (withMac.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    withMac.take(3).forEach { d -> Chip(d.name, LocalAccent.current.b, Modifier.clickable { mac = d.mac }) }
                }
            }
            Spacer(Modifier.height(10.dp))
            GradientButton("Отправить сигнал включения", Modifier.fillMaxWidth(), glyph = Glyph.POWER,
                enabled = NetUtil.normalizeMac(mac) != null) { vm.wakeMac(NetUtil.normalizeMac(mac) ?: mac) }
        }

        SectionTitle("Моя сеть", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            val n = net
            if (n == null) Text("Нет активного подключения к локальной сети", color = Pal.red, fontSize = 14.sp)
            else {
                InfoRow("Тип", if (n.isWifi) "Wi-Fi" else "Ethernet / другое")
                InfoRow("IP-адрес", "${n.ip}/${n.prefix}")
                InfoRow("Шлюз (роутер)", n.gateway ?: "—")
                InfoRow("DNS", n.dns.joinToString(", ").ifBlank { "—" })
                InfoRow("Интерфейс", n.iface ?: "—")
                InfoRow("Диапазон поиска", "${n.base24}1 – ${n.base24}254")
            }
            Spacer(Modifier.height(8.dp))
            GhostButton("Обновить", Modifier.fillMaxWidth()) { net = vm.localNet() }
        }

        SectionTitle("Статистика", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("$presses", "нажатий", Modifier.weight(1f))
            StatTile("${devices.size}", "устройств", Modifier.weight(1f))
            StatTile("${devices.count { it.favorite }}", "избранных", Modifier.weight(1f))
        }
        val byProto = devices.groupBy { it.protocol }
        if (byProto.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Protocol.entries.forEach { p -> byProto[p]?.let { InfoRow(p.title, "${it.size}") } }
            }
        }
    }
}

@Composable
private fun ToolCard(glyph: Glyph, title: String, text: String, colors: List<Color>, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(colors.map { it.copy(alpha = 0.28f) }))
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(colors)), contentAlignment = Alignment.Center) {
            GlyphIcon(glyph, tint = Color.White, size = 28.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(text, color = Pal.textDim, fontSize = 12.sp)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Pal.text)
    }
}

@Composable
fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, color = Pal.textDim, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(v, color = Pal.text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun StatTile(value: String, label: String, modifier: Modifier) {
    Column(modifier.glass(RoundedCornerShape(20.dp)).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, color = Pal.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(label, color = Pal.textDim, fontSize = 12.sp)
    }
}
