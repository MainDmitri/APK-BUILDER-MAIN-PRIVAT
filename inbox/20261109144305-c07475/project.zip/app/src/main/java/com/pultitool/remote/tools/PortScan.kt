package com.pultitool.remote.tools

import com.pultitool.remote.audit.portName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

data class PortResult(val port: Int, val service: String, val banner: String, val rttMs: Double)

object PortScan {
    const val MAX_PORTS = 10000

    val presets = listOf(
        "Популярные" to "21,22,23,25,53,80,110,139,143,443,445,554,631,1883,3389,5000,5353,5900,8000,8008,8009,8080,8443,8554,9000,37777",
        "Веб" to "80,81,443,591,3000,5000,5001,7000,8000,8001,8008,8080,8081,8088,8443,8888,9000,9443",
        "Камеры" to "80,443,554,8000,8080,8554,8899,10554,34567,37777,37778",
        "ТВ" to "1925,1926,3000,3001,6466,6467,7000,8001,8002,8008,8009,8060,9080",
        "1–1024" to "1-1024"
    )

    /** Разбор диапазона вида "22,80,8000-8100". */
    fun parse(spec: String): List<Int> {
        val set = sortedSetOf<Int>()
        spec.split(',', ' ', ';').map { it.trim() }.filter { it.isNotEmpty() }.forEach { part ->
            if ('-' in part) {
                val a = part.substringBefore('-').trim().toIntOrNull() ?: throw IllegalArgumentException("Неверный диапазон: $part")
                val b = part.substringAfter('-').trim().toIntOrNull() ?: throw IllegalArgumentException("Неверный диапазон: $part")
                val lo = minOf(a, b).coerceIn(1, 65535)
                val hi = maxOf(a, b).coerceIn(1, 65535)
                for (p in lo..hi) { set.add(p); if (set.size > MAX_PORTS) throw IllegalArgumentException("Слишком много портов (максимум $MAX_PORTS)") }
            } else {
                val p = part.toIntOrNull() ?: throw IllegalArgumentException("Неверный порт: $part")
                if (p !in 1..65535) throw IllegalArgumentException("Порт вне диапазона: $p")
                set.add(p)
            }
        }
        if (set.isEmpty()) throw IllegalArgumentException("Укажите хотя бы один порт")
        return set.toList()
    }

    /** Проверка TCP-портов одного хоста. Только подключение и чтение приветствия сервиса — без отправки данных. */
    suspend fun scan(
        host: String,
        ports: List<Int>,
        timeoutMs: Int,
        grabBanner: Boolean,
        onProgress: (Int) -> Unit,
        onOpen: (PortResult) -> Unit
    ) = coroutineScope {
        val sem = Semaphore(100)
        var done = 0
        val lock = Any()
        ports.map { port ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    ensureActive()
                    val start = System.nanoTime()
                    try {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(host, port), timeoutMs)
                            val rtt = (System.nanoTime() - start) / 1_000_000.0
                            var banner = ""
                            if (grabBanner) {
                                try {
                                    s.soTimeout = 900
                                    val buf = ByteArray(160)
                                    val n = s.getInputStream().read(buf)
                                    if (n > 0) banner = String(buf, 0, n, Charsets.ISO_8859_1)
                                        .map { c -> if (c.code in 32..126) c else ' ' }.joinToString("").trim().replace(Regex("\\s+"), " ")
                                } catch (_: Exception) {
                                }
                            }
                            onOpen(PortResult(port, portName(port), banner, rtt))
                        }
                    } catch (_: Exception) {
                    }
                    val d = synchronized(lock) { ++done }
                    if (d % 10 == 0 || d == ports.size) onProgress(d)
                }
            }
        }.awaitAll()
    }

    suspend fun resolve(host: String): String? = withContext(Dispatchers.IO) {
        try { java.net.InetAddress.getByName(host.trim()).hostAddress } catch (_: Exception) { null }
    }

    /**
     * Сканирование диапазона IP × список портов.
     * Только TCP connect (и опционально чтение баннера) — без логинов и эксплойтов.
     */
    suspend fun scanRange(
        hosts: List<String>,
        ports: List<Int>,
        timeoutMs: Int,
        concurrency: Int = 128,
        onProgress: (done: Int, total: Int) -> Unit,
        onHit: (RangeHit) -> Unit
    ) = coroutineScope {
        val total = hosts.size * ports.size
        if (total == 0) return@coroutineScope
        if (total > IpRange.MAX_COMBOS) throw IllegalArgumentException("Слишком много проверок ($total). Уменьшите диапазон или число портов (макс. ${IpRange.MAX_COMBOS}).")
        val sem = Semaphore(concurrency.coerceIn(16, 256))
        var done = 0
        val lock = Any()
        hosts.flatMap { host -> ports.map { port -> host to port } }.map { (host, port) ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    ensureActive()
                    val start = System.nanoTime()
                    var open = false
                    var rtt = 0.0
                    try {
                        Socket().use { s ->
                            s.connect(InetSocketAddress(host, port), timeoutMs)
                            rtt = (System.nanoTime() - start) / 1_000_000.0
                            open = true
                        }
                    } catch (_: Exception) {
                    }
                    if (open) onHit(RangeHit(host, port, portName(port), IpRange.guess(port), rtt))
                    val d = synchronized(lock) { ++done }
                    if (d % 25 == 0 || d == total) onProgress(d, total)
                }
            }
        }.awaitAll()
        onProgress(total, total)
    }
}

/** Найденный открытый порт на IP в диапазоне. */
data class RangeHit(
    val ip: String,
    val port: Int,
    val service: String,
    val guess: String,
    val rttMs: Double
) {
    val line: String get() = "$ip:$port"
}

object IpRange {
    const val MAX_HOSTS = 1024
    const val MAX_COMBOS = 50_000

    fun parseIp(ip: String): Long {
        val t = ip.trim()
        if (!t.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))) throw IllegalArgumentException("Неверный IP: $ip")
        return Subnet.ipToLong(t).also { v ->
            // ipToLong already validates octets via split; re-check 0..255
            t.split('.').forEach { o ->
                val n = o.toInt()
                if (n !in 0..255) throw IllegalArgumentException("Неверный IP: $ip")
            }
            if (v < 0 || v > 0xFFFFFFFFL) throw IllegalArgumentException("Неверный IP: $ip")
        }
    }

    /** Список IP из «начало–конец» (включительно). */
    fun fromStartEnd(start: String, end: String): List<String> {
        val a = parseIp(start)
        val b = parseIp(end)
        val lo = minOf(a, b)
        val hi = maxOf(a, b)
        val count = hi - lo + 1
        if (count <= 0L) throw IllegalArgumentException("Пустой диапазон")
        if (count > MAX_HOSTS) throw IllegalArgumentException("Слишком много адресов (максимум $MAX_HOSTS). Сузьте диапазон.")
        return (lo..hi).map { Subnet.longToIp(it) }
    }

    /** Список IP из CIDR, напр. 192.168.1.0/24 (сеть и broadcast пропускаются при /≤30). */
    fun fromCidr(cidr: String): List<String> {
        val t = cidr.trim()
        val slash = t.indexOf('/')
        if (slash < 0) throw IllegalArgumentException("Укажите CIDR вида 192.168.1.0/24")
        val ip = t.substring(0, slash).trim()
        val prefix = t.substring(slash + 1).trim().toIntOrNull()
            ?: throw IllegalArgumentException("Неверный префикс CIDR")
        if (prefix !in 16..32) throw IllegalArgumentException("Префикс должен быть от /16 до /32 (рекомендуется /24)")
        val baseIp = parseIp(ip)
        val mask = Subnet.prefixMask(prefix)
        val network = baseIp and mask
        val broadcast = network or (mask.inv() and 0xFFFFFFFFL)
        val first = if (prefix <= 30) network + 1 else network
        val last = if (prefix <= 30) broadcast - 1 else broadcast
        if (last < first) return listOf(Subnet.longToIp(network))
        val count = last - first + 1
        if (count > MAX_HOSTS) throw IllegalArgumentException("Слишком много адресов в /$prefix (максимум $MAX_HOSTS). Используйте /22 или уже.")
        return (first..last).map { Subnet.longToIp(it) }
    }

    /** Дешёвая догадка по порту (без отправки данных). */
    fun guess(port: Int): String = when (port) {
        37777, 37778 -> "Dahua / XMeye"
        8000 -> "Hikvision SDK / HTTP"
        554, 8554, 10554 -> "RTSP-камера"
        80, 81, 8080, 8081, 8888 -> "Веб-панель"
        443, 8443 -> "HTTPS-панель"
        22 -> "SSH"
        23 -> "Telnet"
        445, 139 -> "SMB / Windows"
        3389 -> "RDP"
        8008, 8009 -> "Google Cast / Android TV"
        8060 -> "Roku"
        8001, 8002 -> "Samsung TV"
        3000, 3001 -> "LG webOS"
        6466, 6467 -> "Android TV Remote"
        5353 -> "mDNS"
        9100, 631 -> "Принтер"
        5000, 5001 -> "NAS"
        else -> portName(port)
    }
}
