package com.pultitool.remote.ui

import android.Manifest
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.util.FileExport
import kotlinx.coroutines.launch

/**
 * Сканер диапазона IP × порты (только TCP connect, read-only).
 * Предназначен для аудита собственной сети пользователя.
 */
@Composable
fun RangePortsScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val st by tools.range.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var timeout by remember { mutableFloatStateOf(350f) }
    var saved by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (st.startIp.isEmpty() && st.cidr.isEmpty()) tools.fillCurrent24()
    }
    LaunchedEffect(saved) { saved?.let { vm.message(it); saved = null } }

    val doSave: () -> Unit = {
        scope.launch {
            try { saved = "Сохранено: " + tools.saveRangeResults() }
            catch (e: Exception) { saved = "Не удалось сохранить: ${e.message}" }
        }
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) doSave() else saved = "Нет доступа к хранилищу"
    }
    val exportRun: () -> Unit = {
        if (FileExport.needsLegacyPermission) permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else doSave()
    }

    ToolScaffold(
        "Диапазон портов",
        "TCP-проверка списка портов на диапазоне IP (только чтение)",
        onBack = { tools.stopRange(); vm.back() }
    ) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text(
                "Только для вашей собственной сети (или сети, владелец которой дал явное разрешение). " +
                    "Сканирование чужих диапазонов без разрешения может нарушать закон.\n\n" +
                    "Режим только чтения: выполняется лишь TCP-подключение к указанным портам. " +
                    "Приложение НЕ подбирает пароли, НЕ пробует стандартные логины и НЕ эксплуатирует уязвимости.",
                color = Pal.yellow, fontSize = 12.sp
            )
        }

        SegmentRow(listOf("Начало–конец", "CIDR"), st.mode) { i -> tools.setRange { it.copy(mode = i, error = null) } }

        if (st.mode == 0) {
            ToolField(st.startIp, { v -> tools.setRange { it.copy(startIp = v.filter { c -> c.isDigit() || c == '.' }) } },
                "Начальный IP", keyboard = KeyboardType.Decimal)
            ToolField(st.endIp, { v -> tools.setRange { it.copy(endIp = v.filter { c -> c.isDigit() || c == '.' }) } },
                "Конечный IP", keyboard = KeyboardType.Decimal)
        } else {
            ToolField(st.cidr, { v -> tools.setRange { it.copy(cidr = v.filter { c -> c.isDigit() || c == '.' || c == '/' }) } },
                "CIDR, например 192.168.1.0/24", keyboard = KeyboardType.Text)
        }
        GhostButton("Текущая /24", Modifier.fillMaxWidth()) { tools.fillCurrent24() }

        ToolField(
            st.spec,
            { v -> tools.setRange { it.copy(spec = v) } },
            "Порты через запятую (по умолчанию 8000,37777)",
            keyboard = KeyboardType.Text,
            singleLine = false
        )
        ChipRow(listOf("8000,37777", "Камеры", "Веб", "Популярные")) { i ->
            val specs = listOf(
                "8000,37777",
                "80,443,554,8000,8080,8554,8899,10554,34567,37777,37778",
                "80,81,443,8000,8080,8081,8443,8888",
                "21,22,23,80,443,445,554,8000,8080,37777"
            )
            tools.setRange { it.copy(spec = specs[i]) }
        }

        GlassCard(Modifier.fillMaxWidth()) {
            Text("Таймаут TCP: ${timeout.toInt()} мс", color = Pal.textDim, fontSize = 12.sp)
            Slider(timeout, { timeout = it }, valueRange = 100f..1500f)
            Text(
                "Меньший таймаут — быстрее, но может пропустить медленные устройства.",
                color = Pal.textDim, fontSize = 11.sp
            )
        }

        if (st.running) GhostButton("Остановить", Modifier.fillMaxWidth()) { tools.stopRange() }
        else GradientButton("Сканировать диапазон", Modifier.fillMaxWidth(), Glyph.RADAR) {
            tools.startRange(timeout.toInt())
        }

        ErrorText(st.error)

        if (st.total > 0) {
            val pct = if (st.total == 0) 0f else st.done.toFloat() / st.total
            ProgressLine(
                pct,
                "Проверено ${st.done} из ${st.total}" +
                    (if (st.hostCount > 0) " · ${st.hostCount} IP" else "") +
                    " · найдено ${st.hits.size}" +
                    " · ${"%.1f".format(st.elapsedMs / 1000.0)} с"
            )
        }

        if (st.hits.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Найдено: ${st.hits.size}", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Пульт Тул — открытые порты")
                        putExtra(Intent.EXTRA_TEXT, tools.rangeReportText())
                    }
                    context.startActivity(Intent.createChooser(send, "Поделиться списком"))
                }) { Icon(Icons.Filled.Share, "Поделиться", tint = Pal.text) }
                IconButton(onClick = exportRun) { GlyphIcon(Glyph.DOWNLOAD, tint = Pal.text, size = 22.dp) }
            }
            Text("Сохранить: TXT в Загрузки/PultTool, по одной строке IP:port", color = Pal.textDim, fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            GhostButton("Сохранить в Загрузки", Modifier.fillMaxWidth()) { exportRun() }
        }

        st.hits.forEach { h ->
            Row(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(Pal.green.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("${h.port}", color = Pal.green, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${h.ip}:${h.port}", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Text(h.guess, color = Pal.textDim, fontSize = 12.sp)
                }
                Text("%.0f мс".format(h.rttMs), color = Pal.textDim, fontSize = 11.sp)
                Spacer(Modifier.width(4.dp))
                CopyChip("${h.ip}:${h.port}")
            }
        }

        if (st.finished && !st.running && st.hits.isEmpty() && st.error == null && st.total > 0) {
            Text(
                "Открытых портов не найдено (устройства выключены, порты закрыты или фильтруются брандмауэром).",
                color = Pal.textDim, fontSize = 13.sp
            )
        }
    }
}
