package com.pultitool.remote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pultitool.remote.AppViewModel
import com.pultitool.remote.NetToolsViewModel
import com.pultitool.remote.Screen
import com.pultitool.remote.data.RKey
import com.pultitool.remote.tv.ConnState
import com.pultitool.remote.util.Achievements
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val ruLocale: Locale = Locale.forLanguageTag("ru")

fun fmtTime(t: Long, pattern: String = "dd.MM HH:mm"): String = SimpleDateFormat(pattern, ruLocale).format(Date(t))

@Composable
fun HomeScreen(vm: AppViewModel, tools: NetToolsViewModel) {
    val summary by vm.auditSummary.collectAsState()
    val presses by vm.presses.collectAsState()
    val devices by vm.devices.collectAsState()
    val controller by vm.controller.collectAsState()
    val lastSpeed by tools.lastSpeed.collectAsState()
    val monitor by tools.monitor.collectAsState()
    val unlocked by Achievements.unlocked.collectAsState()
    val net = remember { vm.localNet() }
    val accent = LocalAccent.current
    val greeting = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Доброе утро"
        in 12..17 -> "Добрый день"
        in 18..23 -> "Добрый вечер"
        else -> "Доброй ночи"
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
        Header("Пульт Тул", "$greeting! Всё под контролем") {
            PadButton(size = 44.dp, onClick = { vm.navigate(Screen.ACHIEVEMENTS) }) { GlyphIcon(Glyph.TROPHY, tint = Pal.yellow, size = 22.dp) }
        }

        // Оценка безопасности
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass().clickable { vm.navigate(Screen.AUDIT) }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ScoreRing(summary?.score, 120.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Безопасность сети", color = Pal.text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                val s = summary
                if (s == null) {
                    Text("Проведите аудит своей сети, чтобы получить оценку и советы", color = Pal.textDim, fontSize = 12.sp)
                } else {
                    Text("${s.hosts} устройств · ${fmtTime(s.time)}", color = Pal.textDim, fontSize = 12.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (s.critical > 0) Chip("${s.critical} крит.", Pal.red)
                        if (s.high > 0) Chip("${s.high} выс.", Color(0xFFFF8A3D))
                        if (s.medium > 0) Chip("${s.medium} ср.", Pal.yellow)
                        if (s.critical + s.high + s.medium == 0) Chip("Чисто", Pal.green)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (summary == null) "Начать аудит →" else "Повторить аудит →", color = accent.b, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniStat("$presses", "нажатий", Modifier.weight(1f))
            MiniStat("${devices.size}", "ТВ", Modifier.weight(1f))
            MiniStat(if (tools.lanSeen > 0) "${tools.lanSeen}" else "—", "в сети", Modifier.weight(1f))
            MiniStat("${unlocked.size}/${Achievements.all.size}", "наград", Modifier.weight(1f), Pal.yellow)
        }

        // Телевизор
        SectionTitle("Телевизор", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        val c = controller
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            if (c == null) {
                Text("ТВ не выбран", color = Pal.text, fontWeight = FontWeight.Bold)
                Text("Найдите телевизор в сети или добавьте вручную", color = Pal.textDim, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GradientButton("Найти ТВ", Modifier.weight(1f), Glyph.RADAR) { vm.startScan() }
                    GhostButton("Устройства", Modifier.weight(1f)) { vm.navigate(Screen.DEVICES) }
                }
            } else {
                val st by c.state.collectAsState()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusDot(when (st) { is ConnState.Connected -> Pal.green; is ConnState.Error -> Pal.red; else -> Pal.yellow })
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.device.name, color = Pal.text, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("${c.device.protocol.short} · ${c.device.ip}", color = Pal.textDim, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    GlyphButton(Glyph.GRID, 52.dp, label = "Пульт") { vm.navigate(Screen.REMOTE) }
                    GlyphButton(Glyph.HAND, 52.dp, label = "Жесты") { vm.navigate(Screen.GESTURE) }
                    GlyphButton(Glyph.MUTE, 52.dp, label = "Звук") { vm.press(RKey.MUTE) }
                    GlyphButton(Glyph.POWER, 52.dp, tint = Pal.red, label = "Питание") { vm.press(RKey.POWER) }
                }
            }
        }

        // Сеть
        SectionTitle("Сеть", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f).glass().clickable { vm.navigate(Screen.SPEED) }.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphIcon(Glyph.SPEED, tint = accent.b, size = 20.dp); Spacer(Modifier.width(6.dp))
                    Text("Скорость", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(6.dp))
                val ls = lastSpeed
                if (ls == null) Text("Не измерялась", color = Pal.textDim, fontSize = 12.sp)
                else {
                    Text("↓ %.1f Мбит/с".format(ls.downMbps), color = Pal.text, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                    Text("↑ %.1f · %.0f мс".format(ls.upMbps, ls.pingMs), color = Pal.textDim, fontSize = 12.sp)
                }
            }
            Column(Modifier.weight(1f).glass().clickable { vm.navigate(Screen.MONITOR) }.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    GlyphIcon(Glyph.EYE, tint = if (monitor.enabled) Pal.green else Pal.textDim, size = 20.dp); Spacer(Modifier.width(6.dp))
                    Text("Монитор", color = Pal.text, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(Modifier.height(6.dp))
                Text(if (monitor.enabled) "Включён" else "Выключен", color = if (monitor.enabled) Pal.green else Pal.textDim, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (monitor.enabled) "Онлайн: ${monitor.online.size}" else "Новые устройства", color = Pal.textDim, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        GlassCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            if (net == null) Text("Нет подключения к локальной сети", color = Pal.red, fontSize = 13.sp)
            else {
                InfoRow("Мой IP", "${net.ip}/${net.prefix}")
                InfoRow("Роутер", net.gateway ?: "—")
                InfoRow("Подключение", if (net.isWifi) "Wi-Fi" else "Другое")
            }
        }

        SectionTitle("Инструменты", Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        ToolGrid(vm)
    }
}

data class ToolTile(val screen: Screen, val glyph: Glyph, val title: String, val c1: Color, val c2: Color)

val toolTiles = listOf(
    ToolTile(Screen.AUDIT, Glyph.SHIELD, "Аудит", Color(0xFFFF3B5C), Color(0xFFFF9100)),
    ToolTile(Screen.SPEED, Glyph.SPEED, "Скорость", Color(0xFF00E676), Color(0xFF00B0FF)),
    ToolTile(Screen.PING, Glyph.PULSE, "Пинг", Color(0xFF7C4DFF), Color(0xFF00E5FF)),
    ToolTile(Screen.MAP, Glyph.MAP, "Карта сети", Color(0xFF2979FF), Color(0xFF651FFF)),
    ToolTile(Screen.MONITOR, Glyph.EYE, "Монитор", Color(0xFFFFC400), Color(0xFFFF6E40)),
    ToolTile(Screen.PORTS, Glyph.DOOR, "Порты", Color(0xFFFF4081), Color(0xFFD500F9)),
    ToolTile(Screen.RANGE, Glyph.RADAR, "Диапазон", Color(0xFF00C853), Color(0xFF2979FF)),
    ToolTile(Screen.TRACE, Glyph.ROUTE, "Трассировка", Color(0xFF00BFA5), Color(0xFF64DD17)),
    ToolTile(Screen.DNS, Glyph.SEARCH, "DNS", Color(0xFF536DFE), Color(0xFF18FFFF)),
    ToolTile(Screen.PUBLIC_IP, Glyph.GLOBE, "Внешний IP", Color(0xFF00B0FF), Color(0xFF1DE9B6)),
    ToolTile(Screen.SUBNET, Glyph.CALC, "Подсети", Color(0xFFAA00FF), Color(0xFFFF4081)),
    ToolTile(Screen.HTTP, Glyph.CODE, "HTTP", Color(0xFFFF6D00), Color(0xFFFFD600)),
    ToolTile(Screen.ACHIEVEMENTS, Glyph.TROPHY, "Награды", Color(0xFFFFD600), Color(0xFFFF6D00))
)

@Composable
fun ToolGrid(vm: AppViewModel) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        toolTiles.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { t ->
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                            .background(Brush.linearGradient(listOf(t.c1.copy(alpha = 0.22f), t.c2.copy(alpha = 0.12f))))
                            .border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(20.dp))
                            .clickable { vm.navigate(t.screen) }
                            .padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(t.c1, t.c2))), contentAlignment = Alignment.Center) {
                            GlyphIcon(t.glyph, tint = Color.White, size = 24.dp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(t.title, color = Pal.text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
