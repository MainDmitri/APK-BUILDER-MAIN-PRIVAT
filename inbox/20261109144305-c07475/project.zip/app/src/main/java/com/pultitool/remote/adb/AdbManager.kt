package com.pultitool.remote.adb

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class AdbManager(private val context: Context) {
    private var dadb: Dadb? = null
    var currentHost: String = ""
        private set

    suspend fun connect(host: String, port: Int = 5555): Result<Unit> = withContext(Dispatchers.IO) {
        if (host.isBlank()) return@withContext Result.failure(IllegalArgumentException("IP пустой"))
        try {
            close()
            val key = File(context.filesDir, "adbkey")
            val pub = File(context.filesDir, "adbkey.pub")
            if (!key.exists()) AdbKeyPair.generate(key, pub)
            dadb = Dadb.create(host, port, AdbKeyPair.read(key, pub))
            currentHost = host
            Result.success(Unit)
        } catch (e: Exception) {
            close()
            Result.failure(e)
        }
    }

    fun isConnected() = dadb != null

    suspend fun shell(cmd: String): String = withContext(Dispatchers.IO) {
        if (dadb == null) error("Не подключено")
        try {
            dadb!!.shell(cmd).allOutput.trim()
        } catch (e: Exception) {
            close()
            throw e
        }
    }

    suspend fun installApk(file: File): String = withContext(Dispatchers.IO) {
        if (dadb == null) error("Не подключено")
        dadb!!.install(file)
        "Установлено: ${file.name}"
    }

    suspend fun push(local: File, remote: String): String = withContext(Dispatchers.IO) {
        if (dadb == null) error("Не подключено")
        dadb!!.push(local, remote)
        "Отправлено: $remote"
    }

    suspend fun pull(remote: String, local: File): String = withContext(Dispatchers.IO) {
        if (dadb == null) error("Не подключено")
        dadb!!.pull(local, remote)
        "Скачано: ${local.name}"
    }

    fun close() {
        try { dadb?.close() } catch (_: Throwable) {}
        dadb = null
        currentHost = ""
    }

    companion object {
        suspend fun scanForAdb(onFound: (String) -> Unit = {}): List<String> = withContext(Dispatchers.IO) {
            val ip = java.net.NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is java.net.Inet4Address && it.isSiteLocalAddress }?.hostAddress
                ?: return@withContext emptyList()

            val prefix = ip.substringBeforeLast('.') + "."
            val pool = Executors.newFixedThreadPool(36)
            val futures = (1..254).map { i ->
                pool.submit<String?> {
                    val h = prefix + i
                    try {
                        Socket().use { it.connect(InetSocketAddress(h, 5555), 260) }
                        onFound(h)
                        h
                    } catch (_: Throwable) { null }
                }
            }
            val result = futures.mapNotNull { try { it.get(600, TimeUnit.MILLISECONDS) } catch (_: Throwable) { null } }
            pool.shutdownNow()
            result.distinct()
        }

        suspend fun download(url: String, dest: File, onProgress: (Int) -> Unit = {}): File = withContext(Dispatchers.IO) {
            require(url.startsWith("http")) { "Некорректный URL" }
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 25000
            conn.readTimeout = 90000
            conn.setRequestProperty("User-Agent", "PultiTool/2.4")
            conn.connect()
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            val total = conn.contentLengthLong
            var done = 0L
            var last = -1
            conn.inputStream.use { input ->
                dest.parentFile?.mkdirs()
                dest.outputStream().use { out ->
                    val buf = ByteArray(16384)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val p = ((done * 100) / total).toInt()
                            if (p != last && p % 5 == 0) {
                                last = p
                                onProgress(p)
                            }
                        }
                    }
                }
            }
            onProgress(100)
            dest
        }
    }
}
