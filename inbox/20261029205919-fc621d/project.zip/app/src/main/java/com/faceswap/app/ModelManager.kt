package com.faceswap.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Управляет загрузкой и хранением ONNX-моделей.
 *
 * Модели (~500 МБ суммарно) загружаются при первом запуске
 * и кэшируются в filesDir/models/ — между запусками сохраняются.
 *
 * Используемые модели:
 *  - det_10g.onnx      — детектор лиц RetinaFace (InsightFace buffalo_l)
 *  - w600k_r50.onnx    — признаки лица ArcFace (128-мерный эмбеддинг)
 *  - inswapper_128.onnx — замена лица (InsightFace inswapper)
 *
 * Источник: публичные зеркала HuggingFace (facefusion-assets).
 */
object ModelManager {

    private const val TAG = "ModelManager"

    // Зеркало моделей через facefusion-assets (публичный HuggingFace release)
    private const val BASE_URL =
        "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main"

    data class ModelInfo(
        val filename: String,
        val url: String,
        val sizeBytes: Long   // приблизительно, для прогресса
    )

    val MODELS = listOf(
        ModelInfo(
            "det_10g.onnx",
            "https://github.com/facefusion/facefusion-assets/releases/download/models/det_10g.onnx",
            16_000_000L
        ),
        ModelInfo(
            "w600k_r50.onnx",
            "https://github.com/facefusion/facefusion-assets/releases/download/models/arcface_w600k_r50.onnx",
            166_000_000L
        ),
        ModelInfo(
            "inswapper_128.onnx",
            "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx",
            544_000_000L
        )
    )

    fun modelsDir(context: Context): File =
        File(context.filesDir, "models").also { it.mkdirs() }

    fun modelFile(context: Context, name: String): File =
        File(modelsDir(context), name)

    /** Все ли модели уже скачаны и не пустые? */
    fun areModelsReady(context: Context): Boolean =
        MODELS.all { model ->
            val f = modelFile(context, model.filename)
            f.exists() && f.length() > 1_000_000L  // хотя бы 1 МБ — не обрезанный файл
        }

    /**
     * Скачивает недостающие модели.
     * [onProgress] вызывается с (modelName, 0..100) для каждой модели.
     */
    suspend fun downloadModels(
        context: Context,
        onProgress: (modelName: String, percent: Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        for (model in MODELS) {
            val dest = modelFile(context, model.filename)
            // Удаляем брошенный .tmp если есть
            File(dest.parent, dest.name + ".tmp").takeIf { it.exists() }?.delete()

            if (dest.exists() && dest.length() > 1_000_000L) {
                Log.d(TAG, "${model.filename} уже есть, пропуск")
                onProgress(model.filename, 100)
                continue
            }
            Log.d(TAG, "Скачивание ${model.filename} ...")
            downloadFile(model.url, dest, model.sizeBytes) { p ->
                onProgress(model.filename, p)
            }
        }
    }

    private fun downloadFile(
        urlStr: String,
        dest: File,
        approxSize: Long,
        onProgress: (Int) -> Unit
    ) {
        val tmp = File(dest.parent, dest.name + ".tmp")
        try {
            val url = URL(urlStr)
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 30_000
            conn.readTimeout = 60_000
            conn.connect()

            val contentLen = if (conn.contentLengthLong > 0) conn.contentLengthLong else approxSize
            val buf = ByteArray(8192)
            var downloaded = 0L

            conn.inputStream.use { inp ->
                FileOutputStream(tmp).use { out ->
                    var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n)
                        downloaded += n
                        val pct = ((downloaded * 100) / contentLen).toInt().coerceIn(0, 99)
                        onProgress(pct)
                    }
                }
            }
            tmp.renameTo(dest)
            onProgress(100)
            Log.d(TAG, "${dest.name} скачан (${downloaded / 1_048_576} МБ)")
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }
}
