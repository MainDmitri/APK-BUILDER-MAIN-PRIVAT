package com.dk.darlin.ui

import com.dk.darlin.core.safeClick
import com.dk.darlin.core.safeLongClick
import android.content.Intent
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.dk.darlin.ai.Conversation
import com.dk.darlin.ai.LlmClient
import com.dk.darlin.core.Db
import com.dk.darlin.core.Prefs
import com.dk.darlin.tts.EdgeTts
import com.dk.darlin.tts.Speaker
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** Экран «Параметры»: ИИ-провайдер, ключ, модель, голос, поведение. */
class SettingsPage(private val act: AppCompatActivity, private val onChanged: () -> Unit) {
    val view = ScrollView(act)
    private val col = LinearLayout(act)
    private val speaker = Speaker(act)
    private fun d(v: Int) = Ui.dp(act, v)

    private lateinit var providerBtn: MaterialButton
    private lateinit var baseUrl: EditText
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var smartModel: EditText
    /** После смены голоса/скорости — заново озвучить частые фразы в кэш (с задержкой, чтобы не дёргать на каждом шаге ползунка). */
    private val rewarm = Runnable { com.dk.darlin.tts.TtsCache.warmAsync(act) }
    private fun voiceChanged() { view.removeCallbacks(rewarm); view.postDelayed(rewarm, 1500) }
    private lateinit var keyLink: MaterialButton
    private lateinit var voiceBtn: MaterialButton
    private var binding = false

    init {
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(8), d(16), d(32))
        view.addView(col)
        view.isVerticalScrollBarEnabled = false
        col.addView(Ui.text(act, "Параметры", 26f, Ui.TEXT, true).apply { setPadding(0, 0, 0, d(10)) })

        // ---- ИИ ----
        val ai = section("🧠 Мозг (ИИ)", "Любой OpenAI-совместимый сервис. Бесплатный вариант — ключ Google Gemini из AI Studio. Ключ хранится только на телефоне.")
        providerBtn = MaterialButton(act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply { safeClick { pickProvider() } }
        ai.addView(providerBtn, full())
        baseUrl = field(ai, "Адрес API (base URL)", InputType.TYPE_TEXT_VARIATION_URI) { if (!binding) { Prefs.setBaseUrl(act, it); onChanged() } }
        apiKey = field(ai, "Ключ API", InputType.TYPE_TEXT_VARIATION_PASSWORD) { if (!binding) { Prefs.setApiKey(act, it); onChanged() } }
        model = field(ai, "Быстрая модель (разговор и команды)", InputType.TYPE_TEXT_VARIATION_NORMAL) { if (!binding) { Prefs.setModel(act, it); onChanged() } }
        smartModel = field(ai, "Умная модель (код и сложные задачи)", InputType.TYPE_TEXT_VARIATION_NORMAL) { if (!binding) { Prefs.setSmartModel(act, it) } }
        val aiRow = row(ai)
        aiRow.addView(small("Модели…") { loadModels() }, weight())
        aiRow.addView(small("Проверить") { testBrain() }, weight())
        keyLink = small("Получить ключ") {
            val u = Prefs.provider(act).keyUrl
            if (u.isNotEmpty()) try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {}
        }
        aiRow.addView(keyLink, weight())

        ai.addView(switch("Мгновенные команды без ИИ (фонарик, будильник, громкость…)", Prefs.bool(act, Prefs.FAST_ROUTER, true)) { Prefs.setBool(act, Prefs.FAST_ROUTER, it) })
        ai.addView(switch("Умная модель для кода и сложных задач", Prefs.bool(act, Prefs.SMART_AUTO, true)) { Prefs.setBool(act, Prefs.SMART_AUTO, it) })
        ai.addView(switch("Быстрые ответы без долгих размышлений", Prefs.bool(act, Prefs.FAST_NO_THINK, true)) { Prefs.setBool(act, Prefs.FAST_NO_THINK, it) })
        ai.addView(switch("Фразы-заполнители («Секунду…»), пока ИИ думает", Prefs.bool(act, Prefs.FILLERS, true)) { Prefs.setBool(act, Prefs.FILLERS, it) })

        // ---- Голос ----
        val v = section("🔊 Голос", "По умолчанию — бесплатные нейроголоса Microsoft Edge (нужен интернет). Без сети Дарлин автоматически переходит на системный голос.")
        v.addView(switch("Нейроголоса Microsoft Edge", Prefs.voiceEngine(act) == "edge") { Prefs.setStr(act, "voice_engine", if (it) "edge" else "system"); voiceChanged() })
        voiceBtn = MaterialButton(act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply { safeClick { pickVoice() } }
        v.addView(voiceBtn, full())
        v.addView(label("Скорость речи"))
        v.addView(slider(-50f, 100f, Prefs.rate(act).toFloat(), 5f) { Prefs.setInt(act, "rate", it); voiceChanged() })
        v.addView(label("Высота голоса"))
        v.addView(slider(-30f, 30f, Prefs.pitch(act).toFloat(), 2f) { Prefs.setInt(act, "pitch", it); voiceChanged() })
        val vr = row(v)
        vr.addView(small("Прослушать") { preview(null) }, weight())
        vr.addView(small("Голос системы…") {
            try { act.startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (_: Exception) {}
        }, weight())

        // ---- Поведение ----
        val b = section("⚙️ Поведение", null)
        b.addView(switch("Закрываться после действия", Prefs.bool(act, Prefs.AUTO_CLOSE, true)) { Prefs.setBool(act, Prefs.AUTO_CLOSE, it) })
        b.addView(switch("Озвучивать ответы на голосовые вопросы", Prefs.bool(act, Prefs.SPEAK, true)) { Prefs.setBool(act, Prefs.SPEAK, it) })
        b.addView(switch("Озвучивать и ответы на текст", Prefs.bool(act, "speak_typed", false)) { Prefs.setBool(act, "speak_typed", it) })
        b.addView(switch("Слушать сразу при вызове", Prefs.bool(act, Prefs.AUTO_LISTEN, true)) { Prefs.setBool(act, Prefs.AUTO_LISTEN, it) })
        b.addView(switch("Продолжать разговор, если Дарлин задала вопрос", Prefs.bool(act, Prefs.CONTINUOUS, true)) { Prefs.setBool(act, Prefs.CONTINUOUS, it) })
        b.addView(switch("Понимать текст на экране", Prefs.bool(act, Prefs.SCREEN_TEXT, true)) { Prefs.setBool(act, Prefs.SCREEN_TEXT, it) })
        b.addView(switch("Отправлять скриншот для вопросов «что на экране» (модель с vision)", Prefs.bool(act, Prefs.SCREENSHOT, false)) { Prefs.setBool(act, Prefs.SCREENSHOT, it) })
        b.addView(switch("Режим беседы: слушать снова после каждого ответа («стоп» — закончить)", Prefs.bool(act, Prefs.CONVERSATION, false)) { Prefs.setBool(act, Prefs.CONVERSATION, it) })
        b.addView(switch("Значок «Спросить Дарлин» в шторке уведомлений", Prefs.bool(act, Prefs.QUICK_NOTIF, false)) {
            Prefs.setBool(act, Prefs.QUICK_NOTIF, it); com.dk.darlin.sys.QuickAccess.update(act)
        })
        b.addView(switch("Вибрация при начале прослушивания", Prefs.bool(act, Prefs.HAPTICS, true)) { Prefs.setBool(act, Prefs.HAPTICS, it) })

        // ---- Личное ----
        val p = section("🙂 О вас", "Дарлин будет учитывать это в ответах.")
        field(p, "Как к вам обращаться", InputType.TYPE_TEXT_FLAG_CAP_WORDS, Prefs.str(act, Prefs.USER_NAME)) { Prefs.setStr(act, Prefs.USER_NAME, it) }
        field(p, "Пожелания (стиль, город, интересы…)", InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES, Prefs.str(act, Prefs.CUSTOM_PROMPT)) {
            Prefs.setStr(act, Prefs.CUSTOM_PROMPT, it)
        }

        // ---- Данные ----
        val data = section("🗂 Данные", null)
        val dr = row(data)
        dr.addView(small("Заметки") { showNotes() }, weight())
        dr.addView(small("Напоминания") { showReminders() }, weight())
        val dr2 = row(data)
        dr2.addView(small("Память") { showMemory() }, weight())
        dr2.addView(small("Сценарии") { showRoutines() }, weight())
        dr.addView(small("Очистить чат") {
            MaterialAlertDialogBuilder(act).setTitle("Очистить историю?").setMessage("Все сообщения будут удалены с телефона.")
                .setPositiveButton("Очистить") { _, _ -> Db.get(act).clearHistory(); Conversation.reset(); onChanged() }
                .setNegativeButton("Отмена", null).show()
        }, weight())

        col.addView(Ui.text(act, "Дарлин " + versionName() + " · данные (заметки, память, история, ключ) хранятся только на этом телефоне. Запросы уходят только выбранному ИИ-сервису и, для озвучки, в Microsoft Edge TTS.", 12f, Ui.TEXT2).apply {
            setPadding(d(4), d(12), d(4), 0); gravity = Gravity.CENTER
        })
        bind()
    }

    fun bind() {
        binding = true
        val pr = Prefs.provider(act)
        providerBtn.text = "Сервис: ${pr.title}"
        baseUrl.setText(Prefs.baseUrl(act))
        apiKey.setText(Prefs.apiKey(act))
        model.setText(Prefs.model(act))
        smartModel.setText(if (Prefs.modelIsCustom(act, true) || Prefs.SMART_DEFAULTS.containsKey(Prefs.providerId(act))) Prefs.smartModel(act) else "")
        smartModel.hint = "Как у быстрой"
        keyLink.isEnabled = pr.keyUrl.isNotEmpty()
        voiceBtn.text = "Голос: " + (EdgeTts.VOICES.firstOrNull { it.id == Prefs.edgeVoice(act) }?.title ?: Prefs.edgeVoice(act))
        binding = false
    }

    private fun pickProvider() {
        val list = Prefs.PROVIDERS
        val cur = list.indexOfFirst { it.id == Prefs.providerId(act) }
        MaterialAlertDialogBuilder(act).setTitle("ИИ-сервис")
            .setSingleChoiceItems(list.map { it.title }.toTypedArray(), cur) { dlg, which ->
                Prefs.setProvider(act, list[which].id); bind(); onChanged(); dlg.dismiss()
            }.show()
    }

    private fun pickVoice() {
        val list = EdgeTts.VOICES
        var cur = list.indexOfFirst { it.id == Prefs.edgeVoice(act) }
        MaterialAlertDialogBuilder(act).setTitle("Голос (нажмите, чтобы прослушать)")
            .setSingleChoiceItems(list.map { it.title }.toTypedArray(), cur) { _, which -> cur = which; preview(list[which].id) }
            .setPositiveButton("Выбрать") { _, _ ->
                if (cur >= 0) { Prefs.setStr(act, "edge_voice", list[cur].id); Prefs.setStr(act, "voice_engine", "edge"); bind(); voiceChanged() }
                speaker.stop()
            }
            .setNegativeButton("Отмена") { _, _ -> speaker.stop() }
            .show()
    }

    private fun preview(voiceId: String?) {
        val name = Prefs.str(act, Prefs.USER_NAME).ifBlank { "" }
        val text = "Привет${if (name.isNotEmpty()) ", $name" else ""}! Я Дарлин, ваш голосовой помощник. Чем могу помочь?"
        speaker.speak(text, voiceId) {
            speaker.lastError?.let { Toast.makeText(act, "Нейроголос недоступен, звучит системный: $it", Toast.LENGTH_LONG).show() }
        }
    }

    private fun loadModels() {
        if (Prefs.apiKey(act).isEmpty()) { toast("Сначала введите ключ API"); return }
        act.lifecycleScope.launch(com.dk.darlin.core.CrashLog.globalHandler) {
            val res = withContext(Dispatchers.IO) { runCatching { LlmClient(act).listModels() } }
            res.onSuccess { models ->
                if (models.isEmpty()) { toast("Сервис не вернул список моделей"); return@onSuccess }
                MaterialAlertDialogBuilder(act).setTitle("Модели (${models.size})")
                    .setItems(models.toTypedArray()) { _, w ->
                        val m = models[w]
                        MaterialAlertDialogBuilder(act).setTitle(m).setMessage("Использовать эту модель как…")
                            .setPositiveButton("Быструю") { _, _ -> Prefs.setModel(act, m); bind(); onChanged() }
                            .setNeutralButton("Умную") { _, _ -> Prefs.setSmartModel(act, m); bind() }
                            .setNegativeButton("Отмена", null).show()
                    }.show()
            }.onFailure { toast("Ошибка: ${it.message}") }
        }
    }

    private fun testBrain() {
        if (!Prefs.hasBrain(act)) { toast("Заполните ключ и модель"); return }
        act.lifecycleScope.launch(com.dk.darlin.core.CrashLog.globalHandler) {
            toast("Проверяю…")
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", "Ответь одним коротким предложением по-русски: ты на связи?"))
                    LlmClient(act).chat(msgs, null).optString("content")
                }
            }
            res.onSuccess {
                MaterialAlertDialogBuilder(act).setTitle("✓ Работает").setMessage(it).setPositiveButton("OK", null).show()
            }.onFailure {
                MaterialAlertDialogBuilder(act).setTitle("Ошибка").setMessage(it.message).setPositiveButton("OK", null).show()
            }
        }
    }

    private fun showNotes() {
        val notes = Db.get(act).notes()
        if (notes.isEmpty()) { toast("Заметок пока нет — скажите «Запомни …»"); return }
        MaterialAlertDialogBuilder(act).setTitle("Заметки")
            .setItems(notes.map { it.text }.toTypedArray()) { _, w ->
                val n = notes[w]
                MaterialAlertDialogBuilder(act).setMessage(n.text)
                    .setPositiveButton("Удалить") { _, _ -> Db.get(act).deleteNote(n.id) }
                    .setNegativeButton("Закрыть", null).show()
            }.show()
    }

    private fun showMemory() {
        val facts = com.dk.darlin.tools.Memory.facts(act)
        if (facts.isEmpty()) { toast("Память пуста — скажите «Запомни, что …»"); return }
        MaterialAlertDialogBuilder(act).setTitle("Что помнит Дарлин")
            .setItems(facts.map { it.text }.toTypedArray()) { _, w ->
                val f = facts[w]
                MaterialAlertDialogBuilder(act).setMessage(f.text)
                    .setPositiveButton("Забыть") { _, _ -> com.dk.darlin.tools.Memory.forgetExact(act, f.text) }
                    .setNegativeButton("Закрыть", null).show()
            }
            .setNeutralButton("Забыть всё") { _, _ ->
                MaterialAlertDialogBuilder(act).setTitle("Очистить память?").setMessage("Дарлин забудет все сохранённые факты.")
                    .setPositiveButton("Очистить") { _, _ -> com.dk.darlin.tools.Memory.forget(act, "всё"); toast("Память очищена") }
                    .setNegativeButton("Отмена", null).show()
            }
            .setNegativeButton("Закрыть", null).show()
    }

    private fun showRoutines() {
        val list = com.dk.darlin.tools.Memory.routines(act)
        if (list.isEmpty()) { toast("Сценариев нет — скажите: «Создай сценарий «еду домой»: построй маршрут домой и включи музыку»"); return }
        MaterialAlertDialogBuilder(act).setTitle("Сценарии")
            .setItems(list.map { "«${it.name}» — ${it.steps}" }.toTypedArray()) { _, w ->
                val r = list[w]
                MaterialAlertDialogBuilder(act).setTitle("«${r.name}»").setMessage(r.steps)
                    .setPositiveButton("Удалить") { _, _ -> com.dk.darlin.tools.Memory.deleteRoutine(act, r.name) }
                    .setNegativeButton("Закрыть", null).show()
            }.show()
    }

    private fun showReminders() {
        val list = Db.get(act).reminders(true)
        if (list.isEmpty()) { toast("Активных напоминаний нет"); return }
        val fmt = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.forLanguageTag("ru"))
        MaterialAlertDialogBuilder(act).setTitle("Напоминания")
            .setItems(list.map { fmt.format(java.util.Date(it.at)) + " — " + it.text }.toTypedArray()) { _, w ->
                val r = list[w]
                MaterialAlertDialogBuilder(act).setMessage(r.text)
                    .setPositiveButton("Удалить") { _, _ -> com.dk.darlin.sys.ReminderScheduler.cancel(act, r.id); Db.get(act).deleteReminder(r.id) }
                    .setNegativeButton("Закрыть", null).show()
            }.show()
    }

    private fun versionName(): String = try { act.packageManager.getPackageInfo(act.packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    private fun toast(s: String) = Toast.makeText(act, s, Toast.LENGTH_SHORT).show()

    // ---- построители ----
    private fun section(title: String, desc: String?): LinearLayout {
        val c = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(act, Ui.SURFACE, 20f, 0x1AFFFFFF)
            setPadding(d(16), d(14), d(16), d(14))
        }
        c.addView(Ui.text(act, title, 17f, Ui.TEXT, true))
        if (desc != null) c.addView(Ui.text(act, desc, 13f, Ui.TEXT2).apply { setPadding(0, d(4), 0, d(6)) })
        col.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = d(12) })
        return c
    }

    private fun full() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = d(6) }
    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = d(6) }

    private fun row(parent: LinearLayout) = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        parent.addView(this, full())
    }

    private fun small(text: String, onClick: () -> Unit) = MaterialButton(act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
        this.text = text; textSize = 12.5f; setPadding(d(4), 0, d(4), 0); safeClick { onClick() }
    }

    private fun label(s: String): TextView = Ui.text(act, s, 13f, Ui.TEXT2).apply { setPadding(0, d(10), 0, 0) }

    private fun field(parent: LinearLayout, hint: String, variation: Int, initial: String = "", onChange: (String) -> Unit): EditText {
        parent.addView(label(hint))
        val e = EditText(act).apply {
            setText(initial)
            setTextColor(Ui.TEXT); setHintTextColor(Ui.TEXT2); textSize = 15f
            inputType = InputType.TYPE_CLASS_TEXT or variation
            background = Ui.round(act, Ui.SURFACE2, 14f, 0x22FFFFFF)
            setPadding(d(14), d(10), d(14), d(10))
            this.hint = hint
        }
        e.doAfterTextChanged { onChange(it?.toString()?.trim() ?: "") }
        parent.addView(e, full())
        return e
    }

    private fun switch(text: String, value: Boolean, onChange: (Boolean) -> Unit) = MaterialSwitch(act).apply {
        this.text = text; isChecked = value; setTextColor(Ui.TEXT); textSize = 14.5f
        setPadding(0, d(4), 0, d(4))
        setOnCheckedChangeListener { _, c -> onChange(c) }
    }

    private fun slider(from: Float, to: Float, value: Float, step: Float, onChange: (Int) -> Unit) = Slider(act).apply {
        valueFrom = from; valueTo = to; stepSize = step
        this.value = (Math.round(value / step) * step).coerceIn(from, to)
        setLabelFormatter { v -> (if (v > 0) "+" else "") + v.toInt() }
        addOnChangeListener { _, v, fromUser -> if (fromUser) onChange(v.toInt()) }
    }

    fun destroy() { speaker.shutdown() }
}
