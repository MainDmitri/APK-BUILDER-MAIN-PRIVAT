package com.dk.darlin.ai

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import com.dk.darlin.core.Prefs
import com.dk.darlin.core.ScreenContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Память текущего диалога (живёт, пока жив процесс; сбрасывается через 10 минут тишины). */
object Conversation {
    val messages = ArrayList<JSONObject>()
    var lastTime = 0L

    fun touch() {
        val now = System.currentTimeMillis()
        if (now - lastTime > 10 * 60_000) messages.clear()
        lastTime = now
    }

    fun reset() { messages.clear(); lastTime = 0 }

    /**
     * Сокращает историю только целыми репликами (user → assistant/tool_calls → tool … ), начиная со старых.
     * Сообщения с вызовами функций не меняются и не разрываются — иначе Gemini отклонит подписи.
     * Текущую (последнюю) реплику пользователя не трогаем.
     */
    fun trim(max: Int = 30) {
        while (messages.size > max) {
            val next = (1 until messages.size).firstOrNull { messages[it].optString("role") == "user" } ?: break
            repeat(next) { messages.removeAt(0) }
        }
        while (messages.size > 1 && messages[0].optString("role") != "user") messages.removeAt(0)
    }
}

/** «Мозг» ассистента: LLM с вызовом функций + локальные команды без интернета. */
class Agent(private val ctx: Context, val tools: ToolExecutor) {
    private val llm = LlmClient(ctx)
    private val local = LocalBrain(tools)

    private val screenWords = Regex("(?i)экран|скрин|на картинк|что это|что тут|что здесь|прочитай|переведи|объясни это|кто это|на фото|сообщени")

    private fun systemPrompt(screen: ScreenContext?, tier: FastRouter.Tier): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale("ru")).format(Date())
        val name = Prefs.str(ctx, Prefs.USER_NAME)
        val sb = StringBuilder()
        sb.append("Ты — Дарлин, голосовой помощник в Android-телефоне пользователя. Ты девушка: тёплая, весёлая и очень толковая; о себе — в женском роде (сделала, открыла, нашла). ")
        sb.append("Говори по-русски. Ответ озвучивается: коротко и естественно, 1–3 предложения, без markdown, таблиц и эмодзи; подробно — только если просят.\n")
        sb.append("ДЕЙСТВИЯ: для всего на телефоне вызывай функции, результат не выдумывай. Независимые функции вызывай сразу пачкой в одном ответе. " +
            "Факты: погода — weather, курсы — exchange_rate/crypto_price, расчёты — calculate, единицы — convert_units, новости — news, справка — wikipedia, остальное свежее — web_search (+fetch_url). " +
            "Уведомления — read_notifications; ответ на них — reply_notification → «Отправить?» → confirm_send; экран — get_screen_text или look_at_screen; «запомни, что…» — remember.\n")
        sb.append("ПОНИМАНИЕ: речь распознаётся с ошибками и бывает разговорной — додумывай очевидный смысл («фанарик» = фонарик, «вотсап» = WhatsApp, имена — в именительном падеже). " +
            "Уточняй, только если выполнить действительно невозможно. Примеры: «врубай фонарь» → flashlight(on=true); «разбуди в полседьмого» → set_alarm(6:30); " +
            "«чё там по погоде на завтра» → weather(day=1); «сделай потише» → set_volume(direction=down); «закинь в заметки купить хлеб» → add_note; «набери маму» → call_phone(contact=мама); " +
            "«почём бакс» → exchange_rate(from=USD); «вруби что-нибудь из Цоя» → play_music(query=Виктор Цой); «напомни через часик позвонить Пете» → set_reminder(in_minutes=60).\n")
        sb.append("СООБЩЕНИЯ: «напиши Максу в WhatsApp привет» → send_message(app=whatsapp, contact, text), затем спроси «Отправить?»; confirm_send — только после явного «да», при «нет» — cancel_send.\n")
        sb.append("ЛЮБОЕ ПРИЛОЖЕНИЕ: open_app(and_look=true) или ui_snapshot → дерево [N] → ui_click/ui_type/ui_scroll/ui_back, проверяй каждый шаг до конца задачи. " +
            "Перед необратимым (отправка, оплата, удаление, звонок) спроси подтверждение. Файлы: пути от /storage/emulated/0 (Download, Documents, DCIM).\n")
        when (tier) {
            FastRouter.Tier.CODE -> sb.append("ЗАДАЧА С КОДОМ — работай как сильный senior-разработчик, качество важнее скорости:\n" +
                "1) Продумай требования и структуру (модули, функции, данные), выбери надёжные стандартные библиотеки.\n" +
                "2) Пиши ПОЛНЫЙ, сразу запускаемый код: все импорты, точка входа (например, if __name__ == \"__main__\"), обработка ошибок и крайних случаев. Никаких заглушек, TODO, «…» и пропусков.\n" +
                "3) В начале файла — комментарий: что делает программа, как запустить, какие зависимости поставить (pip install …).\n" +
                "4) Перед записью мысленно проверь код: синтаксис, имена, импорты, логику, что игра/программа действительно работает от начала до конца. Исправь найденное.\n" +
                "5) Запиши файл ОДНИМ вызовом write_file целиком (по умолчанию в Download/, если путь не назван). Если файлов несколько — каждый целиком.\n" +
                "6) Вслух код не читай: одной-двумя фразами скажи, что сделано, куда сохранено и как запустить.\n")
            FastRouter.Tier.SMART -> sb.append("СЛОЖНАЯ ЗАДАЧА: рассуждай тщательно и по шагам, проверяй вычисления (calculate), затем дай чёткий итог. Если ответ длинный — сохрани его в файл (write_file, Documents/) и кратко перескажи вслух.\n")
            else -> {}
        }
        sb.append("Сейчас: $now. Устройство: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}.\n")
        if (name.isNotBlank()) sb.append("Пользователя зовут $name.\n")
        val custom = Prefs.str(ctx, Prefs.CUSTOM_PROMPT)
        if (custom.isNotBlank()) sb.append("Пожелания пользователя: $custom\n")
        sb.append(com.dk.darlin.tools.Memory.promptBlock(ctx))
        if (screen != null && Prefs.bool(ctx, Prefs.SCREEN_TEXT, true)) {
            screen.packageName?.let { sb.append("Ассистент вызван поверх приложения «${appLabel(it)}» ($it).\n") }
            screen.webUri?.let { sb.append("Открытая страница: $it\n") }
            if (!screen.text.isNullOrBlank()) {
                sb.append("Текст на экране в момент вызова (если спрашивают про «экран», «это», «тут»):\n<<<\n")
                sb.append(screen.text.take(5000)).append("\n>>>\n")
            }
        }
        return sb.toString()
    }

    private fun appLabel(pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun imagePart(bmp: Bitmap): JSONObject = LlmClient.imagePart(bmp)

    /** Как обрабатывается запрос — чтобы панель выбрала фразу-заполнитель. */
    enum class Phase { LOCAL, LOCAL_NET, LLM, SMART, CODE }

    /** Время последнего решения быстрого роутера, мс (для отладки). */
    var lastRouteMs = 0.0
        private set
    /** Как был обработан последний запрос. */
    var lastPhase = Phase.LLM
        private set

    /**
     * Отвечает на реплику пользователя.
     * @param onAction вызывается (в главном потоке) с подписью каждого выполняемого действия.
     * @param onPhase вызывается (в главном потоке) один раз — как будет обработан запрос.
     */
    suspend fun respond(
        userText: String, screen: ScreenContext?, onAction: (String) -> Unit,
        onDelta: ((String) -> Unit)? = null, onPhase: ((Phase) -> Unit)? = null
    ): String {
        tools.screen = screen
        tools.launchedSomething = false
        tools.uiTask = false
        tools.keepAlive = false
        tools.didAction = false
        tools.hiddenAfterLaunch = false
        tools.keepOpen = UiAutomation.pending != null || com.dk.darlin.sys.DarlinNotificationListener.pending != null
        Conversation.touch()

        // 1. Быстрый путь: понятная команда — сразу, без ИИ
        if (Prefs.bool(ctx, Prefs.FAST_ROUTER, true) || !Prefs.hasBrain(ctx)) {
            val t0 = System.nanoTime()
            val pending = UiAutomation.pending != null || com.dk.darlin.sys.DarlinNotificationListener.pending != null
            val r = try { FastRouter.route(userText, pending) } catch (_: Exception) { null }
            lastRouteMs = (System.nanoTime() - t0) / 1e6
            if (r != null) {
                lastPhase = if (r.network) Phase.LOCAL_NET else Phase.LOCAL
                withContext(Dispatchers.Main) { onPhase?.invoke(lastPhase) }
                val answer = runRoute(r, onAction)
                if (answer != null) {
                    Conversation.messages.add(JSONObject().put("role", "user").put("content", userText))
                    Conversation.messages.add(JSONObject().put("role", "assistant").put("content", answer))
                    Conversation.trim()
                    return answer
                }
            }
        }

        if (!Prefs.hasBrain(ctx)) {
            local.handle(userText, onAction)?.let { return it }
            return "Я пока работаю в базовом режиме: умею открывать приложения, звонить, ставить будильники, таймеры, напоминания, заметки, фонарик и громкость. " +
                "Чтобы я отвечала на любые вопросы и работала с файлами и экраном, добавьте ключ ИИ в разделе «Параметры» — например, бесплатный ключ Google Gemini."
        }

        // 2. Выбор модели: код и сложные задачи — умной модели с долгим размышлением
        val tier = if (Prefs.bool(ctx, Prefs.SMART_AUTO, true)) FastRouter.tier(userText) else FastRouter.Tier.FAST
        llm.tier = if (tier == FastRouter.Tier.FAST) LlmClient.Tier.FAST else LlmClient.Tier.SMART
        lastPhase = when (tier) { FastRouter.Tier.CODE -> Phase.CODE; FastRouter.Tier.SMART -> Phase.SMART; else -> Phase.LLM }
        withContext(Dispatchers.Main) { onPhase?.invoke(lastPhase) }

        val userMsg = JSONObject().put("role", "user").put("content", userText)
        Conversation.messages.add(userMsg)
        Conversation.trim()
        var startIdx = Conversation.messages.indexOf(userMsg)
        var retried = false

        val wantsImage = screen?.screenshot != null && Prefs.bool(ctx, Prefs.SCREENSHOT, false) && screenWords.containsMatchIn(userText)

        return try {
            withContext(Dispatchers.IO) {
                var guard = 0
                val system = systemPrompt(screen, tier)
                while (true) {
                    val msgs = JSONArray()
                    msgs.put(JSONObject().put("role", "system").put("content", system))
                    val toolIdx = Conversation.messages.withIndex().filter { it.value.optString("role") == "tool" }.map { it.index }
                    val keepFull = toolIdx.takeLast(2).toSet()
                    for ((idx, m) in Conversation.messages.withIndex()) {
                        if (m.optString("role") == "tool" && idx !in keepFull) {
                            val c = m.optString("content")
                            if (c.length > 1500 && c.contains("Экран")) {
                                msgs.put(JSONObject(m.toString()).put("content", c.take(500) + "\n…(старое дерево экрана сокращено)"))
                                continue
                            }
                        }
                        if (m === userMsg && wantsImage) {
                            val parts = JSONArray().put(JSONObject().put("type", "text").put("text", userText)).put(imagePart(screen!!.screenshot!!))
                            msgs.put(JSONObject().put("role", "user").put("content", parts))
                        } else msgs.put(m)
                    }
                    val maxRounds = if (tools.uiTask) 15 else if (tier == FastRouter.Tier.CODE) 10 else 8
                    val toolsArg = if (guard < maxRounds) ToolSpecs.all else null
                    val reply = try { if (onDelta != null) {
                        // Поток: текст показывается и озвучивается, пока модель ещё пишет
                        val h = android.os.Handler(android.os.Looper.getMainLooper())
                        llm.chatStream(msgs, toolsArg) { d -> h.post { onDelta(d) } }
                    } else llm.chat(msgs, toolsArg) } catch (e: LlmHttpException) {
                        // Испорченная старая история (например, вызовы без подписи Gemini) — начинаем диалог с текущей реплики
                        if (e.historyProblem && guard == 0 && !retried && startIdx > 0) {
                            retried = true
                            val keep = Conversation.messages.indexOf(userMsg)
                            if (keep > 0) repeat(keep) { Conversation.messages.removeAt(0) }
                            startIdx = 0
                            continue
                        }
                        if (e.historyProblem) Conversation.reset()
                        throw e
                    }
                    val calls = reply.optJSONArray("tool_calls")
                    if (calls != null && calls.length() > 0) {
                        // Сохраняем ответ целиком: в tool_calls[].extra_content лежит подпись Gemini, её нужно вернуть без изменений
                        val assistant = ChatWire.assistantForHistory(reply)
                        Conversation.messages.add(assistant)
                        val list = (0 until calls.length()).map { i ->
                            val call = calls.getJSONObject(i)
                            val fn = call.getJSONObject("function")
                            val args = try { JSONObject(fn.optString("arguments").ifBlank { "{}" }) } catch (_: Exception) { JSONObject() }
                            Triple(call.optString("id", "call_$i"), fn.getString("name"), args)
                        }
                        val results = runCalls(list, onAction)
                        for ((n, c) in list.withIndex()) {
                            Conversation.messages.add(
                                JSONObject().put("role", "tool").put("tool_call_id", c.first)
                                    .put("name", c.second).put("content", results[n].take(12000))
                            )
                        }
                        guard++
                        continue
                    }
                    val text = reply.optString("content", "").let { if (it == "null") "" else it }.trim()
                    val answer = text.ifBlank { "Готово." }
                    Conversation.messages.add(ChatWire.assistantForHistory(reply).put("content", answer))
                    return@withContext answer
                }
                @Suppress("UNREACHABLE_CODE")
                ""
            }
        } catch (e: Exception) {
            if (e is kotlinx.coroutines.CancellationException) throw e
            // Без сети/ошибка API — пробуем выполнить команду локально
            if (startIdx >= 0) while (Conversation.messages.size > startIdx) Conversation.messages.removeAt(Conversation.messages.size - 1)
            local.handle(userText, onAction) ?: when (e) {
                is LlmHttpException -> e.message ?: "Ошибка сервиса ИИ."
                is java.net.UnknownHostException, is java.net.ConnectException, is java.net.SocketTimeoutException, is javax.net.ssl.SSLException ->
                    "Нет связи с сервисом ИИ. Проверьте интернет."
                else -> "Не получилось получить ответ ИИ: " + (e.message?.take(160) ?: "неизвестная ошибка") + "."
            }
        }
    }

    /** Выполнить маршрут быстрого пути. null — не вышло (отдать ИИ). */
    private suspend fun runRoute(r: FastRouter.Route, onAction: (String) -> Unit): String? {
        if (r.direct != null) return r.direct
        val tool = r.tool ?: return null
        withContext(Dispatchers.Main) { onAction(tools.label(tool, r.args)) }
        // Как и раньше в локальном режиме: инструменты сами уходят в фон, где нужно (сеть, файлы)
        var res = tools.run(tool, r.args)
        var used = r
        for (alt in r.alts) {
            if (!FastRouter.failed(res)) break
            val again = tools.run(tool, alt)
            if (!FastRouter.failed(again)) { res = again; used = r.copy(args = alt); break }
        }
        // Неизвестный контакт/приложение и есть ИИ — пусть он разберётся (возможно, это была не команда)
        if (FastRouter.failed(res) && Prefs.hasBrain(ctx) && tool in setOf("open_app", "call_phone")) return null
        return FastRouter.confirm(used, res)
    }

    /** Функции только для чтения — их безопасно выполнять одновременно. */
    private val parallelSafe = setOf(
        "weather", "exchange_rate", "crypto_price", "calculate", "convert_units", "wikipedia", "news", "web_search", "fetch_url",
        "read_file", "list_files", "search_files", "device_info", "network_info", "list_notes", "list_reminders", "list_memory",
        "read_notifications", "now_playing", "date_diff", "find_contact", "read_sms", "read_call_log", "list_calendar_events", "translate"
    )

    private suspend fun runCalls(list: List<Triple<String, String, JSONObject>>, onAction: (String) -> Unit): List<String> {
        if (list.size > 1 && list.all { it.second in parallelSafe }) {
            withContext(Dispatchers.Main) { onAction(list.joinToString(" · ") { tools.label(it.second, it.third) }) }
            return coroutineScope { list.map { c -> async(Dispatchers.IO) { tools.run(c.second, c.third) } }.awaitAll() }
        }
        val out = ArrayList<String>()
        for (c in list) {
            withContext(Dispatchers.Main) { onAction(tools.label(c.second, c.third)) }
            out += tools.run(c.second, c.third)
        }
        return out
    }
}
