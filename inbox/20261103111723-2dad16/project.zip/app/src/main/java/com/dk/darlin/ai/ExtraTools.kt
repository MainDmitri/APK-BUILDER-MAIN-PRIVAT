package com.dk.darlin.ai

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.ContentProviderOperation
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Process
import android.provider.AlarmClock
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.dk.darlin.core.Prefs
import com.dk.darlin.sys.CaptureActivity
import com.dk.darlin.sys.DarlinAccessibilityService
import com.dk.darlin.sys.DarlinNotificationListener
import com.dk.darlin.tools.Calc
import com.dk.darlin.tools.Info
import com.dk.darlin.tools.Memory
import com.dk.darlin.tools.Net
import com.dk.darlin.tools.QrDecoder
import com.dk.darlin.tools.Units
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.NetworkInterface
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.coroutines.resume

/** Дополнительные возможности Дарлин: информация из интернета, уведомления, зрение, система, память, сценарии, архивы. */
class ExtraTools(private val exec: ToolExecutor) {
    private val ctx: Context get() = exec.appContext
    private val llm by lazy { LlmClient(ctx) }

    companion object {
        /** Функции, после которых панель можно закрыть (разовое действие). */
        val oneShot = setOf(
            "toggle_setting", "set_brightness", "set_ringer", "play_on", "call_taxi", "show_on_map", "create_contact",
            "zip_files", "unzip", "show_timers", "cancel_timer", "cancel_alarm", "clear_notifications", "remember", "forget",
            "save_routine", "delete_routine", "set_conversation_mode"
        )

        fun label(name: String, a: JSONObject): String? = when (name) {
            "weather" -> "Смотрю погоду" + a.optString("city").takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()
            "exchange_rate" -> "Курс валют"
            "crypto_price" -> "Курс криптовалюты"
            "calculate" -> "Считаю"
            "convert_units" -> "Перевожу единицы"
            "translate" -> "Перевожу"
            "wikipedia" -> "Смотрю в Википедии: ${a.optString("query")}"
            "news" -> "Читаю новости"
            "read_notifications" -> "Смотрю уведомления"
            "reply_notification" -> "Готовлю ответ"
            "clear_notifications" -> "Убираю уведомления"
            "now_playing" -> "Что играет"
            "look_at_screen" -> "Рассматриваю экран"
            "scan_qr" -> "Ищу QR-код на экране"
            "take_photo" -> "Открываю камеру"
            "analyze_image" -> "Смотрю картинку"
            "create_contact" -> "Создаю контакт"
            "read_call_log" -> "Смотрю звонки"
            "network_info" -> "Проверяю сеть"
            "toggle_setting" -> "Переключаю: ${a.optString("setting")}"
            "set_brightness" -> "Яркость"
            "set_ringer" -> "Режим звонка"
            "play_on" -> "Включаю «${a.optString("query")}»"
            "call_taxi" -> "Такси до «${a.optString("destination")}»"
            "show_on_map" -> "Открываю карту"
            "daily_briefing" -> "Готовлю сводку дня"
            "remember" -> "Запоминаю"
            "forget" -> "Забываю"
            "list_memory" -> "Вспоминаю"
            "save_routine" -> "Сохраняю сценарий"
            "list_routines" -> "Сценарии"
            "delete_routine" -> "Удаляю сценарий"
            "app_usage" -> "Статистика приложений"
            "zip_files" -> "Архивирую"
            "unzip" -> "Распаковываю"
            "show_timers" -> "Таймеры"
            "cancel_timer" -> "Отменяю таймер"
            "cancel_alarm" -> "Отменяю будильник"
            "set_conversation_mode" -> "Режим беседы"
            "random" -> "Случайный выбор"
            "date_diff" -> "Считаю дни"
            else -> null
        }
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    private suspend fun <T> io(block: () -> T): T = withContext(Dispatchers.IO) { block() }

    /** null — функция не из этого набора. */
    suspend fun run(name: String, a: JSONObject): String? = when (name) {
        "weather" -> weather(a.optString("city"), a.optInt("day", 0), a.optInt("days", 1))
        "exchange_rate" -> rate(a.optString("from", "USD"), a.optString("to", "RUB"), a.optDouble("amount", 1.0).let { if (it.isNaN()) 1.0 else it })
        "crypto_price" -> crypto(a.optString("coin", "bitcoin"), a.optDouble("amount", 1.0).let { if (it.isNaN()) 1.0 else it })
        "calculate" -> calculate(a.optString("expression"))
        "convert_units" -> Units.convert(a.optDouble("value", 1.0).let { if (it.isNaN()) 1.0 else it }, a.optString("from"), a.optString("to"))
        "translate" -> translate(a.optString("text"), a.optString("to", "русский"), a.optBoolean("from_screen", false))
        "wikipedia" -> wikipedia(a.optString("query"), a.optString("lang", "ru"))
        "news" -> news(a.optString("source"), a.optString("topic"), a.optInt("count", 5))
        "read_notifications" -> DarlinNotificationListener.read(ctx, a.optString("app"), a.optInt("count", 10), a.optBoolean("only_messages", false))
        "reply_notification" -> DarlinNotificationListener.prepareReply(ctx, a.optString("app"), a.optString("contact"), a.optString("text")).also {
            if (DarlinNotificationListener.pending != null) exec.keepOpen = true
        }
        "clear_notifications" -> DarlinNotificationListener.dismiss(ctx, a.optString("app"))
        "now_playing" -> DarlinNotificationListener.nowPlaying(ctx)
            ?: if (!DarlinNotificationListener.isEnabled(ctx)) "Чтобы видеть, что играет, включите доступ к уведомлениям в «Настройке»." else "Сейчас ничего не играет."
        "look_at_screen" -> lookAtScreen(a.optString("question"))
        "scan_qr" -> scanQr()
        "take_photo" -> photo(a.optString("question"), camera = true)
        "analyze_image" -> if (a.optString("path").isNotBlank()) analyzeFile(a.optString("path"), a.optString("question")) else photo(a.optString("question"), camera = false)
        "create_contact" -> createContact(a.optString("name"), a.optString("phone"), a.optString("email"), a.optString("note"))
        "read_call_log" -> callLog(a.optInt("count", 10), a.optString("type", "all"), a.optString("contact"))
        "network_info" -> networkInfo()
        "toggle_setting" -> toggle(a.optString("setting"), if (a.has("on")) a.optBoolean("on") else null)
        "set_brightness" -> brightness(if (a.has("percent")) a.optInt("percent") else -1, if (a.has("auto")) a.optBoolean("auto") else null)
        "set_ringer" -> ringer(a.optString("mode"))
        "play_on" -> playOn(a.optString("service"), a.optString("query"))
        "call_taxi" -> taxi(a.optString("destination"), a.optString("service", "yandex"))
        "show_on_map" -> showOnMap(a.optString("query"), a.optString("app"))
        "daily_briefing" -> briefing()
        "remember" -> Memory.remember(ctx, a.optString("fact"))
        "forget" -> Memory.forget(ctx, a.optString("query"))
        "list_memory" -> Memory.list(ctx)
        "save_routine" -> Memory.saveRoutine(ctx, a.optString("name"), a.optString("steps"))
        "list_routines" -> Memory.routines(ctx).let { r -> if (r.isEmpty()) "Сценариев пока нет. Пример: «когда я скажу «еду домой» — построй маршрут домой и включи музыку»." else r.joinToString("\n") { "• «${it.name}»: ${it.steps}" } }
        "delete_routine" -> Memory.deleteRoutine(ctx, a.optString("name"))
        "app_usage" -> appUsage(a.optInt("days", 1))
        "zip_files" -> zip(a.optString("paths"), a.optString("to"))
        "unzip" -> unzip(a.optString("path"), a.optString("to"))
        "show_timers" -> if (Build.VERSION.SDK_INT >= 26 && exec.start(Intent(AlarmClock.ACTION_SHOW_TIMERS))) "Открыла таймеры." else "Приложение часов не поддерживает список таймеров."
        "cancel_timer" -> cancelTimer()
        "cancel_alarm" -> cancelAlarm(if (a.has("hour")) a.optInt("hour") else -1, a.optInt("minute", 0), a.optString("label"))
        "set_conversation_mode" -> { val on = a.optBoolean("on", true); Prefs.setBool(ctx, Prefs.CONVERSATION, on)
            if (on) "Режим беседы включён: после каждого ответа я снова слушаю. Скажите «стоп» или «хватит», чтобы закончить." else "Режим беседы выключен." }
        "random" -> random(a.optString("kind", "number"), a.optInt("min", 1), a.optInt("max", 100), a.optString("options"))
        "date_diff" -> dateDiff(a.optString("date"))
        else -> null
    }

    // ---------- Местоположение ----------
    @SuppressLint("MissingPermission")
    private suspend fun location(): Info.Place? {
        val fine = granted(Manifest.permission.ACCESS_FINE_LOCATION); val coarse = granted(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine || coarse) {
            val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } ?: continue
                if (best == null || l.time > best.time) best = l
            }
            if ((best == null || System.currentTimeMillis() - best.time > 3 * 3600_000L) && Build.VERSION.SDK_INT >= 30) {
                val provider = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER
                    else if (fine && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER else null
                if (provider != null) withTimeoutOrNull(8000) {
                    suspendCancellableCoroutine<Location?> { cont ->
                        try { lm.getCurrentLocation(provider, null, ctx.mainExecutor) { if (cont.isActive) cont.resume(it) } }
                        catch (_: Exception) { if (cont.isActive) cont.resume(null) }
                    }
                }?.let { best = it }
            }
            best?.let { l ->
                val name = io {
                    try {
                        @Suppress("DEPRECATION")
                        Geocoder(ctx, Locale.forLanguageTag("ru")).getFromLocation(l.latitude, l.longitude, 1)?.firstOrNull()?.let { it.locality ?: it.subAdminArea ?: it.adminArea }
                    } catch (_: Exception) { null }
                } ?: "У вас"
                return Info.Place(name, l.latitude, l.longitude)
            }
        }
        // Без геолокации — примерно по IP
        return try {
            io {
                val o = JSONObject(Net.get("https://ipwho.is/?lang=ru"))
                if (!o.optBoolean("success")) null else Info.Place(o.optString("city"), o.optDouble("latitude"), o.optDouble("longitude"), o.optString("region"), o.optString("country"))
            }
        } catch (_: Exception) { null }
    }

    // ---------- Погода ----------
    private suspend fun weather(city: String, day: Int, days: Int): String {
        val place = if (city.isNotBlank() && !city.lowercase().let { it == "здесь" || it == "тут" || it.contains("мо") && it.contains("мест") }) {
            // «в Москве» → «Москва»: пробуем исходное слово и формы именительного падежа
            io {
                (listOf(city) + FastRouter.phraseNominatives(city)).distinct().take(4).firstNotNullOfOrNull { c ->
                    try { Info.parseGeocode(Net.get(Info.geocodeUrl(c))) } catch (_: Exception) { null }
                }
            } ?: return "Не нашла город «$city»."
        } else location() ?: return "Не удалось определить местоположение. Назовите город или разрешите геолокацию в «Настройке»."
        val json = io { Net.get(Info.forecastUrl(place.lat, place.lon, maxOf(day + days, 2))) }
        val label = if (city.isBlank() && place.name == "У вас") "У вас" else "В ${place.name}".let { if (place.name.isBlank()) "Здесь" else it }
        return Info.formatWeather(json, label, day.coerceIn(0, 15), days.coerceIn(1, 14))
    }

    // ---------- Курсы ----------
    private suspend fun rate(fromRaw: String, toRaw: String, amount: Double): String {
        val from = Info.currencyCode(fromRaw) ?: return "Не знаю валюту «$fromRaw»."
        val to = Info.currencyCode(toRaw.ifBlank { "RUB" }) ?: return "Не знаю валюту «$toRaw»."
        if (Info.cryptoIds.containsKey(fromRaw.lowercase())) return crypto(fromRaw, amount)
        if (from == "RUB" || to == "RUB") {
            try {
                val (date, m) = io { Info.parseCbr(Net.get("https://www.cbr-xml-daily.ru/daily_json.js")) }
                val a = m[from]; val b = m[to]
                if (a != null && b != null) {
                    val v = amount * a / b
                    return "По курсу ЦБ РФ на $date: ${Calc.format(amount)} $from = ${Info.money(v)} $to."
                }
            } catch (_: Exception) {}
        }
        val rates = io { Info.parseEr(Net.get("https://open.er-api.com/v6/latest/$from")) }
        val r = rates[to] ?: return "Нет курса $from → $to."
        return "${Calc.format(amount)} $from = ${Info.money(amount * r)} $to (рыночный курс)."
    }

    private suspend fun crypto(coinRaw: String, amount: Double): String {
        val key = coinRaw.lowercase().trim()
        var id = Info.cryptoIds[key] ?: Info.cryptoIds.entries.firstOrNull { key.startsWith(it.key) }?.value
        if (id == null) {
            id = io {
                JSONObject(Net.get("https://api.coingecko.com/api/v3/search?query=" + Net.enc(coinRaw))).optJSONArray("coins")?.optJSONObject(0)?.optString("id")
            } ?: return "Не нашла криптовалюту «$coinRaw»."
        }
        val json = io { Net.get("https://api.coingecko.com/api/v3/simple/price?ids=$id&vs_currencies=usd,rub&include_24hr_change=true") }
        val base = Info.parseCoinGecko(json, id, coinRaw.replaceFirstChar { it.uppercase() }) ?: return "Нет данных по «$coinRaw»."
        if (amount != 1.0) {
            val o = JSONObject(json).optJSONObject(id)
            val usd = o?.optDouble("usd") ?: Double.NaN
            if (!usd.isNaN()) return "$base ${Calc.format(amount)} шт. ≈ ${Info.money(usd * amount)} $."
        }
        return base
    }

    private fun calculate(expr: String): String = try {
        val v = Calc.eval(expr)
        "${expr.trim()} = ${Calc.format(v)}"
    } catch (e: Calc.CalcException) { "Не смогла посчитать: ${e.message}." }

    // ---------- Перевод ----------
    private suspend fun screenTextNow(): String {
        exec.screen?.text?.takeIf { it.isNotBlank() }?.let { return it }
        val s = DarlinAccessibilityService.instance ?: return ""
        return withContext(Dispatchers.Main) { s.screenText() }
    }

    private suspend fun translate(textRaw: String, to: String, fromScreen: Boolean): String {
        if (!Prefs.hasBrain(ctx)) return "Для перевода нужен ключ ИИ в «Параметрах»."
        val text = if (textRaw.isBlank() || fromScreen) screenTextNow() else textRaw
        if (text.isBlank()) return "Нечего переводить: текст пустой, а текст экрана недоступен."
        val out = io {
            llm.ask("Ты профессиональный переводчик. Переведи текст пользователя на язык: $to. Сохрани смысл, тон и форматирование. Верни ТОЛЬКО перевод без пояснений.", text.take(8000))
        }
        return "Перевод на $to:\n$out"
    }

    // ---------- Википедия и новости ----------
    private suspend fun wikipedia(q: String, lang: String): String = io {
        val l = if (lang.matches(Regex("[a-z]{2,3}"))) lang else "ru"
        fun tryLang(lg: String): Pair<String, String>? {
            val title = Info.parseWikiSearch(Net.get(Info.wikiSearchUrl(q, lg), ua = "DarlinAssistant/1.0 (Android)")) ?: return null
            return Info.parseWikiSummary(Net.get(Info.wikiSummaryUrl(title, lg), ua = "DarlinAssistant/1.0 (Android)"))
        }
        val r = tryLang(l) ?: if (l != "en") tryLang("en") else null
        r?.let { "${it.first.take(2500)}\nИсточник: ${it.second}" } ?: "В Википедии ничего не нашла про «$q»."
    }

    private suspend fun news(source: String, topic: String, count: Int): String = io {
        val n = count.coerceIn(1, 15)
        if (topic.isNotBlank()) {
            try {
                val items = Info.parseRss(Net.get("https://news.google.com/rss/search?hl=ru&gl=RU&ceid=RU:ru&q=" + Net.enc(topic)))
                if (items.isNotEmpty()) return@io Info.formatNews("Новости по теме «$topic»", items, n, false)
            } catch (_: Exception) {}
            val words = topic.lowercase().split(' ').filter { it.length > 2 }.map { it.take(maxOf(4, it.length - 2)) }
            val all = Info.feeds.values.flatMap { (_, url) -> try { Info.parseRss(Net.get(url)) } catch (_: Exception) { emptyList() } }
            val hits = all.filter { i -> val t = (i.title + " " + i.desc).lowercase(); words.any { t.contains(it) } }
            return@io if (hits.isEmpty()) "Свежих новостей по теме «$topic» не нашла." else Info.formatNews("Новости по теме «$topic»", hits.distinctBy { it.title }, n, false)
        }
        val feed = Info.feedFor(source) ?: Info.feeds["lenta"]!!
        val items = Info.parseRss(Net.get(feed.second))
        Info.formatNews(feed.first, items, n, source.isNotBlank() && n <= 5)
    }

    // ---------- Зрение ----------
    private suspend fun screenshot(): Bitmap? {
        exec.screen?.screenshot?.let { return it }
        val s = DarlinAccessibilityService.instance ?: return null
        exec.hideForCapture()
        delay(650)
        return s.screenshot()
    }

    private suspend fun lookAtScreen(question: String): String {
        if (!Prefs.hasBrain(ctx)) return "Чтобы рассмотреть экран, нужен ключ ИИ в «Параметрах»."
        val bmp = screenshot() ?: return if (DarlinAccessibilityService.instance == null)
            "Не могу сделать снимок экрана: включите службу «Управление экраном» в «Настройке» (или «Использовать скриншот» в настройках помощника)."
        else "Система не дала сделать снимок экрана — возможно, приложение защищено от скриншотов."
        val q = question.ifBlank { "Опиши, что на экране, и перепиши важный текст." }
        return io {
            "Снимок экрана: " + llm.vision("Ты — зрение голосового помощника. Отвечай по-русски, кратко и по делу. Если просят прочитать или распознать текст (OCR) — перепиши его точно.", q, bmp)
        }
    }

    private suspend fun scanQr(): String {
        val bmp = screenshot() ?: return "Не могу сделать снимок экрана: включите «Управление экраном» в «Настройке»."
        val text = io {
            val w = bmp.width; val h = bmp.height
            val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
            QrDecoder.decodeArgb(px, w, h) ?: run {
                // Мелкий код на большом экране — пробуем увеличенную середину
                val cw = w / 2; val ch = h / 2
                val crop = Bitmap.createScaledBitmap(Bitmap.createBitmap(bmp, w / 4, h / 4, cw, ch), cw * 2, ch * 2, false)
                val p2 = IntArray(crop.width * crop.height); crop.getPixels(p2, 0, crop.width, 0, 0, crop.width, crop.height)
                QrDecoder.decodeArgb(p2, crop.width, crop.height)
            }
        }
        if (text == null) {
            return if (Prefs.hasBrain(ctx)) io {
                "Не смогла распознать QR-код сама. ИИ видит: " + llm.vision("Ты распознаёшь QR-коды и штрих-коды на снимке. Если не можешь прочитать — так и скажи.", "Что закодировано в QR-коде или штрих-коде на снимке?", bmp)
            } else "QR-код на экране не нашла."
        }
        val isUrl = text.startsWith("http://") || text.startsWith("https://")
        return "QR-код: $text" + if (isUrl) "\nЭто ссылка — могу открыть её (open_url), если пользователь попросит." else ""
    }

    private fun loadBitmap(uri: Uri): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, info, _ ->
                val m = maxOf(info.size.width, info.size.height)
                if (m > 2000) d.setTargetSampleSize(m / 2000 + 1)
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        } else {
            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        }
    } catch (_: Exception) { null }

    private suspend fun photo(question: String, camera: Boolean): String {
        if (!Prefs.hasBrain(ctx)) return "Чтобы анализировать фото, нужен ключ ИИ в «Параметрах»."
        val d = CompletableDeferred<Uri?>()
        CaptureActivity.result = d
        if (!exec.start(CaptureActivity.intent(ctx, if (camera) CaptureActivity.MODE_CAMERA else CaptureActivity.MODE_PICK)))
            return "Не удалось открыть ${if (camera) "камеру" else "галерею"}."
        val uri = withTimeoutOrNull(TimeUnit.MINUTES.toMillis(3)) { d.await() } ?: return if (camera) "Снимок не сделан." else "Картинка не выбрана."
        val bmp = io { loadBitmap(uri) } ?: return "Не удалось открыть изображение."
        val q = question.ifBlank { "Что на этом фото? Опиши кратко, перепиши важный текст, если он есть." }
        return io { "Фото: " + llm.vision("Ты — зрение голосового помощника. Отвечай по-русски, кратко. Если просят перевести текст на фото — переведи.", q, bmp) }
    }

    private suspend fun analyzeFile(path: String, question: String): String {
        if (!Prefs.hasBrain(ctx)) return "Чтобы анализировать картинки, нужен ключ ИИ в «Параметрах»."
        val f = Files.resolve(path)
        if (!f.isFile) return "Файл не найден: $path"
        val bmp = io { loadBitmap(Uri.fromFile(f)) ?: BitmapFactory.decodeFile(f.absolutePath) } ?: return "Это не картинка или файл повреждён."
        return io { llm.vision("Ты — зрение голосового помощника. Отвечай по-русски, кратко.", question.ifBlank { "Что на картинке?" }, bmp) }
    }

    // ---------- Контакты и звонки ----------
    private suspend fun createContact(name: String, phone: String, email: String, note: String): String {
        if (name.isBlank() && phone.isBlank()) return "Нужно имя или номер."
        if (granted(Manifest.permission.WRITE_CONTACTS)) {
            val ops = ArrayList<ContentProviderOperation>()
            ops.add(ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build())
            fun data(mime: String, vararg kv: Pair<String, Any>) {
                val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                    .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0).withValue(ContactsContract.Data.MIMETYPE, mime)
                kv.forEach { b.withValue(it.first, it.second) }
                ops.add(b.build())
            }
            if (name.isNotBlank()) data(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME to name)
            if (phone.isNotBlank()) data(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Phone.NUMBER to phone,
                ContactsContract.CommonDataKinds.Phone.TYPE to ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
            if (email.isNotBlank()) data(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Email.ADDRESS to email,
                ContactsContract.CommonDataKinds.Email.TYPE to ContactsContract.CommonDataKinds.Email.TYPE_HOME)
            if (note.isNotBlank()) data(ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE, ContactsContract.CommonDataKinds.Note.NOTE to note)
            return try {
                io { ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops) }
                "Контакт «${name.ifBlank { phone }}» создан" + (if (phone.isNotBlank()) " с номером $phone" else "") + "."
            } catch (e: Exception) { "Не удалось создать контакт: ${e.message}" }
        }
        val i = Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.NAME, name).putExtra(ContactsContract.Intents.Insert.PHONE, phone)
            .putExtra(ContactsContract.Intents.Insert.EMAIL, email).putExtra(ContactsContract.Intents.Insert.NOTES, note)
        return if (exec.start(i)) "Открыла новый контакт с заполненными данными — нажмите «Сохранить». (Чтобы я сохраняла сама, разрешите изменение контактов в «Настройке».)"
        else "Не нашла приложение контактов."
    }

    private suspend fun callLog(count: Int, type: String, contact: String): String = io {
        if (!granted(Manifest.permission.READ_CALL_LOG)) return@io "Нет доступа к журналу звонков. Выдайте его в «Настройке» → «Контакты и звонки»."
        val sel = when (type) {
            "missed" -> "${CallLog.Calls.TYPE}=${CallLog.Calls.MISSED_TYPE}"
            "incoming" -> "${CallLog.Calls.TYPE}=${CallLog.Calls.INCOMING_TYPE}"
            "outgoing" -> "${CallLog.Calls.TYPE}=${CallLog.Calls.OUTGOING_TYPE}"
            else -> null
        }
        val fmt = SimpleDateFormat("d MMM HH:mm", Locale.forLanguageTag("ru"))
        val out = ArrayList<String>()
        ctx.contentResolver.query(CallLog.Calls.CONTENT_URI, arrayOf(CallLog.Calls.CACHED_NAME, CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION),
            sel, null, CallLog.Calls.DATE + " DESC")?.use { c ->
            while (c.moveToNext() && out.size < count.coerceIn(1, 50)) {
                val nm = c.getString(0) ?: ""; val num = c.getString(1) ?: ""
                if (contact.isNotBlank() && !nm.contains(contact, true) && !num.contains(contact)) continue
                val t = when (c.getInt(2)) {
                    CallLog.Calls.MISSED_TYPE -> "пропущенный"; CallLog.Calls.INCOMING_TYPE -> "входящий"; CallLog.Calls.OUTGOING_TYPE -> "исходящий"
                    CallLog.Calls.REJECTED_TYPE -> "отклонённый"; else -> "звонок"
                }
                val dur = c.getLong(4)
                out.add("• ${fmt.format(Date(c.getLong(3)))} — $t, ${nm.ifBlank { num }}" + (if (nm.isNotBlank()) " ($num)" else "") + (if (dur > 0) ", ${dur / 60} мин ${dur % 60} с" else ""))
            }
        }
        if (out.isEmpty()) "Звонков не найдено." else "Звонки:\n" + out.joinToString("\n")
    }

    // ---------- Сеть ----------
    private suspend fun networkInfo(): String = io {
        val sb = StringBuilder()
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        if (caps == null) sb.append("Нет подключения к интернету.\n") else {
            val kind = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "мобильный интернет"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "сеть"
            }
            sb.append("Подключение: $kind")
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) sb.append(" через VPN")
            sb.append(". Скорость канала: ↓${caps.linkDownstreamBandwidthKbps / 1000} / ↑${caps.linkUpstreamBandwidthKbps / 1000} Мбит/с (оценка системы).")
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) sb.append(" Интернет может не работать (сеть не проверена).")
            sb.append('\n')
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                @Suppress("DEPRECATION")
                val wi = (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo
                if (wi != null) {
                    val ssid = wi.ssid?.trim('"')?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
                    sb.append("Wi-Fi: ${ssid ?: "сеть"}, сигнал ${WifiManager.calculateSignalLevel(wi.rssi, 5)}/4, ${wi.linkSpeed} Мбит/с, ${if (wi.frequency > 4900) "5 ГГц" else "2,4 ГГц"}.\n")
                }
            }
        }
        val local = try {
            NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
                .flatMap { it.inetAddresses.toList() }.filter { it is java.net.Inet4Address }.map { it.hostAddress }
        } catch (_: Exception) { emptyList() }
        if (local.isNotEmpty()) sb.append("Локальный IP: ${local.joinToString(", ")}.\n")
        try { sb.append("Внешний IP: ${Net.get("https://api.ipify.org", timeoutMs = 6000).trim()}.") } catch (_: Exception) { sb.append("Внешний IP узнать не удалось.") }
        sb.toString().trim()
    }

    // ---------- Переключатели ----------
    private val tileLabels = mapOf(
        "wifi" to listOf("wi-fi", "wi‑fi", "wifi", "wlan", "интернет", "internet"),
        "bluetooth" to listOf("bluetooth", "блютуз"),
        "hotspot" to listOf("точка доступа", "hotspot", "модем", "мобильная точка"),
        "airplane" to listOf("режим полета", "режим полёта", "авиарежим", "airplane", "flight mode", "в самолете"),
        "mobile_data" to listOf("мобильные данные", "мобильный интернет", "mobile data", "передача данных"),
        "location" to listOf("местоположение", "геолокация", "геоданные", "location", "gps"),
        "nfc" to listOf("nfc"),
        "battery_saver" to listOf("энергосбережение", "экономия заряда", "battery saver", "экономия энергии"),
        "dark_theme" to listOf("тёмная тема", "темная тема", "dark theme", "ночной режим", "тёмный режим"),
        "auto_rotate" to listOf("автоповорот", "auto-rotate", "auto rotate", "поворот экрана"),
        "dnd" to listOf("не беспокоить", "do not disturb")
    )

    private fun normSetting(s: String): String {
        val x = s.lowercase()
        return when {
            x.contains("wi") || x.contains("вай") -> "wifi"
            x.contains("blue") || x.contains("блют") -> "bluetooth"
            x.contains("точк") || x.contains("hotspot") || x.contains("модем") || x.contains("раздач") -> "hotspot"
            x.contains("полет") || x.contains("полёт") || x.contains("airplane") || x.contains("самол") || x.contains("авиа") -> "airplane"
            x.contains("мобильн") || x.contains("data") || x.contains("данны") -> "mobile_data"
            x.contains("гео") || x.contains("местополож") || x.contains("location") || x.contains("gps") -> "location"
            x.contains("nfc") -> "nfc"
            x.contains("энерго") || x.contains("эконом") || x.contains("saver") -> "battery_saver"
            x.contains("тем") || x.contains("dark") || x.contains("ночн") -> "dark_theme"
            x.contains("поворот") || x.contains("rotat") -> "auto_rotate"
            x.contains("беспоко") || x.contains("dnd") -> "dnd"
            else -> x
        }
    }

    private val names = mapOf(
        "wifi" to "Wi-Fi", "bluetooth" to "Bluetooth", "hotspot" to "точку доступа", "airplane" to "режим полёта", "mobile_data" to "мобильный интернет",
        "location" to "геолокацию", "nfc" to "NFC", "battery_saver" to "энергосбережение", "dark_theme" to "тёмную тему", "auto_rotate" to "автоповорот", "dnd" to "«Не беспокоить»"
    )

    private suspend fun toggle(settingRaw: String, on: Boolean?): String {
        val s = normSetting(settingRaw)
        val nm = names[s] ?: return "Не знаю переключатель «$settingRaw». Доступны: Wi-Fi, Bluetooth, точка доступа, режим полёта, мобильный интернет, геолокация, NFC, энергосбережение, тёмная тема, автоповорот, «Не беспокоить»."
        val verb = when (on) { true -> "Включила"; false -> "Выключила"; null -> "Переключила" }
        // 1. Прямые API, где Android это разрешает
        when (s) {
            "dnd" -> dnd(on ?: true)?.let { return it }
            "auto_rotate" -> if (Settings.System.canWrite(ctx)) {
                val cur = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1
                val v = on ?: !cur
                Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (v) 1 else 0)
                return if (v) "Автоповорот включён." else "Автоповорот выключен."
            }
            "wifi" -> if (Build.VERSION.SDK_INT < 29) {
                @Suppress("DEPRECATION")
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") val v = on ?: !wm.isWifiEnabled
                @Suppress("DEPRECATION") if (wm.setWifiEnabled(v)) return "$verb Wi-Fi."
            }
        }
        // 2. Плитка в быстрых настройках через «Управление экраном»
        if (DarlinAccessibilityService.instance != null) quickTile(s, on)?.let { return it }
        // 3. Системная панель или страница настроек
        val intent = when (s) {
            "wifi" -> Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
            "mobile_data" -> Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_DATA_ROAMING_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "hotspot" -> Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings")
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "nfc" -> Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_NFC else Settings.ACTION_NFC_SETTINGS)
            "battery_saver" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "dark_theme" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "auto_rotate" -> Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName))
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        if (exec.start(intent) || exec.start(Intent(Settings.ACTION_WIRELESS_SETTINGS))) {
            return if (s == "auto_rotate") "Чтобы я переключала автоповорот и яркость сама, разрешите Дарлин «Изменение системных настроек» — открыла этот экран."
            else "Android не даёт приложениям переключать $nm напрямую, поэтому открыла панель — нажмите переключатель. (Включите «Управление экраном», и я буду нажимать сама.)"
        }
        return "Не удалось открыть настройки."
    }

    private fun dnd(on: Boolean): String? {
        val filter = if (on) NotificationManager.INTERRUPTION_FILTER_PRIORITY else NotificationManager.INTERRUPTION_FILTER_ALL
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.isNotificationPolicyAccessGranted) { nm.setInterruptionFilter(filter); return if (on) "Включила «Не беспокоить»." else "Выключила «Не беспокоить»." }
        DarlinNotificationListener.instance?.let {
            it.requestInterruptionFilter(if (on) NotificationListenerService.INTERRUPTION_FILTER_PRIORITY else NotificationListenerService.INTERRUPTION_FILTER_ALL)
            return if (on) "Включила «Не беспокоить»." else "Выключила «Не беспокоить»."
        }
        return null
    }

    private suspend fun quickTile(setting: String, on: Boolean?): String? {
        val svc = DarlinAccessibilityService.instance ?: return null
        val labels = tileLabels[setting] ?: return null
        exec.hideForCapture()
        delay(350)
        withContext(Dispatchers.Main) { svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS) }
        delay(1100)
        fun stateOf(n: AccessibilityNodeInfo): Boolean? {
            if (n.isCheckable) return n.isChecked
            val sd = (if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.toString() else null)?.lowercase() ?: return null
            return when {
                sd.startsWith("выкл") || sd.contains("off") || sd.contains("отключ") -> false
                sd.startsWith("вкл") || sd.contains("on") || sd.contains("подключ") -> true
                else -> null
            }
        }
        val result = withContext(Dispatchers.Main) {
            var node: AccessibilityNodeInfo? = null
            for (r in svc.roots()) {
                node = svc.find(r, { n ->
                    val t = ((n.contentDescription ?: "").toString() + " " + (n.text ?: "").toString()).lowercase()
                    (n.isClickable || n.isCheckable) && labels.any { t.contains(it) }
                })
                if (node != null) break
            }
            val n = node ?: return@withContext null
            val cur = stateOf(n)
            if (on != null && cur == on) return@withContext "already"
            if (svc.click(n)) "clicked" else null
        }
        delay(600)
        withContext(Dispatchers.Main) {
            if (Build.VERSION.SDK_INT >= 31) svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
            else svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        }
        val nm = names[setting] ?: setting
        return when (result) {
            "already" -> "${nm.replaceFirstChar { it.uppercase() }} уже ${if (on == true) "включено" else "выключено"}."
            "clicked" -> "${when (on) { true -> "Включила"; false -> "Выключила"; null -> "Переключила" }} $nm через быстрые настройки."
            else -> null
        }
    }

    private suspend fun brightness(percent: Int, auto: Boolean?): String {
        if (!Settings.System.canWrite(ctx)) {
            exec.start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            return "Чтобы менять яркость, разрешите Дарлин «Изменение системных настроек» — открыла этот экран. Потом повторите команду."
        }
        val cr = ctx.contentResolver
        if (auto != null) Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
            if (auto) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        if (percent >= 0) {
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
            val p = percent.coerceIn(0, 100)
            // Восприятие яркости нелинейно — используем гамму
            val v = (Math.pow(p / 100.0, 2.2) * 254 + 1).toInt().coerceIn(1, 255)
            Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, v)
            return "Яркость $p%."
        }
        return if (auto == true) "Включила автояркость." else if (auto == false) "Выключила автояркость." else "Скажите, какую яркость поставить (0–100%)."
    }

    private fun ringer(mode: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val m = when {
            mode.contains("vib") || mode.contains("вибр") -> AudioManager.RINGER_MODE_VIBRATE
            mode.contains("sil") || mode.contains("бесшум") || mode.contains("тих") || mode.contains("без звук") -> AudioManager.RINGER_MODE_SILENT
            else -> AudioManager.RINGER_MODE_NORMAL
        }
        return try {
            am.ringerMode = m
            when (m) { AudioManager.RINGER_MODE_VIBRATE -> "Включила вибрацию вместо звонка."; AudioManager.RINGER_MODE_SILENT -> "Включила беззвучный режим."; else -> "Включила звук звонка." }
        } catch (e: SecurityException) {
            if (m == AudioManager.RINGER_MODE_SILENT) dnd(true) ?: "Для беззвучного режима нужен доступ к «Не беспокоить» — выдайте его в «Настройке»."
            else "Нет доступа к режиму звонка — выдайте доступ к «Не беспокоить» в «Настройке»."
        }
    }

    // ---------- Медиа-сервисы, такси, карты ----------
    private fun installed(pkg: String) = try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: Exception) { false }

    private suspend fun playOn(serviceRaw: String, q: String): String {
        val s = serviceRaw.lowercase()
        data class Svc(val title: String, val pkg: String, val playFromSearch: Boolean, val search: (String) -> String)
        val e: (String) -> String = { Uri.encode(it) }
        val svc = when {
            s.contains("youtube music") || s.contains("ютуб музык") || s == "youtube_music" -> Svc("YouTube Music", "com.google.android.apps.youtube.music", true) { "https://music.youtube.com/search?q=${e(it)}" }
            s.contains("you") || s.contains("ютуб") || s.contains("ютюб") -> Svc("YouTube", "com.google.android.youtube", false) { "https://www.youtube.com/results?search_query=${e(it)}" }
            s.contains("spot") || s.contains("спот") -> Svc("Spotify", "com.spotify.music", true) { "spotify:search:${e(it)}" }
            s.contains("яндекс") || s.contains("yandex") -> Svc("Яндекс Музыка", "ru.yandex.music", true) { "https://music.yandex.ru/search?text=${e(it)}" }
            s.contains("vk") || s.contains("вк") || s.contains("контакт") -> Svc("VK Музыка", "com.uma.musicvk", true) { "https://vk.com/audio?q=${e(it)}" }
            s.contains("звук") || s.contains("zvuk") -> Svc("Звук", "com.zvooq.openplay", true) { "https://zvuk.com/search?query=${e(it)}" }
            s.contains("rutube") || s.contains("рутуб") -> Svc("Rutube", "ru.rutube.app", false) { "https://rutube.ru/search/?query=${e(it)}" }
            else -> return exec.run("play_music", JSONObject().put("query", q))
        }
        if (q.isBlank()) return if (installed(svc.pkg) && exec.start(ctx.packageManager.getLaunchIntentForPackage(svc.pkg) ?: Intent())) "Открыла ${svc.title}." else "${svc.title} не установлен."
        if (installed(svc.pkg)) {
            if (svc.playFromSearch) {
                val i = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).setPackage(svc.pkg)
                    .putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*").putExtra(android.app.SearchManager.QUERY, q)
                if (exec.start(i)) return "Включаю «$q» в ${svc.title}."
            } else {
                val i = Intent(Intent.ACTION_SEARCH).setPackage(svc.pkg).putExtra("query", q)
                if (exec.start(i)) return "Ищу «$q» в ${svc.title}."
            }
            if (exec.start(Intent(Intent.ACTION_VIEW, Uri.parse(svc.search(q))).setPackage(svc.pkg))) return "Открыла поиск «$q» в ${svc.title}."
        }
        val web = svc.search(q).let { if (it.startsWith("spotify:")) "https://open.spotify.com/search/${e(q)}" else it }
        return if (exec.start(Intent(Intent.ACTION_VIEW, Uri.parse(web)))) "${svc.title} не установлен — открыла поиск «$q» в браузере." else "Не удалось открыть ${svc.title}."
    }

    private suspend fun geocodeAddress(q: String): Info.Place? = try {
        io { Info.parseNominatim(Net.get(Info.nominatimUrl(q), ua = "DarlinAssistant/1.0 (Android voice assistant)")) }
    } catch (_: Exception) { null }

    private suspend fun taxi(dest: String, serviceRaw: String): String {
        val s = serviceRaw.lowercase()
        val p = if (dest.isNotBlank()) geocodeAddress(dest) else null
        if (s.contains("uber") || s.contains("убер")) {
            val u = if (p != null) "uber://?action=setPickup&pickup=my_location&dropoff[latitude]=${p.lat}&dropoff[longitude]=${p.lon}&dropoff[nickname]=${Uri.encode(dest)}"
                else "uber://?action=setPickup&pickup=my_location"
            if (installed("com.ubercab") && exec.start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))) return "Открыла Uber с маршрутом до «$dest». Тариф и заказ подтвердите в приложении."
            if (exec.start(Intent(Intent.ACTION_VIEW, Uri.parse(u.replace("uber://", "https://m.uber.com/ul/"))))) return "Открыла Uber в браузере — подтвердите заказ там."
            return "Не удалось открыть Uber."
        }
        // Яндекс Go (по умолчанию)
        val q = if (p != null) "end-lat=${p.lat}&end-lon=${p.lon}&" else ""
        val deep = "yandextaxi://route?${q}appmetrica_tracking_id=1178268795219780156&ref=darlin"
        val pkg = listOf("ru.yandex.taxi", "ru.yandex.uber").firstOrNull { installed(it) }
        if (pkg != null && exec.start(Intent(Intent.ACTION_VIEW, Uri.parse(deep)).setPackage(pkg))) {
            return "Открыла Яндекс Go" + (if (p != null) " с маршрутом до «${p.name}»" else "") + ". Выберите тариф и подтвердите заказ в приложении — сама я заказ не оформляю."
        }
        if (exec.start(Intent(Intent.ACTION_VIEW, Uri.parse("https://3.redirect.appmetrica.yandex.com/route?${q}appmetrica_tracking_id=1178268795219780156&ref=darlin"))))
            return "Яндекс Go не установлен — открыла заказ такси через сайт."
        return "Не удалось открыть такси."
    }

    private suspend fun showOnMap(query: String, appRaw: String): String {
        val a = appRaw.lowercase(); val e = Uri.encode(query)
        val tries = ArrayList<Intent>()
        val yandex = Intent(Intent.ACTION_VIEW, Uri.parse("yandexmaps://maps.yandex.ru/?text=$e")).setPackage("ru.yandex.yandexmaps")
        val dgis = Intent(Intent.ACTION_VIEW, Uri.parse("dgis://2gis.ru/search/$e")).setPackage("ru.dublgis.dgismobile")
        val google = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$e")).setPackage("com.google.android.apps.maps")
        when {
            a.contains("2") || a.contains("гис") -> tries += dgis
            a.contains("google") || a.contains("гугл") -> tries += google
            a.contains("яндекс") || a.contains("yandex") -> tries += yandex
        }
        tries += listOf(yandex, google, dgis, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$e")))
        for (i in tries) if ((i.`package` == null || installed(i.`package`!!)) && exec.start(i)) return "Показываю на карте: «$query»."
        return if (exec.start(Intent(Intent.ACTION_VIEW, Uri.parse("https://yandex.ru/maps/?text=$e")))) "Открыла карту в браузере: «$query»." else "Нет приложения карт."
    }

    // ---------- Сводка дня ----------
    private suspend fun briefing(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val name = Prefs.str(ctx, Prefs.USER_NAME)
        val hello = when (h) { in 4..11 -> "Доброе утро"; in 12..16 -> "Добрый день"; in 17..22 -> "Добрый вечер"; else -> "Доброй ночи" } +
            (if (name.isNotBlank()) ", $name" else "") + "!"
        val sb = StringBuilder(hello).append(' ')
        sb.append("Сегодня ").append(SimpleDateFormat("EEEE, d MMMM", Locale.forLanguageTag("ru")).format(Date())).append(".\n")
        try { sb.append(weather("", 0, 1).lines().take(2).joinToString(" ")).append('\n') } catch (_: Exception) { sb.append("Погоду узнать не удалось.\n") }
        val cal = exec.run("list_calendar_events", JSONObject().put("days", 1))
        sb.append("Календарь: ").append(cal.take(800)).append('\n')
        val rem = exec.run("list_reminders", JSONObject())
        sb.append("Напоминания: ").append(rem.take(600)).append('\n')
        if (DarlinNotificationListener.instance != null) {
            val msgs = DarlinNotificationListener.active(ctx).filter { it.isMessage }
            if (msgs.isNotEmpty()) sb.append("Непрочитанные сообщения: ${msgs.size} (").append(msgs.take(4).joinToString(", ") { "${it.app}: ${it.title}" }).append(").\n")
        }
        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (bat != null) sb.append("Заряд: ${bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) * 100 / maxOf(1, bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100))}%.\n")
        try {
            val items = io { Info.parseRss(Net.get(Info.feeds["lenta"]!!.second)) }.take(3)
            if (items.isNotEmpty()) sb.append("Главные новости: ").append(items.joinToString("; ") { it.title }).append('.')
        } catch (_: Exception) {}
        return sb.toString().trim()
    }

    // ---------- Статистика приложений ----------
    private fun usageGranted(): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private suspend fun appUsage(days: Int): String {
        if (!usageGranted()) {
            exec.start(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return "Нужен доступ к статистике использования: включите «Дарлин» в открывшемся списке и повторите вопрос."
        }
        return io {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val cal = Calendar.getInstance()
            val end = cal.timeInMillis
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
            cal.add(Calendar.DAY_OF_YEAR, -(days.coerceIn(1, 30) - 1))
            val stats = usm.queryAndAggregateUsageStats(cal.timeInMillis, end)
            val list = stats.values.filter { it.totalTimeInForeground > 60_000 && it.packageName != ctx.packageName }
                .sortedByDescending { it.totalTimeInForeground }
            if (list.isEmpty()) return@io "Статистики пока нет."
            fun fmt(ms: Long): String { val m = ms / 60000; return if (m >= 60) "${m / 60} ч ${m % 60} мин" else "$m мин" }
            val total = list.sumOf { it.totalTimeInForeground }
            val period = if (days <= 1) "сегодня" else "за $days дн."
            "Экранное время $period: ${fmt(total)}.\n" + list.take(10).joinToString("\n") { "• ${DarlinNotificationListener.appLabel(ctx, it.packageName)} — ${fmt(it.totalTimeInForeground)}" }
        }
    }

    // ---------- Архивы ----------
    private fun parsePaths(raw: String): List<String> {
        val t = raw.trim()
        if (t.startsWith("[")) return try { JSONArray(t).let { a -> (0 until a.length()).map { a.getString(it) } } } catch (_: Exception) { listOf(t) }
        return t.split(Regex("[\\n;,]")).map { it.trim() }.filter { it.isNotEmpty() }
    }

    private suspend fun zip(pathsRaw: String, toRaw: String): String = io {
        val srcs = parsePaths(pathsRaw).map { Files.resolve(it) }
        if (srcs.isEmpty()) return@io "Укажите, что архивировать."
        srcs.firstOrNull { !it.exists() }?.let { return@io "Не найдено: ${it.path}" }
        val dest = if (toRaw.isNotBlank()) Files.resolve(toRaw).let { if (it.isDirectory) File(it, srcs[0].nameWithoutExtension + ".zip") else it }
            else File(srcs[0].parentFile, (if (srcs.size == 1) srcs[0].nameWithoutExtension else "архив") + ".zip")
        val target = if (dest.extension.lowercase() == "zip") dest else File(dest.path + ".zip")
        target.parentFile?.mkdirs()
        var count = 0
        ZipOutputStream(FileOutputStream(target)).use { zos ->
            fun add(f: File, base: String) {
                if (f.canonicalPath == target.canonicalPath) return
                if (f.isDirectory) { f.listFiles()?.forEach { add(it, "$base${f.name}/") }; return }
                zos.putNextEntry(ZipEntry(base + f.name)); FileInputStream(f).use { it.copyTo(zos) }; zos.closeEntry(); count++
            }
            srcs.forEach { add(it, "") }
        }
        "Архив готов: ${target.path.removePrefix("/storage/emulated/0/")} (файлов: $count, ${target.length() / 1024} КБ)."
    }

    private suspend fun unzip(path: String, toRaw: String): String = io {
        val src = Files.resolve(path)
        if (!src.isFile) return@io "Архив не найден: $path"
        val dir = if (toRaw.isNotBlank()) Files.resolve(toRaw) else File(src.parentFile, src.nameWithoutExtension)
        dir.mkdirs()
        val root = dir.canonicalPath + File.separator
        var count = 0
        ZipInputStream(FileInputStream(src)).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val out = File(dir, e.name)
                if (!out.canonicalPath.startsWith(root)) continue // защита от zip-slip
                if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); FileOutputStream(out).use { zis.copyTo(it) }; count++ }
            }
        }
        "Распаковала $count файлов в ${dir.path.removePrefix("/storage/emulated/0/")}."
    }

    // ---------- Часы ----------
    private suspend fun cancelTimer(): String {
        if (Build.VERSION.SDK_INT >= 28 && exec.start(Intent(AlarmClock.ACTION_DISMISS_TIMER))) return "Попросила часы отменить таймер."
        return if (Build.VERSION.SDK_INT >= 26 && exec.start(Intent(AlarmClock.ACTION_SHOW_TIMERS))) "Открыла таймеры — остановите нужный." else "Приложение часов этого не поддерживает."
    }

    private suspend fun cancelAlarm(hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_DISMISS_ALARM)
        when {
            hour >= 0 -> i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_TIME)
                .putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
            label.isNotBlank() -> i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_LABEL).putExtra(AlarmClock.EXTRA_MESSAGE, label)
            else -> i.putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_NEXT)
        }
        if (exec.start(i)) return "Попросила часы отключить будильник" + (if (hour >= 0) " на %02d:%02d".format(hour, minute) else "") + ". Если часы спросят — подтвердите."
        return if (exec.start(Intent(AlarmClock.ACTION_SHOW_ALARMS))) "Открыла будильники — отключите нужный." else "Нет приложения часов."
    }

    // ---------- Мелочи ----------
    private val rnd = SecureRandom()
    private fun random(kind: String, min: Int, max: Int, options: String): String = when {
        options.isNotBlank() -> parsePaths(options).let { if (it.isEmpty()) "Нет вариантов." else "Выбираю: ${it[rnd.nextInt(it.size)]}." }
        kind.contains("coin") || kind.contains("монет") -> if (rnd.nextBoolean()) "Орёл!" else "Решка!"
        kind.contains("dice") || kind.contains("куб") -> "Выпало ${rnd.nextInt(6) + 1}."
        else -> { val lo = minOf(min, max); val hi = maxOf(min, max); "Случайное число: ${lo + rnd.nextInt(hi - lo + 1)}." }
    }

    fun dateDiff(dateRaw: String): String {
        val d = parseDate(dateRaw) ?: return "Не поняла дату «$dateRaw». Формат: 2026-12-31 или 31.12.2026."
        val today = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val days = Math.round((d.timeInMillis - today.timeInMillis) / 86_400_000.0)
        val ru = Locale.forLanguageTag("ru")
        val date = SimpleDateFormat("d MMMM yyyy", ru).format(d.time)
        val wd = SimpleDateFormat("EEEE", ru).format(d.time)
        return when {
            days > 0 -> "До $date ($wd) осталось $days ${plural(days, "день", "дня", "дней")}."
            days < 0 -> "С $date ($wd) прошло ${-days} ${plural(-days, "день", "дня", "дней")}."
            else -> "Это сегодня — $date, $wd."
        }
    }

    private fun parseDate(s: String): Calendar? {
        for (f in listOf("yyyy-MM-dd", "dd.MM.yyyy", "d.M.yyyy", "dd.MM")) {
            try {
                val df = SimpleDateFormat(f, Locale.US).apply { isLenient = false }
                val dt = df.parse(s.trim()) ?: continue
                val c = Calendar.getInstance().apply { time = dt }
                if (f == "dd.MM") {
                    val now = Calendar.getInstance()
                    c.set(Calendar.YEAR, now.get(Calendar.YEAR))
                    if (c.before(now) && (now.get(Calendar.DAY_OF_YEAR) != c.get(Calendar.DAY_OF_YEAR))) c.add(Calendar.YEAR, 1)
                }
                return c.apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun plural(n: Long, one: String, few: String, many: String): String {
        val m10 = n % 10; val m100 = n % 100
        return if (m10 == 1L && m100 != 11L) one else if (m10 in 2..4 && m100 !in 12..14) few else many
    }
}
