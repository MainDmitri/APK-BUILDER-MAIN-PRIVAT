package com.dk.darlin.ai

import android.content.Context
import com.dk.darlin.core.Prefs
import org.json.JSONArray
import org.json.JSONObject
import com.dk.darlin.core.Http
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException

/** Клиент любого OpenAI-совместимого API (/chat/completions, /models). */
class LlmClient(private val ctx: Context) {
    companion object {
        @Volatile var streamSupported = true
        @Volatile var reasoningSupported = true

        /** Картинка для vision-запроса (JPEG, не больше 1280 px по длинной стороне). */
        fun imagePart(bmp: android.graphics.Bitmap, maxSide: Int = 1280, quality: Int = 75): JSONObject {
            val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height))
            val b = if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val bos = java.io.ByteArrayOutputStream()
            b.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, bos)
            val b64 = android.util.Base64.encodeToString(bos.toByteArray(), android.util.Base64.NO_WRAP)
            return JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64"))
        }
    }

    /** Разовый запрос без инструментов: системная инструкция + текст пользователя. */
    fun ask(system: String, user: String): String {
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", user))
        return chat(msgs, null).optString("content").trim()
    }

    /** Вопрос по картинке (OCR, описание экрана, фото). */
    fun vision(system: String, prompt: String, bmp: android.graphics.Bitmap): String {
        val parts = JSONArray().put(JSONObject().put("type", "text").put("text", prompt)).put(imagePart(bmp, 1600, 82))
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system)).put(JSONObject().put("role", "user").put("content", parts))
        return chat(msgs, null).optString("content").trim()
    }

    /** Какую модель и с каким «размышлением» использовать. */
    enum class Tier { FAST, SMART }

    /** Ярус текущего запроса (Agent выставляет перед циклом). */
    var tier = Tier.FAST

    fun modelFor(t: Tier = tier): String {
        val auto = Prefs.str(ctx, "auto_model_${Prefs.providerId(ctx)}_${t.name}")
        if (auto.isNotEmpty() && !Prefs.modelIsCustom(ctx, t == Tier.SMART)) return auto
        return if (t == Tier.SMART) Prefs.smartModel(ctx) else Prefs.model(ctx)
    }

    private fun headers(b: Request.Builder): Request.Builder {
        b.header("Authorization", "Bearer " + Prefs.apiKey(ctx))
        if (Prefs.providerId(ctx) == "openrouter") {
            b.header("HTTP-Referer", "https://github.com/darlin-assistant")
            b.header("X-Title", "Darlin Assistant")
        }
        return b
    }

    private fun post(path: String, body: JSONObject, sse: Boolean): Response {
        val rb = Request.Builder().url(Prefs.baseUrl(ctx) + path)
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("Accept", if (sse) "text/event-stream" else "application/json")
        return Http.client.newCall(headers(rb).build()).execute()
    }

    /** История в формате текущего провайдера (Gemini — с подписями мыслей, остальным — только стандартные поля). */
    private fun wire(messages: JSONArray, model: String): JSONArray =
        ChatWire.prepare(messages, ChatWire.isGemini(Prefs.baseUrl(ctx), model), Prefs.providerId(ctx) == "openrouter")

    /** Тело запроса: модель, «размышление» (reasoning_effort) и лимит ответа по ярусу. */
    internal fun request(messages: JSONArray, tools: JSONArray?, model: String, t: Tier, stream: Boolean): JSONObject {
        val req = JSONObject()
        req.put("model", model)
        req.put("messages", wire(messages, model))
        if (tools != null && tools.length() > 0) {
            req.put("tools", tools)
            req.put("tool_choice", "auto")
        }
        val gemini = ChatWire.isGemini(Prefs.baseUrl(ctx), model)
        // Gemini 3+: температуру лучше не трогать (по умолчанию 1.0), иначе возможны зацикливания
        if (!gemini || Reasoning.legacyGemini(model)) req.put("temperature", if (t == Tier.SMART) 0.3 else 0.6)
        if (reasoningSupported) Reasoning.effort(model, t, gemini, Prefs.bool(ctx, Prefs.FAST_NO_THINK, true))?.let { req.put("reasoning_effort", it) }
        if (t == Tier.SMART && gemini) req.put("max_tokens", 60_000)
        if (stream) req.put("stream", true)
        return req
    }

    /** Модель не найдена/недоступна — пробуем следующую из списка по умолчанию (только если пользователь не выбрал свою). */
    private inline fun <T> withFallback(t: Tier, block: (String) -> T): T {
        var model = modelFor(t)
        val chain = if (Prefs.modelIsCustom(ctx, t == Tier.SMART)) emptyList() else Reasoning.fallbacks(Prefs.providerId(ctx), t)
        var idx = chain.indexOf(model)
        while (true) {
            try { return block(model) } catch (e: LlmHttpException) {
                if (e.code == 400 && reasoningSupported && e.raw.contains("reasoning_effort", ignoreCase = true)) { reasoningSupported = false; continue }
                val missing = e.code == 404 || (e.code == 400 && Regex("(?i)not found|is not supported|unknown model|model .*not exist|no longer available").containsMatchIn(e.raw)) || e.code == 403 && e.raw.contains("model", true)
                if (!missing || idx + 1 >= chain.size) throw e
                idx = maxOf(idx, -1) + 1
                model = chain[idx]
                Prefs.setStr(ctx, "auto_model_${Prefs.providerId(ctx)}_${t.name}", model)
            }
        }
    }

    private fun readOrThrow(r: Response, model: String): String {
        val body = r.body?.string() ?: ""
        if (!r.isSuccessful) throw ChatWire.friendlyError(r.code, body, model)
        return body
    }

    /** Возвращает объект message первого варианта ответа. */
    fun chat(messages: JSONArray, tools: JSONArray?): JSONObject = withFallback(tier) { model ->
        val body = post("/chat/completions", request(messages, tools, model, tier, false), false).use { readOrThrow(it, model) }
        val j = JSONObject(body)
        val choices = j.optJSONArray("choices") ?: throw IOException("Пустой ответ модели: ${body.take(300)}")
        choices.getJSONObject(0).getJSONObject("message")
    }

    /**
     * Потоковый запрос (stream=true, SSE): текст ответа приходит в [onDelta] по мере генерации,
     * чтобы показывать и озвучивать его сразу. Возвращает собранный message (как [chat]).
     * Если сервер не умеет stream — тихо откатывается на обычный запрос.
     */
    fun chatStream(messages: JSONArray, tools: JSONArray?, onDelta: (String) -> Unit): JSONObject {
        if (!streamSupported) return chat(messages, tools).also { m -> m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta) }
        return withFallback(tier) { model ->
            val r = post("/chat/completions", request(messages, tools, model, tier, true), true)
            r.use { resp ->
                if (!resp.isSuccessful) {
                    val body = resp.body?.string() ?: ""
                    if (resp.code == 400 && body.contains("stream", ignoreCase = true) && !body.contains("signature", ignoreCase = true)) {
                        streamSupported = false
                        return@withFallback chat(messages, tools).also { m -> m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta) }
                    }
                    throw ChatWire.friendlyError(resp.code, body, model)
                }
                val acc = StreamAccumulator(onDelta)
                val ctype = resp.header("Content-Type") ?: ""
                val src = resp.body!!.source()
                if (!ctype.contains("event-stream")) {
                    // Сервер проигнорировал stream=true и вернул обычный JSON
                    val j = JSONObject(src.readUtf8())
                    val m = j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: throw IOException("Пустой ответ модели")
                    m.optString("content").takeIf { it.isNotBlank() && it != "null" }?.let(onDelta)
                    return@withFallback m
                }
                while (true) {
                    val line = src.readUtf8Line() ?: break
                    if (!acc.line(line)) break
                }
                acc.message()
            }
        }
    }

    fun listModels(): List<String> {
        val r = Http.client.newCall(headers(Request.Builder().url(Prefs.baseUrl(ctx) + "/models").get()).build()).execute()
        val j = JSONObject(r.use { readOrThrow(it, Prefs.model(ctx)) })
        val arr = j.optJSONArray("data") ?: JSONArray()
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val id = arr.optJSONObject(i)?.optString("id") ?: continue
            out.add(id.removePrefix("models/"))
        }
        return out.sorted()
    }
}

/**
 * Сопоставление «размышления» с моделями (по ai.google.dev/gemini-api/docs/openai и /docs/thinking, ноябрь 2026):
 * reasoning_effort none — только Gemini 2.5 (Flash/Flash-Lite), у 2.5 Pro и Gemini 3+ мышление не отключается;
 * minimal — 3.5 Flash-Lite, 3.6 Flash, 3 Flash, 3.1 Flash-Lite; у 3.8 Flash, 4 Argon, 3.x Pro минимум — low; high — максимум.
 */
object Reasoning {
    fun legacyGemini(model: String) = Regex("gemini-(?:1\\.|2\\.0|2\\.5)").containsMatchIn(model)

    fun effort(model: String, t: LlmClient.Tier, gemini: Boolean, fastNoThink: Boolean): String? {
        val m = model.lowercase()
        if (gemini) {
            if (t == LlmClient.Tier.SMART) return "high"
            if (!fastNoThink) return null
            return when {
                m.contains("2.5-pro") -> "low"
                m.contains("2.5") || m.contains("2.0") -> "none"
                Regex("3\\.5-flash-lite|3\\.6-flash|3-flash|3\\.1-flash-lite").containsMatchIn(m) -> "minimal"
                else -> "low"
            }
        }
        // OpenAI: reasoning_effort понимают только «думающие» модели (o-серия, gpt-5)
        if (Regex("^(?:openai/)?(?:o\\d|gpt-5)").containsMatchIn(m)) return if (t == LlmClient.Tier.SMART) "high" else if (fastNoThink) (if (m.contains("gpt-5")) "minimal" else "low") else null
        return null
    }

    /** Цепочки моделей по умолчанию на случай, если ключу недоступна первая. */
    fun fallbacks(provider: String, t: LlmClient.Tier): List<String> = when (provider) {
        "gemini" -> if (t == LlmClient.Tier.SMART) listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-2.5-pro", "gemini-2.5-flash")
            else listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-2.5-flash-lite", "gemini-2.5-flash")
        else -> emptyList()
    }
}

/** Собирает ответ из SSE-кусочков OpenAI-формата: текст + вызовы функций (аргументы приходят по частям). */
class StreamAccumulator(private val onDelta: (String) -> Unit) {
    private val content = StringBuilder()
    private val calls = ArrayList<JSONObject>()      // {id, type, function:{name, arguments}}
    private val args = ArrayList<StringBuilder>()
    private val extra = JSONObject()

    /** Обрабатывает строку SSE. false — поток завершён ([DONE]). */
    fun line(raw: String): Boolean {
        val line = raw.trim()
        if (!line.startsWith("data:")) return true
        val data = line.removePrefix("data:").trim()
        if (data == "[DONE]") return false
        if (data.isEmpty()) return true
        val j = try { JSONObject(data) } catch (_: Exception) { return true }
        j.optJSONObject("error")?.let { throw ChatWire.friendlyError(it.optInt("code", 400).let { c -> if (c in 100..599) c else 400 }, data, "") }
        val choices = j.optJSONArray("choices") ?: return true
        for (ci in 0 until choices.length()) {
            val delta = choices.optJSONObject(ci)?.let { it.optJSONObject("delta") ?: it.optJSONObject("message") } ?: continue
            val text = delta.optString("content", "")
            if (text.isNotEmpty() && text != "null") { content.append(text); onDelta(text) }
            // Прочие поля сообщения (extra_content с подписью Gemini, reasoning…) — сохраняем как есть
            val rest = JSONObject()
            for (k in delta.keys()) if (k != "content" && k != "tool_calls" && k != "role") rest.put(k, delta.opt(k))
            if (rest.length() > 0) ChatWire.merge(extra, rest, appendStrings = true)
            val tc = delta.optJSONArray("tool_calls") ?: continue
            for (k in 0 until tc.length()) {
                val t = tc.optJSONObject(k) ?: continue
                val id = t.optString("id", "")
                var idx = t.optInt("index", -1)
                if (idx < 0 || idx > calls.size) {
                    // У некоторых серверов (Gemini) нет index: новый id — новый вызов
                    idx = if (id.isNotEmpty() && calls.none { it.optString("id") == id }) calls.size else maxOf(0, calls.size - 1)
                }
                while (calls.size <= idx) {
                    calls += JSONObject().put("id", "").put("type", "function").put("function", JSONObject().put("name", "").put("arguments", ""))
                    args += StringBuilder()
                }
                val call = calls[idx]
                if (id.isNotEmpty()) call.put("id", id)
                t.optJSONObject("function")?.let { f ->
                    val n = f.optString("name", "")
                    if (n.isNotEmpty() && n != "null") call.getJSONObject("function").put("name", n)
                    val a = f.optString("arguments", "")
                    if (a.isNotEmpty() && a != "null") args[idx].append(a)
                }
                // extra_content.google.thought_signature и любые другие поля — без изменений (подпись может прийти отдельным куском)
                val other = JSONObject()
                for (k in t.keys()) if (k != "index" && k != "id" && k != "function") other.put(k, t.opt(k))
                if (other.length() > 0) ChatWire.merge(call, other, appendStrings = false)
            }
        }
        return true
    }

    fun message(): JSONObject {
        val m = ChatWire.copy(extra).put("role", "assistant").put("content", content.toString())
        if (calls.isNotEmpty()) {
            val arr = JSONArray()
            for ((i, c) in calls.withIndex()) {
                if (c.getJSONObject("function").optString("name").isEmpty()) continue
                if (c.optString("id").isEmpty()) c.put("id", "call_$i")
                c.getJSONObject("function").put("arguments", args[i].toString().ifBlank { "{}" })
                arr.put(c)
            }
            if (arr.length() > 0) m.put("tool_calls", arr)
        }
        return m
    }
}
