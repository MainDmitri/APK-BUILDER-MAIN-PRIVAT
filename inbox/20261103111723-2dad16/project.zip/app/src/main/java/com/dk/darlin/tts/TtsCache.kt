package com.dk.darlin.tts

import android.content.Context
import com.dk.darlin.core.Prefs
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/**
 * Кэш озвучки на диске: частые фразы («Секунду…», «Включила фонарик.») синтезируются один раз
 * (при первом запуске и при смене голоса) и дальше звучат мгновенно, без сети.
 * Короткие фразы, синтезированные по ходу работы, тоже попадают в кэш.
 */
object TtsCache {
    val FILLERS_ACTION = listOf("Сейчас сделаю.", "Секунду…", "Минутку.")
    val FILLERS_QUESTION = listOf("Секунду…", "Сейчас посмотрю.", "Сейчас узнаю.")
    val FILLERS_THINK = listOf("Дай подумать…", "Хм, секунду…")
    const val CODE = "Берусь за код, это займёт минутку."

    val PHRASES = (FILLERS_ACTION + FILLERS_QUESTION + FILLERS_THINK + listOf(
        CODE, "Готово.", "Хорошо.", "Открываю.", "Звоню.", "Записала.", "Запомнила.", "Всегда пожалуйста!",
        "Включила фонарик.", "Выключила фонарик.", "Сделала громче.", "Сделала тише.", "Звук выключен.", "Звук включён.",
        "Пауза.", "Продолжаю.", "Следующий трек.", "Предыдущий трек.", "Сделала скриншот.", "Отправила.", "Отменила.",
        "Код готов.", "Слушаю."
    )).distinct()

    private const val MAX_FILES = 400
    private const val MAX_TEXT = 70
    private val mem = object : LinkedHashMap<String, ByteArray>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>?) = size > 80
    }

    fun norm(text: String) = text.lowercase(Locale.ROOT).replace('ё', 'е').replace("…", "").trim().trimEnd('.', '!', ' ')

    fun cacheable(text: String) = text.length in 2..MAX_TEXT && !text.any { it.isDigit() } || text in PHRASES

    private fun key(voice: String, rate: Int, pitch: Int, text: String): String {
        val md = MessageDigest.getInstance("SHA-1").digest("$voice|$rate|$pitch|${norm(text)}".toByteArray())
        return md.joinToString("") { "%02x".format(it) }
    }

    fun dir(c: Context) = File(c.applicationContext.filesDir, "tts_cache").apply { mkdirs() }

    fun get(c: Context, voice: String, rate: Int, pitch: Int, text: String): ByteArray? {
        if (text.length > MAX_TEXT) return null
        val k = key(voice, rate, pitch, text)
        synchronized(mem) { mem[k] }?.let { return it }
        val f = File(dir(c), "$k.mp3")
        if (!f.exists() || f.length() < 200) return null
        return try { f.readBytes().also { b -> synchronized(mem) { mem[k] = b }; f.setLastModified(System.currentTimeMillis()) } } catch (_: Exception) { null }
    }

    /** Для текущего голоса из настроек. */
    fun get(c: Context, text: String): ByteArray? = get(c, Prefs.edgeVoice(c), Prefs.rate(c), Prefs.pitch(c), text)

    fun put(c: Context, voice: String, rate: Int, pitch: Int, text: String, mp3: ByteArray) {
        if (mp3.size < 200 || !cacheable(text)) return
        val k = key(voice, rate, pitch, text)
        try {
            val d = dir(c)
            val tmp = File(d, "$k.tmp"); tmp.writeBytes(mp3); tmp.renameTo(File(d, "$k.mp3"))
            synchronized(mem) { mem[k] = mp3 }
            val files = d.listFiles { f -> f.name.endsWith(".mp3") } ?: return
            if (files.size > MAX_FILES) files.sortedBy { it.lastModified() }.take(files.size - MAX_FILES).forEach { it.delete() }
        } catch (_: Exception) {}
    }

    @Volatile private var running = false
    @Volatile private var again = false

    /** Сгенерировать недостающие фразы для текущего голоса (в фоне, один поток; повторный вызов — перезапуск после текущего). */
    fun warmAsync(c: Context, done: ((Int) -> Unit)? = null) {
        val app = c.applicationContext
        if (Prefs.voiceEngine(app) == "system" || android.os.Build.FINGERPRINT == "robolectric") return
        synchronized(this) { if (running) { again = true; return }; running = true }
        Thread {
            var made = 0
            try {
                do {
                    again = false
                    made += warm(app, PHRASES, interruptible = true)
                } while (again)
            } finally { running = false }
            done?.invoke(made)
        }.apply { isDaemon = true; name = "darlin-tts-cache"; priority = Thread.MIN_PRIORITY }.start()
    }

    /** Синхронно: возвращает, сколько фраз синтезировано. */
    fun warm(c: Context, phrases: List<String> = PHRASES, interruptible: Boolean = false): Int {
        val voice = Prefs.edgeVoice(c); val rate = Prefs.rate(c); val pitch = Prefs.pitch(c)
        var n = 0
        for (p in phrases) {
            if (interruptible && again) break
            if (get(c, voice, rate, pitch, p) != null) continue
            val mp3 = try { EdgeTts.synthesize(p, voice, rate, pitch) } catch (_: Exception) {
                try { EdgeTts.synthesize(p, voice, rate, pitch) } catch (_: Exception) { null }
            } ?: break // нет сети — попробуем в другой раз
            put(c, voice, rate, pitch, p, mp3); n++
        }
        return n
    }

    fun has(c: Context, text: String) = get(c, text) != null
}
