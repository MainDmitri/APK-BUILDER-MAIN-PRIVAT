package com.dk.darlin.sys

import com.dk.darlin.core.safeClick
import com.dk.darlin.core.safeLongClick
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.widget.TextView
import com.dk.darlin.ui.Ui
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Необязательная служба специальных возможностей: по вашей команде читает экран,
 * нажимает, вводит текст и прокручивает — так Дарлин может управлять любым приложением.
 * Сама по себе ничего не собирает и не отправляет. Все методы вызываются в главном потоке.
 */
class DarlinAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    /** Время последнего события окна/содержимого — по нему понимаем, что экран «успокоился». */
    @Volatile var lastEventAt = 0L
        private set

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null) lastEventAt = android.os.SystemClock.uptimeMillis()
    }

    /**
     * Ждать, пока экран перестанет меняться: не меньше [minMs], затем до [quietMs] без событий, но не дольше [maxMs].
     * Вместо фиксированных пауз — обычно в 2–4 раза быстрее.
     */
    suspend fun awaitSettle(minMs: Long, quietMs: Long, maxMs: Long) {
        val start = android.os.SystemClock.uptimeMillis()
        kotlinx.coroutines.delay(minMs)
        while (true) {
            val now = android.os.SystemClock.uptimeMillis()
            if (now - start >= maxMs || now - lastEventAt >= quietMs) return
            kotlinx.coroutines.delay(40)
        }
    }
    override fun onInterrupt() {}
    override fun onDestroy() { hideCard(); if (instance === this) instance = null; super.onDestroy() }

    /** Корни окон других приложений (наши окна — панель, карточки — исключаются). */
    /** Снимок экрана (Android 11+). Возвращает null, если система не дала скриншот. */
    suspend fun screenshot(): android.graphics.Bitmap? {
        if (android.os.Build.VERSION.SDK_INT < 30) return null
        return kotlinx.coroutines.withTimeoutOrNull(4000) {
            kotlinx.coroutines.suspendCancellableCoroutine { cont ->
                try {
                    takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                        override fun onSuccess(r: ScreenshotResult) {
                            val bmp = try {
                                val hb = r.hardwareBuffer
                                val b = android.graphics.Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
                                hb.close(); b
                            } catch (_: Exception) { null }
                            if (cont.isActive) cont.resume(bmp)
                        }
                        override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
                    })
                } catch (_: Exception) { if (cont.isActive) cont.resume(null) }
            }
        }
    }

    fun roots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION || w.type == AccessibilityWindowInfo.TYPE_SYSTEM ||
                    w.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD
                ) w.root?.let { if (it.packageName?.toString() != packageName) list.add(it) }
            }
        } catch (_: Exception) {}
        if (list.isEmpty()) rootInActiveWindow?.let { if (it.packageName?.toString() != packageName) list.add(it) }
        return list
    }

    fun foregroundPackage(): String? = try {
        windows.firstOrNull { it.type == AccessibilityWindowInfo.TYPE_APPLICATION && it.root?.packageName?.toString() != packageName }
            ?.root?.packageName?.toString()
    } catch (_: Exception) { null } ?: rootInActiveWindow?.packageName?.toString()

    fun screenText(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 60 || sb.length > 12000) return
            if (!n.isVisibleToUser) return
            val t = n.text?.toString()?.trim()
            val d = n.contentDescription?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n') else if (!d.isNullOrEmpty()) sb.append('[').append(d).append("]\n")
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        for (r in roots()) walk(r, 0)
        return sb.toString().ifBlank { "(на экране нет текста)" }
    }

    // ---------- Дерево элементов для ИИ ----------
    private var indexed: List<AccessibilityNodeInfo> = emptyList()

    /** Пронумерованный список видимых элементов текущего экрана. Номера используются в ui_click/ui_type/ui_scroll. */
    fun snapshot(maxItems: Int = 150): String {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        val pkgs = LinkedHashSet<String>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || depth > 70 || nodes.size >= maxItems) return
            if (!n.isVisibleToUser) return
            n.packageName?.let { pkgs.add(it.toString()) }
            val t = n.text?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val d = n.contentDescription?.toString()?.replace('\n', ' ')?.trim().orEmpty()
            val hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString()?.trim().orEmpty() else ""
            val interesting = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable || n.isLongClickable || t.isNotEmpty() || d.isNotEmpty()
            if (interesting) {
                nodes.add(n)
                val cls = n.className?.toString()?.substringAfterLast('.') ?: "View"
                val id = n.viewIdResourceName?.substringAfter(":id/")
                val r = Rect(); n.getBoundsInScreen(r)
                sb.append('[').append(nodes.size - 1).append("] ").append(cls)
                if (t.isNotEmpty()) sb.append(" \"").append(t.take(80)).append('"')
                if (d.isNotEmpty() && d != t) sb.append(" desc=\"").append(d.take(60)).append('"')
                if (hint.isNotEmpty() && hint != t) sb.append(" hint=\"").append(hint.take(40)).append('"')
                if (!id.isNullOrEmpty()) sb.append(" id=").append(id)
                val f = ArrayList<String>()
                if (n.isClickable) f.add("click"); if (n.isEditable) f.add("edit"); if (n.isScrollable) f.add("scroll")
                if (n.isCheckable) f.add(if (n.isChecked) "checked" else "unchecked"); if (n.isFocused) f.add("focused")
                if (!n.isEnabled) f.add("disabled")
                if (f.isNotEmpty()) sb.append(" (").append(f.joinToString(",")).append(')')
                sb.append(" @").append(r.centerX()).append(',').append(r.centerY()).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        for (r in roots()) walk(r, 0)
        indexed = nodes
        val head = "Приложение на экране: ${pkgs.joinToString(", ").ifEmpty { "неизвестно" }}. Элементов: ${nodes.size}${if (nodes.size >= maxItems) " (показаны первые $maxItems — прокрутите, чтобы увидеть больше)" else ""}\n"
        return head + sb.toString().ifEmpty { "(элементов не видно — возможно, экран ещё загружается)" }
    }

    fun node(index: Int): AccessibilityNodeInfo? = indexed.getOrNull(index)?.also { it.refresh() }

    private fun clickNode(node: AccessibilityNodeInfo, long: Boolean = false): Boolean {
        val action = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        var c: AccessibilityNodeInfo? = node
        var depth = 0
        while (c != null && depth < 8) {
            if ((if (long) c.isLongClickable else c.isClickable) && c.isEnabled && c.performAction(action)) return true
            c = c.parent; depth++
        }
        return false
    }

    /** Нажатие по элементу; если элемент «не кликабелен» — настоящий тап жестом по его центру. */
    suspend fun clickIndex(index: Int, long: Boolean = false): Boolean {
        val n = node(index) ?: return false
        if (clickNode(n, long)) return true
        val r = Rect(); n.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY(), if (long) 700L else 60L)
    }

    suspend fun tap(x: Float, y: Float, durationMs: Long = 60): Boolean {
        if (x < 0 || y < 0) return false
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        return suspendCancellableCoroutine { cont ->
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!ok && cont.isActive) cont.resume(false)
        }
    }

    suspend fun swipe(up: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val (y1, y2) = if (up) dm.heightPixels * 0.72f to dm.heightPixels * 0.30f else dm.heightPixels * 0.30f to dm.heightPixels * 0.72f
        val path = Path().apply { moveTo(x, y1); lineTo(x, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 320)).build()
        return suspendCancellableCoroutine { cont ->
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
                override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
            }, null)
            if (!ok && cont.isActive) cont.resume(false)
        }
    }

    fun setText(index: Int?, text: String): Boolean {
        val target = (if (index != null) node(index) else null)
            ?: roots().firstNotNullOfOrNull { it.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }
            ?: roots().firstNotNullOfOrNull { r -> find(r, { it.isEditable && it.isVisibleToUser }) }
            ?: return false
        target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scrollIndex(index: Int?, forward: Boolean): Boolean {
        val act = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (index != null) {
            var c = node(index)
            while (c != null) { if (c.isScrollable && c.performAction(act)) return true; c = c.parent }
        }
        for (r in roots()) {
            val n = find(r, { it.isScrollable && it.isVisibleToUser }) ?: continue
            if (n.performAction(act)) return true
        }
        return false
    }

    fun global(action: String): Boolean {
        val a = when (action) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            "power_dialog" -> GLOBAL_ACTION_POWER_DIALOG
            "split_screen" -> GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN
            "screenshot" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            "lock_screen" -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            else -> return false
        }
        return performGlobalAction(a)
    }

    fun find(n: AccessibilityNodeInfo?, pred: (AccessibilityNodeInfo) -> Boolean, depth: Int = 0): AccessibilityNodeInfo? {
        if (n == null || depth > 70) return null
        if (pred(n)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), pred, depth + 1)?.let { return it }
        return null
    }

    fun findById(fullId: String): AccessibilityNodeInfo? {
        for (r in roots()) {
            r.findAccessibilityNodeInfosByViewId(fullId)?.firstOrNull { it.isVisibleToUser }?.let { return it }
        }
        return null
    }

    fun findByDescription(vararg labels: String): AccessibilityNodeInfo? {
        val set = labels.map { it.lowercase() }
        for (r in roots()) {
            find(r, { n ->
                n.isVisibleToUser && (n.contentDescription?.toString()?.lowercase()?.trim() in set || n.text?.toString()?.lowercase()?.trim() in set)
            })?.let { return it }
        }
        return null
    }

    fun click(node: AccessibilityNodeInfo): Boolean = clickNode(node)

    fun clickText(text: String): Boolean {
        val q = text.lowercase().trim()
        for (r in roots()) {
            val node = find(r, {
                it.isVisibleToUser && ((it.text?.toString()?.lowercase()?.contains(q) == true) ||
                    (it.contentDescription?.toString()?.lowercase()?.contains(q) == true))
            }) ?: continue
            if (clickNode(node)) return true
        }
        return false
    }

    fun typeText(text: String): Boolean = setText(null, text)
    fun scroll(forward: Boolean): Boolean = scrollIndex(null, forward)

    // ---------- Плавающая карточка поверх приложений (окно спец. возможностей) ----------
    private var card: View? = null

    /**
     * Показывает карточку сверху экрана. Не перекрывает остальной экран, поэтому не мешает управлению приложением.
     * [primary] == null — карточка-индикатор «Дарлин работает…» только с кнопкой [secondary].
     */
    fun showCard(message: String, primary: String?, onPrimary: (() -> Unit)?, secondary: String, onSecondary: () -> Unit) {
        hideCard()
        val d = { v: Int -> Ui.dp(this, v) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(this@DarlinAccessibilityService, 0xF0151A2C.toInt(), 22f, 0x559E85FF)
            setPadding(d(16), d(10), d(10), d(10))
            elevation = d(8).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "✦ $message"; setTextColor(Ui.TEXT); textSize = 14f; maxLines = 3
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        fun btn(label: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(if (filled) 0xFF1A0B4D.toInt() else Ui.TEXT)
            background = if (filled) Ui.round(this@DarlinAccessibilityService, 0xFF9E85FF.toInt(), 18f) else Ui.round(this@DarlinAccessibilityService, 0x22FFFFFF, 18f)
            setPadding(d(14), d(8), d(14), d(8))
            safeClick { hideCard(); onClick() }
        }
        if (primary != null && onPrimary != null) box.addView(btn(primary, true, onPrimary), LinearLayout.LayoutParams(-2, -2).apply { marginStart = d(6) })
        box.addView(btn(secondary, false, onSecondary), LinearLayout.LayoutParams(-2, -2).apply { marginStart = d(6) })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            y = d(36)
            horizontalMargin = 0.03f
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(box, lp)
            card = box
        } catch (_: Exception) {}
    }

    fun hideCard() {
        card?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        card = null
    }

    companion object {
        @Volatile var instance: DarlinAccessibilityService? = null
    }
}
