package com.dk.darlin.core

import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Общий HTTP-клиент: пул соединений, keep-alive и HTTP/2 — повторные запросы к ИИ идут без нового TLS-рукопожатия. */
object Http {
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(180, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .connectionPool(ConnectionPool(6, 5, TimeUnit.MINUTES))
            .protocols(listOf(Protocol.HTTP_2, Protocol.HTTP_1_1))
            .retryOnConnectionFailure(true)
            .build()
    }

    @Volatile private var lastWarm = 0L
    @Volatile private var lastHost = ""

    /** Заранее открыть соединение с сервером ИИ (DNS + TLS + HTTP/2), пока пользователь говорит. */
    fun prewarm(baseUrl: String) {
        if (baseUrl.isBlank()) return
        val origin = try { java.net.URI(baseUrl).let { "${it.scheme}://${it.authority}/" } } catch (_: Exception) { return }
        val now = System.currentTimeMillis()
        if (origin == lastHost && now - lastWarm < 60_000) return
        lastHost = origin; lastWarm = now
        Thread {
            try { client.newCall(Request.Builder().url(origin).head().build()).execute().close() } catch (_: Exception) { lastWarm = 0 }
        }.apply { isDaemon = true; name = "darlin-prewarm" }.start()
    }
}
