package com.dk.darlin.ai

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Буква/цифра слова. Явный класс вместо \\w и \\b: на Android (ICU) и в JVM они по-разному понимают кириллицу. */
private const val W = "[а-яёА-ЯЁa-zA-Z0-9_]"
private const val B = "(?:(?<=$W)(?!$W)|(?<!$W)(?=$W))"

/**
 * Быстрый путь: понятные команды телефону выполняются сразу, без запроса к ИИ.
 * Разбор устойчив к опечаткам и ошибкам распознавания речи («фанарик», «будильнек», «семь тридцать»).
 * Всё, что неоднозначно или состоит из нескольких шагов, отдаётся модели (возвращается null).
 */
object FastRouter {
    /** Решение роутера: вызвать [tool] с [args] (и запасными вариантами [alts]) или сразу ответить [direct]. */
    data class Route(
        val tool: String?,
        val args: JSONObject = JSONObject(),
        val alts: List<JSONObject> = emptyList(),
        val direct: String? = null,
        /** Нужен интернет (погода, курсы) — пока ждём, можно сказать «Сейчас посмотрю». */
        val network: Boolean = false,
        /** Озвучить только первую строку результата. */
        val firstLine: Boolean = false
    )

    private val ru: Locale = Locale.forLanguageTag("ru")

    // ---------- Нормализация ----------
    private val politeness = Regex("${B}(?:пожалуйста|плиз|please|будь добра|будь любезна|если можно|если не сложно)${B}")
    private val leadIn = Regex("^(?:(?:дарлин[гк]?|дарлина|дорлин|darling|darlin|слушай|послушай|эй|ну|а|так|короче|давай|можешь|можешь ли|ты можешь|не могла бы ты|могла бы ты|мне нужно|мне надо|надо|нужно|я хочу|хочу|хочу чтобы ты|сможешь|окей|ок|ok|ладно|теперь|ещё|еще|быстро|срочно)[\\s,]+)+")

    private val units = mapOf(
        "ноль" to 0, "один" to 1, "одна" to 1, "одну" to 1, "одного" to 1, "два" to 2, "две" to 2, "двух" to 2, "три" to 3, "трёх" to 3, "трех" to 3,
        "четыре" to 4, "четырёх" to 4, "четырех" to 4, "пять" to 5, "пяти" to 5, "шесть" to 6, "шести" to 6, "семь" to 7, "семи" to 7,
        "восемь" to 8, "восьми" to 8, "девять" to 9, "девяти" to 9, "десять" to 10, "десяти" to 10, "одиннадцать" to 11, "двенадцать" to 12,
        "тринадцать" to 13, "четырнадцать" to 14, "пятнадцать" to 15, "шестнадцать" to 16, "семнадцать" to 17, "восемнадцать" to 18,
        "девятнадцать" to 19
    )
    private val tens = mapOf(
        "двадцать" to 20, "тридцать" to 30, "сорок" to 40, "пятьдесят" to 50, "шестьдесят" to 60, "семьдесят" to 70, "восемьдесят" to 80, "девяносто" to 90
    )
    private val hundreds = mapOf("сто" to 100, "двести" to 200, "триста" to 300, "четыреста" to 400, "пятьсот" to 500)

    /** «двадцать пять» → «25», «семь тридцать» → «7 30». */
    fun numberize(s: String): String {
        val w = s.split(' ')
        val out = ArrayList<String>()
        var i = 0
        while (i < w.size) {
            if (hundreds[w[i]] == null && tens[w[i]] == null && units[w[i]] == null) { out += w[i]; i++; continue }
            var v = 0; var j = i
            hundreds[w[j]]?.let { v += it; j++ }
            if (j < w.size) tens[w[j]]?.let { v += it; j++ }
            if (j < w.size) units[w[j]]?.let { u -> if (j == i || u < 10) { v += u; j++ } }
            if (j == i) j++
            out += v.toString(); i = j
        }
        return out.joinToString(" ")
    }

    /** Ключевые слова команд — к ним «притягиваются» слова с опечатками. */
    private val vocab = listOf(
        "фонарик", "фонарь", "будильник", "будильники", "таймер", "громкость", "громче", "погромче", "потише", "погода", "погоду", "прогноз",
        "яркость", "напомни", "включи", "выключи", "отключи", "открой", "запусти", "позвони", "набери", "поставь", "следующий",
        "следующую", "предыдущий", "предыдущую", "пауза", "паузу", "курс", "доллара", "евро", "юаня", "биткоин", "биткоина", "новости",
        "уведомления", "скриншот", "заметку", "заметки", "запомни", "блютуз", "вайфай", "беспокоить", "режим", "полета", "вибрацию",
        "беззвучный", "музыку", "песню", "трек", "маршрут", "навигатор", "настройки", "напоминание", "посчитай", "сколько",
        "градусов", "температура", "сводка", "отмени", "останови", "продолжи", "перемотай", "мобильный", "интернет",
        "геолокацию", "автоповорот", "энергосбережение", "фонарика", "камеру", "калькулятор", "телеграм", "ватсап", "ютуб",
        "прочитай", "прочти", "покажи", "расскажи", "скажи", "сделай", "найди"
    )
    private val vocabSet = vocab.toSet()

    private fun dist(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length) {
            val c = if (a[i - 1] == b[j - 1]) 0 else 1
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c)
            if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) d[i][j] = minOf(d[i][j], d[i - 2][j - 2] + 1)
        }
        return d[a.length][b.length]
    }

    /** Исправляет опечатку в слове, если оно очень похоже на ключевое (первая буква совпадает). */
    fun fix(w: String): String {
        if (w.length < 5 || w in vocabSet || w.any { it.isDigit() }) return w
        // Глаголы в неопределённой форме («выключить», «позвонить») — это не опечатки
        if (w.endsWith("ть") || w.endsWith("ться") || w.endsWith("ти")) return w
        val max = if (w.length <= 6) 1 else 2
        var best: String? = null; var bd = 99
        for (v in vocab) {
            if (v[0] != w[0] || kotlin.math.abs(v.length - w.length) > max) continue
            val d = dist(w, v)
            if (d < bd) { bd = d; best = v }
        }
        return if (best != null && bd <= max) best else w
    }

    private val asr = listOf(
        Regex("${B}(?:вац?ап+|вотсап+|ватсап+|воцап+|вотс ап|ватс ап|whats ?app)${B}") to "whatsapp",
        Regex("${B}(?:вай ?фай|вайфай|wi-?fi|вифи)${B}") to "wifi",
        Regex("${B}(?:блютус|блютуз|блю туз|bluetooth)${B}") to "блютуз",
        Regex("${B}(?:телега|телегу|телеге|тг|тилеграм|телеграмм|telegram)${B}") to "телеграм",
        Regex("${B}(?:ютюб|ютьюб|ютубе|you ?tube)${B}") to "ютуб",
        Regex("${B}(?:куар|кьюар|кью ар|qr-?код|qr)${B}") to "qr",
        Regex("${B}пол ?часа${B}") to "30 минут",
        Regex("${B}полтора часа${B}") to "90 минут",
        Regex("${B}часик${W}*${B}") to "1 час",
        Regex("${B}минутк[уа]${B}") to "1 минуту",
        Regex("${B}секундочк[уа]${B}") to "1 секунду",
        Regex("${B}звук (?=на \\d|\\d)") to "громкость "
    )
    private val ordinals = listOf("перв", "втор", "трет", "четверт", "пят", "шест", "седьм", "восьм", "девят", "десят", "одиннадцат", "двенадцат")

    fun normalize(raw: String): String {
        var t = raw.lowercase(ru).replace('ё', 'е').replace(Regex("[«»\"“”!?¿¡…]"), " ").replace(Regex("(?<=\\p{L})-ка${B}"), "")
        t = t.replace(Regex("[,;]+"), " ").replace(Regex("\\.(?!\\d)"), " ").replace(Regex("\\s+"), " ").trim()
        t = politeness.replace(t, " ").replace(Regex("\\s+"), " ").trim()
        t = leadIn.replace(t, "").trim()
        t = t.split(' ').joinToString(" ") { fix(it) }
        t = numberize(t)
        for ((r, v) in asr) t = r.replace(t, v)
        return t.replace(Regex("\\s+"), " ").trim()
    }

    // ---------- Склонения ----------
    /** Возможные именительные формы слова («маме» → «мама», «максу» → «макс», «москве» → «москва»). */
    fun nominatives(word: String): List<String> {
        val w = word.trim()
        if (w.length < 3 || w.any { it.isDigit() }) return listOf(w)
        val out = LinkedHashSet<String>()
        val l = w.lowercase(ru)
        fun base(n: Int) = w.dropLast(n)
        when {
            l.endsWith("ке") || l.endsWith("ге") || l.endsWith("хе") -> { out += base(1) + "а"; out += base(1) }
            l.endsWith("ии") -> { out += base(1) + "я"; out += base(2) + "ий" }
            l.endsWith("ею") -> { out += base(2) + "ей"; out += base(1) + "я" }
            l.endsWith("ой") && l.length > 4 -> { out += base(2) + "а"; out += w }
            l.endsWith("ю") -> { out += base(1) + "й"; out += base(1) + "я" }
            l.endsWith("у") -> { out += base(1); out += base(1) + "а" }
            l.endsWith("е") -> { out += base(1) + "а"; out += base(1); out += base(1) + "я" }
            l.endsWith("и") -> { out += base(1) + "ь"; out += base(1) + "я"; out += base(1) + "а" }
            l.endsWith("ом") || l.endsWith("ем") -> out += base(2)
        }
        out += w
        return out.toList()
    }

    fun phraseNominatives(s: String): List<String> {
        val parts = s.trim().split(' ').filter { it.isNotBlank() }
        if (parts.isEmpty()) return emptyList()
        if (parts.size == 1) return nominatives(parts[0])
        val first = nominatives(parts[0]).first()
        return listOf(parts.joinToString(" ") { nominatives(it).first() }, "$first ${parts.drop(1).joinToString(" ")}", s.trim()).distinct()
    }

    private fun j(vararg kv: Pair<String, Any>) = JSONObject().apply { for ((k, v) in kv) put(k, v) }

    // ---------- Защита от «многоходовок» ----------
    private val verbs = Regex("${B}(?:включи|выключи|отключи|открой|запусти|поставь|позвони|набери|напиши|отправь|найди|сделай|напомни|скинь|прочитай|покажи|создай|удали|скажи|переведи)${B}")
    private val multiStep = Regex("${B}(?:и|а) (?:потом|затем|после|ещё|еще)${B}|${B}после этого${B}|${B}затем${B}|${B}а также${B}")
    private val questiony = Regex("^(?:почему|зачем|как |объясни|расскажи (?!новости)|что такое|что значит|чем отличается|можно ли|стоит ли|правда ли|кто (?!мне |писал|написал))")

    /** Разбор фразы. [pending] — ждём «да/нет» на подготовленное сообщение. */
    fun route(raw: String, pending: Boolean = false, now: Calendar = Calendar.getInstance()): Route? {
        val t = normalize(raw)
        if (t.isEmpty()) return null

        if (pending) {
            if (Regex("^(?:да|ага|угу|конечно|давай|отправь|отправляй|отправить|да отправь|да давай|верно|точно|ок|окей|yes|шли|отправляй давай)(?: .*)?$").matches(t)) return Route("confirm_send")
            if (Regex("^(?:нет|не надо|не отправляй|отмена|отмени|стоп|не|неа|не нужно)(?: .*)?$").matches(t)) return Route("cancel_send")
            return null
        }
        if (t.length > 90) return null
        if (multiStep.containsMatchIn(t)) return null
        // В тексте напоминания/заметки могут быть свои глаголы: «напомни через час выключить плиту»
        val freeText = Regex("^(?:напомни|запиши|запомни|закинь|добавь в заметк|сделай заметку|заметка)").containsMatchIn(t)
        if (!freeText && verbs.findAll(t).count() >= 2) return null
        if (Regex("${B}и\\s+(?:включи|выключи|открой|поставь|позвони|напиши|отправь|найди|сделай|напомни|скажи)").containsMatchIn(t)) return null
        if (questiony.containsMatchIn(t) && !Regex("^как (?:доехать|добраться|дойти|проехать)").containsMatchIn(t)) return null

        // ---- Вежливость ----
        if (Regex("^(?:спасибо|спасибо большое|благодарю|спасибки|спс|спасибо дарлин|спасибо тебе)$").matches(t)) return Route(null, direct = "Всегда пожалуйста!")

        // ---- Время, дата, заряд ----
        if (Regex("^(?:котор${W}+ (?:сейчас )?час|сколько (?:сейчас )?времени|сколько время|какое (?:сейчас )?время|время|точное время|сколько на часах)$").matches(t))
            return Route(null, direct = "Сейчас " + SimpleDateFormat("HH:mm", ru).format(now.time) + ".")
        if (Regex("^(?:какое (?:сегодня |сейчас )?число|какой (?:сегодня )?день(?: недели)?|какая (?:сегодня )?дата|какое сегодня|сегодня какое число|какой сегодня день)$").matches(t))
            return Route(null, direct = "Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy", ru).format(now.time) + ".")
        if (Regex("^(?:сколько |какой |какой у меня |уровень |проверь )?(?:заряд[аы]?|батаре[яи]|батарейк[аи]|процент${W}* (?:батареи|заряда))(?: (?:батареи|телефона|осталось|на телефоне|у телефона))*$").matches(t) ||
            Regex("^сколько (?:осталось )?(?:процентов|заряда)(?: батареи| на телефоне| у телефона)?$").matches(t))
            return Route("device_info", firstLine = true)

        // ---- Фонарик ----
        if (Regex("${B}(?:фонар${W}*|вспышк${W}*)${B}").containsMatchIn(t) || Regex("^(?:посвети|дай свет|подсвети)$").matches(t)) {
            if (t.split(' ').size > 6) return null
            val off = Regex("${B}(?:выключ${W}*|отключ${W}*|погаси|потуши|убери|выруби|вырубай|не надо|хватит)${B}").containsMatchIn(t)
            val on = Regex("${B}(?:включ${W}*|зажги|вруби|врубай|посвети|подсвети|дай|нужен)${B}").containsMatchIn(t)
            return when {
                off -> Route("flashlight", j("on" to false))
                on -> Route("flashlight", j("on" to true))
                else -> Route("flashlight")
            }
        }

        // ---- Будильник ----
        if (Regex("${B}будильник${W}*${B}").containsMatchIn(t) || t.startsWith("разбуди")) {
            if (Regex("${B}(?:выключи|отключи|удали|отмени|убери|сними|сбрось)${B}").containsMatchIn(t)) {
                val m = Regex("(\\d{1,2})(?:[:. ](\\d{2}))?").find(t)
                val a = JSONObject()
                if (m != null) { a.put("hour", pm(m.groupValues[1].toInt(), t)); a.put("minute", m.groupValues[2].toIntOrNull() ?: 0) }
                return Route("cancel_alarm", a)
            }
            if (Regex("^(?:покажи|какие|мои|открой|список)${B}.*будильник").containsMatchIn(t) || t == "будильники") return Route("show_alarms")
            Regex("через (\\d+)\\s*(час${W}*|минут${W}*|мин)(?: (\\d+)\\s*минут${W}*)?").find(t)?.let { m ->
                val add = if (m.groupValues[2].startsWith("час")) m.groupValues[1].toInt() * 60 + (m.groupValues[3].toIntOrNull() ?: 0) else m.groupValues[1].toInt()
                val c = (now.clone() as Calendar).apply { add(Calendar.MINUTE, add) }
                return Route("set_alarm", j("hour" to c.get(Calendar.HOUR_OF_DAY), "minute" to c.get(Calendar.MINUTE)))
            }
            Regex("${B}пол ?(" + ordinals.joinToString("|") + ")${W}*").find(t)?.let { m ->
                val n = ordinals.indexOf(m.groupValues[1]) + 1
                return Route("set_alarm", j("hour" to pm((n + 23) % 24, t), "minute" to 30))
            }
            Regex("(?:пол ?|половин[ау] )(\\d{1,2})(?:-?го|-?ого|ого|го)?").find(t)?.let { m ->
                // «в полседьмого» распознаётся как «пол 7» → 6:30
                val h = (m.groupValues[1].toInt() + 23) % 24
                return Route("set_alarm", j("hour" to pm(h, t), "minute" to 30))
            }
            Regex("(?:на|в|к)?\\s*(\\d{1,2})(?:\\s*(?:[:.]|час${W}*)?\\s*(\\d{1,2})(?!\\d))?\\s*(?:минут${W}*)?").findAll(t).firstOrNull { it.groupValues[1].isNotEmpty() }?.let { m ->
                val h = m.groupValues[1].toInt()
                val min = m.groupValues[2].toIntOrNull() ?: 0
                if (h > 23 || min > 59) return null
                return Route("set_alarm", j("hour" to pm(h, t), "minute" to min))
            }
            return null
        }

        // ---- Таймер ----
        if (Regex("${B}таймер${W}*${B}").containsMatchIn(t) || t.startsWith("засеки")) {
            if (Regex("${B}(?:отмени|выключи|отключи|останови|сбрось|убери|удали|стоп)${B}").containsMatchIn(t)) return Route("cancel_timer")
            if (Regex("${B}(?:покажи|какие|сколько осталось|мои)${B}").containsMatchIn(t)) return Route("show_timers")
            val sec = duration(t) ?: if (Regex("${B}на (?:1 )?минуту${B}").containsMatchIn(t)) 60 else null
            return if (sec != null && sec > 0) Route("set_timer", j("seconds" to sec)) else null
        }
        if (Regex("^сколько осталось(?: на таймере| таймеру)?$").matches(t)) return Route("show_timers")

        // ---- Напоминания ----
        if (t.startsWith("напомни")) {
            // «напомни через 10 минут позвонить маме»
            Regex("^напомни(?: мне)? через ((?:\\d+\\s*(?:час${W}*|минут${W}*|мин|секунд${W}*)\\s*)+)(?:что |о том что |чтобы |про |о |об )?(.+)$").find(t)?.let { m ->
                val sec = duration(m.groupValues[1]) ?: return@let
                val text = m.groupValues[2].trim()
                if (text.isEmpty()) return@let
                return Route("set_reminder", j("text" to text.replaceFirstChar { it.uppercase() }, "in_minutes" to maxOf(1, (sec + 59) / 60)))
            }
            // «напомни завтра в 9 купить молоко»
            Regex("^напомни(?: мне)? (?:(сегодня|завтра|послезавтра) )?в (\\d{1,2})(?:[: ](\\d{2}))?(?: (?:утра|вечера|дня|ночи))? (?:что |о том что |чтобы |про |о |об )?(.+)$").find(t)?.let { m ->
                val h = pm(m.groupValues[2].toInt(), t); val min = m.groupValues[3].toIntOrNull() ?: 0
                if (h > 23 || min > 59) return@let
                val c = (now.clone() as Calendar).apply {
                    set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min); set(Calendar.SECOND, 0)
                    when (m.groupValues[1]) { "завтра" -> add(Calendar.DAY_OF_MONTH, 1); "послезавтра" -> add(Calendar.DAY_OF_MONTH, 2); "" -> if (before(now)) add(Calendar.DAY_OF_MONTH, 1) }
                }
                return Route("set_reminder", j("text" to m.groupValues[4].trim().replaceFirstChar { it.uppercase() },
                    "datetime" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(c.time)))
            }
        }

        // ---- Громкость и звук ----
        Regex("^(?:сделай |поставь |установи )?громкость (?:на )?(\\d{1,3})(?: процент${W}*| %)?$").find(t)?.let {
            return Route("set_volume", j("percent" to it.groupValues[1].toInt().coerceIn(0, 100)))
        }
        if (Regex("^(?:сделай |поставь )?(?:громкость )?(?:на )?(?:максимум|максимальн${W}*|на всю|погромче на максимум)(?: громкость)?$").matches(t) || t == "громкость на максимум")
            return Route("set_volume", j("percent" to 100))
        if (Regex("^(?:сделай )?(?:громче|погромче|ещё громче|еще громче|прибавь(?: звук| громкость)?|увеличь (?:звук|громкость)|громкость (?:выше|больше|прибавь))$").matches(t))
            return Route("set_volume", j("direction" to "up"))
        if (Regex("^(?:сделай )?(?:тише|потише|ещё тише|еще тише|убавь(?: звук| громкость)?|уменьши (?:звук|громкость)|громкость (?:ниже|меньше|убавь))$").matches(t))
            return Route("set_volume", j("direction" to "down"))
        if (Regex("^(?:выключи|отключи|убери) звук$|^без звука$").matches(t)) return Route("set_volume", j("direction" to "mute"))
        if (Regex("^(?:включи|верни) звук$").matches(t)) return Route("set_volume", j("direction" to "unmute"))
        if (Regex("^(?:включи |поставь |сделай )?(?:беззвучный|бесшумный|тихий)(?: режим)?$|^(?:режим )?без звука на звонк${W}*$").matches(t)) return Route("set_ringer", j("mode" to "silent"))
        if (Regex("^(?:включи |поставь |переключи на )?(?:вибро|вибрацию|режим вибрации|на вибрацию|виброрежим)(?: режим)?$").matches(t)) return Route("set_ringer", j("mode" to "vibrate"))
        if (Regex("^(?:включи |верни )?(?:обычный режим|звук звонка|звонок обратно)$").matches(t)) return Route("set_ringer", j("mode" to "normal"))

        // ---- Яркость ----
        Regex("^(?:сделай |поставь |установи )?яркость (?:на )?(\\d{1,3})(?: процент${W}*| %)?$").find(t)?.let { return Route("set_brightness", j("percent" to it.groupValues[1].toInt().coerceIn(1, 100))) }
        if (Regex("^(?:сделай |включи )?(?:автояркость|автоматическую яркость|адаптивную яркость)$").matches(t)) return Route("set_brightness", j("auto" to true))
        if (Regex("^(?:сделай )?(?:ярче|поярче|экран ярче|яркость (?:на )?максимум|максимальная яркость|прибавь яркость|увеличь яркость)$").matches(t)) return Route("set_brightness", j("percent" to 100))
        if (Regex("^(?:сделай )?(?:темнее|потемнее|экран темнее|яркость (?:на )?минимум|убавь яркость|уменьши яркость|приглуши экран)$").matches(t)) return Route("set_brightness", j("percent" to 25))

        // ---- Переключатели ----
        toggle(t)?.let { return it }

        // ---- Музыка ----
        if (Regex("^(?:пауза|на паузу|поставь на паузу|поставь паузу|останови|стоп|стоп музыка|останови (?:музыку|песню|видео|воспроизведение)|выключи (?:музыку|песню))$").matches(t)) return Route("media_control", j("action" to "pause"))
        if (Regex("^(?:продолжи|продолжай|возобнови|играй|сними с паузы|сними паузу|продолжи (?:музыку|воспроизведение)|включи музыку|включи музыку обратно|play)$").matches(t)) return Route("media_control", j("action" to "play"))
        if (Regex("^(?:следующ${W}*(?: трек| песн${W}*| видео)?|дальше|переключи(?: трек| песню)?|скип|пропусти(?: песню| трек)?|другую песню|включи следующ${W}*(?: трек| песн${W}*)?)$").matches(t)) return Route("media_control", j("action" to "next"))
        if (Regex("^(?:предыдущ${W}*(?: трек| песн${W}*| видео)?|верни (?:прошл${W}*|предыдущ${W}*)(?: трек| песн${W}*)?|назад трек|прошлая песня|включи предыдущ${W}*(?: трек| песн${W}*)?)$").matches(t)) return Route("media_control", j("action" to "previous"))
        if (Regex("^перемотай(?: (?:на )?\\d+ секунд${W}*)? вперед$|^перемотай$|^вперед на 30 секунд$").matches(t)) return Route("media_control", j("action" to "forward"))
        if (Regex("^перемотай(?: (?:на )?\\d+ секунд${W}*)? назад$").matches(t)) return Route("media_control", j("action" to "rewind"))
        if (Regex("^(?:что (?:сейчас )?(?:играет|за песня|за трек|звучит)|как называется (?:эта )?(?:песня|трек)|чья (?:это )?песня)$").matches(t)) return Route("now_playing")
        val svcs = "(ютуб|youtube|ютуб музык${W}*|youtube music|спотифа${W}*|spotify|яндекс музык${W}*|вк|вконтакте|звук${W}*|рутуб${W}*)"
        (Regex("^(?:включи|поставь|запусти|найди и включи|вруби) (.+?) (?:на|в) $svcs$").find(t)?.let { it.groupValues[1] to it.groupValues[2] }
            ?: Regex("^(?:включи|поставь|запусти|найди|вруби|открой) (?:на|в) $svcs (.+)$").find(t)?.let { it.groupValues[2] to it.groupValues[1] })?.let { (query, service) ->
            val q = query.removePrefix("песню ").removePrefix("музыку ").removePrefix("видео ")
            val svc = service.let {
                when {
                    it.startsWith("ютуб муз") || it == "youtube music" -> "youtube_music"; it.startsWith("ютуб") || it == "youtube" -> "youtube"
                    it.startsWith("спот") -> "spotify"; it.startsWith("яндекс") -> "yandex_music"; it.startsWith("вк") -> "vk"
                    it.startsWith("рутуб") -> "rutube"; else -> "zvuk"
                }
            }
            return Route("play_on", j("service" to svc, "query" to q))
        }
        Regex("^(?:включи|поставь|запусти|вруби|сыграй) (?:музыку|песню|песни|трек|альбом|плейлист|группу|исполнителя) (.+)$").find(t)?.let { return Route("play_music", j("query" to it.groupValues[1])) }

        // ---- Погода ----
        weather(t)?.let { return it }

        // ---- Курсы ----
        rates(t)?.let { return it }

        // ---- Калькулятор ----
        Regex("^(?:сколько будет|посчитай|вычисли|подсчитай|реши пример|сколько) (.+)$").find(t)?.let { m ->
            val e = m.groupValues[1]
            if (Regex("\\d").containsMatchIn(e) && Regex("[+\\-*/^×÷%]|плюс|минус|умнож|раздел|делить|процент|корень|степен|в квадрате|в кубе|факториал|по модулю|остаток").containsMatchIn(e) &&
                !Regex("доллар|евро|рубл|юан|фунт|биткоин|км|миль|метр|кило|литр|градус").containsMatchIn(e))
                return Route("calculate", j("expression" to e))
        }
        if (Regex("^[\\d\\s+\\-*/^().,%×÷]+$").matches(t) && Regex("\\d\\s*[+\\-*/^×÷%]\\s*\\d").containsMatchIn(t)) return Route("calculate", j("expression" to t))

        // ---- Перевод единиц ----
        Regex("^(?:переведи|сколько будет|сколько) (\\d+(?:[.,]\\d+)?) (\\S+(?: в час)?) (?:в|во) (\\S+(?: в час)?)$").find(t)?.let { m ->
            if (Regex("доллар|евро|рубл|юан|фунт|тенге|лир|биткоин").containsMatchIn(m.value)) return@let
            return Route("convert_units", j("value" to m.groupValues[1].replace(',', '.').toDouble(), "from" to m.groupValues[2], "to" to m.groupValues[3]))
        }

        // ---- Новости, уведомления, сводка, память ----
        if (Regex("^(?:новости|что нового|главные новости|последние новости|свежие новости|расскажи новости|что в мире|какие новости|что происходит в мире|новости дня)$").matches(t)) return Route("news", network = true)
        Regex("^(?:новости|последние новости|расскажи новости|что нового) (?:про|о|об|по) (.+)$").find(t)?.let { return Route("news", j("topic" to it.groupValues[1]), network = true) }
        Regex("^(?:новости|последние новости) (хабр${W}*|риа|тасс|би-?би-?си|bbc|ленты|лента)$").find(t)?.let {
            val s = it.groupValues[1]
            val src = when { s.startsWith("хабр") -> "habr"; s == "риа" -> "ria"; s == "тасс" -> "tass"; s.startsWith("лент") -> "lenta"; else -> "bbc" }
            return Route("news", j("source" to src), network = true)
        }
        if (Regex("^(?:(?:прочитай|покажи|какие|есть|есть ли|новые|мои|озвучь|что в) )?(?:уведомлени${W}*|оповещени${W}*)(?: есть)?$|^(?:что пришло|кто (?:мне )?писал|кто мне написал|есть новые сообщения|что мне написали|прочитай сообщения|какие сообщения пришли)$").matches(t))
            return Route("read_notifications")
        if (Regex("^(?:доброе утро|утро|сводка|сводка дня|утренняя сводка|что у меня сегодня|какие планы на сегодня|что сегодня|план на день|брифинг)$").matches(t)) return Route("daily_briefing", network = true)
        if (Regex("^(?:что ты (?:обо мне )?помнишь|что ты знаешь обо мне|покажи (?:память|что запомнила)|что ты запомнила)$").matches(t)) return Route("list_memory")
        Regex("^запомни(?: что| то что)? (.+)$").find(t)?.let { m ->
            val fact = raw.trim().replace(Regex("(?i)^.*?запомни[,:]?\\s*(?:что\\s+|то,? что\\s+)?"), "").trim().trimEnd('.')
            if (fact.isBlank()) return null
            return if (Regex("^запомни что ").containsMatchIn(t) || Regex("${B}(?:я|мой|моя|мое|мои|меня|мне|у меня)${B}").containsMatchIn(m.groupValues[1]))
                Route("remember", j("fact" to fact.replaceFirstChar { it.uppercase() }))
            else Route("add_note", j("text" to fact.replaceFirstChar { it.uppercase() }))
        }
        Regex("^(?:запиши|создай заметку|сделай заметку|добавь заметку|заметка|запиши в заметки|добавь в заметки|закинь в заметки|новая заметка)(?: что)? (.+)$").find(t)?.let {
            val text = raw.trim().replace(Regex("(?i)^.*?(?:запиши в заметки|добавь в заметки|закинь в заметки|создай заметку|сделай заметку|добавь заметку|новая заметка|заметка|запиши)[,:]?\\s*(?:что\\s+)?"), "").trim()
            return Route("add_note", j("text" to text.ifBlank { it.groupValues[1] }.replaceFirstChar { c -> c.uppercase() }))
        }
        if (Regex("^(?:покажи |мои |открой |прочитай )?заметки$").matches(t)) return Route("list_notes")
        if (Regex("^(?:какие |мои |покажи )?напоминания$").matches(t)) return Route("list_reminders")

        // ---- Системные действия ----
        if (Regex("^(?:назад|вернись назад|кнопка назад|шаг назад)$").matches(t)) return Route("global_action", j("action" to "back"))
        if (Regex("^(?:домой|на главный экран|на рабочий стол|главный экран|выйди на главный экран|сверни все)$").matches(t)) return Route("global_action", j("action" to "home"))
        if (Regex("^(?:сделай )?(?:скриншот|скрин|снимок экрана|скриншот экрана|заскринь(?: экран)?)$").matches(t)) return Route("global_action", j("action" to "screenshot"))
        if (Regex("^(?:недавние|последние|открытые) приложения$").matches(t)) return Route("global_action", j("action" to "recents"))
        if (Regex("^(?:заблокируй|заблокировать) (?:телефон|экран)$|^выключи экран$").matches(t)) return Route("global_action", j("action" to "lock_screen"))
        if (Regex("^(?:открой |опусти )?шторку$").matches(t)) return Route("global_action", j("action" to "notifications"))
        if (Regex("^(?:открой )?быстрые настройки$").matches(t)) return Route("global_action", j("action" to "quick_settings"))
        if (Regex("^(?:отсканируй|сканируй|считай|прочитай|распознай|что в|открой)? ?qr(?: код| коды)?(?: на экране)?$").matches(t)) return Route("scan_qr")

        // ---- Навигация ----
        Regex("^(?:маршрут|проложи маршрут|построй маршрут|как доехать|как добраться|как проехать|навигация|веди меня|поехали|едем|навигатор) (?:до |к |ко |в |во |на )?(.+)$").find(t)?.let { return Route("navigate", j("destination" to it.groupValues[1])) }
        Regex("^как дойти (?:до |к |в |на )?(.+)$").find(t)?.let { return Route("navigate", j("destination" to it.groupValues[1], "mode" to "walk")) }
        Regex("^(?:покажи на карте|найди на карте|где находится) (.+)$").find(t)?.let { return Route("navigate", j("destination" to it.groupValues[1], "mode" to "show")) }

        // ---- Настройки ----
        Regex("^(?:открой |зайди в |покажи )?настройки(?: (.+))?$").find(t)?.let { m ->
            val p = m.groupValues[1]
            val page = when {
                p.isEmpty() || p == "телефона" -> "main"
                p.contains("wifi") || p.contains("интернет") -> "wifi"; p.contains("блютуз") -> "bluetooth"
                p.contains("экран") || p.contains("дисплей") -> "display"; p.contains("звук") -> "sound"
                p.contains("батаре") || p.contains("аккумулятор") -> "battery"; p.contains("приложени") -> "apps"
                p.contains("уведомлени") -> "notifications"; p.contains("памят") || p.contains("хранилищ") -> "storage"
                p.contains("о телефоне") -> "about"; p.contains("язык") -> "language"; p.contains("безопасност") -> "security"
                p.contains("дат") || p.contains("врем") -> "date"; p.contains("геолокац") || p.contains("местоположени") -> "location"
                p.contains("специальн") -> "accessibility"; p.contains("nfc") -> "nfc"; p.contains("ассистент") || p.contains("помощник") -> "assistant"
                else -> return null
            }
            return Route("open_settings", j("page" to page))
        }

        // ---- Звонки ----
        Regex("^(?:позвони|набери|звони|позвонить|набрать|вызов|звонок|сделай звонок|соедини с)(?: мне)?(?: на номер)? (.+)$").find(t)?.let { m ->
            val who = m.groupValues[1].removePrefix("по номеру ").removePrefix("на ").trim()
            if (Regex("такси|скор|полиц|пожарн|112|в службу").containsMatchIn(who)) return null
            if (who.split(' ').size > 3) return null
            val digits = who.replace(Regex("[\\s()-]"), "")
            if (Regex("^\\+?\\d{3,15}$").matches(digits)) return Route("call_phone", j("target" to digits))
            val raw2 = raw.trim().split(Regex("\\s+")).takeLast(who.split(' ').size).joinToString(" ").trim(' ', '.', '!', '?', ',')
            val forms = (phraseNominatives(raw2.ifBlank { who }) + phraseNominatives(who)).distinct()
            return Route("call_phone", j("target" to forms.first()), alts = forms.drop(1).map { j("target" to it) })
        }

        // ---- Приложения ----
        Regex("^(?:открой|запусти|зайди в|включи приложение|открыть|запустить|открой приложение|запусти приложение) (?:приложение )?(.+)$").find(t)?.let { m ->
            val name = m.groupValues[1].trim()
            if (Regex("файл|папк|сайт|ссылк|страниц|чат|переписк|диалог|сообщени|письм|почту от|фото |фотографи|видео |документ|\\.|/|http|заметк|напоминани|будильник|таймер|уведомлени").containsMatchIn(name)) return null
            if (name.split(' ').size > 3) return null
            if (name == "камеру" || name == "камера") return Route("open_app", j("name" to "Камера"))
            val forms = phraseNominatives(name)
            return Route("open_app", j("name" to name), alts = forms.filter { it != name }.map { j("name" to it) })
        }
        return null
    }

    /** «7 вечера» → 19, «12 ночи» → 0. */
    private fun pm(h: Int, t: String): Int = when {
        Regex("${B}(?:вечера|дня)${B}").containsMatchIn(t) && h in 1..11 -> h + 12
        Regex("${B}ночи${B}").containsMatchIn(t) && h == 12 -> 0
        else -> h
    } % 24

    /** Длительность в секундах: «1 час 20 минут», «90 секунд», «5 мин». */
    fun duration(t: String): Int? {
        var total = 0; var any = false
        for (m in Regex("(\\d+)\\s*(час${W}*|ч${B}|минут${W}*|мин${B}|секунд${W}*|сек${B})").findAll(t)) {
            val n = m.groupValues[1].toInt(); val u = m.groupValues[2]
            total += when { u.startsWith("ч") -> n * 3600; u.startsWith("м") -> n * 60; else -> n }
            any = true
        }
        if (!any) {
            Regex("${B}на (час|минуту|секунду)${B}").find(t)?.let { return when (it.groupValues[1]) { "час" -> 3600; "минуту" -> 60; else -> 1 } }
            Regex("${B}(\\d+)${B}").find(t)?.let { if (Regex("таймер").containsMatchIn(t)) return it.groupValues[1].toInt() * 60 }
        }
        return if (any) total else null
    }

    private val settings = listOf(
        Regex("${B}wifi${B}") to "wifi", Regex("${B}блютуз${W}*") to "bluetooth", Regex("режим${W}* (?:полета|самолета)|авиарежим|режим в самолете|авиа режим") to "airplane",
        Regex("не беспокоить|режим тишины") to "dnd", Regex("точк${W}* доступа|хот ?спот|режим модема|раздачу (?:интернета|wifi)|раздай интернет") to "hotspot",
        Regex("мобильн${W}* (?:интернет|данные|связь)|передачу данных") to "mobile_data", Regex("геолокаци${W}*|местоположени${W}*|${B}gps${B}|джипиэс|геопозици${W}*") to "location",
        Regex("${B}nfc${B}|энэфси|бесконтакт${W}*") to "nfc", Regex("энергосбережени${W}*|экономи${W}* (?:заряда|батареи|энергии)|режим экономии") to "battery_saver",
        Regex("темн${W}* (?:тем${W}*|режим)|ночн${W}* (?:режим|тем${W}*)|dark mode") to "dark_theme", Regex("автоповорот|поворот экрана|автоматический поворот") to "auto_rotate"
    )

    private fun toggle(t: String): Route? {
        if (t.split(' ').size > 6) return null
        if (t.contains("настройк")) return null
        val s = settings.firstOrNull { it.first.containsMatchIn(t) }?.second ?: return null
        val off = Regex("${B}(?:выключ${W}*|отключ${W}*|выруби|деактивируй|убери|отмени|останови|запрети)${B}").containsMatchIn(t)
        val on = Regex("${B}(?:включ${W}*|вруби|активируй|подключ${W}*|разреши|раздай|раздачу)${B}").containsMatchIn(t)
        if (!on && !off) {
            // «не беспокоить» без глагола — включить; «wifi» — переключить
            return if (s == "dnd" && Regex("^(?:режим )?не беспокоить$").matches(t)) Route("toggle_setting", j("setting" to "dnd", "on" to true)) else Route("toggle_setting", j("setting" to s))
        }
        return Route("toggle_setting", j("setting" to s, "on" to !off))
    }

    private fun weather(t: String): Route? {
        val isWeather = Regex("${B}(?:погод${W}*|прогноз${W}*)${B}").containsMatchIn(t) ||
            Regex("^(?:сколько (?:сейчас )?градусов|какая (?:сейчас )?температура|холодно ли|тепло ли|жарко ли|будет ли дождь|пойдет ли дождь|нужен ли зонт|брать ли зонт|что надеть)").containsMatchIn(t)
        if (!isWeather || t.split(' ').size > 9) return null
        if (Regex("курс|доллар|евро|биткоин|матч|игр|акци|выбор").containsMatchIn(t)) return null
        val day = when {
            Regex("${B}послезавтра${B}").containsMatchIn(t) -> 2
            Regex("${B}завтра${B}").containsMatchIn(t) -> 1
            else -> 0
        }
        val days = when {
            Regex("на неделю|на 7 дней|на всю неделю").containsMatchIn(t) -> 7
            Regex("на выходные").containsMatchIn(t) -> 3
            Regex("на (\\d+) дн").containsMatchIn(t) -> Regex("на (\\d+) дн").find(t)!!.groupValues[1].toInt().coerceIn(1, 14)
            else -> 1
        }
        val city = Regex("${B}(?:в|во) ((?!час|выходн|неделю|минут)[\\p{L}-]+(?: [\\p{L}-]+)?)(?= (?:сегодня|завтра|послезавтра|на |сейчас)|$)").find(t)?.groupValues?.get(1)
            ?.takeIf { it !in setOf("городе", "моем городе", "нашем городе", "мире", "доме", "квартире") }
        val a = j("day" to day, "days" to days)
        if (city != null) a.put("city", city)
        return Route("weather", a, network = true)
    }

    private val currencies = mapOf(
        "доллар" to "USD", "бакс" to "USD", "евро" to "EUR", "юан" to "CNY", "фунт" to "GBP", "тенге" to "KZT", "лир" to "TRY", "иен" to "JPY",
        "франк" to "CHF", "гривн" to "UAH", "рубл" to "RUB", "дирхам" to "AED", "бат" to "THB", "драм" to "AMD", "лари" to "GEL", "сум" to "UZS", "белорусск" to "BYN"
    )
    private val coins = mapOf("биткоин" to "bitcoin", "биток" to "bitcoin", "bitcoin" to "bitcoin", "btc" to "bitcoin", "эфир" to "ethereum", "эфириум" to "ethereum",
        "ethereum" to "ethereum", "тон" to "ton", "toncoin" to "ton", "тонкоин" to "ton", "usdt" to "usdt", "тезер" to "usdt", "солана" to "solana", "догикоин" to "dogecoin")

    private val shortCur = mapOf("сум" to setOf("сум", "сума", "сумов"), "бат" to setOf("бат", "бата", "батов"), "лари" to setOf("лари"), "драм" to setOf("драм", "драма", "драмов"), "лир" to setOf("лира", "лиры", "лир", "лиру"))

    private fun cur(w: String): String? {
        if (w.startsWith("белорусск")) return "BYN"
        val e = currencies.entries.firstOrNull { w.startsWith(it.key) } ?: return null
        shortCur[e.key]?.let { if (w !in it) return null }
        return if (w.length - e.key.length <= 4) e.value else null
    }

    private fun rates(t: String): Route? {
        // «100 долларов в рублях», «сколько будет 50 евро в долларах»
        Regex("^(?:сколько будет |переведи |сколько |сколько стоят? )?(\\d+(?:[.,]\\d+)?) (\\p{L}+) (?:в|во) (\\p{L}+)$").find(t)?.let { m ->
            val amount = m.groupValues[1].replace(',', '.').toDouble()
            coins.entries.firstOrNull { m.groupValues[2].startsWith(it.key) }?.let { return Route("crypto_price", j("coin" to it.value, "amount" to amount), network = true) }
            val f = cur(m.groupValues[2]) ?: return null; val to = cur(m.groupValues[3]) ?: return null
            return Route("exchange_rate", j("from" to f, "to" to to, "amount" to amount), network = true)
        }
        val m = Regex("^(?:какой |какой сейчас |а |текущий )?(?:курс|почем|почём|сколько стоит|сколько сейчас стоит|по чем|цена) (?:сейчас )?(?:1 )?(\\p{L}+)(?: (?:к|в) (\\p{L}+))?(?: сегодня| сейчас| на сегодня)?$").find(t)
            ?: Regex("^(?:курс )?(\\p{L}+) (?:сегодня|сейчас|по курсу)$").find(t)?.takeIf { cur(it.groupValues[1]) != null || coins.keys.any { k -> it.groupValues[1].startsWith(k) } }
            ?: return null
        val w = m.groupValues[1]
        coins.entries.firstOrNull { w.startsWith(it.key) && (it.key.length > 3 || w == it.key) }?.let { return Route("crypto_price", j("coin" to it.value), network = true) }
        val f = cur(w) ?: if (w == "валют" || w == "валюты") "USD" else return null
        val to = m.groupValues.getOrNull(2)?.takeIf { it.isNotEmpty() }?.let { cur(it) } ?: "RUB"
        return Route("exchange_rate", j("from" to f, "to" to to), network = true)
    }

    // ---------- Подтверждение ----------
    private val failure = Regex("(?i)не найден|не удалось|не получилось|нет доступа|нужн[аоы]? |ошибк|выключена|не могу|не знаю|нет приложени|не нашла|разрешени|включите|не поддерж")

    fun failed(result: String) = failure.containsMatchIn(result)

    /** Короткая фраза для озвучки после выполнения (частые — из кэша, звучат мгновенно). */
    fun confirm(r: Route, result: String): String {
        if (r.direct != null) return r.direct
        if (failed(result) || r.tool == null) return result
        val a = r.args
        return when (r.tool) {
            "flashlight" -> when { !a.has("on") -> result; a.optBoolean("on") -> "Включила фонарик."; else -> "Выключила фонарик." }
            "set_volume" -> when (a.optString("direction")) {
                "up" -> "Сделала громче."; "down" -> "Сделала тише."; "mute" -> "Звук выключен."; "unmute" -> "Звук включён."
                else -> "Громкость ${a.optInt("percent")}%."
            }
            "media_control" -> when (a.optString("action")) {
                "pause" -> "Пауза."; "play" -> "Продолжаю."; "next" -> "Следующий трек."; "previous" -> "Предыдущий трек."; else -> "Готово."
            }
            "open_app", "open_settings", "navigate", "play_music", "play_on", "show_alarms" -> "Открываю."
            "call_phone" -> "Звоню."
            "confirm_send" -> result
            "global_action" -> if (a.optString("action") == "screenshot") "Сделала скриншот." else "Готово."
            "add_note" -> "Записала."
            "remember" -> "Запомнила."
            "set_brightness", "set_ringer", "toggle_setting", "cancel_timer", "cancel_alarm" -> result.lineSequence().first().let { if (it.length <= 80) it else "Готово." }
            "set_timer", "set_alarm", "set_reminder" -> result.lineSequence().first().substringBefore(" (id").trim().let { if (it.endsWith(".")) it else "$it." }
            else -> if (r.firstLine) result.lineSequence().first() else result
        }
    }

    // ---------- Сложность задачи (выбор модели) ----------
    enum class Tier { FAST, SMART, CODE }

    private val codeRx = Regex(
        "(?:${B}код${W}*|скрипт${W}*|программ${W}*|функци[юяи]|класс${W}* на|${B}python${B}|питон${W}*|пайтон${W}*|kotlin|котлин${W}*|${B}java${B}|джав${W}*|javascript|${B}js${B}|typescript|html|css|${B}sql${B}|" +
            "c\\+\\+|${B}c#|golang|${B}rust${B}|bash|баш-?скрипт|${B}игр[уаые]${B}|игрушк${W}*|сайт${W}*|лендинг|телеграм-?бот${W}*|${B}бот[аы]?${B}|парсер${W}*|алгоритм${W}*|рефактор${W}*|отлад${W}*|баг${W}*|" +
            "исправь ошибк${W}*|compile|скомпил${W}*|regex|регуляр${W}*|api${B}|json|\\.(?:py|kt|js|ts|html|css|java|cpp|c|sh|sql|go|rs)${B})"
    )
    private val createRx = Regex("${B}(?:напиши|создай|сделай|сгенерируй|разработай|исправь|доработай|переделай|оптимизируй|допиши|реализуй|запрограммируй)${B}")
    private val complexRx = Regex(
        "(?:реши (?:задач|уравнени|систем|пример)${W}*|докажи|интеграл${W}*|производн${W}*|матриц${W}*|вероятност${W}*|уравнени${W}*|" +
            "составь (?:подробн${W}* )?план|распиши (?:план|по шагам|подробно)|пошагов${W}*|бизнес-?план${W}*|стратеги${W}*|проанализируй|анализ${W}* |сравни подробно|" +
            "напиши (?:эссе|статью|доклад|реферат|сочинение|курсов${W}*|диплом${W}*|резюме|договор)|подробно объясни|глубок${W}* анализ)"
    )

    fun tier(text: String): Tier {
        val t = text.lowercase(ru).replace('ё', 'е')
        if (codeRx.containsMatchIn(t) && (createRx.containsMatchIn(t) || Regex("${B}(?:в файл|файл${W}*|программу|скрипт)${B}").containsMatchIn(t))) {
            // «напиши Максу в WhatsApp» — не код
            if (Regex("whatsapp|вотсап|ватсап|телеграм|смс|sms|сообщени").containsMatchIn(t) && !Regex("${B}бот").containsMatchIn(t)) return Tier.FAST
            return Tier.CODE
        }
        if (complexRx.containsMatchIn(t) || t.length > 400) return Tier.SMART
        return Tier.FAST
    }
}
