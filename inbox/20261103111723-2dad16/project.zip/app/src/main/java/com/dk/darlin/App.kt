package com.dk.darlin

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.dk.darlin.sys.ReminderScheduler

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        com.dk.darlin.core.CrashLog.install(this)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        ReminderScheduler.ensureChannel(this)
        try { com.dk.darlin.sys.QuickAccess.update(this) } catch (_: Exception) {}
        com.dk.darlin.core.Prefs.migrate(this)
        // Частые фразы озвучиваются из кэша без сети (генерируются один раз в фоне)
        com.dk.darlin.tts.TtsCache.warmAsync(this)
    }
}
