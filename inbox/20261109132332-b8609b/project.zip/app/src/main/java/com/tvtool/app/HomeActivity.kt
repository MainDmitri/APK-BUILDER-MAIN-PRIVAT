package com.tvtool.app

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : Activity() {
    private lateinit var grid: GridView
    private lateinit var infoView: TextView
    private var apps: List<ResolveInfo> = emptyList()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F111A"))
        }

        val topBar = LinearLayout(this)
        topBar.addView(TextClock(this).apply {
            format12Hour = "HH:mm · EEE d MMM"
            format24Hour = "HH:mm · EEE d MMM"
            textSize = 22f
            setTextColor(Color.WHITE)
            setOnClickListener { prefs.edit().remove("hidden").apply(); reloadApps() }
        }, LinearLayout.LayoutParams(0, -2, 1f))

        infoView = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 13f }
        topBar.addView(infoView)
        root.addView(topBar)

        grid = GridView(this).apply {
            numColumns = 5
            verticalSpacing = 20
            horizontalSpacing = 20
            setPadding(16, 24, 16, 16)
            selector = ColorDrawable(0x44FFFFFF)
            isFocusable = true
            setOnItemClickListener { _, _, position, _ -> launchApp(position) }
            setOnItemLongClickListener { _, _, position, _ -> showMenu(position); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, -1))

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left + 24, bars.top + 16, bars.right + 24, bars.bottom + 16)
            insets
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        reloadApps()
    }

    @Deprecated("Launcher")
    override fun onBackPressed() { /* ignore */ }

    private fun launchApp(position: Int) {
        if (position >= apps.size) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
            return
        }
        packageManager.getLaunchIntentForPackage(apps[position].activityInfo.packageName)?.let { startActivity(it) }
    }

    private fun showMenu(position: Int) {
        if (position >= apps.size) return
        val pkg = apps[position].activityInfo.packageName
        AlertDialog.Builder(this).setItems(arrayOf("Закрепить / открепить", "Скрыть", "Удалить", "О приложении")) { _, which ->
            when (which) {
                0 -> toggleSet("pinned", pkg)
                1 -> toggleSet("hidden", pkg)
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
                3 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
            }
        }.show()
    }

    private fun toggleSet(key: String, pkg: String) {
        val set = prefs.getStringSet(key, emptySet())!!.toMutableSet()
        if (!set.add(pkg)) set.remove(pkg)
        prefs.edit().putStringSet(key, set).apply()
        reloadApps()
    }

    private fun reloadApps() {
        val pm = packageManager
        val pinned = prefs.getStringSet("pinned", emptySet())!!
        val hidden = prefs.getStringSet("hidden", emptySet())!!

        apps = (pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0) +
                pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0))
            .distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName && it.activityInfo.packageName !in hidden }
            .sortedWith(compareBy({ it.activityInfo.packageName !in pinned }, { it.loadLabel(pm).toString().lowercase() }))

        val memInfo = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(memInfo)
        infoView.text = "RAM ${memInfo.availMem / 1048576} МБ · ${apps.size} приложений"

        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size + 1
            override fun getItem(position: Int) = position
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val layout = LinearLayout(this@HomeActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(8, 12, 8, 12)
                    setBackgroundColor(Color.parseColor("#1C1F2E"))
                }
                val icon = ImageView(this@HomeActivity).apply {
                    layoutParams = LinearLayout.LayoutParams(72, 72)
                }
                val label = TextView(this@HomeActivity).apply {
                    setTextColor(Color.WHITE)
                    textSize = 12f
                    gravity = Gravity.CENTER
                    maxLines = 2
                }
                layout.addView(icon)
                layout.addView(label)

                if (position < apps.size) {
                    val app = apps[position]
                    val isPinned = app.activityInfo.packageName in pinned
                    label.text = (if (isPinned) "★ " else "") + app.loadLabel(pm)
                    icon.setImageDrawable(app.loadIcon(pm))
                } else {
                    label.text = "⚙ Настройки"
                    icon.setImageResource(android.R.drawable.ic_menu_preferences)
                }
                return layout
            }
        }
    }
}
