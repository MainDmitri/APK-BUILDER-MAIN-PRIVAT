package com.tvtool.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.text.InputType
import android.widget.*
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var ipInput: EditText
    private lateinit var urlInput: EditText
    private lateinit var logView: TextView
    private lateinit var container: LinearLayout
    private lateinit var adb: Adb
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("tvtool", MODE_PRIVATE) }
    private val launcherComponent = "com.tvtool.app/.HomeActivity"
    private val adguardDns = "dns.adguard-dns.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adb = Adb(this)

        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16) }
        ipInput = EditText(this).apply {
            hint = "IP телевизора (порт 5555)"
            setText(prefs.getString("ip", ""))
            inputType = InputType.TYPE_CLASS_PHONE
        }
        urlInput = EditText(this).apply {
            hint = "URL для скачивания APK"
            setText("https://github.com/yuliskov/SmartTube/releases/latest/download/smarttube_stable.apk")
        }
        logView = TextView(this).apply { textSize = 11f; setTextIsSelectable(true); setPadding(0, 16, 0, 0) }

        container.addView(ipInput)
        container.addView(urlInput)

        addSection("1. Подключение")
        addButton("🔍 Сканировать сеть (порт 5555)") {
            runTask("Сканирование") {
                log("Сканирую подсеть...")
                val found = Adb.scan { p -> if (p % 20 == 0) log("Прогресс: $p%") }
                if (found.isEmpty()) log("Устройства не найдены") else {
                    log("Найдено: ${found.joinToString()}")
                    runOnUiThread { ipInput.setText(found.first()) }
                }
            }
        }
        addButton("Подключиться и показать инфо") { connect { showInfo() } }
        addButton("Отключиться") { adb.close(); log("Отключено") }

        addSection("2. Установка приложений")
        addButton("⬇ Скачать и установить по URL") { connect { downloadAndInstall(urlInput.text.toString(), true) } }
        addButton("⬇ Только скачать на телефон") { runTask("Скачивание") { downloadAndInstall(urlInput.text.toString(), false) } }
        addButton("GitHub релиз (owner/repo)") {
            askInput("owner/repo", prefs.getString("repo", "yuliskov/SmartTube")!!) { repo ->
                prefs.edit().putString("repo", repo).apply()
                loadGithubApks(repo)
            }
        }
        addButton("Установить APK с телефона") { pickFile(1) }
        addButton("Установить этот лаунчер на ТВ") {
            connect {
                adb.connect().install(File(applicationInfo.sourceDir))
                log(adb.shell("cmd package set-home-activity $launcherComponent"))
                adb.shell("input keyevent 3")
                log("✔ Лаунчер установлен и активирован")
            }
        }

        addSection("3. Управление приложениями")
        addButton("Заморозить приложения...") { pickPackages("Заморозить", "pm list packages -e") { pkgs ->
            runTask("Заморозка") {
                val frozen = getFrozenSet()
                pkgs.forEach { pkg ->
                    val res = adb.shell("pm disable-user --user 0 $pkg")
                    log("$pkg: $res")
                    frozen.add(pkg)
                }
                saveFrozen(frozen)
            }
        } }
        addButton("Вернуть все замороженные") {
            connect {
                val frozen = getFrozenSet()
                frozen.toList().forEach { pkg ->
                    val res = adb.shell("pm enable $pkg")
                    log("$pkg: $res")
                    if (res.contains("enabled", true)) frozen.remove(pkg)
                }
                saveFrozen(frozen)
                log(if (frozen.isEmpty()) "✔ Все включены" else "Осталось: ${frozen.size}")
            }
        }
        addButton("Запустить приложения...") { pickPackages("Запуск", "pm list packages -3") { pkgs ->
            runTask("") { pkgs.forEach { adb.shell("monkey -p $it -c android.intent.category.LAUNCHER 1") } }
        } }
        addButton("Удалить приложения...") { pickPackages("Удалить", "pm list packages -3") { pkgs ->
            runTask("Удаление") { pkgs.forEach { log("$it: ${adb.shell("pm uninstall --user 0 $it")}") } }
        } }

        addSection("4. Система и мониторинг")
        addButton("📸 Сделать снимок пакетов") { connect { prefs.edit().putString("snapshot", takeSnapshot()).apply(); log("✔ Снимок сохранён") } }
        addButton("🔎 Сравнить с снимком") { connect { compareSnapshot() } }
        addButton("📊 Монитор (5 сек)") { connect { repeat(3) { showMonitor(); Thread.sleep(1500) } } }
        addButton("AdGuard DNS (с откатом)") { connect { enableDns() } }
        addButton("Вернуть DNS") { connect { disableDns() } }
        addButton("🔁 Перезагрузка ТВ") { connect { adb.shell("reboot") } }
        addButton("📤 Отчёт") { connect { shareText(generateReport()) } }

        addSection("5. Пульт и файлы")
        val dpad = LinearLayout(this)
        listOf("◀" to 21, "▲" to 19, "▼" to 20, "▶" to 22, "OK" to 23, "⌂" to 3, "↩" to 4).forEach { (label, key) ->
            dpad.addView(Button(this).apply {
                text = label
                setOnClickListener { runTask("") { adb.shell("input keyevent $key") } }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        container.addView(dpad)
        addButton("⌨ Ввести текст на ТВ") { askInput("Текст", "") { text ->
            runTask("") { adb.shell("input text '${text.replace(" ", "%s").replace("'", "")}'") }
        } }
        addButton("📸 Скриншот ТВ") { connect { takeScreenshot() } }
        addButton("📜 Logcat") { connect { shareText(adb.shell("logcat -d -t 300").takeLast(50000)) } }

        container.addView(logView)
        val scroll = ScrollView(this).apply { addView(container) }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left + 12, bars.top + 12, bars.right + 12, bars.bottom + 12)
            insets
        }
        setContentView(scroll)
    }

    private fun log(msg: String) = runOnUiThread { logView.append("• $msg\n") }

    private fun runTask(label: String, block: () -> Unit) = io.execute {
        try {
            if (label.isNotEmpty()) log("▶ $label")
            block()
        } catch (e: Throwable) {
            log("✖ ${e.message ?: e.javaClass.simpleName}")
            adb.close()
        }
    }

    private fun connect(block: () -> Unit) {
        val host = ipInput.text.toString().trim()
        if (host.isBlank()) { log("Укажите IP"); return }
        prefs.edit().putString("ip", host).apply()
        runTask("") {
            if (adb.host != host) adb.close()
            adb.host = host
            adb.connect()
            block()
        }
    }

    private fun addButton(text: String, action: () -> Unit) {
        container.addView(Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { action() } })
    }

    private fun addSection(title: String) {
        container.addView(TextView(this).apply { text = title; textSize = 16f; setPadding(0, 20, 0, 8) })
    }

    private fun askInput(title: String, default: String, onOk: (String) -> Unit) {
        val edit = EditText(this).apply { setText(default) }
        AlertDialog.Builder(this).setTitle(title).setView(edit)
            .setPositiveButton("OK") { _, _ -> onOk(edit.text.toString().trim()) }
            .setNegativeButton("Отмена", null).show()
    }

    private fun shareText(text: String) = runOnUiThread {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Поделиться"))
    }

    private fun pickPackages(title: String, cmd: String, onSelected: (List<String>) -> Unit) = connect {
        val packages = adb.shell(cmd).lines().map { it.removePrefix("package:").trim() }.filter { it.isNotBlank() }.sorted()
        if (packages.isEmpty()) { log("Список пуст"); return@connect }
        runOnUiThread {
            val selected = BooleanArray(packages.size)
            AlertDialog.Builder(this).setTitle(title)
                .setMultiChoiceItems(packages.toTypedArray(), selected) { _, i, checked -> selected[i] = checked }
                .setPositiveButton("OK") { _, _ -> onSelected(packages.filterIndexed { i, _ -> selected[i] }) }
                .show()
        }
    }

    private fun getFrozenSet() = prefs.getStringSet("frozen", emptySet())!!.toMutableSet()
    private fun saveFrozen(set: Set<String>) = prefs.edit().putStringSet("frozen", set).apply()

    private fun showInfo() {
        log("Модель: ${adb.shell("getprop ro.product.model")}")
        log("Android: ${adb.shell("getprop ro.build.version.release")}")
        log("Экран: ${adb.shell("wm size")}")
        log("Диск: ${adb.shell("df -h /data | tail -1")}")
    }

    private fun downloadAndInstall(url: String, install: Boolean) {
        if (url.isBlank()) { log("URL пустой"); return }
        val name = url.substringAfterLast('/').substringBefore('?').ifBlank { "app.apk" }
        val file = File(getExternalFilesDir("apk"), name)
        log("Скачиваю $name...")
        Adb.download(url, file) { log("  $it%") }
        log("SHA-256: ${Adb.sha256(file)}")
        log("Сохранено: ${file.absolutePath}")
        if (install) {
            adb.connect().install(file)
            log("✔ Установлено")
        }
    }

    private fun loadGithubApks(repo: String) = runTask("GitHub $repo") {
        val apks = Adb.releaseApks(repo)
        if (apks.isEmpty()) { log("APK в релизе не найдены"); return@runTask }
        runOnUiThread {
            AlertDialog.Builder(this).setTitle("Выберите APK")
                .setItems(apks.map { it.first }.toTypedArray()) { _, i ->
                    urlInput.setText(apks[i].second)
                    connect { downloadAndInstall(apks[i].second, true) }
                }.show()
        }
    }

    private fun takeSnapshot(): String {
        val disabled = adb.shell("pm list packages -d").lines().toSet()
        return adb.shell("pm list packages").lines()
            .filter { it.startsWith("package:") }
            .joinToString("\n") { pkg ->
                val name = pkg.removePrefix("package:")
                "$name|${if (pkg in disabled) "d" else "e"}"
            }
    }

    private fun compareSnapshot() {
        val old = prefs.getString("snapshot", null) ?: return log("Сначала сделайте снимок")
        fun parse(s: String) = s.lines().filter { "|" in it }.associate { it.substringBefore('|') to it.substringAfter('|') }
        val oldMap = parse(old)
        val newMap = parse(takeSnapshot())
        (newMap.keys - oldMap.keys).forEach { log("+ появилось: $it") }
        (oldMap.keys - newMap.keys).forEach { log("- удалено: $it") }
        newMap.filter { (k, v) -> oldMap[k] != null && oldMap[k] != v }.forEach { (k, v) ->
            log("⟳ $k: ${if (v == "d") "выключено" else "включено"}")
        }
        log("Сравнение завершено")
    }

    private fun showMonitor() {
        val mem = adb.shell("grep -E 'MemTotal|MemAvailable' /proc/meminfo").replace(Regex("\\s+"), " ")
        val temp = adb.shell("cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null").toIntOrNull()?.div(1000)
        val load = adb.shell("cat /proc/loadavg").substringBefore(" ")
        log("$mem | load $load | ${temp ?: "?"}°C")
    }

    private fun enableDns() {
        if (!prefs.contains("dns_mode")) {
            prefs.edit()
                .putString("dns_mode", adb.shell("settings get global private_dns_mode"))
                .putString("dns_spec", adb.shell("settings get global private_dns_specifier"))
                .apply()
        }
        adb.shell("settings put global private_dns_specifier $adguardDns")
        adb.shell("settings put global private_dns_mode hostname")
        Thread.sleep(2500)
        val ping = adb.shell("ping -c 1 -W 2 example.com")
        if (ping.contains("1 received") || ping.contains("1 packets received")) {
            log("✔ DNS $adguardDns активен")
        } else {
            log("✖ Проблема с интернетом — откат")
            disableDns()
        }
    }

    private fun disableDns() {
        val mode = prefs.getString("dns_mode", "opportunistic") ?: "opportunistic"
        val spec = prefs.getString("dns_spec", "") ?: ""
        if (spec.isNotBlank() && spec != "null") adb.shell("settings put global private_dns_specifier $spec")
        adb.shell("settings put global private_dns_mode $mode")
        prefs.edit().remove("dns_mode").remove("dns_spec").apply()
        log("✔ DNS восстановлен: $mode")
    }

    private fun generateReport() = buildString {
        appendLine("TvTool отчёт")
        appendLine(adb.shell("getprop ro.product.model") + " / Android " + adb.shell("getprop ro.build.version.release"))
        appendLine("Пользовательских приложений: " + adb.shell("pm list packages -3").lines().size)
        appendLine("Заморожено: " + getFrozenSet().joinToString())
        appendLine("DNS: " + adb.shell("settings get global private_dns_mode") + " " + adb.shell("settings get global private_dns_specifier"))
        append(adb.shell("grep MemAvailable /proc/meminfo"))
    }

    private fun takeScreenshot() {
        adb.shell("screencap -p /sdcard/tvtool.png")
        val file = File(getExternalFilesDir("shots"), "screen_${System.currentTimeMillis()}.png")
        adb.connect().pull(file, "/sdcard/tvtool.png")
        runOnUiThread {
            AlertDialog.Builder(this).setView(ImageView(this).apply {
                setImageBitmap(BitmapFactory.decodeFile(file.path))
            }).setPositiveButton("OK", null).show()
        }
        log("Скриншот: ${file.name}")
    }

    private fun pickFile(requestCode: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), requestCode)
    }

    @Deprecated("Use Activity Result API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "file"
        connect {
            val dest = File(cacheDir, if (requestCode == 1) "picked.apk" else name)
            contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use { input.copyTo(it) } }
            if (requestCode == 1) {
                adb.connect().install(dest)
                log("✔ Установлено с телефона")
            } else {
                adb.connect().push(dest, "/sdcard/Download/$name")
                log("✔ Отправлено на ТВ: /sdcard/Download/$name")
            }
        }
    }
}
