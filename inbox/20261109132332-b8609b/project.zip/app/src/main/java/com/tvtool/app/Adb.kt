package com.tvtool.app

import android.content.Context
import dadb.AdbKeyPair
import dadb.Dadb
import org.json.JSONObject
import java.io.File
import java.net.*
import java.security.MessageDigest
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class Adb(private val ctx: Context) {
    private var dadb: Dadb? = null
    var host: String = ""
    var port: Int = 5555

    fun connect(): Dadb = dadb ?: run {
        val keyPriv = File(ctx.filesDir, "adbkey")
        val keyPub = File(ctx.filesDir, "adbkey.pub")
        if (!keyPriv.exists()) {
            AdbKeyPair.generate(keyPriv, keyPub)
        }
        Dadb.create(host, port, AdbKeyPair.read(keyPriv, keyPub)).also { dadb = it }
    }

    fun shell(cmd: String): String = try {
        connect().shell(cmd).allOutput.trim()
    } catch (e: Exception) {
        close()
        throw e
    }

    fun close() {
        try { dadb?.close() } catch (_: Throwable) {}
        dadb = null
    }

    companion object {
        fun scan(onProgress: ((Int) -> Unit)? = null): List<String> {
            val interfaces = NetworkInterface.getNetworkInterfaces().toList()
            val localIp = interfaces.flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
                ?: return emptyList()

            val prefix = localIp.substringBeforeLast('.') + "."
            val executor = Executors.newFixedThreadPool(48)
            val futures = (1..254).map { i ->
                executor.submit(Callable {
                    val host = prefix + i
                    try {
                        Socket().use { sock ->
                            sock.connect(InetSocketAddress(host, 5555), 300)
                        }
                        host
                    } catch (_: Throwable) {
                        null
                    }
                })
            }

            val results = mutableListOf<String>()
            futures.forEachIndexed { idx, fut ->
                try {
                    fut.get(500, TimeUnit.MILLISECONDS)?.let { results.add(it) }
                } catch (_: Throwable) {}
                onProgress?.invoke((idx * 100) / 254)
            }
            executor.shutdownNow()
            return results
        }

        fun download(url: String, dest: File, onProgress: (Int) -> Unit) {
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = true
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.setRequestProperty("User-Agent", "TvTool/2.0")
            conn.connect()

            val total = conn.contentLengthLong
            var downloaded = 0L
            var lastPercent = -1

            conn.inputStream.use { input ->
                dest.outputStream().use { output ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        output.write(buffer, 0, read)
                        downloaded += read
                        if (total > 0) {
                            val percent = ((downloaded * 100) / total).toInt()
                            if (percent != lastPercent && percent % 5 == 0) {
                                lastPercent = percent
                                onProgress(percent)
                            }
                        }
                    }
                }
            }
            onProgress(100)
        }

        fun sha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buffer = ByteArray(8192)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    digest.update(buffer, 0, read)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }

        fun releaseApks(repo: String): List<Pair<String, String>> {
            return try {
                val conn = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                conn.setRequestProperty("User-Agent", "TvTool")
                conn.connectTimeout = 15000
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                val assets = json.getJSONArray("assets")
                (0 until assets.length()).map { assets.getJSONObject(it) }
                    .filter { it.getString("name").endsWith(".apk", true) }
                    .map { it.getString("name") to it.getString("browser_download_url") }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
