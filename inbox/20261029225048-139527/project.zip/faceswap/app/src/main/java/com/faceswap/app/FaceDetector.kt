package com.faceswap.app

import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Log
import ai.onnxruntime.*
import java.nio.FloatBuffer
import kotlin.math.max
import kotlin.math.min

/**
 * Детектор лиц на базе RetinaFace (det_10g.onnx от InsightFace buffalo_l).
 */
class FaceDetector(modelPath: String) : AutoCloseable {

    private val TAG = "FaceDetector"
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    private val INPUT_SIZE = 640

    data class Face(
        val bbox: RectF,
        val landmarks: FloatArray,  // 10 чисел: x0,y0,x1,y1,...
        val score: Float
    )

    init {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            try { addNnapi() } catch (e: Exception) {
                Log.w(TAG, "NNAPI недоступен: ${e.message}")
            }
        }
        session = env.createSession(modelPath, opts)
        Log.d(TAG, "det_10g загружен. Входы: ${session.inputNames}, Выходы: ${session.outputNames}")
    }

    fun detect(bitmap: Bitmap): List<Face> {
        val (resized, scale, padX, padY) = resizeWithPad(bitmap, INPUT_SIZE)
        val inputTensor = bitmapToTensor(resized)

        val inputs = mapOf(session.inputNames.first() to inputTensor)
        val results = session.run(inputs)

        Log.d(TAG, "det_10g выходы: ${results.map { "${it.key}: ${(it.value as? OnnxTensor)?.info}" }}")

        val faces = parseOutput(results, scale, padX, padY, bitmap.width, bitmap.height)

        inputTensor.close()
        results.close()

        return faces.sortedByDescending { it.score }
    }

    /**
     * Если детектор не нашёл лицо — возвращает синтетическое центральное лицо.
     * Используется как fallback для фото донора.
     */
    fun detectOrCenter(bitmap: Bitmap): List<Face> {
        val found = detect(bitmap)
        if (found.isNotEmpty()) return found

        Log.w(TAG, "Лицо не найдено, используем центр изображения как fallback")
        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()
        // Берём центральные 60% кадра
        val margin = 0.2f
        val bbox = RectF(w * margin, h * margin, w * (1f - margin), h * (1f - margin))
        // Синтетические landmarks в пропорциях среднего лица
        val cx = w / 2f; val cy = h / 2f
        val faceH = h * 0.6f
        val landmarks = floatArrayOf(
            cx - faceH * 0.18f, cy - faceH * 0.07f,   // левый глаз
            cx + faceH * 0.18f, cy - faceH * 0.07f,   // правый глаз
            cx,                  cy + faceH * 0.05f,   // нос
            cx - faceH * 0.14f, cy + faceH * 0.22f,   // левый уголок рта
            cx + faceH * 0.14f, cy + faceH * 0.22f    // правый уголок рта
        )
        return listOf(Face(bbox, landmarks, 0.5f))
    }

    data class ResizeResult(val bitmap: Bitmap, val scale: Float, val padX: Float, val padY: Float)

    private fun resizeWithPad(src: Bitmap, targetSize: Int): ResizeResult {
        val scale = min(targetSize.toFloat() / src.width, targetSize.toFloat() / src.height)
        val newW = (src.width * scale).toInt()
        val newH = (src.height * scale).toInt()
        val padX = (targetSize - newW) / 2f
        val padY = (targetSize - newH) / 2f

        val padded = Bitmap.createBitmap(targetSize, targetSize, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(padded)
        canvas.drawColor(android.graphics.Color.rgb(114, 114, 114))
        val scaled = Bitmap.createScaledBitmap(src, newW, newH, true)
        canvas.drawBitmap(scaled, padX, padY, null)
        // createScaledBitmap может вернуть тот же объект что src (если размер совпал).
        // Рециклируем только если это новый bitmap — иначе убьём исходный кадр.
        if (scaled !== src) scaled.recycle()

        return ResizeResult(padded, scale, padX, padY)
    }

    private fun bitmapToTensor(bitmap: Bitmap): OnnxTensor {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        // NCHW, BGR, без нормализации [0,255]
        val floatBuf = FloatBuffer.allocate(3 * h * w)
        val r = FloatArray(h * w)
        val g = FloatArray(h * w)
        val b = FloatArray(h * w)
        for (i in pixels.indices) {
            val px = pixels[i]
            b[i] = (px and 0xFF).toFloat()
            g[i] = ((px shr 8) and 0xFF).toFloat()
            r[i] = ((px shr 16) and 0xFF).toFloat()
        }
        floatBuf.put(b); floatBuf.put(g); floatBuf.put(r)
        floatBuf.rewind()

        return OnnxTensor.createTensor(env, floatBuf, longArrayOf(1, 3, h.toLong(), w.toLong()))
    }

    private fun parseOutput(
        results: OrtSession.Result,
        scale: Float,
        padX: Float,
        padY: Float,
        origW: Int,
        origH: Int
    ): List<Face> {
        val faces = mutableListOf<Face>()
        val strides = listOf(8, 16, 32)

        for (stride in strides) {
            // Пробуем оба формата имён
            val scoresTensor = results.get("score_$stride").orElse(null)
                ?: results.get("score${stride}").orElse(null)
                ?: continue
            val bboxesTensor = results.get("bbox_$stride").orElse(null)
                ?: results.get("bbox${stride}").orElse(null)
                ?: continue
            val kpsTensor = results.get("kps_$stride").orElse(null)
                ?: results.get("kps${stride}").orElse(null)

            // Передаём OnnxTensor — toFlatFloats читает через .floatBuffer
            val scoreFlat = toFlatFloats(scoresTensor as OnnxTensor)
            val bboxFlat  = toFlatFloats(bboxesTensor as OnnxTensor)
            val kpsFlat   = kpsTensor?.let { toFlatFloats(it as OnnxTensor) }

            val fW = INPUT_SIZE / stride
            val n = scoreFlat.size   // количество анкоров

            for (i in 0 until n) {
                val sc = scoreFlat[i]
                if (sc < 0.35f) continue   // порог снижен с 0.5 до 0.35

                val anchorX = (i % fW) * stride + stride / 2f
                val anchorY = (i / fW) * stride + stride / 2f

                val bBase = i * 4
                if (bBase + 3 >= bboxFlat.size) continue

                val x1 = (anchorX - bboxFlat[bBase]     * stride - padX) / scale
                val y1 = (anchorY - bboxFlat[bBase + 1] * stride - padY) / scale
                val x2 = (anchorX + bboxFlat[bBase + 2] * stride - padX) / scale
                val y2 = (anchorY + bboxFlat[bBase + 3] * stride - padY) / scale

                val bbox = RectF(
                    x1.coerceIn(0f, origW.toFloat()),
                    y1.coerceIn(0f, origH.toFloat()),
                    x2.coerceIn(0f, origW.toFloat()),
                    y2.coerceIn(0f, origH.toFloat())
                )

                val landmarks = if (kpsFlat != null) {
                    val kBase = i * 10
                    if (kBase + 9 < kpsFlat.size) {
                        FloatArray(10) { j ->
                            val v = kpsFlat[kBase + j]
                            if (j % 2 == 0) {
                                ((anchorX + v * stride - padX) / scale).coerceIn(0f, origW.toFloat())
                            } else {
                                ((anchorY + v * stride - padY) / scale).coerceIn(0f, origH.toFloat())
                            }
                        }
                    } else FloatArray(10)
                } else FloatArray(10)

                faces.add(Face(bbox, landmarks, sc))
            }
        }

        Log.d(TAG, "Найдено лиц до NMS: ${faces.size}")
        return nms(faces, 0.4f)
    }

    /**
     * Читает OnnxTensor напрямую через FloatBuffer — единственный надёжный путь.
     * .value возвращает Java Object (float[], float[][], ...) — каст нестабилен.
     */
    private fun toFlatFloats(raw: Any): FloatArray {
        // Путь 1: сам тензор — читаем через floatBuffer
        if (raw is OnnxTensor) {
            val buf = raw.floatBuffer
            val arr = FloatArray(buf.remaining())
            buf.get(arr)
            return arr
        }
        // Путь 2: уже распакованный Java-объект из .value
        return when (raw) {
            is FloatArray -> raw
            is Array<*>   -> {
                val list = mutableListOf<Float>()
                flattenInto(raw, list)
                list.toFloatArray()
            }
            // float[][] из Java (приходит как Object, не как Array<*> в некоторых версиях ORT)
            else -> {
                try {
                    val javaArr = raw as Array<FloatArray>
                    val list = mutableListOf<Float>()
                    for (row in javaArr) row.forEach { list.add(it) }
                    list.toFloatArray()
                } catch (e: Exception) {
                    Log.e(TAG, "toFlatFloats: неизвестный тип ${raw::class.java.name}")
                    floatArrayOf()
                }
            }
        }
    }

    private fun flattenInto(arr: Array<*>, out: MutableList<Float>) {
        for (el in arr) {
            when (el) {
                is Float      -> out.add(el)
                is FloatArray -> el.forEach { out.add(it) }
                is Array<*>   -> flattenInto(el, out)
            }
        }
    }

    private fun nms(faces: List<Face>, iouThreshold: Float): List<Face> {
        val sorted = faces.sortedByDescending { it.score }.toMutableList()
        val keep = mutableListOf<Face>()
        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            keep.add(best)
            sorted.removeAll { iou(it.bbox, best.bbox) > iouThreshold }
        }
        return keep
    }

    private fun iou(a: RectF, b: RectF): Float {
        val ix1 = max(a.left, b.left); val iy1 = max(a.top, b.top)
        val ix2 = min(a.right, b.right); val iy2 = min(a.bottom, b.bottom)
        val inter = max(0f, ix2 - ix1) * max(0f, iy2 - iy1)
        val union = a.width() * a.height() + b.width() * b.height() - inter
        return if (union <= 0f) 0f else inter / union
    }

    override fun close() {
        session.close()
    }
}
