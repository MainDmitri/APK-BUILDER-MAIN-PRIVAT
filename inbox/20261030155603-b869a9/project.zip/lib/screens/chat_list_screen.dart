import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/tg_service.dart';
import '../services/app_state.dart';
import 'chat_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});
  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen>
    with WidgetsBindingObserver {
  List<TgDialog> _dialogs = [];
  bool _loading = true;
  int _tab = 0; // 0=all,1=personal,2=groups,3=channels
  StreamSubscription? _chatSub;
  int _bnav = 0;

  static const _tabs = [
    ('all', 'Все'),
    ('private', 'Личные'),
    ('group', 'Группы'),
    ('channel', 'Каналы'),
  ];

  TgService get _td => context.read<TgService>();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadFromCache();
    // Слушаем live-обновления из TDLib
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _chatSub = _td.chatStream.listen((dialogs) {
        if (mounted) setState(() => _dialogs = _filterDialogs(dialogs));
      });
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _chatSub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _loadFromCache();
  }

  void _loadFromCache() {
    final td = context.read<TgService>();
    final all = td.dialogs;
    setState(() {
      _dialogs = _filterDialogs(all);
      _loading = false;
    });
  }

  List<TgDialog> _filterDialogs(List<TgDialog> all) {
    final kind = _tabs[_tab].$1;
    if (kind == 'all') return all;
    return all.where((d) => d.kind == kind).toList();
  }

  void _switchTab(int idx) {
    setState(() {
      _tab = idx;
      _dialogs = _filterDialogs(_td.dialogs);
    });
  }

  @override
  Widget build(BuildContext context) {
    final tdState = context.watch<TgService>().authState;
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Column(
        children: [
          _buildAppBar(tdState),
          _buildTabs(),
          Expanded(
            child: _loading
                ? _buildSkeleton()
                : _dialogs.isEmpty
                    ? _buildEmpty()
                    : _buildList(),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  Widget _buildAppBar(TgAuthState tdState) {
    return Container(
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 16, right: 16, bottom: 12,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0F),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                  colors: [Color(0xFFF97316), Color(0xFFEA580C)]),
            ),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Telegram',
                    style: TextStyle(color: Colors.white,
                        fontSize: 17, fontWeight: FontWeight.w700)),
                Row(children: [
                  Container(
                    width: 6, height: 6,
                    margin: const EdgeInsets.only(right: 5),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: tdState == TgAuthState.ready
                          ? const Color(0xFF22C55E)
                          : const Color(0xFFF97316),
                    ),
                  ),
                  Text(
                    tdState == TgAuthState.ready ? 'Подключено' : 'Кэш',
                    style: const TextStyle(color: Color(0xFF71717A), fontSize: 11),
                  ),
                ]),
              ],
            ),
          ),
          IconButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SearchScreen())),
            icon: const Icon(Icons.search_rounded, color: Color(0xFF71717A)),
          ),
          IconButton(
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SettingsScreen())),
            icon: const Icon(Icons.settings_rounded, color: Color(0xFF71717A)),
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        itemCount: _tabs.length,
        itemBuilder: (_, i) {
          final selected = i == _tab;
          return GestureDetector(
            onTap: () => _switchTab(i),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: selected
                    ? const Color(0xFFF97316)
                    : const Color(0xFF1A1A22),
              ),
              child: Text(_tabs[i].$2,
                  style: TextStyle(
                      color: selected ? Colors.white : const Color(0xFF71717A),
                      fontSize: 13, fontWeight: FontWeight.w500)),
            ),
          );
        },
      ),
    );
  }

  Widget _buildList() {
    return ListView.builder(
      itemCount: _dialogs.length,
      itemBuilder: (_, i) {
        final d = _dialogs[i];
        return _ChatTile(dialog: d, index: i,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => ChatScreen(dialog: d))));
      },
    );
  }

  Widget _buildSkeleton() {
    return ListView.builder(
      itemCount: 12,
      itemBuilder: (_, i) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        child: Row(children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF1A1A22),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(height: 14, width: 120,
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A22),
                      borderRadius: BorderRadius.circular(4))),
                const SizedBox(height: 6),
                Container(height: 11, width: 200,
                    decoration: BoxDecoration(
                      color: const Color(0xFF141418),
                      borderRadius: BorderRadius.circular(4))),
              ],
            ),
          ),
        ]),
      ).animate(delay: Duration(milliseconds: i * 40))
          .shimmer(duration: 900.ms, color: const Color(0xFF2A2A35)),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.chat_bubble_outline_rounded,
              color: Color(0xFF3F3F46), size: 48),
          const SizedBox(height: 12),
          const Text('Нет чатов', style: TextStyle(
              color: Color(0xFF71717A), fontSize: 15)),
        ],
      ),
    );
  }

  Widget _buildBottomNav() {
    return NavigationBar(
      backgroundColor: const Color(0xFF0A0A0F),
      selectedIndex: _bnav,
      indicatorColor: const Color(0xFFF97316).withOpacity(0.2),
      onDestinationSelected: (i) => setState(() => _bnav = i),
      destinations: const [
        NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline_rounded),
            selectedIcon: Icon(Icons.chat_bubble_rounded,
                color: Color(0xFFF97316)),
            label: 'Чаты'),
        NavigationDestination(
            icon: Icon(Icons.archive_outlined),
            selectedIcon: Icon(Icons.archive_rounded,
                color: Color(0xFFF97316)),
            label: 'Архив'),
        NavigationDestination(
            icon: Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded,
                color: Color(0xFFF97316)),
            label: 'Настройки'),
      ],
    );
  }
}

class _ChatTile extends StatelessWidget {
  final TgDialog dialog;
  final int index;
  final VoidCallback onTap;

  const _ChatTile({
    required this.dialog,
    required this.index,
    required this.onTap,
  });

  Color _avatarColor(String title) {
    final colors = [
      const Color(0xFFF97316), const Color(0xFF8B5CF6),
      const Color(0xFF3B82F6), const Color(0xFF22C55E),
      const Color(0xFFEC4899), const Color(0xFF14B8A6),
      const Color(0xFFEAB308), const Color(0xFFEF4444),
    ];
    final idx = title.isNotEmpty ? title.codeUnitAt(0) % colors.length : 0;
    return colors[idx];
  }

  String _timeLabel(String isoDate) {
    if (isoDate.isEmpty) return '';
    try {
      final dt = DateTime.parse(isoDate).toLocal();
      final now = DateTime.now();
      if (dt.day == now.day && dt.month == now.month &&
          dt.year == now.year) {
        return '${dt.hour.toString().padLeft(2, '0')}:'
            '${dt.minute.toString().padLeft(2, '0')}';
      }
      return '${dt.day}.${dt.month.toString().padLeft(2, '0')}';
    } catch (_) {
      return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _avatarColor(dialog.title);
    final initial = dialog.title.isNotEmpty
        ? dialog.title[0].toUpperCase()
        : '?';
    final icon = dialog.kind == 'channel'
        ? Icons.campaign_rounded
        : dialog.kind == 'group'
            ? Icons.group_rounded
            : null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          children: [
            // Avatar
            Stack(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [color, color.withOpacity(0.7)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: Center(
                    child: Text(initial,
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w600)),
                  ),
                ),
                if (icon != null)
                  Positioned(
                    right: 0, bottom: 0,
                    child: Container(
                      width: 18, height: 18,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF07070A),
                      ),
                      child: Icon(icon, size: 12, color: color),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(dialog.title,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.w600),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis),
                      ),
                      Text(_timeLabel(dialog.lastSeen),
                          style: const TextStyle(
                              color: Color(0xFF71717A), fontSize: 12)),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          dialog.lastMessage.isNotEmpty
                              ? dialog.lastMessage
                              : '...',
                          style: const TextStyle(
                              color: Color(0xFF71717A), fontSize: 13),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (dialog.unreadCount > 0) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: const Color(0xFFF97316),
                          ),
                          child: Text(
                            dialog.unreadCount > 99
                                ? '99+'
                                : '${dialog.unreadCount}',
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ).animate(delay: Duration(milliseconds: index * 30))
          .fadeIn(duration: 250.ms)
          .slideX(begin: 0.03, end: 0),
    );
  }
}
