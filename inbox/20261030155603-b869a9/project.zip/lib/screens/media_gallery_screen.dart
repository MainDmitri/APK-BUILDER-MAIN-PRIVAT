import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/message.dart';
import '../services/sqlite_cache.dart';
// td_service removed — file download not yet implemented in MTProto service

class MediaGalleryScreen extends StatefulWidget {
  final TgDialog dialog;
  const MediaGalleryScreen({super.key, required this.dialog});
  @override
  State<MediaGalleryScreen> createState() => _MediaGalleryScreenState();
}

class _MediaGalleryScreenState extends State<MediaGalleryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  List<TgMessage> _all = [];
  List<TgMessage> _photos = [];
  List<TgMessage> _videos = [];
  List<TgMessage> _oneTime = [];
  bool _loading = true;
  bool _loadingMore = false;
  bool _hasMore = true;

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 4, vsync: this);
    _load();
  }

  @override
  void dispose() {
    _tabCtrl.dispose();
    super.dispose();
  }

  Future<void> _load({bool more = false}) async {
    if (more && (!_hasMore || _loadingMore)) return;
    setState(() {
      if (more) _loadingMore = true; else _loading = true;
    });
    try {
      final db = await SqliteCache.open();
      final offset = more ? _all.length : 0;
      final msgs = await db.getMediaMessages(
          widget.dialog.chatId, limit: 60, offset: offset);
      if (!mounted) return;
      setState(() {
        if (!more) {
          _all = msgs;
        } else {
          _all.addAll(msgs);
        }
        _photos = _all.where((m) => m.isPhoto && !m.isOneTime).toList();
        _videos = _all.where((m) => m.isVideo && !m.isOneTime).toList();
        _oneTime = _all.where((m) => m.isOneTime).toList();
        _loading = false;
        _loadingMore = false;
        _hasMore = msgs.length >= 60;
      });
    } catch (_) {
      if (mounted) setState(() { _loading = false; _loadingMore = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Column(
        children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(
                    color: Color(0xFFF97316), strokeWidth: 2))
                : TabBarView(
                    controller: _tabCtrl,
                    children: [
                      _GalleryGrid(
                        messages: _all,
                        chatId: widget.dialog.chatId,
                        hasMore: _hasMore,
                        loadingMore: _loadingMore,
                        onLoadMore: () => _load(more: true),
                      ),
                      _GalleryGrid(
                        messages: _photos,
                        chatId: widget.dialog.chatId,
                        hasMore: false,
                        loadingMore: false,
                        onLoadMore: () {},
                      ),
                      _GalleryGrid(
                        messages: _videos,
                        chatId: widget.dialog.chatId,
                        hasMore: false,
                        loadingMore: false,
                        onLoadMore: () {},
                      ),
                      _OneTimeList(
                        messages: _oneTime,
                        chatId: widget.dialog.chatId,
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28))),
      ),
      padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 4,
          bottom: 8, left: 4, right: 16),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded,
                color: Color(0xFFF97316), size: 20),
            onPressed: () => Navigator.pop(context),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Медиагалерея',
                    style: TextStyle(color: Colors.white, fontSize: 17,
                        fontWeight: FontWeight.w600)),
                Text(widget.dialog.title,
                    style: const TextStyle(
                        color: Color(0xFF71717A), fontSize: 12)),
              ],
            ),
          ),
          Text('${_all.length} файлов',
              style: const TextStyle(
                  color: Color(0xFF71717A), fontSize: 13)),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: const Color(0xFF0F0F14),
      child: TabBar(
        controller: _tabCtrl,
        indicatorColor: const Color(0xFFF97316),
        labelColor: const Color(0xFFF97316),
        unselectedLabelColor: const Color(0xFF71717A),
        indicatorWeight: 2,
        labelStyle: const TextStyle(
            fontSize: 13, fontWeight: FontWeight.w600),
        tabs: [
          Tab(text: 'Все (${_all.length})'),
          Tab(text: 'Фото (${_photos.length})'),
          Tab(text: 'Видео (${_videos.length})'),
          Tab(text: '👁 (${_oneTime.length})'),
        ],
      ),
    );
  }
}

// ── Gallery grid ─────────────────────────────────────────────────────────

class _GalleryGrid extends StatelessWidget {
  final List<TgMessage> messages;
  final int chatId;
  final bool hasMore;
  final bool loadingMore;
  final VoidCallback onLoadMore;

  const _GalleryGrid({
    required this.messages,
    required this.chatId,
    required this.hasMore,
    required this.loadingMore,
    required this.onLoadMore,
  });

  @override
  Widget build(BuildContext context) {
    if (messages.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.photo_library_outlined,
                color: Color(0xFF3F3F46), size: 56),
            SizedBox(height: 12),
            Text('Нет медиафайлов',
                style: TextStyle(
                    color: Color(0xFF52525B), fontSize: 16)),
          ],
        ),
      );
    }

    return NotificationListener<ScrollNotification>(
      onNotification: (n) {
        if (n.metrics.pixels >= n.metrics.maxScrollExtent - 200 &&
            hasMore && !loadingMore) {
          onLoadMore();
        }
        return false;
      },
      child: GridView.builder(
        padding: const EdgeInsets.all(2),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 2,
          mainAxisSpacing: 2,
        ),
        itemCount: messages.length + (loadingMore ? 1 : 0),
        itemBuilder: (ctx, i) {
          if (i >= messages.length) {
            return const Center(
                child: CircularProgressIndicator(
                    color: Color(0xFFF97316), strokeWidth: 2));
          }
          return _GridCell(
              msg: messages[i], chatId: chatId, index: i);
        },
      ),
    );
  }
}

class _GridCell extends StatefulWidget {
  final TgMessage msg;
  final int chatId;
  final int index;
  const _GridCell(
      {required this.msg, required this.chatId, required this.index});

  @override
  State<_GridCell> createState() => _GridCellState();
}

class _GridCellState extends State<_GridCell> {
  String? _localPath;

  @override
  void initState() {
    super.initState();
    _download();
  }

  Future<void> _download() async {
    // File download via MTProto not yet implemented
    // TODO: implement via teleflutter upload.getFile or InputDocumentFileLocation
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => _openFull(context),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_localPath != null && (widget.msg.isPhoto || widget.msg.isOneTime))
            Image.file(File(_localPath!), fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: const Color(0xFF18181B),
                  child: const Icon(Icons.broken_image_rounded,
                      color: Color(0xFF52525B), size: 28),
                ))
          else if (widget.msg.isVideo)
            Container(
              color: const Color(0xFF18181B),
              child: const Icon(Icons.video_file_rounded,
                  color: Color(0xFF52525B), size: 32),
            )
          else
            Container(
              color: const Color(0xFF18181B),
              child: const CircularProgressIndicator(
                  color: Color(0xFFF97316), strokeWidth: 1),
            ),
          if (widget.msg.isVideo)
            const Positioned(
              right: 6, bottom: 6,
              child: Icon(Icons.play_circle_rounded,
                  color: Colors.white, size: 22),
            ),
          if (widget.msg.isOneTime)
            Positioned.fill(
              child: Container(
                color: Colors.black.withOpacity(0.4),
                child: const Center(
                  child: Icon(Icons.visibility_rounded,
                      color: Color(0xFFF97316), size: 28),
                ),
              ),
            ),
        ],
      ),
    )
        .animate(delay: (widget.index * 20).ms)
        .fadeIn(duration: 200.ms)
        .scale(
            begin: const Offset(0.95, 0.95),
            end: const Offset(1, 1),
            duration: 200.ms);
  }

  void _openFull(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (_localPath != null && !widget.msg.isVideo)
              InteractiveViewer(
                  child: Image.file(File(_localPath!), fit: BoxFit.contain))
            else
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    widget.msg.isVideo
                        ? Icons.play_circle_rounded
                        : Icons.hourglass_empty_rounded,
                    color: const Color(0xFFF97316),
                    size: 72,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    widget.msg.isVideo
                        ? 'Видеофайл'
                        : 'Загрузка...',
                    style: const TextStyle(color: Colors.white),
                  ),
                ],
              ),
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              right: 12,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.6),
                  ),
                  child: const Icon(Icons.close_rounded,
                      color: Colors.white, size: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── One-time list ─────────────────────────────────────────────────────────

class _OneTimeList extends StatelessWidget {
  final List<TgMessage> messages;
  final int chatId;
  const _OneTimeList(
      {required this.messages, required this.chatId});

  @override
  Widget build(BuildContext context) {
    if (messages.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.visibility_off_rounded,
                color: Color(0xFF3F3F46), size: 56),
            SizedBox(height: 12),
            Text('Нет одноразовых медиа',
                style: TextStyle(
                    color: Color(0xFF52525B), fontSize: 16)),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: messages.length,
      itemBuilder: (ctx, i) {
        final msg = messages[i];
        return _OneTimeTile(msg: msg, chatId: chatId, index: i);
      },
    );
  }
}

class _OneTimeTile extends StatefulWidget {
  final TgMessage msg;
  final int chatId;
  final int index;
  const _OneTimeTile(
      {required this.msg, required this.chatId, required this.index});

  @override
  State<_OneTimeTile> createState() => _OneTimeTileState();
}

class _OneTimeTileState extends State<_OneTimeTile> {
  String? _path;

  Future<void> _open() async {
    // File download via MTProto not yet implemented
    if (_path == null) return;
    if (!mounted || _path == null) return;
    await showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          children: [
            InteractiveViewer(
              child: Image.file(File(_path!), fit: BoxFit.contain),
            ),
            Positioned(
              top: MediaQuery.of(context).padding.top + 8,
              right: 12,
              child: GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.black.withOpacity(0.6),
                  ),
                  child: const Icon(Icons.close_rounded,
                      color: Colors.white, size: 20),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final msg = widget.msg;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F14),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: const Color(0xFFF97316).withOpacity(0.3)),
        gradient: LinearGradient(
          colors: [
            const Color(0xFFF97316).withOpacity(0.08),
            const Color(0xFF8B5CF6).withOpacity(0.08),
          ],
        ),
      ),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 52, height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFFF97316).withOpacity(0.2),
          ),
          child: const Icon(Icons.visibility_rounded,
              color: Color(0xFFF97316), size: 26),
        ),
        title: Text(
          msg.sender.isNotEmpty ? msg.sender : 'Входящее',
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w600),
        ),
        subtitle: Text(msg.dayLabel,
            style: const TextStyle(
                color: Color(0xFF71717A), fontSize: 12)),
        trailing: GestureDetector(
          onTap: _open,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFFF97316),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('Открыть',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.w600)),
          ),
        ),
      ),
    )
        .animate(delay: (widget.index * 30).ms)
        .fadeIn(duration: 250.ms)
        .slideX(begin: 0.05, end: 0);
  }
}
