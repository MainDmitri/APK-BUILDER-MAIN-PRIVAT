// ignore_for_file: avoid_print
import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import 'package:teleflutter/teleflutter.dart';

import '../models/message.dart';
import 'sqlite_cache.dart';

// ─── Auth states ────────────────────────────────────────────────────────────

enum TgAuthState {
  idle,
  connecting,
  waitingPhoneNumber,
  waitingCode,
  waitingPassword,
  ready,
  error,
}

// ─── TgService ──────────────────────────────────────────────────────────────

class TgService extends ChangeNotifier {
  TgService._();
  static final TgService instance = TgService._();

  TelegramClient? _client;

  TgAuthState _authState = TgAuthState.idle;
  String _statusMessage = '';
  int _myUserId = 0;
  bool _initialized = false;

  List<TgDialog> _dialogs = [];

  final _chatStreamCtrl = StreamController<List<TgDialog>>.broadcast();
  final _newMsgCtrl = StreamController<TgMessage>.broadcast();

  // Phone auth state (for manual re-auth flow)
  String _pendingPhone = '';
  String _pendingPhoneCodeHash = '';

  TgAuthState get authState => _authState;
  String get statusMessage => _statusMessage;
  int get myUserId => _myUserId;
  List<TgDialog> get dialogs => List.unmodifiable(_dialogs);
  Stream<List<TgDialog>> get chatStream => _chatStreamCtrl.stream;
  Stream<TgMessage> get newMessageStream => _newMsgCtrl.stream;

  static const int _apiId = 21099690;
  static const String _apiHash = '9c1130843fda5f6516d7c8197ec26281';

  // ─── Init ─────────────────────────────────────────────────────────────────

  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    _setState(TgAuthState.connecting, 'Загрузка кэша...');

    // Show cached data immediately
    await _loadCachedDialogs();

    try {
      final sessionString = await _loadSessionString();
      if (sessionString.isNotEmpty) {
        await _connect(sessionString);
      } else {
        _setState(TgAuthState.waitingPhoneNumber, 'Введите номер телефона');
      }
    } catch (e) {
      print('[TgService] initialize error: $e');
      _setState(TgAuthState.waitingPhoneNumber, 'Требуется авторизация');
    }
  }

  // ─── Session ──────────────────────────────────────────────────────────────

  Future<String> _loadSessionString() async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final sessionDir = Directory(p.join(docsDir.path, 'tg_sessions'));
      await sessionDir.create(recursive: true);

      final sessionFile = File(p.join(sessionDir.path, 'main.session'));
      if (!await sessionFile.exists()) {
        // Copy from assets on first run
        final data = await rootBundle.load('assets/sessions/main.session');
        await sessionFile.writeAsBytes(
          data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes),
        );
      }

      return (await sessionFile.readAsString()).trim();
    } catch (e) {
      print('[TgService] loadSessionString error: $e');
      return '';
    }
  }

  Future<void> _saveSessionString(String session) async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final sessionFile = File(
        p.join(docsDir.path, 'tg_sessions', 'main.session'),
      );
      await sessionFile.writeAsString(session);
    } catch (e) {
      print('[TgService] saveSessionString error: $e');
    }
  }

  // ─── Connect ──────────────────────────────────────────────────────────────

  Future<void> _connect(String sessionString) async {
    _setState(TgAuthState.connecting, 'Подключение к Telegram...');
    try {
      _client = TelegramClient(
        StringSession(sessionString),
        _apiId,
        _apiHash,
      );

      await _client!.connect();
      _subscribeToEvents();

      // Verify authorization using dynamic access to avoid TLObject type issues
      final authorized = await _checkAuth();
      if (authorized) {
        await _onReady();
      } else {
        _setState(TgAuthState.waitingPhoneNumber, 'Введите номер телефона');
      }
    } catch (e) {
      print('[TgService] connect error: $e');
      _setState(TgAuthState.waitingPhoneNumber, 'Требуется авторизация');
    }
  }

  Future<bool> _checkAuth() async {
    try {
      // Cast to dynamic to avoid compile-time TLObject member errors
      final dynamic client = _client;
      final dynamic me = await client.getMe();
      if (me != null) {
        final dynamic uid = me.id;
        if (uid != null) {
          _myUserId = (uid is int) ? uid : int.tryParse(uid.toString()) ?? 0;
          return _myUserId > 0;
        }
      }
      return false;
    } catch (e) {
      print('[TgService] checkAuth error: $e');
      return false;
    }
  }

  Future<void> _onReady() async {
    _setState(TgAuthState.ready, 'Подключено');
    unawaited(_fetchAndCacheDialogs());
  }

  // ─── Events ───────────────────────────────────────────────────────────────

  void _subscribeToEvents() {
    try {
      _client!.on(NewMessage(), _onNewMessage);
    } catch (e) {
      print('[TgService] subscribeToEvents error: $e');
    }
  }

  Future<void> _onNewMessage(dynamic event) async {
    try {
      final dynamic msg = event?.message ?? event;
      final tgMsg = _parseMsgDynamic(msg);
      if (tgMsg == null) return;

      final db = await SqliteCache.open();
      await db.saveMessage(tgMsg);
      _updateDialogLastMsg(tgMsg);

      _newMsgCtrl.add(tgMsg);
      _chatStreamCtrl.add(_dialogs);
      notifyListeners();
    } catch (e) {
      print('[TgService] onNewMessage error: $e');
    }
  }

  // ─── Fetch dialogs ────────────────────────────────────────────────────────

  Future<void> _fetchAndCacheDialogs() async {
    if (_client == null) return;
    try {
      // Cast to dynamic to avoid compile-time errors on unconfirmed methods
      final dynamic client = _client;
      final dynamic result = await client.getDialogs(limit: 100);
      if (result == null) return;

      final List<dynamic> dialogList =
          (result is List) ? result : [result];
      if (dialogList.isEmpty) return;

      final tgDialogs = <TgDialog>[];
      for (final d in dialogList) {
        final tgD = _parseDialogEntity(d);
        if (tgD != null) tgDialogs.add(tgD);
      }

      if (tgDialogs.isNotEmpty) {
        _dialogs = tgDialogs;
        final db = await SqliteCache.open();
        for (final d in tgDialogs) {
          await db.upsertChat(d);
        }
        _chatStreamCtrl.add(_dialogs);
        notifyListeners();
      }
    } catch (e) {
      print('[TgService] fetchDialogs error: $e');
      // Not fatal — cached data already displayed
    }
  }

  TgDialog? _parseDialogEntity(dynamic d) {
    try {
      final dynamic rawId = d.id;
      final int chatId =
          (rawId is int) ? rawId : int.tryParse(rawId.toString()) ?? 0;
      if (chatId == 0) return null;

      String title = '';
      try { title = d.title as String? ?? ''; } catch (_) {}
      if (title.isEmpty) {
        try {
          final fn = d.firstName as String? ?? '';
          final ln = d.lastName as String? ?? '';
          title = '$fn $ln'.trim();
        } catch (_) {}
      }
      if (title.isEmpty) title = 'Чат $chatId';

      String username = '';
      try { username = d.username as String? ?? ''; } catch (_) {}

      bool isBot = false;
      try { isBot = d.bot == true; } catch (_) {}

      bool isGroup = false;
      try { isGroup = d.isGroup == true || d.isChat == true || d.megagroup == true; } catch (_) {}

      bool isChannel = false;
      try { isChannel = d.isChannel == true || d.broadcast == true; } catch (_) {}

      final int unread = () {
        try { return d.unreadCount as int? ?? 0; } catch (_) { return 0; }
      }();

      String kind = 'user';
      if (isBot) kind = 'bot';
      else if (isChannel) kind = 'channel';
      else if (isGroup) kind = 'group';

      String lastMsg = '';
      String lastSeen = '';
      try {
        final dynamic m = d.message;
        if (m != null) {
          lastMsg = m.message as String? ?? m.text as String? ?? '';
          final dynamic dateRaw = m.date;
          if (dateRaw != null) {
            final int dateUnix =
                (dateRaw is int) ? dateRaw : int.tryParse(dateRaw.toString()) ?? 0;
            if (dateUnix > 0) {
              lastSeen = DateTime.fromMillisecondsSinceEpoch(dateUnix * 1000)
                  .toIso8601String();
            }
          }
        }
      } catch (_) {}

      return TgDialog(
        chatId: chatId,
        title: title,
        username: username,
        kind: kind,
        lastMessage: lastMsg,
        lastSeen: lastSeen,
        unreadCount: unread,
      );
    } catch (e) {
      return null;
    }
  }

  // ─── Load cached dialogs ──────────────────────────────────────────────────

  Future<void> _loadCachedDialogs() async {
    try {
      final db = await SqliteCache.open();
      _dialogs = await db.loadChats();
      if (_dialogs.isNotEmpty) {
        _chatStreamCtrl.add(_dialogs);
        notifyListeners();
      }
    } catch (e) {
      print('[TgService] cache load error: $e');
    }
  }

  void _updateDialogLastMsg(TgMessage msg) {
    final idx = _dialogs.indexWhere((d) => d.chatId == msg.chatId);
    if (idx >= 0) {
      final old = _dialogs[idx];
      _dialogs[idx] = TgDialog(
        chatId: old.chatId,
        title: old.title,
        username: old.username,
        kind: old.kind,
        lastMessage: msg.text,
        lastSeen: msg.date,
        unreadCount: old.unreadCount + (msg.out ? 0 : 1),
      );
      _dialogs.sort((a, b) => b.lastSeen.compareTo(a.lastSeen));
    }
  }

  // ─── Parse raw message object ─────────────────────────────────────────────

  TgMessage? _parseMsgDynamic(dynamic msg) {
    if (msg == null) return null;
    try {
      final dynamic rawMsgId = msg.id;
      final int msgId =
          (rawMsgId is int) ? rawMsgId : int.tryParse(rawMsgId.toString()) ?? 0;
      if (msgId == 0) return null;

      // Determine chatId from peer
      int chatId = 0;
      try {
        final dynamic peer = msg.peerId ?? msg.toId ?? msg.peer;
        if (peer != null) {
          final String pType = peer.runtimeType.toString().toLowerCase();
          if (pType.contains('peeruser') || pType.contains('user')) {
            final dynamic uid = peer.userId ?? peer.id;
            chatId = (uid is int) ? uid : int.tryParse(uid.toString()) ?? 0;
          } else if (pType.contains('peerchat') || pType.contains('chat')) {
            final dynamic cid = peer.chatId ?? peer.id;
            chatId = (cid is int) ? cid : int.tryParse(cid.toString()) ?? 0;
          } else if (pType.contains('peerchannel') || pType.contains('channel')) {
            final dynamic chid = peer.channelId ?? peer.id;
            final int rawId =
                (chid is int) ? chid : int.tryParse(chid.toString()) ?? 0;
            chatId = rawId > 0 ? -1000000000000 - rawId : 0;
          }
        }
      } catch (_) {}
      if (chatId == 0) return null;

      final String text = () {
        try { return msg.message as String? ?? msg.text as String? ?? ''; }
        catch (_) { return ''; }
      }();

      final bool isOut = () {
        try { return msg.out == true; } catch (_) { return false; }
      }();

      final int dateUnix = () {
        try {
          final dynamic d = msg.date;
          return (d is int) ? d : int.tryParse(d.toString()) ?? 0;
        } catch (_) { return 0; }
      }();

      final DateTime dt = dateUnix > 0
          ? DateTime.fromMillisecondsSinceEpoch(dateUnix * 1000).toLocal()
          : DateTime.now().toLocal();
      final String dateIso = dt.toIso8601String();
      final String dayKey =
          '${dt.year}-${dt.month.toString().padLeft(2, '0')}-${dt.day.toString().padLeft(2, '0')}';
      final String dayLabel = _formatDayLabel(dt);

      String sender = '';
      try {
        final dynamic from = msg.fromId ?? msg.sender;
        if (from != null) {
          final String ft = from.runtimeType.toString().toLowerCase();
          if (ft.contains('user')) {
            final dynamic sid = from.userId ?? from.id;
            sender = 'User ${sid ?? ''}';
          }
        }
      } catch (_) {}

      String mediaHtml = '';
      try {
        final dynamic media = msg.media;
        if (media != null) mediaHtml = _mediaHtml(media);
      } catch (_) {}

      return TgMessage(
        msgId: msgId,
        chatId: chatId,
        text: text,
        out: isOut,
        sender: sender,
        senderUsername: '',
        mediaHtml: mediaHtml,
        dayKey: dayKey,
        dayLabel: dayLabel,
        date: dateIso,
      );
    } catch (e) {
      print('[TgService] parseMsgDynamic error: $e');
      return null;
    }
  }

  String _mediaHtml(dynamic media) {
    final String t = media.runtimeType.toString().toLowerCase();
    if (t.contains('photo')) return '<img class="msg-photo" />';
    if (t.contains('document')) {
      try {
        final dynamic doc = media.document;
        if (doc != null) {
          for (final dynamic attr in doc.attributes ?? []) {
            final String at = attr.runtimeType.toString().toLowerCase();
            if (at.contains('video')) return '<video class="msg-video" />';
            if (at.contains('audio')) return '<audio class="msg-voice" />';
            if (at.contains('sticker')) return '<img class="msg-sticker" />';
          }
        }
      } catch (_) {}
      return '<div class="msg-document">📄 Файл</div>';
    }
    return '';
  }

  String _formatDayLabel(DateTime dt) {
    final DateTime now = DateTime.now();
    if (dt.day == now.day && dt.month == now.month && dt.year == now.year) {
      return 'Сегодня';
    }
    final DateTime yesterday = now.subtract(const Duration(days: 1));
    if (dt.day == yesterday.day &&
        dt.month == yesterday.month &&
        dt.year == yesterday.year) {
      return 'Вчера';
    }
    const List<String> months = [
      '', 'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
      'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря',
    ];
    return '${dt.day} ${months[dt.month]} ${dt.year}';
  }

  // ─── Public API ───────────────────────────────────────────────────────────

  Future<List<TgMessage>> getHistory(int chatId, {int limit = 50}) async {
    final db = await SqliteCache.open();
    // Always serve from cache (live updates come via NewMessage event)
    return db.loadMessages(chatId, limit: limit);
  }

  Future<void> sendMessage(int chatId, String text, {int? replyToMsgId}) async {
    if (_client == null) throw Exception('Not connected');
    // Cast to dynamic to avoid compile-time errors
    final dynamic client = _client;
    await client.sendMessage(chatId, text);
  }

  Future<void> editMessage(int chatId, int msgId, String text) async {
    // Not available in teleflutter yet — stub
    print('[TgService] editMessage: not implemented in teleflutter');
  }

  Future<void> deleteMessage(int chatId, int msgId) async {
    // Not available in teleflutter yet — stub
    print('[TgService] deleteMessage: not implemented in teleflutter');
  }

  // ─── Auth flow ────────────────────────────────────────────────────────────

  /// Called from AuthScreen when user enters phone number.
  /// teleflutter doesn't expose sendCode/signIn at high-level yet.
  /// We guide the user to use the existing session or re-login via Telethon.
  Future<void> setPhoneNumber(String phone) async {
    _pendingPhone = phone;
    _pendingPhoneCodeHash = '';
    // Attempt connect with empty session to trigger auth
    try {
      _client ??= TelegramClient(StringSession(''), _apiId, _apiHash);
      await _client!.connect();
      // teleflutter low-level: we cannot call sendCode directly.
      // Set state to waiting code — user must obtain code via Telegram app.
      _setState(TgAuthState.waitingCode, 'Введите код из Telegram');
    } catch (e) {
      print('[TgService] setPhoneNumber error: $e');
      _setState(TgAuthState.error, 'Ошибка подключения: $e');
    }
  }

  /// Called from AuthScreen when user enters the SMS/app code.
  Future<void> setCode(String code) async {
    if (_client == null) {
      _setState(TgAuthState.error, 'Клиент не инициализирован');
      return;
    }
    try {
      // Try to sign in via dynamic invocation
      // teleflutter exposes invoke() for raw TL calls
      final dynamic result = await (_client as dynamic).invoke(
        'auth.signIn',
        {
          'phone_number': _pendingPhone,
          'phone_code_hash': _pendingPhoneCodeHash,
          'phone_code': code,
        },
      );
      print('[TgService] signIn result: $result');
      final ok = await _checkAuth();
      if (ok) {
        // Save the session
        final dynamic sess = (_client as dynamic).session;
        final String savedSession = sess?.save?.call() ?? '';
        if (savedSession.isNotEmpty) await _saveSessionString(savedSession);
        await _onReady();
      } else {
        _setState(TgAuthState.waitingPassword, 'Введите пароль 2FA');
      }
    } catch (e) {
      final String err = e.toString().toLowerCase();
      if (err.contains('password') || err.contains('2fa') || err.contains('sessionpasswordneeded')) {
        _setState(TgAuthState.waitingPassword, 'Введите пароль 2FA');
      } else if (err.contains('flood')) {
        _setState(TgAuthState.error, 'Слишком много попыток. Подождите.');
      } else {
        print('[TgService] setCode error: $e');
        _setState(TgAuthState.error, 'Неверный код: $e');
      }
    }
  }

  /// Called from AuthScreen when user enters 2FA password.
  Future<void> setPassword(String password) async {
    if (_client == null) {
      _setState(TgAuthState.error, 'Клиент не инициализирован');
      return;
    }
    try {
      // Try checkPassword via dynamic invocation
      await (_client as dynamic).invoke(
        'auth.checkPassword',
        {'password': password},
      );
      final ok = await _checkAuth();
      if (ok) await _onReady();
    } catch (e) {
      print('[TgService] setPassword error: $e');
      _setState(TgAuthState.error, 'Неверный пароль: $e');
    }
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  void _setState(TgAuthState state, String message) {
    _authState = state;
    _statusMessage = message;
    notifyListeners();
  }

  @override
  void dispose() {
    _chatStreamCtrl.close();
    _newMsgCtrl.close();
    try { _client?.disconnect(); } catch (_) {}
    super.dispose();
  }
}
