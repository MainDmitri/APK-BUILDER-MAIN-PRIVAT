import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/app_state.dart';
import 'services/tg_service.dart';
import 'services/session_installer.dart';
import 'screens/calculator_screen.dart';
import 'screens/chat_list_screen.dart';
import 'screens/auth_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF07070A),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  // Извлечь сессии из assets в Documents
  final sessionDir = await SessionInstaller.install();

  // Загрузить состояние
  final appState = AppState();
  await appState.init();
  appState.setSessionsPath(sessionDir);

  // TDLib сервис — инициализируется асинхронно
  final tgService = TgService.instance;
  // Запускаем в фоне, не ждём — UI покажет прогресс
  tgService.initialize();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: appState),
        ChangeNotifierProvider.value(value: tgService),
      ],
      child: const TgApp(),
    ),
  );
}

class TgApp extends StatelessWidget {
  const TgApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.dark(
          primary: const Color(0xFFF97316),
          secondary: const Color(0xFF8B5CF6),
          surface: const Color(0xFF0F0F14),
          background: const Color(0xFF07070A),
        ),
        scaffoldBackgroundColor: const Color(0xFF07070A),
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
      ),
      home: const RootRouter(),
    );
  }
}

class RootRouter extends StatelessWidget {
  const RootRouter({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    final tgService = context.watch<TgService>();

    // Калькулятор пока не разблокирован
    if (!appState.unlocked) return const CalculatorScreen();

    // MTProto нужна авторизация — показываем экран входа
    if (tgService.authState == TgAuthState.waitingPhoneNumber ||
        tgService.authState == TgAuthState.waitingCode ||
        tgService.authState == TgAuthState.waitingPassword) {
      return const AuthScreen();
    }

    // Всё готово — чаты (кэш сразу, потом живые)
    return const ChatListScreen();
  }
}
