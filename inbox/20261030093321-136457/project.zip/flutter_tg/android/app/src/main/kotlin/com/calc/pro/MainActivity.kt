package com.calc.pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
