import 'package:flutter/material.dart';

/// Wine Dark palette — deep red obsidian (shared by all screens).
const kSurfDark   = Color(0xFF0A0305);   // near-black base
const kSurfCon    = Color(0xFF150709);   // elevated container
const kSurfHigh   = Color(0xFF200C10);   // highest container
const kSurfXHigh  = Color(0xFF2D1118);   // chip / code bg
const kOnSurf     = Color(0xFFF5E4E7);   // light cream text
const kOutline    = Color(0xFF5C2E36);   // muted wine border
const kOutlineBr  = Color(0xFF8B4D58);   // brighter outline
const kPrimary    = Color(0xFFD4697C);   // rose-red primary
const kOnPrimary  = Color(0xFF1C0008);
const kSecondary  = Color(0xFFEBBCC4);   // pale pink
const kOnSec      = Color(0xFF2D0012);
const kError      = Color(0xFFFF5370);
const kSuccess    = Color(0xFF4CAF7D);   // green for found
const kWarning    = Color(0xFFFFB830);   // orange for blocked
