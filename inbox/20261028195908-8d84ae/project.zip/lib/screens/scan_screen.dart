// [context: Flutter/Dart 3.13.5, iOS-only, scan UI v3 premium]
// *state owned by ScanState in main.dart — this is pure display*

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../main.dart' show ScanState;
import '../theme/palette.dart';
import '../models/scan_result.dart';
import '../services/scanner_service.dart';

// ── port descriptor ───────────────────────────────────────────────────────────
class _PD { final int p; final String l; const _PD(this.p, this.l); }

const _kPorts = [
  _PD(37777,'Dahua'),  _PD(80,'HTTP'),     _PD(81,'HTTP+1'),  _PD(82,'HTTP+2'),
  _PD(83,'HTTP+3'),    _PD(84,'HTTP+4'),   _PD(85,'HTTP+5'),  _PD(88,'HTTP+8'),
  _PD(443,'HTTPS'),    _PD(554,'RTSP'),    _PD(2051,'VSIP'),  _PD(3500,'IPC'),
  _PD(7447,'UniFi'),   _PD(8000,'ALT'),    _PD(8001,'ALT+'),  _PD(8080,'Proxy'),
  _PD(8081,'Proxy+'),  _PD(8085,'DVR'),    _PD(8086,'DVR+'),  _PD(8088,'DVR++'),
  _PD(8089,'HIK'),     _PD(8090,'CAM'),    _PD(8181,'ALT2'),  _PD(8443,'HTTPS+'),
  _PD(8554,'RTSP+'),   _PD(8765,'WS'),     _PD(8888,'Proxy2'),_PD(8899,'Proxy3'),
  _PD(9000,'PHP'),     _PD(9090,'ALT3'),   _PD(10554,'RTSP2'),_PD(34567,'XMeye'),
  _PD(22,'SSH'),       _PD(23,'Telnet'),   _PD(2323,'Tel+'),  _PD(5554,'RTSP3'),
  _PD(8186,'RTMP'),    _PD(49152,'UPnP'),  _PD(55555,'DVR-X'),
];

// ── Brand color map ───────────────────────────────────────────────────────────
Color _brandColor(String brand) {
  return switch (brand.toLowerCase()) {
    String b when b.contains('dahua')    => const Color(0xFF2196F3),
    String b when b.contains('hikvisio') => const Color(0xFFFF5252),
    String b when b.contains('xmeye')    => const Color(0xFF9C27B0),
    String b when b.contains('reolink')  => const Color(0xFF4CAF50),
    String b when b.contains('axis')     => const Color(0xFFFF9800),
    String b when b.contains('telnet')   => const Color(0xFF607D8B),
    String b when b.contains('ssh')      => const Color(0xFF009688),
    _                                    => kPrimary,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ScanScreen
// ─────────────────────────────────────────────────────────────────────────────
class ScanScreen extends StatefulWidget {
  final ScanState scanState;
  const ScanScreen({super.key, required this.scanState});
  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  late final TextEditingController _ipCtrl;

  ScanState get _st => widget.scanState;

  @override
  void initState() {
    super.initState();
    _ipCtrl = TextEditingController(text: _st.ipRange);
    // sync controller → state on every keystroke
    _ipCtrl.addListener(() {
      if (_ipCtrl.text != _st.ipRange) _st.ipRange = _ipCtrl.text;
    });
    _st.addListener(_rebuild);
  }

  @override
  void dispose() {
    _st.removeListener(_rebuild);
    _ipCtrl.dispose();
    super.dispose();
  }

  void _rebuild() { if (mounted) setState(() {}); }

  void _dismiss() => FocusManager.instance.primaryFocus?.unfocus();

  Future<void> _startScan() async {
    _dismiss();
    final raw = _ipCtrl.text.trim();
    if (raw.isEmpty) { _snack('Enter an IP range first'); return; }
    final ips = expandIpRange(raw);
    if (ips.isEmpty) { _snack('Could not parse any IPs from input'); return; }
    await _st.startScan();
  }

  void _snack(String msg) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // tap outside any field → dismiss keyboard
    return GestureDetector(
      onTap:     _dismiss,
      behavior:  HitTestBehavior.translucent,
      child: CustomScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
            sliver: SliverList(
              delegate: SliverChildListDelegate([

                // ── 1. IP input ────────────────────────────────────────────
                _SectionLabel('IP RANGE / CIDR'),
                const SizedBox(height: 8),
                _IpField(ctrl: _ipCtrl, enabled: !_st.scanning),
                const SizedBox(height: 20),

                // ── 2. Port selector ───────────────────────────────────────
                Row(children: [
                  _SectionLabel('PORTS'),
                  const SizedBox(width: 8),
                  _CountBadge('${_st.selectedPorts.length}'),
                  const Spacer(),
                  if (_st.selectedPorts.length > 1 && !_st.scanning)
                    _GhostBtn('Reset', () => _st.resetPorts()),
                ]),
                const SizedBox(height: 8),
                _PortGrid(state: _st),
                const SizedBox(height: 16),

                // ── 3. Multi-port toggle ───────────────────────────────────
                _MultiPortCard(state: _st),
                const SizedBox(height: 20),

                // ── 4. Progress ────────────────────────────────────────────
                if (_st.scanning || _st.progress.total > 0) ...[
                  _ProgressCard(state: _st),
                  const SizedBox(height: 20),
                ],

                // ── 5. Action bar ──────────────────────────────────────────
                _ActionBar(
                  scanning:  _st.scanning,
                  onStart:   _startScan,
                  onStop:    _st.stopScan,
                ),
                const SizedBox(height: 20),

                // ── 6. Results header ──────────────────────────────────────
                if (_st.results.isNotEmpty) ...[
                  Row(children: [
                    _SectionLabel('RESULTS'),
                    const SizedBox(width: 8),
                    _CountBadge('${_st.results.length}', color: kSuccess),
                  ]),
                  const SizedBox(height: 10),
                ],
              ]),
            ),
          ),

          // ── 7. Results list ────────────────────────────────────────────
          if (_st.results.isNotEmpty)
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 30),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _ResultCard(r: _st.results[i]),
                  ),
                  childCount: _st.results.length,
                ),
              ),
            )
          else if (!_st.scanning && _st.progress.finished && _st.progress.total > 0)
            SliverFillRemaining(
              hasScrollBody: false,
              child: _EmptyResult(state: _st),
            )
          else
            const SliverToBoxAdapter(child: SizedBox(height: 40)),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Sub-widgets
// ─────────────────────────────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      style: TextStyle(
        color:       kOutlineBr,
        fontSize:    10,
        fontWeight:  FontWeight.w700,
        letterSpacing: 1.8,
      ));
}

class _CountBadge extends StatelessWidget {
  final String text;
  final Color  color;
  const _CountBadge(this.text, {this.color = kPrimary});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
          color:        color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(6),
          border:       Border.all(color: color.withOpacity(0.3)),
        ),
        child: Text(text,
            style: TextStyle(
              color:      color,
              fontSize:   11,
              fontWeight: FontWeight.w800,
            )));
}

class _GhostBtn extends StatelessWidget {
  final String       label;
  final VoidCallback onTap;
  const _GhostBtn(this.label, this.onTap);
  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: Text(label,
            style: TextStyle(color: kOutlineBr, fontSize: 12, fontWeight: FontWeight.w500)));
}

// ── IP field ──────────────────────────────────────────────────────────────────
class _IpField extends StatelessWidget {
  final TextEditingController ctrl;
  final bool enabled;
  const _IpField({required this.ctrl, required this.enabled});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: kPrimary.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, 4)),
        ],
      ),
      child: TextField(
        controller:      ctrl,
        enabled:         enabled,
        maxLines:        null,
        minLines:        2,
        textInputAction: TextInputAction.done,   // "Done" on iOS — no newline
        onSubmitted:     (_) => FocusManager.instance.primaryFocus?.unfocus(),
        style: const TextStyle(
          color:       kOnSurf,
          fontFamily:  'Menlo',
          fontSize:    13,
          height:      1.7,
        ),
        decoration: InputDecoration(
          hintText: '192.168.1.1-254\n10.0.0.0/24\n172.16.0.0/20',
          hintStyle: TextStyle(
            color:      kOutline.withOpacity(0.6),
            fontFamily: 'Menlo',
            fontSize:   12,
          ),
          prefixIcon: const Padding(
            padding: EdgeInsets.only(bottom: 20),
            child: Icon(Icons.lan_outlined, color: kPrimary, size: 20),
          ),
          prefixIconConstraints: const BoxConstraints(minWidth: 48, minHeight: 48),
          suffixIcon: enabled
              ? IconButton(
                  icon: const Icon(Icons.clear_rounded, size: 18, color: kOutlineBr),
                  onPressed: () => ctrl.clear(),
                )
              : null,
          border:          OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
          enabledBorder:   OutlineInputBorder(
            borderSide:    const BorderSide(color: kOutline, width: 0.8),
            borderRadius:  BorderRadius.circular(14),
          ),
          focusedBorder:   OutlineInputBorder(
            borderSide:    const BorderSide(color: kPrimary, width: 1.5),
            borderRadius:  BorderRadius.circular(14),
          ),
          disabledBorder:  OutlineInputBorder(
            borderSide:    BorderSide(color: kOutline.withOpacity(0.4)),
            borderRadius:  BorderRadius.circular(14),
          ),
          fillColor:       kSurfHigh,
          filled:          true,
          contentPadding: const EdgeInsets.fromLTRB(16, 14, 12, 14),
        ),
      ),
    );
  }
}

// ── Port grid ─────────────────────────────────────────────────────────────────
class _PortGrid extends StatelessWidget {
  final ScanState state;
  const _PortGrid({required this.state});

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing:    5,
      runSpacing: 5,
      children: _kPorts.map((pd) {
        final sel = state.selectedPorts.contains(pd.p);
        return GestureDetector(
          onTap: state.scanning ? null : () => state.togglePort(pd.p, !sel),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
            decoration: BoxDecoration(
              color:        sel ? kPrimary : kSurfHigh,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: sel ? kPrimary : kOutline.withOpacity(0.5),
                width: sel ? 0 : 0.5,
              ),
              boxShadow: sel ? [
                BoxShadow(color: kPrimary.withOpacity(0.3), blurRadius: 6, offset: const Offset(0, 2)),
              ] : null,
            ),
            child: Text(
              '${pd.p}',
              style: TextStyle(
                color:      sel ? kOnPrimary : kOnSurf.withOpacity(0.75),
                fontSize:   11,
                fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
                fontFamily: 'Menlo',
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

// ── Multi-port toggle card ────────────────────────────────────────────────────
class _MultiPortCard extends StatelessWidget {
  final ScanState state;
  const _MultiPortCard({required this.state});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color:        kSurfCon,
        borderRadius: BorderRadius.circular(14),
        border:       Border.all(color: kOutline.withOpacity(0.4)),
      ),
      child: SwitchListTile(
        title: const Text('Multi-port scan',
            style: TextStyle(color: kOnSurf, fontSize: 13, fontWeight: FontWeight.w600)),
        subtitle: Text(
          'Probe every selected port per IP  (slower)',
          style: TextStyle(color: kOutlineBr, fontSize: 11),
        ),
        value:     state.multiPort,
        onChanged: state.scanning ? null : state.setMultiPort,
        dense:     true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
      ),
    );
  }
}

// ── Progress card ─────────────────────────────────────────────────────────────
class _ProgressCard extends StatelessWidget {
  final ScanState state;
  const _ProgressCard({required this.state});

  String _pct() {
    if (state.progress.total == 0) return '0%';
    return '${((state.progress.checked / state.progress.total) * 100).round()}%';
  }

  @override
  Widget build(BuildContext context) {
    final p   = state.progress;
    final pct = p.total > 0 ? p.checked / p.total : 0.0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color:        kSurfCon,
        borderRadius: BorderRadius.circular(16),
        border:       Border.all(color: kOutline.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: kPrimary.withOpacity(0.06), blurRadius: 16, offset: const Offset(0, 4)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top: % + label + spinner
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(_pct(),
                  style: const TextStyle(
                    color:       kPrimary,
                    fontSize:    36,
                    fontWeight:  FontWeight.w900,
                    fontFamily:  'Menlo',
                    height:      1.0,
                  )),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      state.scanning ? 'Scanning…'
                          : (p.cancelled ? 'Stopped' : 'Complete'),
                      style: const TextStyle(
                          color: kOnSurf, fontSize: 13, fontWeight: FontWeight.w700),
                    ),
                    Text('${p.checked} / ${p.total} IPs',
                        style: const TextStyle(color: kOutlineBr, fontSize: 11)),
                  ],
                ),
              ),
              if (state.scanning)
                SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2, color: kPrimary,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          // Progress bar
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value:           pct,
              minHeight:       4,
              backgroundColor: kOutline.withOpacity(0.25),
              valueColor:      const AlwaysStoppedAnimation(kPrimary),
            ),
          ),
          const SizedBox(height: 14),
          // Stat chips
          Row(
            children: [
              _StatChip(emoji: '✅', val: '${p.found}',     label: 'found',   color: kSuccess),
              const SizedBox(width: 8),
              _StatChip(emoji: '⛔', val: '${p.blocked}',   label: 'blocked', color: kWarning),
              const SizedBox(width: 8),
              _StatChip(emoji: '🔌', val: '${p.openPorts}', label: 'open',    color: kSecondary),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String emoji, val, label;
  final Color  color;
  const _StatChip({required this.emoji, required this.val,
                   required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: BoxDecoration(
            color:        color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(10),
            border:       Border.all(color: color.withOpacity(0.2)),
          ),
          child: Column(
            children: [
              Text(emoji, style: const TextStyle(fontSize: 14)),
              const SizedBox(height: 2),
              Text(val,
                  style: TextStyle(
                      color: color, fontSize: 16,
                      fontWeight: FontWeight.w800, fontFamily: 'Menlo')),
              Text(label, style: const TextStyle(color: kOutlineBr, fontSize: 9)),
            ],
          ),
        ),
      );
}

// ── Action bar ────────────────────────────────────────────────────────────────
class _ActionBar extends StatelessWidget {
  final bool     scanning;
  final Future<void> Function() onStart;
  final VoidCallback onStop;
  const _ActionBar({required this.scanning, required this.onStart, required this.onStop});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // START button
        Expanded(
          child: GestureDetector(
            onTap: scanning ? null : () => onStart(),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              height: 52,
              decoration: BoxDecoration(
                gradient: scanning
                    ? null
                    : const LinearGradient(
                        colors: [Color(0xFFE07080), Color(0xFFB0283C)],
                        begin:  Alignment.topLeft,
                        end:    Alignment.bottomRight,
                      ),
                color:        scanning ? kSurfHigh : null,
                borderRadius: BorderRadius.circular(14),
                boxShadow: scanning ? null : [
                  BoxShadow(color: kPrimary.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4)),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.play_arrow_rounded, size: 22,
                      color: scanning ? kOutlineBr : kOnPrimary),
                  const SizedBox(width: 6),
                  Text(
                    scanning ? 'SCANNING…' : 'START SCAN',
                    style: TextStyle(
                      color:       scanning ? kOutlineBr : kOnPrimary,
                      fontWeight:  FontWeight.w900,
                      fontSize:    14,
                      letterSpacing: 1.2,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        // STOP button
        GestureDetector(
          onTap: scanning ? onStop : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 52, height: 52,
            decoration: BoxDecoration(
              color:        scanning ? kError.withOpacity(0.12) : kSurfHigh,
              borderRadius: BorderRadius.circular(14),
              border:       Border.all(
                color: scanning ? kError.withOpacity(0.5) : kOutline.withOpacity(0.3),
              ),
            ),
            child: Icon(Icons.stop_rounded, size: 26,
                color: scanning ? kError : kOutlineBr),
          ),
        ),
      ],
    );
  }
}

// ── Empty result ──────────────────────────────────────────────────────────────
class _EmptyResult extends StatelessWidget {
  final ScanState state;
  const _EmptyResult({required this.state});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color:        kSurfHigh,
              shape:        BoxShape.circle,
              border:       Border.all(color: kOutline.withOpacity(0.4)),
            ),
            child: const Icon(Icons.videocam_off_outlined, size: 34, color: kOutlineBr),
          ),
          const SizedBox(height: 18),
          const Text('No cameras found',
              style: TextStyle(color: kOnSurf, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          Text(
            'Scanned ${state.progress.checked} IPs\n'
            '${state.progress.openPorts} open ports detected',
            textAlign: TextAlign.center,
            style: const TextStyle(color: kOutlineBr, fontSize: 13, height: 1.5),
          ),
        ],
      ),
    );
  }
}

// ── Result card ───────────────────────────────────────────────────────────────
class _ResultCard extends StatelessWidget {
  final ScanResult r;
  const _ResultCard({required this.r});

  @override
  Widget build(BuildContext context) {
    final blocked = r.blocked;
    final accent  = blocked ? kWarning : _brandColor(r.brand);
    final cred    = r.credentialLabel;

    return GestureDetector(
      onTap: () {
        if (!blocked) {
          Clipboard.setData(ClipboardData(text: cred));
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Copied  $cred'), duration: const Duration(seconds: 1)),
          );
        }
      },
      child: Container(
        decoration: BoxDecoration(
          color:        kSurfCon,
          borderRadius: BorderRadius.circular(16),
          border:       Border.all(color: accent.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(color: accent.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 3)),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left: coloured dot + icon
              Column(
                children: [
                  Container(
                    width: 44, height: 44,
                    decoration: BoxDecoration(
                      color:        accent.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                      border:       Border.all(color: accent.withOpacity(0.35)),
                    ),
                    child: Icon(
                      blocked ? Icons.lock_rounded : Icons.videocam_rounded,
                      color: accent, size: 22,
                    ),
                  ),
                ],
              ),
              const SizedBox(width: 12),
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // IP:port
                    Row(children: [
                      Text('${r.ip}', style: const TextStyle(
                          color: kOnSurf, fontWeight: FontWeight.w700,
                          fontSize: 14, fontFamily: 'Menlo')),
                      Text(':${r.port}', style: TextStyle(
                          color: accent, fontWeight: FontWeight.w700,
                          fontSize: 14, fontFamily: 'Menlo')),
                    ]),
                    const SizedBox(height: 4),
                    // Brand pill + model
                    Wrap(
                      spacing: 6,
                      children: [
                        _Pill(r.brand, accent),
                        if (r.model.isNotEmpty) _Pill(r.model, kOutlineBr),
                        if (r.channels > 1) _Pill('${r.channels}ch', kSecondary),
                      ],
                    ),
                    const SizedBox(height: 6),
                    // Credentials
                    if (blocked)
                      Row(children: [
                        Icon(Icons.block_rounded, size: 12, color: kWarning),
                        const SizedBox(width: 4),
                        const Text('Blocked by device',
                            style: TextStyle(color: kWarning, fontSize: 12)),
                      ])
                    else
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color:        kSurfXHigh,
                          borderRadius: BorderRadius.circular(8),
                          border:       Border.all(color: kOutline.withOpacity(0.4)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.key_rounded, size: 12, color: kOutlineBr),
                          const SizedBox(width: 5),
                          Text(cred,
                              style: const TextStyle(
                                  color: kSecondary,
                                  fontSize: 12,
                                  fontFamily: 'Menlo',
                                  fontWeight: FontWeight.w500)),
                          const SizedBox(width: 6),
                          const Icon(Icons.copy_rounded, size: 11, color: kOutlineBr),
                        ]),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color  color;
  const _Pill(this.text, this.color);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
        decoration: BoxDecoration(
          color:        color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(text,
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w700)));
}
