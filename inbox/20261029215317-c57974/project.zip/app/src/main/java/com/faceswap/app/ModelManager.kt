package com.faceswap.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Управляет загрузкой и хранением ONNX-моделей.
 *
 * Стратегия: для каждой модели перебираем зеркала по очереди.
 * Если всё заблокировано — бросаем ManualDownloadRequired с инструкцией.
 */
object ModelManager {

    private const val TAG = "ModelManager"

    data class ModelInfo(
        val filename: String,
        val mirrors: List<String>,   // перебираем по очереди
        val sizeBytes: Long
    )

    /** Исключение с инструкцией для пользователя — показываем в UI. */
    class ManualDownloadRequired(val instructions: String) : Exception(instructions)

    val MODELS = listOf(
        ModelInfo(
            filename = "det_10g.onnx",
            mirrors = listOf(
                // GitHub CDN
                "https://github.com/facefusion/facefusion-assets/releases/download/models/det_10g.onnx",
                // HuggingFace зеркала
                "https://huggingface.co/Nomnommish/FaceDetection/resolve/main/det_10g.onnx",
                "https://huggingface.co/Patil/inswapper/resolve/main/det_10g.onnx",
                // HuggingFace CDN (иногда доступен отдельно от основного домена)
                "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/det_10g.onnx"
            ),
            sizeBytes = 16_900_000L
        ),
        ModelInfo(
            filename = "w600k_r50.onnx",
            mirrors = listOf(
                "https://github.com/facefusion/facefusion-assets/releases/download/models/arcface_w600k_r50.onnx",
                "https://huggingface.co/Nomnommish/FaceDetection/resolve/main/w600k_r50.onnx",
                "https://huggingface.co/Patil/inswapper/resolve/main/w600k_r50.onnx"
            ),
            sizeBytes = 174_000_000L
        ),
        ModelInfo(
            filename = "inswapper_128.onnx",
            mirrors = listOf(
                "https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx",
                "https://huggingface.co/Nomnommish/FaceDetection/resolve/main/inswapper_128.onnx",
                "https://huggingface.co/Patil/inswapper/resolve/main/inswapper_128.onnx",
                "https://huggingface.co/victorisgeek/Inswapper128/resolve/main/inswapper_128.onnx"
            ),
            sizeBytes = 554_000_000L
        )
    )

    fun modelsDir(context: Context): File =
        File(context.filesDir, "models").also { it.mkdirs() }

    fun modelFile(context: Context, name: String): File =
        File(modelsDir(context), name)

    /** Все ли модели уже скачаны и не пустые? */
    fun areModelsReady(context: Context): Boolean =
        MODELS.all { model ->
            val f = modelFile(context, model.filename)
            f.exists() && f.length() > 1_000_000L
        }

    /**
     * Возвращает инструкцию для ручного скачивания (показывается если все зеркала недоступны).
     */
    fun manualDownloadInstructions(context: Context): String {
        val dir = modelsDir(context).absolutePath
        return """
Все зеркала недоступны. Скачайте файлы вручную на ПК и скопируйте на телефон:

1. det_10g.onnx (17 МБ)
   https://github.com/facefusion/facefusion-assets/releases/download/models/det_10g.onnx

2. w600k_r50.onnx (166 МБ)
   https://github.com/facefusion/facefusion-assets/releases/download/models/arcface_w600k_r50.onnx

3. inswapper_128.onnx (544 МБ)
   https://huggingface.co/ezioruan/inswapper_128.onnx/resolve/main/inswapper_128.onnx

Положите все три файла в папку на телефоне:
  $dir

Затем нажмите «Проверить модели».
        """.trimIndent()
    }

    /**
     * Скачивает недостающие модели, перебирая зеркала.
     * При полной недоступности бросает [ManualDownloadRequired].
     */
    suspend fun downloadModels(
        context: Context,
        onProgress: (modelName: String, percent: Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        for (model in MODELS) {
            val dest = modelFile(context, model.filename)
            // Удаляем брошенный .tmp
            File(dest.parent, dest.name + ".tmp").takeIf { it.exists() }?.delete()

            if (dest.exists() && dest.length() > 1_000_000L) {
                Log.d(TAG, "${model.filename} уже есть, пропуск")
                onProgress(model.filename, 100)
                continue
            }

            var lastError: Exception? = null
            var success = false

            for ((i, mirror) in model.mirrors.withIndex()) {
                Log.d(TAG, "Пробуем зеркало ${i + 1}/${model.mirrors.size}: $mirror")
                onProgress(model.filename, 0)
                try {
                    downloadFile(mirror, dest, model.sizeBytes) { pct ->
                        onProgress(model.filename, pct)
                    }
                    success = true
                    break
                } catch (e: Exception) {
                    Log.w(TAG, "Зеркало $mirror недоступно: ${e.message}")
                    lastError = e
                    File(dest.parent, dest.name + ".tmp").delete()
                }
            }

            if (!success) {
                throw ManualDownloadRequired(manualDownloadInstructions(context))
            }
        }
    }

    /**
     * Копирует файл из внешнего хранилища в папку моделей (для ручной установки).
     */
    fun installModelFromFile(context: Context, srcFile: File, modelName: String): Boolean {
        if (!MODELS.any { it.filename == modelName }) return false
        val dest = modelFile(context, modelName)
        return try {
            srcFile.copyTo(dest, overwrite = true)
            dest.length() > 1_000_000L
        } catch (e: Exception) {
            Log.e(TAG, "Ошибка установки $modelName: ${e.message}")
            false
        }
    }

    private fun downloadFile(
        urlStr: String,
        dest: File,
        approxSize: Long,
        onProgress: (Int) -> Unit
    ) {
        val tmp = File(dest.parent, dest.name + ".tmp")
        val url = URL(urlStr)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 120_000   // 2 мин на чтение — большие файлы
        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
        conn.instanceFollowRedirects = true
        conn.connect()

        val code = conn.responseCode
        if (code != HttpURLConnection.HTTP_OK) {
            conn.disconnect()
            throw RuntimeException("HTTP $code от $urlStr")
        }

        val contentLen = if (conn.contentLengthLong > 0) conn.contentLengthLong else approxSize
        val buf = ByteArray(32_768)   // 32 КБ буфер — быстрее для больших файлов
        var downloaded = 0L

        try {
            conn.inputStream.use { inp ->
                FileOutputStream(tmp).use { out ->
                    var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n)
                        downloaded += n
                        val pct = ((downloaded * 100) / contentLen).toInt().coerceIn(0, 99)
                        onProgress(pct)
                    }
                }
            }
        } finally {
            conn.disconnect()
        }

        if (downloaded < 1_000_000L) {
            tmp.delete()
            throw RuntimeException("Файл слишком мал ($downloaded байт) — возможно редирект на страницу ошибки")
        }

        tmp.renameTo(dest)
        onProgress(100)
        Log.d(TAG, "${dest.name} скачан (${downloaded / 1_048_576} МБ)")
    }
}
