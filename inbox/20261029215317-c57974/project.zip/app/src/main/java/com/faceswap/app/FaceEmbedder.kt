package com.faceswap.app

import android.graphics.Bitmap
import android.graphics.Matrix
import android.util.Log
import ai.onnxruntime.*
import java.nio.FloatBuffer
import kotlin.math.sqrt

/**
 * ArcFace эмбеддер (w600k_r50.onnx).
 * Принимает выровненное лицо 112x112, возвращает L2-нормализованный вектор 512 чисел.
 */
class FaceEmbedder(modelPath: String) : AutoCloseable {

    private val TAG = "FaceEmbedder"
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession

    // Канонические точки ArcFace для аффинного выравнивания (112x112)
    private val ARCFACE_TEMPLATE = floatArrayOf(
        38.2946f, 51.6963f,   // левый глаз
        73.5318f, 51.5014f,   // правый глаз
        56.0252f, 71.7366f,   // нос
        41.5493f, 92.3655f,   // левый уголок рта
        70.7299f, 92.2041f    // правый уголок рта
    )

    init {
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(4)
            try { addNnapi() } catch (e: Exception) {
                Log.w(TAG, "NNAPI недоступен, продолжаем на CPU: ${e.message}")
            }
        }
        session = env.createSession(modelPath, opts)
        Log.d(TAG, "ArcFace загружен: $modelPath")
    }

    /**
     * Вычисляет эмбеддинг лица.
     * [srcBitmap] — оригинальное изображение.
     * [landmarks] — 10 чисел из FaceDetector (5 точек x,y).
     */
    fun embed(srcBitmap: Bitmap, landmarks: FloatArray): FloatArray {
        val aligned = alignFace(srcBitmap, landmarks)
        return runModel(aligned)
    }

    /** Аффинное выравнивание лица по 5 ключевым точкам → 112x112. */
    fun alignFace(src: Bitmap, landmarks: FloatArray): Bitmap {
        val matrix = estimateSimilarityTransform(landmarks, ARCFACE_TEMPLATE)
        // Не рециклируем промежуточные bitmap — GC справится.
        // Ручной recycle здесь вызывал "Can't compress a recycled bitmap"
        // когда Bitmap.createScaledBitmap возвращал тот же объект (если уже 112x112).
        val warped = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
        return Bitmap.createScaledBitmap(warped, 112, 112, true)
    }

    private fun runModel(face112: Bitmap): FloatArray {
        val tensor = bitmapToTensor(face112)
        val inputs = mapOf(session.inputNames.first() to tensor)
        val results = session.run(inputs)

        // Читаем через floatBuffer — каст .value как Array<FloatArray> нестабилен
        val outTensor = results.first().value as OnnxTensor
        val buf = outTensor.floatBuffer          // shape [1, 512]
        val raw = FloatArray(buf.remaining())
        buf.get(raw)

        tensor.close()
        results.close()

        return l2Normalize(raw)
    }

    private fun bitmapToTensor(bitmap: Bitmap): OnnxTensor {
        val w = 112; val h = 112
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val buf = FloatBuffer.allocate(1 * 3 * h * w)
        val r = FloatArray(h * w)
        val g = FloatArray(h * w)
        val b = FloatArray(h * w)

        for (i in pixels.indices) {
            val px = pixels[i]
            // нормализация ArcFace: (px - 127.5) / 128.0
            b[i] = ((px and 0xFF) - 127.5f) / 128f
            g[i] = (((px shr 8) and 0xFF) - 127.5f) / 128f
            r[i] = (((px shr 16) and 0xFF) - 127.5f) / 128f
        }
        buf.put(r); buf.put(g); buf.put(b)
        buf.rewind()

        return OnnxTensor.createTensor(env, buf, longArrayOf(1, 3, h.toLong(), w.toLong()))
    }

    private fun l2Normalize(v: FloatArray): FloatArray {
        val norm = sqrt(v.sumOf { (it * it).toDouble() }).toFloat()
        return if (norm > 0f) FloatArray(v.size) { v[it] / norm } else v
    }

    /**
     * Оценка матрицы аффинного преобразования методом наименьших квадратов
     * (ограниченная similarity transform: масштаб + поворот + сдвиг).
     *
     * src: 10 чисел (x0,y0, x1,y1, ...) — точки на исходнике
     * dst: 10 чисел — целевые точки ArcFace template
     * Возвращает android.graphics.Matrix.
     *
     * Видимость internal — FaceSwapper вызывает напрямую, без рефлексии.
     */
    internal fun estimateSimilarityTransform(src: FloatArray, dst: FloatArray): Matrix {
        val n = 5
        var a = 0f; var b2 = 0f; var c = 0f; var d = 0f
        for (i in 0 until n) {
            val sx = src[i * 2]; val sy = src[i * 2 + 1]
            val dx = dst[i * 2]; val dy = dst[i * 2 + 1]
            a += sx * dx + sy * dy
            b2 += sy * dx - sx * dy
            c += sx * sx + sy * sy
        }
        if (c == 0f) return Matrix()
        val scale = c / (a * a + b2 * b2).let { if (it == 0f) 1f else sqrt(it.toDouble()).toFloat() }

        // Средние точки
        var srcXm = 0f; var srcYm = 0f; var dstXm = 0f; var dstYm = 0f
        for (i in 0 until n) {
            srcXm += src[i * 2]; srcYm += src[i * 2 + 1]
            dstXm += dst[i * 2]; dstYm += dst[i * 2 + 1]
        }
        srcXm /= n; srcYm /= n; dstXm /= n; dstYm /= n

        // Перебираем стандартный подход через угол поворота
        var sumXX = 0f; var sumXY = 0f
        for (i in 0 until n) {
            val sx = src[i * 2] - srcXm; val sy = src[i * 2 + 1] - srcYm
            val dx = dst[i * 2] - dstXm; val dy = dst[i * 2 + 1] - dstYm
            sumXX += sx * dx + sy * dy
            sumXY += sx * dy - sy * dx
        }
        val srcVar = (0 until n).sumOf {
            val sx = src[it * 2] - srcXm; val sy = src[it * 2 + 1] - srcYm
            (sx * sx + sy * sy).toDouble()
        }.toFloat()

        val sc = if (srcVar > 0f) sumXX / srcVar else 1f
        val ss = if (srcVar > 0f) sumXY / srcVar else 0f

        val tx = dstXm - sc * srcXm + ss * srcYm
        val ty = dstYm - ss * srcXm - sc * srcYm

        // android.graphics.Matrix: [sc, -ss, tx, ss, sc, ty]
        val m = Matrix()
        m.setValues(floatArrayOf(sc, -ss, tx, ss, sc, ty, 0f, 0f, 1f))
        return m
    }

    override fun close() {
        session.close()
        // env — глобальный синглтон OrtEnvironment, не закрываем
    }
}
