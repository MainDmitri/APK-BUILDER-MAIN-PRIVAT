import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  String _base = '';
  static const _short = Duration(seconds: 8);
  static const _long = Duration(seconds: 30);

  void updateBase(String url) {
    _base = url.endsWith('/') ? url.substring(0, url.length - 1) : url;
  }

  Uri _u(String path) => Uri.parse('$_base$path');

  Map<String, dynamic> _dec(http.Response r) {
    if (r.statusCode != 200) return {};
    try { return jsonDecode(r.body) as Map<String, dynamic>; } catch (_) { return {}; }
  }

  Future<bool> ping() async {
    try {
      final r = await http.get(_u('/api/ping')).timeout(_short);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }

  Future<Map<String, dynamic>> getDialogs({String? tab}) async {
    try {
      final q = (tab != null && tab != 'all') ? '?kind=$tab' : '';
      return _dec(await http.get(_u('/api/dialogs$q')).timeout(_long));
    } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> getMessages(String chatId, {
    int limit = 60,
    bool onlyMe = false,
    int? afterId,
  }) async {
    try {
      var path = '/api/chat/$chatId/messages?limit=$limit';
      if (onlyMe) path += '&only_me=1';
      if (afterId != null) path += '&after_id=$afterId';
      return _dec(await http.get(_u(path)).timeout(_long));
    } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> getHistory(String chatId, {
    required int beforeId,
    int limit = 60,
    bool onlyMe = false,
  }) async {
    try {
      var path = '/api/chat/$chatId/history?before_id=$beforeId&limit=$limit';
      if (onlyMe) path += '&only_me=1';
      return _dec(await http.get(_u(path)).timeout(_long));
    } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> getMediaList(String chatId, {
    int offset = 0,
    int limit = 60,
  }) async {
    try {
      return _dec(await http.get(
          _u('/api/chat/$chatId/media?offset=$offset&limit=$limit'))
          .timeout(_long));
    } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> searchMessages(String query) async {
    try {
      final enc = Uri.encodeComponent(query);
      return _dec(await http.get(_u('/api/search?q=$enc&limit=40')).timeout(_long));
    } catch (_) { return {}; }
  }

  Future<Map<String, dynamic>> getStats() async {
    try { return _dec(await http.get(_u('/api/stats')).timeout(_long)); }
    catch (_) { return {}; }
  }

  Future<bool> sendMessage(String chatId, String text, {int? replyTo}) async {
    try {
      final body = <String, dynamic>{'text': text};
      if (replyTo != null) body['reply_to'] = replyTo;
      final r = await http.post(
        _u('/api/chat/$chatId/send'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      ).timeout(_long);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }

  Future<bool> editMessage(String chatId, int msgId, String text) async {
    try {
      final r = await http.post(
        _u('/api/chat/$chatId/edit/$msgId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text}),
      ).timeout(_long);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }

  Future<bool> deleteMessage(String chatId, int msgId) async {
    try {
      final r = await http.delete(_u('/api/chat/$chatId/delete/$msgId')).timeout(_long);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }

  Future<bool> markRead(String chatId) async {
    try {
      final r = await http.post(_u('/api/chat/$chatId/read')).timeout(_short);
      return r.statusCode == 200;
    } catch (_) { return false; }
  }

  String mediaUrl(String chatId, int msgId) =>
      '$_base/api/chat/$chatId/media/$msgId';

  String avatarUrl(String chatId) =>
      '$_base/api/chat/$chatId/avatar';
}
