import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../models/message.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import 'chat_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({super.key});
  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends State<ChatListScreen>
    with WidgetsBindingObserver {
  List<TgDialog> _dialogs = [];
  bool _loading = true;
  String? _error;
  int _tab = 0; // 0=all,1=personal,2=groups,3=channels
  Timer? _pollTimer;
  int _bnav = 0;

  static const _tabs = [
    ('all', 'Все'),
    ('personal', 'Личные'),
    ('groups', 'Группы'),
    ('channels', 'Каналы'),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
    _pollTimer = Timer.periodic(const Duration(seconds: 30), (_) => _load(silent: true));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pollTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load(silent: true);
  }

  ApiService get _api {
    final state = context.read<AppState>();
    final api = context.read<ApiService>();
    api.updateBase(state.serverUrl);
    return api;
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() { _loading = true; _error = null; });
    try {
      final tab = _tabs[_tab].$1;
      final data = await _api.getDialogs(tab: tab);
      if (!mounted) return;
      final raw = (data['dialogs'] as List? ?? []);
      setState(() {
        _dialogs = raw.map((e) => TgDialog.fromJson(e as Map<String, dynamic>)).toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Column(
        children: [
          _buildHeader(),
          _buildTabBar(),
          Expanded(child: _buildBody()),
        ],
      ),
      bottomNavigationBar: _buildBNav(),
    );
  }

  Widget _buildHeader() {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(bottom: BorderSide(color: Color(0xFF1F1F28), width: 1)),
      ),
      padding: EdgeInsets.only(
        top: MediaQuery.of(context).padding.top + 8,
        left: 16, right: 16, bottom: 12,
      ),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFF97316), Color(0xFFEA580C)],
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.send_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Text('CloudCode',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.5)),
          ),
          IconButton(
            icon: const Icon(Icons.search_rounded, color: Color(0xFFA1A1AA)),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SearchScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Color(0xFFA1A1AA)),
            onPressed: () => _load(),
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Row(
        children: List.generate(_tabs.length, (i) {
          final active = i == _tab;
          return GestureDetector(
            onTap: () { setState(() => _tab = i); _load(); },
            child: AnimatedContainer(
              duration: 200.ms,
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
              decoration: BoxDecoration(
                color: active ? const Color(0xFFF97316) : const Color(0xFF18181B),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: active ? const Color(0xFFF97316) : const Color(0xFF27272A),
                ),
              ),
              child: Text(_tabs[i].$2,
                  style: TextStyle(
                      color: active ? Colors.white : const Color(0xFFA1A1AA),
                      fontSize: 13,
                      fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Color(0xFFF97316), strokeWidth: 2),
            SizedBox(height: 16),
            Text('Загрузка чатов...', style: TextStyle(color: Color(0xFF71717A))),
          ],
        ),
      );
    }
    if (_error != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded, color: Color(0xFF52525B), size: 48),
              const SizedBox(height: 16),
              Text(_error!, textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFF71717A), fontSize: 14)),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: _load,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Повторить'),
                style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFF97316),
                    foregroundColor: Colors.white),
              ),
            ],
          ),
        ),
      );
    }
    if (_dialogs.isEmpty) {
      return const Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.inbox_rounded, color: Color(0xFF3F3F46), size: 56),
          SizedBox(height: 12),
          Text('Нет чатов', style: TextStyle(color: Color(0xFF71717A))),
        ]),
      );
    }
    return RefreshIndicator(
      onRefresh: _load,
      color: const Color(0xFFF97316),
      backgroundColor: const Color(0xFF18181B),
      child: ListView.builder(
        itemCount: _dialogs.length,
        itemBuilder: (ctx, i) {
          final d = _dialogs[i];
          return _DialogTile(dialog: d, index: i, onTap: () {
            Navigator.push(context, _slideRoute(ChatScreen(dialog: d)));
          });
        },
      ),
    );
  }

  Widget _buildBNav() {
    final items = [
      (Icons.chat_bubble_rounded, Icons.chat_bubble_outline_rounded, 'Чаты'),
      (Icons.person_rounded, Icons.person_outline_rounded, 'Мои'),
      (Icons.search_rounded, Icons.search_rounded, 'Поиск'),
      (Icons.settings_rounded, Icons.settings_outlined, 'Ещё'),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F0F14),
        border: Border(top: BorderSide(color: Color(0xFF1F1F28), width: 1)),
      ),
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom),
      child: Row(
        children: List.generate(items.length, (i) {
          final active = _bnav == i;
          return Expanded(
            child: GestureDetector(
              onTap: () {
                setState(() => _bnav = i);
                if (i == 2) {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SearchScreen()));
                } else if (i == 3) {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const SettingsScreen()));
                }
              },
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                color: Colors.transparent,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(active ? items[i].$1 : items[i].$2,
                        color: active
                            ? const Color(0xFFF97316)
                            : const Color(0xFF52525B),
                        size: 24),
                    const SizedBox(height: 3),
                    Text(items[i].$3,
                        style: TextStyle(
                            color: active
                                ? const Color(0xFFF97316)
                                : const Color(0xFF52525B),
                            fontSize: 10,
                            fontWeight: active
                                ? FontWeight.w600
                                : FontWeight.w400)),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }

  Route _slideRoute(Widget page) {
    return PageRouteBuilder(
      pageBuilder: (_, a, __) => page,
      transitionsBuilder: (_, a, __, child) => SlideTransition(
        position: Tween(begin: const Offset(1, 0), end: Offset.zero)
            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
        child: child,
      ),
      transitionDuration: const Duration(milliseconds: 280),
    );
  }
}

class _DialogTile extends StatelessWidget {
  final TgDialog dialog;
  final int index;
  final VoidCallback onTap;
  const _DialogTile({required this.dialog, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        splashColor: const Color(0xFFF97316).withOpacity(0.08),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          child: Row(
            children: [
              _Avatar(title: dialog.title, kind: dialog.kind),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(dialog.title,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.5,
                                  fontWeight: FontWeight.w600),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ),
                        if (dialog.lastSeen.isNotEmpty)
                          Text(_fmtDate(dialog.lastSeen),
                              style: const TextStyle(
                                  color: Color(0xFF71717A), fontSize: 12)),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Expanded(
                          child: Text(dialog.lastMessage,
                              style: const TextStyle(
                                  color: Color(0xFF71717A), fontSize: 13.5),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis),
                        ),
                        if (dialog.unread > 0)
                          Container(
                            margin: const EdgeInsets.only(left: 6),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF97316),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text('${dialog.unread}',
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600)),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ).animate(delay: Duration(milliseconds: index * 30))
        .fadeIn(duration: 250.ms)
        .slideX(begin: 0.05, end: 0, duration: 250.ms);
  }

  String _fmtDate(String raw) {
    try {
      final dt = DateTime.parse(raw);
      final now = DateTime.now();
      if (dt.day == now.day && dt.month == now.month && dt.year == now.year) {
        return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
      }
      return '${dt.day}.${dt.month.toString().padLeft(2, '0')}';
    } catch (_) {
      return raw.length > 10 ? raw.substring(5, 10) : raw;
    }
  }
}

class _Avatar extends StatelessWidget {
  final String title;
  final String kind;
  const _Avatar({required this.title, required this.kind});

  Color get _color {
    final colors = [
      const Color(0xFFF97316), const Color(0xFF8B5CF6),
      const Color(0xFF06B6D4), const Color(0xFF22C55E),
      const Color(0xFFEC4899), const Color(0xFFEAB308),
    ];
    final idx = (title.isNotEmpty ? title.codeUnitAt(0) : 0) % colors.length;
    return colors[idx];
  }

  IconData get _icon {
    if (kind == 'channel') return Icons.campaign_rounded;
    if (kind == 'group') return Icons.group_rounded;
    return Icons.person_rounded;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52, height: 52,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [_color, _color.withOpacity(0.7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        shape: BoxShape.circle,
        boxShadow: [
          BoxShadow(
            color: _color.withOpacity(0.3),
            blurRadius: 8, offset: const Offset(0, 2),
          ),
        ],
      ),
      child: title.isNotEmpty
          ? Center(
              child: Text(title[0].toUpperCase(),
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.w700)),
            )
          : Icon(_icon, color: Colors.white, size: 24),
    );
  }
}
