import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../services/session_installer.dart';
import 'chat_list_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _urlCtrl = TextEditingController(text: 'http://192.168.1.');
  bool _testing = false;
  bool? _ok;
  String _error = '';
  Map<String, dynamic>? _account;
  String _sessionsPath = '';

  @override
  void initState() {
    super.initState();
    _loadAccountInfo();
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadAccountInfo() async {
    try {
      final raw = await SessionInstaller.accountsJson;
      final data = jsonDecode(raw) as Map<String, dynamic>;
      final accounts = data['accounts'] as List? ?? [];
      final path = await SessionInstaller.sessionsPath;
      if (mounted) {
        setState(() {
          _account = accounts.isNotEmpty
              ? accounts.first as Map<String, dynamic>
              : null;
          _sessionsPath = path;
        });
      }
    } catch (_) {}
  }

  Future<void> _test() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) return;
    setState(() { _testing = true; _ok = null; _error = ''; });
    try {
      final api = context.read<ApiService>();
      api.updateBase(url);
      final ok = await api.ping();
      if (!mounted) return;
      setState(() { _testing = false; _ok = ok; _error = ok ? '' : 'Сервер не отвечает'; });
      if (ok) {
        await context.read<AppState>().setServer(url);
        await Future.delayed(const Duration(milliseconds: 600));
        if (mounted) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const ChatListScreen()));
        }
      }
    } catch (e) {
      if (mounted) setState(() { _testing = false; _ok = false; _error = e.toString(); });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: ListView(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).padding.top + 24,
          left: 24, right: 24, bottom: 40,
        ),
        children: [
          _buildLogo(),
          const SizedBox(height: 32),
          if (_account != null) _buildAccountCard(),
          const SizedBox(height: 20),
          _buildSessionsCard(),
          const SizedBox(height: 24),
          _buildServerCard(),
          const SizedBox(height: 20),
          _buildInstructionCard(),
        ],
      ),
    );
  }

  Widget _buildLogo() {
    return Column(
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [Color(0xFFF97316), Color(0xFFEA580C)],
            ),
            boxShadow: [BoxShadow(
              color: const Color(0xFFF97316).withOpacity(0.4),
              blurRadius: 24, offset: const Offset(0, 6),
            )],
          ),
          child: const Icon(Icons.send_rounded, color: Colors.white, size: 36),
        ).animate().scale(duration: 400.ms, curve: Curves.elasticOut),
        const SizedBox(height: 16),
        const Text('Настройка сервера',
            style: TextStyle(color: Colors.white, fontSize: 24,
                fontWeight: FontWeight.w700))
            .animate().fadeIn(delay: 200.ms),
        const SizedBox(height: 6),
        const Text('Запустите Python-сервер на том же Wi-Fi',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFF71717A), fontSize: 14))
            .animate().fadeIn(delay: 300.ms),
      ],
    );
  }

  Widget _buildAccountCard() {
    final name = _account?['label'] as String? ??
        _account?['name'] as String? ?? '—';
    final phone = _account?['phone'] as String? ?? '—';
    final username = _account?['username'] as String? ?? '';
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF22C55E).withOpacity(0.15),
            const Color(0xFF16A34A).withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF22C55E).withOpacity(0.4)),
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [Color(0xFF22C55E), Color(0xFF16A34A)],
              ),
            ),
            child: Center(
              child: Text(name[0].toUpperCase(),
                  style: const TextStyle(color: Colors.white,
                      fontSize: 20, fontWeight: FontWeight.w700)),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Аккаунт встроен',
                    style: TextStyle(color: Color(0xFF22C55E),
                        fontSize: 12, fontWeight: FontWeight.w600)),
                Text(name, style: const TextStyle(
                    color: Colors.white, fontSize: 16,
                    fontWeight: FontWeight.w600)),
                Text(username.isNotEmpty ? '@$username · $phone' : phone,
                    style: const TextStyle(
                        color: Color(0xFF71717A), fontSize: 12)),
              ],
            ),
          ),
          const Icon(Icons.check_circle_rounded,
              color: Color(0xFF22C55E), size: 24),
        ],
      ),
    ).animate().fadeIn(delay: 350.ms).slideY(begin: 0.05, end: 0);
  }

  Widget _buildSessionsCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF27272A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.folder_rounded, color: Color(0xFFF97316), size: 18),
              SizedBox(width: 8),
              Text('Сессии скопированы в:',
                  style: TextStyle(color: Color(0xFFA1A1AA), fontSize: 13)),
            ],
          ),
          const SizedBox(height: 6),
          GestureDetector(
            onTap: () {
              Clipboard.setData(ClipboardData(text: _sessionsPath));
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Путь скопирован'),
                    duration: Duration(seconds: 1)));
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFF18181B),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      _sessionsPath.isNotEmpty ? _sessionsPath : 'Загрузка...',
                      style: const TextStyle(
                          color: Color(0xFF71717A), fontSize: 11,
                          fontFamily: 'monospace'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.copy_rounded,
                      color: Color(0xFF52525B), size: 14),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Укажите этот путь в main.py как SESSION_DIR при запуске сервера.',
            style: TextStyle(color: Color(0xFF52525B), fontSize: 11),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 400.ms);
  }

  Widget _buildServerCard() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('IP адрес сервера',
            style: TextStyle(color: Color(0xFF71717A), fontSize: 13,
                fontWeight: FontWeight.w500)),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF0F0F14),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _ok == true
                ? const Color(0xFF22C55E)
                : _ok == false
                    ? const Color(0xFFEF4444)
                    : const Color(0xFF27272A)),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _urlCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  keyboardType: TextInputType.url,
                  decoration: const InputDecoration(
                    hintText: 'http://192.168.1.x:5000',
                    hintStyle: TextStyle(color: Color(0xFF3F3F46)),
                    contentPadding: EdgeInsets.symmetric(
                        horizontal: 16, vertical: 14),
                    border: InputBorder.none,
                  ),
                ),
              ),
              GestureDetector(
                onTap: _testing ? null : _test,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.all(6),
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      colors: _ok == true
                          ? [const Color(0xFF22C55E), const Color(0xFF16A34A)]
                          : _ok == false
                              ? [const Color(0xFFEF4444), const Color(0xFFDC2626)]
                              : [const Color(0xFFF97316), const Color(0xFFEA580C)],
                    ),
                    boxShadow: [BoxShadow(
                      color: (_ok == true
                              ? const Color(0xFF22C55E)
                              : const Color(0xFFF97316))
                          .withOpacity(0.4),
                      blurRadius: 10,
                    )],
                  ),
                  child: Center(
                    child: _testing
                        ? const SizedBox(
                            width: 20, height: 20,
                            child: CircularProgressIndicator(
                                color: Colors.white, strokeWidth: 2))
                        : Icon(
                            _ok == true
                                ? Icons.check_rounded
                                : _ok == false
                                    ? Icons.refresh_rounded
                                    : Icons.arrow_forward_rounded,
                            color: Colors.white, size: 22),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_error.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6, left: 4),
            child: Text(_error,
                style: const TextStyle(
                    color: Color(0xFFEF4444), fontSize: 12)),
          ),
        if (_ok == true)
          Padding(
            padding: const EdgeInsets.only(top: 6, left: 4),
            child: const Text('✓ Подключено — открываю чаты...',
                style: TextStyle(color: Color(0xFF22C55E), fontSize: 12)),
          ),
      ],
    ).animate().fadeIn(delay: 450.ms).slideY(begin: 0.04, end: 0);
  }

  Widget _buildInstructionCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F14),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF27272A)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.terminal_rounded,
                  color: Color(0xFF71717A), size: 16),
              SizedBox(width: 8),
              Text('Запуск сервера',
                  style: TextStyle(color: Color(0xFF71717A),
                      fontSize: 12, fontWeight: FontWeight.w600)),
            ],
          ),
          const SizedBox(height: 10),
          _CodeLine('cd /путь/к/серверу'),
          _CodeLine('python main.py'),
          const SizedBox(height: 8),
          const Text(
            'Сервер должен быть запущен на том же Wi-Fi что и телефон.',
            style: TextStyle(color: Color(0xFF52525B), fontSize: 11),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 500.ms);
  }
}

class _CodeLine extends StatelessWidget {
  final String code;
  const _CodeLine(this.code);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Clipboard.setData(ClipboardData(text: code));
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Скопировано'),
              duration: Duration(seconds: 1)));
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF18181B),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: const Color(0xFF27272A)),
        ),
        child: Text('\$ $code',
            style: const TextStyle(color: Color(0xFF22C55E),
                fontSize: 13, fontFamily: 'monospace')),
      ),
    );
  }
}
